package com.idongbu.smartcustomer.counter.carRider.mileage.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.io.FileUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.mybatis.spring.SqlSessionTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.idongbu.common.ESBBizHeader;
import com.idongbu.common.ESBChannelHeader;
import com.idongbu.common.ESBManager;
import com.idongbu.common.XmlUtil;
import com.idongbu.smartcustomer.counter.carRider.common.service.FileTobeService;
import com.idongbu.smartcustomer.counter.carRider.demo.DBTestDao;
import com.idongbu.smartcustomer.counter.carRider.demo.MBTR01001VO;
import com.idongbu.smartcustomer.counter.carRider.demo.MBTT02001VO;
//import com.idongbu.smartcustomer.counter.carRider.common.service.CarRiderJMService;
import com.idongbu.smartcustomer.vo.FileMeta;
import com.idongbu.smartzone.vo.MMTI0015VO;
import com.idongbu.smartzone.vo.MMTI0213VO;
import com.idongbu.smartzone.vo.MMTI0217VO;
import com.idongbu.smartzone.vo.MMTI0218VO;
import com.idongbu.smartzone.vo.MMTI0259VO;
import com.idongbu.smartzone.vo.MMTI0289VO;
import com.idongbu.smartzone.vo.MMTI0291VO;
import com.idongbu.smartzone.vo.MMTI0294VO;
import com.idongbu.smartzone.vo.MMTI0305VO;
import com.idongbu.smartzone.vo.MMTI0321VO;
import com.idongbu.smartzone.vo.XIDB0004VO;
import com.idongbu.smartzone.vo.XTEM0021VO;
import com.idongbu.util.DateUtil;
import com.idongbu.util.StringUtil;

@Service
public class MileageTobeService {

	private @Value("${legacy.homepage_jojikwon_cd}") String HOMEPAGE_JOJIKWON_CD;

	private @Value("${carrider.upload.temp.path}") String CARRIDER_UPLOAD_TEMP_PATH;
	private @Value("${aiocr.upload.temp.path}") String AIOCR_UPLOAD_TEMP_PATH;
	private @Value("${esb.Realip}") String ESBURL;
	private @Value("${dm.aes.key}") String dmAesKey;
	private static final String CHAT_EMPNO = "80000176";

	// 테스트
	@Autowired(required=true)
	@Qualifier("sqlSession")
	protected SqlSessionTemplate sqlSession;
	// 테스트
	
	@Autowired(required=true)
	private FileTobeService fileTobeService; 	

	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@SuppressWarnings("static-access")
	public MMTI0213VO getMMTI0213VO(MMTI0213VO jmvo) throws Exception {
		logger.info("############### NEVER MMTI0213VO ###############");
		String UserId = HOMEPAGE_JOJIKWON_CD;                                                                                                                                                                                           
		String formId = "MMTI0213";                                                                                                                                                                                           
		String telegram = "MMTI"; // esb                                                                                                                                                                                      
		                                                                                                                                                                                                                      
		ESBManager em = new ESBManager();                                                                                                                                                                                     
		ESBChannelHeader channelHead = new ESBChannelHeader();                                                                                                                                                                
		ESBBizHeader bizHead = new ESBBizHeader();     
		
		bizHead = em.makeDefaultBizHeader(UserId);                                                                                                                                                                            
		channelHead = em.makeDefaultChannelHeader(formId, UserId);  
		String Url = ESBURL;
		logger.debug("Url: " + Url);
		String rtnXmlString = (String)XmlUtil.callESBToString(channelHead, bizHead, jmvo, Url, telegram);                                                                                                                   
		                                                                                                                                                                                                                      
		logger.debug("##############################");                                                                                                                                                                       
		logger.debug(rtnXmlString);                                                                                                                                                                                           
		logger.debug("##############################");                                                                                                                                                                       
		                                                                                                                                                                                                                      
		jmvo = (MMTI0213VO) ESBManager.xmlToVOnew(rtnXmlString, (MMTI0213VO)jmvo);                                                                                                                      
		                                                                                                                                                                                                                      
		return jmvo;
	}
	
	//만기정산 테스트 로직 추가
	@SuppressWarnings("static-access")
	public MMTI0213VO getMMTI0213VO(MMTI0213VO jmvo, String adminSeq) throws Exception {
		logger.info("###############ESBadminSeq : " + adminSeq + "###############");
		if (adminSeq.equals("dongbu")) {
			logger.info("###############adminSeq ESB blocked###############");
		} else {
			String UserId = HOMEPAGE_JOJIKWON_CD;                                                                                                                                                                                           
			String formId = "MMTI0213";                                                                                                                                                                                           
			String telegram = "MMTI"; // esb                                                                                                                                                                                      
		                                                                                                                                                                                                                      
			ESBManager em = new ESBManager();                                                                                                                                                                                     
			ESBChannelHeader channelHead = new ESBChannelHeader();                                                                                                                                                                
			ESBBizHeader bizHead = new ESBBizHeader();     
			
			bizHead = em.makeDefaultBizHeader(UserId);                                                                                                                                                                            
			channelHead = em.makeDefaultChannelHeader(formId, UserId);  
			String Url = ESBURL;
			logger.debug("Url: " + Url);
			logger.info("###############ESBadminSeq : " + adminSeq + "###############");
			String rtnXmlString = (String)XmlUtil.callESBToString(channelHead, bizHead, jmvo, Url, telegram);                                                                                                                   
			                                                                                                                                                                                                                      
			logger.debug("##############################");                                                                                                                                                                       
			logger.debug(rtnXmlString);                                                                                                                                                                                           
			logger.debug("##############################");
			jmvo = (MMTI0213VO) ESBManager.xmlToVOnew(rtnXmlString, (MMTI0213VO) jmvo);
		}
			
		return jmvo;
	}
	
	@SuppressWarnings("static-access")
	public MMTI0259VO getMMTI0259VO(MMTI0259VO jmvo) throws Exception {
		logger.info("############### NEVER MMTI0259VO ###############");
		String UserId = HOMEPAGE_JOJIKWON_CD;                                                                                                                                                                                           
		String formId = "MMTI0259";                                                                                                                                                                                           
		String telegram = "MMTI"; // esb                                                                                                                                                                                      
		                                                                                                                                                                                                                      
		ESBManager em = new ESBManager();                                                                                                                                                                                     
		ESBChannelHeader channelHead = new ESBChannelHeader();                                                                                                                                                                
		ESBBizHeader bizHead = new ESBBizHeader();     
		
		bizHead = em.makeDefaultBizHeader(UserId);                                                                                                                                                                            
		channelHead = em.makeDefaultChannelHeader(formId, UserId);  
		String Url = ESBURL;
		logger.debug("Url: " + Url);
		String rtnXmlString = (String)XmlUtil.callESBToString(channelHead, bizHead, jmvo, Url, telegram);                                                                                                                   
		                                                                                                                                                                                                                      
		logger.debug("##############################");                                                                                                                                                                       
		logger.debug(rtnXmlString);                                                                                                                                                                                           
		logger.debug("##############################");                                                                                                                                                                       
		                                                                                                                                                                                                                      
		jmvo = (MMTI0259VO) ESBManager.xmlToVOnew(rtnXmlString, (MMTI0259VO)jmvo);                                                                                                                      
		                                                                                                                                                                                                                      
		return jmvo;
	}

	//만기정산 테스트 로직 추가
	@SuppressWarnings("static-access")
	public MMTI0259VO getMMTI0259VO(MMTI0259VO jmvo, String adminSeq) throws Exception {
		logger.info("###############ESBadminSeq : " + adminSeq + "###############");
		if (adminSeq.equals("dongbu")) {
			logger.info("###############adminSeq ESB blocked###############");
		} else {
			String UserId = HOMEPAGE_JOJIKWON_CD;
			String formId = "MMTI0259";
			String telegram = "MMTI"; // esb
		
			ESBManager em = new ESBManager();
			ESBChannelHeader channelHead = new ESBChannelHeader();
			ESBBizHeader bizHead = new ESBBizHeader();
		
			bizHead = em.makeDefaultBizHeader(UserId);                                                                                                                                                                            
			channelHead = em.makeDefaultChannelHeader(formId, UserId);  
			String Url = ESBURL;
			logger.debug("Url: " + Url);
			String rtnXmlString = (String)XmlUtil.callESBToString(channelHead, bizHead, jmvo, Url, telegram);                                                                                                                   
			
			logger.debug("##############################");
			logger.debug(rtnXmlString);
			logger.debug("##############################");
	
			jmvo = (MMTI0259VO) ESBManager.xmlToVOnew(rtnXmlString, (MMTI0259VO)jmvo);
		}
		return jmvo;
	}
	
	@SuppressWarnings("static-access")
	public MMTI0321VO getMMTI0321VO(MMTI0321VO jmvo) throws Exception {
		String UserId = HOMEPAGE_JOJIKWON_CD;                                                                                                                                                                                           
		String formId = "MMTI0321";                                                                                                                                                                                           
		String telegram = "MMTI"; // esb                                                                                                                                                                                      
		                                                                                                                                                                                                                      
		ESBManager em = new ESBManager();                                                                                                                                                                                     
		ESBChannelHeader channelHead = new ESBChannelHeader();                                                                                                                                                                
		ESBBizHeader bizHead = new ESBBizHeader();     
		
		bizHead = em.makeDefaultBizHeader(UserId);                                                                                                                                                                            
		channelHead = em.makeDefaultChannelHeader(formId, UserId);  
		String Url = ESBURL;
		logger.debug("Url: " + Url);
		String rtnXmlString = (String)XmlUtil.callESBToString(channelHead, bizHead, jmvo, Url, telegram);                                                                                                                   
		                                                                                                                                                                                                                      
		logger.debug("##############################");                                                                                                                                                                       
		logger.debug(rtnXmlString);                                                                                                                                                                                           
		logger.debug("##############################");                                                                                                                                                                       
		                                                                                                                                                                                                                      
		jmvo = (MMTI0321VO) ESBManager.xmlToVOnew(rtnXmlString, (MMTI0321VO)jmvo);                                                                                                                      
		                                                                                                                                                                                                                      
		return jmvo;
	}
	
	//20220816 AIOCR용 EDMS 업로드(CM인 경우)
	public MBTR01001VO aiocrRegInfoToEdmsForMobileWeb(MultipartHttpServletRequest request, String sms_ts_bvan, MBTR01001VO mbtr01001vo) throws Exception {
		boolean result = false;

		// 등록관련정보조회 서블릿을 호출해서 User ID 조회
		Map<String, String> edmsPreRegInfo = fileTobeService.getEdmsIdForMobileWeb(sms_ts_bvan);
		if(!"1".equals(edmsPreRegInfo.get("RtnCd"))) {
			throw new Exception(edmsPreRegInfo.get("Message"));
		}		

		// 이미지 업로드
		LinkedList<FileMeta> linkedList = fileTobeService.aiocrUpload(request, AIOCR_UPLOAD_TEMP_PATH, sms_ts_bvan);
//		LinkedList<FileMeta> linkedList = fileTobeService.upload(request, CARRIDER_UPLOAD_TEMP_PATH, sms_ts_bvan);

		if(linkedList == null || linkedList.size() == 0) {
			throw new Exception("파일 업로드 실패 [ 업로드할 파일이 없거나 이미지파일이 아닙니다. ]");
		}

		for(int i = 0; i < linkedList.size(); i++) {
			FileMeta fileMeta = linkedList.get(i);

			File file = new File(AIOCR_UPLOAD_TEMP_PATH + fileMeta.getFileName());

			String exifDate = "";
			if(i == 0) exifDate = StringUtil.nvl(request.getParameter("exifDate1"));
			else if(i == 1) exifDate = StringUtil.nvl(request.getParameter("exifDate2"));
			if(exifDate.indexOf(",gallery") > -1) {
				exifDate = exifDate.substring(0, exifDate.indexOf(",gallery"));
			}
			
//				result = fileTobeService.docRegToEdms2(edmsPreRegInfo, file, null, exifDate);
			logger.debug("result: " + result);
			mbtr01001vo = fileTobeService.docRegToEdms2(edmsPreRegInfo, file, null, exifDate, mbtr01001vo);
			
//				if(!result)
			if("N".equals(mbtr01001vo.getNrmYn()))
				throw new Exception("EDMS에 파일전송 실패");
		}
		return mbtr01001vo;
	}
	
	//20220608 원본2
	public void regInfoToEdmsForMobileWeb(MultipartHttpServletRequest request, String sms_ts_bvan) throws Exception {
		boolean result = false;

		// 등록관련정보조회 서블릿을 호출해서 User ID 조회
		Map<String, String> edmsPreRegInfo = fileTobeService.getEdmsIdForMobileWeb(sms_ts_bvan);
		if(!"1".equals(edmsPreRegInfo.get("RtnCd"))) {
			throw new Exception(edmsPreRegInfo.get("Message"));
		}		

		// 이미지 업로드
		LinkedList<FileMeta> linkedList = fileTobeService.upload(request, CARRIDER_UPLOAD_TEMP_PATH, sms_ts_bvan);		

		if(linkedList == null || linkedList.size() == 0) {
			throw new Exception("파일 업로드 실패 [ 업로드할 파일이 없거나 이미지파일이 아닙니다. ]");
		}

		for(int i = 0; i < linkedList.size(); i++) {
			FileMeta fileMeta = linkedList.get(i);

			File file = new File(CARRIDER_UPLOAD_TEMP_PATH + fileMeta.getFileName());

			String exifDate = "";
			if(i == 0) exifDate = StringUtil.nvl(request.getParameter("exifDate1"));
			else if(i == 1) exifDate = StringUtil.nvl(request.getParameter("exifDate2"));
			if(exifDate.indexOf(",gallery") > -1) {
				exifDate = exifDate.substring(0, exifDate.indexOf(",gallery"));
			}
			
			result = fileTobeService.docRegToEdms2(edmsPreRegInfo, file, null, exifDate);
			logger.debug("result: " + result);
			
			if(!result)
				throw new Exception("EDMS에 파일전송 실패");
		}
	}
	
	//20220608 원본2(aiocr용)
	public void aiocrRegInfoToEdmsForMobileWeb(MultipartHttpServletRequest request, String sms_ts_bvan) throws Exception {
		boolean result = false;

		// 등록관련정보조회 서블릿을 호출해서 User ID 조회
		Map<String, String> edmsPreRegInfo = fileTobeService.getEdmsIdForMobileWeb(sms_ts_bvan);
		if(!"1".equals(edmsPreRegInfo.get("RtnCd"))) {
			throw new Exception(edmsPreRegInfo.get("Message"));
		}		

		// 이미지 업로드
		LinkedList<FileMeta> linkedList = fileTobeService.aiocrUpload(request, AIOCR_UPLOAD_TEMP_PATH, sms_ts_bvan);		

		if(linkedList == null || linkedList.size() == 0) {
			throw new Exception("파일 업로드 실패 [ 업로드할 파일이 없거나 이미지파일이 아닙니다. ]");
		}

		for(int i = 0; i < linkedList.size(); i++) {
			FileMeta fileMeta = linkedList.get(i);

			File file = new File(AIOCR_UPLOAD_TEMP_PATH + fileMeta.getFileName());

			String exifDate = "";
			if(i == 0) exifDate = StringUtil.nvl(request.getParameter("exifDate1"));
			else if(i == 1) exifDate = StringUtil.nvl(request.getParameter("exifDate2"));
			if(exifDate.indexOf(",gallery") > -1) {
				exifDate = exifDate.substring(0, exifDate.indexOf(",gallery"));
			}
			
			result = fileTobeService.docRegToEdms2(edmsPreRegInfo, file, null, exifDate);
			logger.debug("result: " + result);
			
			if(!result)
				throw new Exception("EDMS에 파일전송 실패");
		}
	}
	
	//20220608 수정본2
	public MBTR01001VO regInfoToEdmsForMobileWeb(MultipartHttpServletRequest request, String sms_ts_bvan, MBTR01001VO mbtr01001vo) throws Exception {
		boolean result = false;

		// 등록관련정보조회 서블릿을 호출해서 User ID 조회
		Map<String, String> edmsPreRegInfo = fileTobeService.getEdmsIdForMobileWeb(sms_ts_bvan);
		if(!"1".equals(edmsPreRegInfo.get("RtnCd"))) {
			throw new Exception(edmsPreRegInfo.get("Message"));
		}		

		// 이미지 업로드
		LinkedList<FileMeta> linkedList = fileTobeService.upload(request, CARRIDER_UPLOAD_TEMP_PATH, sms_ts_bvan);		

		if(linkedList == null || linkedList.size() == 0) {
			throw new Exception("파일 업로드 실패 [ 업로드할 파일이 없거나 이미지파일이 아닙니다. ]");
		}

		for(int i = 0; i < linkedList.size(); i++) {
			FileMeta fileMeta = linkedList.get(i);

			File file = new File(CARRIDER_UPLOAD_TEMP_PATH + fileMeta.getFileName());

			String exifDate = "";
			if(i == 0) exifDate = StringUtil.nvl(request.getParameter("exifDate1"));
			else if(i == 1) exifDate = StringUtil.nvl(request.getParameter("exifDate2"));
			if(exifDate.indexOf(",gallery") > -1) {
				exifDate = exifDate.substring(0, exifDate.indexOf(",gallery"));
			}
			
//			result = fileTobeService.docRegToEdms2(edmsPreRegInfo, file, null, exifDate);
			logger.debug("result: " + result);
			mbtr01001vo = fileTobeService.docRegToEdms2(edmsPreRegInfo, file, null, exifDate, mbtr01001vo);
			
//			if(!result)
			if("N".equals(mbtr01001vo.getNrmYn()))
				throw new Exception("EDMS에 파일전송 실패");
		}
		return mbtr01001vo;
	}
	
	// 이륜차 블랙박스 20220608 원본
	public void regInfoToEdmsForMobileWeb2(MultipartHttpServletRequest request, String sms_ts_bvan) throws Exception {
		boolean result = false;

		// 등록관련정보조회 서블릿을 호출해서 User ID 조회
		Map<String, String> edmsPreRegInfo = fileTobeService.getEdmsIdForMobileWeb2(sms_ts_bvan);
		if(!"1".equals(edmsPreRegInfo.get("RtnCd"))) {
			throw new Exception(edmsPreRegInfo.get("Message"));
		}		

		// 이미지 업로드
		LinkedList<FileMeta> linkedList = fileTobeService.upload(request, CARRIDER_UPLOAD_TEMP_PATH, sms_ts_bvan);		

		if(linkedList == null || linkedList.size() == 0) {
			throw new Exception("파일 업로드 실패 [ 업로드할 파일이 없거나 이미지파일이 아닙니다. ]");
		}

		for(int i = 0; i < linkedList.size(); i++) {
			FileMeta fileMeta = linkedList.get(i);

			File file = new File(CARRIDER_UPLOAD_TEMP_PATH + fileMeta.getFileName());

			String exifDate = "";
			if(i == 0) exifDate = StringUtil.nvl(request.getParameter("exifDate1"));
			if(exifDate.indexOf(",gallery") > -1) {
				exifDate = exifDate.substring(0, exifDate.indexOf(",gallery"));
			}
			
			result = fileTobeService.docRegToEdms3(edmsPreRegInfo, file, null, exifDate);
			logger.debug("result: " + result);
			
			if(!result)
				throw new Exception("EDMS에 파일전송 실패");
		}
	}
	
	// 이륜차 블랙박스 20220608 수정본
	public MBTR01001VO regInfoToEdmsForMobileWeb2(MultipartHttpServletRequest request, String sms_ts_bvan, MBTR01001VO mbtr01001vo) throws Exception {
		boolean result = false;

		// 등록관련정보조회 서블릿을 호출해서 User ID 조회
		Map<String, String> edmsPreRegInfo = fileTobeService.getEdmsIdForMobileWeb2(sms_ts_bvan);
		if(!"1".equals(edmsPreRegInfo.get("RtnCd"))) {
			throw new Exception(edmsPreRegInfo.get("Message"));
		}		

		// 이미지 업로드
		LinkedList<FileMeta> linkedList = fileTobeService.upload(request, CARRIDER_UPLOAD_TEMP_PATH, sms_ts_bvan);		

		if(linkedList == null || linkedList.size() == 0) {
			throw new Exception("파일 업로드 실패 [ 업로드할 파일이 없거나 이미지파일이 아닙니다. ]");
		}

		for(int i = 0; i < linkedList.size(); i++) {
			FileMeta fileMeta = linkedList.get(i);

			File file = new File(CARRIDER_UPLOAD_TEMP_PATH + fileMeta.getFileName());

			String exifDate = "";
			if(i == 0) exifDate = StringUtil.nvl(request.getParameter("exifDate1"));
			if(exifDate.indexOf(",gallery") > -1) {
				exifDate = exifDate.substring(0, exifDate.indexOf(",gallery"));
			}
			
//			result = fileTobeService.docRegToEdms3(edmsPreRegInfo, file, null, exifDate);
//			logger.debug("result: " + result);
			mbtr01001vo = fileTobeService.docRegToEdms3(edmsPreRegInfo, file, null, exifDate, mbtr01001vo);
			
//			if(!result)
			if("N".equals(mbtr01001vo.getNrmYn()))
				throw new Exception("EDMS에 파일전송 실패");
		}
		return mbtr01001vo;
	}
	
	@SuppressWarnings("static-access")
	public MMTI0289VO getMMTI0289VO(MMTI0289VO jmvo) throws Exception {
		String UserId = HOMEPAGE_JOJIKWON_CD;                                                                                                                                                                                           
		String formId = "MMTI0289";                                                                                                                                                                                           
		String telegram = "MMTI"; // esb                                                                                                                                                                                      
		                                                                                                                                                                                                                      
		ESBManager em = new ESBManager();                                                                                                                                                                                     
		ESBChannelHeader channelHead = new ESBChannelHeader();                                                                                                                                                                
		ESBBizHeader bizHead = new ESBBizHeader();     
		
		bizHead = em.makeDefaultBizHeader(UserId);                                                                                                                                                                            
		channelHead = em.makeDefaultChannelHeader(formId, UserId);  
		String Url = ESBURL;
		logger.debug("Url: " + Url);
		String rtnXmlString = (String)XmlUtil.callESBToString(channelHead, bizHead, jmvo, Url, telegram);                                                                                                                   
		                                                                                                                                                                                                                      
		logger.debug("##############################");                                                                                                                                                                       
		logger.debug(rtnXmlString);                                                                                                                                                                                           
		logger.debug("##############################");                                                                                                                                                                       
		                                                                                                                                                                                                                      
		jmvo = (MMTI0289VO) ESBManager.xmlToVOnew(rtnXmlString, (MMTI0289VO)jmvo);                                                                                                                      
		                                                                                                                                                                                                                      
		return jmvo;
	}	
	
	public String getEncKey() {
		return dmAesKey;
	}

	// EDMS (자차사진등록) 20220608 원본3
	public void regInfoToEdmsForMobileWeb(MultipartHttpServletRequest request, MMTI0289VO jmvo) throws Exception {
		boolean result = false;

		// 등록관련정보조회 서블릿을 호출해서 User ID 조회
		Map<String, String> edmsPreRegInfo = new HashMap<String, String>();
		edmsPreRegInfo.put("UsrId"		, HOMEPAGE_JOJIKWON_CD);
		edmsPreRegInfo.put("SysCode"	, "MTD");
		edmsPreRegInfo.put("Index09"	, "01".equals(jmvo.getMbl_ts_dtl_dvcd()) ? "CKA" : "CKB");
		edmsPreRegInfo.put("DocNo1"		, "01".equals(jmvo.getMbl_ts_dtl_dvcd()) ? jmvo.getPlan_plno() : jmvo.getPlno());
		edmsPreRegInfo.put("DocNo2"		, "01".equals(jmvo.getMbl_ts_dtl_dvcd()) ? "" : jmvo.getPlan_plno());
		if("43".equals(jmvo.getMbl_bz_dvcd())) { // 차선이탈경고장치가입
			edmsPreRegInfo.put("DocType", "01".equals(jmvo.getMbl_ts_dtl_dvcd()) ? "CKA025" : "CKB017");
		}
		else if("01".equals(jmvo.getMbl_bz_dvcd())) { // 자차추가
			edmsPreRegInfo.put("DocType", "01".equals(jmvo.getMbl_ts_dtl_dvcd()) ? "CKA026" : "CKB018");
		}
		else if("35".equals(jmvo.getMbl_bz_dvcd())) { // 베이비인카가입서류
			edmsPreRegInfo.put("DocType", "01".equals(jmvo.getMbl_ts_dtl_dvcd()) ? "CKA027" : "CKB019");
		}
		else if("55".equals(jmvo.getMbl_bz_dvcd())) { // 전방충돌경고장치
			edmsPreRegInfo.put("DocType", "01".equals(jmvo.getMbl_ts_dtl_dvcd()) ? "CKA029" : "CKB020");
		}
		else if("69".equals(jmvo.getMbl_bz_dvcd()) || "71".equals(jmvo.getMbl_bz_dvcd()) 
				|| "72".equals(jmvo.getMbl_bz_dvcd()) || "73".equals(jmvo.getMbl_bz_dvcd())) { // 해지/취소, 자동차사항(차량대체), 요율사항, 가입경력지정자
			edmsPreRegInfo.put("DocType", "CKB003");
		}
		else {
			edmsPreRegInfo.put("DocType", "01".equals(jmvo.getMbl_ts_dtl_dvcd()) ? "CKA003" : "CKB003");
		}

		// 이미지 업로드
		LinkedList<FileMeta> linkedList = fileTobeService.upload(request, CARRIDER_UPLOAD_TEMP_PATH, jmvo.getMbl_snd_no());
		
		LinkedList<String> exifDateQueue = new LinkedList<String>();
		if(request.getParameter("exifDate1") != null) exifDateQueue.add(request.getParameter("exifDate1"));
		if(request.getParameter("exifDate2") != null) exifDateQueue.add(request.getParameter("exifDate2"));
		if(request.getParameter("exifDate3") != null) exifDateQueue.add(request.getParameter("exifDate3"));
		if(request.getParameter("exifDate4") != null) exifDateQueue.add(request.getParameter("exifDate4"));

		if(linkedList == null || linkedList.size() == 0) {
			throw new Exception("파일 업로드 실패 [ 업로드할 파일이 없거나 이미지파일이 아닙니다. ]");
		}

		for(int i = 0; i < linkedList.size(); i++) {
			FileMeta fileMeta = linkedList.get(i);

			File file = new File(CARRIDER_UPLOAD_TEMP_PATH + fileMeta.getFileName());
			
			// EDMS에 문서 등록
			String exifDate = exifDateQueue.removeFirst();
			logger.debug("exifDate: " + exifDate);
			
			result = fileTobeService.docRegToEdms2(edmsPreRegInfo, file, null, exifDate);
			logger.debug("result: " + result);
			
			if(!result) throw new Exception("EDMS 등록 실패");

		}
	}
	
	// EDMS (자차사진등록) aiocr용
	public void aiocrRegInfoToEdmsForMobileWeb(MultipartHttpServletRequest request, MMTI0289VO jmvo) throws Exception {
		boolean result = false;

		// 등록관련정보조회 서블릿을 호출해서 User ID 조회
		Map<String, String> edmsPreRegInfo = new HashMap<String, String>();
		edmsPreRegInfo.put("UsrId"		, HOMEPAGE_JOJIKWON_CD);
		edmsPreRegInfo.put("SysCode"	, "MTD");
		edmsPreRegInfo.put("Index09"	, "01".equals(jmvo.getMbl_ts_dtl_dvcd()) ? "CKA" : "CKB");
		edmsPreRegInfo.put("DocNo1"		, "01".equals(jmvo.getMbl_ts_dtl_dvcd()) ? jmvo.getPlan_plno() : jmvo.getPlno());
		edmsPreRegInfo.put("DocNo2"		, "01".equals(jmvo.getMbl_ts_dtl_dvcd()) ? "" : jmvo.getPlan_plno());
		if("43".equals(jmvo.getMbl_bz_dvcd())) { // 차선이탈경고장치가입
			edmsPreRegInfo.put("DocType", "01".equals(jmvo.getMbl_ts_dtl_dvcd()) ? "CKA025" : "CKB017");
		}
		else if("01".equals(jmvo.getMbl_bz_dvcd())) { // 자차추가
			edmsPreRegInfo.put("DocType", "01".equals(jmvo.getMbl_ts_dtl_dvcd()) ? "CKA026" : "CKB018");
		}
		else if("35".equals(jmvo.getMbl_bz_dvcd())) { // 베이비인카가입서류
			edmsPreRegInfo.put("DocType", "01".equals(jmvo.getMbl_ts_dtl_dvcd()) ? "CKA027" : "CKB019");
		}
		else if("55".equals(jmvo.getMbl_bz_dvcd())) { // 전방충돌경고장치
			edmsPreRegInfo.put("DocType", "01".equals(jmvo.getMbl_ts_dtl_dvcd()) ? "CKA029" : "CKB020");
		}
		else if("69".equals(jmvo.getMbl_bz_dvcd()) || "71".equals(jmvo.getMbl_bz_dvcd()) 
				|| "72".equals(jmvo.getMbl_bz_dvcd()) || "73".equals(jmvo.getMbl_bz_dvcd())) { // 해지/취소, 자동차사항(차량대체), 요율사항, 가입경력지정자
			edmsPreRegInfo.put("DocType", "CKB003");
		}
		else {
			edmsPreRegInfo.put("DocType", "01".equals(jmvo.getMbl_ts_dtl_dvcd()) ? "CKA003" : "CKB003");
		}

		// 이미지 업로드
		LinkedList<FileMeta> linkedList = fileTobeService.aiocrUpload(request, AIOCR_UPLOAD_TEMP_PATH, jmvo.getMbl_snd_no());
		
		LinkedList<String> exifDateQueue = new LinkedList<String>();
		if(request.getParameter("exifDate1") != null) exifDateQueue.add(request.getParameter("exifDate1"));
		if(request.getParameter("exifDate2") != null) exifDateQueue.add(request.getParameter("exifDate2"));
		if(request.getParameter("exifDate3") != null) exifDateQueue.add(request.getParameter("exifDate3"));
		if(request.getParameter("exifDate4") != null) exifDateQueue.add(request.getParameter("exifDate4"));

		if(linkedList == null || linkedList.size() == 0) {
			throw new Exception("파일 업로드 실패 [ 업로드할 파일이 없거나 이미지파일이 아닙니다. ]");
		}

		for(int i = 0; i < linkedList.size(); i++) {
			FileMeta fileMeta = linkedList.get(i);

			File file = new File(AIOCR_UPLOAD_TEMP_PATH + fileMeta.getFileName());
			
			// EDMS에 문서 등록
			String exifDate = exifDateQueue.removeFirst();
			logger.debug("exifDate: " + exifDate);
			
			result = fileTobeService.docRegToEdms2(edmsPreRegInfo, file, null, exifDate);
			logger.debug("result: " + result);
			
			if(!result) throw new Exception("EDMS 등록 실패");

		}
	}
	
	// EDMS (자차사진등록) 20220608 수정본3
	public MBTR01001VO regInfoToEdmsForMobileWeb(MultipartHttpServletRequest request, MMTI0289VO jmvo, MBTR01001VO mbtr01001vo) throws Exception {
		boolean result = false;

		// 등록관련정보조회 서블릿을 호출해서 User ID 조회
		Map<String, String> edmsPreRegInfo = new HashMap<String, String>();
		edmsPreRegInfo.put("UsrId"		, HOMEPAGE_JOJIKWON_CD);
		edmsPreRegInfo.put("SysCode"	, "MTD");
		edmsPreRegInfo.put("Index09"	, "01".equals(jmvo.getMbl_ts_dtl_dvcd()) ? "CKA" : "CKB");
		edmsPreRegInfo.put("DocNo1"		, "01".equals(jmvo.getMbl_ts_dtl_dvcd()) ? jmvo.getPlan_plno() : jmvo.getPlno());
		edmsPreRegInfo.put("DocNo2"		, "01".equals(jmvo.getMbl_ts_dtl_dvcd()) ? "" : jmvo.getPlan_plno());
		if("43".equals(jmvo.getMbl_bz_dvcd())) { // 차선이탈경고장치가입
			edmsPreRegInfo.put("DocType", "01".equals(jmvo.getMbl_ts_dtl_dvcd()) ? "CKA025" : "CKB017");
		}
		else if("01".equals(jmvo.getMbl_bz_dvcd())) { // 자차추가
			edmsPreRegInfo.put("DocType", "01".equals(jmvo.getMbl_ts_dtl_dvcd()) ? "CKA026" : "CKB018");
		}
		else if("35".equals(jmvo.getMbl_bz_dvcd())) { // 베이비인카가입서류
			edmsPreRegInfo.put("DocType", "01".equals(jmvo.getMbl_ts_dtl_dvcd()) ? "CKA027" : "CKB019");
		}
		else if("55".equals(jmvo.getMbl_bz_dvcd())) { // 전방충돌경고장치
			edmsPreRegInfo.put("DocType", "01".equals(jmvo.getMbl_ts_dtl_dvcd()) ? "CKA029" : "CKB020");
		}
		else if("69".equals(jmvo.getMbl_bz_dvcd()) || "71".equals(jmvo.getMbl_bz_dvcd()) 
				|| "72".equals(jmvo.getMbl_bz_dvcd()) || "73".equals(jmvo.getMbl_bz_dvcd())) { // 해지/취소, 자동차사항(차량대체), 요율사항, 가입경력지정자
			edmsPreRegInfo.put("DocType", "CKB003");
		}
		else {
			edmsPreRegInfo.put("DocType", "01".equals(jmvo.getMbl_ts_dtl_dvcd()) ? "CKA003" : "CKB003");
		}

		// 이미지 업로드
		LinkedList<FileMeta> linkedList = fileTobeService.upload(request, CARRIDER_UPLOAD_TEMP_PATH, jmvo.getMbl_snd_no());
		
		LinkedList<String> exifDateQueue = new LinkedList<String>();
		if(request.getParameter("exifDate1") != null) exifDateQueue.add(request.getParameter("exifDate1"));
		if(request.getParameter("exifDate2") != null) exifDateQueue.add(request.getParameter("exifDate2"));
		if(request.getParameter("exifDate3") != null) exifDateQueue.add(request.getParameter("exifDate3"));
		if(request.getParameter("exifDate4") != null) exifDateQueue.add(request.getParameter("exifDate4"));

		if(linkedList == null || linkedList.size() == 0) {
			throw new Exception("파일 업로드 실패 [ 업로드할 파일이 없거나 이미지파일이 아닙니다. ]");
		}

		for(int i = 0; i < linkedList.size(); i++) {
			FileMeta fileMeta = linkedList.get(i);

			File file = new File(CARRIDER_UPLOAD_TEMP_PATH + fileMeta.getFileName());
			
			// EDMS에 문서 등록
			String exifDate = exifDateQueue.removeFirst();
			logger.debug("exifDate: " + exifDate);
			
//			result = fileTobeService.docRegToEdms2(edmsPreRegInfo, file, null, exifDate);
//			logger.debug("result: " + result);
			mbtr01001vo = fileTobeService.docRegToEdms2(edmsPreRegInfo, file, null, exifDate, mbtr01001vo);
			
//			if(!result) throw new Exception("EDMS 등록 실패");
			if("N".equals(mbtr01001vo.getNrmYn()))
				throw new Exception("EDMS 등록 실패");
		}
		return mbtr01001vo;
	}
	
	//20220608 원본1
	public void regInfoToEdmsForMobileWeb2(MultipartHttpServletRequest request, String id, ArrayList<File> files, String plnoAndPlanNo) throws Exception { // OCR 용
		boolean result = false;

		for(int i = 0; i < files.size(); i++) {
			File file = files.get(i);

			// EDMS에 문서 등록
			String exifDate = "";
			if(i == 0) exifDate = StringUtil.nvl(request.getParameter("exifDate1"));
			else if(i == 1) exifDate = StringUtil.nvl(request.getParameter("exifDate2"));
			
			if(exifDate.indexOf(",gallery") > -1) {
				exifDate = exifDate.substring(0, exifDate.indexOf(",gallery"));
			}
			
			result = fileTobeService.docRegToEdms3(id, file, null, exifDate, plnoAndPlanNo);
			logger.debug("result: " + result);
			if(!result)
				throw new Exception("EDMS에 파일전송 실패");
		}
	}
	
		//만기정산 테스트 로직 추가
		public MBTR01001VO regInfoToEdmsForMobileWeb2(MultipartHttpServletRequest request, String id, ArrayList<File> files, String plnoAndPlanNo, MBTR01001VO mbtr01001vo, String adminSeq) throws Exception { // OCR 용
			boolean result = false;
			
			for(int i = 0; i < files.size(); i++) {
				File file = files.get(i);

				// EDMS에 문서 등록
				String exifDate = "";
				if(i == 0) exifDate = StringUtil.nvl(request.getParameter("exifDate1"));
				else if(i == 1) exifDate = StringUtil.nvl(request.getParameter("exifDate2"));
				
				if(exifDate.indexOf(",gallery") > -1) {
					exifDate = exifDate.substring(0, exifDate.indexOf(",gallery"));
				}
				
//				result = fileTobeService.docRegToEdms3(id, file, null, exifDate, plnoAndPlanNo);
				logger.debug("result: " + result);
				mbtr01001vo = fileTobeService.docRegToEdms3(id, file, null, exifDate, plnoAndPlanNo, mbtr01001vo);
				
//				if(!result)
				if("N".equals(mbtr01001vo.getNrmYn()) && !"dongbu".equals(adminSeq))
					throw new Exception("EDMS에 파일전송 실패");
			}
			return mbtr01001vo;
		}
		
		//
		public MBTR01001VO regInfoToEdmsForMobileWeb2(MultipartHttpServletRequest request, String id, ArrayList<File> files, String plnoAndPlanNo, MBTR01001VO mbtr01001vo) throws Exception { // OCR 용
			boolean result = false;
			
			for(int i = 0; i < files.size(); i++) {
				File file = files.get(i);
				
				// EDMS에 문서 등록
				String exifDate = "";
				if(i == 0) exifDate = StringUtil.nvl(request.getParameter("exifDate1"));
				else if(i == 1) exifDate = StringUtil.nvl(request.getParameter("exifDate2"));
				
				if(exifDate.indexOf(",gallery") > -1) {
					exifDate = exifDate.substring(0, exifDate.indexOf(",gallery"));
				}
				
//				result = fileTobeService.docRegToEdms3(id, file, null, exifDate, plnoAndPlanNo);
				logger.debug("result: " + result);
				mbtr01001vo = fileTobeService.docRegToEdms3(id, file, null, exifDate, plnoAndPlanNo, mbtr01001vo);
				
//				if(!result)
				if("N".equals(mbtr01001vo.getNrmYn()))
					throw new Exception("EDMS에 파일전송 실패");
			}
			return mbtr01001vo;
		}

		
	// 주행거리신규 -> 직전계약자동정산용 20220608 원본
	public void regInfoToEdmsForMobileWeb2(String exifDt, String id, Object fileObject, String plnoAndPlanNo) throws Exception {
		boolean result = false;

		File file = new File(CARRIDER_UPLOAD_TEMP_PATH + "TEMP_" + System.currentTimeMillis() + ".jpg");
		
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(file);
			fos.write((byte[]) fileObject);
			fos.close();
			fos = null;
		} catch (Exception e) {
			System.err.println("[MileageTobeService.regInfoToEdmsForMobileWeb2_newocr()] Exception 발생");
		} finally {
			try {
				if(fos != null){
					fos.close();
				}
			} catch (IOException e2) {
				System.err.println("[MileageTobeService.regInfoToEdmsForMobileWeb2_newocr()] IOException 발생2");
			}
		}
		
		if(exifDt.indexOf(",gallery") > -1) {
			exifDt = exifDt.substring(0, exifDt.indexOf(",gallery"));
		}
					
		result = fileTobeService.docRegToEdms3(id, file, null, exifDt, plnoAndPlanNo);
		logger.debug("result: " + result);
		if(!result){
			throw new Exception("EDMS에 파일전송 실패");
		}
	}
	
	// 주행거리신규 -> 직전계약자동정산용 20220608 수정본
	public MBTR01001VO regInfoToEdmsForMobileWeb2(String exifDt, String id, Object fileObject, String plnoAndPlanNo, MBTR01001VO mbtr01001vo) throws Exception {
		boolean result = false;

		File file = new File(CARRIDER_UPLOAD_TEMP_PATH + "TEMP_" + System.currentTimeMillis() + ".jpg");
		
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(file);
			fos.write((byte[]) fileObject);
			fos.close();
			fos = null;
		} catch (Exception e) {
			System.err.println("[MileageTobeService.regInfoToEdmsForMobileWeb2_newocr()] Exception 발생");
		} finally {
			try {
				if(fos != null){
					fos.close();
				}
			} catch (IOException e2) {
				System.err.println("[MileageTobeService.regInfoToEdmsForMobileWeb2_newocr()] IOException 발생2");
			}
		}
		
		if(exifDt.indexOf(",gallery") > -1) {
			exifDt = exifDt.substring(0, exifDt.indexOf(",gallery"));
		}
					
//		result = fileTobeService.docRegToEdms3(id, file, null, exifDt, plnoAndPlanNo);
//		logger.debug("result: " + result);
		mbtr01001vo = fileTobeService.docRegToEdms3(id, file, null, exifDt, plnoAndPlanNo, mbtr01001vo);
		
//		if(!result){
//			throw new Exception("EDMS에 파일전송 실패");
//		}
		if("N".equals(mbtr01001vo.getNrmYn()))
			throw new Exception("EDMS에 파일전송 실패");
		
		return mbtr01001vo;
	}
	
	public void regInfoToEdmsForMobileWeb3(String id, Object fileObject, String exifDate, String plnoAndPlanNo) throws Exception { // OCR 용
		boolean result = false;

		File file = new File(CARRIDER_UPLOAD_TEMP_PATH + "TEMP_" + System.currentTimeMillis() + ".jpg");
		
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(file);
			fos.write((byte[]) fileObject);
			fos.close();
			fos = null;
		} catch (Exception e) {
			System.err.println("[MileageTobeService.regInfoToEdmsForMobileWeb3()] Exception 발생");
		} finally {
			try {
				if(fos != null){
					fos.close();
				}
			} catch (IOException e2) {
				System.err.println("[MileageTobeService.regInfoToEdmsForMobileWeb3()] IOException 발생2");
			}
		}
		
		result = fileTobeService.docRegToEdms4(id, file, null, exifDate, plnoAndPlanNo);
		logger.debug("result: " + result);
		
		if(!result) {
			throw new Exception("EDMS에 파일전송 실패");
		}
	}	
	
	public ArrayList<File> uploadToWAS(MultipartHttpServletRequest request, String sms_ts_bvan) throws Exception { // OCR 용
		ArrayList<File> files = new ArrayList<File>();

		// 이미지 업로드
		LinkedList<FileMeta> linkedList = fileTobeService.upload(request, CARRIDER_UPLOAD_TEMP_PATH, sms_ts_bvan);		

		if(linkedList == null || linkedList.size() == 0) {
			throw new Exception("파일 업로드 실패 [ 업로드할 파일이 없거나 이미지파일이 아닙니다. ]");
		}

		for(int i = 0; i < linkedList.size(); i++) {
			FileMeta fileMeta = linkedList.get(i);
			File file = new File(CARRIDER_UPLOAD_TEMP_PATH + fileMeta.getFileName());
			files.add(file);
		}
		
		return files;
	}
	
	//AIOCR
	public ArrayList<File> aiocrUploadToWAS(MultipartHttpServletRequest request, String sms_ts_bvan) throws Exception { // OCR 용
		ArrayList<File> files = new ArrayList<File>();

		// 이미지 업로드
		LinkedList<FileMeta> linkedList = fileTobeService.aiocrUpload(request, AIOCR_UPLOAD_TEMP_PATH, sms_ts_bvan);		

		if(linkedList == null || linkedList.size() == 0) {
			throw new Exception("파일 업로드 실패 [ 업로드할 파일이 없거나 이미지파일이 아닙니다. ]");
		}

		for(int i = 0; i < linkedList.size(); i++) {
			FileMeta fileMeta = linkedList.get(i);
			File file = new File(AIOCR_UPLOAD_TEMP_PATH + fileMeta.getFileName());
			files.add(file);
		}
		
		return files;
	}

	@SuppressWarnings("static-access")
	public MMTI0291VO getMMTI0291VO(MMTI0291VO jmvo) throws Exception {
		logger.info("############### NEVER MMTI0291VO ###############");
		String UserId = HOMEPAGE_JOJIKWON_CD;                                                                                                                                                                                           
		String formId = "MMTI0291";                                                                                                                                                                                           
		String telegram = "MMTI"; // esb                                                                                                                                                                                      
		                                                                                                                                                                                                                      
		ESBManager em = new ESBManager();                                                                                                                                                                                     
		ESBChannelHeader channelHead = new ESBChannelHeader();                                                                                                                                                                
		ESBBizHeader bizHead = new ESBBizHeader();     
		
		bizHead = em.makeDefaultBizHeader(UserId);                                                                                                                                                                            
		channelHead = em.makeDefaultChannelHeader(formId, UserId);  
		String Url = ESBURL;
		logger.debug("Url: " + Url);
		String rtnXmlString = (String)XmlUtil.callESBToString(channelHead, bizHead, jmvo, Url, telegram);                                                                                                                   
		                                                                                                                                                                                                                      
		logger.debug("##############################");                                                                                                                                                                       
		logger.debug(rtnXmlString);                                                                                                                                                                                           
		logger.debug("##############################");                                                                                                                                                                       
		                                                                                                                                                                                                                      
		jmvo = (MMTI0291VO) ESBManager.xmlToVOnew(rtnXmlString, (MMTI0291VO)jmvo);                                                                                                                      
		                                                                                                                                                                                                                      
		return jmvo;
	}

	//20221221 만기정산 테스트 로직 추가
	@SuppressWarnings("static-access")
	public MMTI0291VO getMMTI0291VO(MMTI0291VO jmvo, String adminSeq) throws Exception {
		logger.info("###############ESBadminSeq : " + adminSeq + "###############");
		if (adminSeq.equals("dongbu")) {
			logger.info("###############adminSeq ESB blocked###############");
		} else {
			String UserId = HOMEPAGE_JOJIKWON_CD;                                                                                                                                                                                           
			String formId = "MMTI0291";                                                                                                                                                                                           
			String telegram = "MMTI"; // esb                                                                                                                                                                                      
		
			ESBManager em = new ESBManager();                                                                                                                                                                                     
			ESBChannelHeader channelHead = new ESBChannelHeader();                                                                                                                                                                
			ESBBizHeader bizHead = new ESBBizHeader();     
		
			bizHead = em.makeDefaultBizHeader(UserId);                                                                                                                                                                            
			channelHead = em.makeDefaultChannelHeader(formId, UserId);  
			String Url = ESBURL;
			logger.debug("Url: " + Url);
			String rtnXmlString = (String)XmlUtil.callESBToString(channelHead, bizHead, jmvo, Url, telegram);                                                                                                                   
			
			logger.debug("##############################");                                                                                                                                                                       
			logger.debug(rtnXmlString);                                                                                                                                                                                           
			logger.debug("##############################");                                                                                                                                                                       
			
			jmvo = (MMTI0291VO) ESBManager.xmlToVOnew(rtnXmlString, (MMTI0291VO)jmvo);                                                                                                                      
		}
		return jmvo;
	}

	@SuppressWarnings("static-access")
	public MMTI0294VO getMMTI0294VO(MMTI0294VO jmvo) throws Exception {
		logger.info("############### NEVER MMTI0294VO ###############");
		String UserId = HOMEPAGE_JOJIKWON_CD;                                                                                                                                                                                           
		String formId = "MMTI0294";                                                                                                                                                                                           
		String telegram = "MMTI"; // esb                                                                                                                                                                                      
		                                                                                                                                                                                                                      
		ESBManager em = new ESBManager();                                                                                                                                                                                     
		ESBChannelHeader channelHead = new ESBChannelHeader();                                                                                                                                                                
		ESBBizHeader bizHead = new ESBBizHeader();     
		
		bizHead = em.makeDefaultBizHeader(UserId);                                                                                                                                                                            
		channelHead = em.makeDefaultChannelHeader(formId, UserId);  
		String Url = ESBURL;
		logger.debug("Url: " + Url);
		String rtnXmlString = (String)XmlUtil.callESBToString(channelHead, bizHead, jmvo, Url, telegram);                                                                                                                   
		                                                                                                                                                                                                                      
		logger.debug("##############################");                                                                                                                                                                       
		logger.debug(rtnXmlString);                                                                                                                                                                                           
		logger.debug("##############################");                                                                                                                                                                       
		                                                                                                                                                                                                                      
		jmvo = (MMTI0294VO) ESBManager.xmlToVOnew(rtnXmlString, (MMTI0294VO)jmvo);                                                                                                                      
		                                                                                                                                                                                                                      
		return jmvo;
	}

	//20221221 만기정산 테스트 로직 추가
	@SuppressWarnings("static-access")
	public MMTI0294VO getMMTI0294VO(MMTI0294VO jmvo, String adminSeq) throws Exception {
		logger.info("###############ESBadminSeq : " + adminSeq + "###############");
		if (adminSeq.equals("dongbu")) {
			logger.info("###############adminSeq ESB blocked###############");
		} else {
			String UserId = HOMEPAGE_JOJIKWON_CD;                                                                                                                                                                                           
			String formId = "MMTI0294";                                                                                                                                                                                           
			String telegram = "MMTI"; // esb                                                                                                                                                                                      
		
			ESBManager em = new ESBManager();                                                                                                                                                                                     
			ESBChannelHeader channelHead = new ESBChannelHeader();                                                                                                                                                                
			ESBBizHeader bizHead = new ESBBizHeader();     
		
			bizHead = em.makeDefaultBizHeader(UserId);                                                                                                                                                                            
			channelHead = em.makeDefaultChannelHeader(formId, UserId);  
			String Url = ESBURL;
			logger.debug("Url: " + Url);
			String rtnXmlString = (String)XmlUtil.callESBToString(channelHead, bizHead, jmvo, Url, telegram);                                                                                                                   
			
			logger.debug("##############################");                                                                                                                                                                       
			logger.debug(rtnXmlString);                                                                                                                                                                                           
			logger.debug("##############################");                                                                                                                                                                       
			
			jmvo = (MMTI0294VO) ESBManager.xmlToVOnew(rtnXmlString, (MMTI0294VO)jmvo);                                                                                                                      
		}
		return jmvo;
	}

	@SuppressWarnings("static-access")
	public MMTI0217VO getMMTI0217VO(MMTI0217VO jmvo) throws Exception {
		String UserId = HOMEPAGE_JOJIKWON_CD;                                                                                                                                                                                           
		String formId = "MMTI0217";                                                                                                                                                                                           
		String telegram = "MMTI"; // esb                                                                                                                                                                                      
		                                                                                                                                                                                                                      
		ESBManager em = new ESBManager();                                                                                                                                                                                     
		ESBChannelHeader channelHead = new ESBChannelHeader();                                                                                                                                                                
		ESBBizHeader bizHead = new ESBBizHeader();     
		
		bizHead = em.makeDefaultBizHeader(UserId);                                                                                                                                                                            
		channelHead = em.makeDefaultChannelHeader(formId, UserId);  
		String Url = ESBURL;
		logger.debug("Url: " + Url);
		String rtnXmlString = (String)XmlUtil.callESBToString(channelHead, bizHead, jmvo, Url, telegram);                                                                                                                   
		                                                                                                                                                                                                                      
		logger.debug("##############################");                                                                                                                                                                       
		logger.debug(rtnXmlString);                                                                                                                                                                                           
		logger.debug("##############################");                                                                                                                                                                       
		                                                                                                                                                                                                                      
		jmvo = (MMTI0217VO) ESBManager.xmlToVOnew(rtnXmlString, (MMTI0217VO)jmvo);                                                                                                                      
		                                                                                                                                                                                                                      
		return jmvo;
	}

	@SuppressWarnings("static-access")
	public MMTI0218VO getMMTI0218VO(MMTI0218VO jmvo) throws Exception {
		String UserId = HOMEPAGE_JOJIKWON_CD;                                                                                                                                                                                           
		String formId = "MMTI0218";                                                                                                                                                                                           
		String telegram = "MMTI"; // esb                                                                                                                                                                                      
		                                                                                                                                                                                                                      
		ESBManager em = new ESBManager();                                                                                                                                                                                     
		ESBChannelHeader channelHead = new ESBChannelHeader();                                                                                                                                                                
		ESBBizHeader bizHead = new ESBBizHeader();     
		
		bizHead = em.makeDefaultBizHeader(UserId);                                                                                                                                                                            
		channelHead = em.makeDefaultChannelHeader(formId, UserId);  
		String Url = ESBURL;
		logger.debug("Url: " + Url);
		String rtnXmlString = (String)XmlUtil.callESBToString(channelHead, bizHead, jmvo, Url, telegram);                                                                                                                   
		                                                                                                                                                                                                                      
		logger.debug("##############################");                                                                                                                                                                       
		logger.debug(rtnXmlString);                                                                                                                                                                                           
		logger.debug("##############################");                                                                                                                                                                       
		                                                                                                                                                                                                                      
		jmvo = (MMTI0218VO) ESBManager.xmlToVOnew(rtnXmlString, (MMTI0218VO)jmvo);                                                                                                                      
		                                                                                                                                                                                                                      
		return jmvo;
	}
	
	
	@SuppressWarnings("static-access")
	public XIDB0004VO getXIDB0004VO(XIDB0004VO jmvo) throws Exception{
		logger.info("############### NEVER XIDB0004VO ###############");
		String UserId = HOMEPAGE_JOJIKWON_CD;                                                                                                                                                                                           
		String formId = "XIDB0004";                                                                                                                                                                                           
		String telegram = "XIDB"; // esb                                                                                                                                                                                      
		                                                                                                                                                                                                                      
		ESBManager em = new ESBManager();                                                                                                                                                                                     
		ESBChannelHeader channelHead = new ESBChannelHeader();                                                                                                                                                                
		ESBBizHeader bizHead = new ESBBizHeader();     
		
		bizHead = em.makeDefaultBizHeader(UserId);                                                                                                                                                                            
		channelHead = em.makeDefaultChannelHeader(formId, UserId);  
		String Url = ESBURL;
		logger.debug("Url: " + Url);
		String rtnXmlString = (String)XmlUtil.callESBToString(channelHead, bizHead, jmvo, Url, telegram);                                                                                                                   
		                                                                                                                                                                                                                      
		logger.debug("##############################");                                                                                                                                                                       
		logger.debug(rtnXmlString);                                                                                                                                                                                           
		logger.debug("##############################");                                                                                                                                                                       
		                                                                                                                                                                                                                      
		jmvo = (XIDB0004VO) ESBManager.xmlToVOnew(rtnXmlString, (XIDB0004VO)jmvo);                                                                                                                      
		      
		return jmvo;
		
	}

	//20221221 만기정산 테스트 로직 추가
	@SuppressWarnings("static-access")
	public XIDB0004VO getXIDB0004VO(XIDB0004VO jmvo, String adminSeq) throws Exception{
		logger.info("###############ESBadminSeq : " + adminSeq + "###############");
		if (adminSeq.equals("dongbu")) {
			logger.info("###############adminSeq ESB blocked###############");
		} else {
			String UserId = HOMEPAGE_JOJIKWON_CD;                                                                                                                                                                                           
			String formId = "XIDB0004";                                                                                                                                                                                           
			String telegram = "XIDB"; // esb                                                                                                                                                                                      
		
			ESBManager em = new ESBManager();                                                                                                                                                                                     
			ESBChannelHeader channelHead = new ESBChannelHeader();                                                                                                                                                                
			ESBBizHeader bizHead = new ESBBizHeader();     
		
			bizHead = em.makeDefaultBizHeader(UserId);                                                                                                                                                                            
			channelHead = em.makeDefaultChannelHeader(formId, UserId);  
			String Url = ESBURL;
			logger.debug("Url: " + Url);
			String rtnXmlString = (String)XmlUtil.callESBToString(channelHead, bizHead, jmvo, Url, telegram);                                                                                                                   
			
			logger.debug("##############################");                                                                                                                                                                       
			logger.debug(rtnXmlString);                                                                                                                                                                                           
			logger.debug("##############################");                                                                                                                                                                       
			
			jmvo = (XIDB0004VO) ESBManager.xmlToVOnew(rtnXmlString, (XIDB0004VO)jmvo);                                                                                                                      
		}
		return jmvo;
	}

	@SuppressWarnings("static-access")
	public MMTI0305VO getMMTI0305VO(MMTI0305VO jmvo) throws Exception{
		String UserId = HOMEPAGE_JOJIKWON_CD;
		String formId = "MMTI0305";                                                                                                                                                                                           
		String telegram = "MMTI"; // esb                                                                                                                                                                                      
		                                                                                                                                                                                                                      
		ESBManager em = new ESBManager();                                                                                                                                                                                     
		ESBChannelHeader channelHead = new ESBChannelHeader();                                                                                                                                                                
		ESBBizHeader bizHead = new ESBBizHeader();     
		
		bizHead = em.makeDefaultBizHeader(UserId);                                                                                                                                                                            
		channelHead = em.makeDefaultChannelHeader(formId, UserId);  
		String Url = ESBURL;
		logger.debug("Url: " + Url);
		String rtnXmlString = (String)XmlUtil.callESBToString(channelHead, bizHead, jmvo, Url, telegram);                                                                                                                   
		                                                                                                                                                                                                                      
		logger.debug("##############################");                                                                                                                                                                       
		logger.debug(rtnXmlString);                                                                                                                                                                                           
		logger.debug("##############################");                                                                                                                                                                       
		                                                                                                                                                                                                                      
		jmvo = (MMTI0305VO) ESBManager.xmlToVOnew(rtnXmlString, (MMTI0305VO)jmvo);                                                                                                                      
		                                                                                                                                                                                                                      
		return jmvo;
	}
	
	@SuppressWarnings("static-access")
	public MMTI0305VO chatMMTI0305VO(MMTI0305VO jmvo) throws Exception{
		String UserId = CHAT_EMPNO;
		String formId = "MMTI0305";                                                                                                                                                                                           
		String telegram = "MMTI"; // esb                                                                                                                                                                                      
		                                                                                                                                                                                                                      
		ESBManager em = new ESBManager();                                                                                                                                                                                     
		ESBChannelHeader channelHead = new ESBChannelHeader();                                                                                                                                                                
		ESBBizHeader bizHead = new ESBBizHeader();     
		
		bizHead = em.makeDefaultBizHeader(UserId);                                                                                                                                                                            
		channelHead = em.makeDefaultChannelHeader(formId, UserId);  
		String Url = ESBURL;
		logger.debug("Url: " + Url);
		String rtnXmlString = (String)XmlUtil.callESBToString(channelHead, bizHead, jmvo, Url, telegram);                                                                                                                   
		                                                                                                                                                                                                                      
		logger.debug("##############################");                                                                                                                                                                       
		logger.debug(rtnXmlString);                                                                                                                                                                                           
		logger.debug("##############################");                                                                                                                                                                       
		                                                                                                                                                                                                                      
		jmvo = (MMTI0305VO) ESBManager.xmlToVOnew(rtnXmlString, (MMTI0305VO)jmvo);                                                                                                                      
		                                                                                                                                                                                                                      
		return jmvo;
	}
	
	
	@SuppressWarnings("static-access")
	public MMTI0213VO chatMMTI0213VO(MMTI0213VO jmvo) throws Exception {
		String UserId = CHAT_EMPNO;                                                                                                                                                                                           
		String formId = "MMTI0213";                                                                                                                                                                                           
		String telegram = "MMTI"; // esb                                                                                                                                                                                      
		                                                                                                                                                                                                                      
		ESBManager em = new ESBManager();                                                                                                                                                                                     
		ESBChannelHeader channelHead = new ESBChannelHeader();                                                                                                                                                                
		ESBBizHeader bizHead = new ESBBizHeader();     
		
		bizHead = em.makeDefaultBizHeader(UserId);                                                                                                                                                                            
		channelHead = em.makeDefaultChannelHeader(formId, UserId);  
		String Url = ESBURL;
		logger.debug("Url: " + Url);
		String rtnXmlString = (String)XmlUtil.callESBToString(channelHead, bizHead, jmvo, Url, telegram);                                                                                                                   
		                                                                                                                                                                                                                      
		logger.debug("##############################");                                                                                                                                                                       
		logger.debug(rtnXmlString);                                                                                                                                                                                           
		logger.debug("##############################");                                                                                                                                                                       
		                                                                                                                                                                                                                      
		jmvo = (MMTI0213VO) ESBManager.xmlToVOnew(rtnXmlString, (MMTI0213VO)jmvo);                                                                                                                      
		                                                                                                                                                                                                                      
		return jmvo;
	}
	
	
	@SuppressWarnings("static-access")
	public MMTI0259VO chatMMTI0259VO(MMTI0259VO jmvo) throws Exception {
		String UserId = CHAT_EMPNO;                                                                                                                                                                                           
		String formId = "MMTI0259";                                                                                                                                                                                           
		String telegram = "MMTI"; // esb                                                                                                                                                                                      
		                                                                                                                                                                                                                      
		ESBManager em = new ESBManager();                                                                                                                                                                                     
		ESBChannelHeader channelHead = new ESBChannelHeader();                                                                                                                                                                
		ESBBizHeader bizHead = new ESBBizHeader();     
		
		bizHead = em.makeDefaultBizHeader(UserId);                                                                                                                                                                            
		channelHead = em.makeDefaultChannelHeader(formId, UserId);  
		String Url = ESBURL;
		logger.debug("Url: " + Url);
		String rtnXmlString = (String)XmlUtil.callESBToString(channelHead, bizHead, jmvo, Url, telegram);                                                                                                                   
		                                                                                                                                                                                                                      
		logger.debug("##############################");                                                                                                                                                                       
		logger.debug(rtnXmlString);                                                                                                                                                                                           
		logger.debug("##############################");                                                                                                                                                                       
		                                                                                                                                                                                                                      
		jmvo = (MMTI0259VO) ESBManager.xmlToVOnew(rtnXmlString, (MMTI0259VO)jmvo);                                                                                                                      
		                                                                                                                                                                                                                      
		return jmvo;
	}
	
	
	@SuppressWarnings("static-access")
	public MMTI0291VO chatMMTI0291VO(MMTI0291VO jmvo) throws Exception {
		String UserId = CHAT_EMPNO;                                                                                                                                                                                           
		String formId = "MMTI0291";                                                                                                                                                                                           
		String telegram = "MMTI"; // esb                                                                                                                                                                                      
		                                                                                                                                                                                                                      
		ESBManager em = new ESBManager();                                                                                                                                                                                     
		ESBChannelHeader channelHead = new ESBChannelHeader();                                                                                                                                                                
		ESBBizHeader bizHead = new ESBBizHeader();     
		
		bizHead = em.makeDefaultBizHeader(UserId);                                                                                                                                                                            
		channelHead = em.makeDefaultChannelHeader(formId, UserId);  
		String Url = ESBURL;
		logger.debug("Url: " + Url);
		String rtnXmlString = (String)XmlUtil.callESBToString(channelHead, bizHead, jmvo, Url, telegram);                                                                                                                   
		                                                                                                                                                                                                                      
		logger.debug("##############################");                                                                                                                                                                       
		logger.debug(rtnXmlString);                                                                                                                                                                                           
		logger.debug("##############################");                                                                                                                                                                       
		                                                                                                                                                                                                                      
		jmvo = (MMTI0291VO) ESBManager.xmlToVOnew(rtnXmlString, (MMTI0291VO)jmvo);                                                                                                                      
		                                                                                                                                                                                                                      
		return jmvo;
	}
	
	@SuppressWarnings("static-access")
	public MMTI0294VO chatMMTI0294VO(MMTI0294VO jmvo) throws Exception {
		String UserId = CHAT_EMPNO;                                                                                                                                                                                           
		String formId = "MMTI0294";                                                                                                                                                                                           
		String telegram = "MMTI"; // esb                                                                                                                                                                                      
		                                                                                                                                                                                                                      
		ESBManager em = new ESBManager();                                                                                                                                                                                     
		ESBChannelHeader channelHead = new ESBChannelHeader();                                                                                                                                                                
		ESBBizHeader bizHead = new ESBBizHeader();     
		
		bizHead = em.makeDefaultBizHeader(UserId);                                                                                                                                                                            
		channelHead = em.makeDefaultChannelHeader(formId, UserId);  
		String Url = ESBURL;
		logger.debug("Url: " + Url);
		String rtnXmlString = (String)XmlUtil.callESBToString(channelHead, bizHead, jmvo, Url, telegram);                                                                                                                   
		                                                                                                                                                                                                                      
		logger.debug("##############################");                                                                                                                                                                       
		logger.debug(rtnXmlString);                                                                                                                                                                                           
		logger.debug("##############################");                                                                                                                                                                       
		                                                                                                                                                                                                                      
		jmvo = (MMTI0294VO) ESBManager.xmlToVOnew(rtnXmlString, (MMTI0294VO)jmvo);                                                                                                                      
		                                                                                                                                                                                                                      
		return jmvo;
	}
	
	@SuppressWarnings("static-access")
	public MMTI0015VO getMMTI0015VO(MMTI0015VO jmvo) throws Exception {
		logger.info("############### NEVER MMTI0015VO ###############");
		String UserId = HOMEPAGE_JOJIKWON_CD;                                                                                                                                                                                           
		String formId = "MMTI0015";                                                                                                                                                                                           
		String telegram = "MMTI"; // esb                                                                                                                                                                                      
		                                                                                                                                                                                                                      
		ESBManager em = new ESBManager();                                                                                                                                                                                     
		ESBChannelHeader channelHead = new ESBChannelHeader();                                                                                                                                                                
		ESBBizHeader bizHead = new ESBBizHeader();     
		
		bizHead = em.makeDefaultBizHeader(UserId);                                                                                                                                                                            
		channelHead = em.makeDefaultChannelHeader(formId, UserId);  
		String Url = ESBURL;
		logger.debug("Url: " + Url);
		String rtnXmlString = (String)XmlUtil.callESBToString(channelHead, bizHead, jmvo, Url, telegram);                                                                                                                   
		                                                                                                                                                                                                                      
		logger.debug("##############################");                                                                                                                                                                       
		logger.debug(rtnXmlString);                                                                                                                                                                                           
		logger.debug("##############################");                                                                                                                                                                       
		                                                                                                                                                                                                                      
		jmvo = (MMTI0015VO) ESBManager.xmlToVOnew(rtnXmlString, (MMTI0015VO)jmvo);                                                                                                                      
		                                                                                                                                                                                                                      
		return jmvo;
	}

	//20221221 만기정산 테스트 로직 추가
	@SuppressWarnings("static-access")
	public MMTI0015VO getMMTI0015VO(MMTI0015VO jmvo, String adminSeq) throws Exception {
		logger.info("###############ESBadminSeq : " + adminSeq + "###############");
		if (adminSeq.equals("dongbu")) {
			logger.info("###############adminSeq ESB blocked###############");
		} else {
			String UserId = HOMEPAGE_JOJIKWON_CD;                                                                                                                                                                                           
			String formId = "MMTI0015";                                                                                                                                                                                           
			String telegram = "MMTI"; // esb                                                                                                                                                                                      
		
			ESBManager em = new ESBManager();                                                                                                                                                                                     
			ESBChannelHeader channelHead = new ESBChannelHeader();                                                                                                                                                                
			ESBBizHeader bizHead = new ESBBizHeader();     
		
			bizHead = em.makeDefaultBizHeader(UserId);                                                                                                                                                                            
			channelHead = em.makeDefaultChannelHeader(formId, UserId);  
			String Url = ESBURL;
			logger.debug("Url: " + Url);
			String rtnXmlString = (String)XmlUtil.callESBToString(channelHead, bizHead, jmvo, Url, telegram);                                                                                                                   
			
			logger.debug("##############################");                                                                                                                                                                       
			logger.debug(rtnXmlString);                                                                                                                                                                                           
			logger.debug("##############################");                                                                                                                                                                       
			
			jmvo = (MMTI0015VO) ESBManager.xmlToVOnew(rtnXmlString, (MMTI0015VO)jmvo);                                                                                                                      
		}
		return jmvo;
	}
	
	@SuppressWarnings("static-access")
	public XTEM0021VO getXTEM0021VO(XTEM0021VO jmvo) throws Exception {
		logger.info("############### NEVER XTEM0021VO ###############");
		String UserId = HOMEPAGE_JOJIKWON_CD;                                                                                                                                                                                           
		String formId = "XTEM0021";                                                                                                                                                                                           
		String telegram = "XTEM"; // esb                                                                                                                                                                                      
		                                                                                                                                                                                                                      
		ESBManager em = new ESBManager();                                                                                                                                                                                     
		ESBChannelHeader channelHead = new ESBChannelHeader();                                                                                                                                                                
		ESBBizHeader bizHead = new ESBBizHeader();     
		
		bizHead = em.makeDefaultBizHeader(UserId);                                                                                                                                                                            
		channelHead = em.makeDefaultChannelHeader(formId, UserId);  
		String Url = ESBURL;
		logger.debug("Url: " + Url);
		String rtnXmlString = (String)XmlUtil.callESBToString(channelHead, bizHead, jmvo, Url, telegram);                                                                                                                   
		                                                                                                                                                                                                                      
		logger.debug("##############################");                                                                                                                                                                       
		logger.debug(rtnXmlString);                                                                                                                                                                                           
		logger.debug("##############################");                                                                                                                                                                       
		                                                                                                                                                                                                                      
		jmvo = (XTEM0021VO) ESBManager.xmlToVOnew(rtnXmlString, (XTEM0021VO)jmvo);                                                                                                                      
		                                                                                                                                                                                                                      
		return jmvo;
	}

	//20221221 만기정산 테스트 로직 추가
	@SuppressWarnings("static-access")
	public XTEM0021VO getXTEM0021VO(XTEM0021VO jmvo, String adminSeq) throws Exception {
		logger.info("###############ESBadminSeq : " + adminSeq + "###############");
		if (adminSeq.equals("dongbu")) {
			logger.info("###############adminSeq ESB blocked###############");
		} else {
			String UserId = HOMEPAGE_JOJIKWON_CD;                                                                                                                                                                                           
			String formId = "XTEM0021";                                                                                                                                                                                           
			String telegram = "XTEM"; // esb                                                                                                                                                                                      
		
			ESBManager em = new ESBManager();                                                                                                                                                                                     
			ESBChannelHeader channelHead = new ESBChannelHeader();                                                                                                                                                                
			ESBBizHeader bizHead = new ESBBizHeader();     
		
			bizHead = em.makeDefaultBizHeader(UserId);                                                                                                                                                                            
			channelHead = em.makeDefaultChannelHeader(formId, UserId);  
			String Url = ESBURL;
			logger.debug("Url: " + Url);
			String rtnXmlString = (String)XmlUtil.callESBToString(channelHead, bizHead, jmvo, Url, telegram);                                                                                                                   
			
			logger.debug("##############################");                                                                                                                                                                       
			logger.debug(rtnXmlString);                                                                                                                                                                                           
			logger.debug("##############################");                                                                                                                                                                       
			
			jmvo = (XTEM0021VO) ESBManager.xmlToVOnew(rtnXmlString, (XTEM0021VO)jmvo);                                                                                                                      
		}
		return jmvo;
	}
	
	public int insertTest(MBTR01001VO mbtr01001vo) throws Exception{
		logger.debug("##########insertTest############");   
		DBTestDao mapper = sqlSession.getMapper(DBTestDao.class);
		logger.debug("##########insertTest1###########");  
		int result = mapper.insertEdmsHist(mbtr01001vo);
		logger.debug("##########insertTest2###########");  
		
		return result;
	}
	
	public int insertJungsanTest(MBTT02001VO mbtt02001vo) throws Exception{
		logger.debug("##########insertJungsanTest############");   
		DBTestDao mapper = sqlSession.getMapper(DBTestDao.class);
		logger.debug("##########insertJungsanTest1###########");  
		int result = mapper.insertMlHist(mbtt02001vo);
		logger.debug("##########insertJungsanTest2###########");  
		
		return result;
	}
	

/*	
	public int insertTest() throws Exception{
		
		CarRiderDao mapper = sqlSession.getMapper(CarRiderDao.class);
		
		MBTR01001VO mbtr01001vo = new MBTR01001VO();
		
		mbtr01001vo.setSqno(1);								// seq
		mbtr01001vo.setPbox_no("M8526672");					
		mbtr01001vo.setPlno("220202820888000");
		mbtr01001vo.setPlan_no("2202107C2800001");
		mbtr01001vo.setCtrmf_plan_no("2202107C5800001");
		mbtr01001vo.setEdms_bz_lgcg_cd("CKB");
		mbtr01001vo.setDoc_typ_smcg_cd("CKB008");
		String dtm = DateUtil.getDate("yyyyMMddHHmmss");
		mbtr01001vo.setFl_ts_dttm(dtm);
		mbtr01001vo.setNrm_yn("Y");
		mbtr01001vo.setProc_rsl_msg_cn("성공");
		mbtr01001vo.setApdx_fl_rut_nm("TEST");
		//mbtr01001vo.setEdms_fl_size_val(110000);
		// mbtr01001vo.set
		
		
		int result = mapper.insertEdmsHist(mbtr01001vo);
		
		return result;
	}
*/
}
