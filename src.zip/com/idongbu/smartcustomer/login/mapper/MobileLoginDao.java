package com.idongbu.smartcustomer.login.mapper;

import com.idongbu.smartcustomer.login.vo.MobileLoginDBVO;


/**
 * @info myBatis 연동위한 interface 
 */
public interface MobileLoginDao {

	MobileLoginDBVO loginSelect(MobileLoginDBVO vo);
	MobileLoginDBVO loginSelect2(MobileLoginDBVO vo);
	int updateLoginDate(MobileLoginDBVO vo);
	MobileLoginDBVO selectDormancyMember(MobileLoginDBVO vo); // 휴면회원 조회
	int wakeUpDormancyMember(MobileLoginDBVO vo);
	int deleteDormancyMember(MobileLoginDBVO vo);
	int insertWakeUpDormancyMemberLog(MobileLoginDBVO vo);
	int selectEMember(MobileLoginDBVO vo); // 전자금융회원 조회
	
}

