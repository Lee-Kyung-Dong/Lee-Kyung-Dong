package com.idongbu.smartcustomer.login.vo;

public class MobileLoginDBVO {
    
	private String FD_MB_NO; 
	private String FD_MB_ID;
	private String FD_MB_NAME;
	private String FD_MB_JUMIN;
	private String FD_MB_BIRTHDAY;
	private String FD_MB_EMAIL;
	private String FD_MB_HPHONE1;
	private String FD_MB_HPHONE2;
	private String FD_MB_HPHONE3;
	private String FD_MB_MPHONE1;
	private String FD_MB_MPHONE2;
	private String FD_MB_MPHONE3;
	private String FD_MB_CPHONE1;
	private String FD_MB_CPHONE2;
	private String FD_MB_CPHONE3;
	private String FD_MB_CFAX1;
	private String FD_MB_CFAX2;
	private String FD_MB_CFAX3;
	private String FD_BUSINESS_GB;	//금융회원여부
	private String FD_MB_BANK_GB;	//금융회원여부
	private String IPIN_DI;

	public String getFD_MB_NO() {
		return FD_MB_NO;
	}
	public void setFD_MB_NO(String FD_MB_NO) {
		this.FD_MB_NO = FD_MB_NO;
	}
	public String getFD_MB_ID() {
		return FD_MB_ID;
	}
	public void setFD_MB_ID(String FD_MB_ID) {
		this.FD_MB_ID = FD_MB_ID;
	}
	public String getFD_MB_NAME() {
		return FD_MB_NAME;
	}
	public void setFD_MB_NAME(String FD_MB_NAME) {
		this.FD_MB_NAME = FD_MB_NAME;
	}
	public String getFD_MB_JUMIN() {
		return FD_MB_JUMIN;
	}
	public void setFD_MB_JUMIN(String FD_MB_JUMIN) {
		this.FD_MB_JUMIN = FD_MB_JUMIN;
	}
	public String getFD_MB_BIRTHDAY() {
		return FD_MB_BIRTHDAY;
	}
	public void setFD_MB_BIRTHDAY(String FD_MB_BIRTHDAY) {
		this.FD_MB_BIRTHDAY = FD_MB_BIRTHDAY;
	}
	public String getFD_MB_EMAIL() {
		return FD_MB_EMAIL;
	}
	public void setFD_MB_EMAIL(String FD_MB_EMAIL) {
		this.FD_MB_EMAIL = FD_MB_EMAIL;
	}
	public String getFD_MB_HPHONE1() {
		return FD_MB_HPHONE1;
	}
	public void setFD_MB_HPHONE1(String fD_MB_HPHONE1) {
		FD_MB_HPHONE1 = fD_MB_HPHONE1;
	}
	public String getFD_MB_HPHONE2() {
		return FD_MB_HPHONE2;
	}
	public void setFD_MB_HPHONE2(String fD_MB_HPHONE2) {
		FD_MB_HPHONE2 = fD_MB_HPHONE2;
	}
	public String getFD_MB_HPHONE3() {
		return FD_MB_HPHONE3;
	}
	public void setFD_MB_HPHONE3(String fD_MB_HPHONE3) {
		FD_MB_HPHONE3 = fD_MB_HPHONE3;
	}
	public String getFD_MB_MPHONE1() {
		return FD_MB_MPHONE1;
	}
	public void setFD_MB_MPHONE1(String fD_MB_MPHONE1) {
		FD_MB_MPHONE1 = fD_MB_MPHONE1;
	}
	public String getFD_MB_MPHONE2() {
		return FD_MB_MPHONE2;
	}
	public void setFD_MB_MPHONE2(String fD_MB_MPHONE2) {
		FD_MB_MPHONE2 = fD_MB_MPHONE2;
	}
	public String getFD_MB_MPHONE3() {
		return FD_MB_MPHONE3;
	}
	public void setFD_MB_MPHONE3(String fD_MB_MPHONE3) {
		FD_MB_MPHONE3 = fD_MB_MPHONE3;
	}
	public String getFD_MB_CFAX1() {
		return FD_MB_CFAX1;
	}
	public void setFD_MB_CFAX1(String fD_MB_CFAX1) {
		FD_MB_CFAX1 = fD_MB_CFAX1;
	}
	public String getFD_MB_CFAX2() {
		return FD_MB_CFAX2;
	}
	public void setFD_MB_CFAX2(String fD_MB_CFAX2) {
		FD_MB_CFAX2 = fD_MB_CFAX2;
	}
	public String getFD_MB_CFAX3() {
		return FD_MB_CFAX3;
	}
	public void setFD_MB_CFAX3(String fD_MB_CFAX3) {
		FD_MB_CFAX3 = fD_MB_CFAX3;
	}
	public String getFD_MB_CPHONE1() {
		return FD_MB_CPHONE1;
	}
	public void setFD_MB_CPHONE1(String fD_MB_CPHONE1) {
		FD_MB_CPHONE1 = fD_MB_CPHONE1;
	}
	public String getFD_MB_CPHONE2() {
		return FD_MB_CPHONE2;
	}
	public void setFD_MB_CPHONE2(String fD_MB_CPHONE2) {
		FD_MB_CPHONE2 = fD_MB_CPHONE2;
	}
	public String getFD_MB_CPHONE3() {
		return FD_MB_CPHONE3;
	}
	public void setFD_MB_CPHONE3(String fD_MB_CPHONE3) {
		FD_MB_CPHONE3 = fD_MB_CPHONE3;
	}
	public String getFD_BUSINESS_GB() {
		return FD_BUSINESS_GB;
	}
	public void setFD_BUSINESS_GB(String fD_BUSINESS_GB) {
		FD_BUSINESS_GB = fD_BUSINESS_GB;
	}
	public String getFD_MB_BANK_GB() {
		return FD_MB_BANK_GB;
	}
	public void setFD_MB_BANK_GB(String fD_MB_BANK_GB) {
		FD_MB_BANK_GB = fD_MB_BANK_GB;
	}
	
	/**
	 * @return the iPIN_DI
	 */
	public String getIPIN_DI() {
		return IPIN_DI;
	}
	/**
	 * @param iPIN_DI the iPIN_DI to set
	 */
	public void setIPIN_DI(String iPIN_DI) {
		IPIN_DI = iPIN_DI;
	}
}
