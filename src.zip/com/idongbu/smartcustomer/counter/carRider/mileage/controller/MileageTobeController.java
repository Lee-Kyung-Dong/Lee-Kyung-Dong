package com.idongbu.smartcustomer.counter.carRider.mileage.controller;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.codec.binary.Base64;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.idongbu.common.SeedUtil;
import com.idongbu.smartcustomer.counter.carRider.common.service.FileTobeService;
import com.idongbu.smartcustomer.counter.carRider.demo.MBTR01001VO;
import com.idongbu.smartcustomer.counter.carRider.demo.MBTT02001VO;
import com.idongbu.smartcustomer.counter.carRider.mileage.service.MileageTobeService;
import com.idongbu.smartzone.vo.MMTI0015VO;
import com.idongbu.smartzone.vo.MMTI0213VO;
import com.idongbu.smartzone.vo.MMTI0217VO;
import com.idongbu.smartzone.vo.MMTI0218VO;
import com.idongbu.smartzone.vo.MMTI0259VO;
import com.idongbu.smartzone.vo.MMTI0289VO;
import com.idongbu.smartzone.vo.MMTI0291VO;
import com.idongbu.smartzone.vo.MMTI0294VO;
import com.idongbu.smartzone.vo.MMTI0305VO;
import com.idongbu.smartzone.vo.MMTI0321VO;
import com.idongbu.smartzone.vo.XIDB0004VO;
import com.idongbu.smartzone.vo.XTEM0021VO;
import com.idongbu.util.DMEncDecUtil;
import com.idongbu.util.DateUtil;
import com.idongbu.util.FTPUtil;
import com.idongbu.util.StringUtil;
import com.raonsecure.transkey.*;

/**
 * @info 보험상품 > 주행거리특약 & 블랙박스특약
 * @author F1F14A61
 */
@Controller
@RequestMapping(value="/idongbu/counter/carrider_tobe")
public class MileageTobeController {

	// private @Value("${server.mode}") String SERVER_MODE;
	// private static final String AIOCR_SERVER_PATH = "http://10.10.88.25:8080/api/carDrivingDistance";
	private static final String AIOCR_SERVER_PATH = "http://acr.dbins.net:8080/api/carDrivingDistance";
	
	@Autowired(required=true)
	private MileageTobeService mileageTobeService;		

	@Autowired(required=true)
	private FileTobeService fileTobeService; 	
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());	
	
	@RequestMapping(value="/mileageBlackBox01")
	public String mileageBlackBox01(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		HttpSession session = request.getSession();
		MMTI0213VO jmvo = new MMTI0213VO();

		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("num")));
		logger.debug("mileageBlackBox01 param num = " + request.getParameter("num"));
		logger.debug("mileageBlackBox01 num = " + aes256Decrypt(request.getParameter("num")));
		jmvo.setMtcc_yn(request.getParameter("mtcc_yn"));
		jmvo.setPdc_cd(request.getParameter("pdc_cd"));
		session.setAttribute("checkYn", request.getParameter("checkYn"));
		jmvo = mileageTobeService.getMMTI0213VO(jmvo);
		String view = "";
		
		if("1".equals(jmvo.getPbox_no_dvcd())) { // 주행거리
			if("1".equals(jmvo.getO_c_r_cecd_yn())){
				view = "/counter/carrider/tobe/mileageNew01";
			} else{
				// view = "/counter/carrider/tobe/mileageNew01";
				view = "/counter/carrider/tobe/mileage01";
			}
		}
		else if("2".equals(jmvo.getPbox_no_dvcd())) { // 블랙박스
			if("1".equals(jmvo.getMtcc_yn())||"20028".equals(jmvo.getPdc_cd())||"20030".equals(jmvo.getPdc_cd())||"20057".equals(jmvo.getPdc_cd())){ // 이륜차(오토바이) 블랙박스 장착인 경우
				view = "/counter/carrider/tobe/blackbox03";
			} else { // 자동차 블랙박스 장착인 경우
				view = "/counter/carrider/tobe/blackbox01";
			}
		}

		request.setAttribute("num", request.getParameter("num"));
		//request.setAttribute("checkYn", request.getParameter("checkYn"));
		request.setAttribute("mtcc_yn", jmvo.getMtcc_yn());
		request.setAttribute("pdc_cd", jmvo.getPdc_cd());
		request.setAttribute("jmvo", jmvo);
		return view;
	}
	
	@RequestMapping(value="/mileageNew02")
	public String mileageNew02(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		MMTI0213VO jmvo = new MMTI0213VO();
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("num")));
		jmvo = mileageTobeService.getMMTI0213VO(jmvo);
		
		request.setAttribute("num", request.getParameter("num"));
		request.setAttribute("jmvo", jmvo);
		return "/counter/carrider/tobe/mileageNew02"; 
	}
	
	// aiocr용
	@RequestMapping(value="/aiocrMileageBlackBox01")
	public String aiocrMileageBlackBox01(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		HttpSession session = request.getSession();
		MMTI0213VO jmvo = new MMTI0213VO();

		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("num")));
		logger.debug("mileageBlackBox01 param num = " + request.getParameter("num"));
		logger.debug("mileageBlackBox01 num = " + aes256Decrypt(request.getParameter("num")));
		jmvo.setMtcc_yn(request.getParameter("mtcc_yn"));
		jmvo.setPdc_cd(request.getParameter("pdc_cd"));
		session.setAttribute("checkYn", request.getParameter("checkYn"));
		jmvo = mileageTobeService.getMMTI0213VO(jmvo);
		String view = "";
		
		if("1".equals(jmvo.getPbox_no_dvcd())) { // 주행거리
			if("1".equals(jmvo.getO_c_r_cecd_yn())){
				view = "/counter/carrider/tobe/aiocrMileageNew01";
			} else {
				// view = "/counter/carrider/tobe/mileageNew01";
				view = "/counter/carrider/tobe/aiocrMileage01";
			}
		}
		else if("2".equals(jmvo.getPbox_no_dvcd())) { // 블랙박스
			if("1".equals(jmvo.getMtcc_yn())||"20028".equals(jmvo.getPdc_cd())||"20030".equals(jmvo.getPdc_cd())||"20057".equals(jmvo.getPdc_cd())){ // 이륜차(오토바이) 블랙박스 장착인 경우
				view = "/counter/carrider/tobe/blackbox03";
			} else { // 자동차 블랙박스 장착인 경우
				view = "/counter/carrider/tobe/blackbox01";
			}
		}

		request.setAttribute("num", request.getParameter("num"));
		//request.setAttribute("checkYn", request.getParameter("checkYn"));
		request.setAttribute("mtcc_yn", jmvo.getMtcc_yn());
		request.setAttribute("pdc_cd", jmvo.getPdc_cd());
		request.setAttribute("jmvo", jmvo);
		return view;
	}
	
	//aiocr용
	@RequestMapping(value="/aiocrMileageNew02")
	public String aiocrMileageNew02(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		MMTI0213VO jmvo = new MMTI0213VO();
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("num")));
		jmvo = mileageTobeService.getMMTI0213VO(jmvo);
		
		request.setAttribute("num", request.getParameter("num"));
		request.setAttribute("jmvo", jmvo);
		return "/counter/carrider/tobe/aiocrMileageNew02"; 
	}
	
	/** 
	 * 주행거리 신규 OCR인식결과 수신(AIOCR용)
	 * */
	@RequestMapping(value="/aiocrMileageNewOCR")
	public @ResponseBody Map<String, String> aiocrMileageNewOCR(MultipartHttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		Map<String, String> map = new HashMap<String, String>();
		String yyyymmdd = DateUtil.getDate("yyyymmdd");
		
		String phgp_rl_ptgr_dt			= StringUtil.nvl(request.getParameter("phgp_rl_ptgr_dt"));			// 사진실제촬영일자
		String phgp_apdx_way_cd			= StringUtil.nvl(request.getParameter("phgp_apdx_way_cd"));			// 사진첨부방식코드
		
		MMTI0213VO jmvo = new MMTI0213VO();
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("num")));
		jmvo = mileageTobeService.getMMTI0213VO(jmvo);
		
		String exifDate1 = StringUtil.nvl(request.getParameter("exifDate1"));
		
		if(exifDate1.indexOf(",gallery") > -1) {
			exifDate1 = exifDate1.substring(0, exifDate1.indexOf(",gallery"));
			if(StringUtil.isEmpty(exifDate1)) {
				exifDate1 = DateUtil.getDate();
			}
			else if(Integer.parseInt(exifDate1) > Integer.parseInt(DateUtil.getDate())) {
				map.put("errorCode", "f");
				return map;
			}
		}

		if(exifDate1.indexOf(",gallery") > -1) {
			exifDate1 = exifDate1.substring(0, exifDate1.indexOf(",gallery"));
		}

		ArrayList<File> files = mileageTobeService.aiocrUploadToWAS(request, jmvo.getSms_ts_bvan());
		
		String aut_cgnt_trv_dstc_rsl_cd = "";	// 자동인식주행거리결과코드
		String aut_cgnt_vh_no_rsl_cd = "";		// 자동인식차량번호결과코드
		String aut_cgnt_trv_dstc = "";			// 자동인식주행거리
		String aut_cgnt_vh_no = "";				// 자동인식차량번호
		
		String aut_cgnt_trv_dstc_1 = "";		// 자동인식주행거리1
		String aut_cgnt_trv_dstc_2 = "";		// 자동인식주행거리2
		String aut_cgnt_trv_dstc_3 = "";		// 자동인식주행거리3
		
		String a_i_o_c_r_rqst_dsky_val	= "";	// aiocr요청구분키값
		String a_i_o_c_r_resultCode 	= "";	// aiocr요청결과코드값
		String resultValue 				= "";	// 주행거리값1
		String dtcn_cgnt_rt 			= "";	// 검출인식률1
		String cgnt_cgnt_rt 			= "";	// 인식인식률1
		String resultValue2 			= "";	// 주행거리값2
		String dtcn_cgnt_rt2 			= "";	// 검출인식률2
		String cgnt_cgnt_rt2 			= "";	// 인식인식률2
		String resultValue3 			= "";	// 주행거리값3
		String dtcn_cgnt_rt3 			= "";	// 검출인식률3
		String cgnt_cgnt_rt3 			= "";	// 인식인식률3
		String RE_CODE 					= "";
		String returnMessage			= "";
		
		HashMap<String, String> resultMap = null;
		
		boolean flag1 = false;
		if(files.size() > 0) {
			FTPUtil ftp = null;
			// [200617]
			FileInputStream in = null;
			FileInputStream fis = null;
			FileOutputStream out = null;
			
			HttpResponse httpResp = null;
			HttpEntity respEntity = null;
			
			resultMap = new HashMap<String, String>();
			try {
				if("1".equals(jmvo.getAut_cgnt_nn_apcn_yn())) { // OCR서버 문제있으면...
					aut_cgnt_trv_dstc_rsl_cd = "03";
					aut_cgnt_vh_no_rsl_cd = "03";
				}
				else {
					String propsPath = this.getClass().getResource("").getPath();
					propsPath = propsPath.substring(0, propsPath.indexOf("/classes/")) + "/config/aiocr_ftp.properties";
					
					String aiocrURL = AIOCR_SERVER_PATH;
					CloseableHttpClient httpClient = HttpClients.createDefault();
					HttpPost httpPost = new HttpPost(aiocrURL);
					
					HttpEntity httpEntity = MultipartEntityBuilder.create()
							.addTextBody("templateName", "car.drivingdistance.workflow")
							.addTextBody("senderName", "SMZ")
							.addBinaryBody("Files", new File(files.get(0).toString()), ContentType.MULTIPART_FORM_DATA, files.get(0).toString()).build();
					
					httpPost.setEntity(httpEntity);
					
					CloseableHttpResponse response1 = httpClient.execute(httpPost);
					
					logger.debug("========== start ==========");
					logger.debug("Status Code : " + response1.getStatusLine().getStatusCode());
					logger.debug("========== end ==========");
					
					// json param setting start
					respEntity = response1.getEntity();
					
					String jsonResp = EntityUtils.toString(respEntity);
					logger.debug("AI OCR uploadAiOCR("+files.get(0).toString()+") 응답 json : " + jsonResp);
					
					JSONParser jsonParser = new JSONParser();
					JSONObject jsonObj = (JSONObject) jsonParser.parse(jsonResp);
					JSONArray jsonArray = (JSONArray) jsonObj.get("results");
					
					a_i_o_c_r_rqst_dsky_val	= (String) jsonObj.get("resultItemKey");	// aiocr요청구분키값
					a_i_o_c_r_resultCode = (String) jsonObj.get("resultCode"); // aiocr요청결과코드값(01:정상, 11~33:오류)
					
					if(response1.getStatusLine().getStatusCode() == 200){
						logger.debug("[거울]jsonArray : " + jsonArray.get(0) + "jsonArray size : " + jsonArray.size());
						
						if(jsonResp != null){
//							String ocrResultCode = (String) jsonObj.get("resultCode");
							if(!StringUtil.isEmpty(a_i_o_c_r_resultCode)){
								if("01".equals(a_i_o_c_r_resultCode)){
									if(jsonArray.size() > 0) {
										resultMap.put("RE_CODE", "2");
										aut_cgnt_trv_dstc_rsl_cd = "01";
										for(int s = 0; s < jsonArray.size(); s++){
											if(s == 0) {
												JSONObject jsonObject = (JSONObject) jsonArray.get(0);
												logger.debug("new resultValue = " + (String)jsonObject.get("resultValue"));
												logger.debug("new detectionConfidence = " + (String)jsonObject.get("detectionConfidence"));
												logger.debug("new recognitionConfidence = " + (String)jsonObject.get("recognitionConfidence"));
												
												resultMap.put("resultValue", (String)jsonObject.get("resultValue"));
												resultMap.put("detectionConfidence", (String)jsonObject.get("detectionConfidence"));
												resultMap.put("recognitionConfidence", (String)jsonObject.get("recognitionConfidence"));
											} else if(s == 1) {
												JSONObject jsonObject = (JSONObject) jsonArray.get(1);
												logger.debug("new resultValue2 = " + (String)jsonObject.get("resultValue"));
												logger.debug("new detectionConfidence2 = " + (String)jsonObject.get("detectionConfidence"));
												logger.debug("new recognitionConfidence2 = " + (String)jsonObject.get("recognitionConfidence"));
												
												resultMap.put("resultValue2", (String)jsonObject.get("resultValue"));
												resultMap.put("detectionConfidence2", (String)jsonObject.get("detectionConfidence"));
												resultMap.put("recognitionConfidence2", (String)jsonObject.get("recognitionConfidence"));
											} else {
												JSONObject jsonObject = (JSONObject) jsonArray.get(2);
												logger.debug("new resultValue3 = " + (String)jsonObject.get("resultValue"));
												logger.debug("new detectionConfidence3 = " + (String)jsonObject.get("detectionConfidence"));
												logger.debug("new recognitionConfidence3 = " + (String)jsonObject.get("recognitionConfidence"));
												
												resultMap.put("resultValue3", (String)jsonObject.get("resultValue"));
												resultMap.put("detectionConfidence3", (String)jsonObject.get("detectionConfidence"));
												resultMap.put("recognitionConfidence3", (String)jsonObject.get("recognitionConfidence"));
											}
										
											resultValue				= StringUtil.nvl((String)resultMap.get("resultValue"));			// 주행거리 인식값1
											dtcn_cgnt_rt 			= StringUtil.nvl((String)resultMap.get("detectionConfidence"));	// 검출인식률1
											cgnt_cgnt_rt 			= StringUtil.nvl((String)resultMap.get("recognitionConfidence"));	// 인식인식률1
											resultValue2			= StringUtil.nvl((String)resultMap.get("resultValue2"));			// 주행거리 인식값1
											dtcn_cgnt_rt2 			= StringUtil.nvl((String)resultMap.get("detectionConfidence2"));	// 검출인식률1
											cgnt_cgnt_rt2 			= StringUtil.nvl((String)resultMap.get("recognitionConfidence2"));	// 인식인식률1
											resultValue3			= StringUtil.nvl((String)resultMap.get("resultValue3"));			// 주행거리 인식값1
											dtcn_cgnt_rt3 			= StringUtil.nvl((String)resultMap.get("detectionConfidence3"));	// 검출인식률1
											cgnt_cgnt_rt3 			= StringUtil.nvl((String)resultMap.get("recognitionConfidence3"));	// 인식인식률1
										}
										logger.debug("[거울]resultValue = " + resultValue);
										logger.debug("[거울]dtcn_cgnt_rt = " + dtcn_cgnt_rt);
										logger.debug("[거울]cgnt_cgnt_rt = " + cgnt_cgnt_rt);
										logger.debug("[거울]resultValue2 = " + resultValue2);
										logger.debug("[거울]dtcn_cgnt_rt2 = " + dtcn_cgnt_rt2);
										logger.debug("[거울]cgnt_cgnt_rt2 = " + cgnt_cgnt_rt2);
										logger.debug("[거울]resultValue3 = " + resultValue3);
										logger.debug("[거울]dtcn_cgnt_rt3 = " + dtcn_cgnt_rt3);
										logger.debug("[거울]cgnt_cgnt_rt3 = " + cgnt_cgnt_rt3);

									}
								} else {
									resultMap.put("RE_CODE", "1");
									aut_cgnt_trv_dstc_rsl_cd = a_i_o_c_r_resultCode;
									logger.debug("[거울]aut_cgnt_trv_dstc_rsl_cd = " + aut_cgnt_trv_dstc_rsl_cd);
								} 
							} else {
								aut_cgnt_trv_dstc_rsl_cd = "02"; //솔루션에서 보내주는 결과코드값이 없는 경우에 02로 세팅
							}
						}
					}
					else {
//						aut_cgnt_trv_dstc_rsl_cd = "02";
						aut_cgnt_trv_dstc_rsl_cd = a_i_o_c_r_resultCode;
						logger.debug("[거울]aut_cgnt_trv_dstc_rsl_cd = " + aut_cgnt_trv_dstc_rsl_cd);
						aut_cgnt_vh_no_rsl_cd = "02";
						
						logger.error("AI OCR uploadAiOCR("+files.get(0).toString()+","+files.size()+") 시 Error 발생 : " + respEntity);
		                throw new Exception("AI OCR 실패 : " + files.get(0).toString() + "/ responseCode :" + response1.getStatusLine().getStatusCode() + "/ responseMsg :" + EntityUtils.toString(respEntity));
					}
					// json param setting end
					httpClient.close();
					// aiocr 서버 통신 end
				}
			}
			catch(Exception e) {
				logger.debug(e.getMessage());
//				aut_cgnt_trv_dstc_rsl_cd = "02";
				aut_cgnt_trv_dstc_rsl_cd = a_i_o_c_r_resultCode;
				aut_cgnt_vh_no_rsl_cd = "02";
			}
			finally {
				if(ftp != null) ftp.disconnect();
				// [200617]
				try{
		    	  	if(in != null){
		    	  		in.close();
		    	  	}
			      }catch(IOException ee){
			    	  System.err.println("[MileageTobeController.mileageNewOCR()] IOException 1");
			      }
				try{
		    	  	if(out != null){
		    	  		out.close();
		    	  	}
			      }catch(IOException ee){
			    	  System.err.println("[MileageTobeController.mileageNewOCR()] IOException 2");
			      }
				try{
		    	  	if(fis != null){
		    	  		fis.close();
		    	  	}
			      }catch(IOException ee){
			    	  System.err.println("[MileageTobeController.mileageNewOCR()] IOException 3");
			      }
			}
		}
		
		HttpSession session = request.getSession();
		Object[] imgfile = new Object[files.size()];
		// [200617]
		FileInputStream fis = null;
		try {
			for(int i = 0; i < files.size(); i++) {
				File f = files.get(i);
				fis = new FileInputStream(f);
				byte[] file = new byte[(int) f.length()];
				fis.read(file);
				imgfile[i] = file;
				fis.close();
				fis = null;
				String fname = f.getName();
				f.delete();
				logger.debug(fname + " 삭제");
			}
		} catch (Exception e) {
			System.err.println("[MileageTobeController.mileageNewOCR()] Exception");
		}
		finally {
			try{
				if(fis!=null){
					fis.close();
				}
			}
			catch(IOException ee){
				System.err.println("[MileageTobeController.mileageNewOCR()] IOException 4");
		    }
		}
		session.setAttribute("imgfile", imgfile);
		
		logger.debug("a_i_o_c_r_rqst_dsky_val = " + a_i_o_c_r_rqst_dsky_val);
		logger.debug("dtcn_cgnt_rt = " + dtcn_cgnt_rt);
		logger.debug("cgnt_cgnt_rt = " + cgnt_cgnt_rt);
		
		// 주행거리 가입 확정처리 분기용 OCR 판독여부
		session.setAttribute("aut_cgnt_trv_dstc_rsl_cd", aut_cgnt_trv_dstc_rsl_cd);
		
		map.put("errorCode",					"0");
		map.put("aut_cgnt_trv_dstc_rsl_cd",		aut_cgnt_trv_dstc_rsl_cd);
		map.put("aut_cgnt_vh_no_rsl_cd",		aut_cgnt_vh_no_rsl_cd);
		map.put("aut_cgnt_trv_dstc",			resultValue);
		map.put("aut_cgnt_vh_no",				aut_cgnt_vh_no);
		map.put("aut_cgnt_trv_dstc_1",			resultValue);
		map.put("aut_cgnt_trv_dstc_2",			resultValue2);
		map.put("aut_cgnt_trv_dstc_3",			resultValue3);
		map.put("phgp_rl_ptgr_dt",				phgp_rl_ptgr_dt);
		map.put("phgp_apdx_way_cd",				phgp_apdx_way_cd);
		
		map.put("a_i_o_c_r_rqst_dsky_val", 		a_i_o_c_r_rqst_dsky_val);
		map.put("resultValue", 					resultValue);
		map.put("dtcn_cgnt_rt", 				dtcn_cgnt_rt);
		map.put("cgnt_cgnt_rt", 				cgnt_cgnt_rt);
		map.put("resultValue2", 				resultValue2);
		map.put("dtcn_cgnt_rt2", 				dtcn_cgnt_rt2);
		map.put("cgnt_cgnt_rt2", 				cgnt_cgnt_rt2);
		map.put("resultValue3", 				resultValue3);
		map.put("dtcn_cgnt_rt3", 				dtcn_cgnt_rt3);
		map.put("cgnt_cgnt_rt3", 				cgnt_cgnt_rt3);
		map.put("returnMessage", 				returnMessage);
		
		return map;
	}
	
	/** 
	 * 주행거리 신규 OCR인식결과 수신
	 * */
	@RequestMapping(value="/mileageNewOCR")
	public @ResponseBody Map<String, String> mileageNewOCR(MultipartHttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		Map<String, String> map = new HashMap<String, String>();
		String yyyymmdd = DateUtil.getDate("yyyymmdd");
		
		String phgp_rl_ptgr_dt			= StringUtil.nvl(request.getParameter("phgp_rl_ptgr_dt"));			// 사진실제촬영일자
		String phgp_apdx_way_cd			= StringUtil.nvl(request.getParameter("phgp_apdx_way_cd"));			// 사진첨부방식코드
		
		MMTI0213VO jmvo = new MMTI0213VO();
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("num")));
		jmvo = mileageTobeService.getMMTI0213VO(jmvo);
		
		String exifDate1 = StringUtil.nvl(request.getParameter("exifDate1"));
		
		if(exifDate1.indexOf(",gallery") > -1) {
			exifDate1 = exifDate1.substring(0, exifDate1.indexOf(",gallery"));
			if(StringUtil.isEmpty(exifDate1)) {
				exifDate1 = DateUtil.getDate();
			}
			else if(Integer.parseInt(exifDate1) > Integer.parseInt(DateUtil.getDate())) {
				map.put("errorCode", "f");
				return map;
			}
		}

		if(exifDate1.indexOf(",gallery") > -1) {
			exifDate1 = exifDate1.substring(0, exifDate1.indexOf(",gallery"));
		}

		ArrayList<File> files = mileageTobeService.uploadToWAS(request, jmvo.getSms_ts_bvan());
		
		String aut_cgnt_trv_dstc_rsl_cd = "";	// 자동인식주행거리결과코드
		String aut_cgnt_vh_no_rsl_cd = "";		// 자동인식차량번호결과코드
		String aut_cgnt_trv_dstc = "";			// 자동인식주행거리
		String aut_cgnt_vh_no = "";				// 자동인식차량번호
		
		String aut_cgnt_trv_dstc_1 = "";		// 자동인식주행거리1
		String aut_cgnt_trv_dstc_2 = "";		// 자동인식주행거리2
		String aut_cgnt_trv_dstc_3 = "";		// 자동인식주행거리3
		
		
		boolean flag1 = false;
		if(files.size() > 0) {
			FTPUtil ftp = null;
			// [200617]
			FileInputStream in = null;
			FileInputStream fis = null;
			FileOutputStream out = null;
			
			try {
				if("1".equals(jmvo.getAut_cgnt_nn_apcn_yn())) { // OCR서버 문제있으면...
					aut_cgnt_trv_dstc_rsl_cd = "03";
					aut_cgnt_vh_no_rsl_cd = "03";
				}
				else {
					String propsPath = this.getClass().getResource("").getPath();
					propsPath = propsPath.substring(0, propsPath.indexOf("/classes/")) + "/config/ocr_ftp.properties";
					Properties p = new Properties();
					// [200617]
					in = new FileInputStream(propsPath);
					p.load(in);
					in.close();
					// [200617]
					in = null;
					
					String password = p.getProperty("password");
					String decPassword = aes256Decrypt(password);
					if(password.equals(decPassword) || StringUtil.isEmpty(decPassword)) {
						decPassword = password;
						String encPassword = aes256Encrypt(password);
						logger.debug("encPassword: " + encPassword);
						// [200617]
						out = new FileOutputStream(propsPath);
						p.setProperty("password", encPassword);
						p.store(out, "");
						out.close();
						// [200617]
						out = null;
					}
					
					ftp = new FTPUtil(p.getProperty("ip"), p.getProperty("user"), decPassword, Integer.parseInt(p.getProperty("port")));
					
					int working = 0;
					for(int i = 1; i <= 3; i++) {
						String[] ls = ftp.ls("/RECOG_JOB" + i + "/" + yyyymmdd);
						for(int j = 0; j < ls.length; j++) {
							if(".".equals(ls[j]) || "..".equals(ls[j])) continue;
							working++;
						}
					}
	
					if(working <= 6) {
						String filename1 = "";
						
						filename1 = ftp.uploadToOCR("/RECOG/" + yyyymmdd, files.get(0), "--D");

						logger.debug("filename1: " + filename1);

						
						logger.debug("--- 1초 대기 ---");
						Thread.sleep(1000);
						int retryNum = 7;
						for(int retry = 0; retry < retryNum; retry++) {
							String[] ls = ftp.ls("/RECOG_RESULT/" + yyyymmdd);
		
							for(int i = 0; i < ls.length; i++) {
								// logger.debug(ls[i]);
								if(!flag1 && ls[i].equals(filename1)) {
									flag1 = true;
								}
								
								if(flag1) break;
							}
		
							if((flag1) || retry == retryNum - 1) {
								break;
							}
							else {
								logger.debug("--- 0.6초 대기 ---");
								Thread.sleep(600);
							}
						}
						
						logger.debug("flag1: " + flag1);
						
						if(flag1) {
							// [210219]
							if(filename1 != null || !"".equals(filename1)){
								filename1 = filename1.replaceAll("/", "");
								filename1 = filename1.replaceAll("\\\\", "");
								filename1 = filename1.replaceAll("./", "");
								filename1 = filename1.replaceAll("../", "");
								filename1 = filename1.replaceAll("&", "");
							}
							
							String path = files.get(0).getParent() + File.separator + filename1;
							ftp.downloadFromOCR("/RECOG_RESULT/" + yyyymmdd, filename1, path);
							logger.debug("path: " + path);
							
							// [210219]
							File f = new File(files.get(0).getParent() + File.separator + filename1);
							// File f = new File(path);
		
							if(f.exists()) {
								Properties props = new Properties();
								// [210219]
								fis = new FileInputStream(files.get(0).getParent() + File.separator + filename1);
								props.load(fis);
								fis.close();
								// [200617]
								fis = null;
								
								if(!StringUtil.isEmpty(props.getProperty("ODO")) && !StringUtil.isEmpty(props.getProperty("RE_CODE"))) {
									aut_cgnt_trv_dstc = props.getProperty("ODO");
									aut_cgnt_trv_dstc_rsl_cd = "1".equals(props.getProperty("RE_CODE")) || "2".equals(props.getProperty("RE_CODE")) ? "01" : "02";
									
									aut_cgnt_trv_dstc_1 = props.getProperty("ODO");
									
									if(!StringUtil.isEmpty(props.getProperty("ODO2"))) {
										aut_cgnt_trv_dstc_2 = props.getProperty("ODO2");
									}
									
									if(!StringUtil.isEmpty(props.getProperty("ODO3"))) {
										aut_cgnt_trv_dstc_3 = props.getProperty("ODO3");
									}
								}
								
				            	if(f.delete()) {
									logger.debug("삭제: " + path);
								}
							}
						}
						else {
							aut_cgnt_trv_dstc_rsl_cd = "02";
						}						
					}
					else {
						aut_cgnt_trv_dstc_rsl_cd = "02";
						aut_cgnt_vh_no_rsl_cd = "02";
					}
				}
			}
			catch(Exception e) {
				logger.debug(e.getMessage());
				aut_cgnt_trv_dstc_rsl_cd = "02";
				aut_cgnt_vh_no_rsl_cd = "02";
			}
			finally {
				if(ftp != null) ftp.disconnect();
				// [200617]
				try{
		    	  	if(in != null){
		    	  		in.close();
		    	  	}
			      }catch(IOException ee){
			    	  System.err.println("[MileageTobeController.mileageNewOCR()] IOException 1");
			      }
				try{
		    	  	if(out != null){
		    	  		out.close();
		    	  	}
			      }catch(IOException ee){
			    	  System.err.println("[MileageTobeController.mileageNewOCR()] IOException 2");
			      }
				try{
		    	  	if(fis != null){
		    	  		fis.close();
		    	  	}
			      }catch(IOException ee){
			    	  System.err.println("[MileageTobeController.mileageNewOCR()] IOException 3");
			      }
			}
		}
		
		HttpSession session = request.getSession();
		Object[] imgfile = new Object[files.size()];
		// [200617]
		FileInputStream fis = null;
		try {
			for(int i = 0; i < files.size(); i++) {
				File f = files.get(i);
				fis = new FileInputStream(f);
				byte[] file = new byte[(int) f.length()];
				fis.read(file);
				imgfile[i] = file;
				fis.close();
				fis = null;
				String fname = f.getName();
				f.delete();
				logger.debug(fname + " 삭제");
			}
		} catch (Exception e) {
			System.err.println("[MileageTobeController.mileageNewOCR()] Exception");
		}
		finally {
			try{
				if(fis!=null){
					fis.close();
				}
			}
			catch(IOException ee){
				System.err.println("[MileageTobeController.mileageNewOCR()] IOException 4");
		    }
		}
		session.setAttribute("imgfile", imgfile);
		
		
		// 주행거리 가입 확정처리 분기용 OCR 판독여부
		session.setAttribute("aut_cgnt_trv_dstc_rsl_cd", aut_cgnt_trv_dstc_rsl_cd);
		
		map.put("errorCode",					"0");
		map.put("aut_cgnt_trv_dstc_rsl_cd",		aut_cgnt_trv_dstc_rsl_cd);
		map.put("aut_cgnt_vh_no_rsl_cd",		aut_cgnt_vh_no_rsl_cd);
		map.put("aut_cgnt_trv_dstc",			aut_cgnt_trv_dstc);
		map.put("aut_cgnt_vh_no",				aut_cgnt_vh_no);
		map.put("aut_cgnt_trv_dstc_1",			aut_cgnt_trv_dstc_1);
		map.put("aut_cgnt_trv_dstc_2",			aut_cgnt_trv_dstc_2);
		map.put("aut_cgnt_trv_dstc_3",			aut_cgnt_trv_dstc_3);
		map.put("phgp_rl_ptgr_dt",				phgp_rl_ptgr_dt);
		map.put("phgp_apdx_way_cd",				phgp_apdx_way_cd);
			
		return map;
	}
	
	@RequestMapping(value="/mileageNew03")
	public String mileageNew03(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		MMTI0213VO jmvo = new MMTI0213VO();
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("num")));
		jmvo = mileageTobeService.getMMTI0213VO(jmvo);
		
		HttpSession session = request.getSession();
		Object[] imgfile = (Object[]) session.getAttribute("imgfile");
		if(imgfile != null) {
			byte[] file = (byte[]) imgfile[0];
			logger.debug("file.length: " + file.length);
			request.setAttribute("imgsrc", "data:image/jpeg;base64," + new String(Base64.encodeBase64(file)));
		}
		
		request.setAttribute("num", request.getParameter("num"));
		request.setAttribute("jmvo", jmvo);
		session.setAttribute("sms_ts_bvan", jmvo.getSms_ts_bvan());
		
		String exifDate1 = StringUtil.nvl(request.getParameter("exifDate1"));
		
		if(exifDate1.indexOf(",gallery") > -1) {
			exifDate1 = exifDate1.substring(0, exifDate1.indexOf(",gallery"));
			if(StringUtil.isEmpty(exifDate1)) {
				exifDate1 = DateUtil.getDate();
			}
		}
		session.setAttribute("exifDt", exifDate1);
		// 계좌환급 완료분기 신규 설계 보종 기준으로 해야함
		session.setAttribute("n_cm_yn", jmvo.getCm_yn());

		return "/counter/carrider/tobe/mileageNew03";
	}
	
	//aiocr용
	@RequestMapping(value="/aiocrMileageNew03")
	public String aiocrMileageNew03(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		MMTI0213VO jmvo = new MMTI0213VO();
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("num")));
		jmvo = mileageTobeService.getMMTI0213VO(jmvo);
		
		HttpSession session = request.getSession();
		Object[] imgfile = (Object[]) session.getAttribute("imgfile");
		if(imgfile != null) {
			byte[] file = (byte[]) imgfile[0];
			logger.debug("file.length: " + file.length);
			request.setAttribute("imgsrc", "data:image/jpeg;base64," + new String(Base64.encodeBase64(file)));
		}
		
		request.setAttribute("num", request.getParameter("num"));
		request.setAttribute("jmvo", jmvo);
		session.setAttribute("sms_ts_bvan", jmvo.getSms_ts_bvan());
		
		String exifDate1 = StringUtil.nvl(request.getParameter("exifDate1"));
		
		if(exifDate1.indexOf(",gallery") > -1) {
			exifDate1 = exifDate1.substring(0, exifDate1.indexOf(",gallery"));
			if(StringUtil.isEmpty(exifDate1)) {
				exifDate1 = DateUtil.getDate();
			}
		}
		session.setAttribute("exifDt", exifDate1);
		// 계좌환급 완료분기 신규 설계 보종 기준으로 해야함
		session.setAttribute("n_cm_yn", jmvo.getCm_yn());

		return "/counter/carrider/tobe/aiocrMileageNew03";
	}
	
	@RequestMapping(value="/mileageNewOCR2")
	public @ResponseBody Map<String, String> mileageNewOCR2(MultipartHttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		
		String aut_cgnt_trv_dstc_rsl_cd	= StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc_rsl_cd"));	// 자동인식주행거리결과코드
		String aut_cgnt_vh_no_rsl_cd	= StringUtil.nvl(request.getParameter("aut_cgnt_vh_no_rsl_cd"));	// 자동인식차량번호결과코드
		String aut_cgnt_trv_dstc		= StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc"));		// 자동인식주행거리
		String aut_cgnt_vh_no			= StringUtil.nvl(request.getParameter("aut_cgnt_vh_no"));			// 자동인식차량번호
		
		String aut_cgnt_trv_dstc_1		= StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc_1"));		// 자동인식주행거리1
		String aut_cgnt_trv_dstc_2		= StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc_2"));		// 자동인식주행거리2
		String aut_cgnt_trv_dstc_3		= StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc_3"));		// 자동인식주행거리3
		
		String phgp_rl_ptgr_dt			= StringUtil.nvl(request.getParameter("phgp_rl_ptgr_dt"));			// 사진실제촬영일자
		String phgp_apdx_way_cd			= StringUtil.nvl(request.getParameter("phgp_apdx_way_cd"));			// 사진첨부방식코드
		
		Map<String, String> map = new HashMap<String, String>();
		MMTI0213VO jmvo = new MMTI0213VO();
		MBTR01001VO mbtr01001vo = new MBTR01001VO();
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("num")));
		
		String exifDate1 = StringUtil.nvl(request.getParameter("exifDate1"));
		
		String phgp_ptgr_dt = "";
		
		boolean empty = false;
		if(exifDate1.indexOf(",gallery") > -1) {
			exifDate1 = exifDate1.substring(0, exifDate1.indexOf(",gallery"));
			if(StringUtil.isEmpty(exifDate1)) {
				exifDate1 = DateUtil.getDate();
				empty = true;
			}
			else if(Integer.parseInt(exifDate1) > Integer.parseInt(DateUtil.getDate())) {
				map.put("errorCode", "f");
				return map;
			}
		}

		phgp_ptgr_dt = empty ? "" : exifDate1;
		
		if(exifDate1.indexOf(",gallery") > -1) {
			exifDate1 = exifDate1.substring(0, exifDate1.indexOf(",gallery"));
		}
		
		HttpSession session = request.getSession();
		session.setAttribute("exifDate", exifDate1);
		
		MMTI0259VO jmvo1 = new MMTI0259VO();
		jmvo1.setPbox_use_yn("1");
		jmvo1.setPbox_no(jmvo.getSms_ts_bvan());
		jmvo1.setPhgp_cnfm_dt(DateUtil.getDate("yyyymmdd"));
		jmvo1.setPhgp_ptgr_dt(phgp_ptgr_dt);
		jmvo1.setPhgp_strg_yn("1");
		if("1".equals(jmvo.getAut_cgnt_nn_apcn_yn())) {
			jmvo1.setPbox_chr_nm(request.getParameter("mileage1"));
		}
		
		jmvo1.setInpt_trv_dstc(request.getParameter("mileage1"));
		
		if(!StringUtil.isEmpty(aut_cgnt_vh_no)) {
			jmvo1.setAut_cgnt_vh_no(aut_cgnt_vh_no);
		}
		
		if(!StringUtil.isEmpty(aut_cgnt_vh_no_rsl_cd)) {
			jmvo1.setAut_cgnt_vh_no_rsl_cd(aut_cgnt_vh_no_rsl_cd);
		} else {
			jmvo1.setAut_cgnt_vh_no_rsl_cd("02");
		}
		
		if(!StringUtil.isEmpty(aut_cgnt_trv_dstc)) {
			jmvo1.setAut_cgnt_trv_dstc(aut_cgnt_trv_dstc);
		}
		
		if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_rsl_cd)) {
			jmvo1.setAut_cgnt_trv_dstc_rsl_cd(aut_cgnt_trv_dstc_rsl_cd);
		}
		else {
			jmvo1.setAut_cgnt_trv_dstc_rsl_cd("02");
		}
		
		if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_1)) {
			jmvo1.setAut_cgnt_trv_dstc_1(aut_cgnt_trv_dstc_1);
		}
		
		if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_2)) {
			jmvo1.setAut_cgnt_trv_dstc_2(aut_cgnt_trv_dstc_2);
		}
		
		if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_3)) {
			jmvo1.setAut_cgnt_trv_dstc_3(aut_cgnt_trv_dstc_3);
		}
		
		jmvo1.setPhgp_rl_ptgr_dt(phgp_rl_ptgr_dt);
		jmvo1.setPhgp_apdx_way_cd(phgp_apdx_way_cd);
		
		// jmvo1.setExp_exca_plan_proc_dvn("1");
		jmvo1.setPlno(jmvo.getPlno());
		jmvo1 = mileageTobeService.getMMTI0259VO(jmvo1);
		session.setAttribute("mileage_0259", jmvo1);
		
		if("0".equals(jmvo1.getErrorCode())){
			mbtr01001vo = mileageTobeService.regInfoToEdmsForMobileWeb(request, jmvo.getSms_ts_bvan(), mbtr01001vo);
		}
		
		// 주행거리 수정한경우 1, 수정안한경우 0

		double inpt_mile = Double.parseDouble(jmvo1.getInpt_trv_dstc());
		double auto_mile = Double.parseDouble(jmvo1.getAut_cgnt_trv_dstc());
		
		if(Math.abs(inpt_mile-auto_mile) <= 250){
			session.setAttribute("modify_mile", "0");
		}else{
			session.setAttribute("modify_mile", "1");
		}
		/*
		if(jmvo1.getInpt_trv_dstc().equals(jmvo1.getAut_cgnt_trv_dstc())){
			session.setAttribute("modify_mile", "0");
		}else{
			session.setAttribute("modify_mile", "1");
		}
		*/
		
		int insertRow = 0;
		
		// VO SET
		mbtr01001vo.setPboxNo(jmvo.getSms_ts_bvan());
		mbtr01001vo.setApdxFlRutNm("");
		mbtr01001vo.setFrstIpmnEmpno("82101685");
		mbtr01001vo.setFnalAmdrEmpno("82101685");
		
		insertRow = mileageTobeService.insertTest(mbtr01001vo);
		if(insertRow < 1){
			logger.info("#### 사서함번호: " + StringUtil.nvl(mbtr01001vo.getPboxNo()) + "####");
			logger.info("#### insert 결과: Fail ####");
		}else{
			logger.info("#### insert 결과: Success ####");
		}
		
		map.put("errorCode", jmvo1.getErrorCode());
		map.put("z_resp_msg", jmvo1.getZ_resp_msg());
			
		return map;
	}
	
	//aiocr용
	@RequestMapping(value="/aiocrMileageNewOCR2")
	public @ResponseBody Map<String, String> aiocrMileageNewOCR2(MultipartHttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		
		String aut_cgnt_trv_dstc_rsl_cd	= StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc_rsl_cd"));	// 자동인식주행거리결과코드
		String aut_cgnt_vh_no_rsl_cd	= StringUtil.nvl(request.getParameter("aut_cgnt_vh_no_rsl_cd"));	// 자동인식차량번호결과코드
		String aut_cgnt_trv_dstc		= StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc"));		// 자동인식주행거리
		String aut_cgnt_vh_no			= StringUtil.nvl(request.getParameter("aut_cgnt_vh_no"));			// 자동인식차량번호
		
		String aut_cgnt_trv_dstc_1		= StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc_1"));		// 자동인식주행거리1
		String aut_cgnt_trv_dstc_2		= StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc_2"));		// 자동인식주행거리2
		String aut_cgnt_trv_dstc_3		= StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc_3"));		// 자동인식주행거리3
		
		String a_i_o_c_r_rqst_dsky_val	= StringUtil.nvl(request.getParameter("a_i_o_c_r_rqst_dsky_val"));	// aiocr요청구분키값
		String resultValue 				= StringUtil.nvl(request.getParameter("resultValue"));				// 주행거리 인식값
		String dtcn_cgnt_rt 			= StringUtil.nvl(request.getParameter("dtcn_cgnt_rt"));				// 검출인식률
		String cgnt_cgnt_rt 			= StringUtil.nvl(request.getParameter("cgnt_cgnt_rt"));				// 인식인식률
		String returnMessage			= StringUtil.nvl(request.getParameter("returnMessage"));			// AIOCR 에러메시지
		
		String phgp_rl_ptgr_dt			= StringUtil.nvl(request.getParameter("phgp_rl_ptgr_dt"));			// 사진실제촬영일자
		String phgp_apdx_way_cd			= StringUtil.nvl(request.getParameter("phgp_apdx_way_cd"));			// 사진첨부방식코드
		
		Map<String, String> map = new HashMap<String, String>();
		MMTI0213VO jmvo = new MMTI0213VO();
		MBTR01001VO mbtr01001vo = new MBTR01001VO();
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("num")));
		
		String exifDate1 = StringUtil.nvl(request.getParameter("exifDate1"));
		
		String phgp_ptgr_dt = "";
		
		boolean empty = false;
		if(exifDate1.indexOf(",gallery") > -1) {
			exifDate1 = exifDate1.substring(0, exifDate1.indexOf(",gallery"));
			if(StringUtil.isEmpty(exifDate1)) {
				exifDate1 = DateUtil.getDate();
				empty = true;
			}
			else if(Integer.parseInt(exifDate1) > Integer.parseInt(DateUtil.getDate())) {
				map.put("errorCode", "f");
				return map;
			}
		}

		phgp_ptgr_dt = empty ? "" : exifDate1;
		
		if(exifDate1.indexOf(",gallery") > -1) {
			exifDate1 = exifDate1.substring(0, exifDate1.indexOf(",gallery"));
		}
		
		HttpSession session = request.getSession();
		session.setAttribute("exifDate", exifDate1);
		
		MMTI0259VO jmvo1 = new MMTI0259VO();
		jmvo1.setPbox_use_yn("1");
		jmvo1.setPbox_no(jmvo.getSms_ts_bvan());
		jmvo1.setPhgp_cnfm_dt(DateUtil.getDate("yyyymmdd"));
		jmvo1.setPhgp_ptgr_dt(phgp_ptgr_dt);
		jmvo1.setPhgp_strg_yn("1");
		if("1".equals(jmvo.getAut_cgnt_nn_apcn_yn())) {
			jmvo1.setPbox_chr_nm(request.getParameter("mileage1"));
		}
		
		jmvo1.setInpt_trv_dstc(request.getParameter("mileage1"));
		
		if(!StringUtil.isEmpty(aut_cgnt_vh_no)) {
			jmvo1.setAut_cgnt_vh_no(aut_cgnt_vh_no);
		}
		
		if(!StringUtil.isEmpty(aut_cgnt_vh_no_rsl_cd)) {
			jmvo1.setAut_cgnt_vh_no_rsl_cd(aut_cgnt_vh_no_rsl_cd);
		} else {
			jmvo1.setAut_cgnt_vh_no_rsl_cd("02");
		}
		
		if(!StringUtil.isEmpty(aut_cgnt_trv_dstc)) {
			jmvo1.setAut_cgnt_trv_dstc(aut_cgnt_trv_dstc);
		}
		
		if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_rsl_cd)) {
			jmvo1.setAut_cgnt_trv_dstc_rsl_cd(aut_cgnt_trv_dstc_rsl_cd);
		}
		else {
			jmvo1.setAut_cgnt_trv_dstc_rsl_cd("02");
		}
		
		if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_1)) {
			jmvo1.setAut_cgnt_trv_dstc_1(aut_cgnt_trv_dstc_1);
		}
		
		if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_2)) {
			jmvo1.setAut_cgnt_trv_dstc_2(aut_cgnt_trv_dstc_2);
		}
		
		if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_3)) {
			jmvo1.setAut_cgnt_trv_dstc_3(aut_cgnt_trv_dstc_3);
		}
		
		if(!StringUtil.isEmpty(a_i_o_c_r_rqst_dsky_val)) {
			jmvo1.setA_i_o_c_r_rqst_dsky_val(a_i_o_c_r_rqst_dsky_val);
		}
		
		if(!StringUtil.isEmpty(dtcn_cgnt_rt)) {
			jmvo1.setDtcn_cgnt_rt(dtcn_cgnt_rt);
		}
		
		if(!StringUtil.isEmpty(cgnt_cgnt_rt)) {
			jmvo1.setCgnt_cgnt_rt(cgnt_cgnt_rt);
		}
		
		if(!StringUtil.isEmpty(returnMessage)) {
			jmvo1.setERRMSG(returnMessage);
		}
		
		jmvo1.setPhgp_rl_ptgr_dt(phgp_rl_ptgr_dt);
		jmvo1.setPhgp_apdx_way_cd(phgp_apdx_way_cd);
		
		// jmvo1.setExp_exca_plan_proc_dvn("1");
		jmvo1.setPlno(jmvo.getPlno());
		jmvo1 = mileageTobeService.getMMTI0259VO(jmvo1);
		session.setAttribute("mileage_0259", jmvo1);
		
		if("0".equals(jmvo1.getErrorCode())){
			mbtr01001vo = mileageTobeService.aiocrRegInfoToEdmsForMobileWeb(request, jmvo.getSms_ts_bvan(), mbtr01001vo);
		}
		
		// 주행거리 수정한경우 1, 수정안한경우 0

		double inpt_mile = Double.parseDouble(jmvo1.getInpt_trv_dstc());
		double auto_mile = Double.parseDouble(jmvo1.getAut_cgnt_trv_dstc());
		
		if(Math.abs(inpt_mile-auto_mile) <= 250){
			session.setAttribute("modify_mile", "0");
		}else{
			session.setAttribute("modify_mile", "1");
		}
		/*
		if(jmvo1.getInpt_trv_dstc().equals(jmvo1.getAut_cgnt_trv_dstc())){
			session.setAttribute("modify_mile", "0");
		}else{
			session.setAttribute("modify_mile", "1");
		}
		*/
		
		int insertRow = 0;
		
		// VO SET
		mbtr01001vo.setPboxNo(jmvo.getSms_ts_bvan());
		mbtr01001vo.setApdxFlRutNm("");
		mbtr01001vo.setFrstIpmnEmpno("82101685");
		mbtr01001vo.setFnalAmdrEmpno("82101685");
		
		insertRow = mileageTobeService.insertTest(mbtr01001vo);
		if(insertRow < 1){
			logger.info("#### 사서함번호: " + StringUtil.nvl(mbtr01001vo.getPboxNo()) + "####");
			logger.info("#### insert 결과: Fail ####");
		}else{
			logger.info("#### insert 결과: Success ####");
		}
		
		map.put("errorCode", jmvo1.getErrorCode());
		map.put("z_resp_msg", jmvo1.getZ_resp_msg());
			
		return map;
	}
	
	@RequestMapping(value="/mileageNew04")
	public String mileageNew04(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		HttpSession session = request.getSession();
		MMTI0213VO mmti0213vo = new MMTI0213VO();
		MMTI0305VO mmti0305vo = new MMTI0305VO();
		String sms_ts_bvan = (String)session.getAttribute("sms_ts_bvan");
		mmti0213vo.setSms_ts_bvan(sms_ts_bvan);
		mmti0213vo = mileageTobeService.getMMTI0213VO(mmti0213vo);
		
		/*
		if("01".equals((String)session.getAttribute("aut_cgnt_trv_dstc_rsl_cd")) && "0".equals((String)session.getAttribute("modify_mile"))){
			// 전계약 정산 진행여부(1: 진행)
			session.setAttribute("ctn_yn", "1");
			
			mmti0305vo.setSrch_cnd__vh_no(SeedUtil.encrypt(mmti0213vo.getVh_no()));
			mmti0305vo.setSrch_cnd__plno(mmti0213vo.getCtc_plno());
			mmti0305vo.setSrch_cnd__proc_dvn("01");
			mmti0305vo.setSrch_cnd__hdlr_empno("80000040");
			mmti0305vo.setSrch_cnd__trv_dstc_proc_dvcd("10");
			mmti0305vo = mileageTobeService.chatMMTI0305VO(mmti0305vo);
			
			String arc_pd = mmti0305vo.getSrch_rsl__arc_pd().substring(0, 4)
					+ "." + mmti0305vo.getSrch_rsl__arc_pd().substring(4, 6)
					+ "." + mmti0305vo.getSrch_rsl__arc_pd().substring(6, 8);
			String arc_et = mmti0305vo.getSrch_rsl__arc_et().substring(0, 4)
					+ "." + mmti0305vo.getSrch_rsl__arc_et().substring(4, 6)
					+ "." + mmti0305vo.getSrch_rsl__arc_et().substring(6, 8);
			// 전계약 보험시기, 종기
			session.setAttribute("arc_pd", arc_pd);
			session.setAttribute("arc_et", arc_et);
		}else{
			// 전계약 정산 진행여부(0: 미진행)
			session.setAttribute("ctn_yn", "0");
		}
		*/
		
		
		// 전계약 정산대상여부 확인(1: 정산대상)
		if("1".equals(mmti0213vo.getTrv_dstc_tty_exca_tgt_yn())){
			// OCR 정상인식 및 주행거리 미수정 확인(01: 정상판독, 0: 주행거리미수정)
			if("01".equals((String)session.getAttribute("aut_cgnt_trv_dstc_rsl_cd")) && "0".equals((String)session.getAttribute("modify_mile"))){
				// 전계약 정산 진행여부(1: 진행)
				session.setAttribute("ctn_yn", "1");
				
				// mmti0305vo.setSrch_cnd__vh_no(SeedUtil.encrypt(mmti0213vo.getVh_no()));
				mmti0305vo.setSrch_cnd__plno(mmti0213vo.getCtc_plno());
				mmti0305vo.setSrch_cnd__proc_dvn("01");
				mmti0305vo.setSrch_cnd__hdlr_empno("80000040");
				mmti0305vo.setSrch_cnd__trv_dstc_proc_dvcd("10");
				mmti0305vo = mileageTobeService.getMMTI0305VO(mmti0305vo);
				
				String arc_pd = mmti0305vo.getSrch_rsl__arc_pd().substring(0, 4)
						+ "." + mmti0305vo.getSrch_rsl__arc_pd().substring(4, 6)
						+ "." + mmti0305vo.getSrch_rsl__arc_pd().substring(6, 8);
				String arc_et = mmti0305vo.getSrch_rsl__arc_et().substring(0, 4)
						+ "." + mmti0305vo.getSrch_rsl__arc_et().substring(4, 6)
						+ "." + mmti0305vo.getSrch_rsl__arc_et().substring(6, 8);
				// 전계약 보험시기, 종기
				session.setAttribute("arc_pd", arc_pd);
				session.setAttribute("arc_et", arc_et);
			}else{
				// 전계약 정산 진행여부(0: 미진행)
				session.setAttribute("ctn_yn", "0");
			}
		}else{
			// 전계약 정산 진행여부(0: 미진행)
			session.setAttribute("ctn_yn", "0");
		}
		
		return "/counter/carrider/tobe/mileageNew04";
	}
	
	@RequestMapping(value="/mileageNew05")
	public @ResponseBody Map<String, String> mileageNew05(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
	// @RequestMapping(value="/mileageNew05")
	// public String mileageNew05(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		HttpSession session = request.getSession();
		Map<String, String> map = new HashMap<String, String>();
		MMTI0213VO mmti0213vo = new MMTI0213VO();
		// 직전계약정보
		MMTI0213VO pre_mmti0213vo = new MMTI0213VO();
		// 가입 시 주행거리입력정보
		MMTI0259VO mmti0259vo = new MMTI0259VO();
		// 전계약 정산 시 주행거리입력정보
		MMTI0259VO pre_mmti0259vo = new MMTI0259VO();
		// 전계약 사서함번호 조회용
		MMTI0305VO mmti0305vo = new MMTI0305VO();
		MBTR01001VO mbtr01001vo = new MBTR01001VO();
		
		MBTT02001VO mbtt02001vo = new MBTT02001VO();
		String scrnNm = "mileageNew05";
		
		// 현계약에서 전계약증번 가져오기
		String sms_ts_bvan = (String)session.getAttribute("sms_ts_bvan");
		mmti0213vo.setSms_ts_bvan(sms_ts_bvan);
		mmti0213vo = mileageTobeService.getMMTI0213VO(mmti0213vo);
		
		// 전계약증번으로 전계약 사서함번호 가져오기
		mmti0305vo.setSrch_cnd__plno(mmti0213vo.getCtc_plno());
		// mmti0305vo.setSrch_cnd__plno("220201439395000");
		
		mmti0305vo.setSrch_cnd__proc_dvn("02");
		mmti0305vo.setSrch_cnd__hdlr_empno("80000040");
		mmti0305vo.setSrch_cnd__trv_dstc_proc_dvcd("10");
		mmti0305vo = mileageTobeService.getMMTI0305VO(mmti0305vo);
		
		String pbox_no = mmti0305vo.getSrch_rsl__pbox_no();
		// 전계약 사서함번호
		session.setAttribute("pbox_no", pbox_no);
		
		
		// 전계약 사서함번호로 전계약정보 가져오기
		pre_mmti0213vo.setSms_ts_bvan(pbox_no);
		pre_mmti0213vo = mileageTobeService.getMMTI0213VO(pre_mmti0213vo);
		
		// 전계약 차량번호
		session.setAttribute("vh_no", pre_mmti0213vo.getVh_no());
		
		// 259, 259, edms => 환급금 발생 x -> 환급보험료 없다는 안내화면 이동, 있으면 연환산주행거리, 환급보험료 보여줌
		
		// 환산주행거리: 259.cnv_trv_dstc
		// 추징환급보험료: 259.adc_rtrn_prm
		//
		
		// 가입 시 주행거리 입력정보
		mmti0259vo = (MMTI0259VO)session.getAttribute("mileage_0259");
		
		// 전계약정산 주행거리정보 세팅
		pre_mmti0259vo.setPbox_use_yn("1");
		pre_mmti0259vo.setPbox_no(pbox_no);
		pre_mmti0259vo.setPhgp_cnfm_dt(DateUtil.getDate());
		pre_mmti0259vo.setPhgp_ptgr_dt(mmti0259vo.getPhgp_ptgr_dt());
		pre_mmti0259vo.setPhgp_strg_yn("1");
		
		// 213 자동인식 미적용여부 1: 미적용
		if("1".equals(pre_mmti0213vo.getAut_cgnt_nn_apcn_yn())){
			pre_mmti0259vo.setPbox_chr_nm(mmti0259vo.getPbox_chr_nm());
		}
		// 사서함번호 구분코드 1:주행거리
		if("1".equals(pre_mmti0213vo.getPbox_no_dvcd())){
			
			// 입력주행거리
			pre_mmti0259vo.setInpt_trv_dstc(mmti0259vo.getInpt_trv_dstc());
			if(!StringUtil.isEmpty(mmti0259vo.getAut_cgnt_vh_no())){
				pre_mmti0259vo.setAut_cgnt_vh_no(mmti0259vo.getAut_cgnt_vh_no());
			}
			if(!StringUtil.isEmpty(mmti0259vo.getAut_cgnt_vh_no_rsl_cd())){
				pre_mmti0259vo.setAut_cgnt_vh_no_rsl_cd(mmti0259vo.getAut_cgnt_vh_no_rsl_cd());
			}else{
				pre_mmti0259vo.setAut_cgnt_vh_no_rsl_cd("02");
			}
			// 자동인식주행거리
			if(!StringUtil.isEmpty(mmti0259vo.getAut_cgnt_trv_dstc())){
				pre_mmti0259vo.setAut_cgnt_trv_dstc(mmti0259vo.getAut_cgnt_trv_dstc());
			}
			// 자동인식주행거리결과코드(01:정상, 02: 오류, 03: OCR미적용)
			if(!StringUtil.isEmpty(mmti0259vo.getAut_cgnt_trv_dstc_rsl_cd())){
				pre_mmti0259vo.setAut_cgnt_trv_dstc_rsl_cd(mmti0259vo.getAut_cgnt_trv_dstc_rsl_cd());
			}else{
				pre_mmti0259vo.setAut_cgnt_trv_dstc_rsl_cd("02");
			}
			if(!StringUtil.isEmpty(mmti0259vo.getAut_cgnt_trv_dstc_1())){
				pre_mmti0259vo.setAut_cgnt_trv_dstc_1(mmti0259vo.getAut_cgnt_trv_dstc_1());
			}
			if(!StringUtil.isEmpty(mmti0259vo.getAut_cgnt_trv_dstc_2())){
				pre_mmti0259vo.setAut_cgnt_trv_dstc_2(mmti0259vo.getAut_cgnt_trv_dstc_2());
			}
			if(!StringUtil.isEmpty(mmti0259vo.getAut_cgnt_trv_dstc_3())){
				pre_mmti0259vo.setAut_cgnt_trv_dstc_3(mmti0259vo.getAut_cgnt_trv_dstc_3());
			}
		}
		if(!StringUtil.isEmpty(mmti0259vo.getPhgp_rl_ptgr_dt())){
			pre_mmti0259vo.setPhgp_rl_ptgr_dt(mmti0259vo.getPhgp_rl_ptgr_dt());
		}
		if(!StringUtil.isEmpty(mmti0259vo.getPhgp_apdx_way_cd())){
			pre_mmti0259vo.setPhgp_apdx_way_cd(mmti0259vo.getPhgp_apdx_way_cd());
		}
		
		//aiocr용 추가
		if (!StringUtil.isEmpty(mmti0259vo.getA_i_o_c_r_rqst_dsky_val())) {
			pre_mmti0259vo.setA_i_o_c_r_rqst_dsky_val(mmti0259vo.getA_i_o_c_r_rqst_dsky_val());
		}
		if (!StringUtil.isEmpty(mmti0259vo.getDtcn_cgnt_rt())) {
			pre_mmti0259vo.setDtcn_cgnt_rt(mmti0259vo.getDtcn_cgnt_rt());
		}
		if (!StringUtil.isEmpty(mmti0259vo.getCgnt_cgnt_rt())) {
			pre_mmti0259vo.setCgnt_cgnt_rt(mmti0259vo.getCgnt_cgnt_rt());
		}
		
		pre_mmti0259vo = mileageTobeService.getMMTI0259VO(pre_mmti0259vo);
		
		String exifDt = StringUtil.nvl((String)session.getAttribute("exifDt"));
		if("0".equals(pre_mmti0259vo.getErrorCode())){
			
			pre_mmti0259vo.setExp_exca_plan_proc_dvn("1");
			pre_mmti0259vo.setPlno(pre_mmti0213vo.getPlno());
			pre_mmti0259vo = mileageTobeService.getMMTI0259VO(pre_mmti0259vo);
			/*
			ArrayList<File> files = new ArrayList<File>();
			Object[] imgfile = (Object[])session.getAttribute("imgfile");
			files.add((File) imgfile[0]);
			*/
			// ArrayList<File> files = new ArrayList<File>();
			Object[] imgfile = (Object[])session.getAttribute("imgfile");
			
			/*
			if(!StringUtil.isEmpty(pre_mmti0259vo.getPlno()) && !StringUtil.isEmpty(pre_mmti0259vo.getExp_exca_plan_no())) {
				mileageTobeService.regInfoToEdmsForMobileWeb2(exifDt, pre_mmti0213vo.getNtft_srv_rc_ormm_cd(), files, pre_mmti0259vo.getPlno() + "," + pre_mmti0259vo.getExp_exca_plan_no());
			}
			else if(!StringUtil.isEmpty(pre_mmti0259vo.getPlno()) && StringUtil.isEmpty(pre_mmti0259vo.getExp_exca_plan_no())) {
				mileageTobeService.regInfoToEdmsForMobileWeb2(exifDt, pre_mmti0213vo.getNtft_srv_rc_ormm_cd(), files, pre_mmti0259vo.getPlno());
			}
			*/
			if(!StringUtil.isEmpty(pre_mmti0259vo.getPlno()) && !StringUtil.isEmpty(pre_mmti0259vo.getExp_exca_plan_no())) {
				mbtr01001vo = mileageTobeService.regInfoToEdmsForMobileWeb2(exifDt, pre_mmti0213vo.getNtft_srv_rc_ormm_cd(), imgfile[0], pre_mmti0259vo.getPlno() + "," + pre_mmti0259vo.getExp_exca_plan_no(), mbtr01001vo);
			}
			else if(!StringUtil.isEmpty(pre_mmti0259vo.getPlno()) && StringUtil.isEmpty(pre_mmti0259vo.getExp_exca_plan_no())) {
				mbtr01001vo = mileageTobeService.regInfoToEdmsForMobileWeb2(exifDt, pre_mmti0213vo.getNtft_srv_rc_ormm_cd(), imgfile[0], pre_mmti0259vo.getPlno(), mbtr01001vo);
			}
		}
		
		int insertRow = 0;
		
		// VO SET
		mbtr01001vo.setPboxNo(pre_mmti0259vo.getPbox_no());
		mbtr01001vo.setApdxFlRutNm("");
		mbtr01001vo.setFrstIpmnEmpno("82101685");
		mbtr01001vo.setFnalAmdrEmpno("82101685");
		
		insertRow = mileageTobeService.insertTest(mbtr01001vo);
		if(insertRow < 1){
			logger.info("#### 사서함번호: " + StringUtil.nvl(mbtr01001vo.getPboxNo()) + "####");
			logger.info("#### insert 결과: Fail ####");
		}else{
			logger.info("#### insert 결과: Success ####");
		}
		
		
		/*
		// 환산주행거리
		String cnv_trv_dstc = mmti0259vo.getCnv_trv_dstc();
		// 추징환급보험료
		String adc_rtrn_prm = mmti0259vo.getAdc_rtrn_prm();
		// 추징환급구분(1:추징, 2: 환급, 3: 금액미발생)
		String adc_rtrn_dvn = mmti0259vo.getAdc_rtrn_dvn();
		session.setAttribute("new_mmti0259vo", mmti0259vo);
		session.setAttribute("cnv_trv_dstc", cnv_trv_dstc);
		session.setAttribute("adc_rtrn_prm", adc_rtrn_prm);
		session.setAttribute("adc_rtrn_dvn", adc_rtrn_dvn);
		*/
		
		// 간편정산 -> 설계보관/추징 등 아니면 다 확정요청
		if("1".equals(pre_mmti0213vo.getTrv_dstc_splc_exca_yn())) {
			if(pre_mmti0259vo.getExp_exca_plan_rsl_cd().equals("11") || pre_mmti0259vo.getExp_exca_plan_rsl_cd().equals("13")
					|| pre_mmti0259vo.getExp_exca_plan_rsl_cd().equals("14")) {
				MMTI0291VO mmti0291vo = new MMTI0291VO();
				// 정산업무처리구분(2: 확정)
				mmti0291vo.setTrv_dstc_exca_mtt__exca_bz_proc_dvn("2");
				mmti0291vo.setTrv_dstc_exca_mtt__plno(StringUtil.nvl(pre_mmti0259vo.getPlno()));
				mmti0291vo.setTrv_dstc_exca_mtt__plan_no(StringUtil.nvl(pre_mmti0259vo.getExp_exca_plan_no()));
				// 정산환급구분(1:계좌환급, 2: 갱신계약활용, 확정인 경우만 필수 이외 null) -> 수정?
				mmti0291vo.setTrv_dstc_exca_mtt__exca_rtrn_dvn("");
				// 상품출처구분(TM,CM,TD)
				mmti0291vo.setTrv_dstc_exca_mtt__pdc_sr_dvn(StringUtil.nvl(pre_mmti0259vo.getPdc_sr_dvn()));
				// 추징환급구분(1:추징, 2:환급, 3:미발생, 환급인 경우만 확정처리함)
				mmti0291vo.setTrv_dstc_exca_mtt__adc_rtrn_dvn(StringUtil.nvl(pre_mmti0259vo.getAdc_rtrn_dvn()));
				// 추징환급보험료
				mmti0291vo.setTrv_dstc_exca_mtt__adc_rtrn_prm(StringUtil.nvl(pre_mmti0259vo.getAdc_rtrn_prm()));
				// 화면처리코드(259.만기정산설계결과코드)
				mmti0291vo.setTrv_dstc_exca_mtt__scrn_proc_cd(StringUtil.nvl(pre_mmti0259vo.getExp_exca_plan_rsl_cd()));
				// 주행거리간편정산여부(1: 주행거리간편정산)
				mmti0291vo.setTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn(pre_mmti0213vo.getTrv_dstc_splc_exca_yn());
				// 사서함번호
				mmti0291vo.setTrv_dstc_exca_mtt__pbox_no(pre_mmti0213vo.getSms_ts_bvan());
				mmti0291vo = mileageTobeService.getMMTI0291VO(mmti0291vo);
				
				request.setAttribute("z_resp_cd", mmti0291vo.getZ_resp_cd());
				request.setAttribute("z_resp_msg", mmti0291vo.getZ_resp_msg());
				// 화면분기용
				session.setAttribute("z_resp_cd", mmti0291vo.getZ_resp_cd());
				session.setAttribute("z_resp_msg", mmti0291vo.getZ_resp_msg());
				
				// 이미지 중복이면 확정신청페이지
				if("1".equals(mmti0291vo.getTrv_dstc_exca_mtt__imag_dup_yn())){
					pre_mmti0259vo.setExp_exca_plan_rsl_cd("14");
				}
				
				// CM 상품이고, 화면처리코드 IN(02, 14) or 이미지 중복
				
				if("CM".equals(mmti0291vo.getTrv_dstc_exca_mtt__pdc_sr_dvn()) && 
						("02".equals(mmti0291vo.getTrv_dstc_exca_mtt__scrn_proc_cd())
						|| "14".equals(mmti0291vo.getTrv_dstc_exca_mtt__scrn_proc_cd()))){
					
					MMTI0015VO mmti0015vo = new MMTI0015VO();
					mmti0015vo.setFunt_key("00");
					mmti0015vo.setPlan_no(mmti0291vo.getTrv_dstc_exca_mtt__plan_no());
					mmti0015vo = mileageTobeService.getMMTI0015VO(mmti0015vo);
					
					logger.debug("##### MMTI0015 시작 ##########################");
					logger.debug("##### 고객식별번호: " + mmti0015vo.getPlhd__cust_dcmt_no() + " ##########################");
					logger.debug("##### 고객번호: " + mmti0015vo.getPlhd__cust_no() + " ##########################");
					logger.debug("##### 고객명: " + mmti0015vo.getPlhd__cust_nm() + " ##########################");
					logger.debug("##### 이메일: " + mmti0015vo.getPlhd__eml() + " ##########################");
					logger.debug("##### 지역번호: " + mmti0015vo.getPlhd_cntp_if__tlp_arno() + " ##########################");
					logger.debug("##### 국번호: " + mmti0015vo.getPlhd_cntp_if__tlp_ofno() + " ##########################");
					logger.debug("##### 개별번호: " + mmti0015vo.getPlhd_cntp_if__tlp_idvno() + " ##########################");
					
					XTEM0021VO xtem0021vo = new XTEM0021VO();
					xtem0021vo.setCnsl_rpt_no("");						// 상담접수번호				
					xtem0021vo.setCm_bz_dvcd("05");
					xtem0021vo.setCnsl_typ_dvcd("07");
					xtem0021vo.setCm_plan_no(mmti0291vo.getTrv_dstc_exca_mtt__plan_no());
					xtem0021vo.setCnsl_rpy_dvcd("1");
					xtem0021vo.setCnsl_rpt_dttm(getDayTime());			// 현재년월일시분초 14자리
					xtem0021vo.setCust_nm(mmti0015vo.getPlhd__cust_nm());
					xtem0021vo.setCust_no(mmti0015vo.getPlhd__cust_no());
					
					String cust_dcmt_no = SeedUtil.decrypt(mmti0015vo.getPlhd__cust_dcmt_no());
					
					if("1".equals(cust_dcmt_no.substring(6, 7)) || "2".equals(cust_dcmt_no.substring(6, 7))
						|| "5".equals(cust_dcmt_no.substring(6, 7)) || "6".equals(cust_dcmt_no.substring(6, 7))){
						xtem0021vo.setBrth("19" + cust_dcmt_no.substring(0, 6));
					} else{
						xtem0021vo.setBrth("20" + cust_dcmt_no.substring(0, 6));
					}
					// xtem0021vo.setBrth("");  							// 생년월일
					xtem0021vo.setSx_cd(cust_dcmt_no.substring(6, 7));
					xtem0021vo.setEml_adr(mmti0015vo.getPlhd__eml());
					xtem0021vo.setClp_tlcno(mmti0015vo.getPlhd_cntp_if__tlp_arno());
					xtem0021vo.setClp_ofno(mmti0015vo.getPlhd_cntp_if__tlp_ofno());
					xtem0021vo.setClp_idvno(mmti0015vo.getPlhd_cntp_if__tlp_idvno());
					xtem0021vo.setCnsl_rsvt_dt("99990101");
					xtem0021vo.setCnsl_rsvt_time_cd("1");
					xtem0021vo.setCnsl_cn("최종주행거리사진등록/만기정산");
					xtem0021vo.setCnsl_aply_csn_yn("1");
					xtem0021vo.setUrl_adr("");
					xtem0021vo.setCm_ctrmf_tpcd("32");
					xtem0021vo.setFrst_ipmn_empno("80000028");
					xtem0021vo.setFrst_ipnpt_dttm(getDayTime());		// 현재년월일시분초 14자리	
					
					xtem0021vo = mileageTobeService.getXTEM0021VO(xtem0021vo);
					logger.debug("##### XTEM0021 시작 ##########################");
					logger.debug("##### 처리결과: [ " + xtem0021vo.getProc_rtn() + " ] ##########################");
				}
				
				//MMTI0291전문 정산이력테이블(MBTT02001) 적재
				mbtt02001vo.setPboxNo(StringUtil.nvl(mmti0213vo.getSms_ts_bvan()));
				mbtt02001vo.setTlgIdVal("MMTI0291");
				mbtt02001vo.setEsbTrscId(StringUtil.nvl(mmti0291vo.getZ_trsc_id()));
				if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__plno()) || null == mmti0291vo.getTrv_dstc_exca_mtt__plno()){
					mbtt02001vo.setPlno(" ");
				} else {
					mbtt02001vo.setPlno(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__plno()));
				}
				if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__plan_no()) || null == mmti0291vo.getTrv_dstc_exca_mtt__plan_no()){
					mbtt02001vo.setPlanNo(" ");
				} else {
					mbtt02001vo.setPlanNo(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__plan_no()));
				}
				if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__rnw_plno()) || null == mmti0291vo.getTrv_dstc_exca_mtt__rnw_plno()){
					mbtt02001vo.setRnwPlno(" ");
				} else {
					mbtt02001vo.setRnwPlno(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__rnw_plno()));
				}
				mbtt02001vo.setTlgProcRslCdVal(StringUtil.nvl(mmti0291vo.getZ_tlg_sp_cd()));
				mbtt02001vo.setTlgErrCdVal(StringUtil.nvl(mmti0291vo.getZ_trns_org_dvcd())+StringUtil.nvl(mmti0291vo.getZ_trns_org_cd()));
				if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__hdlr_empno()) || null == mmti0291vo.getTrv_dstc_exca_mtt__hdlr_empno()){
					mbtt02001vo.setHdlrEmpno(" ");
				} else {
					mbtt02001vo.setHdlrEmpno(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__hdlr_empno()));
				}
				if("".equals(pre_mmti0213vo.getPbox_no_dvcd()) || null == pre_mmti0213vo.getPbox_no_dvcd()){
					mbtt02001vo.setPboxNoDvcd(" ");
				} else {
					mbtt02001vo.setPboxNoDvcd(StringUtil.nvl(pre_mmti0213vo.getPbox_no_dvcd()));
				}
				if("".equals(pre_mmti0213vo.getProc_dvn()) || null == pre_mmti0213vo.getProc_dvn()){
					mbtt02001vo.setProcDvn(" ");
				} else {
					mbtt02001vo.setProcDvn(StringUtil.nvl(pre_mmti0213vo.getProc_dvn()));
				}
				if("".equals(pre_mmti0213vo.getTrv_dstc_exp_exca_dvcd()) || null == pre_mmti0213vo.getTrv_dstc_exp_exca_dvcd()){
					mbtt02001vo.setTrvDstcExpExcaDvcd(" ");
				} else {
					mbtt02001vo.setTrvDstcExpExcaDvcd(StringUtil.nvl(pre_mmti0213vo.getTrv_dstc_exp_exca_dvcd()));
				}
				if("".equals(pre_mmti0213vo.getTrv_dstc_chng_aply_dvn()) || null == pre_mmti0213vo.getTrv_dstc_chng_aply_dvn()){
					mbtt02001vo.setTrvDstcChngAplyDvn(" ");
				} else {
					mbtt02001vo.setTrvDstcChngAplyDvn(StringUtil.nvl(pre_mmti0213vo.getTrv_dstc_chng_aply_dvn()));
				}
				if("".equals(pre_mmti0213vo.getHdlr_fire_yn()) || null == pre_mmti0213vo.getHdlr_fire_yn()){
					mbtt02001vo.setHdlrFireYn(" ");
				} else {
					mbtt02001vo.setHdlrFireYn(StringUtil.nvl(pre_mmti0213vo.getHdlr_fire_yn()));
				}
				if("".equals(pre_mmti0213vo.getMtcc_yn()) || null == pre_mmti0213vo.getMtcc_yn()){
					mbtt02001vo.setMtccYn(" ");
				} else {
					mbtt02001vo.setMtccYn(StringUtil.nvl(pre_mmti0213vo.getMtcc_yn()));
				}
				if("".equals(request.getParameter("aut_cgnt_trv_dstc")) || null == request.getParameter("aut_cgnt_trv_dstc")){
					mbtt02001vo.setAutCgntTrvDstc(0);
				} else {
					mbtt02001vo.setAutCgntTrvDstc(Double.parseDouble(request.getParameter("aut_cgnt_trv_dstc")));
				}
				if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__aut_cgnt_trv_dstc_rsl_cd()) || null == mmti0291vo.getTrv_dstc_exca_mtt__aut_cgnt_trv_dstc_rsl_cd()){
					mbtt02001vo.setAutCgntTrvDstcRslCd(" ");
				} else {
					mbtt02001vo.setAutCgntTrvDstcRslCd(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__aut_cgnt_trv_dstc_rsl_cd()));
				}
				if("".equals(request.getParameter("inptTrvDstc")) || null == request.getParameter("inptTrvDstc")){
					mbtt02001vo.setInptTrvDstc(0);
				} else {
					mbtt02001vo.setInptTrvDstc(Double.parseDouble(request.getParameter("inptTrvDstc")));
				}
				if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__cnv_trv_dstc()) || null == mmti0291vo.getTrv_dstc_exca_mtt__cnv_trv_dstc()){
					mbtt02001vo.setCnvTrvDstc(0);
				} else {
					mbtt02001vo.setCnvTrvDstc(Double.parseDouble(mmti0291vo.getTrv_dstc_exca_mtt__cnv_trv_dstc()));
				}
				if("".equals(request.getParameter("exp_exca_plan_rsl_cd")) || null == request.getParameter("exp_exca_plan_rsl_cd")){
					mbtt02001vo.setExpExcaPlanRslCd(" ");
				} else {
					mbtt02001vo.setExpExcaPlanRslCd(StringUtil.nvl(request.getParameter("exp_exca_plan_rsl_cd")));
				}
				if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__exca_bz_proc_dvn()) || null == mmti0291vo.getTrv_dstc_exca_mtt__exca_bz_proc_dvn()){
					mbtt02001vo.setExcaBzProcDvn(" ");
				} else {
					mbtt02001vo.setExcaBzProcDvn(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__exca_bz_proc_dvn()));
				}
				if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__exca_rtrn_dvn()) || null == mmti0291vo.getTrv_dstc_exca_mtt__exca_rtrn_dvn()){
					mbtt02001vo.setExcaRtrnDvn(" ");
				} else {
					mbtt02001vo.setExcaRtrnDvn(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__exca_rtrn_dvn()));
				}
				if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__pdc_sr_dvn()) || null == mmti0291vo.getTrv_dstc_exca_mtt__pdc_sr_dvn()){
					mbtt02001vo.setPdcSrDvn(" ");
				} else {
					mbtt02001vo.setPdcSrDvn(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__pdc_sr_dvn()));
				}
				if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__adc_rtrn_prm()) || null == mmti0291vo.getTrv_dstc_exca_mtt__adc_rtrn_prm()){
					mbtt02001vo.setAdcRtrnPrm(0);
				} else {
					mbtt02001vo.setAdcRtrnPrm(Double.parseDouble(mmti0291vo.getTrv_dstc_exca_mtt__adc_rtrn_prm()));
				}
				if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn()) || null == mmti0291vo.getTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn()){
					mbtt02001vo.setTrvDstcSplcExcaYn(" ");
				} else {
					mbtt02001vo.setTrvDstcSplcExcaYn(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn()));
				}
				if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__imag_dup_yn()) || null == mmti0291vo.getTrv_dstc_exca_mtt__imag_dup_yn()){
					mbtt02001vo.setImagDupYn(" ");
				} else {
					mbtt02001vo.setImagDupYn(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__imag_dup_yn()));
				}
				if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__nrm_proc_yn()) || null == mmti0291vo.getTrv_dstc_exca_mtt__nrm_proc_yn()){
					mbtt02001vo.setNrmProcYn(" ");
				} else {
					mbtt02001vo.setNrmProcYn(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__nrm_proc_yn()));
				}
				if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__crd_scn_cncl_pss_yn()) || null == mmti0291vo.getTrv_dstc_exca_mtt__crd_scn_cncl_pss_yn()){
					mbtt02001vo.setCrdScnCnclPssYn(" ");
				} else {
					mbtt02001vo.setCrdScnCnclPssYn(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__crd_scn_cncl_pss_yn()));
				}
				mbtt02001vo.setRespCn(StringUtil.nvl(mmti0291vo.getZ_resp_cd()));
				mbtt02001vo.setRslCn(scrnNm + "_" + StringUtil.nvl(mmti0291vo.getZ_resp_msg()));
				mbtt02001vo.setFrstIpmnEmpno("82101685");
				mbtt02001vo.setFnalAmdrEmpno("82101685");
				if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__adc_rtrn_dvn()) || null == mmti0291vo.getTrv_dstc_exca_mtt__adc_rtrn_dvn()){
					mbtt02001vo.setAdcRtrnDvn(" ");
				} else {
					mbtt02001vo.setAdcRtrnDvn(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__adc_rtrn_dvn()));
				}
				if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__scrn_proc_cd()) || null == mmti0291vo.getTrv_dstc_exca_mtt__scrn_proc_cd()){
					mbtt02001vo.setScrnProcCd(" ");
				} else {
					mbtt02001vo.setScrnProcCd(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__scrn_proc_cd()));
				}
				if("".equals(request.getParameter("ctc_plno")) || null == request.getParameter("ctc_plno")){
					mbtt02001vo.setCtcPlno(" ");
				} else {
					mbtt02001vo.setCtcPlno(StringUtil.nvl(request.getParameter("ctc_plno")));
				}
				if("".equals(request.getParameter("trv_dstc_proc_dvcd")) || null == request.getParameter("trv_dstc_proc_dvcd")){
					mbtt02001vo.setTrvDstcProcDvcd(" ");
				} else {
					mbtt02001vo.setTrvDstcProcDvcd(StringUtil.nvl(request.getParameter("trv_dstc_proc_dvcd")));
				}
				if("".equals(request.getParameter("mbl_snd_no")) || null == request.getParameter("mbl_snd_no")){
					mbtt02001vo.setMblSndNo(" ");
				} else {
					mbtt02001vo.setMblSndNo(StringUtil.nvl(request.getParameter("mbl_snd_no")));
				}
				if("".equals(request.getParameter("plan_plno_dvcd")) || null == request.getParameter("plan_plno_dvcd")){
					mbtt02001vo.setPlanPlnoDvcd(" ");
				} else {
					mbtt02001vo.setPlanPlnoDvcd(StringUtil.nvl(request.getParameter("plan_plno_dvcd")));
				}
				if("".equals(request.getParameter("plan_plno")) || null == request.getParameter("plan_plno")){
					mbtt02001vo.setPlanPlno(" ");
				} else {
					mbtt02001vo.setPlanPlno(StringUtil.nvl(request.getParameter("plan_plno")));
				}
				if("".equals(request.getParameter("chng_plan_no")) || null == request.getParameter("chng_plan_no")){
					mbtt02001vo.setChngPlanNo(" ");
				} else {
					mbtt02001vo.setChngPlanNo(StringUtil.nvl(request.getParameter("chng_plan_no")));
				}
				if("".equals(request.getParameter("dst_tty_dvn1")) || null == request.getParameter("dst_tty_dvn1")){
					mbtt02001vo.setDstTtyDvn1(" ");
				} else {
					mbtt02001vo.setDstTtyDvn1(StringUtil.nvl(request.getParameter("dst_tty_dvn1")));
				}
				if("".equals(request.getParameter("dst_tty_dvn2")) || null == request.getParameter("dst_tty_dvn2")){
					mbtt02001vo.setDstTtyDvn2(" ");
				} else {
					mbtt02001vo.setDstTtyDvn2(StringUtil.nvl(request.getParameter("dst_tty_dvn2")));
				}
				if("".equals(request.getParameter("dst_tty_dvn3")) || null == request.getParameter("dst_tty_dvn3")){
					mbtt02001vo.setDstTtyDvn3(" ");
				} else {
					mbtt02001vo.setDstTtyDvn3(StringUtil.nvl(request.getParameter("dst_tty_dvn3")));
				}
				if("".equals(request.getParameter("dst_tty_dvn4")) || null == request.getParameter("dst_tty_dvn4")){
					mbtt02001vo.setDstTtyDvn4(" ");
				} else {
					mbtt02001vo.setDstTtyDvn4(StringUtil.nvl(request.getParameter("dst_tty_dvn4")));
				}
				if("".equals(request.getParameter("dst_tty_dvn5")) || null == request.getParameter("dst_tty_dvn5")){
					mbtt02001vo.setDstTtyDvn5(" ");
				} else {
					mbtt02001vo.setDstTtyDvn5(StringUtil.nvl(request.getParameter("dst_tty_dvn5")));
				}
				if("".equals(request.getParameter("phgp_regt_tgt1")) || null == request.getParameter("phgp_regt_tgt1")){
					mbtt02001vo.setPhgpRegtTgt1(" ");
				} else {
					mbtt02001vo.setPhgpRegtTgt1(StringUtil.nvl(request.getParameter("phgp_regt_tgt1")));
				}
				if("".equals(request.getParameter("phgp_regt_tgt2")) || null == request.getParameter("phgp_regt_tgt2")){
					mbtt02001vo.setPhgpRegtTgt2(" ");
				} else {
					mbtt02001vo.setPhgpRegtTgt2(StringUtil.nvl(request.getParameter("phgp_regt_tgt2")));
				}
				if("".equals(request.getParameter("phgp_regt_tgt3")) || null == request.getParameter("phgp_regt_tgt3")){
					mbtt02001vo.setPhgpRegtTgt3(" ");
				} else {
					mbtt02001vo.setPhgpRegtTgt3(StringUtil.nvl(request.getParameter("phgp_regt_tgt3")));
				}
				if("".equals(request.getParameter("phgp_regt_tgt4")) || null == request.getParameter("phgp_regt_tgt4")){
					mbtt02001vo.setPhgpRegtTgt4(" ");
				} else {
					mbtt02001vo.setPhgpRegtTgt4(StringUtil.nvl(request.getParameter("phgp_regt_tgt4")));
				}
				if("".equals(request.getParameter("phgp_regt_tgt5")) || null == request.getParameter("phgp_regt_tgt5")){
					mbtt02001vo.setPhgpRegtTgt5(" ");
				} else {
					mbtt02001vo.setPhgpRegtTgt5(StringUtil.nvl(request.getParameter("phgp_regt_tgt5")));
				}
				
				//MMTI0291 insert
				insertRow = 0;
				
				logger.info("#### mileageNew05 MMTI0291 MBTT02001 before ####");
				insertRow = mileageTobeService.insertJungsanTest(mbtt02001vo);
				logger.info("#### mileageNew05 MMTI0291 MBTT02001 after ####");
				
				if(insertRow < 1){
					logger.info("#### 사서함번호: " + StringUtil.nvl(mbtt02001vo.getPboxNo()) + "####");
					logger.info("#### insert 결과: Fail ####");
				}else{
					logger.info("#### insert 결과: Success ####");
				}
			}
		}
		
		session.setAttribute("pre_mmti0213vo", pre_mmti0213vo);
		session.setAttribute("pre_mmti0259vo", pre_mmti0259vo);
		
		//MMTI0213전문 정산이력테이블(MBTT02001) 적재
		mbtt02001vo.setPboxNo(StringUtil.nvl(pre_mmti0213vo.getSms_ts_bvan()));
		mbtt02001vo.setTlgIdVal("MMTI0213");
		mbtt02001vo.setEsbTrscId(StringUtil.nvl(pre_mmti0213vo.getZ_trsc_id()));
		if("".equals(pre_mmti0213vo.getPlno()) || null == pre_mmti0213vo.getPlno()){
			mbtt02001vo.setPlno(" ");
		} else {
			mbtt02001vo.setPlno(StringUtil.nvl(pre_mmti0213vo.getPlno()));
		}
		if("".equals(pre_mmti0213vo.getPlan_no()) || null == pre_mmti0213vo.getPlan_no()){
			mbtt02001vo.setPlanNo(" ");
		} else {
			mbtt02001vo.setPlanNo(StringUtil.nvl(pre_mmti0213vo.getPlan_no()));
		}
		if("".equals(pre_mmti0213vo.getRnw_plno()) || null == pre_mmti0213vo.getRnw_plno()){
			mbtt02001vo.setRnwPlno(" ");
		} else {
			mbtt02001vo.setRnwPlno(StringUtil.nvl(pre_mmti0213vo.getRnw_plno()));
		}
		mbtt02001vo.setTlgProcRslCdVal(StringUtil.nvl(pre_mmti0213vo.getZ_tlg_sp_cd()));
		mbtt02001vo.setTlgErrCdVal(StringUtil.nvl(pre_mmti0213vo.getZ_trns_org_dvcd())+StringUtil.nvl(pre_mmti0213vo.getZ_trns_org_cd()));
		if("".equals(request.getParameter("hdlrEmpno")) || null == request.getParameter("hdlrEmpno")){
			mbtt02001vo.setHdlrEmpno(" ");
		} else {
			mbtt02001vo.setHdlrEmpno(StringUtil.nvl(request.getParameter("hdlrEmpno")));
		}
		if("".equals(pre_mmti0213vo.getPbox_no_dvcd()) || null == pre_mmti0213vo.getPbox_no_dvcd()){
			mbtt02001vo.setPboxNoDvcd(" ");
		} else {
			mbtt02001vo.setPboxNoDvcd(StringUtil.nvl(pre_mmti0213vo.getPbox_no_dvcd()));
		}
		if("".equals(pre_mmti0213vo.getProc_dvn()) || null == pre_mmti0213vo.getProc_dvn()){
			mbtt02001vo.setProcDvn(" ");
		} else {
			mbtt02001vo.setProcDvn(StringUtil.nvl(pre_mmti0213vo.getProc_dvn()));
		}
		if("".equals(pre_mmti0213vo.getTrv_dstc_exp_exca_dvcd()) || null == pre_mmti0213vo.getTrv_dstc_exp_exca_dvcd()){
			mbtt02001vo.setTrvDstcExpExcaDvcd(" ");
		} else {
			mbtt02001vo.setTrvDstcExpExcaDvcd(StringUtil.nvl(pre_mmti0213vo.getTrv_dstc_exp_exca_dvcd()));
		}
		if("".equals(pre_mmti0213vo.getTrv_dstc_chng_aply_dvn()) || null == pre_mmti0213vo.getTrv_dstc_chng_aply_dvn()){
			mbtt02001vo.setTrvDstcChngAplyDvn(" ");
		} else {
			mbtt02001vo.setTrvDstcChngAplyDvn(StringUtil.nvl(pre_mmti0213vo.getTrv_dstc_chng_aply_dvn()));
		}
		if("".equals(pre_mmti0213vo.getHdlr_fire_yn()) || null == pre_mmti0213vo.getHdlr_fire_yn()){
			mbtt02001vo.setHdlrFireYn(" ");
		} else {
			mbtt02001vo.setHdlrFireYn(StringUtil.nvl(pre_mmti0213vo.getHdlr_fire_yn()));
		}
		if("".equals(pre_mmti0213vo.getMtcc_yn()) || null == pre_mmti0213vo.getMtcc_yn()){
			mbtt02001vo.setMtccYn(" ");
		} else {
			mbtt02001vo.setMtccYn(StringUtil.nvl(pre_mmti0213vo.getMtcc_yn()));
		}
		if("".equals(request.getParameter("aut_cgnt_trv_dstc")) || null == request.getParameter("aut_cgnt_trv_dstc")){
			mbtt02001vo.setAutCgntTrvDstc(0);
		} else {
			mbtt02001vo.setAutCgntTrvDstc(Double.parseDouble(request.getParameter("aut_cgnt_trv_dstc")));
		}
		if("".equals(request.getParameter("autCgntTrvDstcRslCd")) || null == request.getParameter("autCgntTrvDstcRslCd")){
			mbtt02001vo.setAutCgntTrvDstcRslCd(" ");
		} else {
			mbtt02001vo.setAutCgntTrvDstcRslCd(StringUtil.nvl(request.getParameter("autCgntTrvDstcRslCd")));
		}
		if("".equals(request.getParameter("inptTrvDstc")) || null == request.getParameter("inptTrvDstc")){
			mbtt02001vo.setInptTrvDstc(0);
		} else {
			mbtt02001vo.setInptTrvDstc(Double.parseDouble(request.getParameter("inptTrvDstc")));
		}
		if("".equals(request.getParameter("cnv_trv_dstc")) || null == request.getParameter("cnv_trv_dstc")){
			mbtt02001vo.setCnvTrvDstc(0);
		} else {
			mbtt02001vo.setCnvTrvDstc(Double.parseDouble(request.getParameter("cnv_trv_dstc")));
		}
		if("".equals(request.getParameter("exp_exca_plan_rsl_cd")) || null == request.getParameter("exp_exca_plan_rsl_cd")){
			mbtt02001vo.setExpExcaPlanRslCd(" ");
		} else {
			mbtt02001vo.setExpExcaPlanRslCd(StringUtil.nvl(request.getParameter("exp_exca_plan_rsl_cd")));
		}
		if("".equals(request.getParameter("excaBzProcDvn")) || null == request.getParameter("excaBzProcDvn")){
			mbtt02001vo.setExcaBzProcDvn(" ");
		} else {
			mbtt02001vo.setExcaBzProcDvn(StringUtil.nvl(request.getParameter("excaBzProcDvn")));
		}
		if("".equals(request.getParameter("excaRtrnDvn")) || null == request.getParameter("excaRtrnDvn")){
			mbtt02001vo.setExcaRtrnDvn(" ");
		} else {
			mbtt02001vo.setExcaRtrnDvn(StringUtil.nvl(request.getParameter("excaRtrnPrm")));
		}
		if("".equals(request.getParameter("pdc_sr_dvn")) || null == request.getParameter("pdc_sr_dvn")){
			mbtt02001vo.setPdcSrDvn(" ");
		} else {
			mbtt02001vo.setPdcSrDvn(StringUtil.nvl(request.getParameter("pdc_sr_dvn")));
		}
		if("".equals(request.getParameter("adc_rtrn_prm")) || null == request.getParameter("adc_rtrn_prm")){
			mbtt02001vo.setAdcRtrnPrm(0);
		} else {
			mbtt02001vo.setAdcRtrnPrm(Double.parseDouble(request.getParameter("adc_rtrn_prm")));
		}
		if("".equals(request.getParameter("trvDstcSplcExcaYn")) || null == request.getParameter("trvDstcSplcExcaYn")){
			mbtt02001vo.setTrvDstcSplcExcaYn(" ");
		} else {
			mbtt02001vo.setTrvDstcSplcExcaYn(StringUtil.nvl(request.getParameter("trvDstcSplcExcaYn")));
		}
		if("".equals(request.getParameter("imagDupYn")) || null == request.getParameter("imagDupYn")){
			mbtt02001vo.setImagDupYn(" ");
		} else {
			mbtt02001vo.setImagDupYn(StringUtil.nvl(request.getParameter("imagDupYn")));
		}
		if("".equals(request.getParameter("nrmProcYn")) || null == request.getParameter("nrmProcYn")){
			mbtt02001vo.setNrmProcYn(" ");
		} else {
			mbtt02001vo.setNrmProcYn(StringUtil.nvl(request.getParameter("nrmProcYn")));
		}
		if("".equals(request.getParameter("crdScnCnclPssYn")) || null == request.getParameter("crdScnCnclPssYn")){
			mbtt02001vo.setCrdScnCnclPssYn(" ");
		} else {
			mbtt02001vo.setCrdScnCnclPssYn(StringUtil.nvl(request.getParameter("crdScnCnclPssYn")));
		}
		mbtt02001vo.setRespCn(StringUtil.nvl(pre_mmti0213vo.getZ_resp_cd()));
		mbtt02001vo.setRslCn(scrnNm + "_" + StringUtil.nvl(pre_mmti0213vo.getZ_resp_msg()));
		mbtt02001vo.setFrstIpmnEmpno("82101685");
		mbtt02001vo.setFnalAmdrEmpno("82101685");
		if("".equals(request.getParameter("adc_rtrn_dvn")) || null == request.getParameter("adc_rtrn_dvn")){
			mbtt02001vo.setAdcRtrnDvn(" ");
		} else {
			mbtt02001vo.setAdcRtrnDvn(StringUtil.nvl(request.getParameter("adc_rtrn_dvn")));
		}
		if("".equals(request.getParameter("scrn_proc_cd")) || null == request.getParameter("scrn_proc_cd")){
			mbtt02001vo.setScrnProcCd(" ");
		} else {
			mbtt02001vo.setScrnProcCd(StringUtil.nvl(request.getParameter("scrn_proc_cd")));
		}
		if("".equals(pre_mmti0213vo.getCtc_plno()) || null == pre_mmti0213vo.getCtc_plno()){
			mbtt02001vo.setCtcPlno(" ");
		} else {
			mbtt02001vo.setCtcPlno(StringUtil.nvl(pre_mmti0213vo.getCtc_plno()));
		}
		if("".equals(request.getParameter("trv_dstc_proc_dvcd")) || null == request.getParameter("trv_dstc_proc_dvcd")){
			mbtt02001vo.setTrvDstcProcDvcd(" ");
		} else {
			mbtt02001vo.setTrvDstcProcDvcd(StringUtil.nvl(request.getParameter("trv_dstc_proc_dvcd")));
		}
		if("".equals(request.getParameter("mbl_snd_no")) || null == request.getParameter("mbl_snd_no")){
			mbtt02001vo.setMblSndNo(" ");
		} else {
			mbtt02001vo.setMblSndNo(StringUtil.nvl(request.getParameter("mbl_snd_no")));
		}
		if("".equals(request.getParameter("plan_plno_dvcd")) || null == request.getParameter("plan_plno_dvcd")){
			mbtt02001vo.setPlanPlnoDvcd(" ");
		} else {
			mbtt02001vo.setPlanPlnoDvcd(StringUtil.nvl(request.getParameter("plan_plno_dvcd")));
		}
		if("".equals(request.getParameter("plan_plno")) || null == request.getParameter("plan_plno")){
			mbtt02001vo.setPlanPlno(" ");
		} else {
			mbtt02001vo.setPlanPlno(StringUtil.nvl(request.getParameter("plan_plno")));
		}
		if("".equals(pre_mmti0213vo.getChng_plan_no()) || null == pre_mmti0213vo.getChng_plan_no()){
			mbtt02001vo.setChngPlanNo(" ");
		} else {
			mbtt02001vo.setChngPlanNo(StringUtil.nvl(pre_mmti0213vo.getChng_plan_no()));
		}
		if("".equals(request.getParameter("dst_tty_dvn1")) || null == request.getParameter("dst_tty_dvn1")){
			mbtt02001vo.setDstTtyDvn1(" ");
		} else {
			mbtt02001vo.setDstTtyDvn1(StringUtil.nvl(request.getParameter("dst_tty_dvn1")));
		}
		if("".equals(request.getParameter("dst_tty_dvn2")) || null == request.getParameter("dst_tty_dvn2")){
			mbtt02001vo.setDstTtyDvn2(" ");
		} else {
			mbtt02001vo.setDstTtyDvn2(StringUtil.nvl(request.getParameter("dst_tty_dvn2")));
		}
		if("".equals(request.getParameter("dst_tty_dvn3")) || null == request.getParameter("dst_tty_dvn3")){
			mbtt02001vo.setDstTtyDvn3(" ");
		} else {
			mbtt02001vo.setDstTtyDvn3(StringUtil.nvl(request.getParameter("dst_tty_dvn3")));
		}
		if("".equals(request.getParameter("dst_tty_dvn4")) || null == request.getParameter("dst_tty_dvn4")){
			mbtt02001vo.setDstTtyDvn4(" ");
		} else {
			mbtt02001vo.setDstTtyDvn4(StringUtil.nvl(request.getParameter("dst_tty_dvn4")));
		}
		if("".equals(request.getParameter("dst_tty_dvn5")) || null == request.getParameter("dst_tty_dvn5")){
			mbtt02001vo.setDstTtyDvn5(" ");
		} else {
			mbtt02001vo.setDstTtyDvn5(StringUtil.nvl(request.getParameter("dst_tty_dvn5")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt1")) || null == request.getParameter("phgp_regt_tgt1")){
			mbtt02001vo.setPhgpRegtTgt1(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt1(StringUtil.nvl(request.getParameter("phgp_regt_tgt1")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt2")) || null == request.getParameter("phgp_regt_tgt2")){
			mbtt02001vo.setPhgpRegtTgt2(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt2(StringUtil.nvl(request.getParameter("phgp_regt_tgt2")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt3")) || null == request.getParameter("phgp_regt_tgt3")){
			mbtt02001vo.setPhgpRegtTgt3(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt3(StringUtil.nvl(request.getParameter("phgp_regt_tgt3")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt4")) || null == request.getParameter("phgp_regt_tgt4")){
			mbtt02001vo.setPhgpRegtTgt4(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt4(StringUtil.nvl(request.getParameter("phgp_regt_tgt4")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt5")) || null == request.getParameter("phgp_regt_tgt5")){
			mbtt02001vo.setPhgpRegtTgt5(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt5(StringUtil.nvl(request.getParameter("phgp_regt_tgt5")));
		}
		
		//MMTI0213 insert
		insertRow = 0;
		
		logger.info("#### mileageNew05 MMTI0213 MBTT02001 before ####");
		insertRow = mileageTobeService.insertJungsanTest(mbtt02001vo);
		logger.info("#### mileageNew05 MMTI0213 MBTT02001 after ####");
		
		if(insertRow < 1){
			logger.info("#### 사서함번호: " + StringUtil.nvl(mbtt02001vo.getPboxNo()) + "####");
			logger.info("#### insert 결과: Fail ####");
		}else{
			logger.info("#### insert 결과: Success ####");
		}
		
		//MMTI0259전문 정산이력테이블(MBTT02001) 적재
		mbtt02001vo.setPboxNo(StringUtil.nvl(pre_mmti0213vo.getSms_ts_bvan()));
		mbtt02001vo.setTlgIdVal("MMTI0259");
		mbtt02001vo.setEsbTrscId(StringUtil.nvl(pre_mmti0259vo.getZ_trsc_id()));
		if("".equals(pre_mmti0259vo.getPlno()) || null == pre_mmti0259vo.getPlno()){
			mbtt02001vo.setPlno(" ");
		} else {
			mbtt02001vo.setPlno(StringUtil.nvl(pre_mmti0259vo.getPlno()));
		}
		if("".equals(pre_mmti0213vo.getPlan_no()) || null == pre_mmti0213vo.getPlan_no()){
			mbtt02001vo.setPlanNo(" ");
		} else {
			mbtt02001vo.setPlanNo(StringUtil.nvl(pre_mmti0213vo.getPlan_no()));
		}
		if("".equals(pre_mmti0213vo.getRnw_plno()) || null == pre_mmti0213vo.getRnw_plno()){
			mbtt02001vo.setRnwPlno(" ");
		} else {
			mbtt02001vo.setRnwPlno(StringUtil.nvl(pre_mmti0213vo.getRnw_plno()));
		}
		mbtt02001vo.setTlgProcRslCdVal(StringUtil.nvl(pre_mmti0259vo.getZ_tlg_sp_cd()));
		mbtt02001vo.setTlgErrCdVal(StringUtil.nvl(pre_mmti0259vo.getZ_trns_org_dvcd())+StringUtil.nvl(pre_mmti0259vo.getZ_trns_org_cd()));
		if("".equals(request.getParameter("hdlrEmpno")) || null == request.getParameter("hdlrEmpno")){
			mbtt02001vo.setHdlrEmpno(" ");
		} else {
			mbtt02001vo.setHdlrEmpno(StringUtil.nvl(request.getParameter("hdlrEmpno")));
		}
		if("".equals(pre_mmti0213vo.getPbox_no_dvcd()) || null == pre_mmti0213vo.getPbox_no_dvcd()){
			mbtt02001vo.setPboxNoDvcd(" ");
		} else {
			mbtt02001vo.setPboxNoDvcd(StringUtil.nvl(pre_mmti0213vo.getPbox_no_dvcd()));
		}
		if("".equals(pre_mmti0213vo.getProc_dvn()) || null == pre_mmti0213vo.getProc_dvn()){
			mbtt02001vo.setProcDvn(" ");
		} else {
			mbtt02001vo.setProcDvn(StringUtil.nvl(pre_mmti0213vo.getProc_dvn()));
		}
		if("".equals(pre_mmti0213vo.getTrv_dstc_exp_exca_dvcd()) || null == pre_mmti0213vo.getTrv_dstc_exp_exca_dvcd()){
			mbtt02001vo.setTrvDstcExpExcaDvcd(" ");
		} else {
			mbtt02001vo.setTrvDstcExpExcaDvcd(StringUtil.nvl(pre_mmti0213vo.getTrv_dstc_exp_exca_dvcd()));
		}
		if("".equals(pre_mmti0213vo.getTrv_dstc_chng_aply_dvn()) || null == pre_mmti0213vo.getTrv_dstc_chng_aply_dvn()){
			mbtt02001vo.setTrvDstcChngAplyDvn(" ");
		} else {
			mbtt02001vo.setTrvDstcChngAplyDvn(StringUtil.nvl(pre_mmti0213vo.getTrv_dstc_chng_aply_dvn()));
		}
		if("".equals(pre_mmti0213vo.getHdlr_fire_yn()) || null == pre_mmti0213vo.getHdlr_fire_yn()){
			mbtt02001vo.setHdlrFireYn(" ");
		} else {
			mbtt02001vo.setHdlrFireYn(StringUtil.nvl(pre_mmti0213vo.getHdlr_fire_yn()));
		}
		if("".equals(pre_mmti0213vo.getMtcc_yn()) || null == pre_mmti0213vo.getMtcc_yn()){
			mbtt02001vo.setMtccYn(" ");
		} else {
			mbtt02001vo.setMtccYn(StringUtil.nvl(pre_mmti0213vo.getMtcc_yn()));
		}
		if("".equals(pre_mmti0259vo.getAut_cgnt_trv_dstc()) || null == pre_mmti0259vo.getAut_cgnt_trv_dstc()){
			mbtt02001vo.setAutCgntTrvDstc(0);
		} else {
			mbtt02001vo.setAutCgntTrvDstc(Double.parseDouble(pre_mmti0259vo.getAut_cgnt_trv_dstc()));
		}
		if("".equals(pre_mmti0259vo.getAut_cgnt_trv_dstc_rsl_cd()) || null == pre_mmti0259vo.getAut_cgnt_trv_dstc_rsl_cd()){
			mbtt02001vo.setAutCgntTrvDstcRslCd(" ");
		} else {
			mbtt02001vo.setAutCgntTrvDstcRslCd(StringUtil.nvl(pre_mmti0259vo.getAut_cgnt_trv_dstc_rsl_cd()));
		}
		if("".equals(pre_mmti0259vo.getInpt_trv_dstc()) || null == pre_mmti0259vo.getInpt_trv_dstc()){
			mbtt02001vo.setInptTrvDstc(0);
		} else {
			mbtt02001vo.setInptTrvDstc(Double.parseDouble(pre_mmti0259vo.getInpt_trv_dstc()));
		}
		if("".equals(pre_mmti0259vo.getCnv_trv_dstc()) || null == pre_mmti0259vo.getCnv_trv_dstc()){
			mbtt02001vo.setCnvTrvDstc(0);
		} else {
			mbtt02001vo.setCnvTrvDstc(Double.parseDouble(pre_mmti0259vo.getCnv_trv_dstc()));
		}
		if("".equals(pre_mmti0259vo.getExp_exca_plan_rsl_cd()) || null == pre_mmti0259vo.getExp_exca_plan_rsl_cd()){
			mbtt02001vo.setExpExcaPlanRslCd(" ");
		} else {
			mbtt02001vo.setExpExcaPlanRslCd(StringUtil.nvl(pre_mmti0259vo.getExp_exca_plan_rsl_cd()));
		}
		if("".equals(request.getParameter("excaBzProcDvn")) || null == request.getParameter("excaBzProcDvn")){
			mbtt02001vo.setExcaBzProcDvn(" ");
		} else {
			mbtt02001vo.setExcaBzProcDvn(StringUtil.nvl(request.getParameter("excaBzProcDvn")));
		}
		if("".equals(request.getParameter("excaRtrnDvn")) || null == request.getParameter("excaRtrnDvn")){
			mbtt02001vo.setExcaRtrnDvn(" ");
		} else {
			mbtt02001vo.setExcaRtrnDvn(StringUtil.nvl(request.getParameter("excaRtrnPrm")));
		}
		if("".equals(pre_mmti0259vo.getPdc_sr_dvn()) || null == pre_mmti0259vo.getPdc_sr_dvn()){
			mbtt02001vo.setPdcSrDvn(" ");
		} else {
			mbtt02001vo.setPdcSrDvn(StringUtil.nvl(pre_mmti0259vo.getPdc_sr_dvn()));
		}
		if("".equals(pre_mmti0259vo.getAdc_rtrn_prm()) || null == pre_mmti0259vo.getAdc_rtrn_prm()){
			mbtt02001vo.setAdcRtrnPrm(0);
		} else {
			mbtt02001vo.setAdcRtrnPrm(Double.parseDouble(pre_mmti0259vo.getAdc_rtrn_prm()));
		}
		if("".equals(request.getParameter("trvDstcSplcExcaYn")) || null == request.getParameter("trvDstcSplcExcaYn")){
			mbtt02001vo.setTrvDstcSplcExcaYn(" ");
		} else {
			mbtt02001vo.setTrvDstcSplcExcaYn(StringUtil.nvl(request.getParameter("trvDstcSplcExcaYn")));
		}
		if("".equals(request.getParameter("imagDupYn")) || null == request.getParameter("imagDupYn")){
			mbtt02001vo.setImagDupYn(" ");
		} else {
			mbtt02001vo.setImagDupYn(StringUtil.nvl(request.getParameter("imagDupYn")));
		}
		if("".equals(request.getParameter("nrmProcYn")) || null == request.getParameter("nrmProcYn")){
			mbtt02001vo.setNrmProcYn(" ");
		} else {
			mbtt02001vo.setNrmProcYn(StringUtil.nvl(request.getParameter("nrmProcYn")));
		}
		if("".equals(request.getParameter("crdScnCnclPssYn")) || null == request.getParameter("crdScnCnclPssYn")){
			mbtt02001vo.setCrdScnCnclPssYn(" ");
		} else {
			mbtt02001vo.setCrdScnCnclPssYn(StringUtil.nvl(request.getParameter("crdScnCnclPssYn")));
		}
		mbtt02001vo.setRespCn(StringUtil.nvl(pre_mmti0259vo.getZ_resp_cd()));
		mbtt02001vo.setRslCn(scrnNm + "_" + StringUtil.nvl(pre_mmti0259vo.getZ_resp_msg()));
		mbtt02001vo.setFrstIpmnEmpno("82101685");
		mbtt02001vo.setFnalAmdrEmpno("82101685");
		
		if("".equals(pre_mmti0259vo.getAdc_rtrn_dvn()) || null == pre_mmti0259vo.getAdc_rtrn_dvn()){
			mbtt02001vo.setAdcRtrnDvn(" ");
		} else {
			mbtt02001vo.setAdcRtrnDvn(StringUtil.nvl(pre_mmti0259vo.getAdc_rtrn_dvn()));
		}
		if("".equals(request.getParameter("scrn_proc_cd")) || null == request.getParameter("scrn_proc_cd")){
			mbtt02001vo.setScrnProcCd(" ");
		} else {
			mbtt02001vo.setScrnProcCd(StringUtil.nvl(request.getParameter("scrn_proc_cd")));
		}
		if("".equals(request.getParameter("ctc_plno")) || null == request.getParameter("ctc_plno")){
			mbtt02001vo.setCtcPlno(" ");
		} else {
			mbtt02001vo.setCtcPlno(StringUtil.nvl(request.getParameter("ctc_plno")));
		}
		if("".equals(request.getParameter("trv_dstc_proc_dvcd")) || null == request.getParameter("trv_dstc_proc_dvcd")){
			mbtt02001vo.setTrvDstcProcDvcd(" ");
		} else {
			mbtt02001vo.setTrvDstcProcDvcd(StringUtil.nvl(request.getParameter("trv_dstc_proc_dvcd")));
		}
		if("".equals(request.getParameter("mbl_snd_no")) || null == request.getParameter("mbl_snd_no")){
			mbtt02001vo.setMblSndNo(" ");
		} else {
			mbtt02001vo.setMblSndNo(StringUtil.nvl(request.getParameter("mbl_snd_no")));
		}
		if("".equals(request.getParameter("plan_plno_dvcd")) || null == request.getParameter("plan_plno_dvcd")){
			mbtt02001vo.setPlanPlnoDvcd(" ");
		} else {
			mbtt02001vo.setPlanPlnoDvcd(StringUtil.nvl(request.getParameter("plan_plno_dvcd")));
		}
		if("".equals(request.getParameter("plan_plno")) || null == request.getParameter("plan_plno")){
			mbtt02001vo.setPlanPlno(" ");
		} else {
			mbtt02001vo.setPlanPlno(StringUtil.nvl(request.getParameter("plan_plno")));
		}
		if("".equals(request.getParameter("chng_plan_no")) || null == request.getParameter("chng_plan_no")){
			mbtt02001vo.setChngPlanNo(" ");
		} else {
			mbtt02001vo.setChngPlanNo(StringUtil.nvl(request.getParameter("chng_plan_no")));
		}
		if("".equals(request.getParameter("dst_tty_dvn1")) || null == request.getParameter("dst_tty_dvn1")){
			mbtt02001vo.setDstTtyDvn1(" ");
		} else {
			mbtt02001vo.setDstTtyDvn1(StringUtil.nvl(request.getParameter("dst_tty_dvn1")));
		}
		if("".equals(request.getParameter("dst_tty_dvn2")) || null == request.getParameter("dst_tty_dvn2")){
			mbtt02001vo.setDstTtyDvn2(" ");
		} else {
			mbtt02001vo.setDstTtyDvn2(StringUtil.nvl(request.getParameter("dst_tty_dvn2")));
		}
		if("".equals(request.getParameter("dst_tty_dvn3")) || null == request.getParameter("dst_tty_dvn3")){
			mbtt02001vo.setDstTtyDvn3(" ");
		} else {
			mbtt02001vo.setDstTtyDvn3(StringUtil.nvl(request.getParameter("dst_tty_dvn3")));
		}
		if("".equals(request.getParameter("dst_tty_dvn4")) || null == request.getParameter("dst_tty_dvn4")){
			mbtt02001vo.setDstTtyDvn4(" ");
		} else {
			mbtt02001vo.setDstTtyDvn4(StringUtil.nvl(request.getParameter("dst_tty_dvn4")));
		}
		if("".equals(request.getParameter("dst_tty_dvn5")) || null == request.getParameter("dst_tty_dvn5")){
			mbtt02001vo.setDstTtyDvn5(" ");
		} else {
			mbtt02001vo.setDstTtyDvn5(StringUtil.nvl(request.getParameter("dst_tty_dvn5")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt1")) || null == request.getParameter("phgp_regt_tgt1")){
			mbtt02001vo.setPhgpRegtTgt1(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt1(StringUtil.nvl(request.getParameter("phgp_regt_tgt1")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt2")) || null == request.getParameter("phgp_regt_tgt2")){
			mbtt02001vo.setPhgpRegtTgt2(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt2(StringUtil.nvl(request.getParameter("phgp_regt_tgt2")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt3")) || null == request.getParameter("phgp_regt_tgt3")){
			mbtt02001vo.setPhgpRegtTgt3(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt3(StringUtil.nvl(request.getParameter("phgp_regt_tgt3")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt4")) || null == request.getParameter("phgp_regt_tgt4")){
			mbtt02001vo.setPhgpRegtTgt4(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt4(StringUtil.nvl(request.getParameter("phgp_regt_tgt4")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt5")) || null == request.getParameter("phgp_regt_tgt5")){
			mbtt02001vo.setPhgpRegtTgt5(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt5(StringUtil.nvl(request.getParameter("phgp_regt_tgt5")));
		}
		
		//MMTI0259 insert
		insertRow = 0;
		
		logger.info("#### mileageNew05 MMTI0259 MBTT02001 before ####");
		insertRow = mileageTobeService.insertJungsanTest(mbtt02001vo);
		logger.info("#### mileageNew05 MMTI0259 MBTT02001 after ####");
		
		if(insertRow < 1){
			logger.info("#### 사서함번호: " + StringUtil.nvl(mbtt02001vo.getPboxNo()) + "####");
			logger.info("#### insert 결과: Fail ####");
		}else{
			logger.info("#### insert 결과: Success ####");
		}
		
		//MMTI0305전문 정산이력테이블(MBTT02001) 적재
		mbtt02001vo.setPboxNo(StringUtil.nvl(pre_mmti0213vo.getSms_ts_bvan()));
		mbtt02001vo.setTlgIdVal("MMTI0305");
		mbtt02001vo.setEsbTrscId(StringUtil.nvl(mmti0305vo.getZ_trsc_id()));
		if("".equals(mmti0305vo.getSrch_cnd__plno()) || null == mmti0305vo.getSrch_cnd__plno()){
			mbtt02001vo.setPlno(" ");
		} else {
			mbtt02001vo.setPlno(StringUtil.nvl(mmti0305vo.getSrch_cnd__plno()));
		}
		if("".equals(mmti0305vo.getSrch_cnd__plan_no()) || null == mmti0305vo.getSrch_cnd__plan_no()){
			mbtt02001vo.setPlanNo(" ");
		} else {
			mbtt02001vo.setPlanNo(StringUtil.nvl(mmti0305vo.getSrch_cnd__plan_no()));
		}
		if("".equals(request.getParameter("rnwPlno")) || null == request.getParameter("rnwPlno")){
			mbtt02001vo.setRnwPlno(" ");
		} else {
			mbtt02001vo.setRnwPlno(StringUtil.nvl(request.getParameter("rnwPlno")));
		}
		mbtt02001vo.setTlgProcRslCdVal(StringUtil.nvl(mmti0305vo.getZ_tlg_sp_cd()));
		mbtt02001vo.setTlgErrCdVal(StringUtil.nvl(mmti0305vo.getZ_trns_org_dvcd())+StringUtil.nvl(mmti0305vo.getZ_trns_org_cd()));
		if("".equals(mmti0305vo.getSrch_cnd__hdlr_empno()) || null == mmti0305vo.getSrch_cnd__hdlr_empno()){
			mbtt02001vo.setHdlrEmpno(" ");
		} else {
			mbtt02001vo.setHdlrEmpno(StringUtil.nvl(mmti0305vo.getSrch_cnd__hdlr_empno()));
		}
		if("".equals(mmti0305vo.getSrch_rsl__pbox_no()) || null == mmti0305vo.getSrch_rsl__pbox_no()){
			mbtt02001vo.setPboxNoDvcd(" ");
		} else {
			mbtt02001vo.setPboxNoDvcd(StringUtil.nvl("1"));
		}
		if("".equals(mmti0305vo.getSrch_cnd__proc_dvn()) || null == mmti0305vo.getSrch_cnd__proc_dvn()){
			mbtt02001vo.setProcDvn(" ");
		} else {
			mbtt02001vo.setProcDvn(StringUtil.nvl(mmti0305vo.getSrch_cnd__proc_dvn()));
		}
		if("".equals(request.getParameter("trvDstcExpExcaDvcd")) || null == request.getParameter("trvDstcExpExcaDvcd")){
			mbtt02001vo.setTrvDstcExpExcaDvcd(" ");
		} else {
			mbtt02001vo.setTrvDstcExpExcaDvcd(StringUtil.nvl(request.getParameter("trvDstcExpExcaDvcd")));
		}
		if("".equals(request.getParameter("trvDstcChngAplyDvn")) || null == request.getParameter("trvDstcChngAplyDvn")){
			mbtt02001vo.setTrvDstcChngAplyDvn(" ");
		} else {
			mbtt02001vo.setTrvDstcChngAplyDvn(StringUtil.nvl(request.getParameter("trvDstcChngAplyDvn")));
		}
		if("".equals(request.getParameter("hdlrFireYn")) || null == request.getParameter("hdlrFireYn")){
			mbtt02001vo.setHdlrFireYn(" ");
		} else {
			mbtt02001vo.setHdlrFireYn(StringUtil.nvl(request.getParameter("hdlrFireYn")));
		}
		if("".equals(request.getParameter("mtccYn")) || null == request.getParameter("mtccYn")){
			mbtt02001vo.setMtccYn(" ");
		} else {
			mbtt02001vo.setMtccYn(StringUtil.nvl(request.getParameter("mtccYn")));
		}
		mbtt02001vo.setAutCgntTrvDstc(0);
		if("".equals(request.getParameter("autCgntTrvDstcRslCd")) || null == request.getParameter("autCgntTrvDstcRslCd")){
			mbtt02001vo.setAutCgntTrvDstcRslCd(" ");
		} else {
			mbtt02001vo.setAutCgntTrvDstcRslCd(StringUtil.nvl(request.getParameter("autCgntTrvDstcRslCd")));
		}
		mbtt02001vo.setInptTrvDstc(0);
		mbtt02001vo.setCnvTrvDstc(0);
		if("".equals(request.getParameter("exp_exca_plan_rsl_cd")) || null == request.getParameter("exp_exca_plan_rsl_cd")){
			mbtt02001vo.setExpExcaPlanRslCd(" ");
		} else {
			mbtt02001vo.setExpExcaPlanRslCd(StringUtil.nvl(request.getParameter("exp_exca_plan_rsl_cd")));
		}
		if("".equals(request.getParameter("excaBzProcDvn")) || null == request.getParameter("excaBzProcDvn")){
			mbtt02001vo.setExcaBzProcDvn(" ");
		} else {
			mbtt02001vo.setExcaBzProcDvn(StringUtil.nvl(request.getParameter("excaBzProcDvn")));
		}
		if("".equals(request.getParameter("excaRtrnDvn")) || null == request.getParameter("excaRtrnDvn")){
			mbtt02001vo.setExcaRtrnDvn(" ");
		} else {
			mbtt02001vo.setExcaRtrnDvn(StringUtil.nvl(request.getParameter("excaRtrnDvn")));
		}
		if("".equals(request.getParameter("pdcSrDvn")) || null == request.getParameter("pdcSrDvn")){
			mbtt02001vo.setPdcSrDvn(" ");
		} else {
			mbtt02001vo.setPdcSrDvn(StringUtil.nvl(request.getParameter("pdcSrDvn")));
		}
		mbtt02001vo.setAdcRtrnPrm(0);
		if("".equals(request.getParameter("trvDstcSplcExcaYn")) || null == request.getParameter("trvDstcSplcExcaYn")){
			mbtt02001vo.setTrvDstcSplcExcaYn(" ");
		} else {
			mbtt02001vo.setTrvDstcSplcExcaYn(StringUtil.nvl(request.getParameter("trvDstcSplcExcaYn")));
		}
		if("".equals(request.getParameter("imagDupYn")) || null == request.getParameter("imagDupYn")){
			mbtt02001vo.setImagDupYn(" ");
		} else {
			mbtt02001vo.setImagDupYn(StringUtil.nvl(request.getParameter("imagDupYn")));
		}
		if("".equals(request.getParameter("nrmProcYn")) || null == request.getParameter("nrmProcYn")){
			mbtt02001vo.setNrmProcYn(" ");
		} else {
			mbtt02001vo.setNrmProcYn(StringUtil.nvl(request.getParameter("nrmProcYn")));
		}
		if("".equals(request.getParameter("crdScnCnclPssYn")) || null == request.getParameter("crdScnCnclPssYn")){
			mbtt02001vo.setCrdScnCnclPssYn(" ");
		} else {
			mbtt02001vo.setCrdScnCnclPssYn(StringUtil.nvl(request.getParameter("crdScnCnclPssYn")));
		}
		mbtt02001vo.setRespCn(StringUtil.nvl(mmti0305vo.getZ_resp_cd()));
		mbtt02001vo.setRslCn(scrnNm + "_" + StringUtil.nvl(mmti0305vo.getZ_resp_msg()));
		mbtt02001vo.setFrstIpmnEmpno("82101685");
		mbtt02001vo.setFnalAmdrEmpno("82101685");		
		if("".equals(request.getParameter("adc_rtrn_dvn")) || null == request.getParameter("adc_rtrn_dvn")){
			mbtt02001vo.setAdcRtrnDvn(" ");
		} else {
			mbtt02001vo.setAdcRtrnDvn(StringUtil.nvl(request.getParameter("adc_rtrn_dvn")));
		}
		if("".equals(request.getParameter("scrn_proc_cd")) || null == request.getParameter("scrn_proc_cd")){
			mbtt02001vo.setScrnProcCd(" ");
		} else {
			mbtt02001vo.setScrnProcCd(StringUtil.nvl(request.getParameter("scrn_proc_cd")));
		}
		if("".equals(request.getParameter("ctc_plno")) || null == request.getParameter("ctc_plno")){
			mbtt02001vo.setCtcPlno(" ");
		} else {
			mbtt02001vo.setCtcPlno(StringUtil.nvl(request.getParameter("ctc_plno")));
		}
		if("".equals(request.getParameter("trv_dstc_proc_dvcd")) || null == request.getParameter("trv_dstc_proc_dvcd")){
			mbtt02001vo.setTrvDstcProcDvcd(" ");
		} else {
			mbtt02001vo.setTrvDstcProcDvcd(StringUtil.nvl(request.getParameter("trv_dstc_proc_dvcd")));
		}
		if("".equals(request.getParameter("mbl_snd_no")) || null == request.getParameter("mbl_snd_no")){
			mbtt02001vo.setMblSndNo(" ");
		} else {
			mbtt02001vo.setMblSndNo(StringUtil.nvl(request.getParameter("mbl_snd_no")));
		}
		if("".equals(request.getParameter("plan_plno_dvcd")) || null == request.getParameter("plan_plno_dvcd")){
			mbtt02001vo.setPlanPlnoDvcd(" ");
		} else {
			mbtt02001vo.setPlanPlnoDvcd(StringUtil.nvl(request.getParameter("plan_plno_dvcd")));
		}
		if("".equals(request.getParameter("plan_plno")) || null == request.getParameter("plan_plno")){
			mbtt02001vo.setPlanPlno(" ");
		} else {
			mbtt02001vo.setPlanPlno(StringUtil.nvl(request.getParameter("plan_plno")));
		}
		if("".equals(request.getParameter("chng_plan_no")) || null == request.getParameter("chng_plan_no")){
			mbtt02001vo.setChngPlanNo(" ");
		} else {
			mbtt02001vo.setChngPlanNo(StringUtil.nvl(request.getParameter("chng_plan_no")));
		}
		if("".equals(request.getParameter("dst_tty_dvn1")) || null == request.getParameter("dst_tty_dvn1")){
			mbtt02001vo.setDstTtyDvn1(" ");
		} else {
			mbtt02001vo.setDstTtyDvn1(StringUtil.nvl(request.getParameter("dst_tty_dvn1")));
		}
		if("".equals(request.getParameter("dst_tty_dvn2")) || null == request.getParameter("dst_tty_dvn2")){
			mbtt02001vo.setDstTtyDvn2(" ");
		} else {
			mbtt02001vo.setDstTtyDvn2(StringUtil.nvl(request.getParameter("dst_tty_dvn2")));
		}
		if("".equals(request.getParameter("dst_tty_dvn3")) || null == request.getParameter("dst_tty_dvn3")){
			mbtt02001vo.setDstTtyDvn3(" ");
		} else {
			mbtt02001vo.setDstTtyDvn3(StringUtil.nvl(request.getParameter("dst_tty_dvn3")));
		}
		if("".equals(request.getParameter("dst_tty_dvn4")) || null == request.getParameter("dst_tty_dvn4")){
			mbtt02001vo.setDstTtyDvn4(" ");
		} else {
			mbtt02001vo.setDstTtyDvn4(StringUtil.nvl(request.getParameter("dst_tty_dvn4")));
		}
		if("".equals(request.getParameter("dst_tty_dvn5")) || null == request.getParameter("dst_tty_dvn5")){
			mbtt02001vo.setDstTtyDvn5(" ");
		} else {
			mbtt02001vo.setDstTtyDvn5(StringUtil.nvl(request.getParameter("dst_tty_dvn5")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt1")) || null == request.getParameter("phgp_regt_tgt1")){
			mbtt02001vo.setPhgpRegtTgt1(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt1(StringUtil.nvl(request.getParameter("phgp_regt_tgt1")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt2")) || null == request.getParameter("phgp_regt_tgt2")){
			mbtt02001vo.setPhgpRegtTgt2(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt2(StringUtil.nvl(request.getParameter("phgp_regt_tgt2")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt3")) || null == request.getParameter("phgp_regt_tgt3")){
			mbtt02001vo.setPhgpRegtTgt3(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt3(StringUtil.nvl(request.getParameter("phgp_regt_tgt3")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt4")) || null == request.getParameter("phgp_regt_tgt4")){
			mbtt02001vo.setPhgpRegtTgt4(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt4(StringUtil.nvl(request.getParameter("phgp_regt_tgt4")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt5")) || null == request.getParameter("phgp_regt_tgt5")){
			mbtt02001vo.setPhgpRegtTgt5(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt5(StringUtil.nvl(request.getParameter("phgp_regt_tgt5")));
		}
		
		//MMTI0305 insert
		insertRow = 0;
		
		logger.info("#### mileageNew05 MMTI0305 MBTT02001 before ####");
		insertRow = mileageTobeService.insertJungsanTest(mbtt02001vo);
		logger.info("#### mileageNew05 MMTI0305 MBTT02001 after ####");
		
		if(insertRow < 1){
			logger.info("#### 사서함번호: " + StringUtil.nvl(mbtt02001vo.getPboxNo()) + "####");
			logger.info("#### insert 결과: Fail ####");
		}else{
			logger.info("#### insert 결과: Success ####");
		}
		
		map.put("resultCode", pre_mmti0259vo.getErrorCode());
		
		return map;
	}
	
	@RequestMapping(value="/mileageNew05go")
	public String mileageNew05go(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		return "/counter/carrider/tobe/mileageNew05";
	}
	
	// 계좌번호 입력 선택 시
	@RequestMapping(value="/mileageNew06A")
	public String mileageNew06A(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		
		HttpSession session = request.getSession();
		MMTI0213VO pre_mmti0213vo = new MMTI0213VO();
		MMTI0259VO pre_mmti0259vo = new MMTI0259VO();
		pre_mmti0213vo = (MMTI0213VO) session.getAttribute("pre_mmti0213vo");
		pre_mmti0259vo = (MMTI0259VO) session.getAttribute("pre_mmti0259vo");
		
		String gubun = request.getParameter("gubun");
		request.setAttribute("gubun", gubun);
		
		MBTT02001VO mbtt02001vo = new MBTT02001VO();
		String scrnNm = "mileageNew06A";
		int insertRow = 0;
		
		if("3".equals(gubun)) {
			MMTI0291VO mmti0291vo = new MMTI0291VO();
			
			mmti0291vo.setTrv_dstc_exca_mtt__exca_bz_proc_dvn("2");
			mmti0291vo.setTrv_dstc_exca_mtt__plno(pre_mmti0259vo.getPlno());
			mmti0291vo.setTrv_dstc_exca_mtt__plan_no(pre_mmti0259vo.getExp_exca_plan_no());
			// 정산환급구분(1: 계좌환급)
			mmti0291vo.setTrv_dstc_exca_mtt__exca_rtrn_dvn("1");
			mmti0291vo.setTrv_dstc_exca_mtt__pdc_sr_dvn(pre_mmti0259vo.getPdc_sr_dvn());
			mmti0291vo.setTrv_dstc_exca_mtt__scrn_proc_cd(pre_mmti0259vo.getExp_exca_plan_rsl_cd());
			
			// 키패드
			String account = "";
			try {
				account = TransKey.decode("account", request);
			}
			catch(Exception e) {
				logger.debug(e.getMessage());
				account = request.getParameter("account");
			}
			logger.debug("account: " + account);
			mmti0291vo.setTrv_dstc_exca_mtt__bank_cd(request.getParameter("bank"));
			mmti0291vo.setTrv_dstc_exca_mtt__acc_no(account);
			// 키패드
			
			mmti0291vo.setTrv_dstc_exca_mtt__adc_rtrn_dvn(pre_mmti0259vo.getAdc_rtrn_dvn());
			mmti0291vo.setTrv_dstc_exca_mtt__adc_rtrn_prm(pre_mmti0259vo.getAdc_rtrn_prm());
			mmti0291vo.setTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn(pre_mmti0213vo.getTrv_dstc_splc_exca_yn());
			mmti0291vo.setTrv_dstc_exca_mtt__pbox_no(pre_mmti0213vo.getSms_ts_bvan());
			mmti0291vo = mileageTobeService.getMMTI0291VO(mmti0291vo);
			
			
			// 부적정/중복 이미지인 경우 화면처리코드 02 
			if("1".equals(mmti0291vo.getTrv_dstc_exca_mtt__imag_dup_yn())){
				mmti0291vo.setTrv_dstc_exca_mtt__scrn_proc_cd("02");
			}
			session.setAttribute("mmti0291vo", mmti0291vo);
			
			// CM 상품이고, 화면처리코드 IN(02, 14) or 이미지 중복
			
			if("CM".equals(mmti0291vo.getTrv_dstc_exca_mtt__pdc_sr_dvn()) && 
					("02".equals(mmti0291vo.getTrv_dstc_exca_mtt__scrn_proc_cd())
					|| "14".equals(mmti0291vo.getTrv_dstc_exca_mtt__scrn_proc_cd()))){
				
				MMTI0015VO mmti0015vo = new MMTI0015VO();
				mmti0015vo.setFunt_key("00");
				mmti0015vo.setPlan_no(mmti0291vo.getTrv_dstc_exca_mtt__plan_no());
				mmti0015vo = mileageTobeService.getMMTI0015VO(mmti0015vo);
				
				logger.debug("##### MMTI0015 시작 ##########################");
				logger.debug("##### 고객식별번호: " + mmti0015vo.getPlhd__cust_dcmt_no() + " ##########################");
				logger.debug("##### 고객번호: " + mmti0015vo.getPlhd__cust_no() + " ##########################");
				logger.debug("##### 고객명: " + mmti0015vo.getPlhd__cust_nm() + " ##########################");
				logger.debug("##### 이메일: " + mmti0015vo.getPlhd__eml() + " ##########################");
				logger.debug("##### 지역번호: " + mmti0015vo.getPlhd_cntp_if__tlp_arno() + " ##########################");
				logger.debug("##### 국번호: " + mmti0015vo.getPlhd_cntp_if__tlp_ofno() + " ##########################");
				logger.debug("##### 개별번호: " + mmti0015vo.getPlhd_cntp_if__tlp_idvno() + " ##########################");
				
				XTEM0021VO xtem0021vo = new XTEM0021VO();
				xtem0021vo.setCnsl_rpt_no("");						// 상담접수번호				
				xtem0021vo.setCm_bz_dvcd("05");
				xtem0021vo.setCnsl_typ_dvcd("07");
				xtem0021vo.setCm_plan_no(mmti0291vo.getTrv_dstc_exca_mtt__plan_no());
				xtem0021vo.setCnsl_rpy_dvcd("1");
				xtem0021vo.setCnsl_rpt_dttm(getDayTime());			// 현재년월일시분초 14자리
				xtem0021vo.setCust_nm(mmti0015vo.getPlhd__cust_nm());
				xtem0021vo.setCust_no(mmti0015vo.getPlhd__cust_no());
				
				String cust_dcmt_no = SeedUtil.decrypt(mmti0015vo.getPlhd__cust_dcmt_no());
				
				if("1".equals(cust_dcmt_no.substring(6, 7)) || "2".equals(cust_dcmt_no.substring(6, 7))
					|| "5".equals(cust_dcmt_no.substring(6, 7)) || "6".equals(cust_dcmt_no.substring(6, 7))){
					xtem0021vo.setBrth("19" + cust_dcmt_no.substring(0, 6));
				} else{
					xtem0021vo.setBrth("20" + cust_dcmt_no.substring(0, 6));
				}
				// xtem0021vo.setBrth("");  							// 생년월일
				xtem0021vo.setSx_cd(cust_dcmt_no.substring(6, 7));
				xtem0021vo.setEml_adr(mmti0015vo.getPlhd__eml());
				xtem0021vo.setClp_tlcno(mmti0015vo.getPlhd_cntp_if__tlp_arno());
				xtem0021vo.setClp_ofno(mmti0015vo.getPlhd_cntp_if__tlp_ofno());
				xtem0021vo.setClp_idvno(mmti0015vo.getPlhd_cntp_if__tlp_idvno());
				xtem0021vo.setCnsl_rsvt_dt("99990101");
				xtem0021vo.setCnsl_rsvt_time_cd("1");
				xtem0021vo.setCnsl_cn("최종주행거리사진등록/만기정산");
				xtem0021vo.setCnsl_aply_csn_yn("1");
				xtem0021vo.setUrl_adr("");
				xtem0021vo.setCm_ctrmf_tpcd("32");
				xtem0021vo.setFrst_ipmn_empno("80000028");
				xtem0021vo.setFrst_ipnpt_dttm(getDayTime());		// 현재년월일시분초 14자리	
				
				xtem0021vo = mileageTobeService.getXTEM0021VO(xtem0021vo);
				logger.debug("##### XTEM0021 시작 ##########################");
				logger.debug("##### 처리결과: [ " + xtem0021vo.getProc_rtn() + " ] ##########################");
			}
			
			//MMTI0291전문 정산이력테이블(MBTT02001) 적재
			mbtt02001vo.setPboxNo(StringUtil.nvl(pre_mmti0213vo.getSms_ts_bvan()));
			mbtt02001vo.setTlgIdVal("MMTI0291");
			mbtt02001vo.setEsbTrscId(StringUtil.nvl(mmti0291vo.getZ_trsc_id()));
			if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__plno()) || null == mmti0291vo.getTrv_dstc_exca_mtt__plno()){
				mbtt02001vo.setPlno(" ");
			} else {
				mbtt02001vo.setPlno(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__plno()));
			}
			if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__plan_no()) || null == mmti0291vo.getTrv_dstc_exca_mtt__plan_no()){
				mbtt02001vo.setPlanNo(" ");
			} else {
				mbtt02001vo.setPlanNo(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__plan_no()));
			}
			if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__rnw_plno()) || null == mmti0291vo.getTrv_dstc_exca_mtt__rnw_plno()){
				mbtt02001vo.setRnwPlno(" ");
			} else {
				mbtt02001vo.setRnwPlno(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__rnw_plno()));
			}
			mbtt02001vo.setTlgProcRslCdVal(StringUtil.nvl(mmti0291vo.getZ_tlg_sp_cd()));
			mbtt02001vo.setTlgErrCdVal(StringUtil.nvl(mmti0291vo.getZ_trns_org_dvcd())+StringUtil.nvl(mmti0291vo.getZ_trns_org_cd()));
			if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__hdlr_empno()) || null == mmti0291vo.getTrv_dstc_exca_mtt__hdlr_empno()){
				mbtt02001vo.setHdlrEmpno(" ");
			} else {
				mbtt02001vo.setHdlrEmpno(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__hdlr_empno()));
			}
			if("".equals(request.getParameter("pboxNoDvcd")) || null == request.getParameter("pboxNoDvcd")){
				mbtt02001vo.setPboxNoDvcd(" ");
			} else {
				mbtt02001vo.setPboxNoDvcd(StringUtil.nvl(request.getParameter("pboxNoDvcd")));
			}
			if("".equals(request.getParameter("procDvn")) || null == request.getParameter("procDvn")){
				mbtt02001vo.setProcDvn(" ");
			} else {
				mbtt02001vo.setProcDvn(StringUtil.nvl(request.getParameter("procDvn")));
			}
			if("".equals(request.getParameter("trvDstcExpExcaDvcd")) || null == request.getParameter("trvDstcExpExcaDvcd")){
				mbtt02001vo.setTrvDstcExpExcaDvcd(" ");
			} else {
				mbtt02001vo.setTrvDstcExpExcaDvcd(StringUtil.nvl(request.getParameter("trvDstcExpExcaDvcd")));
			}
			if("".equals(request.getParameter("trvDstcChngAplyDvn")) || null == request.getParameter("trvDstcChngAplyDvn")){
				mbtt02001vo.setTrvDstcChngAplyDvn(" ");
			} else {
				mbtt02001vo.setTrvDstcChngAplyDvn(StringUtil.nvl(request.getParameter("trvDstcChngAplyDvn")));
			}
			if("".equals(request.getParameter("hdlrFireYn")) || null == request.getParameter("hdlrFireYn")){
				mbtt02001vo.setHdlrFireYn(" ");
			} else {
				mbtt02001vo.setHdlrFireYn(StringUtil.nvl(request.getParameter("hdlrFireYn")));
			}
			if("".equals(request.getParameter("mtccYn")) || null == request.getParameter("mtccYn")){
				mbtt02001vo.setMtccYn(" ");
			} else {
				mbtt02001vo.setMtccYn(StringUtil.nvl(request.getParameter("mtccYn")));
			}
			if("".equals(request.getParameter("aut_cgnt_trv_dstc")) || null == request.getParameter("aut_cgnt_trv_dstc")){
				mbtt02001vo.setAutCgntTrvDstc(0);
			} else {
				mbtt02001vo.setAutCgntTrvDstc(Double.parseDouble(request.getParameter("aut_cgnt_trv_dstc")));
			}
			if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__aut_cgnt_trv_dstc_rsl_cd()) || null == mmti0291vo.getTrv_dstc_exca_mtt__aut_cgnt_trv_dstc_rsl_cd()){
				mbtt02001vo.setAutCgntTrvDstcRslCd(" ");
			} else {
				mbtt02001vo.setAutCgntTrvDstcRslCd(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__aut_cgnt_trv_dstc_rsl_cd()));
			}
			if("".equals(request.getParameter("inptTrvDstc")) || null == request.getParameter("inptTrvDstc")){
				mbtt02001vo.setInptTrvDstc(0);
			} else {
				mbtt02001vo.setInptTrvDstc(Double.parseDouble(request.getParameter("inptTrvDstc")));
			}
			if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__cnv_trv_dstc()) || null == mmti0291vo.getTrv_dstc_exca_mtt__cnv_trv_dstc()){
				mbtt02001vo.setCnvTrvDstc(0);
			} else {
				mbtt02001vo.setCnvTrvDstc(Double.parseDouble(mmti0291vo.getTrv_dstc_exca_mtt__cnv_trv_dstc()));
			}
			if("".equals(request.getParameter("exp_exca_plan_rsl_cd")) || null == request.getParameter("exp_exca_plan_rsl_cd")){
				mbtt02001vo.setExpExcaPlanRslCd(" ");
			} else {
				mbtt02001vo.setExpExcaPlanRslCd(StringUtil.nvl(request.getParameter("exp_exca_plan_rsl_cd")));
			}
			if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__exca_bz_proc_dvn()) || null == mmti0291vo.getTrv_dstc_exca_mtt__exca_bz_proc_dvn()){
				mbtt02001vo.setExcaBzProcDvn(" ");
			} else {
				mbtt02001vo.setExcaBzProcDvn(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__exca_bz_proc_dvn()));
			}
			if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__exca_rtrn_dvn()) || null == mmti0291vo.getTrv_dstc_exca_mtt__exca_rtrn_dvn()){
				mbtt02001vo.setExcaRtrnDvn(" ");
			} else {
				mbtt02001vo.setExcaRtrnDvn(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__exca_rtrn_dvn()));
			}
			if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__pdc_sr_dvn()) || null == mmti0291vo.getTrv_dstc_exca_mtt__pdc_sr_dvn()){
				mbtt02001vo.setPdcSrDvn(" ");
			} else {
				mbtt02001vo.setPdcSrDvn(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__pdc_sr_dvn()));
			}
			if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__adc_rtrn_prm()) || null == mmti0291vo.getTrv_dstc_exca_mtt__adc_rtrn_prm()){
				mbtt02001vo.setAdcRtrnPrm(0);
			} else {
				mbtt02001vo.setAdcRtrnPrm(Double.parseDouble(mmti0291vo.getTrv_dstc_exca_mtt__adc_rtrn_prm()));
			}
			if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn()) || null == mmti0291vo.getTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn()){
				mbtt02001vo.setTrvDstcSplcExcaYn(" ");
			} else {
				mbtt02001vo.setTrvDstcSplcExcaYn(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn()));
			}
			if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__imag_dup_yn()) || null == mmti0291vo.getTrv_dstc_exca_mtt__imag_dup_yn()){
				mbtt02001vo.setImagDupYn(" ");
			} else {
				mbtt02001vo.setImagDupYn(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__imag_dup_yn()));
			}
			if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__nrm_proc_yn()) || null == mmti0291vo.getTrv_dstc_exca_mtt__nrm_proc_yn()){
				mbtt02001vo.setNrmProcYn(" ");
			} else {
				mbtt02001vo.setNrmProcYn(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__nrm_proc_yn()));
			}
			if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__crd_scn_cncl_pss_yn()) || null == mmti0291vo.getTrv_dstc_exca_mtt__crd_scn_cncl_pss_yn()){
				mbtt02001vo.setCrdScnCnclPssYn(" ");
			} else {
				mbtt02001vo.setCrdScnCnclPssYn(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__crd_scn_cncl_pss_yn()));
			}
			mbtt02001vo.setRespCn(StringUtil.nvl(mmti0291vo.getZ_resp_cd()));
			mbtt02001vo.setRslCn(scrnNm + "_" + StringUtil.nvl(mmti0291vo.getZ_resp_msg()));
			mbtt02001vo.setFrstIpmnEmpno("82101685");
			mbtt02001vo.setFnalAmdrEmpno("82101685");
			if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__adc_rtrn_dvn()) || null == mmti0291vo.getTrv_dstc_exca_mtt__adc_rtrn_dvn()){
				mbtt02001vo.setAdcRtrnDvn(" ");
			} else {
				mbtt02001vo.setAdcRtrnDvn(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__adc_rtrn_dvn()));
			}
			if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__scrn_proc_cd()) || null == mmti0291vo.getTrv_dstc_exca_mtt__scrn_proc_cd()){
				mbtt02001vo.setScrnProcCd(" ");
			} else {
				mbtt02001vo.setScrnProcCd(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__scrn_proc_cd()));
			}
			if("".equals(request.getParameter("ctc_plno")) || null == request.getParameter("ctc_plno")){
				mbtt02001vo.setCtcPlno(" ");
			} else {
				mbtt02001vo.setCtcPlno(StringUtil.nvl(request.getParameter("ctc_plno")));
			}
			if("".equals(request.getParameter("trv_dstc_proc_dvcd")) || null == request.getParameter("trv_dstc_proc_dvcd")){
				mbtt02001vo.setTrvDstcProcDvcd(" ");
			} else {
				mbtt02001vo.setTrvDstcProcDvcd(StringUtil.nvl(request.getParameter("trv_dstc_proc_dvcd")));
			}
			if("".equals(request.getParameter("mbl_snd_no")) || null == request.getParameter("mbl_snd_no")){
				mbtt02001vo.setMblSndNo(" ");
			} else {
				mbtt02001vo.setMblSndNo(StringUtil.nvl(request.getParameter("mbl_snd_no")));
			}
			if("".equals(request.getParameter("plan_plno_dvcd")) || null == request.getParameter("plan_plno_dvcd")){
				mbtt02001vo.setPlanPlnoDvcd(" ");
			} else {
				mbtt02001vo.setPlanPlnoDvcd(StringUtil.nvl(request.getParameter("plan_plno_dvcd")));
			}
			if("".equals(request.getParameter("plan_plno")) || null == request.getParameter("plan_plno")){
				mbtt02001vo.setPlanPlno(" ");
			} else {
				mbtt02001vo.setPlanPlno(StringUtil.nvl(request.getParameter("plan_plno")));
			}
			if("".equals(request.getParameter("chng_plan_no")) || null == request.getParameter("chng_plan_no")){
				mbtt02001vo.setChngPlanNo(" ");
			} else {
				mbtt02001vo.setChngPlanNo(StringUtil.nvl(request.getParameter("chng_plan_no")));
			}
			if("".equals(request.getParameter("dst_tty_dvn1")) || null == request.getParameter("dst_tty_dvn1")){
				mbtt02001vo.setDstTtyDvn1(" ");
			} else {
				mbtt02001vo.setDstTtyDvn1(StringUtil.nvl(request.getParameter("dst_tty_dvn1")));
			}
			if("".equals(request.getParameter("dst_tty_dvn2")) || null == request.getParameter("dst_tty_dvn2")){
				mbtt02001vo.setDstTtyDvn2(" ");
			} else {
				mbtt02001vo.setDstTtyDvn2(StringUtil.nvl(request.getParameter("dst_tty_dvn2")));
			}
			if("".equals(request.getParameter("dst_tty_dvn3")) || null == request.getParameter("dst_tty_dvn3")){
				mbtt02001vo.setDstTtyDvn3(" ");
			} else {
				mbtt02001vo.setDstTtyDvn3(StringUtil.nvl(request.getParameter("dst_tty_dvn3")));
			}
			if("".equals(request.getParameter("dst_tty_dvn4")) || null == request.getParameter("dst_tty_dvn4")){
				mbtt02001vo.setDstTtyDvn4(" ");
			} else {
				mbtt02001vo.setDstTtyDvn4(StringUtil.nvl(request.getParameter("dst_tty_dvn4")));
			}
			if("".equals(request.getParameter("dst_tty_dvn5")) || null == request.getParameter("dst_tty_dvn5")){
				mbtt02001vo.setDstTtyDvn5(" ");
			} else {
				mbtt02001vo.setDstTtyDvn5(StringUtil.nvl(request.getParameter("dst_tty_dvn5")));
			}
			if("".equals(request.getParameter("phgp_regt_tgt1")) || null == request.getParameter("phgp_regt_tgt1")){
				mbtt02001vo.setPhgpRegtTgt1(" ");
			} else {
				mbtt02001vo.setPhgpRegtTgt1(StringUtil.nvl(request.getParameter("phgp_regt_tgt1")));
			}
			if("".equals(request.getParameter("phgp_regt_tgt2")) || null == request.getParameter("phgp_regt_tgt2")){
				mbtt02001vo.setPhgpRegtTgt2(" ");
			} else {
				mbtt02001vo.setPhgpRegtTgt2(StringUtil.nvl(request.getParameter("phgp_regt_tgt2")));
			}
			if("".equals(request.getParameter("phgp_regt_tgt3")) || null == request.getParameter("phgp_regt_tgt3")){
				mbtt02001vo.setPhgpRegtTgt3(" ");
			} else {
				mbtt02001vo.setPhgpRegtTgt3(StringUtil.nvl(request.getParameter("phgp_regt_tgt3")));
			}
			if("".equals(request.getParameter("phgp_regt_tgt4")) || null == request.getParameter("phgp_regt_tgt4")){
				mbtt02001vo.setPhgpRegtTgt4(" ");
			} else {
				mbtt02001vo.setPhgpRegtTgt4(StringUtil.nvl(request.getParameter("phgp_regt_tgt4")));
			}
			if("".equals(request.getParameter("phgp_regt_tgt5")) || null == request.getParameter("phgp_regt_tgt5")){
				mbtt02001vo.setPhgpRegtTgt5(" ");
			} else {
				mbtt02001vo.setPhgpRegtTgt5(StringUtil.nvl(request.getParameter("phgp_regt_tgt5")));
			}
			
			//MMTI0291 insert
			insertRow = 0;
			
			logger.info("#### mileageNew06A MMTI0291 MBTT02001 before ####");
			insertRow = mileageTobeService.insertJungsanTest(mbtt02001vo);
			logger.info("#### mileageNew06A MMTI0291 MBTT02001 after ####");
			
			if(insertRow < 1){
				logger.info("#### 사서함번호: " + StringUtil.nvl(mbtt02001vo.getPboxNo()) + "####");
				logger.info("#### insert 결과: Fail ####");
			}else{
				logger.info("#### insert 결과: Success ####");
			}
		}
		
		//MMTI0213전문 정산이력테이블(MBTT02001) 적재
		mbtt02001vo.setPboxNo(StringUtil.nvl(pre_mmti0213vo.getSms_ts_bvan()));
		mbtt02001vo.setTlgIdVal("MMTI0213");
		mbtt02001vo.setEsbTrscId(StringUtil.nvl(pre_mmti0213vo.getZ_trsc_id()));
		if("".equals(pre_mmti0213vo.getPlno()) || null == pre_mmti0213vo.getPlno()){
			mbtt02001vo.setPlno(" ");
		} else {
			mbtt02001vo.setPlno(StringUtil.nvl(pre_mmti0213vo.getPlno()));
		}
		if("".equals(pre_mmti0213vo.getPlan_no()) || null == pre_mmti0213vo.getPlan_no()){
			mbtt02001vo.setPlanNo(" ");
		} else {
			mbtt02001vo.setPlanNo(StringUtil.nvl(pre_mmti0213vo.getPlan_no()));
		}
		if("".equals(pre_mmti0213vo.getRnw_plno()) || null == pre_mmti0213vo.getRnw_plno()){
			mbtt02001vo.setRnwPlno(" ");
		} else {
			mbtt02001vo.setRnwPlno(StringUtil.nvl(pre_mmti0213vo.getRnw_plno()));
		}
		mbtt02001vo.setTlgProcRslCdVal(StringUtil.nvl(pre_mmti0213vo.getZ_tlg_sp_cd()));
		mbtt02001vo.setTlgErrCdVal(StringUtil.nvl(pre_mmti0213vo.getZ_trns_org_dvcd())+StringUtil.nvl(pre_mmti0213vo.getZ_trns_org_cd()));
		if("".equals(request.getParameter("hdlrEmpno")) || null == request.getParameter("hdlrEmpno")){
			mbtt02001vo.setHdlrEmpno(" ");
		} else {
			mbtt02001vo.setHdlrEmpno(StringUtil.nvl(request.getParameter("hdlrEmpno")));
		}
		if("".equals(pre_mmti0213vo.getPbox_no_dvcd()) || null == pre_mmti0213vo.getPbox_no_dvcd()){
			mbtt02001vo.setPboxNoDvcd(" ");
		} else {
			mbtt02001vo.setPboxNoDvcd(StringUtil.nvl(pre_mmti0213vo.getPbox_no_dvcd()));
		}
		if("".equals(pre_mmti0213vo.getProc_dvn()) || null == pre_mmti0213vo.getProc_dvn()){
			mbtt02001vo.setProcDvn(" ");
		} else {
			mbtt02001vo.setProcDvn(StringUtil.nvl(pre_mmti0213vo.getProc_dvn()));
		}
		if("".equals(pre_mmti0213vo.getTrv_dstc_exp_exca_dvcd()) || null == pre_mmti0213vo.getTrv_dstc_exp_exca_dvcd()){
			mbtt02001vo.setTrvDstcExpExcaDvcd(" ");
		} else {
			mbtt02001vo.setTrvDstcExpExcaDvcd(StringUtil.nvl(pre_mmti0213vo.getTrv_dstc_exp_exca_dvcd()));
		}
		if("".equals(pre_mmti0213vo.getTrv_dstc_chng_aply_dvn()) || null == pre_mmti0213vo.getTrv_dstc_chng_aply_dvn()){
			mbtt02001vo.setTrvDstcChngAplyDvn(" ");
		} else {
			mbtt02001vo.setTrvDstcChngAplyDvn(StringUtil.nvl(pre_mmti0213vo.getTrv_dstc_chng_aply_dvn()));
		}
		if("".equals(pre_mmti0213vo.getHdlr_fire_yn()) || null == pre_mmti0213vo.getHdlr_fire_yn()){
			mbtt02001vo.setHdlrFireYn(" ");
		} else {
			mbtt02001vo.setHdlrFireYn(StringUtil.nvl(pre_mmti0213vo.getHdlr_fire_yn()));
		}
		if("".equals(pre_mmti0213vo.getMtcc_yn()) || null == pre_mmti0213vo.getMtcc_yn()){
			mbtt02001vo.setMtccYn(" ");
		} else {
			mbtt02001vo.setMtccYn(StringUtil.nvl(pre_mmti0213vo.getMtcc_yn()));
		}
		if("".equals(request.getParameter("aut_cgnt_trv_dstc")) || null == request.getParameter("aut_cgnt_trv_dstc")){
			mbtt02001vo.setAutCgntTrvDstc(0);
		} else {
			mbtt02001vo.setAutCgntTrvDstc(Double.parseDouble(request.getParameter("aut_cgnt_trv_dstc")));
		}
		if("".equals(request.getParameter("autCgntTrvDstcRslCd")) || null == request.getParameter("autCgntTrvDstcRslCd")){
			mbtt02001vo.setAutCgntTrvDstcRslCd(" ");
		} else {
			mbtt02001vo.setAutCgntTrvDstcRslCd(StringUtil.nvl(request.getParameter("autCgntTrvDstcRslCd")));
		}
		if("".equals(request.getParameter("inptTrvDstc")) || null == request.getParameter("inptTrvDstc")){
			mbtt02001vo.setInptTrvDstc(0);
		} else {
			mbtt02001vo.setInptTrvDstc(Double.parseDouble(request.getParameter("inptTrvDstc")));
		}
		if("".equals(request.getParameter("cnv_trv_dstc")) || null == request.getParameter("cnv_trv_dstc")){
			mbtt02001vo.setCnvTrvDstc(0);
		} else {
			mbtt02001vo.setCnvTrvDstc(Double.parseDouble(request.getParameter("cnv_trv_dstc")));
		}
		if("".equals(request.getParameter("exp_exca_plan_rsl_cd")) || null == request.getParameter("exp_exca_plan_rsl_cd")){
			mbtt02001vo.setExpExcaPlanRslCd(" ");
		} else {
			mbtt02001vo.setExpExcaPlanRslCd(StringUtil.nvl(request.getParameter("exp_exca_plan_rsl_cd")));
		}
		if("".equals(request.getParameter("excaBzProcDvn")) || null == request.getParameter("excaBzProcDvn")){
			mbtt02001vo.setExcaBzProcDvn(" ");
		} else {
			mbtt02001vo.setExcaBzProcDvn(StringUtil.nvl(request.getParameter("excaBzProcDvn")));
		}
		if("".equals(request.getParameter("excaRtrnDvn")) || null == request.getParameter("excaRtrnDvn")){
			mbtt02001vo.setExcaRtrnDvn(" ");
		} else {
			mbtt02001vo.setExcaRtrnDvn(StringUtil.nvl(request.getParameter("excaRtrnPrm")));
		}
		if("".equals(request.getParameter("pdc_sr_dvn")) || null == request.getParameter("pdc_sr_dvn")){
			mbtt02001vo.setPdcSrDvn(" ");
		} else {
			mbtt02001vo.setPdcSrDvn(StringUtil.nvl(request.getParameter("pdc_sr_dvn")));
		}
		if("".equals(request.getParameter("adc_rtrn_prm")) || null == request.getParameter("adc_rtrn_prm")){
			mbtt02001vo.setAdcRtrnPrm(0);
		} else {
			mbtt02001vo.setAdcRtrnPrm(Double.parseDouble(request.getParameter("adc_rtrn_prm")));
		}
		if("".equals(request.getParameter("trvDstcSplcExcaYn")) || null == request.getParameter("trvDstcSplcExcaYn")){
			mbtt02001vo.setTrvDstcSplcExcaYn(" ");
		} else {
			mbtt02001vo.setTrvDstcSplcExcaYn(StringUtil.nvl(request.getParameter("trvDstcSplcExcaYn")));
		}
		if("".equals(request.getParameter("imagDupYn")) || null == request.getParameter("imagDupYn")){
			mbtt02001vo.setImagDupYn(" ");
		} else {
			mbtt02001vo.setImagDupYn(StringUtil.nvl(request.getParameter("imagDupYn")));
		}
		if("".equals(request.getParameter("nrmProcYn")) || null == request.getParameter("nrmProcYn")){
			mbtt02001vo.setNrmProcYn(" ");
		} else {
			mbtt02001vo.setNrmProcYn(StringUtil.nvl(request.getParameter("nrmProcYn")));
		}
		if("".equals(request.getParameter("crdScnCnclPssYn")) || null == request.getParameter("crdScnCnclPssYn")){
			mbtt02001vo.setCrdScnCnclPssYn(" ");
		} else {
			mbtt02001vo.setCrdScnCnclPssYn(StringUtil.nvl(request.getParameter("crdScnCnclPssYn")));
		}
		mbtt02001vo.setRespCn(StringUtil.nvl(pre_mmti0213vo.getZ_resp_cd()));
		mbtt02001vo.setRslCn(scrnNm + "_" + StringUtil.nvl(pre_mmti0213vo.getZ_resp_msg()));
		mbtt02001vo.setFrstIpmnEmpno("82101685");
		mbtt02001vo.setFnalAmdrEmpno("82101685");
		if("".equals(request.getParameter("adc_rtrn_dvn")) || null == request.getParameter("adc_rtrn_dvn")){
			mbtt02001vo.setAdcRtrnDvn(" ");
		} else {
			mbtt02001vo.setAdcRtrnDvn(StringUtil.nvl(request.getParameter("adc_rtrn_dvn")));
		}
		if("".equals(request.getParameter("scrn_proc_cd")) || null == request.getParameter("scrn_proc_cd")){
			mbtt02001vo.setScrnProcCd(" ");
		} else {
			mbtt02001vo.setScrnProcCd(StringUtil.nvl(request.getParameter("scrn_proc_cd")));
		}
		if("".equals(pre_mmti0213vo.getCtc_plno()) || null == pre_mmti0213vo.getCtc_plno()){
			mbtt02001vo.setCtcPlno(" ");
		} else {
			mbtt02001vo.setCtcPlno(StringUtil.nvl(pre_mmti0213vo.getCtc_plno()));
		}
		if("".equals(request.getParameter("trv_dstc_proc_dvcd")) || null == request.getParameter("trv_dstc_proc_dvcd")){
			mbtt02001vo.setTrvDstcProcDvcd(" ");
		} else {
			mbtt02001vo.setTrvDstcProcDvcd(StringUtil.nvl(request.getParameter("trv_dstc_proc_dvcd")));
		}
		if("".equals(request.getParameter("mbl_snd_no")) || null == request.getParameter("mbl_snd_no")){
			mbtt02001vo.setMblSndNo(" ");
		} else {
			mbtt02001vo.setMblSndNo(StringUtil.nvl(request.getParameter("mbl_snd_no")));
		}
		if("".equals(request.getParameter("plan_plno_dvcd")) || null == request.getParameter("plan_plno_dvcd")){
			mbtt02001vo.setPlanPlnoDvcd(" ");
		} else {
			mbtt02001vo.setPlanPlnoDvcd(StringUtil.nvl(request.getParameter("plan_plno_dvcd")));
		}
		if("".equals(request.getParameter("plan_plno")) || null == request.getParameter("plan_plno")){
			mbtt02001vo.setPlanPlno(" ");
		} else {
			mbtt02001vo.setPlanPlno(StringUtil.nvl(request.getParameter("plan_plno")));
		}
		if("".equals(pre_mmti0213vo.getChng_plan_no()) || null == pre_mmti0213vo.getChng_plan_no()){
			mbtt02001vo.setChngPlanNo(" ");
		} else {
			mbtt02001vo.setChngPlanNo(StringUtil.nvl(pre_mmti0213vo.getChng_plan_no()));
		}
		if("".equals(request.getParameter("dst_tty_dvn1")) || null == request.getParameter("dst_tty_dvn1")){
			mbtt02001vo.setDstTtyDvn1(" ");
		} else {
			mbtt02001vo.setDstTtyDvn1(StringUtil.nvl(request.getParameter("dst_tty_dvn1")));
		}
		if("".equals(request.getParameter("dst_tty_dvn2")) || null == request.getParameter("dst_tty_dvn2")){
			mbtt02001vo.setDstTtyDvn2(" ");
		} else {
			mbtt02001vo.setDstTtyDvn2(StringUtil.nvl(request.getParameter("dst_tty_dvn2")));
		}
		if("".equals(request.getParameter("dst_tty_dvn3")) || null == request.getParameter("dst_tty_dvn3")){
			mbtt02001vo.setDstTtyDvn3(" ");
		} else {
			mbtt02001vo.setDstTtyDvn3(StringUtil.nvl(request.getParameter("dst_tty_dvn3")));
		}
		if("".equals(request.getParameter("dst_tty_dvn4")) || null == request.getParameter("dst_tty_dvn4")){
			mbtt02001vo.setDstTtyDvn4(" ");
		} else {
			mbtt02001vo.setDstTtyDvn4(StringUtil.nvl(request.getParameter("dst_tty_dvn4")));
		}
		if("".equals(request.getParameter("dst_tty_dvn5")) || null == request.getParameter("dst_tty_dvn5")){
			mbtt02001vo.setDstTtyDvn5(" ");
		} else {
			mbtt02001vo.setDstTtyDvn5(StringUtil.nvl(request.getParameter("dst_tty_dvn5")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt1")) || null == request.getParameter("phgp_regt_tgt1")){
			mbtt02001vo.setPhgpRegtTgt1(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt1(StringUtil.nvl(request.getParameter("phgp_regt_tgt1")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt2")) || null == request.getParameter("phgp_regt_tgt2")){
			mbtt02001vo.setPhgpRegtTgt2(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt2(StringUtil.nvl(request.getParameter("phgp_regt_tgt2")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt3")) || null == request.getParameter("phgp_regt_tgt3")){
			mbtt02001vo.setPhgpRegtTgt3(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt3(StringUtil.nvl(request.getParameter("phgp_regt_tgt3")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt4")) || null == request.getParameter("phgp_regt_tgt4")){
			mbtt02001vo.setPhgpRegtTgt4(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt4(StringUtil.nvl(request.getParameter("phgp_regt_tgt4")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt5")) || null == request.getParameter("phgp_regt_tgt5")){
			mbtt02001vo.setPhgpRegtTgt5(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt5(StringUtil.nvl(request.getParameter("phgp_regt_tgt5")));
		}
		
		//MMTI0213 insert
		insertRow = 0;
		
		logger.info("#### mlieageNew06A MMTI0213 MBTT02001 before ####");
		insertRow = mileageTobeService.insertJungsanTest(mbtt02001vo);
		logger.info("#### mlieageNew06A MMTI0213 MBTT02001 after ####");
		
		if(insertRow < 1){
			logger.info("#### 사서함번호: " + StringUtil.nvl(mbtt02001vo.getPboxNo()) + "####");
			logger.info("#### insert 결과: Fail ####");
		}else{
			logger.info("#### insert 결과: Success ####");
		}
		
		return "/counter/carrider/tobe/mileageNew06A";
	}
	
	// 갱신보험료 차감 선택 시
	@RequestMapping(value="/mileageNew06B")
	public String mileageNew06B(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		
		HttpSession session = request.getSession();
		session.setAttribute("renewal", "01");
		
		return "/counter/carrider/tobe/mileageNew06B";
	}
	
	// 갱신보험료 차감
	@RequestMapping(value="/mileageNew06B2")
	public String mileageNew06B2(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
	
		HttpSession session = request.getSession();
		MMTI0213VO pre_mmti0213vo = new MMTI0213VO();
		MMTI0259VO pre_mmti0259vo = new MMTI0259VO();
		MMTI0291VO mmti0291vo = new MMTI0291VO();
		
		MBTT02001VO mbtt02001vo = new MBTT02001VO();
		String scrnNm = "mileageNew06B2";
		
		pre_mmti0213vo = (MMTI0213VO)session.getAttribute("pre_mmti0213vo");
		pre_mmti0259vo = (MMTI0259VO)session.getAttribute("pre_mmti0259vo");
		
		mmti0291vo.setTrv_dstc_exca_mtt__exca_bz_proc_dvn("2");													// 정산업무처리구분 2:확정
		mmti0291vo.setTrv_dstc_exca_mtt__plno(pre_mmti0259vo.getPlno());										// 증권번호
		mmti0291vo.setTrv_dstc_exca_mtt__plan_no(pre_mmti0259vo.getExp_exca_plan_no());							// 설계번호
		mmti0291vo.setTrv_dstc_exca_mtt__exca_rtrn_dvn("2");													// 갱신환급구분 2:갱신계약활용
		mmti0291vo.setTrv_dstc_exca_mtt__pdc_sr_dvn(pre_mmti0259vo.getPdc_sr_dvn());							// 상품출처구분
		mmti0291vo.setTrv_dstc_exca_mtt__scrn_proc_cd(pre_mmti0259vo.getExp_exca_plan_rsl_cd());				// 화면처리코드
		mmti0291vo.setTrv_dstc_exca_mtt__adc_rtrn_dvn(pre_mmti0259vo.getAdc_rtrn_dvn());						// 추징환급구분
		mmti0291vo.setTrv_dstc_exca_mtt__adc_rtrn_prm(pre_mmti0259vo.getAdc_rtrn_prm());						// 추징환급보험료
		mmti0291vo.setTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn(pre_mmti0213vo.getTrv_dstc_splc_exca_yn());		// 주행거리간편정산여부
		mmti0291vo.setTrv_dstc_exca_mtt__pbox_no(pre_mmti0213vo.getSms_ts_bvan());								// 사서함번호
		mmti0291vo = mileageTobeService.getMMTI0291VO(mmti0291vo);
		
		// 미환급대체 완료화면 CM상품 분기용
		session.setAttribute("sr_dvn", mmti0291vo.getTrv_dstc_exca_mtt__pdc_sr_dvn());
		
		// 부적정/중복 이미지인 경우 화면처리코드 02 
		if("1".equals(mmti0291vo.getTrv_dstc_exca_mtt__imag_dup_yn())){
			mmti0291vo.setTrv_dstc_exca_mtt__scrn_proc_cd("02");
		}
		session.setAttribute("mmti0291vo", mmti0291vo);
		
		// CM 상품이고, 화면처리코드 IN(02, 14) or 이미지 중복
		
		if("CM".equals(mmti0291vo.getTrv_dstc_exca_mtt__pdc_sr_dvn()) && 
				("02".equals(mmti0291vo.getTrv_dstc_exca_mtt__scrn_proc_cd())
				|| "14".equals(mmti0291vo.getTrv_dstc_exca_mtt__scrn_proc_cd()))){
			
			MMTI0015VO mmti0015vo = new MMTI0015VO();
			mmti0015vo.setFunt_key("00");
			mmti0015vo.setPlan_no(mmti0291vo.getTrv_dstc_exca_mtt__plan_no());
			mmti0015vo = mileageTobeService.getMMTI0015VO(mmti0015vo);
			
			logger.debug("##### MMTI0015 시작 ##########################");
			logger.debug("##### 고객식별번호: " + mmti0015vo.getPlhd__cust_dcmt_no() + " ##########################");
			logger.debug("##### 고객번호: " + mmti0015vo.getPlhd__cust_no() + " ##########################");
			logger.debug("##### 고객명: " + mmti0015vo.getPlhd__cust_nm() + " ##########################");
			logger.debug("##### 이메일: " + mmti0015vo.getPlhd__eml() + " ##########################");
			logger.debug("##### 지역번호: " + mmti0015vo.getPlhd_cntp_if__tlp_arno() + " ##########################");
			logger.debug("##### 국번호: " + mmti0015vo.getPlhd_cntp_if__tlp_ofno() + " ##########################");
			logger.debug("##### 개별번호: " + mmti0015vo.getPlhd_cntp_if__tlp_idvno() + " ##########################");
			
			XTEM0021VO xtem0021vo = new XTEM0021VO();
			xtem0021vo.setCnsl_rpt_no("");						// 상담접수번호				
			xtem0021vo.setCm_bz_dvcd("05");
			xtem0021vo.setCnsl_typ_dvcd("07");
			xtem0021vo.setCm_plan_no(mmti0291vo.getTrv_dstc_exca_mtt__plan_no());
			xtem0021vo.setCnsl_rpy_dvcd("1");
			xtem0021vo.setCnsl_rpt_dttm(getDayTime());			// 현재년월일시분초 14자리
			xtem0021vo.setCust_nm(mmti0015vo.getPlhd__cust_nm());
			xtem0021vo.setCust_no(mmti0015vo.getPlhd__cust_no());
			
			String cust_dcmt_no = SeedUtil.decrypt(mmti0015vo.getPlhd__cust_dcmt_no());
			
			if("1".equals(cust_dcmt_no.substring(6, 7)) || "2".equals(cust_dcmt_no.substring(6, 7))
				|| "5".equals(cust_dcmt_no.substring(6, 7)) || "6".equals(cust_dcmt_no.substring(6, 7))){
				xtem0021vo.setBrth("19" + cust_dcmt_no.substring(0, 6));
			} else{
				xtem0021vo.setBrth("20" + cust_dcmt_no.substring(0, 6));
			}
			xtem0021vo.setSx_cd(cust_dcmt_no.substring(6, 7));
			xtem0021vo.setEml_adr(mmti0015vo.getPlhd__eml());
			xtem0021vo.setClp_tlcno(mmti0015vo.getPlhd_cntp_if__tlp_arno());
			xtem0021vo.setClp_ofno(mmti0015vo.getPlhd_cntp_if__tlp_ofno());
			xtem0021vo.setClp_idvno(mmti0015vo.getPlhd_cntp_if__tlp_idvno());
			xtem0021vo.setCnsl_rsvt_dt("99990101");
			xtem0021vo.setCnsl_rsvt_time_cd("1");
			xtem0021vo.setCnsl_cn("최종주행거리사진등록/만기정산");
			xtem0021vo.setCnsl_aply_csn_yn("1");
			xtem0021vo.setUrl_adr("");
			xtem0021vo.setCm_ctrmf_tpcd("32");
			xtem0021vo.setFrst_ipmn_empno("80000028");
			xtem0021vo.setFrst_ipnpt_dttm(getDayTime());		// 현재년월일시분초 14자리	
			
			xtem0021vo = mileageTobeService.getXTEM0021VO(xtem0021vo);
			logger.debug("##### XTEM0021 시작 ##########################");
			logger.debug("##### 처리결과: [ " + xtem0021vo.getProc_rtn() + " ] ##########################");
		}
		
		//MMTI0291전문 정산이력테이블(MBTT02001) 적재
		mbtt02001vo.setPboxNo(StringUtil.nvl(pre_mmti0213vo.getSms_ts_bvan()));
		mbtt02001vo.setTlgIdVal("MMTI0291");
		mbtt02001vo.setEsbTrscId(StringUtil.nvl(mmti0291vo.getZ_trsc_id()));
		if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__plno()) || null == mmti0291vo.getTrv_dstc_exca_mtt__plno()){
			mbtt02001vo.setPlno(" ");
		} else {
			mbtt02001vo.setPlno(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__plno()));
		}
		if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__plan_no()) || null == mmti0291vo.getTrv_dstc_exca_mtt__plan_no()){
			mbtt02001vo.setPlanNo(" ");
		} else {
			mbtt02001vo.setPlanNo(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__plan_no()));
		}
		if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__rnw_plno()) || null == mmti0291vo.getTrv_dstc_exca_mtt__rnw_plno()){
			mbtt02001vo.setRnwPlno(" ");
		} else {
			mbtt02001vo.setRnwPlno(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__rnw_plno()));
		}
		mbtt02001vo.setTlgProcRslCdVal(StringUtil.nvl(mmti0291vo.getZ_tlg_sp_cd()));
		mbtt02001vo.setTlgErrCdVal(StringUtil.nvl(mmti0291vo.getZ_trns_org_dvcd())+StringUtil.nvl(mmti0291vo.getZ_trns_org_cd()));
		if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__hdlr_empno()) || null == mmti0291vo.getTrv_dstc_exca_mtt__hdlr_empno()){
			mbtt02001vo.setHdlrEmpno(" ");
		} else {
			mbtt02001vo.setHdlrEmpno(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__hdlr_empno()));
		}
		if("".equals(pre_mmti0213vo.getPbox_no_dvcd()) || null == pre_mmti0213vo.getPbox_no_dvcd()){
			mbtt02001vo.setPboxNoDvcd(" ");
		} else {
			mbtt02001vo.setPboxNoDvcd(StringUtil.nvl(pre_mmti0213vo.getPbox_no_dvcd()));
		}
		if("".equals(pre_mmti0213vo.getProc_dvn()) || null == pre_mmti0213vo.getProc_dvn()){
			mbtt02001vo.setProcDvn(" ");
		} else {
			mbtt02001vo.setProcDvn(StringUtil.nvl(pre_mmti0213vo.getProc_dvn()));
		}
		if("".equals(pre_mmti0213vo.getTrv_dstc_exp_exca_dvcd()) || null == pre_mmti0213vo.getTrv_dstc_exp_exca_dvcd()){
			mbtt02001vo.setTrvDstcExpExcaDvcd(" ");
		} else {
			mbtt02001vo.setTrvDstcExpExcaDvcd(StringUtil.nvl(pre_mmti0213vo.getTrv_dstc_exp_exca_dvcd()));
		}
		if("".equals(pre_mmti0213vo.getTrv_dstc_chng_aply_dvn()) || null == pre_mmti0213vo.getTrv_dstc_chng_aply_dvn()){
			mbtt02001vo.setTrvDstcChngAplyDvn(" ");
		} else {
			mbtt02001vo.setTrvDstcChngAplyDvn(StringUtil.nvl(pre_mmti0213vo.getTrv_dstc_chng_aply_dvn()));
		}
		if("".equals(pre_mmti0213vo.getHdlr_fire_yn()) || null == pre_mmti0213vo.getHdlr_fire_yn()){
			mbtt02001vo.setHdlrFireYn(" ");
		} else {
			mbtt02001vo.setHdlrFireYn(StringUtil.nvl(pre_mmti0213vo.getHdlr_fire_yn()));
		}
		if("".equals(pre_mmti0213vo.getMtcc_yn()) || null == pre_mmti0213vo.getMtcc_yn()){
			mbtt02001vo.setMtccYn(" ");
		} else {
			mbtt02001vo.setMtccYn(StringUtil.nvl(pre_mmti0213vo.getMtcc_yn()));
		}
		if("".equals(request.getParameter("aut_cgnt_trv_dstc")) || null == request.getParameter("aut_cgnt_trv_dstc")){
			mbtt02001vo.setAutCgntTrvDstc(0);
		} else {
			mbtt02001vo.setAutCgntTrvDstc(Double.parseDouble(request.getParameter("aut_cgnt_trv_dstc")));
		}
		if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__aut_cgnt_trv_dstc_rsl_cd()) || null == mmti0291vo.getTrv_dstc_exca_mtt__aut_cgnt_trv_dstc_rsl_cd()){
			mbtt02001vo.setAutCgntTrvDstcRslCd(" ");
		} else {
			mbtt02001vo.setAutCgntTrvDstcRslCd(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__aut_cgnt_trv_dstc_rsl_cd()));
		}
		if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__cnv_trv_dstc()) || null == mmti0291vo.getTrv_dstc_exca_mtt__cnv_trv_dstc()){
			mbtt02001vo.setCnvTrvDstc(0);
		} else {
			mbtt02001vo.setCnvTrvDstc(Double.parseDouble(mmti0291vo.getTrv_dstc_exca_mtt__cnv_trv_dstc()));
		}
		if("".equals(request.getParameter("inptTrvDstc")) || null == request.getParameter("inptTrvDstc")){
			mbtt02001vo.setInptTrvDstc(0);
		} else {
			mbtt02001vo.setInptTrvDstc(Double.parseDouble(request.getParameter("inptTrvDstc")));
		}
		if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__cnv_trv_dstc()) || null == mmti0291vo.getTrv_dstc_exca_mtt__cnv_trv_dstc()){
			mbtt02001vo.setCnvTrvDstc(0);
		} else {
			mbtt02001vo.setCnvTrvDstc(Double.parseDouble(mmti0291vo.getTrv_dstc_exca_mtt__cnv_trv_dstc()));
		}
		if("".equals(request.getParameter("exp_exca_plan_rsl_cd")) || null == request.getParameter("exp_exca_plan_rsl_cd")){
			mbtt02001vo.setExpExcaPlanRslCd(" ");
		} else {
			mbtt02001vo.setExpExcaPlanRslCd(StringUtil.nvl(request.getParameter("exp_exca_plan_rsl_cd")));
		}
		if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__exca_bz_proc_dvn()) || null == mmti0291vo.getTrv_dstc_exca_mtt__exca_bz_proc_dvn()){
			mbtt02001vo.setExcaBzProcDvn(" ");
		} else {
			mbtt02001vo.setExcaBzProcDvn(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__exca_bz_proc_dvn()));
		}
		if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__exca_rtrn_dvn()) || null == mmti0291vo.getTrv_dstc_exca_mtt__exca_rtrn_dvn()){
			mbtt02001vo.setExcaRtrnDvn(" ");
		} else {
			mbtt02001vo.setExcaRtrnDvn(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__exca_rtrn_dvn()));
		}
		if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__pdc_sr_dvn()) || null == mmti0291vo.getTrv_dstc_exca_mtt__pdc_sr_dvn()){
			mbtt02001vo.setPdcSrDvn(" ");
		} else {
			mbtt02001vo.setPdcSrDvn(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__pdc_sr_dvn()));
		}
		if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__adc_rtrn_prm()) || null == mmti0291vo.getTrv_dstc_exca_mtt__adc_rtrn_prm()){
			mbtt02001vo.setAdcRtrnPrm(0);
		} else {
			mbtt02001vo.setAdcRtrnPrm(Double.parseDouble(mmti0291vo.getTrv_dstc_exca_mtt__adc_rtrn_prm()));
		}
		if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn()) || null == mmti0291vo.getTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn()){
			mbtt02001vo.setTrvDstcSplcExcaYn(" ");
		} else {
			mbtt02001vo.setTrvDstcSplcExcaYn(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn()));
		}
		if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__imag_dup_yn()) || null == mmti0291vo.getTrv_dstc_exca_mtt__imag_dup_yn()){
			mbtt02001vo.setImagDupYn(" ");
		} else {
			mbtt02001vo.setImagDupYn(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__imag_dup_yn()));
		}
		if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__nrm_proc_yn()) || null == mmti0291vo.getTrv_dstc_exca_mtt__nrm_proc_yn()){
			mbtt02001vo.setNrmProcYn(" ");
		} else {
			mbtt02001vo.setNrmProcYn(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__nrm_proc_yn()));
		}
		if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__crd_scn_cncl_pss_yn()) || null == mmti0291vo.getTrv_dstc_exca_mtt__crd_scn_cncl_pss_yn()){
			mbtt02001vo.setCrdScnCnclPssYn(" ");
		} else {
			mbtt02001vo.setCrdScnCnclPssYn(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__crd_scn_cncl_pss_yn()));
		}
		mbtt02001vo.setRespCn(StringUtil.nvl(mmti0291vo.getZ_resp_cd()));
		mbtt02001vo.setRslCn(scrnNm + "_" + StringUtil.nvl(mmti0291vo.getZ_resp_msg()));
		mbtt02001vo.setFrstIpmnEmpno("82101685");
		mbtt02001vo.setFnalAmdrEmpno("82101685");
		if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__adc_rtrn_dvn()) || null == mmti0291vo.getTrv_dstc_exca_mtt__adc_rtrn_dvn()){
			mbtt02001vo.setAdcRtrnDvn(" ");
		} else {
			mbtt02001vo.setAdcRtrnDvn(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__adc_rtrn_dvn()));
		}
		if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__scrn_proc_cd()) || null == mmti0291vo.getTrv_dstc_exca_mtt__scrn_proc_cd()){
			mbtt02001vo.setScrnProcCd(" ");
		} else {
			mbtt02001vo.setScrnProcCd(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__scrn_proc_cd()));
		}
		if("".equals(request.getParameter("ctc_plno")) || null == request.getParameter("ctc_plno")){
			mbtt02001vo.setCtcPlno(" ");
		} else {
			mbtt02001vo.setCtcPlno(StringUtil.nvl(request.getParameter("ctc_plno")));
		}
		if("".equals(request.getParameter("trv_dstc_proc_dvcd")) || null == request.getParameter("trv_dstc_proc_dvcd")){
			mbtt02001vo.setTrvDstcProcDvcd(" ");
		} else {
			mbtt02001vo.setTrvDstcProcDvcd(StringUtil.nvl(request.getParameter("trv_dstc_proc_dvcd")));
		}
		if("".equals(request.getParameter("mbl_snd_no")) || null == request.getParameter("mbl_snd_no")){
			mbtt02001vo.setMblSndNo(" ");
		} else {
			mbtt02001vo.setMblSndNo(StringUtil.nvl(request.getParameter("mbl_snd_no")));
		}
		if("".equals(request.getParameter("plan_plno_dvcd")) || null == request.getParameter("plan_plno_dvcd")){
			mbtt02001vo.setPlanPlnoDvcd(" ");
		} else {
			mbtt02001vo.setPlanPlnoDvcd(StringUtil.nvl(request.getParameter("plan_plno_dvcd")));
		}
		if("".equals(request.getParameter("plan_plno")) || null == request.getParameter("plan_plno")){
			mbtt02001vo.setPlanPlno(" ");
		} else {
			mbtt02001vo.setPlanPlno(StringUtil.nvl(request.getParameter("plan_plno")));
		}
		if("".equals(request.getParameter("chng_plan_no")) || null == request.getParameter("chng_plan_no")){
			mbtt02001vo.setChngPlanNo(" ");
		} else {
			mbtt02001vo.setChngPlanNo(StringUtil.nvl(request.getParameter("chng_plan_no")));
		}
		if("".equals(request.getParameter("dst_tty_dvn1")) || null == request.getParameter("dst_tty_dvn1")){
			mbtt02001vo.setDstTtyDvn1(" ");
		} else {
			mbtt02001vo.setDstTtyDvn1(StringUtil.nvl(request.getParameter("dst_tty_dvn1")));
		}
		if("".equals(request.getParameter("dst_tty_dvn2")) || null == request.getParameter("dst_tty_dvn2")){
			mbtt02001vo.setDstTtyDvn2(" ");
		} else {
			mbtt02001vo.setDstTtyDvn2(StringUtil.nvl(request.getParameter("dst_tty_dvn2")));
		}
		if("".equals(request.getParameter("dst_tty_dvn3")) || null == request.getParameter("dst_tty_dvn3")){
			mbtt02001vo.setDstTtyDvn3(" ");
		} else {
			mbtt02001vo.setDstTtyDvn3(StringUtil.nvl(request.getParameter("dst_tty_dvn3")));
		}
		if("".equals(request.getParameter("dst_tty_dvn4")) || null == request.getParameter("dst_tty_dvn4")){
			mbtt02001vo.setDstTtyDvn4(" ");
		} else {
			mbtt02001vo.setDstTtyDvn4(StringUtil.nvl(request.getParameter("dst_tty_dvn4")));
		}
		if("".equals(request.getParameter("dst_tty_dvn5")) || null == request.getParameter("dst_tty_dvn5")){
			mbtt02001vo.setDstTtyDvn5(" ");
		} else {
			mbtt02001vo.setDstTtyDvn5(StringUtil.nvl(request.getParameter("dst_tty_dvn5")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt1")) || null == request.getParameter("phgp_regt_tgt1")){
			mbtt02001vo.setPhgpRegtTgt1(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt1(StringUtil.nvl(request.getParameter("phgp_regt_tgt1")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt2")) || null == request.getParameter("phgp_regt_tgt2")){
			mbtt02001vo.setPhgpRegtTgt2(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt2(StringUtil.nvl(request.getParameter("phgp_regt_tgt2")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt3")) || null == request.getParameter("phgp_regt_tgt3")){
			mbtt02001vo.setPhgpRegtTgt3(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt3(StringUtil.nvl(request.getParameter("phgp_regt_tgt3")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt4")) || null == request.getParameter("phgp_regt_tgt4")){
			mbtt02001vo.setPhgpRegtTgt4(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt4(StringUtil.nvl(request.getParameter("phgp_regt_tgt4")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt5")) || null == request.getParameter("phgp_regt_tgt5")){
			mbtt02001vo.setPhgpRegtTgt5(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt5(StringUtil.nvl(request.getParameter("phgp_regt_tgt5")));
		}
		
		//MMTI0291 insert
		int insertRow = 0;
		
		logger.info("#### mileageNew06B2 MMTI0291 MBTT02001 before ####");
		insertRow = mileageTobeService.insertJungsanTest(mbtt02001vo);
		logger.info("#### mileageNew06B2 MMTI0291 MBTT02001 after ####");
		
		if(insertRow < 1){
			logger.info("#### 사서함번호: " + StringUtil.nvl(mbtt02001vo.getPboxNo()) + "####");
			logger.info("#### insert 결과: Fail ####");
		}else{
			logger.info("#### insert 결과: Success ####");
		}
		
		session.setAttribute("renewal", "02");
		return "/counter/carrider/tobe/mileageNew06B";
	}
	
	@RequestMapping(value="/mileageNew06C")
	public @ResponseBody Map<String, String> mileageNew06C(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		HttpSession session = request.getSession();
		Map<String, String> map = new HashMap<String, String>();
		MMTI0213VO pre_mmti0213vo = new MMTI0213VO();
		MMTI0259VO pre_mmti0259vo = new MMTI0259VO();
		pre_mmti0213vo = (MMTI0213VO)session.getAttribute("pre_mmti0213vo");
		pre_mmti0259vo = (MMTI0259VO)session.getAttribute("pre_mmti0259vo");
		
		MBTT02001VO mbtt02001vo = new MBTT02001VO();
		String scrnNm = "mileageNew06C";
		
		MMTI0291VO pre_mmti0291vo = new MMTI0291VO();
		pre_mmti0291vo.setTrv_dstc_exca_mtt__exca_bz_proc_dvn("2");												// 정산업무처리구분 2:확정
		pre_mmti0291vo.setTrv_dstc_exca_mtt__plno(pre_mmti0259vo.getPlno());									// 증권번호
		pre_mmti0291vo.setTrv_dstc_exca_mtt__plan_no(pre_mmti0259vo.getExp_exca_plan_no());						// 설계번호
		pre_mmti0291vo.setTrv_dstc_exca_mtt__exca_rtrn_dvn("3");												// 갱신환급구분 3:카드부분취소
		pre_mmti0291vo.setTrv_dstc_exca_mtt__pdc_sr_dvn(pre_mmti0259vo.getPdc_sr_dvn());						// 상품출처구분
		pre_mmti0291vo.setTrv_dstc_exca_mtt__scrn_proc_cd(pre_mmti0259vo.getExp_exca_plan_rsl_cd());			// 화면처리코드
		pre_mmti0291vo.setTrv_dstc_exca_mtt__adc_rtrn_dvn(pre_mmti0259vo.getAdc_rtrn_dvn());					// 추징환급구분
		pre_mmti0291vo.setTrv_dstc_exca_mtt__adc_rtrn_prm(pre_mmti0259vo.getAdc_rtrn_prm());					// 추징환급보험료
		pre_mmti0291vo.setTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn(pre_mmti0213vo.getTrv_dstc_splc_exca_yn());	// 주행거리간편정산여부
		pre_mmti0291vo.setTrv_dstc_exca_mtt__pbox_no(pre_mmti0213vo.getSms_ts_bvan());							// 사서함번호
		
		pre_mmti0291vo.setTrv_dstc_exca_mtt__crd_scn_cncl_pss_yn(pre_mmti0259vo.getCrd_scn_cncl_pss_yn()); 		// 카드부분취소가능여부
		pre_mmti0291vo.setTrv_dstc_exca_mtt__stlm_cdcp_nm(pre_mmti0259vo.getStlm_cdcp_nm());					// 결제카드사명
		pre_mmti0291vo.setTrv_dstc_exca_mtt__stlm_crd_no(pre_mmti0259vo.getStlm_crd_no());						// 결제카드번호
		pre_mmti0291vo = mileageTobeService.getMMTI0291VO(pre_mmti0291vo);
		
		if(pre_mmti0291vo.getErrorCode().equals("0")){
			map.put("result", "y");
			session.setAttribute("scrn_proc_cd", pre_mmti0291vo.getTrv_dstc_exca_mtt__scrn_proc_cd());
			session.setAttribute("rnw_plno", pre_mmti0291vo.getTrv_dstc_exca_mtt__rnw_plno());
			session.setAttribute("pdc_sr_dvn", pre_mmti0291vo.getTrv_dstc_exca_mtt__pdc_sr_dvn());
			
			// 아래 데이터 + 갱신증번: 추가가입위해 저장
			session.setAttribute("trv_dstc_exca_mtt__plno", pre_mmti0291vo.getTrv_dstc_exca_mtt__plno());
			session.setAttribute("trv_dstc_exca_mtt__plan_no", pre_mmti0291vo.getTrv_dstc_exca_mtt__plan_no());
			session.setAttribute("trv_dstc_exca_mtt__plan_dt", pre_mmti0291vo.getTrv_dstc_exca_mtt__plan_dt());
			session.setAttribute("trv_dstc_exca_mtt__hdlr_empno", pre_mmti0291vo.getTrv_dstc_exca_mtt__hdlr_empno());
			
			// 부적정/중복 이미지인 경우 화면처리코드 02 
			if("1".equals(pre_mmti0291vo.getTrv_dstc_exca_mtt__imag_dup_yn())){
				pre_mmti0291vo.setTrv_dstc_exca_mtt__scrn_proc_cd("02");
			}
			
			// CM 상품이고, 화면처리코드 IN(02, 14) or 이미지 중복
			
			if("CM".equals(pre_mmti0291vo.getTrv_dstc_exca_mtt__pdc_sr_dvn()) && 
					("02".equals(pre_mmti0291vo.getTrv_dstc_exca_mtt__scrn_proc_cd())
					|| "14".equals(pre_mmti0291vo.getTrv_dstc_exca_mtt__scrn_proc_cd()))){
				
				MMTI0015VO mmti0015vo = new MMTI0015VO();
				mmti0015vo.setFunt_key("00");
				mmti0015vo.setPlan_no(pre_mmti0291vo.getTrv_dstc_exca_mtt__plan_no());
				mmti0015vo = mileageTobeService.getMMTI0015VO(mmti0015vo);
				
				logger.debug("##### MMTI0015 시작 ##########################");
				logger.debug("##### 고객식별번호: " + mmti0015vo.getPlhd__cust_dcmt_no() + " ##########################");
				logger.debug("##### 고객번호: " + mmti0015vo.getPlhd__cust_no() + " ##########################");
				logger.debug("##### 고객명: " + mmti0015vo.getPlhd__cust_nm() + " ##########################");
				logger.debug("##### 이메일: " + mmti0015vo.getPlhd__eml() + " ##########################");
				logger.debug("##### 지역번호: " + mmti0015vo.getPlhd_cntp_if__tlp_arno() + " ##########################");
				logger.debug("##### 국번호: " + mmti0015vo.getPlhd_cntp_if__tlp_ofno() + " ##########################");
				logger.debug("##### 개별번호: " + mmti0015vo.getPlhd_cntp_if__tlp_idvno() + " ##########################");
				
				XTEM0021VO xtem0021vo = new XTEM0021VO();
				xtem0021vo.setCnsl_rpt_no("");						// 상담접수번호				
				xtem0021vo.setCm_bz_dvcd("05");
				xtem0021vo.setCnsl_typ_dvcd("07");
				xtem0021vo.setCm_plan_no(pre_mmti0291vo.getTrv_dstc_exca_mtt__plan_no());
				xtem0021vo.setCnsl_rpy_dvcd("1");
				xtem0021vo.setCnsl_rpt_dttm(getDayTime());			// 현재년월일시분초 14자리
				xtem0021vo.setCust_nm(mmti0015vo.getPlhd__cust_nm());
				xtem0021vo.setCust_no(mmti0015vo.getPlhd__cust_no());
				
				String cust_dcmt_no = SeedUtil.decrypt(mmti0015vo.getPlhd__cust_dcmt_no());
				
				if("1".equals(cust_dcmt_no.substring(6, 7)) || "2".equals(cust_dcmt_no.substring(6, 7))
					|| "5".equals(cust_dcmt_no.substring(6, 7)) || "6".equals(cust_dcmt_no.substring(6, 7))){
					xtem0021vo.setBrth("19" + cust_dcmt_no.substring(0, 6));
				} else{
					xtem0021vo.setBrth("20" + cust_dcmt_no.substring(0, 6));
				}
				xtem0021vo.setSx_cd(cust_dcmt_no.substring(6, 7));
				xtem0021vo.setEml_adr(mmti0015vo.getPlhd__eml());
				xtem0021vo.setClp_tlcno(mmti0015vo.getPlhd_cntp_if__tlp_arno());
				xtem0021vo.setClp_ofno(mmti0015vo.getPlhd_cntp_if__tlp_ofno());
				xtem0021vo.setClp_idvno(mmti0015vo.getPlhd_cntp_if__tlp_idvno());
				xtem0021vo.setCnsl_rsvt_dt("99990101");
				xtem0021vo.setCnsl_rsvt_time_cd("1");
				xtem0021vo.setCnsl_cn("최종주행거리사진등록/만기정산");
				xtem0021vo.setCnsl_aply_csn_yn("1");
				xtem0021vo.setUrl_adr("");
				xtem0021vo.setCm_ctrmf_tpcd("32");
				xtem0021vo.setFrst_ipmn_empno("80000028");
				xtem0021vo.setFrst_ipnpt_dttm(getDayTime());		// 현재년월일시분초 14자리	
				
				xtem0021vo = mileageTobeService.getXTEM0021VO(xtem0021vo);
				logger.debug("##### XTEM0021 시작 ##########################");
				logger.debug("##### 처리결과: [ " + xtem0021vo.getProc_rtn() + " ] ##########################");
			}
		}else{
			map.put("result", "n");
			map.put("z_resp_msg", pre_mmti0291vo.getZ_resp_msg());
		}
		
		//MMTI0291전문 정산이력테이블(MBTT02001) 적재
		mbtt02001vo.setPboxNo(StringUtil.nvl(pre_mmti0213vo.getSms_ts_bvan()));
		mbtt02001vo.setTlgIdVal("MMTI0291");
		mbtt02001vo.setEsbTrscId(StringUtil.nvl(pre_mmti0291vo.getZ_trsc_id()));
		if("".equals(pre_mmti0291vo.getTrv_dstc_exca_mtt__plno()) || null == pre_mmti0291vo.getTrv_dstc_exca_mtt__plno()){
			mbtt02001vo.setPlno(" ");
		} else {
			mbtt02001vo.setPlno(StringUtil.nvl(pre_mmti0291vo.getTrv_dstc_exca_mtt__plno()));
		}
		if("".equals(pre_mmti0291vo.getTrv_dstc_exca_mtt__plan_no()) || null == pre_mmti0291vo.getTrv_dstc_exca_mtt__plan_no()){
			mbtt02001vo.setPlanNo(" ");
		} else {
			mbtt02001vo.setPlanNo(StringUtil.nvl(pre_mmti0291vo.getTrv_dstc_exca_mtt__plan_no()));
		}
		if("".equals(pre_mmti0291vo.getTrv_dstc_exca_mtt__rnw_plno()) || null == pre_mmti0291vo.getTrv_dstc_exca_mtt__rnw_plno()){
			mbtt02001vo.setRnwPlno(" ");
		} else {
			mbtt02001vo.setRnwPlno(StringUtil.nvl(pre_mmti0291vo.getTrv_dstc_exca_mtt__rnw_plno()));
		}
		mbtt02001vo.setTlgProcRslCdVal(StringUtil.nvl(pre_mmti0291vo.getZ_tlg_sp_cd()));
		mbtt02001vo.setTlgErrCdVal(StringUtil.nvl(pre_mmti0291vo.getZ_trns_org_dvcd())+StringUtil.nvl(pre_mmti0291vo.getZ_trns_org_cd()));
		if("".equals(pre_mmti0291vo.getTrv_dstc_exca_mtt__hdlr_empno()) || null == pre_mmti0291vo.getTrv_dstc_exca_mtt__hdlr_empno()){
			mbtt02001vo.setHdlrEmpno(" ");
		} else {
			mbtt02001vo.setHdlrEmpno(StringUtil.nvl(pre_mmti0291vo.getTrv_dstc_exca_mtt__hdlr_empno()));
		}
		if("".equals(pre_mmti0213vo.getPbox_no_dvcd()) || null == pre_mmti0213vo.getPbox_no_dvcd()){
			mbtt02001vo.setPboxNoDvcd(" ");
		} else {
			mbtt02001vo.setPboxNoDvcd(StringUtil.nvl(pre_mmti0213vo.getPbox_no_dvcd()));
		}
		if("".equals(pre_mmti0213vo.getProc_dvn()) || null == pre_mmti0213vo.getProc_dvn()){
			mbtt02001vo.setProcDvn(" ");
		} else {
			mbtt02001vo.setProcDvn(StringUtil.nvl(pre_mmti0213vo.getProc_dvn()));
		}
		if("".equals(pre_mmti0213vo.getTrv_dstc_exp_exca_dvcd()) || null == pre_mmti0213vo.getTrv_dstc_exp_exca_dvcd()){
			mbtt02001vo.setTrvDstcExpExcaDvcd(" ");
		} else {
			mbtt02001vo.setTrvDstcExpExcaDvcd(StringUtil.nvl(pre_mmti0213vo.getTrv_dstc_exp_exca_dvcd()));
		}
		if("".equals(pre_mmti0213vo.getTrv_dstc_chng_aply_dvn()) || null == pre_mmti0213vo.getTrv_dstc_chng_aply_dvn()){
			mbtt02001vo.setTrvDstcChngAplyDvn(" ");
		} else {
			mbtt02001vo.setTrvDstcChngAplyDvn(StringUtil.nvl(pre_mmti0213vo.getTrv_dstc_chng_aply_dvn()));
		}
		if("".equals(pre_mmti0213vo.getHdlr_fire_yn()) || null == pre_mmti0213vo.getHdlr_fire_yn()){
			mbtt02001vo.setHdlrFireYn(" ");
		} else {
			mbtt02001vo.setHdlrFireYn(StringUtil.nvl(pre_mmti0213vo.getHdlr_fire_yn()));
		}
		if("".equals(pre_mmti0213vo.getMtcc_yn()) || null == pre_mmti0213vo.getMtcc_yn()){
			mbtt02001vo.setMtccYn(" ");
		} else {
			mbtt02001vo.setMtccYn(StringUtil.nvl(pre_mmti0213vo.getMtcc_yn()));
		}
		if("".equals(request.getParameter("aut_cgnt_trv_dstc")) || null == request.getParameter("aut_cgnt_trv_dstc")){
			mbtt02001vo.setAutCgntTrvDstc(0);
		} else {
			mbtt02001vo.setAutCgntTrvDstc(Double.parseDouble(request.getParameter("aut_cgnt_trv_dstc")));
		}
		if("".equals(pre_mmti0291vo.getTrv_dstc_exca_mtt__aut_cgnt_trv_dstc_rsl_cd()) || null == pre_mmti0291vo.getTrv_dstc_exca_mtt__aut_cgnt_trv_dstc_rsl_cd()){
			mbtt02001vo.setAutCgntTrvDstcRslCd(" ");
		} else {
			mbtt02001vo.setAutCgntTrvDstcRslCd(StringUtil.nvl(pre_mmti0291vo.getTrv_dstc_exca_mtt__aut_cgnt_trv_dstc_rsl_cd()));
		}
		if("".equals(request.getParameter("inptTrvDstc")) || null == request.getParameter("inptTrvDstc")){
			mbtt02001vo.setInptTrvDstc(0);
		} else {
			mbtt02001vo.setInptTrvDstc(Double.parseDouble(request.getParameter("inptTrvDstc")));
		}
		if("".equals(pre_mmti0291vo.getTrv_dstc_exca_mtt__cnv_trv_dstc()) || null == pre_mmti0291vo.getTrv_dstc_exca_mtt__cnv_trv_dstc()){
			mbtt02001vo.setCnvTrvDstc(0);
		} else {
			mbtt02001vo.setCnvTrvDstc(Double.parseDouble(pre_mmti0291vo.getTrv_dstc_exca_mtt__cnv_trv_dstc()));
		}
		if("".equals(request.getParameter("exp_exca_plan_rsl_cd")) || null == request.getParameter("exp_exca_plan_rsl_cd")){
			mbtt02001vo.setExpExcaPlanRslCd(" ");
		} else {
			mbtt02001vo.setExpExcaPlanRslCd(StringUtil.nvl(request.getParameter("exp_exca_plan_rsl_cd")));
		}
		if("".equals(pre_mmti0291vo.getTrv_dstc_exca_mtt__exca_bz_proc_dvn()) || null == pre_mmti0291vo.getTrv_dstc_exca_mtt__exca_bz_proc_dvn()){
			mbtt02001vo.setExcaBzProcDvn(" ");
		} else {
			mbtt02001vo.setExcaBzProcDvn(StringUtil.nvl(pre_mmti0291vo.getTrv_dstc_exca_mtt__exca_bz_proc_dvn()));
		}
		if("".equals(pre_mmti0291vo.getTrv_dstc_exca_mtt__exca_rtrn_dvn()) || null == pre_mmti0291vo.getTrv_dstc_exca_mtt__exca_rtrn_dvn()){
			mbtt02001vo.setExcaRtrnDvn(" ");
		} else {
			mbtt02001vo.setExcaRtrnDvn(StringUtil.nvl(pre_mmti0291vo.getTrv_dstc_exca_mtt__exca_rtrn_dvn()));
		}
		if("".equals(pre_mmti0291vo.getTrv_dstc_exca_mtt__pdc_sr_dvn()) || null == pre_mmti0291vo.getTrv_dstc_exca_mtt__pdc_sr_dvn()){
			mbtt02001vo.setPdcSrDvn(" ");
		} else {
			mbtt02001vo.setPdcSrDvn(StringUtil.nvl(pre_mmti0291vo.getTrv_dstc_exca_mtt__pdc_sr_dvn()));
		}
		if("".equals(pre_mmti0291vo.getTrv_dstc_exca_mtt__adc_rtrn_prm()) || null == pre_mmti0291vo.getTrv_dstc_exca_mtt__adc_rtrn_prm()){
			mbtt02001vo.setAdcRtrnPrm(0);
		} else {
			mbtt02001vo.setAdcRtrnPrm(Double.parseDouble(pre_mmti0291vo.getTrv_dstc_exca_mtt__adc_rtrn_prm()));
		}
		if("".equals(pre_mmti0291vo.getTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn()) || null == pre_mmti0291vo.getTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn()){
			mbtt02001vo.setTrvDstcSplcExcaYn(" ");
		} else {
			mbtt02001vo.setTrvDstcSplcExcaYn(StringUtil.nvl(pre_mmti0291vo.getTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn()));
		}
		if("".equals(pre_mmti0291vo.getTrv_dstc_exca_mtt__imag_dup_yn()) || null == pre_mmti0291vo.getTrv_dstc_exca_mtt__imag_dup_yn()){
			mbtt02001vo.setImagDupYn(" ");
		} else {
			mbtt02001vo.setImagDupYn(StringUtil.nvl(pre_mmti0291vo.getTrv_dstc_exca_mtt__imag_dup_yn()));
		}
		if("".equals(pre_mmti0291vo.getTrv_dstc_exca_mtt__nrm_proc_yn()) || null == pre_mmti0291vo.getTrv_dstc_exca_mtt__nrm_proc_yn()){
			mbtt02001vo.setNrmProcYn(" ");
		} else {
			mbtt02001vo.setNrmProcYn(StringUtil.nvl(pre_mmti0291vo.getTrv_dstc_exca_mtt__nrm_proc_yn()));
		}
		if("".equals(pre_mmti0291vo.getTrv_dstc_exca_mtt__crd_scn_cncl_pss_yn()) || null == pre_mmti0291vo.getTrv_dstc_exca_mtt__crd_scn_cncl_pss_yn()){
			mbtt02001vo.setCrdScnCnclPssYn(" ");
		} else {
			mbtt02001vo.setCrdScnCnclPssYn(StringUtil.nvl(pre_mmti0291vo.getTrv_dstc_exca_mtt__crd_scn_cncl_pss_yn()));
		}
		mbtt02001vo.setRespCn(StringUtil.nvl(pre_mmti0291vo.getZ_resp_cd()));
		mbtt02001vo.setRslCn(scrnNm + "_" + StringUtil.nvl(pre_mmti0291vo.getZ_resp_msg()));
		mbtt02001vo.setFrstIpmnEmpno("82101685");
		mbtt02001vo.setFnalAmdrEmpno("82101685");
		
		if("".equals(pre_mmti0291vo.getTrv_dstc_exca_mtt__adc_rtrn_dvn()) || null == pre_mmti0291vo.getTrv_dstc_exca_mtt__adc_rtrn_dvn()){
			mbtt02001vo.setAdcRtrnDvn(" ");
		} else {
			mbtt02001vo.setAdcRtrnDvn(StringUtil.nvl(pre_mmti0291vo.getTrv_dstc_exca_mtt__adc_rtrn_dvn()));
		}
		if("".equals(pre_mmti0291vo.getTrv_dstc_exca_mtt__scrn_proc_cd()) || null == pre_mmti0291vo.getTrv_dstc_exca_mtt__scrn_proc_cd()){
			mbtt02001vo.setScrnProcCd(" ");
		} else {
			mbtt02001vo.setScrnProcCd(StringUtil.nvl(pre_mmti0291vo.getTrv_dstc_exca_mtt__scrn_proc_cd()));
		}
		if("".equals(request.getParameter("ctc_plno")) || null == request.getParameter("ctc_plno")){
			mbtt02001vo.setCtcPlno(" ");
		} else {
			mbtt02001vo.setCtcPlno(StringUtil.nvl(request.getParameter("ctc_plno")));
		}
		if("".equals(request.getParameter("trv_dstc_proc_dvcd")) || null == request.getParameter("trv_dstc_proc_dvcd")){
			mbtt02001vo.setTrvDstcProcDvcd(" ");
		} else {
			mbtt02001vo.setTrvDstcProcDvcd(StringUtil.nvl(request.getParameter("trv_dstc_proc_dvcd")));
		}
		if("".equals(request.getParameter("mbl_snd_no")) || null == request.getParameter("mbl_snd_no")){
			mbtt02001vo.setMblSndNo(" ");
		} else {
			mbtt02001vo.setMblSndNo(StringUtil.nvl(request.getParameter("mbl_snd_no")));
		}
		if("".equals(request.getParameter("plan_plno_dvcd")) || null == request.getParameter("plan_plno_dvcd")){
			mbtt02001vo.setPlanPlnoDvcd(" ");
		} else {
			mbtt02001vo.setPlanPlnoDvcd(StringUtil.nvl(request.getParameter("plan_plno_dvcd")));
		}
		if("".equals(request.getParameter("plan_plno")) || null == request.getParameter("plan_plno")){
			mbtt02001vo.setPlanPlno(" ");
		} else {
			mbtt02001vo.setPlanPlno(StringUtil.nvl(request.getParameter("plan_plno")));
		}
		if("".equals(request.getParameter("chng_plan_no")) || null == request.getParameter("chng_plan_no")){
			mbtt02001vo.setChngPlanNo(" ");
		} else {
			mbtt02001vo.setChngPlanNo(StringUtil.nvl(request.getParameter("chng_plan_no")));
		}
		if("".equals(request.getParameter("dst_tty_dvn1")) || null == request.getParameter("dst_tty_dvn1")){
			mbtt02001vo.setDstTtyDvn1(" ");
		} else {
			mbtt02001vo.setDstTtyDvn1(StringUtil.nvl(request.getParameter("dst_tty_dvn1")));
		}
		if("".equals(request.getParameter("dst_tty_dvn2")) || null == request.getParameter("dst_tty_dvn2")){
			mbtt02001vo.setDstTtyDvn2(" ");
		} else {
			mbtt02001vo.setDstTtyDvn2(StringUtil.nvl(request.getParameter("dst_tty_dvn2")));
		}
		if("".equals(request.getParameter("dst_tty_dvn3")) || null == request.getParameter("dst_tty_dvn3")){
			mbtt02001vo.setDstTtyDvn3(" ");
		} else {
			mbtt02001vo.setDstTtyDvn3(StringUtil.nvl(request.getParameter("dst_tty_dvn3")));
		}
		if("".equals(request.getParameter("dst_tty_dvn4")) || null == request.getParameter("dst_tty_dvn4")){
			mbtt02001vo.setDstTtyDvn4(" ");
		} else {
			mbtt02001vo.setDstTtyDvn4(StringUtil.nvl(request.getParameter("dst_tty_dvn4")));
		}
		if("".equals(request.getParameter("dst_tty_dvn5")) || null == request.getParameter("dst_tty_dvn5")){
			mbtt02001vo.setDstTtyDvn5(" ");
		} else {
			mbtt02001vo.setDstTtyDvn5(StringUtil.nvl(request.getParameter("dst_tty_dvn5")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt1")) || null == request.getParameter("phgp_regt_tgt1")){
			mbtt02001vo.setPhgpRegtTgt1(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt1(StringUtil.nvl(request.getParameter("phgp_regt_tgt1")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt2")) || null == request.getParameter("phgp_regt_tgt2")){
			mbtt02001vo.setPhgpRegtTgt2(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt2(StringUtil.nvl(request.getParameter("phgp_regt_tgt2")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt3")) || null == request.getParameter("phgp_regt_tgt3")){
			mbtt02001vo.setPhgpRegtTgt3(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt3(StringUtil.nvl(request.getParameter("phgp_regt_tgt3")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt4")) || null == request.getParameter("phgp_regt_tgt4")){
			mbtt02001vo.setPhgpRegtTgt4(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt4(StringUtil.nvl(request.getParameter("phgp_regt_tgt4")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt5")) || null == request.getParameter("phgp_regt_tgt5")){
			mbtt02001vo.setPhgpRegtTgt5(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt5(StringUtil.nvl(request.getParameter("phgp_regt_tgt5")));
		}
		
		//MMTI0291 insert
		int insertRow = 0;
		
		logger.info("#### mileageNew06C MMTI0291 MBTT02001 before ####");
		insertRow = mileageTobeService.insertJungsanTest(mbtt02001vo);
		logger.info("#### mileageNew06C MMTI0291 MBTT02001 after ####");
		
		if(insertRow < 1){
			logger.info("#### 사서함번호: " + StringUtil.nvl(mbtt02001vo.getPboxNo()) + "####");
			logger.info("#### insert 결과: Fail ####");
		}else{
			logger.info("#### insert 결과: Success ####");
		}
		
		return map;	
	}
	
	@RequestMapping(value="/mileageNew06C2")
	public String mileageNew06C2(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		
		return "/counter/carrider/tobe/mileageNew06C2";
	}
	
	@RequestMapping(value="/mileageBlackBox02")
	public String mileageBlackBox02(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		HttpSession session = request.getSession();
		MMTI0213VO jmvo = new MMTI0213VO();
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("num")));
		jmvo.setMtcc_yn(request.getParameter("mtcc_yn"));
		jmvo.setPdc_cd(request.getParameter("pdc_cd"));
		jmvo = mileageTobeService.getMMTI0213VO(jmvo);
		String checkYn = request.getParameter("checkYn");
		logger.debug(">>>> mileageBlackBox02 checkYn = " + checkYn);
		String view = "";
		
		if("1".equals(jmvo.getPbox_no_dvcd())) { // 주행거리
			view = "/counter/carrider/tobe/mileage02";
		}
		else if("2".equals(jmvo.getPbox_no_dvcd())) { // 블랙박스
			if("1".equals(jmvo.getMtcc_yn())||"20028".equals(jmvo.getPdc_cd())||"20030".equals(jmvo.getPdc_cd())||"20057".equals(jmvo.getPdc_cd())){
				view = "/counter/carrider/tobe/blackbox04"; //이륜차(오토바이) 블랙박스
			} else {
				view = "/counter/carrider/tobe/blackbox02"; //자동차 블랙박스
			}
		}

		request.setAttribute("num", request.getParameter("num"));
		session.setAttribute("checkYn", request.getParameter("checkYn"));
//		request.setAttribute("checkYn", request.getParameter("checkYn"));
		request.setAttribute("mtcc_yn", jmvo.getMtcc_yn());
		request.setAttribute("pdc_cd", jmvo.getPdc_cd());
		request.setAttribute("jmvo", jmvo);
		return view;
	}
	
	//aiocr용
	@RequestMapping(value="/aiocrMileageBlackBox02")
	public String aiocrMileageBlackBox02(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		HttpSession session = request.getSession();
		MMTI0213VO jmvo = new MMTI0213VO();
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("num")));
		jmvo.setMtcc_yn(request.getParameter("mtcc_yn"));
		jmvo.setPdc_cd(request.getParameter("pdc_cd"));
		jmvo = mileageTobeService.getMMTI0213VO(jmvo);
		String checkYn = request.getParameter("checkYn");
		logger.debug(">>>> mileageBlackBox02 checkYn = " + checkYn);
		String view = "";
		
		if("1".equals(jmvo.getPbox_no_dvcd())) { // 주행거리
			view = "/counter/carrider/tobe/aiocrMileage02";
		}
		else if("2".equals(jmvo.getPbox_no_dvcd())) { // 블랙박스
			if("1".equals(jmvo.getMtcc_yn())||"20028".equals(jmvo.getPdc_cd())||"20030".equals(jmvo.getPdc_cd())||"20057".equals(jmvo.getPdc_cd())){
				view = "/counter/carrider/tobe/blackbox04"; //이륜차(오토바이) 블랙박스
			} else {
				view = "/counter/carrider/tobe/blackbox02"; //자동차 블랙박스
			}
		}

		request.setAttribute("num", request.getParameter("num"));
		session.setAttribute("checkYn", request.getParameter("checkYn"));
//		request.setAttribute("checkYn", request.getParameter("checkYn"));
		request.setAttribute("mtcc_yn", jmvo.getMtcc_yn());
		request.setAttribute("pdc_cd", jmvo.getPdc_cd());
		request.setAttribute("jmvo", jmvo);
		return view;
	}
	
	//aiocr용
	@RequestMapping(value="/aiocrMileageBlackBoxFileUpload")
	public @ResponseBody Map<String, String> aiocrMileageBlackBoxFileUpload(MultipartHttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		Map<String, String> map = new HashMap<String, String>();
		
		MMTI0213VO jmvo = new MMTI0213VO();
		MBTR01001VO mbtr01001vo = new MBTR01001VO();
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("num")));
		jmvo = mileageTobeService.getMMTI0213VO(jmvo);

		mbtr01001vo = mileageTobeService.aiocrRegInfoToEdmsForMobileWeb(request, jmvo.getSms_ts_bvan(), mbtr01001vo);
		
		MMTI0259VO jmvo1 = new MMTI0259VO();
		jmvo1.setPbox_use_yn("1");
		jmvo1.setPbox_no(jmvo.getSms_ts_bvan());
		jmvo1.setPhgp_cnfm_dt(DateUtil.getDate("yyyymmdd"));
		jmvo1.setPhgp_strg_yn("1");
		
		if("1".equals(jmvo.getPbox_no_dvcd()) && !"1".equals(jmvo.getCm_yn())) {
			if("03".equals(jmvo.getProc_dvn())) {
				jmvo1.setPbox_chr_nm(request.getParameter("mileage1") + "/" + request.getParameter("mileage2"));
			}
			else {
				jmvo1.setPbox_chr_nm(request.getParameter("mileage1"));
			}
		}
		jmvo1 = mileageTobeService.getMMTI0259VO(jmvo1);
		
		int insertRow = 0;
		
		// VO SET
		mbtr01001vo.setPboxNo(jmvo.getSms_ts_bvan());
		mbtr01001vo.setApdxFlRutNm("");
		mbtr01001vo.setFrstIpmnEmpno("82101685");
		mbtr01001vo.setFnalAmdrEmpno("82101685");
		
		insertRow = mileageTobeService.insertTest(mbtr01001vo);
		if(insertRow < 1){
			logger.info("#### 사서함번호: " + StringUtil.nvl(mbtr01001vo.getPboxNo()) + "####");
			logger.info("#### insert 결과: Fail ####");
		}else{
			logger.info("#### insert 결과: Success ####");
		}
		
		map.put("errorCode", jmvo1.getErrorCode());
			
		return map;
	}
	
	@RequestMapping(value="/mileageBlackBoxFileUpload")
	public @ResponseBody Map<String, String> mileageBlackBoxFileUpload(MultipartHttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		Map<String, String> map = new HashMap<String, String>();
		
		MMTI0213VO jmvo = new MMTI0213VO();
		MBTR01001VO mbtr01001vo = new MBTR01001VO();
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("num")));
		jmvo = mileageTobeService.getMMTI0213VO(jmvo);

		mbtr01001vo = mileageTobeService.regInfoToEdmsForMobileWeb(request, jmvo.getSms_ts_bvan(), mbtr01001vo);
		
		MMTI0259VO jmvo1 = new MMTI0259VO();
		jmvo1.setPbox_use_yn("1");
		jmvo1.setPbox_no(jmvo.getSms_ts_bvan());
		jmvo1.setPhgp_cnfm_dt(DateUtil.getDate("yyyymmdd"));
		jmvo1.setPhgp_strg_yn("1");
		
		if("1".equals(jmvo.getPbox_no_dvcd()) && !"1".equals(jmvo.getCm_yn())) {
			if("03".equals(jmvo.getProc_dvn())) {
				jmvo1.setPbox_chr_nm(request.getParameter("mileage1") + "/" + request.getParameter("mileage2"));
			}
			else {
				jmvo1.setPbox_chr_nm(request.getParameter("mileage1"));
			}
		}
		jmvo1 = mileageTobeService.getMMTI0259VO(jmvo1);
		
		int insertRow = 0;
		
		// VO SET
		mbtr01001vo.setPboxNo(jmvo.getSms_ts_bvan());
		mbtr01001vo.setApdxFlRutNm("");
		mbtr01001vo.setFrstIpmnEmpno("82101685");
		mbtr01001vo.setFnalAmdrEmpno("82101685");
		
		insertRow = mileageTobeService.insertTest(mbtr01001vo);
		if(insertRow < 1){
			logger.info("#### 사서함번호: " + StringUtil.nvl(mbtr01001vo.getPboxNo()) + "####");
			logger.info("#### insert 결과: Fail ####");
		}else{
			logger.info("#### insert 결과: Success ####");
		}
		
		map.put("errorCode", jmvo1.getErrorCode());
			
		return map;
	}
	
	// 이륜차 블랙박스 장착 - OCR 인식 제외, EDMS을 이용하여 사진전송
	@RequestMapping(value="/blackBoxFileUpload")
	public @ResponseBody Map<String, String> blackBoxFileUpload(MultipartHttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		Map<String, String> map = new HashMap<String, String>();
		
		MMTI0213VO jmvo = new MMTI0213VO();
		MBTR01001VO mbtr01001vo = new MBTR01001VO();
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("num")));
//		jmvo.setSms_ts_bvan(aes256Decrypt("Q0043373"));
		jmvo.setMtcc_yn(request.getParameter("mtcc_yn"));
		String checkYn = request.getParameter("checkYn");
		logger.debug(">>>> blackBoxFileUpload checkYn = " + checkYn);
		jmvo = mileageTobeService.getMMTI0213VO(jmvo);

		mbtr01001vo = mileageTobeService.regInfoToEdmsForMobileWeb2(request, jmvo.getSms_ts_bvan(), mbtr01001vo);
		
		MMTI0259VO jmvo1 = new MMTI0259VO();
		jmvo1.setPbox_use_yn("1");
		jmvo1.setPbox_no(jmvo.getSms_ts_bvan());
		jmvo1.setPhgp_cnfm_dt(DateUtil.getDate("yyyymmdd"));
		jmvo1.setPhgp_strg_yn("1");
		
		jmvo1 = mileageTobeService.getMMTI0259VO(jmvo1);
		
		int insertRow = 0;
		
		// VO SET
		mbtr01001vo.setPboxNo(jmvo.getSms_ts_bvan());
		mbtr01001vo.setApdxFlRutNm("");
		mbtr01001vo.setFrstIpmnEmpno("82101685");
		mbtr01001vo.setFnalAmdrEmpno("82101685");
		
		insertRow = mileageTobeService.insertTest(mbtr01001vo);
		if(insertRow < 1){
			logger.info("#### 사서함번호: " + StringUtil.nvl(mbtr01001vo.getPboxNo()) + "####");
			logger.info("#### insert 결과: Fail ####");
		}else{
			logger.info("#### insert 결과: Success ####");
		}
		
		map.put("errorCode", jmvo1.getErrorCode());
			
		return map;
	}

	private String aes256Decrypt(String enc) {
		String dec = "";
		String encKey = mileageTobeService.getEncKey();
		
		try {
			dec = DMEncDecUtil.decAES256(enc, null, null, encKey);
		}
		catch(Exception e) {
			logger.debug("DMEncDecUtil.decAES256 실패 시 js로 복호화");
			
			String path = this.getClass().getResource("").getPath();
			logger.debug(path);
			
			// [200617]
			BufferedReader in = null;
			
			try {
				String aesJs = path.substring(0, path.indexOf("/classes/")) + "/aes/gibberish-aes.js";
				if(aesJs.startsWith("/")) aesJs = aesJs.substring(1);
				String cmd = "cscript " + aesJs + " " + encKey  + " " + enc;
				logger.debug("cmd: " + cmd);
				Process p = Runtime.getRuntime().exec(cmd);
				// [200617]
				in = new BufferedReader(new InputStreamReader(p.getInputStream()));
		
				String line = null;  
				boolean flag = false;
				while (true) {
					line = in.readLine();
					if(line == null) break;
					logger.debug(line);
					dec = line;
					if(flag) break;
					if(dec.startsWith("enc: ")) flag = true;
				}
				
				if(dec.startsWith("enc: ")) {
					dec = dec.substring(5);
				}
		
				in.close();
				// [200617]
				in = null;
			}
			catch(Exception e1) {
				return null;
			}
			// [200617]
			finally{
				try{
					if(in!=null){
						in.close();
					}
				}catch(IOException ee){
					System.err.println("[MileageTobeController.aes256Decrypt()] IOException");
				}
			}
		}
		return dec;
	}
 
	private String aes256Encrypt(String plainText) {
		String enc = "";
		String encKey = mileageTobeService.getEncKey();
		
		try {
			enc = DMEncDecUtil.encAES256(plainText, null, null, encKey);
		}
		catch(Exception e) {
			logger.debug("DMEncDecUtil.encAES256 실패 시 js로 암호화");
			
			String path = this.getClass().getResource("").getPath();
			logger.debug(path);
			// [200617]
			BufferedReader in = null;
			
			try {
				String aesJs = path.substring(0, path.indexOf("/classes/")) + "/aes/gibberish-aes-2.js";
				if(aesJs.startsWith("/")) aesJs = aesJs.substring(1);
				String cmd = "cscript " + aesJs + " " + encKey  + " " + plainText;
				logger.debug("cmd: " + cmd);
				Process p = Runtime.getRuntime().exec(cmd);
				// [200617]
				in = new BufferedReader(new InputStreamReader(p.getInputStream()));
		
				String line = null;
				boolean flag = false;
				while (true) {
					line = in.readLine();
					if(line == null) break;
					logger.debug(line);
					enc = line;
					if(flag) break;
					if(enc.startsWith("plain_text: ")) flag = true;
				}
				
				if(enc.startsWith("plain_text: ")) {
					enc = enc.substring(12);
				}
		
				in.close();
				// [200617]
				in = null;
			}
			catch(Exception e1) {
				return null;
			}
			// [200617]
			finally{
				try{
					if(in!=null){
						in.close();
					}
				}catch(IOException ee){
					System.err.println("[MileageTobeController.aes256Encrypt()] IOException");
				}
			}
		}
		return enc;
	}
		
	// 자차보험 
	@RequestMapping(value="/mycar01")
	public String mycar01(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		String no = request.getParameter("no");
		
		MMTI0289VO jmvo = new MMTI0289VO();
		jmvo.setMbl_snd_no(aes256Decrypt(no));
		jmvo = mileageTobeService.getMMTI0289VO(jmvo);

		request.setAttribute("no", no);
		request.setAttribute("jmvo", jmvo);
		return "/counter/carrider/tobe/mycar01";
	}

	@RequestMapping(value="/mycar02")
	public String mycar02(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		String no = request.getParameter("no");
		
		MMTI0289VO jmvo = new MMTI0289VO();
		jmvo.setMbl_snd_no(aes256Decrypt(no));
		jmvo = mileageTobeService.getMMTI0289VO(jmvo);

		request.setAttribute("no", no);
		request.setAttribute("jmvo", jmvo);
		return "/counter/carrider/tobe/mycar02";
	}

	@RequestMapping(value="/mycarFileUpload")
	public @ResponseBody Map<String, String> mycarFileUpload(MultipartHttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		Map<String, String> map = new HashMap<String, String>();
		String no = request.getParameter("no");
		
		MMTI0289VO jmvo = new MMTI0289VO();
		jmvo.setMbl_snd_no(aes256Decrypt(no));
		jmvo = mileageTobeService.getMMTI0289VO(jmvo);

		try {
			mileageTobeService.regInfoToEdmsForMobileWeb(request, jmvo);
			map.put("errorCode", "0");
		}
		catch(Exception e) {
			logger.debug(StringUtil.getStackTraceString(e));
			map.put("errorCode", "-1");
		}
		
		return map;
	}
	
/*	
	// 자차보험 (aiocr용)
	@RequestMapping(value="/aiocrMycar01")
	public String aiocrMycar01(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		String no = request.getParameter("no");
		
		MMTI0289VO jmvo = new MMTI0289VO();
		jmvo.setMbl_snd_no(aes256Decrypt(no));
		jmvo = mileageTobeService.getMMTI0289VO(jmvo);

		request.setAttribute("no", no);
		request.setAttribute("jmvo", jmvo);
		return "/counter/carrider/tobe/aiocrMycar01";
	}
	
	//aiocr용
	@RequestMapping(value="/aiocrMycar02")
	public String aiocrMycar02(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		String no = request.getParameter("no");
		
		MMTI0289VO jmvo = new MMTI0289VO();
		jmvo.setMbl_snd_no(aes256Decrypt(no));
		jmvo = mileageTobeService.getMMTI0289VO(jmvo);

		request.setAttribute("no", no);
		request.setAttribute("jmvo", jmvo);
		return "/counter/carrider/tobe/aiocrMycar02";
	}
	
	//aiocr용
	@RequestMapping(value="/aiocrMycarFileUpload")
	public @ResponseBody Map<String, String> aiocrMycarFileUpload(MultipartHttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		Map<String, String> map = new HashMap<String, String>();
		String no = request.getParameter("no");
		
		MMTI0289VO jmvo = new MMTI0289VO();
		jmvo.setMbl_snd_no(aes256Decrypt(no));
		jmvo = mileageTobeService.getMMTI0289VO(jmvo);

		try {
			mileageTobeService.aiocrRegInfoToEdmsForMobileWeb(request, jmvo);
			map.put("errorCode", "0");
		}
		catch(Exception e) {
			logger.debug(StringUtil.getStackTraceString(e));
			map.put("errorCode", "-1");
		}
		
		return map;
	}
*/
	
/*
	@RequestMapping(value="/uploadForm")
	public void uploadForm() {
		logger.info("upload form");
	}
	@RequestMapping(value="/uploadFormAction")
	public void uploadFormAction(MultipartFile[] Files, Model model){
		String uploadFolder = "http://10.10.88.61:5000/api/carDrivingDistance";
		for(MultipartFile multipartFile : Files){
			logger.info("------------------------------------");
			logger.info("Upload File Name : " + multipartFile.getOriginalFilename());
			logger.info("Upload File Size : " + multipartFile.getSize());
			logger.info("------------------------------------");
			File saveFile = new File(uploadFolder, multipartFile.getOriginalFilename());
			try{
				multipartFile.transferTo(saveFile);
			} catch(Exception e) {
				logger.info(e.getMessage());
			}
		}
	}
*/
	
	@RequestMapping(value="/aiocr_ml1")
	public String aiocr_ml1(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		HttpSession session = request.getSession();
		
		MMTI0213VO jmvo = new MMTI0213VO();
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("p")));
		jmvo = mileageTobeService.getMMTI0213VO(jmvo);

		request.setAttribute("p", request.getParameter("p"));
		request.setAttribute("jmvo", jmvo);
		
		if(!StringUtil.isEmpty(request.getParameter("appSeq"))){
			session.setAttribute("appSeq", StringUtil.nvl(request.getParameter("appSeq")));
		}
		if(!StringUtil.isEmpty(request.getParameter("webSeq"))){
			session.setAttribute("webSeq", StringUtil.nvl(request.getParameter("webSeq")));
		}
		
		return "/counter/carrider/tobe/aiocr_ml1";
	}
	
	@RequestMapping(value="/aiocr_ml2")
	public String aiocr_ml2(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		MMTI0213VO jmvo = new MMTI0213VO();
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("p")));
		jmvo = mileageTobeService.getMMTI0213VO(jmvo);
		
		request.setAttribute("p", request.getParameter("p"));
		request.setAttribute("jmvo", jmvo);
		return "/counter/carrider/tobe/aiocr_ml2";
	}
	
	@RequestMapping(value="/aiocr_ml2_1")
	public String aiocr_ml2_1(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		MMTI0213VO jmvo = new MMTI0213VO();
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("p")));
		jmvo = mileageTobeService.getMMTI0213VO(jmvo);
		
		HttpSession session = request.getSession();
		Object[] imgfile = (Object[]) session.getAttribute("imgfile");
		if(imgfile != null) {
			byte[] file = (byte[]) imgfile[0];
			logger.debug("file.length: " + file.length);
			request.setAttribute("imgsrc", "data:image/jpeg;base64," + new String(Base64.encodeBase64(file)));
		}
		
		request.setAttribute("p", request.getParameter("p"));
		session.setAttribute("p", request.getParameter("p"));
		request.setAttribute("jmvo", jmvo);
		return "/counter/carrider/tobe/aiocr_ml2_1";
	}
	
	@RequestMapping(value="/ml1")
	public String ml1(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		HttpSession session = request.getSession();
		
		MMTI0213VO jmvo = new MMTI0213VO();
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("p")));
		jmvo = mileageTobeService.getMMTI0213VO(jmvo);

		request.setAttribute("p", request.getParameter("p"));
		request.setAttribute("jmvo", jmvo);
		
		if(!StringUtil.isEmpty(request.getParameter("appSeq"))){
			session.setAttribute("appSeq", StringUtil.nvl(request.getParameter("appSeq")));
		}
		if(!StringUtil.isEmpty(request.getParameter("webSeq"))){
			session.setAttribute("webSeq", StringUtil.nvl(request.getParameter("webSeq")));
		}
		
		return "/counter/carrider/tobe/ml1";
	}	
	
	@RequestMapping(value="/ml2")
	public String ml2(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		MMTI0213VO jmvo = new MMTI0213VO();
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("p")));
		jmvo = mileageTobeService.getMMTI0213VO(jmvo);
		
		request.setAttribute("p", request.getParameter("p"));
		request.setAttribute("jmvo", jmvo);
		return "/counter/carrider/tobe/ml2";
	}

	@RequestMapping(value="/ml2_1")
	public String ml2_1(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		MMTI0213VO jmvo = new MMTI0213VO();
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("p")));
		jmvo = mileageTobeService.getMMTI0213VO(jmvo);
		
		HttpSession session = request.getSession();
		Object[] imgfile = (Object[]) session.getAttribute("imgfile");
		if(imgfile != null) {
			byte[] file = (byte[]) imgfile[0];
			logger.debug("file.length: " + file.length);
			request.setAttribute("imgsrc", "data:image/jpeg;base64," + new String(Base64.encodeBase64(file)));
		}
		
		request.setAttribute("p", request.getParameter("p"));
		session.setAttribute("p", request.getParameter("p"));
		request.setAttribute("jmvo", jmvo);
		return "/counter/carrider/tobe/ml2_1";
	}
	
	@RequestMapping(value="/ml3")
	public String ml3(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		HttpSession session = request.getSession();
		MMTI0213VO jmvo = new MMTI0213VO();		
		MBTT02001VO mbtt02001vo = new MBTT02001VO();
		String scrnNm = "ml3";
		
		//jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("p")));
//		jmvo.setSms_ts_bvan(aes256Decrypt((String)session.getAttribute("p")));
		jmvo.setSms_ts_bvan(StringUtil.nvl(aes256Decrypt((String)session.getAttribute("p"))));
		
		jmvo = mileageTobeService.getMMTI0213VO(jmvo);
		
//		session.setAttribute("pbox_no", jmvo.getSms_ts_bvan());
		session.setAttribute("pbox_no", StringUtil.nvl(jmvo.getSms_ts_bvan()));
		
		logger.info("###### ml3 테스트1 ######");
		logger.info("###### request ######");
		logger.info("###### plno: " + StringUtil.nvl(request.getParameter("plno")));
		logger.info("###### plan_no: " + StringUtil.nvl(request.getParameter("exp_exca_plan_no")));
		logger.info("###### pdc_sr_dvn: " + StringUtil.nvl(request.getParameter("pdc_sr_dvn")));
		logger.info("###### adc_rtrn_dvn: " + StringUtil.nvl(request.getParameter("adc_rtrn_dvn")));
		logger.info("###### adc_rtrn_prm: " + StringUtil.nvl(request.getParameter("adc_rtrn_prm")));
		logger.info("###### exp_exca_plan_rsl_cd: " + StringUtil.nvl(request.getParameter("exp_exca_plan_rsl_cd")));
		logger.info("###### cnv_trv_dstc: " + StringUtil.nvl(request.getParameter("cnv_trv_dstc")));
		logger.info("###### aut_cgnt_trv_dstc: " + StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc")));
		logger.info("###### mtcc_yn: " + StringUtil.nvl(request.getParameter("mtcc_yn")));
		logger.info("###### trv_dstc_exp_exca_dvcd: " + StringUtil.nvl(request.getParameter("trv_dstc_exp_exca_dvcd")));
		logger.info("###### trv_dstc_chng_aply_dvn: " + StringUtil.nvl(request.getParameter("trv_dstc_chng_aply_dvn")));
		logger.info("###### hdlr_empno: " + StringUtil.nvl(request.getParameter("hdlr_empno")));
		
		logger.info("###### ml3 테스트2 ######");
		logger.info("###### session ######");
		logger.info("###### plno: " + StringUtil.nvl((String)session.getAttribute("plno")));
		logger.info("###### plan_no: " + StringUtil.nvl((String)session.getAttribute("exp_exca_plan_no")));
		logger.info("###### pdc_sr_dvn: " + StringUtil.nvl((String)session.getAttribute("pdc_sr_dvn")));
		logger.info("###### adc_rtrn_dvn: " + StringUtil.nvl((String)session.getAttribute("adc_rtrn_dvn")));
		logger.info("###### adc_rtrn_prm: " + String.valueOf(session.getAttribute("adc_rtrn_prm")));
		logger.info("###### scrn_proc_cd: " + StringUtil.nvl((String)session.getAttribute("exp_exca_plan_rsl_cd")));
		
//		String exp_exca_plan_rsl_cd = request.getParameter("exp_exca_plan_rsl_cd");
		String exp_exca_plan_rsl_cd = (String)session.getAttribute("exp_exca_plan_rsl_cd");
		
		// 간편정산 -> 설계보관/추징 등 아니면 다 확정요청
		if("1".equals(jmvo.getTrv_dstc_splc_exca_yn())) {
			if(exp_exca_plan_rsl_cd.equals("11") || exp_exca_plan_rsl_cd.equals("13") || exp_exca_plan_rsl_cd.equals("14")) {
				// [200617]
				MMTI0291VO jmvo1 = new MMTI0291VO();
				jmvo1.setTrv_dstc_exca_mtt__exca_bz_proc_dvn("2");
				jmvo1.setTrv_dstc_exca_mtt__plno(StringUtil.nvl(request.getParameter("plno")));
				jmvo1.setTrv_dstc_exca_mtt__plan_no(StringUtil.nvl(request.getParameter("exp_exca_plan_no")));
				jmvo1.setTrv_dstc_exca_mtt__exca_rtrn_dvn("");
				jmvo1.setTrv_dstc_exca_mtt__pdc_sr_dvn(StringUtil.nvl(request.getParameter("pdc_sr_dvn")));
				jmvo1.setTrv_dstc_exca_mtt__adc_rtrn_dvn(StringUtil.nvl(request.getParameter("adc_rtrn_dvn")));
				jmvo1.setTrv_dstc_exca_mtt__adc_rtrn_prm(StringUtil.nvl(request.getParameter("adc_rtrn_prm")));
				jmvo1.setTrv_dstc_exca_mtt__scrn_proc_cd(StringUtil.nvl(request.getParameter("exp_exca_plan_rsl_cd")));
				jmvo1.setTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn(jmvo.getTrv_dstc_splc_exca_yn());
				jmvo1.setTrv_dstc_exca_mtt__pbox_no(jmvo.getSms_ts_bvan());
				jmvo1 = mileageTobeService.getMMTI0291VO(jmvo1);
				
				request.setAttribute("z_resp_cd", jmvo1.getZ_resp_cd());
				request.setAttribute("z_resp_msg", jmvo1.getZ_resp_msg());
				session.setAttribute("z_resp_cd", jmvo1.getZ_resp_cd());
				session.setAttribute("z_resp_msg", jmvo1.getZ_resp_msg());
				
				// 이미지 중복이면 확정신청페이지
				if("1".equals(jmvo1.getTrv_dstc_exca_mtt__imag_dup_yn())){
					exp_exca_plan_rsl_cd = "14";
				}
					
				/*request.setAttribute("imag_dup_yn", jmvo1.getTrv_dstc_exca_mtt__imag_dup_yn());	// 중복여부
				request.setAttribute("imag_rsl_cd", jmvo1.getTrv_dstc_exca_mtt__rsl_cd());			// 결과코드
				request.setAttribute("imag_rsl_msg", jmvo1.getTrv_dstc_exca_mtt__rsl_msg());*/		// 결과메시지
				
				// CM 상품이고, 화면처리코드 IN(02, 14) or 이미지 중복
				if("CM".equals(jmvo1.getTrv_dstc_exca_mtt__pdc_sr_dvn()) && 
						("02".equals(jmvo1.getTrv_dstc_exca_mtt__scrn_proc_cd())
						|| "14".equals(jmvo1.getTrv_dstc_exca_mtt__scrn_proc_cd()))){
					
					MMTI0015VO mmti0015vo = new MMTI0015VO();
					mmti0015vo.setFunt_key("00");
					mmti0015vo.setPlan_no(jmvo1.getTrv_dstc_exca_mtt__plan_no());
					mmti0015vo = mileageTobeService.getMMTI0015VO(mmti0015vo);
					
					logger.debug("##### MMTI0015 시작 ##########################");
					logger.debug("##### 고객식별번호: " + mmti0015vo.getPlhd__cust_dcmt_no() + " ##########################");
					logger.debug("##### 고객번호: " + mmti0015vo.getPlhd__cust_no() + " ##########################");
					logger.debug("##### 고객명: " + mmti0015vo.getPlhd__cust_nm() + " ##########################");
					logger.debug("##### 이메일: " + mmti0015vo.getPlhd__eml() + " ##########################");
					logger.debug("##### 지역번호: " + mmti0015vo.getPlhd_cntp_if__tlp_arno() + " ##########################");
					logger.debug("##### 국번호: " + mmti0015vo.getPlhd_cntp_if__tlp_ofno() + " ##########################");
					logger.debug("##### 개별번호: " + mmti0015vo.getPlhd_cntp_if__tlp_idvno() + " ##########################");
					
					XTEM0021VO xtem0021vo = new XTEM0021VO();
					xtem0021vo.setCnsl_rpt_no("");						// 상담접수번호				
					xtem0021vo.setCm_bz_dvcd("05");
					xtem0021vo.setCnsl_typ_dvcd("07");
					xtem0021vo.setCm_plan_no(jmvo1.getTrv_dstc_exca_mtt__plan_no());
					xtem0021vo.setCnsl_rpy_dvcd("1");
					xtem0021vo.setCnsl_rpt_dttm(getDayTime());			// 현재년월일시분초 14자리
					xtem0021vo.setCust_nm(mmti0015vo.getPlhd__cust_nm());
					xtem0021vo.setCust_no(mmti0015vo.getPlhd__cust_no());
					
					String cust_dcmt_no = SeedUtil.decrypt(mmti0015vo.getPlhd__cust_dcmt_no());
					
					if("1".equals(cust_dcmt_no.substring(6, 7)) || "2".equals(cust_dcmt_no.substring(6, 7))
						|| "5".equals(cust_dcmt_no.substring(6, 7)) || "6".equals(cust_dcmt_no.substring(6, 7))){
						xtem0021vo.setBrth("19" + cust_dcmt_no.substring(0, 6));
					} else{
						xtem0021vo.setBrth("20" + cust_dcmt_no.substring(0, 6));
					}
					// xtem0021vo.setBrth("");  							// 생년월일
					xtem0021vo.setSx_cd(cust_dcmt_no.substring(6, 7));
					xtem0021vo.setEml_adr(mmti0015vo.getPlhd__eml());
					xtem0021vo.setClp_tlcno(mmti0015vo.getPlhd_cntp_if__tlp_arno());
					xtem0021vo.setClp_ofno(mmti0015vo.getPlhd_cntp_if__tlp_ofno());
					xtem0021vo.setClp_idvno(mmti0015vo.getPlhd_cntp_if__tlp_idvno());
					xtem0021vo.setCnsl_rsvt_dt("99990101");
					xtem0021vo.setCnsl_rsvt_time_cd("1");
					xtem0021vo.setCnsl_cn("최종주행거리사진등록/만기정산");
					xtem0021vo.setCnsl_aply_csn_yn("1");
					xtem0021vo.setUrl_adr("");
					xtem0021vo.setCm_ctrmf_tpcd("32");
					xtem0021vo.setFrst_ipmn_empno("80000028");
					xtem0021vo.setFrst_ipnpt_dttm(getDayTime());		// 현재년월일시분초 14자리	
					
					xtem0021vo = mileageTobeService.getXTEM0021VO(xtem0021vo);
					logger.debug("##### XTEM0021 시작 ##########################");
					logger.debug("##### 처리결과: [ " + xtem0021vo.getProc_rtn() + " ] ##########################");
				}
				
				//MMTI0291
				if("".equals(jmvo.getSms_ts_bvan()) || null == jmvo.getSms_ts_bvan()){
					mbtt02001vo.setPboxNo(" ");
				} else {
					mbtt02001vo.setPboxNo(StringUtil.nvl(jmvo.getSms_ts_bvan()));
				}
				mbtt02001vo.setTlgIdVal("MMTI0291");
				mbtt02001vo.setEsbTrscId(StringUtil.nvl(jmvo1.getZ_trsc_id()));
				if("".equals(jmvo1.getTrv_dstc_exca_mtt__plno()) || null == jmvo1.getTrv_dstc_exca_mtt__plno()){
					mbtt02001vo.setPlno(" ");
				} else {
					mbtt02001vo.setPlno(StringUtil.nvl(jmvo1.getTrv_dstc_exca_mtt__plno()));
				}
				if("".equals(jmvo1.getTrv_dstc_exca_mtt__plan_no()) || null == jmvo1.getTrv_dstc_exca_mtt__plan_no()){
					mbtt02001vo.setPlanNo(" ");
				} else {
					mbtt02001vo.setPlanNo(StringUtil.nvl(jmvo1.getTrv_dstc_exca_mtt__plan_no()));
				}
				if("".equals(jmvo1.getTrv_dstc_exca_mtt__rnw_plno()) || null == jmvo1.getTrv_dstc_exca_mtt__rnw_plno()){
					mbtt02001vo.setRnwPlno(" ");
				} else {
					mbtt02001vo.setRnwPlno(StringUtil.nvl(jmvo1.getTrv_dstc_exca_mtt__rnw_plno()));
				}
				mbtt02001vo.setTlgProcRslCdVal(StringUtil.nvl(jmvo1.getZ_tlg_sp_cd()));
				mbtt02001vo.setTlgErrCdVal(StringUtil.nvl(jmvo1.getZ_trns_org_dvcd())+StringUtil.nvl(jmvo1.getZ_trns_org_cd()));
				if("".equals(jmvo1.getTrv_dstc_exca_mtt__hdlr_empno()) || null == jmvo1.getTrv_dstc_exca_mtt__hdlr_empno()){
					mbtt02001vo.setHdlrEmpno(" ");
				} else {
					mbtt02001vo.setHdlrEmpno(StringUtil.nvl(jmvo1.getTrv_dstc_exca_mtt__hdlr_empno()));
				}
				if("".equals(jmvo.getPbox_no_dvcd()) || null == jmvo.getPbox_no_dvcd()){
					mbtt02001vo.setPboxNoDvcd(" ");
				} else {
					mbtt02001vo.setPboxNoDvcd(StringUtil.nvl(jmvo.getPbox_no_dvcd()));
				}
				if("".equals(jmvo.getProc_dvn()) || null == jmvo.getProc_dvn()){
					mbtt02001vo.setProcDvn(" ");
				} else {
					mbtt02001vo.setProcDvn(StringUtil.nvl(jmvo.getProc_dvn()));
				}
				if("".equals(jmvo.getTrv_dstc_exp_exca_dvcd()) || null == jmvo.getTrv_dstc_exp_exca_dvcd()){
					mbtt02001vo.setTrvDstcExpExcaDvcd(" ");
				} else {
					mbtt02001vo.setTrvDstcExpExcaDvcd(StringUtil.nvl(jmvo.getTrv_dstc_exp_exca_dvcd()));
				}
				if("".equals(jmvo.getTrv_dstc_chng_aply_dvn()) || null == jmvo.getTrv_dstc_chng_aply_dvn()){
					mbtt02001vo.setTrvDstcChngAplyDvn(" ");
				} else {
					mbtt02001vo.setTrvDstcChngAplyDvn(StringUtil.nvl(jmvo.getTrv_dstc_chng_aply_dvn()));
				}
				if("".equals(jmvo.getHdlr_fire_yn()) || null == jmvo.getHdlr_fire_yn()){
					mbtt02001vo.setHdlrFireYn(" ");
				} else {
					mbtt02001vo.setHdlrFireYn(StringUtil.nvl(jmvo.getHdlr_fire_yn()));
				}
				if("".equals(jmvo.getMtcc_yn()) || null == jmvo.getMtcc_yn()){
					mbtt02001vo.setMtccYn(" ");
				} else {
					mbtt02001vo.setMtccYn(StringUtil.nvl(jmvo.getMtcc_yn()));
				}
				if("".equals(request.getParameter("aut_cgnt_trv_dstc")) || null == request.getParameter("aut_cgnt_trv_dstc")){
					mbtt02001vo.setAutCgntTrvDstc(0);
				} else {
					mbtt02001vo.setAutCgntTrvDstc(Double.parseDouble(request.getParameter("aut_cgnt_trv_dstc")));
				}
				if("".equals(jmvo1.getTrv_dstc_exca_mtt__aut_cgnt_trv_dstc_rsl_cd()) || null == jmvo1.getTrv_dstc_exca_mtt__aut_cgnt_trv_dstc_rsl_cd()){
					mbtt02001vo.setAutCgntTrvDstcRslCd(" ");
				} else {
					mbtt02001vo.setAutCgntTrvDstcRslCd(StringUtil.nvl(jmvo1.getTrv_dstc_exca_mtt__aut_cgnt_trv_dstc_rsl_cd()));
				}
				if("".equals(request.getParameter("inptTrvDstc")) || null == request.getParameter("inptTrvDstc")){
					mbtt02001vo.setInptTrvDstc(0);
				} else {
					mbtt02001vo.setInptTrvDstc(Double.parseDouble(request.getParameter("inptTrvDstc")));
				}
				if("".equals(jmvo1.getTrv_dstc_exca_mtt__cnv_trv_dstc()) || null == jmvo1.getTrv_dstc_exca_mtt__cnv_trv_dstc()){
					mbtt02001vo.setCnvTrvDstc(0);
				} else {
					mbtt02001vo.setCnvTrvDstc(Double.parseDouble(jmvo1.getTrv_dstc_exca_mtt__cnv_trv_dstc()));
				}
				if("".equals(request.getParameter("exp_exca_plan_rsl_cd")) || null == request.getParameter("exp_exca_plan_rsl_cd")){
					mbtt02001vo.setExpExcaPlanRslCd(" ");
				} else {
					mbtt02001vo.setExpExcaPlanRslCd(StringUtil.nvl(request.getParameter("exp_exca_plan_rsl_cd")));
				}
				if("".equals(jmvo1.getTrv_dstc_exca_mtt__exca_bz_proc_dvn()) || null == jmvo1.getTrv_dstc_exca_mtt__exca_bz_proc_dvn()){
					mbtt02001vo.setExcaBzProcDvn(" ");
				} else {
					mbtt02001vo.setExcaBzProcDvn(StringUtil.nvl(jmvo1.getTrv_dstc_exca_mtt__exca_bz_proc_dvn()));
				}
				if("".equals(jmvo1.getTrv_dstc_exca_mtt__exca_rtrn_dvn()) || null == jmvo1.getTrv_dstc_exca_mtt__exca_rtrn_dvn()){
					mbtt02001vo.setExcaRtrnDvn(" ");
				} else {
					mbtt02001vo.setExcaRtrnDvn(StringUtil.nvl(jmvo1.getTrv_dstc_exca_mtt__exca_rtrn_dvn()));
				}
				if("".equals(jmvo1.getTrv_dstc_exca_mtt__pdc_sr_dvn()) || null == jmvo1.getTrv_dstc_exca_mtt__pdc_sr_dvn()){
					mbtt02001vo.setPdcSrDvn(" ");
				} else {
					mbtt02001vo.setPdcSrDvn(StringUtil.nvl(jmvo1.getTrv_dstc_exca_mtt__pdc_sr_dvn()));
				}
				if("".equals(jmvo1.getTrv_dstc_exca_mtt__adc_rtrn_prm()) || null == jmvo1.getTrv_dstc_exca_mtt__adc_rtrn_prm()){
					mbtt02001vo.setAdcRtrnPrm(0);
				} else {
					mbtt02001vo.setAdcRtrnPrm(Double.parseDouble(jmvo1.getTrv_dstc_exca_mtt__adc_rtrn_prm()));
				}
				if("".equals(jmvo1.getTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn()) || null == jmvo1.getTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn()){
					mbtt02001vo.setTrvDstcSplcExcaYn(" ");
				} else {
					mbtt02001vo.setTrvDstcSplcExcaYn(StringUtil.nvl(jmvo1.getTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn()));
				}
				if("".equals(jmvo1.getTrv_dstc_exca_mtt__imag_dup_yn()) || null == jmvo1.getTrv_dstc_exca_mtt__imag_dup_yn()){
					mbtt02001vo.setImagDupYn(" ");
				} else {
					mbtt02001vo.setImagDupYn(StringUtil.nvl(jmvo1.getTrv_dstc_exca_mtt__imag_dup_yn()));
				}
				if("".equals(jmvo1.getTrv_dstc_exca_mtt__nrm_proc_yn()) || null == jmvo1.getTrv_dstc_exca_mtt__nrm_proc_yn()){
					mbtt02001vo.setNrmProcYn(" ");
				} else {
					mbtt02001vo.setNrmProcYn(StringUtil.nvl(jmvo1.getTrv_dstc_exca_mtt__nrm_proc_yn()));
				}
				if("".equals(request.getParameter("crdScnCnclPssYn")) || null == request.getParameter("crdScnCnclPssYn")){
					mbtt02001vo.setCrdScnCnclPssYn(" ");
				} else {
					mbtt02001vo.setCrdScnCnclPssYn(StringUtil.nvl(request.getParameter("crdScnCnclPssYn")));
				}
				mbtt02001vo.setRespCn(StringUtil.nvl(jmvo1.getZ_resp_cd()));
				mbtt02001vo.setRslCn(scrnNm + "_" + StringUtil.nvl(jmvo1.getZ_resp_msg()));
				mbtt02001vo.setFrstIpmnEmpno("82101685");
				mbtt02001vo.setFnalAmdrEmpno("82101685");
				if("".equals(jmvo1.getTrv_dstc_exca_mtt__adc_rtrn_dvn()) || null == jmvo1.getTrv_dstc_exca_mtt__adc_rtrn_dvn()){
					mbtt02001vo.setAdcRtrnDvn(" ");
				} else {
					mbtt02001vo.setAdcRtrnDvn(StringUtil.nvl(jmvo1.getTrv_dstc_exca_mtt__adc_rtrn_dvn()));
				}
				if("".equals(jmvo1.getTrv_dstc_exca_mtt__scrn_proc_cd()) || null == jmvo1.getTrv_dstc_exca_mtt__scrn_proc_cd()){
					mbtt02001vo.setScrnProcCd(" ");
				} else {
					mbtt02001vo.setScrnProcCd(StringUtil.nvl(jmvo1.getTrv_dstc_exca_mtt__scrn_proc_cd()));
				}
				if("".equals(request.getParameter("ctc_plno")) || null == request.getParameter("ctc_plno")){
					mbtt02001vo.setCtcPlno(" ");
				} else {
					mbtt02001vo.setCtcPlno(StringUtil.nvl(request.getParameter("ctc_plno")));
				}
				if("".equals(request.getParameter("trv_dstc_proc_dvcd")) || null == request.getParameter("trv_dstc_proc_dvcd")){
					mbtt02001vo.setTrvDstcProcDvcd(" ");
				} else {
					mbtt02001vo.setTrvDstcProcDvcd(StringUtil.nvl(request.getParameter("trv_dstc_proc_dvcd")));
				}
				if("".equals(request.getParameter("mbl_snd_no")) || null == request.getParameter("mbl_snd_no")){
					mbtt02001vo.setMblSndNo(" ");
				} else {
					mbtt02001vo.setMblSndNo(StringUtil.nvl(request.getParameter("mbl_snd_no")));
				}
				if("".equals(request.getParameter("plan_plno_dvcd")) || null == request.getParameter("plan_plno_dvcd")){
					mbtt02001vo.setPlanPlnoDvcd(" ");
				} else {
					mbtt02001vo.setPlanPlnoDvcd(StringUtil.nvl(request.getParameter("plan_plno_dvcd")));
				}
				if("".equals(request.getParameter("plan_plno")) || null == request.getParameter("plan_plno")){
					mbtt02001vo.setPlanPlno(" ");
				} else {
					mbtt02001vo.setPlanPlno(StringUtil.nvl(request.getParameter("plan_plno")));
				}
				if("".equals(jmvo.getChng_plan_no()) || null == jmvo.getChng_plan_no()){
					mbtt02001vo.setChngPlanNo(" ");
				} else {
					mbtt02001vo.setChngPlanNo(StringUtil.nvl(jmvo.getChng_plan_no()));
				}
				if("".equals(request.getParameter("dst_tty_dvn1")) || null == request.getParameter("dst_tty_dvn1")){
					mbtt02001vo.setDstTtyDvn1(" ");
				} else {
					mbtt02001vo.setDstTtyDvn1(StringUtil.nvl(request.getParameter("dst_tty_dvn1")));
				}
				if("".equals(request.getParameter("dst_tty_dvn2")) || null == request.getParameter("dst_tty_dvn2")){
					mbtt02001vo.setDstTtyDvn2(" ");
				} else {
					mbtt02001vo.setDstTtyDvn2(StringUtil.nvl(request.getParameter("dst_tty_dvn2")));
				}
				if("".equals(request.getParameter("dst_tty_dvn3")) || null == request.getParameter("dst_tty_dvn3")){
					mbtt02001vo.setDstTtyDvn3(" ");
				} else {
					mbtt02001vo.setDstTtyDvn3(StringUtil.nvl(request.getParameter("dst_tty_dvn3")));
				}
				if("".equals(request.getParameter("dst_tty_dvn4")) || null == request.getParameter("dst_tty_dvn4")){
					mbtt02001vo.setDstTtyDvn4(" ");
				} else {
					mbtt02001vo.setDstTtyDvn4(StringUtil.nvl(request.getParameter("dst_tty_dvn4")));
				}
				if("".equals(request.getParameter("dst_tty_dvn5")) || null == request.getParameter("dst_tty_dvn5")){
					mbtt02001vo.setDstTtyDvn5(" ");
				} else {
					mbtt02001vo.setDstTtyDvn5(StringUtil.nvl(request.getParameter("dst_tty_dvn5")));
				}
				if("".equals(request.getParameter("phgp_regt_tgt1")) || null == request.getParameter("phgp_regt_tgt1")){
					mbtt02001vo.setPhgpRegtTgt1(" ");
				} else {
					mbtt02001vo.setPhgpRegtTgt1(StringUtil.nvl(request.getParameter("phgp_regt_tgt1")));
				}
				if("".equals(request.getParameter("phgp_regt_tgt2")) || null == request.getParameter("phgp_regt_tgt2")){
					mbtt02001vo.setPhgpRegtTgt2(" ");
				} else {
					mbtt02001vo.setPhgpRegtTgt2(StringUtil.nvl(request.getParameter("phgp_regt_tgt2")));
				}
				if("".equals(request.getParameter("phgp_regt_tgt3")) || null == request.getParameter("phgp_regt_tgt3")){
					mbtt02001vo.setPhgpRegtTgt3(" ");
				} else {
					mbtt02001vo.setPhgpRegtTgt3(StringUtil.nvl(request.getParameter("phgp_regt_tgt3")));
				}
				if("".equals(request.getParameter("phgp_regt_tgt4")) || null == request.getParameter("phgp_regt_tgt4")){
					mbtt02001vo.setPhgpRegtTgt4(" ");
				} else {
					mbtt02001vo.setPhgpRegtTgt4(StringUtil.nvl(request.getParameter("phgp_regt_tgt4")));
				}
				if("".equals(request.getParameter("phgp_regt_tgt5")) || null == request.getParameter("phgp_regt_tgt5")){
					mbtt02001vo.setPhgpRegtTgt5(" ");
				} else {
					mbtt02001vo.setPhgpRegtTgt5(StringUtil.nvl(request.getParameter("phgp_regt_tgt5")));
				}
				
				//MMTI0291 insert
				int insertRow = 0;
				
				logger.info("#### MMTI0291 insertJungsanTest before ####");
				insertRow = mileageTobeService.insertJungsanTest(mbtt02001vo);
				logger.info("#### MMTI0291 insertJungsanTest after ####");
				
				if(insertRow < 1){
					logger.info("#### 사서함번호: " + StringUtil.nvl(mbtt02001vo.getPboxNo()) + "####");
					logger.info("#### insert 결과: Fail ####");
				}else{
					logger.info("#### insert 결과: Success ####");
				}
			}
		}
		
		if("".equals(jmvo.getSms_ts_bvan()) || null == jmvo.getSms_ts_bvan()){
			mbtt02001vo.setPboxNo(" ");
		} else {
			mbtt02001vo.setPboxNo(StringUtil.nvl(jmvo.getSms_ts_bvan()));
		}
		mbtt02001vo.setTlgIdVal("MMTI0213");
		mbtt02001vo.setEsbTrscId(StringUtil.nvl(jmvo.getZ_trsc_id()));
		if("".equals(request.getParameter("plno")) || null == request.getParameter("plno")){
			mbtt02001vo.setPlno(" ");
		} else {
			mbtt02001vo.setPlno(StringUtil.nvl(request.getParameter("plno")));
		}
		if("".equals(request.getParameter("exp_exca_plan_no")) || null == request.getParameter("exp_exca_plan_no")){
			mbtt02001vo.setPlanNo(" ");
		} else {
			mbtt02001vo.setPlanNo(StringUtil.nvl(request.getParameter("exp_exca_plan_no")));
		}
		if("".equals(jmvo.getRnw_plno()) || null == jmvo.getRnw_plno()){
			mbtt02001vo.setRnwPlno(" ");
		} else {
			mbtt02001vo.setRnwPlno(StringUtil.nvl(jmvo.getRnw_plno()));
		}
		if("".equals(request.getParameter("aut_cgnt_trv_dstc")) || null == request.getParameter("aut_cgnt_trv_dstc")){
			mbtt02001vo.setAutCgntTrvDstc(0);
		} else {
			mbtt02001vo.setAutCgntTrvDstc(Double.parseDouble(request.getParameter("aut_cgnt_trv_dstc")));
		}
		if("".equals(request.getParameter("inptTrvDstc")) || null == request.getParameter("inptTrvDstc")){
			mbtt02001vo.setInptTrvDstc(0);
		} else {
			mbtt02001vo.setInptTrvDstc(Double.parseDouble(request.getParameter("inptTrvDstc")));
		}
		if("".equals(request.getParameter("exp_exca_plan_rsl_cd")) || null == request.getParameter("exp_exca_plan_rsl_cd")){
			mbtt02001vo.setExpExcaPlanRslCd(" ");
		} else {
			mbtt02001vo.setExpExcaPlanRslCd(StringUtil.nvl(request.getParameter("exp_exca_plan_rsl_cd")));
		}
		mbtt02001vo.setTlgProcRslCdVal(StringUtil.nvl(jmvo.getZ_tlg_sp_cd()));
		mbtt02001vo.setTlgErrCdVal(StringUtil.nvl(jmvo.getZ_trns_org_dvcd())+StringUtil.nvl(jmvo.getZ_trns_org_cd()));
		mbtt02001vo.setRespCn(StringUtil.nvl(jmvo.getZ_resp_cd()));
		mbtt02001vo.setRslCn(scrnNm + "_" + StringUtil.nvl(jmvo.getZ_resp_msg()));
		mbtt02001vo.setFrstIpmnEmpno("82101685");
		mbtt02001vo.setFnalAmdrEmpno("82101685");
		if("".equals(jmvo.getPbox_no_dvcd()) || null == jmvo.getPbox_no_dvcd()){
			mbtt02001vo.setPboxNoDvcd(" ");
		} else {
			mbtt02001vo.setPboxNoDvcd(StringUtil.nvl(jmvo.getPbox_no_dvcd()));
		}
		if("".equals(jmvo.getProc_dvn()) || null == jmvo.getProc_dvn()){
			mbtt02001vo.setProcDvn(" ");
		} else {
			mbtt02001vo.setProcDvn(StringUtil.nvl(jmvo.getProc_dvn()));
		}
		if("".equals(jmvo.getTrv_dstc_exp_exca_dvcd()) || null == jmvo.getTrv_dstc_exp_exca_dvcd()){
			mbtt02001vo.setTrvDstcExpExcaDvcd(" ");
		} else {
			mbtt02001vo.setTrvDstcExpExcaDvcd(StringUtil.nvl(jmvo.getTrv_dstc_exp_exca_dvcd()));
		}
		if("".equals(jmvo.getTrv_dstc_chng_aply_dvn()) || null == jmvo.getTrv_dstc_chng_aply_dvn()){
			mbtt02001vo.setTrvDstcChngAplyDvn(" ");
		} else {
			mbtt02001vo.setTrvDstcChngAplyDvn(StringUtil.nvl(jmvo.getTrv_dstc_chng_aply_dvn()));
		}
		mbtt02001vo.setHdlrFireYn(StringUtil.nvl(jmvo.getHdlr_fire_yn()));
		if("".equals(jmvo.getMtcc_yn()) || null == jmvo.getMtcc_yn()){
			mbtt02001vo.setMtccYn(" ");
		} else {
			mbtt02001vo.setMtccYn(StringUtil.nvl(jmvo.getMtcc_yn()));
		}
		if("".equals(request.getParameter("pdc_sr_dvn")) || null == request.getParameter("pdc_sr_dvn")){
			mbtt02001vo.setPdcSrDvn(" ");
		} else {
			mbtt02001vo.setPdcSrDvn(StringUtil.nvl(request.getParameter("pdc_sr_dvn")));
		}
		if("".equals(request.getParameter("adc_rtrn_prm")) || null == request.getParameter("adc_rtrn_prm")){
			mbtt02001vo.setAdcRtrnPrm(0);
		} else {
			mbtt02001vo.setAdcRtrnPrm(Double.parseDouble(request.getParameter("adc_rtrn_prm")));
		}
		if("".equals(request.getParameter("aut_cgnt_trv_dstc_rsl_cd")) || null == request.getParameter("aut_cgnt_trv_dstc_rsl_cd")){
			mbtt02001vo.setAutCgntTrvDstcRslCd(" ");
		} else {
			mbtt02001vo.setAutCgntTrvDstcRslCd(StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc_rsl_cd")));
		}
		if("".equals(request.getParameter("hdlr_empno")) || null == request.getParameter("hdlr_empno")){
			mbtt02001vo.setHdlrEmpno(" ");
		} else {
			mbtt02001vo.setHdlrEmpno(StringUtil.nvl(request.getParameter("hdlr_empno")));
		}
		if("".equals(request.getParameter("cnv_trv_dstc")) || null == request.getParameter("cnv_trv_dstc")){
			mbtt02001vo.setCnvTrvDstc(0);
		} else {
			mbtt02001vo.setCnvTrvDstc(Double.parseDouble(request.getParameter("cnv_trv_dstc")));
		}
		if("".equals(request.getParameter("excaBzProcDvn")) || null == request.getParameter("excaBzProcDvn")){
			mbtt02001vo.setExcaBzProcDvn(" ");
		} else {
			mbtt02001vo.setExcaBzProcDvn(StringUtil.nvl(request.getParameter("excaBzProcDvn")));
		}
		if("".equals(request.getParameter("excaRtrnDvn")) || null == request.getParameter("excaRtrnDvn")){
			mbtt02001vo.setExcaRtrnDvn(" ");
		} else {
			mbtt02001vo.setExcaRtrnDvn(StringUtil.nvl(request.getParameter("excaRtrnPrm")));
		}
		if("".equals(request.getParameter("pdc_sr_dvn")) || null == request.getParameter("pdc_sr_dvn")){
			mbtt02001vo.setPdcSrDvn(" ");
		} else {
			mbtt02001vo.setPdcSrDvn(StringUtil.nvl(request.getParameter("pdc_sr_dvn")));
		}
		if("".equals(request.getParameter("adc_rtrn_prm")) || null == request.getParameter("adc_rtrn_prm")){
			mbtt02001vo.setAdcRtrnPrm(0);
		} else {
			mbtt02001vo.setAdcRtrnPrm(Double.parseDouble(request.getParameter("adc_rtrn_prm")));
		}
		if("".equals(request.getParameter("trv_dstc_splc_exca_yn")) || null == request.getParameter("trv_dstc_splc_exca_yn")){
			mbtt02001vo.setTrvDstcSplcExcaYn(" ");
		} else {
			mbtt02001vo.setTrvDstcSplcExcaYn(StringUtil.nvl(request.getParameter("trv_dstc_splc_exca_yn")));
		}
		if("".equals(request.getParameter("imag_dup_yn")) || null == request.getParameter("imag_dup_yn")){
			mbtt02001vo.setImagDupYn(" ");
		} else {
			mbtt02001vo.setImagDupYn(StringUtil.nvl(request.getParameter("imag_dup_yn")));
		}
		if("".equals(request.getParameter("nrm_proc_yn")) || null == request.getParameter("nrm_proc_yn")){
			mbtt02001vo.setNrmProcYn(" ");
		} else {
			mbtt02001vo.setNrmProcYn(StringUtil.nvl(request.getParameter("nrm_proc_yn")));
		}
		if("".equals(request.getParameter("crd_scn_cncl_pss_yn")) || null == request.getParameter("crd_scn_cncl_pss_yn")){
			mbtt02001vo.setCrdScnCnclPssYn(" ");
		} else {
			mbtt02001vo.setCrdScnCnclPssYn(StringUtil.nvl(request.getParameter("crd_scn_cncl_pss_yn")));
		}
		if("".equals(request.getParameter("adc_rtrn_dvn")) || null == request.getParameter("adc_rtrn_dvn")){
			mbtt02001vo.setAdcRtrnDvn(" ");
		} else {
			mbtt02001vo.setAdcRtrnDvn(StringUtil.nvl(request.getParameter("adc_rtrn_dvn")));
		}
		if("".equals(request.getParameter("scrn_proc_cd")) || null == request.getParameter("scrn_proc_cd")){
			mbtt02001vo.setScrnProcCd(" ");
		} else {
			mbtt02001vo.setScrnProcCd(StringUtil.nvl(request.getParameter("scrn_proc_cd")));
		}
		if("".equals(jmvo.getCtc_plno()) || null == jmvo.getCtc_plno()){
			mbtt02001vo.setCtcPlno(" ");
		} else {
			mbtt02001vo.setCtcPlno(StringUtil.nvl(jmvo.getCtc_plno()));
		}
		if("".equals(request.getParameter("trv_dstc_proc_dvcd")) || null == request.getParameter("trv_dstc_proc_dvcd")){
			mbtt02001vo.setTrvDstcProcDvcd(" ");
		} else {
			mbtt02001vo.setTrvDstcProcDvcd(StringUtil.nvl(request.getParameter("trv_dstc_proc_dvcd")));
		}
		if("".equals(request.getParameter("mbl_snd_no")) || null == request.getParameter("mbl_snd_no")){
			mbtt02001vo.setMblSndNo(" ");
		} else {
			mbtt02001vo.setMblSndNo(StringUtil.nvl(request.getParameter("mbl_snd_no")));
		}
		if("".equals(request.getParameter("plan_plno_dvcd")) || null == request.getParameter("plan_plno_dvcd")){
			mbtt02001vo.setPlanPlnoDvcd(" ");
		} else {
			mbtt02001vo.setPlanPlnoDvcd(StringUtil.nvl(request.getParameter("plan_plno_dvcd")));
		}
		if("".equals(request.getParameter("plan_plno")) || null == request.getParameter("plan_plno")){
			mbtt02001vo.setPlanPlno(" ");
		} else {
			mbtt02001vo.setPlanPlno(StringUtil.nvl(request.getParameter("plan_plno")));
		}
		if("".equals(jmvo.getChng_plan_no()) || null == jmvo.getChng_plan_no()){
			mbtt02001vo.setChngPlanNo(" ");
		} else {
			mbtt02001vo.setChngPlanNo(StringUtil.nvl(jmvo.getChng_plan_no()));
		}
		if("".equals(request.getParameter("dst_tty_dvn1")) || null == request.getParameter("dst_tty_dvn1")){
			mbtt02001vo.setDstTtyDvn1(" ");
		} else {
			mbtt02001vo.setDstTtyDvn1(StringUtil.nvl(request.getParameter("dst_tty_dvn1")));
		}
		if("".equals(request.getParameter("dst_tty_dvn2")) || null == request.getParameter("dst_tty_dvn2")){
			mbtt02001vo.setDstTtyDvn2(" ");
		} else {
			mbtt02001vo.setDstTtyDvn2(StringUtil.nvl(request.getParameter("dst_tty_dvn2")));
		}
		if("".equals(request.getParameter("dst_tty_dvn3")) || null == request.getParameter("dst_tty_dvn3")){
			mbtt02001vo.setDstTtyDvn3(" ");
		} else {
			mbtt02001vo.setDstTtyDvn3(StringUtil.nvl(request.getParameter("dst_tty_dvn3")));
		}
		if("".equals(request.getParameter("dst_tty_dvn4")) || null == request.getParameter("dst_tty_dvn4")){
			mbtt02001vo.setDstTtyDvn4(" ");
		} else {
			mbtt02001vo.setDstTtyDvn4(StringUtil.nvl(request.getParameter("dst_tty_dvn4")));
		}
		if("".equals(request.getParameter("dst_tty_dvn5")) || null == request.getParameter("dst_tty_dvn5")){
			mbtt02001vo.setDstTtyDvn5(" ");
		} else {
			mbtt02001vo.setDstTtyDvn5(StringUtil.nvl(request.getParameter("dst_tty_dvn5")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt1")) || null == request.getParameter("phgp_regt_tgt1")){
			mbtt02001vo.setPhgpRegtTgt1(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt1(StringUtil.nvl(request.getParameter("phgp_regt_tgt1")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt2")) || null == request.getParameter("phgp_regt_tgt2")){
			mbtt02001vo.setPhgpRegtTgt2(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt2(StringUtil.nvl(request.getParameter("phgp_regt_tgt2")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt3")) || null == request.getParameter("phgp_regt_tgt3")){
			mbtt02001vo.setPhgpRegtTgt3(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt3(StringUtil.nvl(request.getParameter("phgp_regt_tgt3")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt4")) || null == request.getParameter("phgp_regt_tgt4")){
			mbtt02001vo.setPhgpRegtTgt4(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt4(StringUtil.nvl(request.getParameter("phgp_regt_tgt4")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt5")) || null == request.getParameter("phgp_regt_tgt5")){
			mbtt02001vo.setPhgpRegtTgt5(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt5(StringUtil.nvl(request.getParameter("phgp_regt_tgt5")));
		}
		
		//MMTI0213 insert
		int insertRow = 0;
		
		logger.info("#### insertJungsanTest before ####");
		insertRow = mileageTobeService.insertJungsanTest(mbtt02001vo);
		logger.info("#### insertJungsanTest after ####");
		
		if(insertRow < 1){
			logger.info("#### 사서함번호: " + StringUtil.nvl(mbtt02001vo.getPboxNo()) + "####");
			logger.info("#### insert 결과: Fail ####");
		}else{
			logger.info("#### insert 결과: Success ####");
		}
		
		logger.debug("##### MBTT02001 시작 ##########################");
		logger.debug("##### 사서함번호: " + StringUtil.nvl(mbtt02001vo.getPboxNo()) + " ##########################");
		logger.debug("##### 전문ID값: " + StringUtil.nvl(mbtt02001vo.getTlgIdVal()) + " ##########################");
		logger.debug("##### ESB트랜잭션ID: " + StringUtil.nvl(mbtt02001vo.getEsbTrscId()) + " ##########################");
		logger.debug("##### 증권번호: " + StringUtil.nvl(mbtt02001vo.getPlno()) + " ##########################");
		logger.debug("##### 설계번호: " + StringUtil.nvl(mbtt02001vo.getPlanNo()) + " ##########################");
		logger.debug("##### 갱신증권번호: " + StringUtil.nvl(mbtt02001vo.getRnwPlno()) + " ##########################");
		logger.debug("##### 전문처리결과코드값: " + StringUtil.nvl(mbtt02001vo.getTlgProcRslCdVal()) + " ##########################");
		logger.debug("##### 전문에러코드값: " + StringUtil.nvl(mbtt02001vo.getTlgErrCdVal()) + " ##########################");
		logger.debug("##### 취급자사원번호: " + StringUtil.nvl(mbtt02001vo.getHdlrEmpno()) + " ##########################");
		logger.debug("##### 응답내용: " + StringUtil.nvl(mbtt02001vo.getRespCn()) + " ##########################");
		logger.debug("##### 결과내용: " + StringUtil.nvl(mbtt02001vo.getRslCn()) + " ##########################");
		logger.debug("##### 최초입력자사원번호: " + StringUtil.nvl(mbtt02001vo.getFrstIpmnEmpno()) + " ##########################");
		logger.debug("##### 최종수정자사원번호: " + StringUtil.nvl(mbtt02001vo.getFnalAmdrEmpno()) + " ##########################");
		logger.debug("##### 사서함번호구분코드: " + StringUtil.nvl(mbtt02001vo.getPboxNoDvcd()) + " ##########################");
		logger.debug("##### 정산처리구분코드: " + StringUtil.nvl(mbtt02001vo.getProcDvn()) + " ##########################");
		logger.debug("##### 주행거리만기정산구분: " + StringUtil.nvl(mbtt02001vo.getTrvDstcExpExcaDvcd()) + " ##########################");
		logger.debug("##### 주행거리변경신청구분: " + StringUtil.nvl(mbtt02001vo.getTrvDstcChngAplyDvn()) + " ##########################");
		logger.debug("##### 취급자해촉여부: " + StringUtil.nvl(mbtt02001vo.getHdlrFireYn()) + " ##########################");
		logger.debug("##### 이륜차여부: " + StringUtil.nvl(mbtt02001vo.getMtccYn()) + " ##########################");
		logger.debug("##### 자동인식주행거리: " + StringUtil.nvl(mbtt02001vo.getAutCgntTrvDstc()) + " ##########################");
		logger.debug("##### 자동인식주행거리결과코드: " + StringUtil.nvl(mbtt02001vo.getAutCgntTrvDstcRslCd()) + " ##########################");
		logger.debug("##### 입력주행거리: " + String.valueOf(mbtt02001vo.getInptTrvDstc()) + " ##########################");
		logger.debug("##### 환산주행거리: " + String.valueOf(mbtt02001vo.getCnvTrvDstc()) + " ##########################");
		logger.debug("##### 만기정산설계결과코드: " + StringUtil.nvl(mbtt02001vo.getExpExcaPlanRslCd()) + " ##########################");
		logger.debug("##### 정산업무처리구분코드: " + String.valueOf(mbtt02001vo.getExcaBzProcDvn()) + " ##########################");
		logger.debug("##### 정산환급구분코드: " + String.valueOf(mbtt02001vo.getExcaRtrnDvn()) + " ##########################");
		logger.debug("##### 상품출처구분코드: " + StringUtil.nvl(mbtt02001vo.getPdcSrDvn()) + " ##########################");		
		logger.debug("##### 추징환급보험료: " + String.valueOf(mbtt02001vo.getAdcRtrnPrm()) + " ##########################");
		logger.debug("##### 주행거리간편정산여부: " + StringUtil.nvl(mbtt02001vo.getTrvDstcSplcExcaYn()) + " ##########################");
		logger.debug("##### 이미지중복여부: " + StringUtil.nvl(mbtt02001vo.getImagDupYn()) + " ##########################");
		logger.debug("##### 정산처리여부: " + StringUtil.nvl(mbtt02001vo.getNrmProcYn()) + " ##########################");
		logger.debug("##### 카드부분취소가능여부: " + StringUtil.nvl(mbtt02001vo.getCrdScnCnclPssYn()) + " ##########################");
		
		
		request.setAttribute("p",							StringUtil.nvl(request.getParameter("p")));
		request.setAttribute("jmvo",						jmvo);
		request.setAttribute("exp_exca_plan_rsl_cd",		exp_exca_plan_rsl_cd);
		request.setAttribute("adc_rtrn_dvn",				StringUtil.nvl(request.getParameter("adc_rtrn_dvn")));
		request.setAttribute("adc_rtrn_prm",				StringUtil.nvl(request.getParameter("adc_rtrn_prm")));
		request.setAttribute("plno",						StringUtil.nvl(request.getParameter("plno")));
		request.setAttribute("exp_exca_plan_no",			StringUtil.nvl(request.getParameter("exp_exca_plan_no")));
		request.setAttribute("exp_exca_plan_bse_dd",		StringUtil.nvl(request.getParameter("exp_exca_plan_bse_dd")));
		request.setAttribute("aut_cgnt_vh_no",				StringUtil.nvl(request.getParameter("aut_cgnt_vh_no")));
		request.setAttribute("aut_cgnt_vh_no_rsl_cd",		StringUtil.nvl(request.getParameter("aut_cgnt_vh_no_rsl_cd")));
		request.setAttribute("aut_cgnt_trv_dstc",			StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc")));
		request.setAttribute("aut_cgnt_trv_dstc_rsl_cd",	StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc_rsl_cd")));
		request.setAttribute("exp_exca_plan_proc_dvn",		StringUtil.nvl(request.getParameter("exp_exca_plan_proc_dvn")));
		request.setAttribute("cnv_trv_dstc",				StringUtil.nvl(request.getParameter("cnv_trv_dstc")));
		request.setAttribute("plhd_cust_nm",				StringUtil.nvl(request.getParameter("plhd_cust_nm")));
		request.setAttribute("pdc_sr_dvn",					StringUtil.nvl(request.getParameter("pdc_sr_dvn")));
		request.setAttribute("errorCode",					StringUtil.nvl(request.getParameter("errorCode")));
		

		session.setAttribute("p",							StringUtil.nvl(session.getAttribute("p")));
		session.setAttribute("jmvo",						jmvo);
		session.setAttribute("exp_exca_plan_rsl_cd",		exp_exca_plan_rsl_cd);
		session.setAttribute("adc_rtrn_dvn",				StringUtil.nvl(session.getAttribute("adc_rtrn_dvn")));
		session.setAttribute("adc_rtrn_prm",				StringUtil.nvl(session.getAttribute("adc_rtrn_prm")));
		session.setAttribute("plno",						StringUtil.nvl(session.getAttribute("plno")));
		session.setAttribute("exp_exca_plan_no",			StringUtil.nvl(session.getAttribute("exp_exca_plan_no")));
		session.setAttribute("exp_exca_plan_bse_dd",		StringUtil.nvl(session.getAttribute("exp_exca_plan_bse_dd")));
		session.setAttribute("aut_cgnt_vh_no",				StringUtil.nvl(session.getAttribute("aut_cgnt_vh_no")));
		session.setAttribute("aut_cgnt_vh_no_rsl_cd",		StringUtil.nvl(session.getAttribute("aut_cgnt_vh_no_rsl_cd")));
		session.setAttribute("aut_cgnt_trv_dstc",			StringUtil.nvl(session.getAttribute("aut_cgnt_trv_dstc")));
		session.setAttribute("aut_cgnt_trv_dstc_rsl_cd",	StringUtil.nvl(session.getAttribute("aut_cgnt_trv_dstc_rsl_cd")));
		session.setAttribute("exp_exca_plan_proc_dvn",		StringUtil.nvl(session.getAttribute("exp_exca_plan_proc_dvn")));
		session.setAttribute("cnv_trv_dstc",				StringUtil.nvl(session.getAttribute("cnv_trv_dstc")));
		session.setAttribute("plhd_cust_nm",				StringUtil.nvl(session.getAttribute("plhd_cust_nm")));
		session.setAttribute("pdc_sr_dvn",					StringUtil.nvl(session.getAttribute("pdc_sr_dvn")));
		session.setAttribute("errorCode",					StringUtil.nvl(session.getAttribute("errorCode")));
		
		
		return "/counter/carrider/tobe/ml3";
	}
	
	@RequestMapping(value="/ml3_1")
	public @ResponseBody Map<String, String> ml3_1(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		HttpSession session = request.getSession();
		Map<String, String> map = new HashMap<String, String>();
		MMTI0291VO jmvo = new MMTI0291VO();
		MBTT02001VO mbtt02001vo = new MBTT02001VO();
		String scrnNm = "ml3_1";
		
		logger.info("###### ml3_1 테스트1 ######");
		logger.info("###### request ######");
		logger.info("###### plno: " + StringUtil.nvl(request.getParameter("plno")));
		logger.info("###### plan_no: " + StringUtil.nvl(request.getParameter("exp_exca_plan_no")));
		logger.info("###### pdc_sr_dvn: " + StringUtil.nvl(request.getParameter("pdc_sr_dvn")));
		logger.info("###### adc_rtrn_dvn: " + StringUtil.nvl(request.getParameter("adc_rtrn_dvn")));
		logger.info("###### adc_rtrn_prm: " + StringUtil.nvl(request.getParameter("adc_rtrn_prm")));
		logger.info("###### scrn_proc_cd: " + StringUtil.nvl(request.getParameter("exp_exca_plan_rsl_cd")));
		
		logger.info("###### ml3_1 테스트2 ######");
		logger.info("###### session ######");
		logger.info("###### plno: " + StringUtil.nvl((String)session.getAttribute("plno")));
		logger.info("###### plan_no: " + StringUtil.nvl((String)session.getAttribute("exp_exca_plan_no")));
		logger.info("###### pdc_sr_dvn: " + StringUtil.nvl((String)session.getAttribute("pdc_sr_dvn")));
		logger.info("###### adc_rtrn_dvn: " + StringUtil.nvl((String)session.getAttribute("adc_rtrn_dvn")));
		logger.info("###### adc_rtrn_prm: " + StringUtil.nvl((String)session.getAttribute("adc_rtrn_prm")));
		logger.info("###### scrn_proc_cd: " + StringUtil.nvl((String)session.getAttribute("exp_exca_plan_rsl_cd")));
		
		jmvo.setTrv_dstc_exca_mtt__exca_bz_proc_dvn("2");
		jmvo.setTrv_dstc_exca_mtt__plno(StringUtil.nvl(request.getParameter("plno")));
		jmvo.setTrv_dstc_exca_mtt__plan_no(StringUtil.nvl(request.getParameter("exp_exca_plan_no")));
		jmvo.setTrv_dstc_exca_mtt__exca_rtrn_dvn("");
		jmvo.setTrv_dstc_exca_mtt__pdc_sr_dvn(StringUtil.nvl(request.getParameter("pdc_sr_dvn")));
		jmvo.setTrv_dstc_exca_mtt__adc_rtrn_dvn(StringUtil.nvl(request.getParameter("adc_rtrn_dvn")));
		jmvo.setTrv_dstc_exca_mtt__adc_rtrn_prm(StringUtil.nvl(request.getParameter("adc_rtrn_prm")));
		jmvo.setTrv_dstc_exca_mtt__scrn_proc_cd(StringUtil.nvl(request.getParameter("exp_exca_plan_rsl_cd")));
		jmvo.setTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn(StringUtil.nvl(request.getParameter("trv_dstc_splc_exca_yn")));
		jmvo.setTrv_dstc_exca_mtt__pbox_no(StringUtil.nvl(request.getParameter("pbox_no")));
		jmvo = mileageTobeService.getMMTI0291VO(jmvo);

		map.put("trv_dstc_exca_mtt__exca_bz_proc_dvn",			jmvo.getTrv_dstc_exca_mtt__exca_bz_proc_dvn());
		map.put("trv_dstc_exca_mtt__plno", 						jmvo.getTrv_dstc_exca_mtt__plno());
		map.put("trv_dstc_exca_mtt__plan_no", 					jmvo.getTrv_dstc_exca_mtt__plan_no());
		map.put("trv_dstc_exca_mtt__plan_dt", 					jmvo.getTrv_dstc_exca_mtt__plan_dt());
		map.put("trv_dstc_exca_mtt__exca_rtrn_dvn", 			jmvo.getTrv_dstc_exca_mtt__exca_rtrn_dvn());
		map.put("trv_dstc_exca_mtt__bank_cd", 					jmvo.getTrv_dstc_exca_mtt__bank_cd());
		map.put("trv_dstc_exca_mtt__acc_no", 					jmvo.getTrv_dstc_exca_mtt__acc_no());
		map.put("trv_dstc_exca_mtt__adc_rtrn_dvn", 				jmvo.getTrv_dstc_exca_mtt__adc_rtrn_dvn());
		map.put("trv_dstc_exca_mtt__adc_rtrn_prm", 				jmvo.getTrv_dstc_exca_mtt__adc_rtrn_prm());
		map.put("trv_dstc_exca_mtt__cnv_trv_dstc", 				jmvo.getTrv_dstc_exca_mtt__cnv_trv_dstc());
		map.put("trv_dstc_exca_mtt__nrm_proc_yn", 				jmvo.getTrv_dstc_exca_mtt__nrm_proc_yn());
		map.put("trv_dstc_exca_mtt__aut_cgnt_vh_no_eqal_yn", 	jmvo.getTrv_dstc_exca_mtt__aut_cgnt_vh_no_eqal_yn());
		map.put("trv_dstc_exca_mtt__aut_cgnt_trv_dstc_eqal_yn",	jmvo.getTrv_dstc_exca_mtt__aut_cgnt_trv_dstc_eqal_yn());
		map.put("trv_dstc_exca_mtt__rnw_plno", 					jmvo.getTrv_dstc_exca_mtt__rnw_plno());
		map.put("trv_dstc_exca_mtt__hdlr_empno", 				jmvo.getTrv_dstc_exca_mtt__hdlr_empno());
		map.put("trv_dstc_exca_mtt__aut_cgnt_trv_dstc_rsl_cd", 	jmvo.getTrv_dstc_exca_mtt__aut_cgnt_trv_dstc_rsl_cd());
		map.put("trv_dstc_exca_mtt__plhd_cust_nm", 				jmvo.getTrv_dstc_exca_mtt__plhd_cust_nm());
		map.put("trv_dstc_exca_mtt__pdc_sr_dvn", 				jmvo.getTrv_dstc_exca_mtt__pdc_sr_dvn());
		map.put("trv_dstc_exca_mtt__scrn_proc_cd", 				jmvo.getTrv_dstc_exca_mtt__scrn_proc_cd());
		map.put("trv_dstc_exca_mtt__arc_trm_str_dt", 			jmvo.getTrv_dstc_exca_mtt__arc_trm_str_dt());
		map.put("z_resp_cd",									jmvo.getZ_resp_cd());
		
		map.put("trv_dstc_exca_mtt__imag_dup_yn", 				jmvo.getTrv_dstc_exca_mtt__imag_dup_yn());
		map.put("trv_dstc_exca_mtt__crd_scn_cncl_pss_yn", 		jmvo.getTrv_dstc_exca_mtt__crd_scn_cncl_pss_yn());

//		mbtt02001vo.setPboxNo(StringUtil.nvl(aes256Decrypt((String)session.getAttribute("p"))));
		if("".equals(jmvo.getTrv_dstc_exca_mtt__pbox_no()) || null == jmvo.getTrv_dstc_exca_mtt__pbox_no()){
			mbtt02001vo.setPboxNo(" ");
		} else {
			mbtt02001vo.setPboxNo(StringUtil.nvl(jmvo.getTrv_dstc_exca_mtt__pbox_no()));
		}
		mbtt02001vo.setTlgIdVal("MMTI0291");
		mbtt02001vo.setEsbTrscId(StringUtil.nvl(jmvo.getZ_trsc_id()));
		if("".equals(jmvo.getTrv_dstc_exca_mtt__plno()) || null == jmvo.getTrv_dstc_exca_mtt__plno()){
			mbtt02001vo.setPlno(" ");
		} else {
			mbtt02001vo.setPlno(StringUtil.nvl(jmvo.getTrv_dstc_exca_mtt__plno()));
		}
		if("".equals(jmvo.getTrv_dstc_exca_mtt__plan_no()) || null == jmvo.getTrv_dstc_exca_mtt__plan_no()){
			mbtt02001vo.setPlanNo(" ");
		} else {
			mbtt02001vo.setPlanNo(StringUtil.nvl(jmvo.getTrv_dstc_exca_mtt__plan_no()));
		}
		if("".equals(jmvo.getTrv_dstc_exca_mtt__rnw_plno()) || null == jmvo.getTrv_dstc_exca_mtt__rnw_plno()){
			mbtt02001vo.setRnwPlno(" ");
		} else {
			mbtt02001vo.setRnwPlno(StringUtil.nvl(jmvo.getTrv_dstc_exca_mtt__rnw_plno()));
		}
		mbtt02001vo.setTlgProcRslCdVal(StringUtil.nvl(jmvo.getZ_tlg_sp_cd()));
		mbtt02001vo.setTlgErrCdVal(StringUtil.nvl(jmvo.getZ_trns_org_dvcd())+StringUtil.nvl(jmvo.getZ_trns_org_cd()));
		if("".equals(jmvo.getTrv_dstc_exca_mtt__hdlr_empno()) || null == jmvo.getTrv_dstc_exca_mtt__hdlr_empno()){
			mbtt02001vo.setHdlrEmpno(" ");
		} else {
			mbtt02001vo.setHdlrEmpno(StringUtil.nvl(jmvo.getTrv_dstc_exca_mtt__hdlr_empno()));
		}
		if("".equals(request.getParameter("pbox_no_dvcd")) || null == request.getParameter("pbox_no_dvcd")){
			mbtt02001vo.setPboxNoDvcd(" ");
		} else {
			mbtt02001vo.setPboxNoDvcd(StringUtil.nvl(request.getParameter("pbox_no_dvcd")));
		}
		if("".equals(request.getParameter("proc_dvn")) || null == request.getParameter("proc_dvn")){
			mbtt02001vo.setProcDvn(" ");
		} else {
			mbtt02001vo.setProcDvn(StringUtil.nvl(request.getParameter("proc_dvn")));
		}
		if("".equals(request.getParameter("trv_dstc_exp_exca_dvcd")) || null == request.getParameter("trv_dstc_exp_exca_dvcd")){
			mbtt02001vo.setTrvDstcExpExcaDvcd(" ");
		} else {
			mbtt02001vo.setTrvDstcExpExcaDvcd(StringUtil.nvl(request.getParameter("trv_dstc_exp_exca_dvcd")));
		}
		if("".equals(request.getParameter("trv_dstc_chng_aply_dvn")) || null == request.getParameter("trv_dstc_chng_aply_dvn")){
			mbtt02001vo.setTrvDstcChngAplyDvn(" ");
		} else {
			mbtt02001vo.setTrvDstcChngAplyDvn(StringUtil.nvl(request.getParameter("trv_dstc_chng_aply_dvn")));
		}
		if("".equals(request.getParameter("hdlr_fire_yn")) || null == request.getParameter("hdlr_fire_yn")){
			mbtt02001vo.setHdlrFireYn(" ");
		} else {
			mbtt02001vo.setHdlrFireYn(StringUtil.nvl(request.getParameter("hdlr_fire_yn")));
		}
		if("".equals(request.getParameter("mtcc_yn")) || null == request.getParameter("mtcc_yn")){
			mbtt02001vo.setMtccYn(" ");
		} else {
			mbtt02001vo.setMtccYn(StringUtil.nvl(request.getParameter("mtcc_yn")));
		}
		if("".equals(request.getParameter("aut_cgnt_trv_dstc")) || null == request.getParameter("aut_cgnt_trv_dstc")){
			mbtt02001vo.setAutCgntTrvDstc(0);
		} else {
			mbtt02001vo.setAutCgntTrvDstc(Double.parseDouble(request.getParameter("aut_cgnt_trv_dstc")));
		}
		if("".equals(jmvo.getTrv_dstc_exca_mtt__aut_cgnt_trv_dstc_rsl_cd()) || null == jmvo.getTrv_dstc_exca_mtt__aut_cgnt_trv_dstc_rsl_cd()){
			mbtt02001vo.setAutCgntTrvDstcRslCd(" ");
		} else {
			mbtt02001vo.setAutCgntTrvDstcRslCd(StringUtil.nvl(jmvo.getTrv_dstc_exca_mtt__aut_cgnt_trv_dstc_rsl_cd()));
		}
		if("".equals(request.getParameter("inptTrvDstc")) || null == request.getParameter("inptTrvDstc")){
			mbtt02001vo.setInptTrvDstc(0);
		} else {
			mbtt02001vo.setInptTrvDstc(Double.parseDouble(request.getParameter("inptTrvDstc")));
		}
		if("".equals(jmvo.getTrv_dstc_exca_mtt__cnv_trv_dstc()) || null == jmvo.getTrv_dstc_exca_mtt__cnv_trv_dstc()){
			mbtt02001vo.setCnvTrvDstc(0);
		} else {
			mbtt02001vo.setCnvTrvDstc(Double.parseDouble(jmvo.getTrv_dstc_exca_mtt__cnv_trv_dstc()));
		}
		if("".equals(request.getParameter("exp_exca_plan_rsl_cd")) || null == request.getParameter("exp_exca_plan_rsl_cd")){
			mbtt02001vo.setExpExcaPlanRslCd(" ");
		} else {
			mbtt02001vo.setExpExcaPlanRslCd(StringUtil.nvl(request.getParameter("exp_exca_plan_rsl_cd")));
		}
		if("".equals(jmvo.getTrv_dstc_exca_mtt__exca_bz_proc_dvn()) || null == jmvo.getTrv_dstc_exca_mtt__exca_bz_proc_dvn()){
			mbtt02001vo.setExcaBzProcDvn(" ");
		} else {
			mbtt02001vo.setExcaBzProcDvn(StringUtil.nvl(jmvo.getTrv_dstc_exca_mtt__exca_bz_proc_dvn()));
		}
		if("".equals(jmvo.getTrv_dstc_exca_mtt__exca_rtrn_dvn()) || null == jmvo.getTrv_dstc_exca_mtt__exca_rtrn_dvn()){
			mbtt02001vo.setExcaRtrnDvn(" ");
		} else {
			mbtt02001vo.setExcaRtrnDvn(StringUtil.nvl(jmvo.getTrv_dstc_exca_mtt__exca_rtrn_dvn()));
		}
		if("".equals(jmvo.getTrv_dstc_exca_mtt__pdc_sr_dvn()) || null == jmvo.getTrv_dstc_exca_mtt__pdc_sr_dvn()){
			mbtt02001vo.setPdcSrDvn(" ");
		} else {
			mbtt02001vo.setPdcSrDvn(StringUtil.nvl(jmvo.getTrv_dstc_exca_mtt__pdc_sr_dvn()));
		}
		if("".equals(jmvo.getTrv_dstc_exca_mtt__adc_rtrn_prm()) || null == jmvo.getTrv_dstc_exca_mtt__adc_rtrn_prm()){
			mbtt02001vo.setAdcRtrnPrm(0);
		} else {
			mbtt02001vo.setAdcRtrnPrm(Double.parseDouble(jmvo.getTrv_dstc_exca_mtt__adc_rtrn_prm()));
		}
		if("".equals(jmvo.getTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn()) || null == jmvo.getTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn()){
			mbtt02001vo.setTrvDstcSplcExcaYn(" ");
		} else {
			mbtt02001vo.setTrvDstcSplcExcaYn(StringUtil.nvl(jmvo.getTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn()));
		}
		if("".equals(jmvo.getTrv_dstc_exca_mtt__imag_dup_yn()) || null == jmvo.getTrv_dstc_exca_mtt__imag_dup_yn()){
			mbtt02001vo.setImagDupYn(" ");
		} else {
			mbtt02001vo.setImagDupYn(StringUtil.nvl(jmvo.getTrv_dstc_exca_mtt__imag_dup_yn()));
		}
		if("".equals(jmvo.getTrv_dstc_exca_mtt__nrm_proc_yn()) || null == jmvo.getTrv_dstc_exca_mtt__nrm_proc_yn()){
			mbtt02001vo.setNrmProcYn(" ");
		} else {
			mbtt02001vo.setNrmProcYn(StringUtil.nvl(jmvo.getTrv_dstc_exca_mtt__nrm_proc_yn()));
		}
		if("".equals(request.getParameter("crdScnCnclPssYn")) || null == request.getParameter("crdScnCnclPssYn")){
			mbtt02001vo.setCrdScnCnclPssYn(" ");
		} else {
			mbtt02001vo.setCrdScnCnclPssYn(StringUtil.nvl(request.getParameter("crdScnCnclPssYn")));
		}
		mbtt02001vo.setRespCn(StringUtil.nvl(jmvo.getZ_resp_cd()));
		mbtt02001vo.setRslCn(scrnNm + "_" + StringUtil.nvl(jmvo.getZ_resp_msg()));
		mbtt02001vo.setFrstIpmnEmpno("82101685");
		mbtt02001vo.setFnalAmdrEmpno("82101685");
		if("".equals(jmvo.getTrv_dstc_exca_mtt__adc_rtrn_dvn()) || null == jmvo.getTrv_dstc_exca_mtt__adc_rtrn_dvn()){
			mbtt02001vo.setAdcRtrnDvn(" ");
		} else {
			mbtt02001vo.setAdcRtrnDvn(StringUtil.nvl(jmvo.getTrv_dstc_exca_mtt__adc_rtrn_dvn()));
		}
		if("".equals(jmvo.getTrv_dstc_exca_mtt__scrn_proc_cd()) || null == jmvo.getTrv_dstc_exca_mtt__scrn_proc_cd()){
			mbtt02001vo.setScrnProcCd(" ");
		} else {
			mbtt02001vo.setScrnProcCd(StringUtil.nvl(jmvo.getTrv_dstc_exca_mtt__scrn_proc_cd()));
		}
		if("".equals(request.getParameter("ctc_plno")) || null == request.getParameter("ctc_plno")){
			mbtt02001vo.setCtcPlno(" ");
		} else {
			mbtt02001vo.setCtcPlno(StringUtil.nvl(request.getParameter("ctc_plno")));
		}
		if("".equals(request.getParameter("trv_dstc_proc_dvcd")) || null == request.getParameter("trv_dstc_proc_dvcd")){
			mbtt02001vo.setTrvDstcProcDvcd(" ");
		} else {
			mbtt02001vo.setTrvDstcProcDvcd(StringUtil.nvl(request.getParameter("trv_dstc_proc_dvcd")));
		}
		if("".equals(request.getParameter("mbl_snd_no")) || null == request.getParameter("mbl_snd_no")){
			mbtt02001vo.setMblSndNo(" ");
		} else {
			mbtt02001vo.setMblSndNo(StringUtil.nvl(request.getParameter("mbl_snd_no")));
		}
		if("".equals(request.getParameter("plan_plno_dvcd")) || null == request.getParameter("plan_plno_dvcd")){
			mbtt02001vo.setPlanPlnoDvcd(" ");
		} else {
			mbtt02001vo.setPlanPlnoDvcd(StringUtil.nvl(request.getParameter("plan_plno_dvcd")));
		}
		if("".equals(request.getParameter("plan_plno")) || null == request.getParameter("plan_plno")){
			mbtt02001vo.setPlanPlno(" ");
		} else {
			mbtt02001vo.setPlanPlno(StringUtil.nvl(request.getParameter("plan_plno")));
		}
		if("".equals(request.getParameter("chng_plan_no")) || null == request.getParameter("chng_plan_no")){
			mbtt02001vo.setChngPlanNo(" ");
		} else {
			mbtt02001vo.setChngPlanNo(StringUtil.nvl(request.getParameter("chng_plan_no")));
		}
		if("".equals(request.getParameter("dst_tty_dvn1")) || null == request.getParameter("dst_tty_dvn1")){
			mbtt02001vo.setDstTtyDvn1(" ");
		} else {
			mbtt02001vo.setDstTtyDvn1(StringUtil.nvl(request.getParameter("dst_tty_dvn1")));
		}
		if("".equals(request.getParameter("dst_tty_dvn2")) || null == request.getParameter("dst_tty_dvn2")){
			mbtt02001vo.setDstTtyDvn2(" ");
		} else {
			mbtt02001vo.setDstTtyDvn2(StringUtil.nvl(request.getParameter("dst_tty_dvn2")));
		}
		if("".equals(request.getParameter("dst_tty_dvn3")) || null == request.getParameter("dst_tty_dvn3")){
			mbtt02001vo.setDstTtyDvn3(" ");
		} else {
			mbtt02001vo.setDstTtyDvn3(StringUtil.nvl(request.getParameter("dst_tty_dvn3")));
		}
		if("".equals(request.getParameter("dst_tty_dvn4")) || null == request.getParameter("dst_tty_dvn4")){
			mbtt02001vo.setDstTtyDvn4(" ");
		} else {
			mbtt02001vo.setDstTtyDvn4(StringUtil.nvl(request.getParameter("dst_tty_dvn4")));
		}
		if("".equals(request.getParameter("dst_tty_dvn5")) || null == request.getParameter("dst_tty_dvn5")){
			mbtt02001vo.setDstTtyDvn5(" ");
		} else {
			mbtt02001vo.setDstTtyDvn5(StringUtil.nvl(request.getParameter("dst_tty_dvn5")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt1")) || null == request.getParameter("phgp_regt_tgt1")){
			mbtt02001vo.setPhgpRegtTgt1(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt1(StringUtil.nvl(request.getParameter("phgp_regt_tgt1")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt2")) || null == request.getParameter("phgp_regt_tgt2")){
			mbtt02001vo.setPhgpRegtTgt2(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt2(StringUtil.nvl(request.getParameter("phgp_regt_tgt2")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt3")) || null == request.getParameter("phgp_regt_tgt3")){
			mbtt02001vo.setPhgpRegtTgt3(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt3(StringUtil.nvl(request.getParameter("phgp_regt_tgt3")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt4")) || null == request.getParameter("phgp_regt_tgt4")){
			mbtt02001vo.setPhgpRegtTgt4(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt4(StringUtil.nvl(request.getParameter("phgp_regt_tgt4")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt5")) || null == request.getParameter("phgp_regt_tgt5")){
			mbtt02001vo.setPhgpRegtTgt5(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt5(StringUtil.nvl(request.getParameter("phgp_regt_tgt5")));
		}
		
		//MMTI0291 insert
		int insertRow = 0;
		
		logger.info("#### MMTI0291 insertJungsanTest before ####");
		insertRow = mileageTobeService.insertJungsanTest(mbtt02001vo);
		logger.info("#### MMTI0291 insertJungsanTest after ####");
		
		if(insertRow < 1){
			logger.info("#### 사서함번호: " + StringUtil.nvl(mbtt02001vo.getPboxNo()) + "####");
			logger.info("#### insert 결과: Fail ####");
		}else{
			logger.info("#### insert 결과: Success ####");
		}
		
		return map;
	}

	@RequestMapping(value="/ml4")
	public String ml4(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		MMTI0213VO jmvo = new MMTI0213VO();
		MBTT02001VO mbtt02001vo = new MBTT02001VO();
		String scrnNm = "ml4";
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("p")));
		jmvo = mileageTobeService.getMMTI0213VO(jmvo);

		String gubun = request.getParameter("gubun");
		request.setAttribute("p",							request.getParameter("p"));
		request.setAttribute("jmvo",						jmvo);
		request.setAttribute("exp_exca_plan_rsl_cd",		request.getParameter("exp_exca_plan_rsl_cd"));
		request.setAttribute("adc_rtrn_dvn",				request.getParameter("adc_rtrn_dvn"));
		request.setAttribute("adc_rtrn_prm",				request.getParameter("adc_rtrn_prm"));
		request.setAttribute("plno",						request.getParameter("plno"));
		request.setAttribute("exp_exca_plan_no",			request.getParameter("exp_exca_plan_no"));
		request.setAttribute("exp_exca_plan_bse_dd",		request.getParameter("exp_exca_plan_bse_dd"));
		request.setAttribute("aut_cgnt_vh_no",				request.getParameter("aut_cgnt_vh_no"));
		request.setAttribute("aut_cgnt_vh_no_rsl_cd",		request.getParameter("aut_cgnt_vh_no_rsl_cd"));
		request.setAttribute("aut_cgnt_trv_dstc",			request.getParameter("aut_cgnt_trv_dstc"));
		request.setAttribute("aut_cgnt_trv_dstc_rsl_cd",	request.getParameter("aut_cgnt_trv_dstc_rsl_cd"));
		request.setAttribute("cnv_trv_dstc",				request.getParameter("cnv_trv_dstc"));
		request.setAttribute("plhd_cust_nm",				request.getParameter("plhd_cust_nm"));
		request.setAttribute("pdc_sr_dvn",					request.getParameter("pdc_sr_dvn"));
		request.setAttribute("gubun",						gubun);
		
		//MMTI0213전문 정산이력테이블(MBTT02001) 적재
		mbtt02001vo.setPboxNo(StringUtil.nvl(jmvo.getSms_ts_bvan()));
		mbtt02001vo.setTlgIdVal("MMTI0213");
		mbtt02001vo.setEsbTrscId(StringUtil.nvl(jmvo.getZ_trsc_id()));
		if("".equals(request.getParameter("plno")) || null == request.getParameter("plno")){
			mbtt02001vo.setPlno(" ");
		} else {
			mbtt02001vo.setPlno(StringUtil.nvl(request.getParameter("plno")));
		}
		if("".equals(request.getParameter("exp_exca_plan_no")) || null == request.getParameter("exp_exca_plan_no")){
			mbtt02001vo.setPlanNo(" ");
		} else {
			mbtt02001vo.setPlanNo(StringUtil.nvl(request.getParameter("exp_exca_plan_no")));
		}
		if("".equals(jmvo.getRnw_plno()) || null == jmvo.getRnw_plno()){
			mbtt02001vo.setRnwPlno(" ");
		} else {
			mbtt02001vo.setRnwPlno(StringUtil.nvl(jmvo.getRnw_plno()));
		}
		mbtt02001vo.setTlgProcRslCdVal(StringUtil.nvl(jmvo.getZ_tlg_sp_cd()));
		mbtt02001vo.setTlgErrCdVal(StringUtil.nvl(jmvo.getZ_trns_org_dvcd())+StringUtil.nvl(jmvo.getZ_trns_org_cd()));
		if("".equals(request.getParameter("hdlr_empno")) || null == request.getParameter("hdlr_empno")){
			mbtt02001vo.setHdlrEmpno(" ");
		} else {
			mbtt02001vo.setHdlrEmpno(StringUtil.nvl(request.getParameter("hdlr_empno")));
		}
		if("".equals(jmvo.getPbox_no_dvcd()) || null == jmvo.getPbox_no_dvcd()){
			mbtt02001vo.setPboxNoDvcd(" ");
		} else {
			mbtt02001vo.setPboxNoDvcd(StringUtil.nvl(jmvo.getPbox_no_dvcd()));
		}
		if("".equals(jmvo.getProc_dvn()) || null == jmvo.getProc_dvn()){
			mbtt02001vo.setProcDvn(" ");
		} else {
			mbtt02001vo.setProcDvn(StringUtil.nvl(jmvo.getProc_dvn()));
		}
		if("".equals(jmvo.getTrv_dstc_exp_exca_dvcd()) || null == jmvo.getTrv_dstc_exp_exca_dvcd()){
			mbtt02001vo.setTrvDstcExpExcaDvcd(" ");
		} else {
			mbtt02001vo.setTrvDstcExpExcaDvcd(StringUtil.nvl(jmvo.getTrv_dstc_exp_exca_dvcd()));
		}
		if("".equals(jmvo.getTrv_dstc_chng_aply_dvn()) || null == jmvo.getTrv_dstc_chng_aply_dvn()){
			mbtt02001vo.setTrvDstcChngAplyDvn(" ");
		} else {
			mbtt02001vo.setTrvDstcChngAplyDvn(StringUtil.nvl(jmvo.getTrv_dstc_chng_aply_dvn()));
		}
		if("".equals(jmvo.getHdlr_fire_yn()) || null == jmvo.getHdlr_fire_yn()){
			mbtt02001vo.setHdlrFireYn(" ");
		} else {
			mbtt02001vo.setHdlrFireYn(StringUtil.nvl(jmvo.getHdlr_fire_yn()));
		}
		if("".equals(jmvo.getMtcc_yn()) || null == jmvo.getMtcc_yn()){
			mbtt02001vo.setMtccYn(" ");
		} else {
			mbtt02001vo.setMtccYn(StringUtil.nvl(jmvo.getMtcc_yn()));
		}
		if("".equals(request.getParameter("aut_cgnt_trv_dstc")) || null == request.getParameter("aut_cgnt_trv_dstc")){
			mbtt02001vo.setAutCgntTrvDstc(0);
		} else {
			mbtt02001vo.setAutCgntTrvDstc(Double.parseDouble(request.getParameter("aut_cgnt_trv_dstc")));
		}
		if("".equals(request.getParameter("autCgntTrvDstcRslCd")) || null == request.getParameter("autCgntTrvDstcRslCd")){
			mbtt02001vo.setAutCgntTrvDstcRslCd(" ");
		} else {
			mbtt02001vo.setAutCgntTrvDstcRslCd(StringUtil.nvl(request.getParameter("autCgntTrvDstcRslCd")));
		}
		if("".equals(request.getParameter("inptTrvDstc")) || null == request.getParameter("inptTrvDstc")){
			mbtt02001vo.setInptTrvDstc(0);
		} else {
			mbtt02001vo.setInptTrvDstc(Double.parseDouble(request.getParameter("inptTrvDstc")));
		}
		if("".equals(request.getParameter("cnv_trv_dstc")) || null == request.getParameter("cnv_trv_dstc")){
			mbtt02001vo.setCnvTrvDstc(0);
		} else {
			mbtt02001vo.setCnvTrvDstc(Double.parseDouble(request.getParameter("cnv_trv_dstc")));
		}
		if("".equals(request.getParameter("exp_exca_plan_rsl_cd")) || null == request.getParameter("exp_exca_plan_rsl_cd")){
			mbtt02001vo.setExpExcaPlanRslCd(" ");
		} else {
			mbtt02001vo.setExpExcaPlanRslCd(StringUtil.nvl(request.getParameter("exp_exca_plan_rsl_cd")));
		}
		if("".equals(request.getParameter("excaBzProcDvn")) || null == request.getParameter("excaBzProcDvn")){
			mbtt02001vo.setExcaBzProcDvn(" ");
		} else {
			mbtt02001vo.setExcaBzProcDvn(StringUtil.nvl(request.getParameter("excaBzProcDvn")));
		}
		if("".equals(request.getParameter("excaRtrnDvn")) || null == request.getParameter("excaRtrnDvn")){
			mbtt02001vo.setExcaRtrnDvn(" ");
		} else {
			mbtt02001vo.setExcaRtrnDvn(StringUtil.nvl(request.getParameter("excaRtrnPrm")));
		}
		if("".equals(request.getParameter("pdc_sr_dvn")) || null == request.getParameter("pdc_sr_dvn")){
			mbtt02001vo.setPdcSrDvn(" ");
		} else {
			mbtt02001vo.setPdcSrDvn(StringUtil.nvl(request.getParameter("pdc_sr_dvn")));
		}
		if("".equals(request.getParameter("adc_rtrn_prm")) || null == request.getParameter("adc_rtrn_prm")){
			mbtt02001vo.setAdcRtrnPrm(0);
		} else {
			mbtt02001vo.setAdcRtrnPrm(Double.parseDouble(request.getParameter("adc_rtrn_prm")));
		}
		if("".equals(request.getParameter("trvDstcSplcExcaYn")) || null == request.getParameter("trvDstcSplcExcaYn")){
			mbtt02001vo.setTrvDstcSplcExcaYn(" ");
		} else {
			mbtt02001vo.setTrvDstcSplcExcaYn(StringUtil.nvl(request.getParameter("trvDstcSplcExcaYn")));
		}
		if("".equals(request.getParameter("imagDupYn")) || null == request.getParameter("imagDupYn")){
			mbtt02001vo.setImagDupYn(" ");
		} else {
			mbtt02001vo.setImagDupYn(StringUtil.nvl(request.getParameter("imagDupYn")));
		}
		if("".equals(request.getParameter("nrmProcYn")) || null == request.getParameter("nrmProcYn")){
			mbtt02001vo.setNrmProcYn(" ");
		} else {
			mbtt02001vo.setNrmProcYn(StringUtil.nvl(request.getParameter("nrmProcYn")));
		}
		if("".equals(request.getParameter("crdScnCnclPssYn")) || null == request.getParameter("crdScnCnclPssYn")){
			mbtt02001vo.setCrdScnCnclPssYn(" ");
		} else {
			mbtt02001vo.setCrdScnCnclPssYn(StringUtil.nvl(request.getParameter("crdScnCnclPssYn")));
		}
		mbtt02001vo.setRespCn(StringUtil.nvl(jmvo.getZ_resp_cd()));
		mbtt02001vo.setRslCn(scrnNm + "_" + StringUtil.nvl(jmvo.getZ_resp_msg()));
		mbtt02001vo.setFrstIpmnEmpno("82101685");
		mbtt02001vo.setFnalAmdrEmpno("82101685");
		if("".equals(request.getParameter("adc_rtrn_dvn")) || null == request.getParameter("adc_rtrn_dvn")){
			mbtt02001vo.setAdcRtrnDvn(" ");
		} else {
			mbtt02001vo.setAdcRtrnDvn(StringUtil.nvl(request.getParameter("adc_rtrn_dvn")));
		}
		if("".equals(request.getParameter("scrn_proc_cd")) || null == request.getParameter("scrn_proc_cd")){
			mbtt02001vo.setScrnProcCd(" ");
		} else {
			mbtt02001vo.setScrnProcCd(StringUtil.nvl(request.getParameter("scrn_proc_cd")));
		}
		if("".equals(jmvo.getCtc_plno()) || null == jmvo.getCtc_plno()){
			mbtt02001vo.setCtcPlno(" ");
		} else {
			mbtt02001vo.setCtcPlno(StringUtil.nvl(jmvo.getCtc_plno()));
		}
		if("".equals(request.getParameter("trv_dstc_proc_dvcd")) || null == request.getParameter("trv_dstc_proc_dvcd")){
			mbtt02001vo.setTrvDstcProcDvcd(" ");
		} else {
			mbtt02001vo.setTrvDstcProcDvcd(StringUtil.nvl(request.getParameter("trv_dstc_proc_dvcd")));
		}
		if("".equals(request.getParameter("mbl_snd_no")) || null == request.getParameter("mbl_snd_no")){
			mbtt02001vo.setMblSndNo(" ");
		} else {
			mbtt02001vo.setMblSndNo(StringUtil.nvl(request.getParameter("mbl_snd_no")));
		}
		if("".equals(request.getParameter("plan_plno_dvcd")) || null == request.getParameter("plan_plno_dvcd")){
			mbtt02001vo.setPlanPlnoDvcd(" ");
		} else {
			mbtt02001vo.setPlanPlnoDvcd(StringUtil.nvl(request.getParameter("plan_plno_dvcd")));
		}
		if("".equals(request.getParameter("plan_plno")) || null == request.getParameter("plan_plno")){
			mbtt02001vo.setPlanPlno(" ");
		} else {
			mbtt02001vo.setPlanPlno(StringUtil.nvl(request.getParameter("plan_plno")));
		}
		if("".equals(jmvo.getChng_plan_no()) || null == jmvo.getChng_plan_no()){
			mbtt02001vo.setChngPlanNo(" ");
		} else {
			mbtt02001vo.setChngPlanNo(StringUtil.nvl(jmvo.getChng_plan_no()));
		}
		if("".equals(request.getParameter("dst_tty_dvn1")) || null == request.getParameter("dst_tty_dvn1")){
			mbtt02001vo.setDstTtyDvn1(" ");
		} else {
			mbtt02001vo.setDstTtyDvn1(StringUtil.nvl(request.getParameter("dst_tty_dvn1")));
		}
		if("".equals(request.getParameter("dst_tty_dvn2")) || null == request.getParameter("dst_tty_dvn2")){
			mbtt02001vo.setDstTtyDvn2(" ");
		} else {
			mbtt02001vo.setDstTtyDvn2(StringUtil.nvl(request.getParameter("dst_tty_dvn2")));
		}
		if("".equals(request.getParameter("dst_tty_dvn3")) || null == request.getParameter("dst_tty_dvn3")){
			mbtt02001vo.setDstTtyDvn3(" ");
		} else {
			mbtt02001vo.setDstTtyDvn3(StringUtil.nvl(request.getParameter("dst_tty_dvn3")));
		}
		if("".equals(request.getParameter("dst_tty_dvn4")) || null == request.getParameter("dst_tty_dvn4")){
			mbtt02001vo.setDstTtyDvn4(" ");
		} else {
			mbtt02001vo.setDstTtyDvn4(StringUtil.nvl(request.getParameter("dst_tty_dvn4")));
		}
		if("".equals(request.getParameter("dst_tty_dvn5")) || null == request.getParameter("dst_tty_dvn5")){
			mbtt02001vo.setDstTtyDvn5(" ");
		} else {
			mbtt02001vo.setDstTtyDvn5(StringUtil.nvl(request.getParameter("dst_tty_dvn5")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt1")) || null == request.getParameter("phgp_regt_tgt1")){
			mbtt02001vo.setPhgpRegtTgt1(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt1(StringUtil.nvl(request.getParameter("phgp_regt_tgt1")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt2")) || null == request.getParameter("phgp_regt_tgt2")){
			mbtt02001vo.setPhgpRegtTgt2(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt2(StringUtil.nvl(request.getParameter("phgp_regt_tgt2")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt3")) || null == request.getParameter("phgp_regt_tgt3")){
			mbtt02001vo.setPhgpRegtTgt3(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt3(StringUtil.nvl(request.getParameter("phgp_regt_tgt3")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt4")) || null == request.getParameter("phgp_regt_tgt4")){
			mbtt02001vo.setPhgpRegtTgt4(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt4(StringUtil.nvl(request.getParameter("phgp_regt_tgt4")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt5")) || null == request.getParameter("phgp_regt_tgt5")){
			mbtt02001vo.setPhgpRegtTgt5(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt5(StringUtil.nvl(request.getParameter("phgp_regt_tgt5")));
		}
		
		//MMTI0213 insert
		int insertRow = 0;
		
		logger.info("#### ml4 MMTI0213 MBTT02001 before ####");
		insertRow = mileageTobeService.insertJungsanTest(mbtt02001vo);
		logger.info("#### ml4 MMTI0213 MBTT02001 after ####");
		
		if(insertRow < 1){
			logger.info("#### 사서함번호: " + StringUtil.nvl(mbtt02001vo.getPboxNo()) + "####");
			logger.info("#### insert 결과: Fail ####");
		}else{
			logger.info("#### insert 결과: Success ####");
		}
		
		if("2".equals(gubun) || "3".equals(gubun)) {
			MMTI0291VO jmvo1 = new MMTI0291VO();
			
			if("1".equals(request.getParameter("skip"))) {
				jmvo1.setTrv_dstc_exca_mtt__exca_bz_proc_dvn(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__exca_bz_proc_dvn")));
				jmvo1.setTrv_dstc_exca_mtt__plno(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__plno")));
				jmvo1.setTrv_dstc_exca_mtt__plan_no(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__plan_no")));
				jmvo1.setTrv_dstc_exca_mtt__plan_dt(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__plan_dt")));
				jmvo1.setTrv_dstc_exca_mtt__exca_rtrn_dvn(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__exca_rtrn_dvn")));
				jmvo1.setTrv_dstc_exca_mtt__bank_cd(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__bank_cd")));
				jmvo1.setTrv_dstc_exca_mtt__acc_no(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__acc_no")));
				jmvo1.setTrv_dstc_exca_mtt__adc_rtrn_dvn(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__adc_rtrn_dvn")));
				jmvo1.setTrv_dstc_exca_mtt__adc_rtrn_prm(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__adc_rtrn_prm")));
				jmvo1.setTrv_dstc_exca_mtt__cnv_trv_dstc(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__cnv_trv_dstc")));
				jmvo1.setTrv_dstc_exca_mtt__nrm_proc_yn(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__nrm_proc_yn")));
				jmvo1.setTrv_dstc_exca_mtt__aut_cgnt_vh_no_eqal_yn(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__aut_cgnt_vh_no_eqal_yn")));
				jmvo1.setTrv_dstc_exca_mtt__aut_cgnt_trv_dstc_eqal_yn(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__aut_cgnt_trv_dstc_eqal_yn")));
				jmvo1.setTrv_dstc_exca_mtt__rnw_plno(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__rnw_plno")));
				jmvo1.setTrv_dstc_exca_mtt__hdlr_empno(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__hdlr_empno")));
				jmvo1.setTrv_dstc_exca_mtt__aut_cgnt_trv_dstc_rsl_cd(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__aut_cgnt_trv_dstc_rsl_cd")));
				jmvo1.setTrv_dstc_exca_mtt__plhd_cust_nm(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__plhd_cust_nm")));
				jmvo1.setTrv_dstc_exca_mtt__pdc_sr_dvn(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__pdc_sr_dvn")));
				jmvo1.setTrv_dstc_exca_mtt__scrn_proc_cd(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__scrn_proc_cd")));
				jmvo1.setTrv_dstc_exca_mtt__arc_trm_str_dt(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__arc_trm_str_dt")));
				jmvo1.setZ_resp_cd(StringUtil.nvl(request.getParameter("z_resp_cd")));
			}
			else {
				jmvo1.setTrv_dstc_exca_mtt__exca_bz_proc_dvn("2");
				jmvo1.setTrv_dstc_exca_mtt__plno(request.getParameter("plno"));
				jmvo1.setTrv_dstc_exca_mtt__plan_no(request.getParameter("exp_exca_plan_no"));
				jmvo1.setTrv_dstc_exca_mtt__exca_rtrn_dvn("3".equals(gubun) ? "1" : "2");
				jmvo1.setTrv_dstc_exca_mtt__pdc_sr_dvn(request.getParameter("pdc_sr_dvn"));
				jmvo1.setTrv_dstc_exca_mtt__scrn_proc_cd(request.getParameter("exp_exca_plan_rsl_cd"));
				
				if("3".equals(gubun)) {
					String account = "";
					try {
						account = TransKey.decode("account", request);
					}
					catch(Exception e) {
						logger.debug(e.getMessage());
						account = request.getParameter("account");
					}
					logger.debug("account: " + account);
					jmvo1.setTrv_dstc_exca_mtt__bank_cd(request.getParameter("bank"));
					jmvo1.setTrv_dstc_exca_mtt__acc_no(account);
				}
				jmvo1.setTrv_dstc_exca_mtt__adc_rtrn_dvn(request.getParameter("adc_rtrn_dvn"));
				jmvo1.setTrv_dstc_exca_mtt__adc_rtrn_prm(request.getParameter("adc_rtrn_prm"));
				jmvo1.setTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn(jmvo.getTrv_dstc_splc_exca_yn());
				jmvo1.setTrv_dstc_exca_mtt__pbox_no(jmvo.getSms_ts_bvan());
				jmvo1 = mileageTobeService.getMMTI0291VO(jmvo1);
				
				/*
					TB: 	MBTT02001
					IDX:	IMBT02001P (SQNO + PBOX_NO)
					
					COL					NM					VAL
					=================================================================================
					SQNO				일련번호
					PBOX_NO				사서함번호			MMTI0213.sms_ts_bvan
					TLG_ID_VAL			전문ID값			"MMTI0291"
					ESB_TRSC_ID			ESB트랜잭션ID		MMTI0291.z_trsc_id
					PLNO				증권번호			MMTI0291.trv_dstc_exca_mtt__plno
					PLAN_NO				설계번호			MMTI0259.exp_exca_plan_no
					RNW_PLNO			갱신증권번호		MMTI0291.trv_dstc_exca_mtt__rnw_plno
					REGT_DTTM			등록일시			getDayTime() - yyyyMMddHHmmss
					TLG_PROC_RSL_CD_VAL	전문처리결과코드값	MMTI0291.z_resp_cd
					TLG_ERR_CD_VAL		전문에러코드값		MMTI0291.errorCode
					HDLR_EMPNO			취급자사원번호		MMTI0291.trv_dstc_exca_mtt__hdlr_empno
					RESP_CN				응답내용			
					RSL_CN				결과내용			
					
					
				*/
			}
			
			// 부적정/중복 이미지인 경우 화면처리코드 02 
			if("1".equals(jmvo1.getTrv_dstc_exca_mtt__imag_dup_yn())){
				jmvo1.setTrv_dstc_exca_mtt__scrn_proc_cd("02");
			}
			request.setAttribute("jmvo1", jmvo1);
			
			// CM 상품이고, 화면처리코드 IN(02, 14) or 이미지 중복
			
			if("CM".equals(jmvo1.getTrv_dstc_exca_mtt__pdc_sr_dvn()) && 
					("02".equals(jmvo1.getTrv_dstc_exca_mtt__scrn_proc_cd())
					|| "14".equals(jmvo1.getTrv_dstc_exca_mtt__scrn_proc_cd()))){
				
				MMTI0015VO mmti0015vo = new MMTI0015VO();
				mmti0015vo.setFunt_key("00");
				mmti0015vo.setPlan_no(jmvo1.getTrv_dstc_exca_mtt__plan_no());
				mmti0015vo = mileageTobeService.getMMTI0015VO(mmti0015vo);
				
				logger.debug("##### MMTI0015 시작 ##########################");
				logger.debug("##### 고객식별번호: " + mmti0015vo.getPlhd__cust_dcmt_no() + " ##########################");
				logger.debug("##### 고객번호: " + mmti0015vo.getPlhd__cust_no() + " ##########################");
				logger.debug("##### 고객명: " + mmti0015vo.getPlhd__cust_nm() + " ##########################");
				logger.debug("##### 이메일: " + mmti0015vo.getPlhd__eml() + " ##########################");
				logger.debug("##### 지역번호: " + mmti0015vo.getPlhd_cntp_if__tlp_arno() + " ##########################");
				logger.debug("##### 국번호: " + mmti0015vo.getPlhd_cntp_if__tlp_ofno() + " ##########################");
				logger.debug("##### 개별번호: " + mmti0015vo.getPlhd_cntp_if__tlp_idvno() + " ##########################");
				
				XTEM0021VO xtem0021vo = new XTEM0021VO();
				xtem0021vo.setCnsl_rpt_no("");						// 상담접수번호				
				xtem0021vo.setCm_bz_dvcd("05");
				xtem0021vo.setCnsl_typ_dvcd("07");
				xtem0021vo.setCm_plan_no(jmvo1.getTrv_dstc_exca_mtt__plan_no());
				xtem0021vo.setCnsl_rpy_dvcd("1");
				xtem0021vo.setCnsl_rpt_dttm(getDayTime());			// 현재년월일시분초 14자리
				xtem0021vo.setCust_nm(mmti0015vo.getPlhd__cust_nm());
				xtem0021vo.setCust_no(mmti0015vo.getPlhd__cust_no());
				
				String cust_dcmt_no = SeedUtil.decrypt(mmti0015vo.getPlhd__cust_dcmt_no());
				
				if("1".equals(cust_dcmt_no.substring(6, 7)) || "2".equals(cust_dcmt_no.substring(6, 7))
					|| "5".equals(cust_dcmt_no.substring(6, 7)) || "6".equals(cust_dcmt_no.substring(6, 7))){
					xtem0021vo.setBrth("19" + cust_dcmt_no.substring(0, 6));
				} else{
					xtem0021vo.setBrth("20" + cust_dcmt_no.substring(0, 6));
				}
				// xtem0021vo.setBrth("");  							// 생년월일
				xtem0021vo.setSx_cd(cust_dcmt_no.substring(6, 7));
				xtem0021vo.setEml_adr(mmti0015vo.getPlhd__eml());
				xtem0021vo.setClp_tlcno(mmti0015vo.getPlhd_cntp_if__tlp_arno());
				xtem0021vo.setClp_ofno(mmti0015vo.getPlhd_cntp_if__tlp_ofno());
				xtem0021vo.setClp_idvno(mmti0015vo.getPlhd_cntp_if__tlp_idvno());
				xtem0021vo.setCnsl_rsvt_dt("99990101");
				xtem0021vo.setCnsl_rsvt_time_cd("1");
				xtem0021vo.setCnsl_cn("최종주행거리사진등록/만기정산");
				xtem0021vo.setCnsl_aply_csn_yn("1");
				xtem0021vo.setUrl_adr("");
				xtem0021vo.setCm_ctrmf_tpcd("32");
				xtem0021vo.setFrst_ipmn_empno("80000028");
				xtem0021vo.setFrst_ipnpt_dttm(getDayTime());		// 현재년월일시분초 14자리	
				
				xtem0021vo = mileageTobeService.getXTEM0021VO(xtem0021vo);
				logger.debug("##### XTEM0021 시작 ##########################");
				logger.debug("##### 처리결과: [ " + xtem0021vo.getProc_rtn() + " ] ##########################");
			}
			
			//MMTI0291전문 정산이력테이블(MBTT02001) 적재
			mbtt02001vo.setPboxNo(StringUtil.nvl(jmvo.getSms_ts_bvan()));
			mbtt02001vo.setTlgIdVal("MMTI0291");
			mbtt02001vo.setEsbTrscId(StringUtil.nvl(jmvo1.getZ_trsc_id()));
			if("".equals(request.getParameter("plno")) || null == request.getParameter("plno")){
				mbtt02001vo.setPlno(" ");
			} else {
				mbtt02001vo.setPlno(StringUtil.nvl(request.getParameter("plno")));
			}
			if("".equals(jmvo1.getTrv_dstc_exca_mtt__plan_no()) || null == jmvo1.getTrv_dstc_exca_mtt__plan_no()){
				mbtt02001vo.setPlanNo(" ");
			} else {
				mbtt02001vo.setPlanNo(StringUtil.nvl(jmvo1.getTrv_dstc_exca_mtt__plan_no()));
			}
			if("".equals(jmvo1.getTrv_dstc_exca_mtt__rnw_plno()) || null == jmvo1.getTrv_dstc_exca_mtt__rnw_plno()){
				mbtt02001vo.setRnwPlno(" ");
			} else {
				mbtt02001vo.setRnwPlno(StringUtil.nvl(jmvo1.getTrv_dstc_exca_mtt__rnw_plno()));
			}
			mbtt02001vo.setTlgProcRslCdVal(StringUtil.nvl(jmvo1.getZ_tlg_sp_cd()));
			mbtt02001vo.setTlgErrCdVal(StringUtil.nvl(jmvo1.getZ_trns_org_dvcd())+StringUtil.nvl(jmvo1.getZ_trns_org_cd()));
			if("".equals(jmvo1.getTrv_dstc_exca_mtt__hdlr_empno()) || null == jmvo1.getTrv_dstc_exca_mtt__hdlr_empno()){
				mbtt02001vo.setHdlrEmpno(" ");
			} else {
				mbtt02001vo.setHdlrEmpno(StringUtil.nvl(jmvo1.getTrv_dstc_exca_mtt__hdlr_empno()));
			}
			if("".equals(jmvo.getPbox_no_dvcd()) || null == jmvo.getPbox_no_dvcd()){
				mbtt02001vo.setPboxNoDvcd(" ");
			} else {
				mbtt02001vo.setPboxNoDvcd(StringUtil.nvl(jmvo.getPbox_no_dvcd()));
			}
			if("".equals(jmvo.getProc_dvn()) || null == jmvo.getProc_dvn()){
				mbtt02001vo.setProcDvn(" ");
			} else {
				mbtt02001vo.setProcDvn(StringUtil.nvl(jmvo.getProc_dvn()));
			}
			if("".equals(jmvo.getTrv_dstc_exp_exca_dvcd()) || null == jmvo.getTrv_dstc_exp_exca_dvcd()){
				mbtt02001vo.setTrvDstcExpExcaDvcd(" ");
			} else {
				mbtt02001vo.setTrvDstcExpExcaDvcd(StringUtil.nvl(jmvo.getTrv_dstc_exp_exca_dvcd()));
			}
			if("".equals(jmvo.getTrv_dstc_chng_aply_dvn()) || null == jmvo.getTrv_dstc_chng_aply_dvn()){
				mbtt02001vo.setTrvDstcChngAplyDvn(" ");
			} else {
				mbtt02001vo.setTrvDstcChngAplyDvn(StringUtil.nvl(jmvo.getTrv_dstc_chng_aply_dvn()));
			}
			if("".equals(jmvo.getHdlr_fire_yn()) || null == jmvo.getHdlr_fire_yn()){
				mbtt02001vo.setHdlrFireYn(" ");
			} else {
				mbtt02001vo.setHdlrFireYn(StringUtil.nvl(jmvo.getHdlr_fire_yn()));
			}
			if("".equals(jmvo.getMtcc_yn()) || null == jmvo.getMtcc_yn()){
				mbtt02001vo.setMtccYn(" ");
			} else {
				mbtt02001vo.setMtccYn(StringUtil.nvl(jmvo.getMtcc_yn()));
			}
			if("".equals(request.getParameter("aut_cgnt_trv_dstc")) || null == request.getParameter("aut_cgnt_trv_dstc")){
				mbtt02001vo.setAutCgntTrvDstc(0);
			} else {
				mbtt02001vo.setAutCgntTrvDstc(Double.parseDouble(request.getParameter("aut_cgnt_trv_dstc")));
			}
			if("".equals(jmvo1.getTrv_dstc_exca_mtt__aut_cgnt_trv_dstc_rsl_cd()) || null == jmvo1.getTrv_dstc_exca_mtt__aut_cgnt_trv_dstc_rsl_cd()){
				mbtt02001vo.setAutCgntTrvDstcRslCd(" ");
			} else {
				mbtt02001vo.setAutCgntTrvDstcRslCd(StringUtil.nvl(jmvo1.getTrv_dstc_exca_mtt__aut_cgnt_trv_dstc_rsl_cd()));
			}
			if("".equals(request.getParameter("inptTrvDstc")) || null == request.getParameter("inptTrvDstc")){
				mbtt02001vo.setInptTrvDstc(0);
			} else {
				mbtt02001vo.setInptTrvDstc(Double.parseDouble(request.getParameter("inptTrvDstc")));
			}
			if("".equals(jmvo1.getTrv_dstc_exca_mtt__cnv_trv_dstc()) || null == jmvo1.getTrv_dstc_exca_mtt__cnv_trv_dstc()){
				mbtt02001vo.setCnvTrvDstc(0);
			} else {
				mbtt02001vo.setCnvTrvDstc(Double.parseDouble(jmvo1.getTrv_dstc_exca_mtt__cnv_trv_dstc()));
			}
			if("".equals(request.getParameter("exp_exca_plan_rsl_cd")) || null == request.getParameter("exp_exca_plan_rsl_cd")){
				mbtt02001vo.setExpExcaPlanRslCd(" ");
			} else {
				mbtt02001vo.setExpExcaPlanRslCd(StringUtil.nvl(request.getParameter("exp_exca_plan_rsl_cd")));
			}
			if("".equals(jmvo1.getTrv_dstc_exca_mtt__exca_bz_proc_dvn()) || null == jmvo1.getTrv_dstc_exca_mtt__exca_bz_proc_dvn()){
				mbtt02001vo.setExcaBzProcDvn(" ");
			} else {
				mbtt02001vo.setExcaBzProcDvn(StringUtil.nvl(jmvo1.getTrv_dstc_exca_mtt__exca_bz_proc_dvn()));
			}
			if("".equals(jmvo1.getTrv_dstc_exca_mtt__exca_rtrn_dvn()) || null == jmvo1.getTrv_dstc_exca_mtt__exca_rtrn_dvn()){
				mbtt02001vo.setExcaRtrnDvn(" ");
			} else {
				mbtt02001vo.setExcaRtrnDvn(StringUtil.nvl(jmvo1.getTrv_dstc_exca_mtt__exca_rtrn_dvn()));
			}
			if("".equals(jmvo1.getTrv_dstc_exca_mtt__pdc_sr_dvn()) || null == jmvo1.getTrv_dstc_exca_mtt__pdc_sr_dvn()){
				mbtt02001vo.setPdcSrDvn(" ");
			} else {
				mbtt02001vo.setPdcSrDvn(StringUtil.nvl(jmvo1.getTrv_dstc_exca_mtt__pdc_sr_dvn()));
			}
			if("".equals(jmvo1.getTrv_dstc_exca_mtt__adc_rtrn_prm()) || null == jmvo1.getTrv_dstc_exca_mtt__adc_rtrn_prm()){
				mbtt02001vo.setAdcRtrnPrm(0);
			} else {
				mbtt02001vo.setAdcRtrnPrm(Double.parseDouble(jmvo1.getTrv_dstc_exca_mtt__adc_rtrn_prm()));
			}
			if("".equals(jmvo1.getTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn()) || null == jmvo1.getTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn()){
				mbtt02001vo.setTrvDstcSplcExcaYn(" ");
			} else {
				mbtt02001vo.setTrvDstcSplcExcaYn(StringUtil.nvl(jmvo1.getTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn()));
			}
			if("".equals(jmvo1.getTrv_dstc_exca_mtt__imag_dup_yn()) || null == jmvo1.getTrv_dstc_exca_mtt__imag_dup_yn()){
				mbtt02001vo.setImagDupYn(" ");
			} else {
				mbtt02001vo.setImagDupYn(StringUtil.nvl(jmvo1.getTrv_dstc_exca_mtt__imag_dup_yn()));
			}
			if("".equals(jmvo1.getTrv_dstc_exca_mtt__nrm_proc_yn()) || null == jmvo1.getTrv_dstc_exca_mtt__nrm_proc_yn()){
				mbtt02001vo.setNrmProcYn(" ");
			} else {
				mbtt02001vo.setNrmProcYn(StringUtil.nvl(jmvo1.getTrv_dstc_exca_mtt__nrm_proc_yn()));
			}
			if("".equals(request.getParameter("crdScnCnclPssYn")) || null == request.getParameter("crdScnCnclPssYn")){
				mbtt02001vo.setCrdScnCnclPssYn(" ");
			} else {
				mbtt02001vo.setCrdScnCnclPssYn(StringUtil.nvl(request.getParameter("crdScnCnclPssYn")));
			}
			mbtt02001vo.setRespCn(StringUtil.nvl(jmvo1.getZ_resp_cd()));
			mbtt02001vo.setRslCn(scrnNm + "_" + StringUtil.nvl(jmvo1.getZ_resp_msg()));
			mbtt02001vo.setFrstIpmnEmpno("82101685");
			mbtt02001vo.setFnalAmdrEmpno("82101685");
			if("".equals(jmvo1.getTrv_dstc_exca_mtt__adc_rtrn_dvn()) || null == jmvo1.getTrv_dstc_exca_mtt__adc_rtrn_dvn()){
				mbtt02001vo.setAdcRtrnDvn(" ");
			} else {
				mbtt02001vo.setAdcRtrnDvn(StringUtil.nvl(jmvo1.getTrv_dstc_exca_mtt__adc_rtrn_dvn()));
			}
			if("".equals(jmvo1.getTrv_dstc_exca_mtt__scrn_proc_cd()) || null == jmvo1.getTrv_dstc_exca_mtt__scrn_proc_cd()){
				mbtt02001vo.setScrnProcCd(" ");
			} else {
				mbtt02001vo.setScrnProcCd(StringUtil.nvl(jmvo1.getTrv_dstc_exca_mtt__scrn_proc_cd()));
			}
			if("".equals(request.getParameter("ctc_plno")) || null == request.getParameter("ctc_plno")){
				mbtt02001vo.setCtcPlno(" ");
			} else {
				mbtt02001vo.setCtcPlno(StringUtil.nvl(request.getParameter("ctc_plno")));
			}
			if("".equals(request.getParameter("trv_dstc_proc_dvcd")) || null == request.getParameter("trv_dstc_proc_dvcd")){
				mbtt02001vo.setTrvDstcProcDvcd(" ");
			} else {
				mbtt02001vo.setTrvDstcProcDvcd(StringUtil.nvl(request.getParameter("trv_dstc_proc_dvcd")));
			}
			if("".equals(request.getParameter("mbl_snd_no")) || null == request.getParameter("mbl_snd_no")){
				mbtt02001vo.setMblSndNo(" ");
			} else {
				mbtt02001vo.setMblSndNo(StringUtil.nvl(request.getParameter("mbl_snd_no")));
			}
			if("".equals(request.getParameter("plan_plno_dvcd")) || null == request.getParameter("plan_plno_dvcd")){
				mbtt02001vo.setPlanPlnoDvcd(" ");
			} else {
				mbtt02001vo.setPlanPlnoDvcd(StringUtil.nvl(request.getParameter("plan_plno_dvcd")));
			}
			if("".equals(request.getParameter("plan_plno")) || null == request.getParameter("plan_plno")){
				mbtt02001vo.setPlanPlno(" ");
			} else {
				mbtt02001vo.setPlanPlno(StringUtil.nvl(request.getParameter("plan_plno")));
			}
			if("".equals(request.getParameter("chng_plan_no")) || null == request.getParameter("chng_plan_no")){
				mbtt02001vo.setChngPlanNo(" ");
			} else {
				mbtt02001vo.setChngPlanNo(StringUtil.nvl(request.getParameter("chng_plan_no")));
			}
			if("".equals(request.getParameter("dst_tty_dvn1")) || null == request.getParameter("dst_tty_dvn1")){
				mbtt02001vo.setDstTtyDvn1(" ");
			} else {
				mbtt02001vo.setDstTtyDvn1(StringUtil.nvl(request.getParameter("dst_tty_dvn1")));
			}
			if("".equals(request.getParameter("dst_tty_dvn2")) || null == request.getParameter("dst_tty_dvn2")){
				mbtt02001vo.setDstTtyDvn2(" ");
			} else {
				mbtt02001vo.setDstTtyDvn2(StringUtil.nvl(request.getParameter("dst_tty_dvn2")));
			}
			if("".equals(request.getParameter("dst_tty_dvn3")) || null == request.getParameter("dst_tty_dvn3")){
				mbtt02001vo.setDstTtyDvn3(" ");
			} else {
				mbtt02001vo.setDstTtyDvn3(StringUtil.nvl(request.getParameter("dst_tty_dvn3")));
			}
			if("".equals(request.getParameter("dst_tty_dvn4")) || null == request.getParameter("dst_tty_dvn4")){
				mbtt02001vo.setDstTtyDvn4(" ");
			} else {
				mbtt02001vo.setDstTtyDvn4(StringUtil.nvl(request.getParameter("dst_tty_dvn4")));
			}
			if("".equals(request.getParameter("dst_tty_dvn5")) || null == request.getParameter("dst_tty_dvn5")){
				mbtt02001vo.setDstTtyDvn5(" ");
			} else {
				mbtt02001vo.setDstTtyDvn5(StringUtil.nvl(request.getParameter("dst_tty_dvn5")));
			}
			if("".equals(request.getParameter("phgp_regt_tgt1")) || null == request.getParameter("phgp_regt_tgt1")){
				mbtt02001vo.setPhgpRegtTgt1(" ");
			} else {
				mbtt02001vo.setPhgpRegtTgt1(StringUtil.nvl(request.getParameter("phgp_regt_tgt1")));
			}
			if("".equals(request.getParameter("phgp_regt_tgt2")) || null == request.getParameter("phgp_regt_tgt2")){
				mbtt02001vo.setPhgpRegtTgt2(" ");
			} else {
				mbtt02001vo.setPhgpRegtTgt2(StringUtil.nvl(request.getParameter("phgp_regt_tgt2")));
			}
			if("".equals(request.getParameter("phgp_regt_tgt3")) || null == request.getParameter("phgp_regt_tgt3")){
				mbtt02001vo.setPhgpRegtTgt3(" ");
			} else {
				mbtt02001vo.setPhgpRegtTgt3(StringUtil.nvl(request.getParameter("phgp_regt_tgt3")));
			}
			if("".equals(request.getParameter("phgp_regt_tgt4")) || null == request.getParameter("phgp_regt_tgt4")){
				mbtt02001vo.setPhgpRegtTgt4(" ");
			} else {
				mbtt02001vo.setPhgpRegtTgt4(StringUtil.nvl(request.getParameter("phgp_regt_tgt4")));
			}
			if("".equals(request.getParameter("phgp_regt_tgt5")) || null == request.getParameter("phgp_regt_tgt5")){
				mbtt02001vo.setPhgpRegtTgt5(" ");
			} else {
				mbtt02001vo.setPhgpRegtTgt5(StringUtil.nvl(request.getParameter("phgp_regt_tgt5")));
			}
			
			//MMTI0291 insert
			insertRow = 0;
			
			logger.info("#### ml4 MMTI0291 MBTT02001 before ####");
			insertRow = mileageTobeService.insertJungsanTest(mbtt02001vo);
			logger.info("#### ml4 MMTI0291 MBTT02001 after ####");
			
			if(insertRow < 1){
				logger.info("#### 사서함번호: " + StringUtil.nvl(mbtt02001vo.getPboxNo()) + "####");
				logger.info("#### insert 결과: Fail ####");
			}else{
				logger.info("#### insert 결과: Success ####");
			}
		}
		
		return "/counter/carrider/tobe/ml4";
	}
	
	@RequestMapping(value="/ml4_1")
	public String ml4_1(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
	
		HttpSession session = request.getSession();
		
		logger.debug("####### ml4_1 값 확인 #######");
		logger.debug("p: " + StringUtil.nvl(request.getParameter("p")));
		logger.debug("plno: " + request.getParameter("plno"));
		logger.debug("exp_exca_plan_no: " + request.getParameter("exp_exca_plan_no"));
		logger.debug("cnv_trv_dstc: " + request.getParameter("cnv_trv_dstc"));
		logger.debug("pdc_sr_dvn: " + request.getParameter("pdc_sr_dvn"));
//		logger.debug("appSeq: " + request.getParameter("appSeq"));
		logger.debug("exp_exca_plan_rsl_cd: " + request.getParameter("exp_exca_plan_rsl_cd"));
		logger.debug("adc_rtrn_dvn: " + request.getParameter("adc_rtrn_dvn"));
		logger.debug("adc_rtrn_prm: " + request.getParameter("adc_rtrn_prm"));
		
		session.setAttribute("p", request.getParameter("p"));
		
//		model.addAttribute("exp_exca_plan_rsl_cd",		request.getParameter("exp_exca_plan_rsl_cd"));
//		model.addAttribute("adc_rtrn_dvn",				request.getParameter("adc_rtrn_dvn"));
		
		// 증번 설번
		session.setAttribute("plno", request.getParameter("plno"));
		session.setAttribute("exp_exca_plan_no", request.getParameter("exp_exca_plan_no"));
		
//		model.addAttribute("exp_exca_plan_bse_dd",		request.getParameter("exp_exca_plan_bse_dd"));
//		model.addAttribute("aut_cgnt_vh_no",			request.getParameter("aut_cgnt_vh_no"));
//		model.addAttribute("aut_cgnt_vh_no_rsl_cd",		request.getParameter("aut_cgnt_vh_no_rsl_cd"));
//		model.addAttribute("aut_cgnt_trv_dstc",			request.getParameter("aut_cgnt_trv_dstc"));
//		model.addAttribute("aut_cgnt_trv_dstc_rsl_cd",	request.getParameter("aut_cgnt_trv_dstc_rsl_cd"));
		
		// 연환산 주행거리
		session.setAttribute("cnv_trv_dstc", request.getParameter("cnv_trv_dstc"));
		//model.addAttribute("cnv_trv_dstc",				request.getParameter("cnv_trv_dstc"));
//		model.addAttribute("plhd_cust_nm",				request.getParameter("plhd_cust_nm"));
		
		// 상품출처
		session.setAttribute("pdc_sr_dvn", request.getParameter("pdc_sr_dvn"));
		
		//시퀀스
		session.setAttribute("appSeq",					request.getParameter("appSeq"));
		session.setAttribute("webSeq",					request.getParameter("webSeq"));
		// model.addAttribute("appSeq",					request.getParameter("appSeq"));
//		model.addAttribute("pdc_sr_dvn",			request.getParameter("pdc_sr_dvn"));
		
		// 화면처리코드, 추징환급구분
		session.setAttribute("exp_exca_plan_rsl_cd", request.getParameter("exp_exca_plan_rsl_cd"));
		session.setAttribute("adc_rtrn_dvn", request.getParameter("adc_rtrn_dvn"));
		
		// 추징환급보험료(갱신보험료 차감금액)
		session.setAttribute("adc_rtrn_prm", request.getParameter("adc_rtrn_prm"));
		
		// 입력주행거리(ocr2에서 넘김)
		// model.addAttribute("trv_dstc1", request.getParameter("mileage1"));
		session.setAttribute("renewal", "01");
		
		
		//정산이력테이블(MBTT02001) 적재
		MBTT02001VO mbtt02001vo = new MBTT02001VO();
		String scrnNm = "ml4_1";
		
		mbtt02001vo.setPboxNo(StringUtil.nvl(request.getParameter("pbox_no")));
		mbtt02001vo.setTlgIdVal(" ");
		mbtt02001vo.setEsbTrscId(" ");
		if("".equals(request.getParameter("plno")) || null == request.getParameter("plno")){
			mbtt02001vo.setPlno(" ");
		} else {
			mbtt02001vo.setPlno(StringUtil.nvl(request.getParameter("plno")));
		}
		if("".equals(request.getParameter("exp_exca_plan_no")) || null == request.getParameter("exp_exca_plan_no")){
			mbtt02001vo.setPlanNo(" ");
		} else {
			mbtt02001vo.setPlanNo(StringUtil.nvl(request.getParameter("exp_exca_plan_no")));
		}
		if("".equals(request.getParameter("rnw_plno")) || null == request.getParameter("rnw_plno")){
			mbtt02001vo.setRnwPlno(" ");
		} else {
			mbtt02001vo.setRnwPlno(StringUtil.nvl(request.getParameter("rnw_plno")));
		}
		mbtt02001vo.setTlgProcRslCdVal(StringUtil.nvl(request.getParameter("tlg_proc_rsl_cd_val")));
		mbtt02001vo.setTlgErrCdVal(StringUtil.nvl(request.getParameter("tlg_err_cd_val")));
		if("".equals(request.getParameter("hdlr_empno")) || null == request.getParameter("hdlr_empno")){
			mbtt02001vo.setHdlrEmpno(" ");
		} else {
			mbtt02001vo.setHdlrEmpno(StringUtil.nvl(request.getParameter("hdlr_empno")));
		}
		if("".equals(request.getParameter("pbox_no_dvcd")) || null == request.getParameter("pbox_no_dvcd")){
			mbtt02001vo.setPboxNoDvcd(" ");
		} else {
			mbtt02001vo.setPboxNoDvcd(StringUtil.nvl(request.getParameter("pbox_no_dvcd")));
		}
		if("".equals(request.getParameter("proc_dvn")) || null == request.getParameter("proc_dvn")){
			mbtt02001vo.setProcDvn(" ");
		} else {
			mbtt02001vo.setProcDvn(StringUtil.nvl(request.getParameter("proc_dvn")));
		}
		if("".equals(request.getParameter("trv_dstc_exp_exca_dvcd")) || null == request.getParameter("trv_dstc_exp_exca_dvcd")){
			mbtt02001vo.setTrvDstcExpExcaDvcd(" ");
		} else {
			mbtt02001vo.setTrvDstcExpExcaDvcd(StringUtil.nvl(request.getParameter("trv_dstc_exp_exca_dvcd")));
		}
		if("".equals(request.getParameter("trv_dstc_chng_aply_dvn")) || null == request.getParameter("trv_dstc_chng_aply_dvn")){
			mbtt02001vo.setTrvDstcChngAplyDvn(" ");
		} else {
			mbtt02001vo.setTrvDstcChngAplyDvn(StringUtil.nvl(request.getParameter("trv_dstc_chng_aply_dvn")));
		}
		if("".equals(request.getParameter("hdlr_fire_yn")) || null == request.getParameter("hdlr_fire_yn")){
			mbtt02001vo.setHdlrFireYn(" ");
		} else {
			mbtt02001vo.setHdlrFireYn(StringUtil.nvl(request.getParameter("hdlr_fire_yn")));
		}
		if("".equals(request.getParameter("mtcc_yn")) || null == request.getParameter("mtcc_yn")){
			mbtt02001vo.setMtccYn(" ");
		} else {
			mbtt02001vo.setMtccYn(StringUtil.nvl(request.getParameter("mtcc_yn")));
		}
		if("".equals(request.getParameter("aut_cgnt_trv_dstc")) || null == request.getParameter("aut_cgnt_trv_dstc")){
			mbtt02001vo.setAutCgntTrvDstc(0);
		} else {
			mbtt02001vo.setAutCgntTrvDstc(Double.parseDouble(request.getParameter("aut_cgnt_trv_dstc")));
		}
		if("".equals(request.getParameter("autCgntTrvDstcRslCd")) || null == request.getParameter("autCgntTrvDstcRslCd")){
			mbtt02001vo.setAutCgntTrvDstcRslCd(" ");
		} else {
			mbtt02001vo.setAutCgntTrvDstcRslCd(StringUtil.nvl(request.getParameter("autCgntTrvDstcRslCd")));
		}
		if("".equals(request.getParameter("inptTrvDstc")) || null == request.getParameter("inptTrvDstc")){
			mbtt02001vo.setInptTrvDstc(0);
		} else {
			mbtt02001vo.setInptTrvDstc(Double.parseDouble(request.getParameter("inptTrvDstc")));
		}
		if("".equals(request.getParameter("cnv_trv_dstc")) || null == request.getParameter("cnv_trv_dstc")){
			mbtt02001vo.setCnvTrvDstc(0);
		} else {
			mbtt02001vo.setCnvTrvDstc(Double.parseDouble(request.getParameter("cnv_trv_dstc")));
		}
		if("".equals(request.getParameter("exp_exca_plan_rsl_cd")) || null == request.getParameter("exp_exca_plan_rsl_cd")){
			mbtt02001vo.setExpExcaPlanRslCd(" ");
		} else {
			mbtt02001vo.setExpExcaPlanRslCd(StringUtil.nvl(request.getParameter("exp_exca_plan_rsl_cd")));
		}
		if("".equals(request.getParameter("excaBzProcDvn")) || null == request.getParameter("excaBzProcDvn")){
			mbtt02001vo.setExcaBzProcDvn(" ");
		} else {
			mbtt02001vo.setExcaBzProcDvn(StringUtil.nvl(request.getParameter("excaBzProcDvn")));
		}
		if("".equals(request.getParameter("excaRtrnDvn")) || null == request.getParameter("excaRtrnDvn")){
			mbtt02001vo.setExcaRtrnDvn(" ");
		} else {
			mbtt02001vo.setExcaRtrnDvn(StringUtil.nvl(request.getParameter("excaRtrnPrm")));
		}
		if("".equals(request.getParameter("pdc_sr_dvn")) || null == request.getParameter("pdc_sr_dvn")){
			mbtt02001vo.setPdcSrDvn(" ");
		} else {
			mbtt02001vo.setPdcSrDvn(StringUtil.nvl(request.getParameter("pdc_sr_dvn")));
		}
		if("".equals(request.getParameter("adc_rtrn_prm")) || null == request.getParameter("adc_rtrn_prm")){
			mbtt02001vo.setAdcRtrnPrm(0);
		} else {
			mbtt02001vo.setAdcRtrnPrm(Double.parseDouble(request.getParameter("adc_rtrn_prm")));
		}
		if("".equals(request.getParameter("trvDstcSplcExcaYn")) || null == request.getParameter("trvDstcSplcExcaYn")){
			mbtt02001vo.setTrvDstcSplcExcaYn(" ");
		} else {
			mbtt02001vo.setTrvDstcSplcExcaYn(StringUtil.nvl(request.getParameter("trvDstcSplcExcaYn")));
		}
		if("".equals(request.getParameter("imagDupYn")) || null == request.getParameter("imagDupYn")){
			mbtt02001vo.setImagDupYn(" ");
		} else {
			mbtt02001vo.setImagDupYn(StringUtil.nvl(request.getParameter("imagDupYn")));
		}
		if("".equals(request.getParameter("nrmProcYn")) || null == request.getParameter("nrmProcYn")){
			mbtt02001vo.setNrmProcYn(" ");
		} else {
			mbtt02001vo.setNrmProcYn(StringUtil.nvl(request.getParameter("nrmProcYn")));
		}
		if("".equals(request.getParameter("crdScnCnclPssYn")) || null == request.getParameter("crdScnCnclPssYn")){
			mbtt02001vo.setCrdScnCnclPssYn(" ");
		} else {
			mbtt02001vo.setCrdScnCnclPssYn(StringUtil.nvl(request.getParameter("crdScnCnclPssYn")));
		}
		if("".equals(request.getParameter("resp_cn")) || null == request.getParameter("resp_cn")){
			mbtt02001vo.setRespCn(" ");
		} else {
			mbtt02001vo.setRespCn(StringUtil.nvl(request.getParameter("resp_cn")));
		}
		mbtt02001vo.setRslCn(scrnNm + "_" + StringUtil.nvl(request.getParameter("rsl_cn")));
		mbtt02001vo.setFrstIpmnEmpno("82101685");
		mbtt02001vo.setFnalAmdrEmpno("82101685");
		if("".equals(request.getParameter("adc_rtrn_dvn")) || null == request.getParameter("adc_rtrn_dvn")){
			mbtt02001vo.setAdcRtrnDvn(" ");
		} else {
			mbtt02001vo.setAdcRtrnDvn(StringUtil.nvl(request.getParameter("adc_rtrn_dvn")));
		}
		if("".equals(request.getParameter("scrn_proc_cd")) || null == request.getParameter("scrn_proc_cd")){
			mbtt02001vo.setScrnProcCd(" ");
		} else {
			mbtt02001vo.setScrnProcCd(StringUtil.nvl(request.getParameter("scrn_proc_cd")));
		}
		if("".equals(request.getParameter("ctc_plno")) || null == request.getParameter("ctc_plno")){
			mbtt02001vo.setCtcPlno(" ");
		} else {
			mbtt02001vo.setCtcPlno(StringUtil.nvl(request.getParameter("ctc_plno")));
		}
		if("".equals(request.getParameter("trv_dstc_proc_dvcd")) || null == request.getParameter("trv_dstc_proc_dvcd")){
			mbtt02001vo.setTrvDstcProcDvcd(" ");
		} else {
			mbtt02001vo.setTrvDstcProcDvcd(StringUtil.nvl(request.getParameter("trv_dstc_proc_dvcd")));
		}
		if("".equals(request.getParameter("mbl_snd_no")) || null == request.getParameter("mbl_snd_no")){
			mbtt02001vo.setMblSndNo(" ");
		} else {
			mbtt02001vo.setMblSndNo(StringUtil.nvl(request.getParameter("mbl_snd_no")));
		}
		if("".equals(request.getParameter("plan_plno_dvcd")) || null == request.getParameter("plan_plno_dvcd")){
			mbtt02001vo.setPlanPlnoDvcd(" ");
		} else {
			mbtt02001vo.setPlanPlnoDvcd(StringUtil.nvl(request.getParameter("plan_plno_dvcd")));
		}
		if("".equals(request.getParameter("plan_plno")) || null == request.getParameter("plan_plno")){
			mbtt02001vo.setPlanPlno(" ");
		} else {
			mbtt02001vo.setPlanPlno(StringUtil.nvl(request.getParameter("plan_plno")));
		}
		if("".equals(request.getParameter("chng_plan_no")) || null == request.getParameter("chng_plan_no")){
			mbtt02001vo.setChngPlanNo(" ");
		} else {
			mbtt02001vo.setChngPlanNo(StringUtil.nvl(request.getParameter("chng_plan_no")));
		}
		if("".equals(request.getParameter("dst_tty_dvn1")) || null == request.getParameter("dst_tty_dvn1")){
			mbtt02001vo.setDstTtyDvn1(" ");
		} else {
			mbtt02001vo.setDstTtyDvn1(StringUtil.nvl(request.getParameter("dst_tty_dvn1")));
		}
		if("".equals(request.getParameter("dst_tty_dvn2")) || null == request.getParameter("dst_tty_dvn2")){
			mbtt02001vo.setDstTtyDvn2(" ");
		} else {
			mbtt02001vo.setDstTtyDvn2(StringUtil.nvl(request.getParameter("dst_tty_dvn2")));
		}
		if("".equals(request.getParameter("dst_tty_dvn3")) || null == request.getParameter("dst_tty_dvn3")){
			mbtt02001vo.setDstTtyDvn3(" ");
		} else {
			mbtt02001vo.setDstTtyDvn3(StringUtil.nvl(request.getParameter("dst_tty_dvn3")));
		}
		if("".equals(request.getParameter("dst_tty_dvn4")) || null == request.getParameter("dst_tty_dvn4")){
			mbtt02001vo.setDstTtyDvn4(" ");
		} else {
			mbtt02001vo.setDstTtyDvn4(StringUtil.nvl(request.getParameter("dst_tty_dvn4")));
		}
		if("".equals(request.getParameter("dst_tty_dvn5")) || null == request.getParameter("dst_tty_dvn5")){
			mbtt02001vo.setDstTtyDvn5(" ");
		} else {
			mbtt02001vo.setDstTtyDvn5(StringUtil.nvl(request.getParameter("dst_tty_dvn5")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt1")) || null == request.getParameter("phgp_regt_tgt1")){
			mbtt02001vo.setPhgpRegtTgt1(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt1(StringUtil.nvl(request.getParameter("phgp_regt_tgt1")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt2")) || null == request.getParameter("phgp_regt_tgt2")){
			mbtt02001vo.setPhgpRegtTgt2(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt2(StringUtil.nvl(request.getParameter("phgp_regt_tgt2")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt3")) || null == request.getParameter("phgp_regt_tgt3")){
			mbtt02001vo.setPhgpRegtTgt3(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt3(StringUtil.nvl(request.getParameter("phgp_regt_tgt3")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt4")) || null == request.getParameter("phgp_regt_tgt4")){
			mbtt02001vo.setPhgpRegtTgt4(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt4(StringUtil.nvl(request.getParameter("phgp_regt_tgt4")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt5")) || null == request.getParameter("phgp_regt_tgt5")){
			mbtt02001vo.setPhgpRegtTgt5(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt5(StringUtil.nvl(request.getParameter("phgp_regt_tgt5")));
		}
		
		//MMTI0213 insert
		int insertRow = 0;
		
		logger.info("#### ml4_1 MBTT02001 before ####");
		insertRow = mileageTobeService.insertJungsanTest(mbtt02001vo);
		logger.info("####  ml4_1 MBTT02001 after ####");
		
		if(insertRow < 1){
			logger.info("#### 사서함번호: " + StringUtil.nvl(mbtt02001vo.getPboxNo()) + "####");
			logger.info("#### insert 결과: Fail ####");
		}else{
			logger.info("#### insert 결과: Success ####");
		}
		
		return "/counter/carrider/tobe/ml4_1";
	}
	
	@RequestMapping(value="/ml4_2")
	public String ml4_2(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
	
		HttpSession session = request.getSession();
		
		logger.debug("####### ml4_2 값 확인 #######");
		logger.debug("p: " + (String)session.getAttribute("p"));
		logger.debug("plno: " + (String)session.getAttribute("plno"));
		logger.debug("exp_exca_plan_no: " + (String)session.getAttribute("exp_exca_plan_no"));
		//logger.debug("cnv_trv_dstc: " + (String)session.getAttribute("cnv_trv_dstc"));
		logger.debug("pdc_sr_dvn: " + (String)session.getAttribute("pdc_sr_dvn"));
		//logger.debug("appSeq: " + (String)session.getAttribute("appSeq"));
		logger.debug("exp_exca_plan_rsl_cd: " + (String)session.getAttribute("exp_exca_plan_rsl_cd"));
		logger.debug("adc_rtrn_dvn: " + (String)session.getAttribute("adc_rtrn_dvn"));
		logger.debug("adc_rtrn_prm: " + (String)session.getAttribute("adc_rtrn_prm"));
		
		MMTI0213VO jmvo = new MMTI0213VO();
		String p = (String) session.getAttribute("p");
		jmvo.setSms_ts_bvan(aes256Decrypt(p));
		jmvo = mileageTobeService.getMMTI0213VO(jmvo);
		
		MMTI0291VO jmvo1 = new MMTI0291VO();
		jmvo1.setTrv_dstc_exca_mtt__exca_bz_proc_dvn("2");												// 정산업무처리구분 2:확정
		jmvo1.setTrv_dstc_exca_mtt__plno((String)session.getAttribute("plno"));							// 증권번호
		jmvo1.setTrv_dstc_exca_mtt__plan_no((String)session.getAttribute("exp_exca_plan_no"));			// 설계번호
		jmvo1.setTrv_dstc_exca_mtt__exca_rtrn_dvn("2");													// 갱신환급구분 2:갱신계약활용
		jmvo1.setTrv_dstc_exca_mtt__pdc_sr_dvn((String)session.getAttribute("pdc_sr_dvn"));				// 상품출처구분
		jmvo1.setTrv_dstc_exca_mtt__scrn_proc_cd((String)session.getAttribute("exp_exca_plan_rsl_cd"));	// 화면처리코드
		jmvo1.setTrv_dstc_exca_mtt__adc_rtrn_dvn((String)session.getAttribute("adc_rtrn_dvn"));			// 추징환급구분
		jmvo1.setTrv_dstc_exca_mtt__adc_rtrn_prm((String)session.getAttribute("adc_rtrn_prm"));			// 추징환급보험료
		jmvo1.setTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn(jmvo.getTrv_dstc_splc_exca_yn());				// 주행거리간편정산여부
		jmvo1.setTrv_dstc_exca_mtt__pbox_no(jmvo.getSms_ts_bvan());										// 사서함번호
		jmvo1 = mileageTobeService.getMMTI0291VO(jmvo1);
		
		// 미환급대체 완료화면 CM상품 분기용
		session.setAttribute("sr_dvn", jmvo1.getTrv_dstc_exca_mtt__pdc_sr_dvn());
		
		// 부적정/중복 이미지인 경우 화면처리코드 02 
		if("1".equals(jmvo1.getTrv_dstc_exca_mtt__imag_dup_yn())){
			jmvo1.setTrv_dstc_exca_mtt__scrn_proc_cd("02");
		}
		request.setAttribute("jmvo1", jmvo1);
		
		// CM 상품이고, 화면처리코드 IN(02, 14) or 이미지 중복
		
		if("CM".equals(jmvo1.getTrv_dstc_exca_mtt__pdc_sr_dvn()) && 
				("02".equals(jmvo1.getTrv_dstc_exca_mtt__scrn_proc_cd())
				|| "14".equals(jmvo1.getTrv_dstc_exca_mtt__scrn_proc_cd()))){
			
			MMTI0015VO mmti0015vo = new MMTI0015VO();
			mmti0015vo.setFunt_key("00");
			mmti0015vo.setPlan_no(jmvo1.getTrv_dstc_exca_mtt__plan_no());
			mmti0015vo = mileageTobeService.getMMTI0015VO(mmti0015vo);
			
			logger.debug("##### MMTI0015 시작 ##########################");
			logger.debug("##### 고객식별번호: " + mmti0015vo.getPlhd__cust_dcmt_no() + " ##########################");
			logger.debug("##### 고객번호: " + mmti0015vo.getPlhd__cust_no() + " ##########################");
			logger.debug("##### 고객명: " + mmti0015vo.getPlhd__cust_nm() + " ##########################");
			logger.debug("##### 이메일: " + mmti0015vo.getPlhd__eml() + " ##########################");
			logger.debug("##### 지역번호: " + mmti0015vo.getPlhd_cntp_if__tlp_arno() + " ##########################");
			logger.debug("##### 국번호: " + mmti0015vo.getPlhd_cntp_if__tlp_ofno() + " ##########################");
			logger.debug("##### 개별번호: " + mmti0015vo.getPlhd_cntp_if__tlp_idvno() + " ##########################");
			
			XTEM0021VO xtem0021vo = new XTEM0021VO();
			xtem0021vo.setCnsl_rpt_no("");						// 상담접수번호				
			xtem0021vo.setCm_bz_dvcd("05");
			xtem0021vo.setCnsl_typ_dvcd("07");
			xtem0021vo.setCm_plan_no(jmvo1.getTrv_dstc_exca_mtt__plan_no());
			xtem0021vo.setCnsl_rpy_dvcd("1");
			xtem0021vo.setCnsl_rpt_dttm(getDayTime());			// 현재년월일시분초 14자리
			xtem0021vo.setCust_nm(mmti0015vo.getPlhd__cust_nm());
			xtem0021vo.setCust_no(mmti0015vo.getPlhd__cust_no());
			
			String cust_dcmt_no = SeedUtil.decrypt(mmti0015vo.getPlhd__cust_dcmt_no());
			
			if("1".equals(cust_dcmt_no.substring(6, 7)) || "2".equals(cust_dcmt_no.substring(6, 7))
				|| "5".equals(cust_dcmt_no.substring(6, 7)) || "6".equals(cust_dcmt_no.substring(6, 7))){
				xtem0021vo.setBrth("19" + cust_dcmt_no.substring(0, 6));
			} else{
				xtem0021vo.setBrth("20" + cust_dcmt_no.substring(0, 6));
			}
			xtem0021vo.setSx_cd(cust_dcmt_no.substring(6, 7));
			xtem0021vo.setEml_adr(mmti0015vo.getPlhd__eml());
			xtem0021vo.setClp_tlcno(mmti0015vo.getPlhd_cntp_if__tlp_arno());
			xtem0021vo.setClp_ofno(mmti0015vo.getPlhd_cntp_if__tlp_ofno());
			xtem0021vo.setClp_idvno(mmti0015vo.getPlhd_cntp_if__tlp_idvno());
			xtem0021vo.setCnsl_rsvt_dt("99990101");
			xtem0021vo.setCnsl_rsvt_time_cd("1");
			xtem0021vo.setCnsl_cn("최종주행거리사진등록/만기정산");
			xtem0021vo.setCnsl_aply_csn_yn("1");
			xtem0021vo.setUrl_adr("");
			xtem0021vo.setCm_ctrmf_tpcd("32");
			xtem0021vo.setFrst_ipmn_empno("80000028");
			xtem0021vo.setFrst_ipnpt_dttm(getDayTime());		// 현재년월일시분초 14자리	
			
			xtem0021vo = mileageTobeService.getXTEM0021VO(xtem0021vo);
			logger.debug("##### XTEM0021 시작 ##########################");
			logger.debug("##### 처리결과: [ " + xtem0021vo.getProc_rtn() + " ] ##########################");
		}
		// model.addAttribute("trv_dstc1", request.getParameter("mileage1"));
		
		MBTT02001VO mbtt02001vo = new MBTT02001VO();
		String scrnNm = "ml4_2";
		
		//MMTI0213전문 정산이력테이블(MBTT02001) 적재
		mbtt02001vo.setPboxNo(StringUtil.nvl(jmvo.getSms_ts_bvan()));
		mbtt02001vo.setTlgIdVal("MMTI0213");
		mbtt02001vo.setEsbTrscId(StringUtil.nvl(jmvo.getZ_trsc_id()));
		if("".equals(jmvo.getPlno()) || null == jmvo.getPlno()){
			mbtt02001vo.setPlno(" ");
		} else {
			mbtt02001vo.setPlno(StringUtil.nvl(jmvo.getPlno()));
		}
		if("".equals(jmvo.getPlan_no()) || null == jmvo.getPlan_no()){
			mbtt02001vo.setPlanNo(" ");
		} else {
			mbtt02001vo.setPlanNo(StringUtil.nvl(jmvo.getPlan_no()));
		}
		if("".equals(jmvo.getRnw_plno()) || null == jmvo.getRnw_plno()){
			mbtt02001vo.setRnwPlno(" ");
		} else {
			mbtt02001vo.setRnwPlno(StringUtil.nvl(jmvo.getRnw_plno()));
		}
		mbtt02001vo.setTlgProcRslCdVal(StringUtil.nvl(jmvo.getZ_tlg_sp_cd()));
		mbtt02001vo.setTlgErrCdVal(StringUtil.nvl(jmvo.getZ_trns_org_dvcd())+StringUtil.nvl(jmvo.getZ_trns_org_cd()));
		if("".equals(request.getParameter("hdlrEmpno")) || null == request.getParameter("hdlrEmpno")){
			mbtt02001vo.setHdlrEmpno(" ");
		} else {
			mbtt02001vo.setHdlrEmpno(StringUtil.nvl(request.getParameter("hdlrEmpno")));
		}
		if("".equals(jmvo.getPbox_no_dvcd()) || null == jmvo.getPbox_no_dvcd()){
			mbtt02001vo.setPboxNoDvcd(" ");
		} else {
			mbtt02001vo.setPboxNoDvcd(StringUtil.nvl(jmvo.getPbox_no_dvcd()));
		}
		if("".equals(jmvo.getProc_dvn()) || null == jmvo.getProc_dvn()){
			mbtt02001vo.setProcDvn(" ");
		} else {
			mbtt02001vo.setProcDvn(StringUtil.nvl(jmvo.getProc_dvn()));
		}
		if("".equals(jmvo.getTrv_dstc_exp_exca_dvcd()) || null == jmvo.getTrv_dstc_exp_exca_dvcd()){
			mbtt02001vo.setTrvDstcExpExcaDvcd(" ");
		} else {
			mbtt02001vo.setTrvDstcExpExcaDvcd(StringUtil.nvl(jmvo.getTrv_dstc_exp_exca_dvcd()));
		}
		if("".equals(jmvo.getTrv_dstc_chng_aply_dvn()) || null == jmvo.getTrv_dstc_chng_aply_dvn()){
			mbtt02001vo.setTrvDstcChngAplyDvn(" ");
		} else {
			mbtt02001vo.setTrvDstcChngAplyDvn(StringUtil.nvl(jmvo.getTrv_dstc_chng_aply_dvn()));
		}
		if("".equals(jmvo.getHdlr_fire_yn()) || null == jmvo.getHdlr_fire_yn()){
			mbtt02001vo.setHdlrFireYn(" ");
		} else {
			mbtt02001vo.setHdlrFireYn(StringUtil.nvl(jmvo.getHdlr_fire_yn()));
		}
		if("".equals(jmvo.getMtcc_yn()) || null == jmvo.getMtcc_yn()){
			mbtt02001vo.setMtccYn(" ");
		} else {
			mbtt02001vo.setMtccYn(StringUtil.nvl(jmvo.getMtcc_yn()));
		}
		if("".equals(request.getParameter("aut_cgnt_trv_dstc")) || null == request.getParameter("aut_cgnt_trv_dstc")){
			mbtt02001vo.setAutCgntTrvDstc(0);
		} else {
			mbtt02001vo.setAutCgntTrvDstc(Double.parseDouble(request.getParameter("aut_cgnt_trv_dstc")));
		}
		if("".equals(request.getParameter("autCgntTrvDstcRslCd")) || null == request.getParameter("autCgntTrvDstcRslCd")){
			mbtt02001vo.setAutCgntTrvDstcRslCd(" ");
		} else {
			mbtt02001vo.setAutCgntTrvDstcRslCd(StringUtil.nvl(request.getParameter("autCgntTrvDstcRslCd")));
		}
		if("".equals(request.getParameter("inptTrvDstc")) || null == request.getParameter("inptTrvDstc")){
			mbtt02001vo.setInptTrvDstc(0);
		} else {
			mbtt02001vo.setInptTrvDstc(Double.parseDouble(request.getParameter("inptTrvDstc")));
		}
		if("".equals(request.getParameter("cnv_trv_dstc")) || null == request.getParameter("cnv_trv_dstc")){
			mbtt02001vo.setCnvTrvDstc(0);
		} else {
			mbtt02001vo.setCnvTrvDstc(Double.parseDouble(request.getParameter("cnv_trv_dstc")));
		}
		if("".equals(request.getParameter("exp_exca_plan_rsl_cd")) || null == request.getParameter("exp_exca_plan_rsl_cd")){
			mbtt02001vo.setExpExcaPlanRslCd(" ");
		} else {
			mbtt02001vo.setExpExcaPlanRslCd(StringUtil.nvl(request.getParameter("exp_exca_plan_rsl_cd")));
		}
		if("".equals(request.getParameter("excaBzProcDvn")) || null == request.getParameter("excaBzProcDvn")){
			mbtt02001vo.setExcaBzProcDvn(" ");
		} else {
			mbtt02001vo.setExcaBzProcDvn(StringUtil.nvl(request.getParameter("excaBzProcDvn")));
		}
		if("".equals(request.getParameter("excaRtrnDvn")) || null == request.getParameter("excaRtrnDvn")){
			mbtt02001vo.setExcaRtrnDvn(" ");
		} else {
			mbtt02001vo.setExcaRtrnDvn(StringUtil.nvl(request.getParameter("excaRtrnPrm")));
		}
		if("".equals(request.getParameter("pdc_sr_dvn")) || null == request.getParameter("pdc_sr_dvn")){
			mbtt02001vo.setPdcSrDvn(" ");
		} else {
			mbtt02001vo.setPdcSrDvn(StringUtil.nvl(request.getParameter("pdc_sr_dvn")));
		}
		if("".equals(request.getParameter("adc_rtrn_prm")) || null == request.getParameter("adc_rtrn_prm")){
			mbtt02001vo.setAdcRtrnPrm(0);
		} else {
			mbtt02001vo.setAdcRtrnPrm(Double.parseDouble(request.getParameter("adc_rtrn_prm")));
		}
		if("".equals(request.getParameter("trvDstcSplcExcaYn")) || null == request.getParameter("trvDstcSplcExcaYn")){
			mbtt02001vo.setTrvDstcSplcExcaYn(" ");
		} else {
			mbtt02001vo.setTrvDstcSplcExcaYn(StringUtil.nvl(request.getParameter("trvDstcSplcExcaYn")));
		}
		if("".equals(request.getParameter("imagDupYn")) || null == request.getParameter("imagDupYn")){
			mbtt02001vo.setImagDupYn(" ");
		} else {
			mbtt02001vo.setImagDupYn(StringUtil.nvl(request.getParameter("imagDupYn")));
		}
		if("".equals(request.getParameter("nrmProcYn")) || null == request.getParameter("nrmProcYn")){
			mbtt02001vo.setNrmProcYn(" ");
		} else {
			mbtt02001vo.setNrmProcYn(StringUtil.nvl(request.getParameter("nrmProcYn")));
		}
		if("".equals(request.getParameter("crdScnCnclPssYn")) || null == request.getParameter("crdScnCnclPssYn")){
			mbtt02001vo.setCrdScnCnclPssYn(" ");
		} else {
			mbtt02001vo.setCrdScnCnclPssYn(StringUtil.nvl(request.getParameter("crdScnCnclPssYn")));
		}
		mbtt02001vo.setRespCn(StringUtil.nvl(jmvo.getZ_resp_cd()));
		mbtt02001vo.setRslCn(scrnNm + "_" + StringUtil.nvl(jmvo.getZ_resp_msg()));
		mbtt02001vo.setFrstIpmnEmpno("82101685");
		mbtt02001vo.setFnalAmdrEmpno("82101685");
		if("".equals(request.getParameter("adc_rtrn_dvn")) || null == request.getParameter("adc_rtrn_dvn")){
			mbtt02001vo.setAdcRtrnDvn(" ");
		} else {
			mbtt02001vo.setAdcRtrnDvn(StringUtil.nvl(request.getParameter("adc_rtrn_dvn")));
		}
		if("".equals(request.getParameter("scrn_proc_cd")) || null == request.getParameter("scrn_proc_cd")){
			mbtt02001vo.setScrnProcCd(" ");
		} else {
			mbtt02001vo.setScrnProcCd(StringUtil.nvl(request.getParameter("scrn_proc_cd")));
		}
		if("".equals(jmvo.getCtc_plno()) || null == jmvo.getCtc_plno()){
			mbtt02001vo.setCtcPlno(" ");
		} else {
			mbtt02001vo.setCtcPlno(StringUtil.nvl(jmvo.getCtc_plno()));
		}
		if("".equals(request.getParameter("trv_dstc_proc_dvcd")) || null == request.getParameter("trv_dstc_proc_dvcd")){
			mbtt02001vo.setTrvDstcProcDvcd(" ");
		} else {
			mbtt02001vo.setTrvDstcProcDvcd(StringUtil.nvl(request.getParameter("trv_dstc_proc_dvcd")));
		}
		if("".equals(request.getParameter("mbl_snd_no")) || null == request.getParameter("mbl_snd_no")){
			mbtt02001vo.setMblSndNo(" ");
		} else {
			mbtt02001vo.setMblSndNo(StringUtil.nvl(request.getParameter("mbl_snd_no")));
		}
		if("".equals(request.getParameter("plan_plno_dvcd")) || null == request.getParameter("plan_plno_dvcd")){
			mbtt02001vo.setPlanPlnoDvcd(" ");
		} else {
			mbtt02001vo.setPlanPlnoDvcd(StringUtil.nvl(request.getParameter("plan_plno_dvcd")));
		}
		if("".equals(request.getParameter("plan_plno")) || null == request.getParameter("plan_plno")){
			mbtt02001vo.setPlanPlno(" ");
		} else {
			mbtt02001vo.setPlanPlno(StringUtil.nvl(request.getParameter("plan_plno")));
		}
		if("".equals(jmvo.getChng_plan_no()) || null == jmvo.getChng_plan_no()){
			mbtt02001vo.setChngPlanNo(" ");
		} else {
			mbtt02001vo.setChngPlanNo(StringUtil.nvl(jmvo.getChng_plan_no()));
		}
		if("".equals(request.getParameter("dst_tty_dvn1")) || null == request.getParameter("dst_tty_dvn1")){
			mbtt02001vo.setDstTtyDvn1(" ");
		} else {
			mbtt02001vo.setDstTtyDvn1(StringUtil.nvl(request.getParameter("dst_tty_dvn1")));
		}
		if("".equals(request.getParameter("dst_tty_dvn2")) || null == request.getParameter("dst_tty_dvn2")){
			mbtt02001vo.setDstTtyDvn2(" ");
		} else {
			mbtt02001vo.setDstTtyDvn2(StringUtil.nvl(request.getParameter("dst_tty_dvn2")));
		}
		if("".equals(request.getParameter("dst_tty_dvn3")) || null == request.getParameter("dst_tty_dvn3")){
			mbtt02001vo.setDstTtyDvn3(" ");
		} else {
			mbtt02001vo.setDstTtyDvn3(StringUtil.nvl(request.getParameter("dst_tty_dvn3")));
		}
		if("".equals(request.getParameter("dst_tty_dvn4")) || null == request.getParameter("dst_tty_dvn4")){
			mbtt02001vo.setDstTtyDvn4(" ");
		} else {
			mbtt02001vo.setDstTtyDvn4(StringUtil.nvl(request.getParameter("dst_tty_dvn4")));
		}
		if("".equals(request.getParameter("dst_tty_dvn5")) || null == request.getParameter("dst_tty_dvn5")){
			mbtt02001vo.setDstTtyDvn5(" ");
		} else {
			mbtt02001vo.setDstTtyDvn5(StringUtil.nvl(request.getParameter("dst_tty_dvn5")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt1")) || null == request.getParameter("phgp_regt_tgt1")){
			mbtt02001vo.setPhgpRegtTgt1(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt1(StringUtil.nvl(request.getParameter("phgp_regt_tgt1")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt2")) || null == request.getParameter("phgp_regt_tgt2")){
			mbtt02001vo.setPhgpRegtTgt2(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt2(StringUtil.nvl(request.getParameter("phgp_regt_tgt2")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt3")) || null == request.getParameter("phgp_regt_tgt3")){
			mbtt02001vo.setPhgpRegtTgt3(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt3(StringUtil.nvl(request.getParameter("phgp_regt_tgt3")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt4")) || null == request.getParameter("phgp_regt_tgt4")){
			mbtt02001vo.setPhgpRegtTgt4(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt4(StringUtil.nvl(request.getParameter("phgp_regt_tgt4")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt5")) || null == request.getParameter("phgp_regt_tgt5")){
			mbtt02001vo.setPhgpRegtTgt5(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt5(StringUtil.nvl(request.getParameter("phgp_regt_tgt5")));
		}
		
		//MMTI0213 insert
		int insertRow = 0;
		
		logger.info("#### ml4_2 MMTI0213 MBTT02001 before ####");
		insertRow = mileageTobeService.insertJungsanTest(mbtt02001vo);
		logger.info("#### ml4_2 MMTI0213 MBTT02001 after ####");
		
		if(insertRow < 1){
			logger.info("#### 사서함번호: " + StringUtil.nvl(mbtt02001vo.getPboxNo()) + "####");
			logger.info("#### insert 결과: Fail ####");
		}else{
			logger.info("#### insert 결과: Success ####");
		}
		
		//MMTI0291전문 정산이력테이블(MBTT02001) 적재
		mbtt02001vo.setPboxNo(StringUtil.nvl(jmvo.getSms_ts_bvan()));
		mbtt02001vo.setTlgIdVal("MMTI0291");
		mbtt02001vo.setEsbTrscId(StringUtil.nvl(jmvo1.getZ_trsc_id()));
		if("".equals(jmvo1.getTrv_dstc_exca_mtt__plno()) || null == jmvo1.getTrv_dstc_exca_mtt__plno()){
			mbtt02001vo.setPlno(" ");
		} else {
			mbtt02001vo.setPlno(StringUtil.nvl(jmvo1.getTrv_dstc_exca_mtt__plno()));
		}
		if("".equals(jmvo1.getTrv_dstc_exca_mtt__plan_no()) || null == jmvo1.getTrv_dstc_exca_mtt__plan_no()){
			mbtt02001vo.setPlanNo(" ");
		} else {
			mbtt02001vo.setPlanNo(StringUtil.nvl(jmvo1.getTrv_dstc_exca_mtt__plan_no()));
		}
		if("".equals(jmvo1.getTrv_dstc_exca_mtt__rnw_plno()) || null == jmvo1.getTrv_dstc_exca_mtt__rnw_plno()){
			mbtt02001vo.setRnwPlno(" ");
		} else {
			mbtt02001vo.setRnwPlno(StringUtil.nvl(jmvo1.getTrv_dstc_exca_mtt__rnw_plno()));
		}
		mbtt02001vo.setTlgProcRslCdVal(StringUtil.nvl(jmvo1.getZ_tlg_sp_cd()));
		mbtt02001vo.setTlgErrCdVal(StringUtil.nvl(jmvo1.getZ_trns_org_dvcd())+StringUtil.nvl(jmvo1.getZ_trns_org_cd()));
		if("".equals(jmvo1.getTrv_dstc_exca_mtt__hdlr_empno()) || null == jmvo1.getTrv_dstc_exca_mtt__hdlr_empno()){
			mbtt02001vo.setHdlrEmpno(" ");
		} else {
			mbtt02001vo.setHdlrEmpno(StringUtil.nvl(jmvo1.getTrv_dstc_exca_mtt__hdlr_empno()));
		}
		if("".equals(jmvo.getPbox_no_dvcd()) || null == jmvo.getPbox_no_dvcd()){
			mbtt02001vo.setPboxNoDvcd(" ");
		} else {
			mbtt02001vo.setPboxNoDvcd(StringUtil.nvl(jmvo.getPbox_no_dvcd()));
		}
		if("".equals(jmvo.getProc_dvn()) || null == jmvo.getProc_dvn()){
			mbtt02001vo.setProcDvn(" ");
		} else {
			mbtt02001vo.setProcDvn(StringUtil.nvl(jmvo.getProc_dvn()));
		}
		if("".equals(jmvo.getTrv_dstc_exp_exca_dvcd()) || null == jmvo.getTrv_dstc_exp_exca_dvcd()){
			mbtt02001vo.setTrvDstcExpExcaDvcd(" ");
		} else {
			mbtt02001vo.setTrvDstcExpExcaDvcd(StringUtil.nvl(jmvo.getTrv_dstc_exp_exca_dvcd()));
		}
		if("".equals(jmvo.getTrv_dstc_chng_aply_dvn()) || null == jmvo.getTrv_dstc_chng_aply_dvn()){
			mbtt02001vo.setTrvDstcChngAplyDvn(" ");
		} else {
			mbtt02001vo.setTrvDstcChngAplyDvn(StringUtil.nvl(jmvo.getTrv_dstc_chng_aply_dvn()));
		}
		if("".equals(jmvo.getHdlr_fire_yn()) || null == jmvo.getHdlr_fire_yn()){
			mbtt02001vo.setHdlrFireYn(" ");
		} else {
			mbtt02001vo.setHdlrFireYn(StringUtil.nvl(jmvo.getHdlr_fire_yn()));
		}
		if("".equals(jmvo.getMtcc_yn()) || null == jmvo.getMtcc_yn()){
			mbtt02001vo.setMtccYn(" ");
		} else {
			mbtt02001vo.setMtccYn(StringUtil.nvl(jmvo.getMtcc_yn()));
		}
		if("".equals(request.getParameter("aut_cgnt_trv_dstc")) || null == request.getParameter("aut_cgnt_trv_dstc")){
			mbtt02001vo.setAutCgntTrvDstc(0);
		} else {
			mbtt02001vo.setAutCgntTrvDstc(Double.parseDouble(request.getParameter("aut_cgnt_trv_dstc")));
		}
		if("".equals(jmvo1.getTrv_dstc_exca_mtt__aut_cgnt_trv_dstc_rsl_cd()) || null == jmvo1.getTrv_dstc_exca_mtt__aut_cgnt_trv_dstc_rsl_cd()){
			mbtt02001vo.setAutCgntTrvDstcRslCd(" ");
		} else {
			mbtt02001vo.setAutCgntTrvDstcRslCd(StringUtil.nvl(jmvo1.getTrv_dstc_exca_mtt__aut_cgnt_trv_dstc_rsl_cd()));
		}
		if("".equals(request.getParameter("inptTrvDstc")) || null == request.getParameter("inptTrvDstc")){
			mbtt02001vo.setInptTrvDstc(0);
		} else {
			mbtt02001vo.setInptTrvDstc(Double.parseDouble(request.getParameter("inptTrvDstc")));
		}
		if("".equals(jmvo1.getTrv_dstc_exca_mtt__cnv_trv_dstc()) || null == jmvo1.getTrv_dstc_exca_mtt__cnv_trv_dstc()){
			mbtt02001vo.setCnvTrvDstc(0);
		} else {
			mbtt02001vo.setCnvTrvDstc(Double.parseDouble(jmvo1.getTrv_dstc_exca_mtt__cnv_trv_dstc()));
		}
		if("".equals(request.getParameter("exp_exca_plan_rsl_cd")) || null == request.getParameter("exp_exca_plan_rsl_cd")){
			mbtt02001vo.setExpExcaPlanRslCd(" ");
		} else {
			mbtt02001vo.setExpExcaPlanRslCd(StringUtil.nvl(request.getParameter("exp_exca_plan_rsl_cd")));
		}
		if("".equals(jmvo1.getTrv_dstc_exca_mtt__exca_bz_proc_dvn()) || null == jmvo1.getTrv_dstc_exca_mtt__exca_bz_proc_dvn()){
			mbtt02001vo.setExcaBzProcDvn(" ");
		} else {
			mbtt02001vo.setExcaBzProcDvn(StringUtil.nvl(jmvo1.getTrv_dstc_exca_mtt__exca_bz_proc_dvn()));
		}
		if("".equals(jmvo1.getTrv_dstc_exca_mtt__exca_rtrn_dvn()) || null == jmvo1.getTrv_dstc_exca_mtt__exca_rtrn_dvn()){
			mbtt02001vo.setExcaRtrnDvn(" ");
		} else {
			mbtt02001vo.setExcaRtrnDvn(StringUtil.nvl(jmvo1.getTrv_dstc_exca_mtt__exca_rtrn_dvn()));
		}
		if("".equals(jmvo1.getTrv_dstc_exca_mtt__pdc_sr_dvn()) || null == jmvo1.getTrv_dstc_exca_mtt__pdc_sr_dvn()){
			mbtt02001vo.setPdcSrDvn(" ");
		} else {
			mbtt02001vo.setPdcSrDvn(StringUtil.nvl(jmvo1.getTrv_dstc_exca_mtt__pdc_sr_dvn()));
		}
		if("".equals(jmvo1.getTrv_dstc_exca_mtt__adc_rtrn_prm()) || null == jmvo1.getTrv_dstc_exca_mtt__adc_rtrn_prm()){
			mbtt02001vo.setAdcRtrnPrm(0);
		} else {
			mbtt02001vo.setAdcRtrnPrm(Double.parseDouble(jmvo1.getTrv_dstc_exca_mtt__adc_rtrn_prm()));
		}
		if("".equals(jmvo1.getTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn()) || null == jmvo1.getTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn()){
			mbtt02001vo.setTrvDstcSplcExcaYn(" ");
		} else {
			mbtt02001vo.setTrvDstcSplcExcaYn(StringUtil.nvl(jmvo1.getTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn()));
		}
		if("".equals(jmvo1.getTrv_dstc_exca_mtt__imag_dup_yn()) || null == jmvo1.getTrv_dstc_exca_mtt__imag_dup_yn()){
			mbtt02001vo.setImagDupYn(" ");
		} else {
			mbtt02001vo.setImagDupYn(StringUtil.nvl(jmvo1.getTrv_dstc_exca_mtt__imag_dup_yn()));
		}
		if("".equals(jmvo1.getTrv_dstc_exca_mtt__nrm_proc_yn()) || null == jmvo1.getTrv_dstc_exca_mtt__nrm_proc_yn()){
			mbtt02001vo.setNrmProcYn(" ");
		} else {
			mbtt02001vo.setNrmProcYn(StringUtil.nvl(jmvo1.getTrv_dstc_exca_mtt__nrm_proc_yn()));
		}
		if("".equals(request.getParameter("crdScnCnclPssYn")) || null == request.getParameter("crdScnCnclPssYn")){
			mbtt02001vo.setCrdScnCnclPssYn(" ");
		} else {
			mbtt02001vo.setCrdScnCnclPssYn(StringUtil.nvl(request.getParameter("crdScnCnclPssYn")));
		}
		mbtt02001vo.setRespCn(StringUtil.nvl(jmvo1.getZ_resp_cd()));
		mbtt02001vo.setRslCn(scrnNm + "_" + StringUtil.nvl(jmvo1.getZ_resp_msg()));
		mbtt02001vo.setFrstIpmnEmpno("82101685");
		mbtt02001vo.setFnalAmdrEmpno("82101685");
		if("".equals(jmvo1.getTrv_dstc_exca_mtt__adc_rtrn_dvn()) || null == jmvo1.getTrv_dstc_exca_mtt__adc_rtrn_dvn()){
			mbtt02001vo.setAdcRtrnDvn(" ");
		} else {
			mbtt02001vo.setAdcRtrnDvn(StringUtil.nvl(jmvo1.getTrv_dstc_exca_mtt__adc_rtrn_dvn()));
		}
		if("".equals(jmvo1.getTrv_dstc_exca_mtt__scrn_proc_cd()) || null == jmvo1.getTrv_dstc_exca_mtt__scrn_proc_cd()){
			mbtt02001vo.setScrnProcCd(" ");
		} else {
			mbtt02001vo.setScrnProcCd(StringUtil.nvl(jmvo1.getTrv_dstc_exca_mtt__scrn_proc_cd()));
		}
		if("".equals(request.getParameter("ctc_plno")) || null == request.getParameter("ctc_plno")){
			mbtt02001vo.setCtcPlno(" ");
		} else {
			mbtt02001vo.setCtcPlno(StringUtil.nvl(request.getParameter("ctc_plno")));
		}
		if("".equals(request.getParameter("trv_dstc_proc_dvcd")) || null == request.getParameter("trv_dstc_proc_dvcd")){
			mbtt02001vo.setTrvDstcProcDvcd(" ");
		} else {
			mbtt02001vo.setTrvDstcProcDvcd(StringUtil.nvl(request.getParameter("trv_dstc_proc_dvcd")));
		}
		if("".equals(request.getParameter("mbl_snd_no")) || null == request.getParameter("mbl_snd_no")){
			mbtt02001vo.setMblSndNo(" ");
		} else {
			mbtt02001vo.setMblSndNo(StringUtil.nvl(request.getParameter("mbl_snd_no")));
		}
		if("".equals(request.getParameter("plan_plno_dvcd")) || null == request.getParameter("plan_plno_dvcd")){
			mbtt02001vo.setPlanPlnoDvcd(" ");
		} else {
			mbtt02001vo.setPlanPlnoDvcd(StringUtil.nvl(request.getParameter("plan_plno_dvcd")));
		}
		if("".equals(request.getParameter("plan_plno")) || null == request.getParameter("plan_plno")){
			mbtt02001vo.setPlanPlno(" ");
		} else {
			mbtt02001vo.setPlanPlno(StringUtil.nvl(request.getParameter("plan_plno")));
		}
		if("".equals(jmvo.getChng_plan_no()) || null == jmvo.getChng_plan_no()){
			mbtt02001vo.setChngPlanNo(" ");
		} else {
			mbtt02001vo.setChngPlanNo(StringUtil.nvl(jmvo.getChng_plan_no()));
		}
		if("".equals(request.getParameter("dst_tty_dvn1")) || null == request.getParameter("dst_tty_dvn1")){
			mbtt02001vo.setDstTtyDvn1(" ");
		} else {
			mbtt02001vo.setDstTtyDvn1(StringUtil.nvl(request.getParameter("dst_tty_dvn1")));
		}
		if("".equals(request.getParameter("dst_tty_dvn2")) || null == request.getParameter("dst_tty_dvn2")){
			mbtt02001vo.setDstTtyDvn2(" ");
		} else {
			mbtt02001vo.setDstTtyDvn2(StringUtil.nvl(request.getParameter("dst_tty_dvn2")));
		}
		if("".equals(request.getParameter("dst_tty_dvn3")) || null == request.getParameter("dst_tty_dvn3")){
			mbtt02001vo.setDstTtyDvn3(" ");
		} else {
			mbtt02001vo.setDstTtyDvn3(StringUtil.nvl(request.getParameter("dst_tty_dvn3")));
		}
		if("".equals(request.getParameter("dst_tty_dvn4")) || null == request.getParameter("dst_tty_dvn4")){
			mbtt02001vo.setDstTtyDvn4(" ");
		} else {
			mbtt02001vo.setDstTtyDvn4(StringUtil.nvl(request.getParameter("dst_tty_dvn4")));
		}
		if("".equals(request.getParameter("dst_tty_dvn5")) || null == request.getParameter("dst_tty_dvn5")){
			mbtt02001vo.setDstTtyDvn5(" ");
		} else {
			mbtt02001vo.setDstTtyDvn5(StringUtil.nvl(request.getParameter("dst_tty_dvn5")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt1")) || null == request.getParameter("phgp_regt_tgt1")){
			mbtt02001vo.setPhgpRegtTgt1(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt1(StringUtil.nvl(request.getParameter("phgp_regt_tgt1")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt2")) || null == request.getParameter("phgp_regt_tgt2")){
			mbtt02001vo.setPhgpRegtTgt2(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt2(StringUtil.nvl(request.getParameter("phgp_regt_tgt2")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt3")) || null == request.getParameter("phgp_regt_tgt3")){
			mbtt02001vo.setPhgpRegtTgt3(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt3(StringUtil.nvl(request.getParameter("phgp_regt_tgt3")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt4")) || null == request.getParameter("phgp_regt_tgt4")){
			mbtt02001vo.setPhgpRegtTgt4(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt4(StringUtil.nvl(request.getParameter("phgp_regt_tgt4")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt5")) || null == request.getParameter("phgp_regt_tgt5")){
			mbtt02001vo.setPhgpRegtTgt5(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt5(StringUtil.nvl(request.getParameter("phgp_regt_tgt5")));
		}
		
		//MMTI0291 insert
		insertRow = 0;
		
		logger.info("#### ml4_2 MMTI0291 MBTT02001 before ####");
		insertRow = mileageTobeService.insertJungsanTest(mbtt02001vo);
		logger.info("#### ml4_2 MMTI0291 MBTT02001 after ####");
		
		if(insertRow < 1){
			logger.info("#### 사서함번호: " + StringUtil.nvl(mbtt02001vo.getPboxNo()) + "####");
			logger.info("#### insert 결과: Fail ####");
		}else{
			logger.info("#### insert 결과: Success ####");
		}
	
		session.setAttribute("renewal", "02");
		return "/counter/carrider/tobe/ml4_1";
	}
	
	
	
	@RequestMapping(value="/ml5")
	public String ml5(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		HttpSession session = request.getSession();
		MMTI0294VO jmvo = new MMTI0294VO();
		
		String isCrd = StringUtil.nvl(request.getParameter("isCrd"));
		String empno = "";
		
		
		logger.info("######################### ml5 test ");
		logger.info("isCrd: " + isCrd);
		
		if("Y".equals(isCrd)){
			// 카드취소에서 넘어온 추가가입: session
			logger.info("취급자사번: " + StringUtil.nvl((String)session.getAttribute("trv_dstc_exca_mtt__hdlr_empno")));
			logger.info("증번: " + StringUtil.nvl((String)session.getAttribute("trv_dstc_exca_mtt__plno")));
			logger.info("설번: " + StringUtil.nvl((String)session.getAttribute("trv_dstc_exca_mtt__plan_no")));
			logger.info("날짜" + StringUtil.nvl((String)session.getAttribute("rnw_plno")));
			logger.info("갱신증번: " + StringUtil.nvl((String)session.getAttribute("rnw_plno")));
			
			empno = StringUtil.nvl((String)session.getAttribute("trv_dstc_exca_mtt__hdlr_empno"));
			jmvo.setTrv_dstc_exca_mtt__plno(StringUtil.nvl((String)session.getAttribute("trv_dstc_exca_mtt__plno")));
			jmvo.setTrv_dstc_exca_mtt__plan_no(StringUtil.nvl((String)session.getAttribute("trv_dstc_exca_mtt__plan_no")));
			jmvo.setTrv_dstc_exca_mtt__plan_dt(StringUtil.nvl((String)session.getAttribute("trv_dstc_exca_mtt__plan_dt")));
			jmvo.setTrv_dstc_exca_mtt__rnw_plno(StringUtil.nvl((String)session.getAttribute("rnw_plno")));
			jmvo.setTrv_dstc_exca_mtt__hdlr_empno(empno);
		}else{ // 계좌환급에서 넘어온 추가가입: request
			empno = StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__hdlr_empno"));
			jmvo.setTrv_dstc_exca_mtt__plno(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__plno")));
			jmvo.setTrv_dstc_exca_mtt__plan_no(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__plan_no")));
			jmvo.setTrv_dstc_exca_mtt__plan_dt(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__plan_dt")));
			jmvo.setTrv_dstc_exca_mtt__rnw_plno(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__rnw_plno")));
			jmvo.setTrv_dstc_exca_mtt__hdlr_empno(empno);
		}
		
		jmvo = mileageTobeService.getMMTI0294VO(jmvo);
		
		if("ZH001".equals(jmvo.getZ_resp_cd()) && session.getAttribute("imgfile") != null && session.getAttribute("exifDate") != null && !StringUtil.isEmpty(empno)) {
			Object[] imgfile = (Object[]) session.getAttribute("imgfile");
			String exifDate = (String) session.getAttribute("exifDate");

			mileageTobeService.regInfoToEdmsForMobileWeb3(empno, imgfile[0], exifDate, jmvo.getTrv_dstc_exca_mtt__rnw_plno() + "," + jmvo.getTrv_dstc_exca_mtt__rnw_plan_no());
		}
		
		request.setAttribute("jmvo", jmvo);
		return "/counter/carrider/tobe/ml5";
	}
	
	@RequestMapping(value="/mlCancelCard")
	public @ResponseBody Map<String, String> mlCancelCard(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		HttpSession session = request.getSession();
		Map<String, String> map = new HashMap<String, String>();
		MMTI0213VO mmti0213vo = new MMTI0213VO();
		mmti0213vo.setSms_ts_bvan(aes256Decrypt((String)session.getAttribute("p")));
		
		mmti0213vo = mileageTobeService.getMMTI0213VO(mmti0213vo);
		
		MMTI0291VO mmti0291vo = new MMTI0291VO();
		mmti0291vo.setTrv_dstc_exca_mtt__exca_bz_proc_dvn("2");													// 정산업무처리구분 2:확정
		mmti0291vo.setTrv_dstc_exca_mtt__plno((String)session.getAttribute("plno"));							// 증권번호
		mmti0291vo.setTrv_dstc_exca_mtt__plan_no((String)session.getAttribute("exp_exca_plan_no"));				// 설계번호
		mmti0291vo.setTrv_dstc_exca_mtt__exca_rtrn_dvn("3");													// 갱신환급구분 3:카드부분취소
		mmti0291vo.setTrv_dstc_exca_mtt__pdc_sr_dvn((String)session.getAttribute("pdc_sr_dvn"));				// 상품출처구분
		mmti0291vo.setTrv_dstc_exca_mtt__scrn_proc_cd((String)session.getAttribute("exp_exca_plan_rsl_cd"));	// 화면처리코드
		mmti0291vo.setTrv_dstc_exca_mtt__adc_rtrn_dvn((String)session.getAttribute("adc_rtrn_dvn"));			// 추징환급구분
		mmti0291vo.setTrv_dstc_exca_mtt__adc_rtrn_prm((String)session.getAttribute("adc_rtrn_prm"));			// 추징환급보험료
		mmti0291vo.setTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn(mmti0213vo.getTrv_dstc_splc_exca_yn());			// 주행거리간편정산여부
		mmti0291vo.setTrv_dstc_exca_mtt__pbox_no(mmti0213vo.getSms_ts_bvan());									// 사서함번호
		
		mmti0291vo.setTrv_dstc_exca_mtt__crd_scn_cncl_pss_yn((String)session.getAttribute("crd_scn_cncl_pss_yn")); // 카드부분취소가능여부
		mmti0291vo.setTrv_dstc_exca_mtt__stlm_cdcp_nm((String)session.getAttribute("stlm_cdcp_nm"));			// 결제카드사명
		mmti0291vo.setTrv_dstc_exca_mtt__stlm_crd_no((String)session.getAttribute("stlm_crd_no"));				// 결제카드번호
		mmti0291vo = mileageTobeService.getMMTI0291VO(mmti0291vo);
		
		if(mmti0291vo.getErrorCode().equals("0")){
			map.put("result", "y");
			session.setAttribute("scrn_proc_cd", mmti0291vo.getTrv_dstc_exca_mtt__scrn_proc_cd());
			session.setAttribute("rnw_plno", mmti0291vo.getTrv_dstc_exca_mtt__rnw_plno());
			session.setAttribute("pdc_sr_dvn", mmti0291vo.getTrv_dstc_exca_mtt__pdc_sr_dvn());
			
			// 아래 데이터 + 갱신증번: 추가가입위해 저장
			session.setAttribute("trv_dstc_exca_mtt__plno", mmti0291vo.getTrv_dstc_exca_mtt__plno());
			session.setAttribute("trv_dstc_exca_mtt__plan_no", mmti0291vo.getTrv_dstc_exca_mtt__plan_no());
			session.setAttribute("trv_dstc_exca_mtt__plan_dt", mmti0291vo.getTrv_dstc_exca_mtt__plan_dt());
			session.setAttribute("trv_dstc_exca_mtt__hdlr_empno", mmti0291vo.getTrv_dstc_exca_mtt__hdlr_empno());
			
			// 부적정/중복 이미지인 경우 화면처리코드 02 
			if("1".equals(mmti0291vo.getTrv_dstc_exca_mtt__imag_dup_yn())){
				mmti0291vo.setTrv_dstc_exca_mtt__scrn_proc_cd("02");
			}
			
			// CM 상품이고, 화면처리코드 IN(02, 14) or 이미지 중복
			
			if("CM".equals(mmti0291vo.getTrv_dstc_exca_mtt__pdc_sr_dvn()) && 
					("02".equals(mmti0291vo.getTrv_dstc_exca_mtt__scrn_proc_cd())
					|| "14".equals(mmti0291vo.getTrv_dstc_exca_mtt__scrn_proc_cd()))){
				
				MMTI0015VO mmti0015vo = new MMTI0015VO();
				mmti0015vo.setFunt_key("00");
				mmti0015vo.setPlan_no(mmti0291vo.getTrv_dstc_exca_mtt__plan_no());
				mmti0015vo = mileageTobeService.getMMTI0015VO(mmti0015vo);
				
				logger.debug("##### MMTI0015 시작 ##########################");
				logger.debug("##### 고객식별번호: " + mmti0015vo.getPlhd__cust_dcmt_no() + " ##########################");
				logger.debug("##### 고객번호: " + mmti0015vo.getPlhd__cust_no() + " ##########################");
				logger.debug("##### 고객명: " + mmti0015vo.getPlhd__cust_nm() + " ##########################");
				logger.debug("##### 이메일: " + mmti0015vo.getPlhd__eml() + " ##########################");
				logger.debug("##### 지역번호: " + mmti0015vo.getPlhd_cntp_if__tlp_arno() + " ##########################");
				logger.debug("##### 국번호: " + mmti0015vo.getPlhd_cntp_if__tlp_ofno() + " ##########################");
				logger.debug("##### 개별번호: " + mmti0015vo.getPlhd_cntp_if__tlp_idvno() + " ##########################");
				
				XTEM0021VO xtem0021vo = new XTEM0021VO();
				xtem0021vo.setCnsl_rpt_no("");						// 상담접수번호				
				xtem0021vo.setCm_bz_dvcd("05");
				xtem0021vo.setCnsl_typ_dvcd("07");
				xtem0021vo.setCm_plan_no(mmti0291vo.getTrv_dstc_exca_mtt__plan_no());
				xtem0021vo.setCnsl_rpy_dvcd("1");
				xtem0021vo.setCnsl_rpt_dttm(getDayTime());			// 현재년월일시분초 14자리
				xtem0021vo.setCust_nm(mmti0015vo.getPlhd__cust_nm());
				xtem0021vo.setCust_no(mmti0015vo.getPlhd__cust_no());
				
				String cust_dcmt_no = SeedUtil.decrypt(mmti0015vo.getPlhd__cust_dcmt_no());
				
				if("1".equals(cust_dcmt_no.substring(6, 7)) || "2".equals(cust_dcmt_no.substring(6, 7))
					|| "5".equals(cust_dcmt_no.substring(6, 7)) || "6".equals(cust_dcmt_no.substring(6, 7))){
					xtem0021vo.setBrth("19" + cust_dcmt_no.substring(0, 6));
				} else{
					xtem0021vo.setBrth("20" + cust_dcmt_no.substring(0, 6));
				}
				xtem0021vo.setSx_cd(cust_dcmt_no.substring(6, 7));
				xtem0021vo.setEml_adr(mmti0015vo.getPlhd__eml());
				xtem0021vo.setClp_tlcno(mmti0015vo.getPlhd_cntp_if__tlp_arno());
				xtem0021vo.setClp_ofno(mmti0015vo.getPlhd_cntp_if__tlp_ofno());
				xtem0021vo.setClp_idvno(mmti0015vo.getPlhd_cntp_if__tlp_idvno());
				xtem0021vo.setCnsl_rsvt_dt("99990101");
				xtem0021vo.setCnsl_rsvt_time_cd("1");
				xtem0021vo.setCnsl_cn("최종주행거리사진등록/만기정산");
				xtem0021vo.setCnsl_aply_csn_yn("1");
				xtem0021vo.setUrl_adr("");
				xtem0021vo.setCm_ctrmf_tpcd("32");
				xtem0021vo.setFrst_ipmn_empno("80000028");
				xtem0021vo.setFrst_ipnpt_dttm(getDayTime());		// 현재년월일시분초 14자리	
				
				xtem0021vo = mileageTobeService.getXTEM0021VO(xtem0021vo);
				logger.debug("##### XTEM0021 시작 ##########################");
				logger.debug("##### 처리결과: [ " + xtem0021vo.getProc_rtn() + " ] ##########################");
			}
		}else{
			map.put("result", "n");
			map.put("z_resp_msg", mmti0291vo.getZ_resp_msg());
		}
		
		//MMTI0213전문 정산이력테이블(MBTT02001) 적재
		MBTT02001VO mbtt02001vo = new MBTT02001VO();
		String scrnNm = "mlCancelCard";
		
		mbtt02001vo.setPboxNo(StringUtil.nvl(mmti0213vo.getSms_ts_bvan()));
		mbtt02001vo.setTlgIdVal("MMTI0213");
		mbtt02001vo.setEsbTrscId(StringUtil.nvl(mmti0213vo.getZ_trsc_id()));
		if("".equals(mmti0213vo.getPlno()) || null == mmti0213vo.getPlno()){
			mbtt02001vo.setPlno(" ");
		} else {
			mbtt02001vo.setPlno(StringUtil.nvl(mmti0213vo.getPlno()));
		}
		if("".equals(request.getParameter("exp_exca_plan_no")) || null == request.getParameter("exp_exca_plan_no")){
			mbtt02001vo.setPlanNo(" ");
		} else {
			mbtt02001vo.setPlanNo(StringUtil.nvl(request.getParameter("exp_exca_plan_no")));
		}
		if("".equals(mmti0213vo.getRnw_plno()) || null == mmti0213vo.getRnw_plno()){
			mbtt02001vo.setRnwPlno(" ");
		} else {
			mbtt02001vo.setRnwPlno(StringUtil.nvl(mmti0213vo.getRnw_plno()));
		}
		mbtt02001vo.setTlgProcRslCdVal(StringUtil.nvl(mmti0213vo.getZ_tlg_sp_cd()));
		mbtt02001vo.setTlgErrCdVal(StringUtil.nvl(mmti0213vo.getZ_trns_org_dvcd())+StringUtil.nvl(mmti0213vo.getZ_trns_org_cd()));
		if("".equals(request.getParameter("hdlrEmpno")) || null == request.getParameter("hdlrEmpno")){
			mbtt02001vo.setHdlrEmpno(" ");
		} else {
			mbtt02001vo.setHdlrEmpno(StringUtil.nvl(request.getParameter("hdlrEmpno")));
		}
		if("".equals(mmti0213vo.getPbox_no_dvcd()) || null == mmti0213vo.getPbox_no_dvcd()){
			mbtt02001vo.setPboxNoDvcd(" ");
		} else {
			mbtt02001vo.setPboxNoDvcd(StringUtil.nvl(mmti0213vo.getPbox_no_dvcd()));
		}
		if("".equals(mmti0213vo.getProc_dvn()) || null == mmti0213vo.getProc_dvn()){
			mbtt02001vo.setProcDvn(" ");
		} else {
			mbtt02001vo.setProcDvn(StringUtil.nvl(mmti0213vo.getProc_dvn()));
		}
		if("".equals(mmti0213vo.getTrv_dstc_exp_exca_dvcd()) || null == mmti0213vo.getTrv_dstc_exp_exca_dvcd()){
			mbtt02001vo.setTrvDstcExpExcaDvcd(" ");
		} else {
			mbtt02001vo.setTrvDstcExpExcaDvcd(StringUtil.nvl(mmti0213vo.getTrv_dstc_exp_exca_dvcd()));
		}
		if("".equals(mmti0213vo.getTrv_dstc_chng_aply_dvn()) || null == mmti0213vo.getTrv_dstc_chng_aply_dvn()){
			mbtt02001vo.setTrvDstcChngAplyDvn(" ");
		} else {
			mbtt02001vo.setTrvDstcChngAplyDvn(StringUtil.nvl(mmti0213vo.getTrv_dstc_chng_aply_dvn()));
		}
		if("".equals(mmti0213vo.getHdlr_fire_yn()) || null == mmti0213vo.getHdlr_fire_yn()){
			mbtt02001vo.setHdlrFireYn(" ");
		} else {
			mbtt02001vo.setHdlrFireYn(StringUtil.nvl(mmti0213vo.getHdlr_fire_yn()));
		}
		if("".equals(mmti0213vo.getMtcc_yn()) || null == mmti0213vo.getMtcc_yn()){
			mbtt02001vo.setMtccYn(" ");
		} else {
			mbtt02001vo.setMtccYn(StringUtil.nvl(mmti0213vo.getMtcc_yn()));
		}
		if("".equals(request.getParameter("aut_cgnt_trv_dstc")) || null == request.getParameter("aut_cgnt_trv_dstc")){
			mbtt02001vo.setAutCgntTrvDstc(0);
		} else {
			mbtt02001vo.setAutCgntTrvDstc(Double.parseDouble(request.getParameter("aut_cgnt_trv_dstc")));
		}
		if("".equals(request.getParameter("autCgntTrvDstcRslCd")) || null == request.getParameter("autCgntTrvDstcRslCd")){
			mbtt02001vo.setAutCgntTrvDstcRslCd(" ");
		} else {
			mbtt02001vo.setAutCgntTrvDstcRslCd(StringUtil.nvl(request.getParameter("autCgntTrvDstcRslCd")));
		}
		if("".equals(request.getParameter("inptTrvDstc")) || null == request.getParameter("inptTrvDstc")){
			mbtt02001vo.setInptTrvDstc(0);
		} else {
			mbtt02001vo.setInptTrvDstc(Double.parseDouble(request.getParameter("inptTrvDstc")));
		}
		if("".equals(request.getParameter("cnv_trv_dstc")) || null == request.getParameter("cnv_trv_dstc")){
			mbtt02001vo.setCnvTrvDstc(0);
		} else {
			mbtt02001vo.setCnvTrvDstc(Double.parseDouble(request.getParameter("cnv_trv_dstc")));
		}
		if("".equals(request.getParameter("exp_exca_plan_rsl_cd")) || null == request.getParameter("exp_exca_plan_rsl_cd")){
			mbtt02001vo.setExpExcaPlanRslCd(" ");
		} else {
			mbtt02001vo.setExpExcaPlanRslCd(StringUtil.nvl(request.getParameter("exp_exca_plan_rsl_cd")));
		}
		if("".equals(request.getParameter("excaBzProcDvn")) || null == request.getParameter("excaBzProcDvn")){
			mbtt02001vo.setExcaBzProcDvn(" ");
		} else {
			mbtt02001vo.setExcaBzProcDvn(StringUtil.nvl(request.getParameter("excaBzProcDvn")));
		}
		if("".equals(request.getParameter("excaRtrnDvn")) || null == request.getParameter("excaRtrnDvn")){
			mbtt02001vo.setExcaRtrnDvn(" ");
		} else {
			mbtt02001vo.setExcaRtrnDvn(StringUtil.nvl(request.getParameter("excaRtrnPrm")));
		}
		if("".equals(request.getParameter("pdc_sr_dvn")) || null == request.getParameter("pdc_sr_dvn")){
			mbtt02001vo.setPdcSrDvn(" ");
		} else {
			mbtt02001vo.setPdcSrDvn(StringUtil.nvl(request.getParameter("pdc_sr_dvn")));
		}
		if("".equals(request.getParameter("adc_rtrn_prm")) || null == request.getParameter("adc_rtrn_prm")){
			mbtt02001vo.setAdcRtrnPrm(0);
		} else {
			mbtt02001vo.setAdcRtrnPrm(Double.parseDouble(request.getParameter("adc_rtrn_prm")));
		}
		if("".equals(request.getParameter("trvDstcSplcExcaYn")) || null == request.getParameter("trvDstcSplcExcaYn")){
			mbtt02001vo.setTrvDstcSplcExcaYn(" ");
		} else {
			mbtt02001vo.setTrvDstcSplcExcaYn(StringUtil.nvl(request.getParameter("trvDstcSplcExcaYn")));
		}
		if("".equals(request.getParameter("imagDupYn")) || null == request.getParameter("imagDupYn")){
			mbtt02001vo.setImagDupYn(" ");
		} else {
			mbtt02001vo.setImagDupYn(StringUtil.nvl(request.getParameter("imagDupYn")));
		}
		if("".equals(request.getParameter("nrmProcYn")) || null == request.getParameter("nrmProcYn")){
			mbtt02001vo.setNrmProcYn(" ");
		} else {
			mbtt02001vo.setNrmProcYn(StringUtil.nvl(request.getParameter("nrmProcYn")));
		}
		if("".equals(request.getParameter("crdScnCnclPssYn")) || null == request.getParameter("crdScnCnclPssYn")){
			mbtt02001vo.setCrdScnCnclPssYn(" ");
		} else {
			mbtt02001vo.setCrdScnCnclPssYn(StringUtil.nvl(request.getParameter("crdScnCnclPssYn")));
		}
		mbtt02001vo.setRespCn(StringUtil.nvl(mmti0213vo.getZ_resp_cd()));
		mbtt02001vo.setRslCn(scrnNm + "_" + StringUtil.nvl(mmti0213vo.getZ_resp_msg()));
		mbtt02001vo.setFrstIpmnEmpno("82101685");
		mbtt02001vo.setFnalAmdrEmpno("82101685");
		if("".equals(request.getParameter("adc_rtrn_dvn")) || null == request.getParameter("adc_rtrn_dvn")){
			mbtt02001vo.setAdcRtrnDvn(" ");
		} else {
			mbtt02001vo.setAdcRtrnDvn(StringUtil.nvl(request.getParameter("adc_rtrn_dvn")));
		}
		if("".equals(request.getParameter("scrn_proc_cd")) || null == request.getParameter("scrn_proc_cd")){
			mbtt02001vo.setScrnProcCd(" ");
		} else {
			mbtt02001vo.setScrnProcCd(StringUtil.nvl(request.getParameter("scrn_proc_cd")));
		}
		if("".equals(mmti0213vo.getCtc_plno()) || null == mmti0213vo.getCtc_plno()){
			mbtt02001vo.setCtcPlno(" ");
		} else {
			mbtt02001vo.setCtcPlno(StringUtil.nvl(mmti0213vo.getCtc_plno()));
		}
		if("".equals(request.getParameter("trv_dstc_proc_dvcd")) || null == request.getParameter("trv_dstc_proc_dvcd")){
			mbtt02001vo.setTrvDstcProcDvcd(" ");
		} else {
			mbtt02001vo.setTrvDstcProcDvcd(StringUtil.nvl(request.getParameter("trv_dstc_proc_dvcd")));
		}
		if("".equals(request.getParameter("mbl_snd_no")) || null == request.getParameter("mbl_snd_no")){
			mbtt02001vo.setMblSndNo(" ");
		} else {
			mbtt02001vo.setMblSndNo(StringUtil.nvl(request.getParameter("mbl_snd_no")));
		}
		if("".equals(request.getParameter("plan_plno_dvcd")) || null == request.getParameter("plan_plno_dvcd")){
			mbtt02001vo.setPlanPlnoDvcd(" ");
		} else {
			mbtt02001vo.setPlanPlnoDvcd(StringUtil.nvl(request.getParameter("plan_plno_dvcd")));
		}
		if("".equals(request.getParameter("plan_plno")) || null == request.getParameter("plan_plno")){
			mbtt02001vo.setPlanPlno(" ");
		} else {
			mbtt02001vo.setPlanPlno(StringUtil.nvl(request.getParameter("plan_plno")));
		}
		if("".equals(mmti0213vo.getChng_plan_no()) || null == mmti0213vo.getChng_plan_no()){
			mbtt02001vo.setChngPlanNo(" ");
		} else {
			mbtt02001vo.setChngPlanNo(StringUtil.nvl(mmti0213vo.getChng_plan_no()));
		}
		if("".equals(request.getParameter("dst_tty_dvn1")) || null == request.getParameter("dst_tty_dvn1")){
			mbtt02001vo.setDstTtyDvn1(" ");
		} else {
			mbtt02001vo.setDstTtyDvn1(StringUtil.nvl(request.getParameter("dst_tty_dvn1")));
		}
		if("".equals(request.getParameter("dst_tty_dvn2")) || null == request.getParameter("dst_tty_dvn2")){
			mbtt02001vo.setDstTtyDvn2(" ");
		} else {
			mbtt02001vo.setDstTtyDvn2(StringUtil.nvl(request.getParameter("dst_tty_dvn2")));
		}
		if("".equals(request.getParameter("dst_tty_dvn3")) || null == request.getParameter("dst_tty_dvn3")){
			mbtt02001vo.setDstTtyDvn3(" ");
		} else {
			mbtt02001vo.setDstTtyDvn3(StringUtil.nvl(request.getParameter("dst_tty_dvn3")));
		}
		if("".equals(request.getParameter("dst_tty_dvn4")) || null == request.getParameter("dst_tty_dvn4")){
			mbtt02001vo.setDstTtyDvn4(" ");
		} else {
			mbtt02001vo.setDstTtyDvn4(StringUtil.nvl(request.getParameter("dst_tty_dvn4")));
		}
		if("".equals(request.getParameter("dst_tty_dvn5")) || null == request.getParameter("dst_tty_dvn5")){
			mbtt02001vo.setDstTtyDvn5(" ");
		} else {
			mbtt02001vo.setDstTtyDvn5(StringUtil.nvl(request.getParameter("dst_tty_dvn5")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt1")) || null == request.getParameter("phgp_regt_tgt1")){
			mbtt02001vo.setPhgpRegtTgt1(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt1(StringUtil.nvl(request.getParameter("phgp_regt_tgt1")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt2")) || null == request.getParameter("phgp_regt_tgt2")){
			mbtt02001vo.setPhgpRegtTgt2(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt2(StringUtil.nvl(request.getParameter("phgp_regt_tgt2")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt3")) || null == request.getParameter("phgp_regt_tgt3")){
			mbtt02001vo.setPhgpRegtTgt3(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt3(StringUtil.nvl(request.getParameter("phgp_regt_tgt3")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt4")) || null == request.getParameter("phgp_regt_tgt4")){
			mbtt02001vo.setPhgpRegtTgt4(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt4(StringUtil.nvl(request.getParameter("phgp_regt_tgt4")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt5")) || null == request.getParameter("phgp_regt_tgt5")){
			mbtt02001vo.setPhgpRegtTgt5(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt5(StringUtil.nvl(request.getParameter("phgp_regt_tgt5")));
		}
		
		//MMTI0213 insert
		int insertRow = 0;
		
		logger.info("#### mlCancelCard MMTI0213 MBTT02001 before ####");
		insertRow = mileageTobeService.insertJungsanTest(mbtt02001vo);
		logger.info("#### mlCancelCard MMTI0213 MBTT02001 after ####");
		
		if(insertRow < 1){
			logger.info("#### 사서함번호: " + StringUtil.nvl(mbtt02001vo.getPboxNo()) + "####");
			logger.info("#### insert 결과: Fail ####");
		}else{
			logger.info("#### insert 결과: Success ####");
		}
		
		//MMTI0291전문 정산이력테이블(MBTT02001) 적재
		mbtt02001vo.setPboxNo(StringUtil.nvl(mmti0213vo.getSms_ts_bvan()));
		mbtt02001vo.setTlgIdVal("MMTI0291");
		mbtt02001vo.setEsbTrscId(StringUtil.nvl(mmti0291vo.getZ_trsc_id()));
		if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__plno()) || null == mmti0291vo.getTrv_dstc_exca_mtt__plno()){
			mbtt02001vo.setPlno(" ");
		} else {
			mbtt02001vo.setPlno(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__plno()));
		}
		if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__plan_no()) || null == mmti0291vo.getTrv_dstc_exca_mtt__plan_no()){
			mbtt02001vo.setPlanNo(" ");
		} else {
			mbtt02001vo.setPlanNo(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__plan_no()));
		}
		if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__rnw_plno()) || null == mmti0291vo.getTrv_dstc_exca_mtt__rnw_plno()){
			mbtt02001vo.setRnwPlno(" ");
		} else {
			mbtt02001vo.setRnwPlno(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__rnw_plno()));
		}
		mbtt02001vo.setTlgProcRslCdVal(StringUtil.nvl(mmti0291vo.getZ_tlg_sp_cd()));
		mbtt02001vo.setTlgErrCdVal(StringUtil.nvl(mmti0291vo.getZ_trns_org_dvcd())+StringUtil.nvl(mmti0291vo.getZ_trns_org_cd()));
		if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__hdlr_empno()) || null == mmti0291vo.getTrv_dstc_exca_mtt__hdlr_empno()){
			mbtt02001vo.setHdlrEmpno(" ");
		} else {
			mbtt02001vo.setHdlrEmpno(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__hdlr_empno()));
		}
		if("".equals(mmti0213vo.getPbox_no_dvcd()) || null == mmti0213vo.getPbox_no_dvcd()){
			mbtt02001vo.setPboxNoDvcd(" ");
		} else {
			mbtt02001vo.setPboxNoDvcd(StringUtil.nvl(mmti0213vo.getPbox_no_dvcd()));
		}
		if("".equals(mmti0213vo.getProc_dvn()) || null == mmti0213vo.getProc_dvn()){
			mbtt02001vo.setProcDvn(" ");
		} else {
			mbtt02001vo.setProcDvn(StringUtil.nvl(mmti0213vo.getProc_dvn()));
		}
		if("".equals(mmti0213vo.getTrv_dstc_exp_exca_dvcd()) || null == mmti0213vo.getTrv_dstc_exp_exca_dvcd()){
			mbtt02001vo.setTrvDstcExpExcaDvcd(" ");
		} else {
			mbtt02001vo.setTrvDstcExpExcaDvcd(StringUtil.nvl(mmti0213vo.getTrv_dstc_exp_exca_dvcd()));
		}
		if("".equals(mmti0213vo.getTrv_dstc_chng_aply_dvn()) || null == mmti0213vo.getTrv_dstc_chng_aply_dvn()){
			mbtt02001vo.setTrvDstcChngAplyDvn(" ");
		} else {
			mbtt02001vo.setTrvDstcChngAplyDvn(StringUtil.nvl(mmti0213vo.getTrv_dstc_chng_aply_dvn()));
		}
		if("".equals(mmti0213vo.getHdlr_fire_yn()) || null == mmti0213vo.getHdlr_fire_yn()){
			mbtt02001vo.setHdlrFireYn(" ");
		} else {
			mbtt02001vo.setHdlrFireYn(StringUtil.nvl(mmti0213vo.getHdlr_fire_yn()));
		}
		if("".equals(mmti0213vo.getMtcc_yn()) || null == mmti0213vo.getMtcc_yn()){
			mbtt02001vo.setMtccYn(" ");
		} else {
			mbtt02001vo.setMtccYn(StringUtil.nvl(mmti0213vo.getMtcc_yn()));
		}
		if("".equals(request.getParameter("aut_cgnt_trv_dstc")) || null == request.getParameter("aut_cgnt_trv_dstc")){
			mbtt02001vo.setAutCgntTrvDstc(0);
		} else {
			mbtt02001vo.setAutCgntTrvDstc(Double.parseDouble(request.getParameter("aut_cgnt_trv_dstc")));
		}
		if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__aut_cgnt_trv_dstc_rsl_cd()) || null == mmti0291vo.getTrv_dstc_exca_mtt__aut_cgnt_trv_dstc_rsl_cd()){
			mbtt02001vo.setAutCgntTrvDstcRslCd(" ");
		} else {
			mbtt02001vo.setAutCgntTrvDstcRslCd(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__aut_cgnt_trv_dstc_rsl_cd()));
		}
		if("".equals(request.getParameter("inptTrvDstc")) || null == request.getParameter("inptTrvDstc")){
			mbtt02001vo.setInptTrvDstc(0);
		} else {
			mbtt02001vo.setInptTrvDstc(Double.parseDouble(request.getParameter("inptTrvDstc")));
		}
		if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__cnv_trv_dstc()) || null == mmti0291vo.getTrv_dstc_exca_mtt__cnv_trv_dstc()){
			mbtt02001vo.setCnvTrvDstc(0);
		} else {
			mbtt02001vo.setCnvTrvDstc(Double.parseDouble(mmti0291vo.getTrv_dstc_exca_mtt__cnv_trv_dstc()));
		}
		if("".equals(request.getParameter("exp_exca_plan_rsl_cd")) || null == request.getParameter("exp_exca_plan_rsl_cd")){
			mbtt02001vo.setExpExcaPlanRslCd(" ");
		} else {
			mbtt02001vo.setExpExcaPlanRslCd(StringUtil.nvl(request.getParameter("exp_exca_plan_rsl_cd")));
		}
		if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__exca_bz_proc_dvn()) || null == mmti0291vo.getTrv_dstc_exca_mtt__exca_bz_proc_dvn()){
			mbtt02001vo.setExcaBzProcDvn(" ");
		} else {
			mbtt02001vo.setExcaBzProcDvn(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__exca_bz_proc_dvn()));
		}
		if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__exca_rtrn_dvn()) || null == mmti0291vo.getTrv_dstc_exca_mtt__exca_rtrn_dvn()){
			mbtt02001vo.setExcaRtrnDvn(" ");
		} else {
			mbtt02001vo.setExcaRtrnDvn(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__exca_rtrn_dvn()));
		}
		if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__pdc_sr_dvn()) || null == mmti0291vo.getTrv_dstc_exca_mtt__pdc_sr_dvn()){
			mbtt02001vo.setPdcSrDvn(" ");
		} else {
			mbtt02001vo.setPdcSrDvn(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__pdc_sr_dvn()));
		}
		if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__adc_rtrn_prm()) || null == mmti0291vo.getTrv_dstc_exca_mtt__adc_rtrn_prm()){
			mbtt02001vo.setAdcRtrnPrm(0);
		} else {
			mbtt02001vo.setAdcRtrnPrm(Double.parseDouble(mmti0291vo.getTrv_dstc_exca_mtt__adc_rtrn_prm()));
		}
		if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn()) || null == mmti0291vo.getTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn()){
			mbtt02001vo.setTrvDstcSplcExcaYn(" ");
		} else {
			mbtt02001vo.setTrvDstcSplcExcaYn(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn()));
		}
		if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__imag_dup_yn()) || null == mmti0291vo.getTrv_dstc_exca_mtt__imag_dup_yn()){
			mbtt02001vo.setImagDupYn(" ");
		} else {
			mbtt02001vo.setImagDupYn(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__imag_dup_yn()));
		}
		if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__nrm_proc_yn()) || null == mmti0291vo.getTrv_dstc_exca_mtt__nrm_proc_yn()){
			mbtt02001vo.setNrmProcYn(" ");
		} else {
			mbtt02001vo.setNrmProcYn(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__nrm_proc_yn()));
		}
		if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__crd_scn_cncl_pss_yn()) || null == mmti0291vo.getTrv_dstc_exca_mtt__crd_scn_cncl_pss_yn()){
			mbtt02001vo.setCrdScnCnclPssYn(" ");
		} else {
			mbtt02001vo.setCrdScnCnclPssYn(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__crd_scn_cncl_pss_yn()));
		}
		mbtt02001vo.setRespCn(StringUtil.nvl(mmti0291vo.getZ_resp_cd()));
		mbtt02001vo.setRslCn(scrnNm + "_" + StringUtil.nvl(mmti0291vo.getZ_resp_msg()));
		mbtt02001vo.setFrstIpmnEmpno("82101685");
		mbtt02001vo.setFnalAmdrEmpno("82101685");
		if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__adc_rtrn_dvn()) || null == mmti0291vo.getTrv_dstc_exca_mtt__adc_rtrn_dvn()){
			mbtt02001vo.setAdcRtrnDvn(" ");
		} else {
			mbtt02001vo.setAdcRtrnDvn(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__adc_rtrn_dvn()));
		}
		if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__scrn_proc_cd()) || null == mmti0291vo.getTrv_dstc_exca_mtt__scrn_proc_cd()){
			mbtt02001vo.setScrnProcCd(" ");
		} else {
			mbtt02001vo.setScrnProcCd(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__scrn_proc_cd()));
		}
		if("".equals(request.getParameter("ctc_plno")) || null == request.getParameter("ctc_plno")){
			mbtt02001vo.setCtcPlno(" ");
		} else {
			mbtt02001vo.setCtcPlno(StringUtil.nvl(request.getParameter("ctc_plno")));
		}
		if("".equals(request.getParameter("trv_dstc_proc_dvcd")) || null == request.getParameter("trv_dstc_proc_dvcd")){
			mbtt02001vo.setTrvDstcProcDvcd(" ");
		} else {
			mbtt02001vo.setTrvDstcProcDvcd(StringUtil.nvl(request.getParameter("trv_dstc_proc_dvcd")));
		}
		if("".equals(request.getParameter("mbl_snd_no")) || null == request.getParameter("mbl_snd_no")){
			mbtt02001vo.setMblSndNo(" ");
		} else {
			mbtt02001vo.setMblSndNo(StringUtil.nvl(request.getParameter("mbl_snd_no")));
		}
		if("".equals(request.getParameter("plan_plno_dvcd")) || null == request.getParameter("plan_plno_dvcd")){
			mbtt02001vo.setPlanPlnoDvcd(" ");
		} else {
			mbtt02001vo.setPlanPlnoDvcd(StringUtil.nvl(request.getParameter("plan_plno_dvcd")));
		}
		if("".equals(request.getParameter("plan_plno")) || null == request.getParameter("plan_plno")){
			mbtt02001vo.setPlanPlno(" ");
		} else {
			mbtt02001vo.setPlanPlno(StringUtil.nvl(request.getParameter("plan_plno")));
		}
		if("".equals(request.getParameter("chng_plan_no")) || null == request.getParameter("chng_plan_no")){
			mbtt02001vo.setChngPlanNo(" ");
		} else {
			mbtt02001vo.setChngPlanNo(StringUtil.nvl(request.getParameter("chng_plan_no")));
		}
		if("".equals(request.getParameter("dst_tty_dvn1")) || null == request.getParameter("dst_tty_dvn1")){
			mbtt02001vo.setDstTtyDvn1(" ");
		} else {
			mbtt02001vo.setDstTtyDvn1(StringUtil.nvl(request.getParameter("dst_tty_dvn1")));
		}
		if("".equals(request.getParameter("dst_tty_dvn2")) || null == request.getParameter("dst_tty_dvn2")){
			mbtt02001vo.setDstTtyDvn2(" ");
		} else {
			mbtt02001vo.setDstTtyDvn2(StringUtil.nvl(request.getParameter("dst_tty_dvn2")));
		}
		if("".equals(request.getParameter("dst_tty_dvn3")) || null == request.getParameter("dst_tty_dvn3")){
			mbtt02001vo.setDstTtyDvn3(" ");
		} else {
			mbtt02001vo.setDstTtyDvn3(StringUtil.nvl(request.getParameter("dst_tty_dvn3")));
		}
		if("".equals(request.getParameter("dst_tty_dvn4")) || null == request.getParameter("dst_tty_dvn4")){
			mbtt02001vo.setDstTtyDvn4(" ");
		} else {
			mbtt02001vo.setDstTtyDvn4(StringUtil.nvl(request.getParameter("dst_tty_dvn4")));
		}
		if("".equals(request.getParameter("dst_tty_dvn5")) || null == request.getParameter("dst_tty_dvn5")){
			mbtt02001vo.setDstTtyDvn5(" ");
		} else {
			mbtt02001vo.setDstTtyDvn5(StringUtil.nvl(request.getParameter("dst_tty_dvn5")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt1")) || null == request.getParameter("phgp_regt_tgt1")){
			mbtt02001vo.setPhgpRegtTgt1(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt1(StringUtil.nvl(request.getParameter("phgp_regt_tgt1")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt2")) || null == request.getParameter("phgp_regt_tgt2")){
			mbtt02001vo.setPhgpRegtTgt2(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt2(StringUtil.nvl(request.getParameter("phgp_regt_tgt2")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt3")) || null == request.getParameter("phgp_regt_tgt3")){
			mbtt02001vo.setPhgpRegtTgt3(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt3(StringUtil.nvl(request.getParameter("phgp_regt_tgt3")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt4")) || null == request.getParameter("phgp_regt_tgt4")){
			mbtt02001vo.setPhgpRegtTgt4(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt4(StringUtil.nvl(request.getParameter("phgp_regt_tgt4")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt5")) || null == request.getParameter("phgp_regt_tgt5")){
			mbtt02001vo.setPhgpRegtTgt5(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt5(StringUtil.nvl(request.getParameter("phgp_regt_tgt5")));
		}
		
		//MMTI0291 insert
		insertRow = 0;
		
		logger.info("#### mlCancelCard MMTI0291 MBTT02001 before ####");
		insertRow = mileageTobeService.insertJungsanTest(mbtt02001vo);
		logger.info("#### mlCancelCard MMTI0291 MBTT02001 after ####");
		
		if(insertRow < 1){
			logger.info("#### 사서함번호: " + StringUtil.nvl(mbtt02001vo.getPboxNo()) + "####");
			logger.info("#### insert 결과: Fail ####");
		}else{
			logger.info("#### insert 결과: Success ####");
		}
		
		return map;	
	}
	
/*	@RequestMapping(value="/mlCancelCard2")
	public @ResponseBody Map<String, String> mlCancelCard2(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		HttpSession session = request.getSession();
		Map<String, String> map = new HashMap<String, String>();

		map.put("result", "y");
		session.setAttribute("scrn_proc_cd", "01");
		session.setAttribute("rnw_plno", "123123123123");
		session.setAttribute("pdc_sr_dvn", "CM");
		
		return map;	
	}*/
	
	@RequestMapping(value="/ml_crd_end")
	public String ml_crd_end(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		
		return "/counter/carrider/tobe/ml_crd_end";
	}
	
	  @RequestMapping({"/buttonLog"})
	  public void buttonLog(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
	    String buttonStyleLog = request.getParameter("buttonStyle");
	    System.out.println("### CHECK BTN STYLE ###");
	    System.out.println(buttonStyleLog);
	  }
	
	@RequestMapping(value="/otcm_self_ctf")
	public String otcm_self_ctf(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		HttpSession session = request.getSession();
		
		//갱신주행거리정산처리
		MMTI0321VO jmvo = new MMTI0321VO();
		
		jmvo.setSrch_cnd__pbox_no(request.getParameter("p"));
		jmvo = mileageTobeService.getMMTI0321VO(jmvo);
		
		request.setAttribute("p", request.getParameter("p"));
		session.setAttribute("pbox_no", request.getParameter("p"));
		session.setAttribute("rtun_cd", StringUtil.nvl(jmvo.getSrch_rsl__rtun_cd()));
		session.setAttribute("rtun_msg", StringUtil.nvl(jmvo.getSrch_rsl__rtun_msg()));
		session.setAttribute("plhd_nm", StringUtil.nvl(jmvo.getSrch_rsl__plhd_nm()));
		session.setAttribute("plno", StringUtil.nvl(jmvo.getSrch_rsl__plno()));
		session.setAttribute("plan_no", StringUtil.nvl(jmvo.getSrch_rsl__plan_no()));
		session.setAttribute("ctrmf_bse_dt", StringUtil.nvl(jmvo.getSrch_rsl__ctrmf_bse_dt()));
		session.setAttribute("hngl_vh_no", StringUtil.nvl(jmvo.getSrch_rsl__hngl_vh_no()));
		session.setAttribute("adc_rtrn_dvcd", StringUtil.nvl(jmvo.getSrch_rsl__adc_rtrn_dvcd()));
		session.setAttribute("pdc_sr_dvn", StringUtil.nvl(jmvo.getSrch_rsl__pdc_sr_dvn()));
		session.setAttribute("cnv_trv_dstc", StringUtil.nvl(jmvo.getSrch_rsl__cnv_trv_dstc()));
		session.setAttribute("kid_trv_dstc", StringUtil.nvl(jmvo.getSrch_rsl__kid_trv_dstc()));
		session.setAttribute("adc_rtrn_prm", StringUtil.nvl(jmvo.getSrch_rsl__adc_rtrn_prm()));
		session.setAttribute("crd_scn_cncl_pss_yn", StringUtil.nvl(jmvo.getSrch_rsl__crd_scn_cncl_pss_yn()));
		session.setAttribute("stlm_cdcp_nm", StringUtil.nvl(jmvo.getSrch_rsl__stlm_cdcp_nm()));
		session.setAttribute("stlm_crd_no", StringUtil.nvl(aes256Decrypt(jmvo.getSrch_rsl__stlm_crd_no())));
		session.setAttribute("trv_dstc_exp_exca_dvcd", StringUtil.nvl(jmvo.getSrch_rsl__trv_dstc_exp_exca_dvcd()));
		request.setAttribute("jmvo", jmvo);
		
		if(!StringUtil.isEmpty(request.getParameter("appSeq"))){
			session.setAttribute("appSeq", StringUtil.nvl(request.getParameter("appSeq")));
		}
		
		logger.info("###### otcm_self_ctf 테스트1 ######");
		logger.info("###### request ######");
		logger.info("###### p: " + StringUtil.nvl(request.getParameter("p")));
		logger.info("###### pbox_no: " + request.getParameter("p"));
		logger.info("###### plno: " + StringUtil.nvl(request.getParameter("plno")));
		logger.info("###### plan_no: " + StringUtil.nvl(request.getParameter("plan_no")));
		logger.info("###### rtun_cd: " + StringUtil.nvl(request.getParameter("rtun_cd")));
		logger.info("###### rtun_msg: " + StringUtil.nvl(request.getParameter("rtun_msg")));
		logger.info("###### plhd_nm: " + StringUtil.nvl(request.getParameter("plhd_nm")));
		logger.info("###### ctrmf_bse_dt: " + StringUtil.nvl(request.getParameter("ctrmf_bse_dt")));
		logger.info("###### hngl_vh_no: " + StringUtil.nvl(request.getParameter("hngl_vh_no")));
		logger.info("###### adc_rtrn_dvcd: " + StringUtil.nvl(request.getParameter("adc_rtrn_dvcd")));
		logger.info("###### pdc_sr_dvn: " + StringUtil.nvl(request.getParameter("pdc_sr_dvn")));
		logger.info("###### cnv_trv_dstc: " + StringUtil.nvl(request.getParameter("cnv_trv_dstc")));
		logger.info("###### kid_trv_dstc: " + StringUtil.nvl(request.getParameter("kid_trv_dstc")));
		logger.info("###### adc_rtrn_prm: " + StringUtil.nvl(request.getParameter("adc_rtrn_prm")));
		logger.info("###### crd_scn_cncl_pss_yn: " + StringUtil.nvl(request.getParameter("crd_scn_cncl_pss_yn")));
		logger.info("###### stlm_cdcp_nm: " + StringUtil.nvl(request.getParameter("stlm_cdcp_nm")));
		logger.info("###### stlm_crd_no: " + StringUtil.nvl(aes256Decrypt(jmvo.getSrch_rsl__stlm_crd_no())));
		logger.info("###### trv_dstc_exp_exca_dvcd: " + StringUtil.nvl(request.getParameter("trv_dstc_exp_exca_dvcd")));
		
		logger.info("###### otcm_self_ctf 테스트2 ######");
		logger.info("###### session ######");
		logger.info("###### p: " + request.getParameter("p"));
		logger.info("###### pbox_no: " + request.getParameter("p"));
		logger.info("###### plno: " + StringUtil.nvl((String)session.getAttribute("plno")));
		logger.info("###### plan_no: " + StringUtil.nvl((String)session.getAttribute("plan_no")));
		logger.info("###### rtun_cd: " + StringUtil.nvl((String)session.getAttribute("rtun_cd")));
		logger.info("###### rtun_msg: " + StringUtil.nvl((String)session.getAttribute("rtun_msg")));
		logger.info("###### plhd_nm: " + String.valueOf(session.getAttribute("plhd_nm")));
		logger.info("###### ctrmf_bse_dt: " + StringUtil.nvl((String)session.getAttribute("ctrmf_bse_dt")));
		logger.info("###### hngl_vh_no: " + StringUtil.nvl((String)session.getAttribute("hngl_vh_no")));
		logger.info("###### adc_rtrn_dvcd: " + StringUtil.nvl((String)session.getAttribute("adc_rtrn_dvcd")));
		logger.info("###### pdc_sr_dvn: " + StringUtil.nvl((String)session.getAttribute("pdc_sr_dvn")));
		logger.info("###### cnv_trv_dstc: " + StringUtil.nvl((String)session.getAttribute("cnv_trv_dstc")));
		logger.info("###### kid_trv_dstc: " + StringUtil.nvl((String)session.getAttribute("kid_trv_dstc")));
		logger.info("###### adc_rtrn_prm: " + StringUtil.nvl((String)session.getAttribute("adc_rtrn_prm")));
		logger.info("###### crd_scn_cncl_pss_yn: " + StringUtil.nvl((String)session.getAttribute("crd_scn_cncl_pss_yn")));
		logger.info("###### stlm_cdcp_nm: " + StringUtil.nvl((String)session.getAttribute("stlm_cdcp_nm")));
		logger.info("###### stlm_crd_no: " + StringUtil.nvl(aes256Decrypt(jmvo.getSrch_rsl__stlm_crd_no())));
		logger.info("###### trv_dstc_exp_exca_dvcd: " + StringUtil.nvl((String)session.getAttribute("trv_dstc_exp_exca_dvcd")));
		
		request.setAttribute("p",							request.getParameter("p"));
		request.setAttribute("pbox_no",						request.getParameter("p"));
		request.setAttribute("jmvo",						jmvo);
		request.setAttribute("plno",						StringUtil.nvl(request.getParameter("plno")));
		request.setAttribute("plan_no",						StringUtil.nvl(request.getParameter("plan_no")));
		request.setAttribute("rtun_cd",						StringUtil.nvl(request.getParameter("rtun_cd")));
		request.setAttribute("rtun_msg",					StringUtil.nvl(request.getParameter("rtun_msg")));
		request.setAttribute("plhd_nm",						StringUtil.nvl(request.getParameter("plhd_nm")));
		request.setAttribute("ctrmf_bse_dt",				StringUtil.nvl(request.getParameter("ctrmf_bse_dt")));
		request.setAttribute("hngl_vh_no",					StringUtil.nvl(request.getParameter("hngl_vh_no")));
		request.setAttribute("adc_rtrn_dvn",				StringUtil.nvl(request.getParameter("adc_rtrn_dvn")));
		request.setAttribute("pdc_sr_dvn",					StringUtil.nvl(request.getParameter("pdc_sr_dvn")));
		request.setAttribute("cnv_trv_dstc",				StringUtil.nvl(request.getParameter("cnv_trv_dstc")));
		request.setAttribute("kid_trv_dstc",				StringUtil.nvl(request.getParameter("kid_trv_dstc")));
		request.setAttribute("adc_rtrn_prm",				StringUtil.nvl(request.getParameter("adc_rtrn_prm")));
		request.setAttribute("crd_scn_cncl_pss_yn",			StringUtil.nvl(request.getParameter("crd_scn_cncl_pss_yn")));
		request.setAttribute("stlm_cdcp_nm",				StringUtil.nvl(request.getParameter("stlm_cdcp_nm")));
		request.setAttribute("stlm_crd_no",					StringUtil.nvl(aes256Decrypt(jmvo.getSrch_rsl__stlm_crd_no())));
		request.setAttribute("bank_cd",						StringUtil.nvl(request.getParameter("bank_cd")));
		request.setAttribute("acc_no",						StringUtil.nvl(request.getParameter("acc_no")));
		request.setAttribute("exca_rtrn_dvn",				StringUtil.nvl(request.getParameter("exca_rtrn_dvn")));
		request.setAttribute("errorCode",					StringUtil.nvl(request.getParameter("errorCode")));
		request.setAttribute("trv_dstc_exp_exca_dvcd",		StringUtil.nvl(request.getParameter("trv_dstc_exp_exca_dvcd")));
		
		session.setAttribute("p", 							request.getParameter("p"));
		session.setAttribute("pbox_no", 					request.getParameter("p"));
		session.setAttribute("jmvo",						jmvo);
		session.setAttribute("plno",						StringUtil.nvl(session.getAttribute("plno")));
		session.setAttribute("plan_no",						StringUtil.nvl(session.getAttribute("plan_no")));
		session.setAttribute("rtun_cd",						StringUtil.nvl(session.getAttribute("rtun_cd")));
		session.setAttribute("rtun_msg",					StringUtil.nvl(session.getAttribute("rtun_msg")));
		session.setAttribute("plhd_nm",						StringUtil.nvl(session.getAttribute("plhd_nm")));
		session.setAttribute("ctrmf_bse_dt",				StringUtil.nvl(session.getAttribute("ctrmf_bse_dt")));
		session.setAttribute("hngl_vh_no",					StringUtil.nvl(session.getAttribute("hngl_vh_no")));
		session.setAttribute("adc_rtrn_dvn",				StringUtil.nvl(session.getAttribute("adc_rtrn_dvn")));
		session.setAttribute("pdc_sr_dvn",					StringUtil.nvl(session.getAttribute("pdc_sr_dvn")));
		session.setAttribute("cnv_trv_dstc",				StringUtil.nvl(session.getAttribute("cnv_trv_dstc")));
		session.setAttribute("kid_trv_dstc",				StringUtil.nvl(session.getAttribute("kid_trv_dstc")));
		session.setAttribute("adc_rtrn_prm",				StringUtil.nvl(session.getAttribute("adc_rtrn_prm")));
		session.setAttribute("crd_scn_cncl_pss_yn",			StringUtil.nvl(session.getAttribute("crd_scn_cncl_pss_yn")));
		session.setAttribute("stlm_cdcp_nm",				StringUtil.nvl(session.getAttribute("stlm_cdcp_nm")));
		session.setAttribute("stlm_crd_no",					StringUtil.nvl(aes256Decrypt(jmvo.getSrch_rsl__stlm_crd_no())));
		session.setAttribute("bank_cd",						StringUtil.nvl(session.getAttribute("bank_cd")));
		session.setAttribute("acc_no",						StringUtil.nvl(session.getAttribute("acc_no")));
		session.setAttribute("exca_rtrn_dvn",				StringUtil.nvl(session.getAttribute("exca_rtrn_dvn")));
		session.setAttribute("errorCode",					StringUtil.nvl(session.getAttribute("errorCode")));
		session.setAttribute("trv_dstc_exp_exca_dvcd",		StringUtil.nvl(session.getAttribute("trv_dstc_exp_exca_dvcd")));
		
		return "/counter/carrider/tobe/otcm_self_ctf"; 
	}
	
	// 타사갱신계약 자동정산(계좌입력 선택)
	@RequestMapping(value="/otcm_jungsan1")
	public String otcm_jungsan1(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		HttpSession session = request.getSession();
		
		//갱신주행거리정산처리
		MMTI0321VO jmvo = new MMTI0321VO();
		
		jmvo.setSrch_cnd__pbox_no((String)session.getAttribute("p"));
		jmvo = mileageTobeService.getMMTI0321VO(jmvo);
		
		request.setAttribute("p", (String)session.getAttribute("p"));
		session.setAttribute("pbox_no", (String)session.getAttribute("p"));
		session.setAttribute("rtun_cd", StringUtil.nvl(jmvo.getSrch_rsl__rtun_cd()));
		session.setAttribute("rtun_msg", StringUtil.nvl(jmvo.getSrch_rsl__rtun_msg()));
		session.setAttribute("plhd_nm", StringUtil.nvl(jmvo.getSrch_rsl__plhd_nm()));
		session.setAttribute("plno", StringUtil.nvl(jmvo.getSrch_rsl__plno()));
		session.setAttribute("plan_no", StringUtil.nvl(jmvo.getSrch_rsl__plan_no()));
		session.setAttribute("ctrmf_bse_dt", StringUtil.nvl(jmvo.getSrch_rsl__ctrmf_bse_dt()));
		session.setAttribute("hngl_vh_no", StringUtil.nvl(jmvo.getSrch_rsl__hngl_vh_no()));
		session.setAttribute("adc_rtrn_dvcd", StringUtil.nvl(jmvo.getSrch_rsl__adc_rtrn_dvcd()));
		session.setAttribute("pdc_sr_dvn", StringUtil.nvl(jmvo.getSrch_rsl__pdc_sr_dvn()));
		session.setAttribute("cnv_trv_dstc", StringUtil.nvl(jmvo.getSrch_rsl__cnv_trv_dstc()));
		session.setAttribute("kid_trv_dstc", StringUtil.nvl(jmvo.getSrch_rsl__kid_trv_dstc()));
		session.setAttribute("adc_rtrn_prm", StringUtil.nvl(jmvo.getSrch_rsl__adc_rtrn_prm()));
		session.setAttribute("crd_scn_cncl_pss_yn", StringUtil.nvl(jmvo.getSrch_rsl__crd_scn_cncl_pss_yn()));
		session.setAttribute("stlm_cdcp_nm", StringUtil.nvl(jmvo.getSrch_rsl__stlm_cdcp_nm()));
		session.setAttribute("stlm_crd_no", StringUtil.nvl(aes256Decrypt(jmvo.getSrch_rsl__stlm_crd_no())));
		session.setAttribute("trv_dstc_exp_exca_dvcd", StringUtil.nvl(jmvo.getSrch_rsl__trv_dstc_exp_exca_dvcd()));
		request.setAttribute("jmvo", jmvo);
		
		String pbox_no = (String)session.getAttribute("p");
		String gubun = request.getParameter("gubun");
		request.setAttribute("gubun", gubun);
		
		if("3".equals(gubun)) {
			//경계주행거리정산처리
			MMTI0291VO mmti0291vo = new MMTI0291VO();
			mmti0291vo.setTrv_dstc_exca_mtt__pbox_no(pbox_no);
			mmti0291vo.setTrv_dstc_exca_mtt__plno(StringUtil.nvl(jmvo.getSrch_rsl__plno()));
			mmti0291vo.setTrv_dstc_exca_mtt__plan_no(StringUtil.nvl(jmvo.getSrch_rsl__plan_no()));
			mmti0291vo.setTrv_dstc_exca_mtt__adc_rtrn_dvn(StringUtil.nvl(jmvo.getSrch_rsl__adc_rtrn_dvcd()));
			mmti0291vo.setTrv_dstc_exca_mtt__adc_rtrn_prm(StringUtil.nvl(jmvo.getSrch_rsl__adc_rtrn_prm()));
			mmti0291vo.setTrv_dstc_exca_mtt__plhd_cust_nm(StringUtil.nvl(jmvo.getSrch_rsl__plhd_nm()));
			mmti0291vo.setTrv_dstc_exca_mtt__cnv_trv_dstc(StringUtil.nvl(jmvo.getSrch_rsl__cnv_trv_dstc())); //환산주행거리(임시로 최초주행거리 세팅)
			mmti0291vo.setTrv_dstc_exca_mtt__crd_scn_cncl_pss_yn(StringUtil.nvl(jmvo.getSrch_rsl__crd_scn_cncl_pss_yn())); //카드부분취소가능여부(1:카드부분취소가능)
			//추징환급구분 (1:추징, 2:환급, 3:미발생) 환급인 경우만 확정 처리함.
			if("2".equals(jmvo.getSrch_rsl__adc_rtrn_dvcd())) {
				mmti0291vo.setTrv_dstc_exca_mtt__exca_bz_proc_dvn("2"); //정산업무처리구분(1:설계, 2:확정)
				if("1".equals(jmvo.getSrch_rsl__crd_scn_cncl_pss_yn())) { //카드부분취소가능여부(1:카드부분취소가능)
					mmti0291vo.setTrv_dstc_exca_mtt__bank_cd("");
					mmti0291vo.setTrv_dstc_exca_mtt__acc_no("");
					mmti0291vo.setTrv_dstc_exca_mtt__exca_rtrn_dvn("3"); // 정산환급구분(1:계좌환급, 2:갱신계약활용, 3:카드) 확정인 경우만 필수 이외에는 null
				} else {
					// 키패드
					String account = "";
					try {
						account = TransKey.decode("account", request);
					}
					catch(Exception e) {
						logger.debug(e.getMessage());
						account = request.getParameter("acc_no");
					}
					logger.debug("account: " + account);
					mmti0291vo.setTrv_dstc_exca_mtt__bank_cd(request.getParameter("bank_cd"));
					mmti0291vo.setTrv_dstc_exca_mtt__acc_no(request.getParameter("acc_no"));
					mmti0291vo.setTrv_dstc_exca_mtt__exca_rtrn_dvn("1"); // 계좌환급
					mmti0291vo.setTrv_dstc_exca_mtt__scrn_proc_cd("01"); // 화면처리코드(01:확정까지 진행)
				}
			} else {
				mmti0291vo.setTrv_dstc_exca_mtt__exca_bz_proc_dvn("1");
//				mmti0291vo.setTrv_dstc_exca_mtt__plan_no("");
				mmti0291vo.setTrv_dstc_exca_mtt__exca_rtrn_dvn("");
			}
			
			mmti0291vo = mileageTobeService.getMMTI0291VO(mmti0291vo);
			
			request.setAttribute("mmti0291vo", mmti0291vo);
			session.setAttribute("bank_cd", StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__bank_cd()));
			session.setAttribute("acc_no", StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__acc_no()));
			session.setAttribute("exca_rtrn_dvn", StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__exca_rtrn_dvn()));
			session.setAttribute("trv_dstc_splc_exca_yn", StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn()));
			session.setAttribute("adc_rtrn_dvn", StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__adc_rtrn_dvn()));
			session.setAttribute("exca_bz_proc_dvn", StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__exca_bz_proc_dvn()));
			session.setAttribute("plan_no", StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__plan_no()));
			session.setAttribute("exca_rtrn_dvn", StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__exca_rtrn_dvn()));
			
			if(!StringUtil.isEmpty(request.getParameter("appSeq"))){
				session.setAttribute("appSeq", StringUtil.nvl(request.getParameter("appSeq")));
			}
			
			logger.info("###### otcm_jungsan1 테스트1 ######");
			logger.info("###### request ######");
			logger.info("###### p: " + (String)session.getAttribute("p"));
			logger.info("###### pbox_no: " + (String)session.getAttribute("p"));
			logger.info("###### plno: " + StringUtil.nvl(request.getParameter("plno")));
			logger.info("###### plan_no: " + StringUtil.nvl(request.getParameter("plan_no")));
			logger.info("###### rtun_cd: " + StringUtil.nvl(request.getParameter("rtun_cd")));
			logger.info("###### rtun_msg: " + StringUtil.nvl(request.getParameter("rtun_msg")));
			logger.info("###### plhd_nm: " + StringUtil.nvl(request.getParameter("plhd_nm")));
			logger.info("###### ctrmf_bse_dt: " + StringUtil.nvl(request.getParameter("ctrmf_bse_dt")));
			logger.info("###### hngl_vh_no: " + StringUtil.nvl(request.getParameter("hngl_vh_no")));
			logger.info("###### adc_rtrn_dvcd: " + StringUtil.nvl(request.getParameter("adc_rtrn_dvcd")));
			logger.info("###### pdc_sr_dvn: " + StringUtil.nvl(request.getParameter("pdc_sr_dvn")));
			logger.info("###### cnv_trv_dstc: " + StringUtil.nvl(request.getParameter("cnv_trv_dstc")));
			logger.info("###### kid_trv_dstc: " + StringUtil.nvl(request.getParameter("kid_trv_dstc")));
			logger.info("###### adc_rtrn_prm: " + StringUtil.nvl(request.getParameter("adc_rtrn_prm")));
			logger.info("###### crd_scn_cncl_pss_yn: " + StringUtil.nvl(request.getParameter("crd_scn_cncl_pss_yn")));
			logger.info("###### stlm_cdcp_nm: " + StringUtil.nvl(request.getParameter("stlm_cdcp_nm")));
			logger.info("###### stlm_crd_no: " + StringUtil.nvl(aes256Decrypt(jmvo.getSrch_rsl__stlm_crd_no())));
			logger.info("###### trv_dstc_exp_exca_dvcd: " + StringUtil.nvl(request.getParameter("trv_dstc_exp_exca_dvcd")));
			
			logger.info("###### otcm_jungsan1 테스트2 ######");
			logger.info("###### session ######");
			logger.info("###### p: " + (String)session.getAttribute("p"));
			logger.info("###### pbox_no: " + (String)session.getAttribute("p"));
			logger.info("###### plno: " + StringUtil.nvl((String)session.getAttribute("plno")));
			logger.info("###### plan_no: " + StringUtil.nvl((String)session.getAttribute("plan_no")));
			logger.info("###### rtun_cd: " + StringUtil.nvl((String)session.getAttribute("rtun_cd")));
			logger.info("###### rtun_msg: " + StringUtil.nvl((String)session.getAttribute("rtun_msg")));
			logger.info("###### plhd_nm: " + String.valueOf(session.getAttribute("plhd_nm")));
			logger.info("###### ctrmf_bse_dt: " + StringUtil.nvl((String)session.getAttribute("ctrmf_bse_dt")));
			logger.info("###### hngl_vh_no: " + StringUtil.nvl((String)session.getAttribute("hngl_vh_no")));
			logger.info("###### adc_rtrn_dvcd: " + StringUtil.nvl((String)session.getAttribute("adc_rtrn_dvcd")));
			logger.info("###### pdc_sr_dvn: " + StringUtil.nvl((String)session.getAttribute("pdc_sr_dvn")));
			logger.info("###### cnv_trv_dstc: " + StringUtil.nvl((String)session.getAttribute("cnv_trv_dstc")));
			logger.info("###### kid_trv_dstc: " + StringUtil.nvl((String)session.getAttribute("kid_trv_dstc")));
			logger.info("###### adc_rtrn_prm: " + StringUtil.nvl((String)session.getAttribute("adc_rtrn_prm")));
			logger.info("###### crd_scn_cncl_pss_yn: " + StringUtil.nvl((String)session.getAttribute("crd_scn_cncl_pss_yn")));
			logger.info("###### stlm_cdcp_nm: " + StringUtil.nvl((String)session.getAttribute("stlm_cdcp_nm")));
			logger.info("###### stlm_crd_no: " + StringUtil.nvl(aes256Decrypt(jmvo.getSrch_rsl__stlm_crd_no())));
			logger.info("###### trv_dstc_exp_exca_dvcd: " + StringUtil.nvl((String)session.getAttribute("trv_dstc_exp_exca_dvcd")));
			
			logger.info("###### otcm_jungsan1 mmti0291vo ######");
			logger.info("###### bank_cd: " + StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__bank_cd()));
			logger.info("###### acc_no: " + StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__acc_no()));
			logger.info("###### exca_rtrn_dvn: " + StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__exca_rtrn_dvn()));
			logger.info("###### exca_bz_proc_dvn: " + StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__exca_bz_proc_dvn()));
			logger.info("###### plan_no: " + StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__plan_no()));
			logger.info("###### exca_rtrn_dvn: " + StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__exca_rtrn_dvn()));
			
			request.setAttribute("p",							(String)session.getAttribute("p"));
			request.setAttribute("pbox_no", 					(String)session.getAttribute("p"));
			request.setAttribute("jmvo",						jmvo);
			request.setAttribute("plno",						StringUtil.nvl(request.getParameter("plno")));
			request.setAttribute("plan_no",						StringUtil.nvl(request.getParameter("plan_no")));
			request.setAttribute("rtun_cd",						StringUtil.nvl(request.getParameter("rtun_cd")));
			request.setAttribute("rtun_msg",					StringUtil.nvl(request.getParameter("rtun_msg")));
			request.setAttribute("plhd_nm",						StringUtil.nvl(request.getParameter("plhd_nm")));
			request.setAttribute("ctrmf_bse_dt",				StringUtil.nvl(request.getParameter("ctrmf_bse_dt")));
			request.setAttribute("hngl_vh_no",					StringUtil.nvl(request.getParameter("hngl_vh_no")));
			request.setAttribute("adc_rtrn_dvn",				StringUtil.nvl(request.getParameter("adc_rtrn_dvn")));
			request.setAttribute("pdc_sr_dvn",					StringUtil.nvl(request.getParameter("pdc_sr_dvn")));
			request.setAttribute("cnv_trv_dstc",				StringUtil.nvl(request.getParameter("cnv_trv_dstc")));
			request.setAttribute("kid_trv_dstc",				StringUtil.nvl(request.getParameter("kid_trv_dstc")));
			request.setAttribute("adc_rtrn_prm",				StringUtil.nvl(request.getParameter("adc_rtrn_prm")));
			request.setAttribute("crd_scn_cncl_pss_yn",			StringUtil.nvl(request.getParameter("crd_scn_cncl_pss_yn")));
			request.setAttribute("stlm_cdcp_nm",				StringUtil.nvl(request.getParameter("stlm_cdcp_nm")));
			request.setAttribute("stlm_crd_no",					StringUtil.nvl(aes256Decrypt(jmvo.getSrch_rsl__stlm_crd_no())));
			request.setAttribute("bank_cd",						StringUtil.nvl(request.getParameter("bank_cd")));
			request.setAttribute("acc_no",						StringUtil.nvl(request.getParameter("acc_no")));
			request.setAttribute("exca_rtrn_dvn",				StringUtil.nvl(request.getParameter("exca_rtrn_dvn")));
			request.setAttribute("trv_dstc_exp_exca_dvcd",		StringUtil.nvl(request.getParameter("trv_dstc_exp_exca_dvcd")));
			request.setAttribute("exca_bz_proc_dvn",			StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__exca_bz_proc_dvn()));
			request.setAttribute("plan_no",						StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__plan_no()));
			request.setAttribute("exca_rtrn_dvn",				StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__exca_rtrn_dvn()));
			request.setAttribute("errorCode",					StringUtil.nvl(request.getParameter("errorCode")));
			
			session.setAttribute("p",							(String)session.getAttribute("p"));
			session.setAttribute("pbox_no", 					(String)session.getAttribute("p"));
			session.setAttribute("jmvo",						jmvo);
			session.setAttribute("plno",						StringUtil.nvl(session.getAttribute("plno")));
			session.setAttribute("plan_no",						StringUtil.nvl(session.getAttribute("plan_no")));
			session.setAttribute("rtun_cd",						StringUtil.nvl(session.getAttribute("rtun_cd")));
			session.setAttribute("rtun_msg",					StringUtil.nvl(session.getAttribute("rtun_msg")));
			session.setAttribute("plhd_nm",						StringUtil.nvl(session.getAttribute("plhd_nm")));
			session.setAttribute("ctrmf_bse_dt",				StringUtil.nvl(session.getAttribute("ctrmf_bse_dt")));
			session.setAttribute("hngl_vh_no",					StringUtil.nvl(session.getAttribute("hngl_vh_no")));
			session.setAttribute("adc_rtrn_dvn",				StringUtil.nvl(session.getAttribute("adc_rtrn_dvn")));
			session.setAttribute("pdc_sr_dvn",					StringUtil.nvl(session.getAttribute("pdc_sr_dvn")));
			session.setAttribute("cnv_trv_dstc",				StringUtil.nvl(session.getAttribute("cnv_trv_dstc")));
			session.setAttribute("kid_trv_dstc",				StringUtil.nvl(session.getAttribute("kid_trv_dstc")));
			session.setAttribute("adc_rtrn_prm",				StringUtil.nvl(session.getAttribute("adc_rtrn_prm")));
			session.setAttribute("crd_scn_cncl_pss_yn",			StringUtil.nvl(session.getAttribute("crd_scn_cncl_pss_yn")));
			session.setAttribute("stlm_cdcp_nm",				StringUtil.nvl(session.getAttribute("stlm_cdcp_nm")));
			session.setAttribute("stlm_crd_no",					StringUtil.nvl(aes256Decrypt(jmvo.getSrch_rsl__stlm_crd_no())));
			session.setAttribute("bank_cd",						StringUtil.nvl(session.getAttribute("bank_cd")));
			session.setAttribute("acc_no",						StringUtil.nvl(session.getAttribute("acc_no")));
			session.setAttribute("exca_rtrn_dvn",				StringUtil.nvl(session.getAttribute("exca_rtrn_dvn")));
			session.setAttribute("trv_dstc_exp_exca_dvcd",		StringUtil.nvl(session.getAttribute("trv_dstc_exp_exca_dvcd")));
			session.setAttribute("exca_bz_proc_dvn",			StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__exca_bz_proc_dvn()));
			session.setAttribute("plan_no",						StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__plan_no()));
			session.setAttribute("exca_rtrn_dvn",				StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__exca_rtrn_dvn()));
			session.setAttribute("errorCode",					StringUtil.nvl(session.getAttribute("errorCode")));	
		}
		return "/counter/carrider/tobe/otcm_jungsan1";
	}
	
	@RequestMapping(value="/otcm_jungsan2_end")
	public String otcm_jungsan1_end(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		String gubun = request.getParameter("gubun");
		request.setAttribute("gubun", gubun);
		
		return "/counter/carrider/tobe/otcm_jungsan2_end"; 
	}
	
	// 타사갱신계약 자동정산(카드부분취소 선택)
	@RequestMapping(value="/otcm_jungsan2")
	public String otcm_jungsan2(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		String view = "";
		HttpSession session = request.getSession();
		
		//갱신주행거리정산처리
		MMTI0321VO jmvo = new MMTI0321VO();
		
		jmvo.setSrch_cnd__pbox_no((String)session.getAttribute("p"));
		jmvo = mileageTobeService.getMMTI0321VO(jmvo);
		
		request.setAttribute("p", (String)session.getAttribute("p"));
		session.setAttribute("pbox_no", (String)session.getAttribute("p"));
		session.setAttribute("rtun_cd", StringUtil.nvl(jmvo.getSrch_rsl__rtun_cd()));
		session.setAttribute("rtun_msg", StringUtil.nvl(jmvo.getSrch_rsl__rtun_msg()));
		session.setAttribute("plhd_nm", StringUtil.nvl(jmvo.getSrch_rsl__plhd_nm()));
		session.setAttribute("plno", StringUtil.nvl(jmvo.getSrch_rsl__plno()));
		session.setAttribute("plan_no", StringUtil.nvl(jmvo.getSrch_rsl__plan_no()));
		session.setAttribute("ctrmf_bse_dt", StringUtil.nvl(jmvo.getSrch_rsl__ctrmf_bse_dt()));
		session.setAttribute("hngl_vh_no", StringUtil.nvl(jmvo.getSrch_rsl__hngl_vh_no()));
		session.setAttribute("adc_rtrn_dvcd", StringUtil.nvl(jmvo.getSrch_rsl__adc_rtrn_dvcd()));
		session.setAttribute("pdc_sr_dvn", StringUtil.nvl(jmvo.getSrch_rsl__pdc_sr_dvn()));
		session.setAttribute("cnv_trv_dstc", StringUtil.nvl(jmvo.getSrch_rsl__cnv_trv_dstc()));
		session.setAttribute("kid_trv_dstc", StringUtil.nvl(jmvo.getSrch_rsl__kid_trv_dstc()));
		session.setAttribute("adc_rtrn_prm", StringUtil.nvl(jmvo.getSrch_rsl__adc_rtrn_prm()));
		session.setAttribute("crd_scn_cncl_pss_yn", StringUtil.nvl(jmvo.getSrch_rsl__crd_scn_cncl_pss_yn()));
		session.setAttribute("stlm_cdcp_nm", StringUtil.nvl(jmvo.getSrch_rsl__stlm_cdcp_nm()));
		session.setAttribute("stlm_crd_no", StringUtil.nvl(aes256Decrypt(jmvo.getSrch_rsl__stlm_crd_no())));
		session.setAttribute("trv_dstc_exp_exca_dvcd", StringUtil.nvl(jmvo.getSrch_rsl__trv_dstc_exp_exca_dvcd()));
		request.setAttribute("jmvo", jmvo);
		
		String pbox_no = (String)session.getAttribute("p");
		String gubun = request.getParameter("gubun");
		request.setAttribute("gubun", gubun);
		
		System.out.println("##### MMTI0321 Z_RESP_CD = " + StringUtil.nvl(jmvo.getZ_resp_cd()));
		System.out.println("##### MMTI0321 Z_RESP_MSG = " + StringUtil.nvl(jmvo.getZ_resp_msg()));
		String errCd0321 = StringUtil.nvl(jmvo.getZ_resp_cd());
		String errMsg0321 = StringUtil.nvl(jmvo.getZ_resp_msg());
		
		if("3".equals(gubun)) {
			if("ZH001".equals(errCd0321)){
				//경계주행거리정산처리
				MMTI0291VO mmti0291vo = new MMTI0291VO();
				mmti0291vo.setTrv_dstc_exca_mtt__pbox_no(pbox_no);
				mmti0291vo.setTrv_dstc_exca_mtt__plno(StringUtil.nvl(jmvo.getSrch_rsl__plno()));
				mmti0291vo.setTrv_dstc_exca_mtt__plan_no(StringUtil.nvl(jmvo.getSrch_rsl__plan_no()));
				mmti0291vo.setTrv_dstc_exca_mtt__adc_rtrn_dvn(StringUtil.nvl(jmvo.getSrch_rsl__adc_rtrn_dvcd()));
				mmti0291vo.setTrv_dstc_exca_mtt__adc_rtrn_prm(StringUtil.nvl(jmvo.getSrch_rsl__adc_rtrn_prm()));
				mmti0291vo.setTrv_dstc_exca_mtt__plhd_cust_nm(StringUtil.nvl(jmvo.getSrch_rsl__plhd_nm()));
				mmti0291vo.setTrv_dstc_exca_mtt__cnv_trv_dstc(StringUtil.nvl(jmvo.getSrch_rsl__cnv_trv_dstc())); //환산주행거리(임시로 최초주행거리 세팅)
				mmti0291vo.setTrv_dstc_exca_mtt__crd_scn_cncl_pss_yn(StringUtil.nvl(jmvo.getSrch_rsl__crd_scn_cncl_pss_yn())); //카드부분취소가능여부(1:카드부분취소가능)
				//추징환급구분 (1:추징, 2:환급, 3:미발생) 환급인 경우만 확정 처리함.
				if("2".equals(jmvo.getSrch_rsl__adc_rtrn_dvcd())) {
					mmti0291vo.setTrv_dstc_exca_mtt__exca_bz_proc_dvn("2"); //정산업무처리구분(1:설계, 2:확정)
					if("1".equals(jmvo.getSrch_rsl__crd_scn_cncl_pss_yn())) { //카드부분취소가능여부(1:카드부분취소가능)
						mmti0291vo.setTrv_dstc_exca_mtt__crd_scn_cncl_pss_yn(jmvo.getSrch_rsl__crd_scn_cncl_pss_yn());
						mmti0291vo.setTrv_dstc_exca_mtt__stlm_cdcp_nm(jmvo.getSrch_rsl__stlm_cdcp_nm());
						mmti0291vo.setTrv_dstc_exca_mtt__stlm_crd_no(aes256Decrypt(jmvo.getSrch_rsl__stlm_crd_no()));
						mmti0291vo.setTrv_dstc_exca_mtt__exca_rtrn_dvn("3"); //정산환급구분(1:계좌환급, 2:갱신계약활용, 3:카드) 확정인 경우만 필수 이외에는 null
						mmti0291vo.setTrv_dstc_exca_mtt__scrn_proc_cd("01"); // 화면처리코드(01:확정까지 진행)
					} else {
						mmti0291vo.setTrv_dstc_exca_mtt__stlm_cdcp_nm("");
						mmti0291vo.setTrv_dstc_exca_mtt__stlm_crd_no("");
						mmti0291vo.setTrv_dstc_exca_mtt__exca_rtrn_dvn("1"); // 갱신계약활용
					}
				} else {
					mmti0291vo.setTrv_dstc_exca_mtt__exca_bz_proc_dvn("1");
					mmti0291vo.setTrv_dstc_exca_mtt__exca_rtrn_dvn("");
				}
				
				mmti0291vo = mileageTobeService.getMMTI0291VO(mmti0291vo);
				
				System.out.println("##### MMTI0291 Z_RESP_CD " + mmti0291vo.getZ_resp_cd());
				System.out.println("##### MMTI0291 Z_RESP_MSG " + mmti0291vo.getZ_resp_msg());
				
				request.setAttribute("mmti0291vo", mmti0291vo);
				session.setAttribute("scrn_proc_cd", StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__scrn_proc_cd()));
				session.setAttribute("stlm_cdcp_nm", StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__stlm_cdcp_nm()));
				session.setAttribute("stlm_crd_no", StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__stlm_crd_no()));
				session.setAttribute("exca_rtrn_dvn", StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__exca_rtrn_dvn()));
				session.setAttribute("trv_dstc_splc_exca_yn", StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn()));
				session.setAttribute("adc_rtrn_dvn", StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__adc_rtrn_dvn()));
				session.setAttribute("exca_bz_proc_dvn", StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__exca_bz_proc_dvn()));
				session.setAttribute("plan_no", StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__plan_no()));
				session.setAttribute("exca_rtrn_dvn", StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__exca_rtrn_dvn()));
				
				if(!StringUtil.isEmpty(request.getParameter("appSeq"))){
					session.setAttribute("appSeq", StringUtil.nvl(request.getParameter("appSeq")));
				}
				
				logger.info("###### otcm_jungsan2 테스트1 ######");
				logger.info("###### request ######");
				logger.info("###### p: " + (String)session.getAttribute("p"));
				logger.info("###### pbox_no: " + (String)session.getAttribute("p"));
				logger.info("###### plno: " + StringUtil.nvl(request.getParameter("plno")));
				logger.info("###### plan_no: " + StringUtil.nvl(request.getParameter("plan_no")));
				logger.info("###### rtun_cd: " + StringUtil.nvl(request.getParameter("rtun_cd")));
				logger.info("###### rtun_msg: " + StringUtil.nvl(request.getParameter("rtun_msg")));
				logger.info("###### plhd_nm: " + StringUtil.nvl(request.getParameter("plhd_nm")));
				logger.info("###### ctrmf_bse_dt: " + StringUtil.nvl(request.getParameter("ctrmf_bse_dt")));
				logger.info("###### hngl_vh_no: " + StringUtil.nvl(request.getParameter("hngl_vh_no")));
				logger.info("###### adc_rtrn_dvcd: " + StringUtil.nvl(request.getParameter("adc_rtrn_dvcd")));
				logger.info("###### pdc_sr_dvn: " + StringUtil.nvl(request.getParameter("pdc_sr_dvn")));
				logger.info("###### cnv_trv_dstc: " + StringUtil.nvl(request.getParameter("cnv_trv_dstc")));
				logger.info("###### kid_trv_dstc: " + StringUtil.nvl(request.getParameter("kid_trv_dstc")));
				logger.info("###### adc_rtrn_prm: " + StringUtil.nvl(request.getParameter("adc_rtrn_prm")));
				logger.info("###### crd_scn_cncl_pss_yn: " + StringUtil.nvl(request.getParameter("crd_scn_cncl_pss_yn")));
				logger.info("###### stlm_cdcp_nm: " + StringUtil.nvl(request.getParameter("stlm_cdcp_nm")));
				logger.info("###### stlm_crd_no: " + StringUtil.nvl(aes256Decrypt(jmvo.getSrch_rsl__stlm_crd_no())));
				logger.info("###### scrn_proc_cd: " + StringUtil.nvl(request.getParameter("scrn_proc_cd")));
				logger.info("###### trv_dstc_exp_exca_dvcd: " + StringUtil.nvl(request.getParameter("trv_dstc_exp_exca_dvcd")));
				
				logger.info("###### otcm_jungsan2 테스트2 ######");
				logger.info("###### session ######");
				logger.info("###### p: " + (String)session.getAttribute("p"));
				logger.info("###### pbox_no: " + (String)session.getAttribute("p"));
				logger.info("###### plno: " + StringUtil.nvl((String)session.getAttribute("plno")));
				logger.info("###### plan_no: " + StringUtil.nvl((String)session.getAttribute("plan_no")));
				logger.info("###### rtun_cd: " + StringUtil.nvl((String)session.getAttribute("rtun_cd")));
				logger.info("###### rtun_msg: " + StringUtil.nvl((String)session.getAttribute("rtun_msg")));
				logger.info("###### plhd_nm: " + String.valueOf(session.getAttribute("plhd_nm")));
				logger.info("###### ctrmf_bse_dt: " + StringUtil.nvl((String)session.getAttribute("ctrmf_bse_dt")));
				logger.info("###### hngl_vh_no: " + StringUtil.nvl((String)session.getAttribute("hngl_vh_no")));
				logger.info("###### adc_rtrn_dvcd: " + StringUtil.nvl((String)session.getAttribute("adc_rtrn_dvcd")));
				logger.info("###### pdc_sr_dvn: " + StringUtil.nvl((String)session.getAttribute("pdc_sr_dvn")));
				logger.info("###### cnv_trv_dstc: " + StringUtil.nvl((String)session.getAttribute("cnv_trv_dstc")));
				logger.info("###### kid_trv_dstc: " + StringUtil.nvl((String)session.getAttribute("kid_trv_dstc")));
				logger.info("###### adc_rtrn_prm: " + StringUtil.nvl((String)session.getAttribute("adc_rtrn_prm")));
				logger.info("###### crd_scn_cncl_pss_yn: " + StringUtil.nvl((String)session.getAttribute("crd_scn_cncl_pss_yn")));
				logger.info("###### stlm_cdcp_nm: " + StringUtil.nvl((String)session.getAttribute("stlm_cdcp_nm")));
				logger.info("###### stlm_crd_no: " + StringUtil.nvl(aes256Decrypt(jmvo.getSrch_rsl__stlm_crd_no())));
				logger.info("###### scrn_proc_cd: " + StringUtil.nvl((String)session.getAttribute("scrn_proc_cd")));
				logger.info("###### trv_dstc_exp_exca_dvcd: " + StringUtil.nvl((String)session.getAttribute("trv_dstc_exp_exca_dvcd")));
				
				logger.info("###### otcm_jungsan2 mmti0291vo ######");
				logger.info("###### stlm_cdcp_nm: " + StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__stlm_cdcp_nm()));
				logger.info("###### stlm_crd_no: " + StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__stlm_crd_no()));
				logger.info("###### exca_rtrn_dvn: " + StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__exca_rtrn_dvn()));
				logger.info("###### exca_bz_proc_dvn: " + StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__exca_bz_proc_dvn()));
				logger.info("###### plan_no: " + StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__plan_no()));
				logger.info("###### exca_rtrn_dvn: " + StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__exca_rtrn_dvn()));
				logger.info("###### scrn_proc_cd: " + StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__scrn_proc_cd()));
				
				request.setAttribute("p",							(String)session.getAttribute("p"));
				request.setAttribute("pbox_no",						(String)session.getAttribute("p"));
				request.setAttribute("jmvo",						jmvo);
				request.setAttribute("plno",						StringUtil.nvl(request.getParameter("plno")));
				request.setAttribute("plan_no",						StringUtil.nvl(request.getParameter("plan_no")));
				request.setAttribute("rtun_cd",						StringUtil.nvl(request.getParameter("rtun_cd")));
				request.setAttribute("rtun_msg",					StringUtil.nvl(request.getParameter("rtun_msg")));
				request.setAttribute("plhd_nm",						StringUtil.nvl(request.getParameter("plhd_nm")));
				request.setAttribute("ctrmf_bse_dt",				StringUtil.nvl(request.getParameter("ctrmf_bse_dt")));
				request.setAttribute("hngl_vh_no",					StringUtil.nvl(request.getParameter("hngl_vh_no")));
				request.setAttribute("adc_rtrn_dvn",				StringUtil.nvl(request.getParameter("adc_rtrn_dvn")));
				request.setAttribute("pdc_sr_dvn",					StringUtil.nvl(request.getParameter("pdc_sr_dvn")));
				request.setAttribute("cnv_trv_dstc",				StringUtil.nvl(request.getParameter("cnv_trv_dstc")));
				request.setAttribute("kid_trv_dstc",				StringUtil.nvl(request.getParameter("kid_trv_dstc")));
				request.setAttribute("adc_rtrn_prm",				StringUtil.nvl(request.getParameter("adc_rtrn_prm")));
				request.setAttribute("crd_scn_cncl_pss_yn",			StringUtil.nvl(request.getParameter("crd_scn_cncl_pss_yn")));
				request.setAttribute("stlm_cdcp_nm",				StringUtil.nvl(request.getParameter("stlm_cdcp_nm")));
				request.setAttribute("trv_dstc_exp_exca_dvcd",		StringUtil.nvl(request.getParameter("trv_dstc_exp_exca_dvcd")));
				request.setAttribute("stlm_crd_no",					StringUtil.nvl(aes256Decrypt(jmvo.getSrch_rsl__stlm_crd_no())));
				request.setAttribute("bank_cd",						StringUtil.nvl(request.getParameter("bank_cd")));
				request.setAttribute("acc_no",						StringUtil.nvl(request.getParameter("acc_no")));
				request.setAttribute("exca_rtrn_dvn",				StringUtil.nvl(request.getParameter("exca_rtrn_dvn")));
				request.setAttribute("exca_bz_proc_dvn",			StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__exca_bz_proc_dvn()));
				request.setAttribute("exca_rtrn_dvn",				StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__exca_rtrn_dvn()));
				request.setAttribute("errorCode",					StringUtil.nvl(request.getParameter("errorCode")));
				
				session.setAttribute("p",							(String)session.getAttribute("p"));
				session.setAttribute("pbox_no",						(String)session.getAttribute("p"));
				session.setAttribute("jmvo",						jmvo);
				session.setAttribute("plno",						StringUtil.nvl(session.getAttribute("plno")));
				session.setAttribute("plan_no",						StringUtil.nvl(session.getAttribute("plan_no")));
				session.setAttribute("rtun_cd",						StringUtil.nvl(session.getAttribute("rtun_cd")));
				session.setAttribute("rtun_msg",					StringUtil.nvl(session.getAttribute("rtun_msg")));
				session.setAttribute("plhd_nm",						StringUtil.nvl(session.getAttribute("plhd_nm")));
				session.setAttribute("ctrmf_bse_dt",				StringUtil.nvl(session.getAttribute("ctrmf_bse_dt")));
				session.setAttribute("hngl_vh_no",					StringUtil.nvl(session.getAttribute("hngl_vh_no")));
				session.setAttribute("adc_rtrn_dvn",				StringUtil.nvl(session.getAttribute("adc_rtrn_dvn")));
				session.setAttribute("pdc_sr_dvn",					StringUtil.nvl(session.getAttribute("pdc_sr_dvn")));
				session.setAttribute("cnv_trv_dstc",				StringUtil.nvl(session.getAttribute("cnv_trv_dstc")));
				session.setAttribute("kid_trv_dstc",				StringUtil.nvl(session.getAttribute("kid_trv_dstc")));
				session.setAttribute("adc_rtrn_prm",				StringUtil.nvl(session.getAttribute("adc_rtrn_prm")));
				session.setAttribute("crd_scn_cncl_pss_yn",			StringUtil.nvl(session.getAttribute("crd_scn_cncl_pss_yn")));
				session.setAttribute("stlm_cdcp_nm",				StringUtil.nvl(session.getAttribute("stlm_cdcp_nm")));
				session.setAttribute("stlm_crd_no",					StringUtil.nvl(aes256Decrypt(jmvo.getSrch_rsl__stlm_crd_no())));
				session.setAttribute("trv_dstc_exp_exca_dvcd",		StringUtil.nvl(session.getAttribute("trv_dstc_exp_exca_dvcd")));
				session.setAttribute("bank_cd",						StringUtil.nvl(session.getAttribute("bank_cd")));
				session.setAttribute("acc_no",						StringUtil.nvl(session.getAttribute("acc_no")));
				session.setAttribute("exca_rtrn_dvn",				StringUtil.nvl(session.getAttribute("exca_rtrn_dvn")));
				session.setAttribute("exca_bz_proc_dvn",			StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__exca_bz_proc_dvn()));
				session.setAttribute("exca_rtrn_dvn",				StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__exca_rtrn_dvn()));
				session.setAttribute("errorCode",					StringUtil.nvl(session.getAttribute("errorCode")));	
				view = "/counter/carrider/tobe/otcm_jungsan2_end";
			} 
		} else {
				view = "/counter/carrider/tobe/otcm_jungsan2"; 
		}
		return view;
	}
	
	@RequestMapping(value="/mlFileUpload")
	public @ResponseBody Map<String, String> mlFileUpload(MultipartHttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		Map<String, String> map = new HashMap<String, String>();
		String yyyymmdd = DateUtil.getDate("yyyymmdd");
		
		MMTI0213VO jmvo = new MMTI0213VO();
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("p")));
		jmvo = mileageTobeService.getMMTI0213VO(jmvo);
		
		String exifDate1 = StringUtil.nvl(request.getParameter("exifDate1"));
		// 사진실제촬영일자
		String phgp_rl_ptgr_dt = StringUtil.nvl(request.getParameter("phgp_rl_ptgr_dt"));
		// 사진첨부방식코드
		String phgp_apdx_way_cd = StringUtil.nvl(request.getParameter("phgp_apdx_way_cd"));
		
		String phgp_ptgr_dt = "";
	
		boolean empty = false;
		if(exifDate1.indexOf(",gallery") > -1) {
			exifDate1 = exifDate1.substring(0, exifDate1.indexOf(",gallery"));
			if(StringUtil.isEmpty(exifDate1)) {
				exifDate1 = DateUtil.getDate();
				empty = true;
			}
			else if(Integer.parseInt(exifDate1) > Integer.parseInt(DateUtil.getDate())) {
				map.put("errorCode", "f");
				return map;
			}
		}

		phgp_ptgr_dt = empty ? "" : exifDate1;
		
		if(exifDate1.indexOf(",gallery") > -1) {
			exifDate1 = exifDate1.substring(0, exifDate1.indexOf(",gallery"));
		}

		if("08".equals(jmvo.getProc_dvn()) || "09".equals(jmvo.getProc_dvn())) {
			ArrayList<File> files = mileageTobeService.uploadToWAS(request, jmvo.getSms_ts_bvan());
			
			String aut_cgnt_trv_dstc_rsl_cd = "";	// 자동인식주행거리결과코드
			String aut_cgnt_vh_no_rsl_cd = "";		// 자동인식차량번호결과코드
			String aut_cgnt_trv_dstc = "";			// 자동인식주행거리
			String aut_cgnt_vh_no = "";				// 자동인식차량번호
			
			String aut_cgnt_trv_dstc_1 = "";		// 자동인식주행거리1
			String aut_cgnt_trv_dstc_2 = "";		// 자동인식주행거리2
			String aut_cgnt_trv_dstc_3 = "";		// 자동인식주행거리3
			
			boolean flag1 = false;
			if(files.size() > 0) {
				FTPUtil ftp = null;
				// [200617]
				FileInputStream in = null;
				FileInputStream fis = null;
				FileOutputStream out = null;
				
				try {
					if("1".equals(jmvo.getAut_cgnt_nn_apcn_yn())) { // OCR서버 문제있으면...
						aut_cgnt_trv_dstc_rsl_cd = "03";
						aut_cgnt_vh_no_rsl_cd = "03";
					}
					else {
						String propsPath = this.getClass().getResource("").getPath();
						propsPath = propsPath.substring(0, propsPath.indexOf("/classes/")) + "/config/ocr_ftp.properties";
						Properties p = new Properties();
						// [200617]
						in = new FileInputStream(propsPath);
						p.load(in);
						in.close();
						// [200617]
						in = null;
						
						String password = p.getProperty("password");
						String decPassword = aes256Decrypt(password);
						if(password.equals(decPassword) || StringUtil.isEmpty(decPassword)) {
							decPassword = password;
							String encPassword = aes256Encrypt(password);
							logger.debug("encPassword: " + encPassword);
							// [200617]
							out = new FileOutputStream(propsPath);
							p.setProperty("password", encPassword);
							p.store(out, "");
							out.close();
							// [200617]
							out = null;
						}
						
						ftp = new FTPUtil(p.getProperty("ip"), p.getProperty("user"), decPassword, Integer.parseInt(p.getProperty("port")));
						
						int working = 0;
						for(int i = 1; i <= 3; i++) {
							String[] ls = ftp.ls("/RECOG_JOB" + i + "/" + yyyymmdd);
							for(int j = 0; j < ls.length; j++) {
								if(".".equals(ls[j]) || "..".equals(ls[j])) continue;
								working++;
							}
						}
		
						if(working <= 6) {
							String filename1 = "";
							
							filename1 = ftp.uploadToOCR("/RECOG/" + yyyymmdd, files.get(0), "--D");

							logger.debug("filename1: " + filename1);

							
							logger.debug("--- 1초 대기 ---");
							Thread.sleep(1000);
							int retryNum = 7;
							for(int retry = 0; retry < retryNum; retry++) {
								String[] ls = ftp.ls("/RECOG_RESULT/" + yyyymmdd);
			
								for(int i = 0; i < ls.length; i++) {
									logger.debug(ls[i]);
									if(!flag1 && ls[i].equals(filename1)) {
										flag1 = true;
									}
									
									if(flag1) break;
								}
			
								if((flag1) || retry == retryNum - 1) {
									break;
								}
								else {
									logger.debug("--- 0.6초 대기 ---");
									Thread.sleep(600);
								}
							}
							
							logger.debug("flag1: " + flag1);
							
							if(flag1) {
								// [210219]
								if(filename1 != null || !"".equals(filename1)){
									filename1 = filename1.replaceAll("/", "");
									filename1 = filename1.replaceAll("\\\\", "");
									filename1 = filename1.replaceAll("./", "");
									filename1 = filename1.replaceAll("../", "");
									filename1 = filename1.replaceAll("&", "");
								}
								
								String path = files.get(0).getParent() + File.separator + filename1;
								ftp.downloadFromOCR("/RECOG_RESULT/" + yyyymmdd, filename1, path);
								logger.debug("path: " + path);
								
								// [210219]
								File f = new File(files.get(0).getParent() + File.separator + filename1);
								// File f = new File(path);
			
								if(f.exists()) {
									Properties props = new Properties();
									// [210219]
									fis = new FileInputStream(files.get(0).getParent() + File.separator + filename1);
									props.load(fis);
									fis.close();
									// [200617]
									fis = null;
									
									if(!StringUtil.isEmpty(props.getProperty("ODO")) && !StringUtil.isEmpty(props.getProperty("RE_CODE"))) {
										aut_cgnt_trv_dstc = props.getProperty("ODO");
										aut_cgnt_trv_dstc_rsl_cd = "1".equals(props.getProperty("RE_CODE")) || "2".equals(props.getProperty("RE_CODE")) ? "01" : "02";
										
										aut_cgnt_trv_dstc_1 = props.getProperty("ODO");
										
										if(!StringUtil.isEmpty(props.getProperty("ODO2"))) {
											aut_cgnt_trv_dstc_2 = props.getProperty("ODO2");
										}
										
										if(!StringUtil.isEmpty(props.getProperty("ODO3"))) {
											aut_cgnt_trv_dstc_3 = props.getProperty("ODO3");
										}
									}
									
					            	if(f.delete()) {
										logger.debug("삭제: " + path);
									}
								}
							}
							else {
								aut_cgnt_trv_dstc_rsl_cd = "02";
							}						
						}
						else {
							aut_cgnt_trv_dstc_rsl_cd = "02";
							if(!"1".equals(jmvo.getCm_yn())) {
								aut_cgnt_vh_no_rsl_cd = "02";
							}
						}
					}
				}
				catch(Exception e) {
					logger.debug(e.getMessage());
					aut_cgnt_trv_dstc_rsl_cd = "02";
					if(!"1".equals(jmvo.getCm_yn())) {
						aut_cgnt_vh_no_rsl_cd = "02";
					}
				}
				finally {
					if(ftp != null) ftp.disconnect();
					
					// [200617]
					try{
			    	  	if(in != null){
			    	  		in.close();
			    	  	}
				      }catch(IOException ee){
				    	  System.err.println("[MileageTobeController.mlFileUpload()] IOException 1");
				      }
					try{
			    	  	if(out != null){
			    	  		out.close();
			    	  	}
				      }catch(IOException ee){
				    	  System.err.println("[MileageTobeController.mlFileUpload()] IOException 2");
				      }
					try{
			    	  	if(fis != null){
			    	  		fis.close();
			    	  	}
				      }catch(IOException ee){
				    	  System.err.println("[MileageTobeController.mlFileUpload()] IOException 3");
				      }
				}
			}
			
			MMTI0259VO jmvo1 = new MMTI0259VO();
			MBTR01001VO mbtr01001vo = new MBTR01001VO();
			jmvo1.setPbox_use_yn("1");
			jmvo1.setPbox_no(jmvo.getSms_ts_bvan());
			jmvo1.setPhgp_cnfm_dt(DateUtil.getDate());
			jmvo1.setPhgp_ptgr_dt(phgp_ptgr_dt);
			jmvo1.setPhgp_strg_yn("1");
			if("1".equals(jmvo.getAut_cgnt_nn_apcn_yn())) {
				jmvo1.setPbox_chr_nm(request.getParameter("mileage1"));
			}
			
			if("1".equals(jmvo.getPbox_no_dvcd())) {
				if(!"1".equals(jmvo.getCm_yn())) {
					jmvo1.setInpt_trv_dstc(request.getParameter("mileage1"));
					if(!StringUtil.isEmpty(aut_cgnt_vh_no)) {
						jmvo1.setAut_cgnt_vh_no(aut_cgnt_vh_no);
					}
					
					if(!StringUtil.isEmpty(aut_cgnt_vh_no_rsl_cd)) {
						jmvo1.setAut_cgnt_vh_no_rsl_cd(aut_cgnt_vh_no_rsl_cd);
					}
					else {
						jmvo1.setAut_cgnt_vh_no_rsl_cd("02");
					}
				}
					
				if(!StringUtil.isEmpty(aut_cgnt_trv_dstc)) {
					jmvo1.setAut_cgnt_trv_dstc(aut_cgnt_trv_dstc);
				}
				
				if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_rsl_cd)) {
					jmvo1.setAut_cgnt_trv_dstc_rsl_cd(aut_cgnt_trv_dstc_rsl_cd);
				}
				else {
					jmvo1.setAut_cgnt_trv_dstc_rsl_cd("02");
				}
				
				if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_1)) {
					jmvo1.setAut_cgnt_trv_dstc_1(aut_cgnt_trv_dstc_1);
				}
				
				if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_2)) {
					jmvo1.setAut_cgnt_trv_dstc_2(aut_cgnt_trv_dstc_2);
				}
				
				if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_3)) {
					jmvo1.setAut_cgnt_trv_dstc_3(aut_cgnt_trv_dstc_3);
				}
			}
			
			// 200708
			jmvo1.setPhgp_rl_ptgr_dt(phgp_rl_ptgr_dt);
			jmvo1.setPhgp_apdx_way_cd(phgp_apdx_way_cd);
			
			jmvo1 = mileageTobeService.getMMTI0259VO(jmvo1);
			
			if("0".equals(jmvo1.getErrorCode()) && !"1".equals(jmvo.getCm_yn())) {
				jmvo1.setExp_exca_plan_proc_dvn("1");
				jmvo1.setPlno(jmvo.getPlno());
			
				// 200708
				jmvo1.setPhgp_rl_ptgr_dt(phgp_rl_ptgr_dt);
				jmvo1.setPhgp_apdx_way_cd(phgp_apdx_way_cd);
				
				jmvo1 = mileageTobeService.getMMTI0259VO(jmvo1);
				
				if("05".equals(jmvo1.getExp_exca_plan_rsl_cd())) {
					logger.info("#### controller 05 ####");
					mbtr01001vo = mileageTobeService.regInfoToEdmsForMobileWeb(request, jmvo.getSms_ts_bvan(), mbtr01001vo);
				}
				else if(!StringUtil.isEmpty(jmvo1.getPlno()) && !StringUtil.isEmpty(jmvo1.getExp_exca_plan_no())) {
					logger.info("#### controller plno and exp_exca_plan_no not null ####");
					mbtr01001vo = mileageTobeService.regInfoToEdmsForMobileWeb2(request, jmvo.getNtft_srv_rc_ormm_cd(), files, jmvo1.getPlno() + "," + jmvo1.getExp_exca_plan_no(), mbtr01001vo);
				}
				else {
					logger.info("#### controller else ####");
					mbtr01001vo = mileageTobeService.regInfoToEdmsForMobileWeb2(request, jmvo.getNtft_srv_rc_ormm_cd(), files, jmvo1.getPlno(), mbtr01001vo);
				}
			}
			else {
				if("1".equals(jmvo.getCm_yn())) {
					logger.info("#### controller cm_yn=1 ####");
					mbtr01001vo = mileageTobeService.regInfoToEdmsForMobileWeb(request, jmvo.getSms_ts_bvan(), mbtr01001vo);
				}
				else {
					logger.info("#### controller cm_yn null ####");
					mbtr01001vo = mileageTobeService.regInfoToEdmsForMobileWeb2(request, jmvo.getNtft_srv_rc_ormm_cd(), files, jmvo1.getPlno(), mbtr01001vo);
				}
			}
			
			int insertRow = 0;
			// VO SET
			mbtr01001vo.setPboxNo(jmvo.getSms_ts_bvan());
			mbtr01001vo.setApdxFlRutNm("");
			mbtr01001vo.setFrstIpmnEmpno("82101685");
			mbtr01001vo.setFnalAmdrEmpno("82101685");
			if(mbtr01001vo.getProcRslMsgCn() != null){
				mbtr01001vo.getProcRslMsgCn();
				logger.info("#### procRslMsgCn = " + mbtr01001vo.getProcRslMsgCn());
			}
			
			logger.info("#### insertTest before ####");
			insertRow = mileageTobeService.insertTest(mbtr01001vo);
			logger.info("#### insertTest after ####");
			
			if(insertRow < 1){
				logger.info("#### 사서함번호: " + StringUtil.nvl(mbtr01001vo.getPboxNo()) + "####");
				logger.info("#### insert 결과: Fail ####");
			}else{
				logger.info("#### insert 결과: Success ####");
			}
	
			for(int i = 0; i < files.size(); i++) {
				File f = files.get(i);
				String fname = f.getName();
				f.delete();
				logger.debug(fname + " 삭제");
			}		
			
			map.put("errorCode",				jmvo1.getErrorCode());
			map.put("exp_exca_plan_rsl_cd",		jmvo1.getExp_exca_plan_rsl_cd());
			map.put("adc_rtrn_dvn",				jmvo1.getAdc_rtrn_dvn());
			map.put("adc_rtrn_prm",				jmvo1.getAdc_rtrn_prm());
			map.put("plno",						jmvo1.getPlno());
			map.put("exp_exca_plan_no",			jmvo1.getExp_exca_plan_no());
			map.put("exp_exca_plan_bse_dd",		jmvo1.getExp_exca_plan_bse_dd());
			map.put("aut_cgnt_vh_no",			jmvo1.getAut_cgnt_vh_no());
			map.put("aut_cgnt_vh_no_rsl_cd",	jmvo1.getAut_cgnt_vh_no_rsl_cd());
			map.put("aut_cgnt_trv_dstc",		jmvo1.getAut_cgnt_trv_dstc());
			map.put("aut_cgnt_trv_dstc_rsl_cd",	jmvo1.getAut_cgnt_trv_dstc_rsl_cd());
			map.put("exp_exca_plan_proc_dvn",	jmvo1.getExp_exca_plan_proc_dvn());
			map.put("cnv_trv_dstc",				jmvo1.getCnv_trv_dstc());
			
			// 200708
			map.put("phgp_rl_ptgr_dt",			phgp_rl_ptgr_dt);
			map.put("phgp_apdx_way_cd", 		phgp_apdx_way_cd);
			
		}
		else {
			logger.info("#### controller 만기정산 아님 ####"); //차량대체(변경)인 경우
			MBTR01001VO mbtr01001vo = new MBTR01001VO();
			mbtr01001vo = mileageTobeService.regInfoToEdmsForMobileWeb(request, jmvo.getSms_ts_bvan(), mbtr01001vo);
			
			int insertRow = 0;
			// VO SET
			mbtr01001vo.setPboxNo(jmvo.getSms_ts_bvan());
			mbtr01001vo.setApdxFlRutNm("");
			mbtr01001vo.setFrstIpmnEmpno("82101685");
			mbtr01001vo.setFnalAmdrEmpno("82101685");
			if(mbtr01001vo.getProcRslMsgCn() != null){
				mbtr01001vo.getProcRslMsgCn();
				logger.info("#### procRslMsgCn = " + mbtr01001vo.getProcRslMsgCn());
			}
			
			insertRow = mileageTobeService.insertTest(mbtr01001vo);
			if(insertRow < 1){
				logger.info("#### 사서함번호: " + StringUtil.nvl(mbtr01001vo.getPboxNo()) + "####");
				logger.info("#### insert 결과: Fail ####");
			}else{
				logger.info("#### insert 결과: Success ####");
			}
			
			MMTI0259VO jmvo1 = new MMTI0259VO();
			jmvo1.setPbox_use_yn("1");
			jmvo1.setPbox_no(jmvo.getSms_ts_bvan());
			jmvo1.setPhgp_cnfm_dt(DateUtil.getDate());
			jmvo1.setPhgp_ptgr_dt(phgp_ptgr_dt);
			jmvo1.setPhgp_strg_yn("1");
			
			// 200708
			jmvo1.setPhgp_rl_ptgr_dt(phgp_rl_ptgr_dt);
			jmvo1.setPhgp_apdx_way_cd(phgp_apdx_way_cd);
			
			if("1".equals(jmvo.getPbox_no_dvcd()) && !"1".equals(jmvo.getCm_yn())) {
				if("03".equals(jmvo.getProc_dvn())) {
					jmvo1.setPbox_chr_nm(request.getParameter("mileage1") + "/" + request.getParameter("mileage2"));
				}
				else {
					jmvo1.setPbox_chr_nm(request.getParameter("mileage1"));
				}
			}
			jmvo1 = mileageTobeService.getMMTI0259VO(jmvo1);
			
			map.put("errorCode", jmvo1.getErrorCode());
		}
			
		return map;
	}
	
	
	//aiocr용 OCR
	@RequestMapping(value="/aiocrFileUpload")
	public @ResponseBody Map<String, String> aiocrFileUpload(MultipartHttpServletRequest request,HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		Map<String, String> map = new HashMap<String, String>();
		String yyyymmdd = DateUtil.getDate("yyyymmdd");
		
		String phgp_rl_ptgr_dt			= StringUtil.nvl(request.getParameter("phgp_rl_ptgr_dt"));			// 사진실제촬영일자
		String phgp_apdx_way_cd			= StringUtil.nvl(request.getParameter("phgp_apdx_way_cd"));			// 사진첨부방식코드
		String phgp_ptgr_dt = "";
		
		MMTI0213VO jmvo = new MMTI0213VO();
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("p")));
		jmvo = mileageTobeService.getMMTI0213VO(jmvo);
		
		String exifDate1 = StringUtil.nvl(request.getParameter("exifDate1"));
		
		boolean empty = false;
		if(exifDate1.indexOf(",gallery") > -1) {
			exifDate1 = exifDate1.substring(0, exifDate1.indexOf(",gallery"));
			if(StringUtil.isEmpty(exifDate1)) {
				exifDate1 = DateUtil.getDate();
				empty = true;
			}
			else if(Integer.parseInt(exifDate1) > Integer.parseInt(DateUtil.getDate())) {
				map.put("errorCode", "f");
				return map;
			}
		}
		phgp_ptgr_dt = empty ? "" : exifDate1;

		if(exifDate1.indexOf(",gallery") > -1) {
			exifDate1 = exifDate1.substring(0, exifDate1.indexOf(",gallery"));
		}
		
		if("08".equals(jmvo.getProc_dvn()) || "09".equals(jmvo.getProc_dvn())) {
			ArrayList<File> files = mileageTobeService.aiocrUploadToWAS(request, jmvo.getSms_ts_bvan());
	//		ArrayList<File> files = mileageTobeService.uploadToWAS(request, jmvo.getSms_ts_bvan());
			
			String aut_cgnt_trv_dstc_rsl_cd = "";	// 자동인식주행거리결과코드
			String aut_cgnt_vh_no_rsl_cd = "";		// 자동인식차량번호결과코드
			String aut_cgnt_trv_dstc = "";			// 자동인식주행거리
			String aut_cgnt_vh_no = "";				// 자동인식차량번호
			
			String aut_cgnt_trv_dstc_1 = "";		// 자동인식주행거리1
			String aut_cgnt_trv_dstc_2 = "";		// 자동인식주행거리2
			String aut_cgnt_trv_dstc_3 = "";		// 자동인식주행거리3
			
			String a_i_o_c_r_rqst_dsky_val	= "";	// aiocr요청구분키값
			String a_i_o_c_r_resultCode 	= "";	// aiocr요청결과코드값
			String resultValue 				= "";	// 주행거리값1
			String dtcn_cgnt_rt 			= "";	// 검출인식률1
			String cgnt_cgnt_rt 			= "";	// 인식인식률1
			String resultValue2 			= "";	// 주행거리값2
			String dtcn_cgnt_rt2 			= "";	// 검출인식률2
			String cgnt_cgnt_rt2 			= "";	// 인식인식률2
			String resultValue3 			= "";	// 주행거리값3
			String dtcn_cgnt_rt3 			= "";	// 검출인식률3
			String cgnt_cgnt_rt3 			= "";	// 인식인식률3
			String RE_CODE 					= "";
			
			HashMap<String, String> resultMap = null;
			
			
			boolean flag1 = false;
			if(files.size() > 0) {
				FTPUtil ftp = null;
				// [200617]
				FileInputStream in = null;
				FileInputStream fis = null;
				FileOutputStream out = null;
				
				
				HttpResponse httpResp = null;
				HttpEntity respEntity = null;
				
				resultMap = new HashMap<String, String>();
				
				try {
					if("1".equals(jmvo.getAut_cgnt_nn_apcn_yn())) { // OCR서버 문제있으면...
						aut_cgnt_trv_dstc_rsl_cd = "03";
						aut_cgnt_vh_no_rsl_cd = "03";
					}
					else {
						String propsPath = this.getClass().getResource("").getPath();
						propsPath = propsPath.substring(0, propsPath.indexOf("/classes/")) + "/config/aiocr_ftp.properties";
	//					propsPath = propsPath.substring(0, propsPath.indexOf("/classes/")) + "/config/ocr_ftp.properties";
						
						String aiocrURL = AIOCR_SERVER_PATH;
						CloseableHttpClient httpClient = HttpClients.createDefault();
						HttpPost httpPost = new HttpPost(aiocrURL);
						
						HttpEntity httpEntity = MultipartEntityBuilder.create()
								.addTextBody("templateName", "car.drivingdistance.workflow")
								.addTextBody("senderName", "SMZ")
								.addBinaryBody("Files", new File(files.get(0).toString()), ContentType.MULTIPART_FORM_DATA, files.get(0).toString()).build();
						
						httpPost.setEntity(httpEntity);
						
						CloseableHttpResponse response1 = httpClient.execute(httpPost);
						
						logger.debug("========== start ==========");
						logger.debug("Status Code : " + response1.getStatusLine().getStatusCode());
						logger.debug("========== end ==========");
						
						// json param setting start
						respEntity = response1.getEntity();
						
						String jsonResp = EntityUtils.toString(respEntity);
						logger.debug("AI OCR uploadAiOCR("+files.get(0).toString()+") 응답 json : " + jsonResp);
						
						JSONParser jsonParser = new JSONParser();
						JSONObject jsonObj = (JSONObject) jsonParser.parse(jsonResp);
						JSONArray jsonArray = (JSONArray) jsonObj.get("results");
						
						a_i_o_c_r_rqst_dsky_val	= (String) jsonObj.get("resultItemKey");	// aiocr요청구분키값
						a_i_o_c_r_resultCode = (String) jsonObj.get("resultCode"); // aiocr요청결과코드값(01:정상, 11~33:오류)
						
						if(response1.getStatusLine().getStatusCode() == 200){
							
							logger.debug("[거울]jsonArray : " + jsonArray.get(0) + "jsonArray size : " + jsonArray.size());
							
							if(jsonResp != null){
//								String ocrResultCode = (String) jsonObj.get("resultCode");
								if(!StringUtil.isEmpty(a_i_o_c_r_resultCode)){
									if("01".equals(a_i_o_c_r_resultCode)){
										if(jsonArray.size() > 0) {
											resultMap.put("RE_CODE", "2");
											aut_cgnt_trv_dstc_rsl_cd = "01";
											for(int s = 0; s < jsonArray.size(); s++){
												if(s == 0) {
													JSONObject jsonObject = (JSONObject) jsonArray.get(0);
													logger.debug("new resultValue = " + (String)jsonObject.get("resultValue"));
													logger.debug("new detectionConfidence = " + (String)jsonObject.get("detectionConfidence"));
													logger.debug("new recognitionConfidence = " + (String)jsonObject.get("recognitionConfidence"));
													
													resultMap.put("resultValue", (String)jsonObject.get("resultValue"));
													resultMap.put("detectionConfidence", (String)jsonObject.get("detectionConfidence"));
													resultMap.put("recognitionConfidence", (String)jsonObject.get("recognitionConfidence"));
												} else if(s == 1) {
													JSONObject jsonObject = (JSONObject) jsonArray.get(1);
													logger.debug("new resultValue2 = " + (String)jsonObject.get("resultValue"));
													logger.debug("new detectionConfidence2 = " + (String)jsonObject.get("detectionConfidence"));
													logger.debug("new recognitionConfidence2 = " + (String)jsonObject.get("recognitionConfidence"));
													
													resultMap.put("resultValue2", (String)jsonObject.get("resultValue"));
													resultMap.put("detectionConfidence2", (String)jsonObject.get("detectionConfidence"));
													resultMap.put("recognitionConfidence2", (String)jsonObject.get("recognitionConfidence"));
												} else {
													JSONObject jsonObject = (JSONObject) jsonArray.get(2);
													logger.debug("new resultValue3 = " + (String)jsonObject.get("resultValue"));
													logger.debug("new detectionConfidence3 = " + (String)jsonObject.get("detectionConfidence"));
													logger.debug("new recognitionConfidence3 = " + (String)jsonObject.get("recognitionConfidence"));
													
													resultMap.put("resultValue3", (String)jsonObject.get("resultValue"));
													resultMap.put("detectionConfidence3", (String)jsonObject.get("detectionConfidence"));
													resultMap.put("recognitionConfidence3", (String)jsonObject.get("recognitionConfidence"));
												}
											
												resultValue				= StringUtil.nvl((String)resultMap.get("resultValue"));			// 주행거리 인식값1
												dtcn_cgnt_rt 			= StringUtil.nvl((String)resultMap.get("detectionConfidence"));	// 검출인식률1
												cgnt_cgnt_rt 			= StringUtil.nvl((String)resultMap.get("recognitionConfidence"));	// 인식인식률1
												resultValue2			= StringUtil.nvl((String)resultMap.get("resultValue2"));			// 주행거리 인식값1
												dtcn_cgnt_rt2 			= StringUtil.nvl((String)resultMap.get("detectionConfidence2"));	// 검출인식률1
												cgnt_cgnt_rt2 			= StringUtil.nvl((String)resultMap.get("recognitionConfidence2"));	// 인식인식률1
												resultValue3			= StringUtil.nvl((String)resultMap.get("resultValue3"));			// 주행거리 인식값1
												dtcn_cgnt_rt3 			= StringUtil.nvl((String)resultMap.get("detectionConfidence3"));	// 검출인식률1
												cgnt_cgnt_rt3 			= StringUtil.nvl((String)resultMap.get("recognitionConfidence3"));	// 인식인식률1
											}
											logger.debug("[거울]resultValue = " + resultValue);
											logger.debug("[거울]dtcn_cgnt_rt = " + dtcn_cgnt_rt);
											logger.debug("[거울]cgnt_cgnt_rt = " + cgnt_cgnt_rt);
											logger.debug("[거울]resultValue2 = " + resultValue2);
											logger.debug("[거울]dtcn_cgnt_rt2 = " + dtcn_cgnt_rt2);
											logger.debug("[거울]cgnt_cgnt_rt2 = " + cgnt_cgnt_rt2);
											logger.debug("[거울]resultValue3 = " + resultValue3);
											logger.debug("[거울]dtcn_cgnt_rt3 = " + dtcn_cgnt_rt3);
											logger.debug("[거울]cgnt_cgnt_rt3 = " + cgnt_cgnt_rt3);
										}
									} else {
										resultMap.put("RE_CODE", "1");
										aut_cgnt_trv_dstc_rsl_cd = a_i_o_c_r_resultCode;
										logger.debug("[거울]aut_cgnt_trv_dstc_rsl_cd = " + aut_cgnt_trv_dstc_rsl_cd);
									}
								} else {
									aut_cgnt_trv_dstc_rsl_cd = "02"; //솔루션에서 보내주는 결과코드값이 없는 경우에 02로 세팅
								}
							}
						} else {
							aut_cgnt_trv_dstc_rsl_cd = a_i_o_c_r_resultCode;
							logger.error("AI OCR uploadAiOCR("+files.get(0).toString()+","+files.size()+") 시 Error 발생 : " + respEntity);
				                throw new Exception("AI OCR 실패 : " + files.get(0).toString() + "/ responseCode :" + response1.getStatusLine().getStatusCode() + "/ responseMsg :" + EntityUtils.toString(respEntity));
						}
						// json param setting end
						httpClient.close();
						// aiocr 서버 통신 end
					}
				}
				catch(Exception e) {
					logger.debug(e.getMessage());
//					aut_cgnt_trv_dstc_rsl_cd = "02";
					aut_cgnt_trv_dstc_rsl_cd = a_i_o_c_r_resultCode;
					if(!"1".equals(jmvo.getCm_yn())) {
						aut_cgnt_vh_no_rsl_cd = "02";
					}
				}
				finally {
					if(ftp != null) ftp.disconnect();
					
					// [200617]
					try{
			    	  	if(in != null){
			    	  		in.close();
			    	  	}
				      }catch(IOException ee){
				    	  System.err.println("[MileageTobeController.aiocrFileUpload()] IOException 1");
				      }
					try{
			    	  	if(out != null){
			    	  		out.close();
			    	  	}
				      }catch(IOException ee){
				    	  System.err.println("[MileageTobeController.aiocrFileUpload()] IOException 2");
				      }
					try{
			    	  	if(fis != null){
			    	  		fis.close();
			    	  	}
				      }catch(IOException ee){
				    	  System.err.println("[MileageTobeController.aiocrFileUpload()] IOException 3");
				      }
				}
			}
			logger.debug("a_i_o_c_r_rqst_dsky_val = " + a_i_o_c_r_rqst_dsky_val);
			logger.debug("dtcn_cgnt_rt = " + dtcn_cgnt_rt);
			logger.debug("cgnt_cgnt_rt = " + cgnt_cgnt_rt);
			
			MMTI0259VO jmvo1 = new MMTI0259VO();
			jmvo1.setPbox_use_yn("1");
			jmvo1.setPbox_no(jmvo.getSms_ts_bvan());
			jmvo1.setPhgp_cnfm_dt(DateUtil.getDate());
			jmvo1.setPhgp_ptgr_dt(phgp_ptgr_dt);
			jmvo1.setPhgp_strg_yn("1");
			if("1".equals(jmvo.getAut_cgnt_nn_apcn_yn())) {
				jmvo1.setPbox_chr_nm(request.getParameter("mileage1"));
			}
			
			if("1".equals(jmvo.getPbox_no_dvcd())) {
				if(!"1".equals(jmvo.getCm_yn())) {
					jmvo1.setInpt_trv_dstc(request.getParameter("mileage1"));
					if(!StringUtil.isEmpty(aut_cgnt_vh_no)) {
						jmvo1.setAut_cgnt_vh_no(aut_cgnt_vh_no);
					}
					
					if(!StringUtil.isEmpty(aut_cgnt_vh_no_rsl_cd)) {
						jmvo1.setAut_cgnt_vh_no_rsl_cd(aut_cgnt_vh_no_rsl_cd);
					}
					else {
						jmvo1.setAut_cgnt_vh_no_rsl_cd("02");
					}
				}
					
				if(!StringUtil.isEmpty(aut_cgnt_trv_dstc)) {
					jmvo1.setAut_cgnt_trv_dstc(aut_cgnt_trv_dstc);
				}
				
				if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_rsl_cd)) {
					jmvo1.setAut_cgnt_trv_dstc_rsl_cd(aut_cgnt_trv_dstc_rsl_cd);
				}
				else {
					jmvo1.setAut_cgnt_trv_dstc_rsl_cd("02");
				}
				
				if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_1)) {
					jmvo1.setAut_cgnt_trv_dstc_1(aut_cgnt_trv_dstc_1);
				}
				
				if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_2)) {
					jmvo1.setAut_cgnt_trv_dstc_2(aut_cgnt_trv_dstc_2);
				}
				
				if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_3)) {
					jmvo1.setAut_cgnt_trv_dstc_3(aut_cgnt_trv_dstc_3);
				}
			}
			
			
			// 200708
			jmvo1.setPhgp_rl_ptgr_dt(phgp_rl_ptgr_dt);
			jmvo1.setPhgp_apdx_way_cd(phgp_apdx_way_cd);
			jmvo1.setA_i_o_c_r_rqst_dsky_val(a_i_o_c_r_rqst_dsky_val);
			jmvo1.setDtcn_cgnt_rt(dtcn_cgnt_rt);
			jmvo1.setCgnt_cgnt_rt(cgnt_cgnt_rt);
			jmvo1.setAut_cgnt_trv_dstc(resultValue);
			jmvo1.setAut_cgnt_trv_dstc_1(resultValue);
			jmvo1.setAut_cgnt_trv_dstc_2(resultValue2);
			jmvo1.setAut_cgnt_trv_dstc_3(resultValue3);
			
			jmvo1 = mileageTobeService.getMMTI0259VO(jmvo1);
			
			if("0".equals(jmvo1.getErrorCode()) && !"1".equals(jmvo.getCm_yn())) {
				jmvo1.setExp_exca_plan_proc_dvn("1");
				jmvo1.setPlno(jmvo.getPlno());
				
				// 200708
				jmvo1.setPhgp_rl_ptgr_dt(phgp_rl_ptgr_dt);
				jmvo1.setPhgp_apdx_way_cd(phgp_apdx_way_cd);
				
				jmvo1 = mileageTobeService.getMMTI0259VO(jmvo1);
				
				if("05".equals(jmvo1.getExp_exca_plan_rsl_cd())) {
					mileageTobeService.aiocrRegInfoToEdmsForMobileWeb(request, jmvo.getSms_ts_bvan());
				}
				else if(!StringUtil.isEmpty(jmvo1.getPlno()) && !StringUtil.isEmpty(jmvo1.getExp_exca_plan_no())) {
					mileageTobeService.regInfoToEdmsForMobileWeb2(request, jmvo.getNtft_srv_rc_ormm_cd(), files, jmvo1.getPlno() + "," + jmvo1.getExp_exca_plan_no());
				}
				else {
					mileageTobeService.regInfoToEdmsForMobileWeb2(request, jmvo.getNtft_srv_rc_ormm_cd(), files, jmvo1.getPlno());
				}
			}
			else {
				if("1".equals(jmvo.getCm_yn())) {
					mileageTobeService.aiocrRegInfoToEdmsForMobileWeb(request, jmvo.getSms_ts_bvan());
				}
				else {
					mileageTobeService.regInfoToEdmsForMobileWeb2(request, jmvo.getNtft_srv_rc_ormm_cd(), files, jmvo1.getPlno());
				}
			}
	
			for(int i = 0; i < files.size(); i++) {
				File f = files.get(i);
				String fname = f.getName();
				f.delete();
				logger.debug(fname + " 삭제");
			}

			map.put("errorCode",				jmvo1.getErrorCode());
			map.put("exp_exca_plan_rsl_cd",		jmvo1.getExp_exca_plan_rsl_cd());
			map.put("adc_rtrn_dvn",				jmvo1.getAdc_rtrn_dvn());
			map.put("adc_rtrn_prm",				jmvo1.getAdc_rtrn_prm());
			map.put("plno",						jmvo1.getPlno());
			map.put("exp_exca_plan_no",			jmvo1.getExp_exca_plan_no());
			map.put("exp_exca_plan_bse_dd",		jmvo1.getExp_exca_plan_bse_dd());
			map.put("aut_cgnt_vh_no",			jmvo1.getAut_cgnt_vh_no());
			map.put("aut_cgnt_vh_no_rsl_cd",	jmvo1.getAut_cgnt_vh_no_rsl_cd());
			map.put("aut_cgnt_trv_dstc",		jmvo1.getAut_cgnt_trv_dstc());
			map.put("aut_cgnt_trv_dstc_rsl_cd",	jmvo1.getAut_cgnt_trv_dstc_rsl_cd());
			map.put("exp_exca_plan_proc_dvn",	jmvo1.getExp_exca_plan_proc_dvn());
			map.put("cnv_trv_dstc",				jmvo1.getCnv_trv_dstc());
			
			// 200708
			map.put("phgp_rl_ptgr_dt",			phgp_rl_ptgr_dt);
			map.put("phgp_apdx_way_cd", 		phgp_apdx_way_cd);
			
			map.put("aut_cgnt_trv_dstc_1",			resultValue);
			map.put("aut_cgnt_trv_dstc_2",			resultValue2);
			map.put("aut_cgnt_trv_dstc_3",			resultValue3);
			map.put("a_i_o_c_r_rqst_dsky_val", 		a_i_o_c_r_rqst_dsky_val);
			map.put("resultValue", 					resultValue);
			map.put("dtcn_cgnt_rt", 				dtcn_cgnt_rt);
			map.put("cgnt_cgnt_rt", 				cgnt_cgnt_rt);
			map.put("resultValue2", 				resultValue2);
			map.put("dtcn_cgnt_rt2", 				dtcn_cgnt_rt2);
			map.put("cgnt_cgnt_rt2", 				cgnt_cgnt_rt2);
			map.put("resultValue3", 				resultValue3);
			map.put("dtcn_cgnt_rt3", 				dtcn_cgnt_rt3);
			map.put("cgnt_cgnt_rt3", 				cgnt_cgnt_rt3);
		}
			
		else {
			mileageTobeService.aiocrRegInfoToEdmsForMobileWeb(request, jmvo.getSms_ts_bvan());
			
			MMTI0259VO jmvo1 = new MMTI0259VO();
			jmvo1.setPbox_use_yn("1");
			jmvo1.setPbox_no(jmvo.getSms_ts_bvan());
			jmvo1.setPhgp_cnfm_dt(DateUtil.getDate());
			jmvo1.setPhgp_ptgr_dt(phgp_ptgr_dt);
			jmvo1.setPhgp_strg_yn("1");
			
			// 200708
			jmvo1.setPhgp_rl_ptgr_dt(phgp_rl_ptgr_dt);
			jmvo1.setPhgp_apdx_way_cd(phgp_apdx_way_cd);
			
			if("1".equals(jmvo.getPbox_no_dvcd()) && !"1".equals(jmvo.getCm_yn())) {
				if("03".equals(jmvo.getProc_dvn())) {
					jmvo1.setPbox_chr_nm(request.getParameter("mileage1") + "/" + request.getParameter("mileage2"));
				}
				else {
					jmvo1.setPbox_chr_nm(request.getParameter("mileage1"));
				}
			}
			jmvo1 = mileageTobeService.getMMTI0259VO(jmvo1);
			
			map.put("errorCode", jmvo1.getErrorCode());
		}


		
			
		return map;
	}
	
	//aiocr용 OCR2
	@RequestMapping(value="/aiocrFileUploadOCR2")
	public @ResponseBody Map<String, String> aiocrFileUploadOCR2(MultipartHttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		Map<String, String> map = new HashMap<String, String>();

		String aut_cgnt_trv_dstc_rsl_cd	= StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc_rsl_cd"));	// 자동인식주행거리결과코드
		String aut_cgnt_vh_no_rsl_cd	= StringUtil.nvl(request.getParameter("aut_cgnt_vh_no_rsl_cd"));	// 자동인식차량번호결과코드
		String aut_cgnt_trv_dstc		= StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc"));		// 자동인식주행거리
		String aut_cgnt_vh_no			= StringUtil.nvl(request.getParameter("aut_cgnt_vh_no"));			// 자동인식차량번호
		
		String aut_cgnt_trv_dstc_1		= StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc_1"));		// 자동인식주행거리
		String aut_cgnt_trv_dstc_2		= StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc_2"));		// 자동인식주행거리
		String aut_cgnt_trv_dstc_3		= StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc_3"));		// 자동인식주행거리
		
		String a_i_o_c_r_rqst_dsky_val	= StringUtil.nvl(request.getParameter("a_i_o_c_r_rqst_dsky_val"));	// aiocr요청구분키값
		String resultValue 				= StringUtil.nvl(request.getParameter("resultValue"));				// 주행거리 인식값
		String dtcn_cgnt_rt 			= StringUtil.nvl(request.getParameter("dtcn_cgnt_rt"));				// 검출인식률
		String cgnt_cgnt_rt 			= StringUtil.nvl(request.getParameter("cgnt_cgnt_rt"));				// 인식인식률
		
		// 020708
		String phgp_rl_ptgr_dt			= StringUtil.nvl(request.getParameter("phgp_rl_ptgr_dt"));			// 사진실제촬영일자
		String phgp_apdx_way_cd			= StringUtil.nvl(request.getParameter("phgp_apdx_way_cd"));			// 사진첨부방식코드
		
		MMTI0213VO jmvo = new MMTI0213VO();
		MBTT02001VO mbtt02001vo = new MBTT02001VO();
		String scrnNm = "aiocrFileUploadOCR2";
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("p")));
		jmvo = mileageTobeService.getMMTI0213VO(jmvo);
		
		String exifDate1 = StringUtil.nvl(request.getParameter("exifDate1"));
		String phgp_ptgr_dt = "";
		
		boolean empty = false;
		if(exifDate1.indexOf(",gallery") > -1) {
			exifDate1 = exifDate1.substring(0, exifDate1.indexOf(",gallery"));
			if(StringUtil.isEmpty(exifDate1)) {
				exifDate1 = DateUtil.getDate();
				empty = true;
			}
			else if(Integer.parseInt(exifDate1) > Integer.parseInt(DateUtil.getDate())) {
				map.put("errorCode", "f");
				return map;
			}
		}

		phgp_ptgr_dt = empty ? "" : exifDate1;
		
		if(exifDate1.indexOf(",gallery") > -1) {
			exifDate1 = exifDate1.substring(0, exifDate1.indexOf(",gallery"));
		}
		
		HttpSession session = request.getSession();
		session.setAttribute("exifDate", exifDate1);

		ArrayList<File> files = mileageTobeService.aiocrUploadToWAS(request, jmvo.getSms_ts_bvan());
//		ArrayList<File> files = mileageTobeService.uploadToWAS(request, jmvo.getSms_ts_bvan());
		
		MMTI0259VO jmvo1 = new MMTI0259VO();
		jmvo1.setPbox_use_yn("1");
		jmvo1.setPbox_no(jmvo.getSms_ts_bvan());
		jmvo1.setPhgp_cnfm_dt(DateUtil.getDate());
		jmvo1.setPhgp_ptgr_dt(phgp_ptgr_dt);
		jmvo1.setPhgp_strg_yn("1");
		if("1".equals(jmvo.getAut_cgnt_nn_apcn_yn())) {
			jmvo1.setPbox_chr_nm(request.getParameter("mileage1"));
		}
		
		if("1".equals(jmvo.getPbox_no_dvcd())) {
			if(!"1".equals(jmvo.getCm_yn())) {
				jmvo1.setInpt_trv_dstc(request.getParameter("mileage1"));
				if(!StringUtil.isEmpty(aut_cgnt_vh_no)) {
					jmvo1.setAut_cgnt_vh_no(aut_cgnt_vh_no);
				}
				
				if(!StringUtil.isEmpty(aut_cgnt_vh_no_rsl_cd)) {
					jmvo1.setAut_cgnt_vh_no_rsl_cd(aut_cgnt_vh_no_rsl_cd);
				}
				else {
					jmvo1.setAut_cgnt_vh_no_rsl_cd("02");
				}
			}
				
			if(!StringUtil.isEmpty(aut_cgnt_trv_dstc)) {
				jmvo1.setAut_cgnt_trv_dstc(aut_cgnt_trv_dstc);
			}
			
			if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_rsl_cd)) {
				jmvo1.setAut_cgnt_trv_dstc_rsl_cd(aut_cgnt_trv_dstc_rsl_cd);
			}
			else {
				jmvo1.setAut_cgnt_trv_dstc_rsl_cd("02");
			}
			
			if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_1)) {
				jmvo1.setAut_cgnt_trv_dstc_1(aut_cgnt_trv_dstc_1);
			}
			
			if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_2)) {
				jmvo1.setAut_cgnt_trv_dstc_2(aut_cgnt_trv_dstc_2);
			}
			
			if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_3)) {
				jmvo1.setAut_cgnt_trv_dstc_3(aut_cgnt_trv_dstc_3);
			}
			
			if(!StringUtil.isEmpty(a_i_o_c_r_rqst_dsky_val)) {
				jmvo1.setA_i_o_c_r_rqst_dsky_val(a_i_o_c_r_rqst_dsky_val);
			}
			
			if(!StringUtil.isEmpty(dtcn_cgnt_rt)) {
				jmvo1.setDtcn_cgnt_rt(dtcn_cgnt_rt);
			}
			
			if(!StringUtil.isEmpty(cgnt_cgnt_rt)) {
				jmvo1.setCgnt_cgnt_rt(cgnt_cgnt_rt);
			}
		}
		
		// 200708
		jmvo1.setPhgp_rl_ptgr_dt(phgp_rl_ptgr_dt);
		jmvo1.setPhgp_apdx_way_cd(phgp_apdx_way_cd);
		
		jmvo1 = mileageTobeService.getMMTI0259VO(jmvo1);
		MBTR01001VO mbtr01001vo = new MBTR01001VO();
		
		if("0".equals(jmvo1.getErrorCode()) && !"1".equals(jmvo.getCm_yn())) {
			jmvo1.setExp_exca_plan_proc_dvn("1");
			jmvo1.setPlno(jmvo.getPlno());
			
			// 200708
			jmvo1.setPhgp_rl_ptgr_dt(phgp_rl_ptgr_dt);
			jmvo1.setPhgp_apdx_way_cd(phgp_apdx_way_cd);
			
			jmvo1 = mileageTobeService.getMMTI0259VO(jmvo1);
			
			if("08".equals(jmvo.getProc_dvn())) {
				mbtr01001vo = mileageTobeService.regInfoToEdmsForMobileWeb2(request, jmvo.getNtft_srv_rc_ormm_cd(), files, jmvo.getPlno() + "," + jmvo.getChng_plan_no(), mbtr01001vo);
			}
			else if(!StringUtil.isEmpty(jmvo1.getPlno()) && !StringUtil.isEmpty(jmvo1.getExp_exca_plan_no())) {
				mbtr01001vo = mileageTobeService.regInfoToEdmsForMobileWeb2(request, jmvo.getNtft_srv_rc_ormm_cd(), files, jmvo1.getPlno() + "," + jmvo1.getExp_exca_plan_no(), mbtr01001vo);
			}
			else if(!StringUtil.isEmpty(jmvo1.getPlno()) && StringUtil.isEmpty(jmvo1.getExp_exca_plan_no())) {
				mbtr01001vo = mileageTobeService.regInfoToEdmsForMobileWeb2(request, jmvo.getNtft_srv_rc_ormm_cd(), files, jmvo1.getPlno(), mbtr01001vo);
			}
		}
		else {
			if("1".equals(jmvo.getCm_yn())) {
				mbtr01001vo = mileageTobeService.aiocrRegInfoToEdmsForMobileWeb(request, jmvo.getSms_ts_bvan(), mbtr01001vo);
			}
			else {
				mbtr01001vo = mileageTobeService.regInfoToEdmsForMobileWeb2(request, jmvo.getNtft_srv_rc_ormm_cd(), files, jmvo1.getPlno(), mbtr01001vo);
			}
		}
		
		int insertRow = 0;
		
		// VO SET
		mbtr01001vo.setPboxNo(jmvo.getSms_ts_bvan());
		mbtr01001vo.setApdxFlRutNm("");
		mbtr01001vo.setFrstIpmnEmpno("82101685");
		mbtr01001vo.setFnalAmdrEmpno("82101685");
		
		if(mbtr01001vo.getProcRslMsgCn() != null){
			mbtr01001vo.getProcRslMsgCn();
			logger.info("#### procRslMsgCn = " + mbtr01001vo.getProcRslMsgCn());
		}
		
		try {
			insertRow = mileageTobeService.insertTest(mbtr01001vo);
			if(insertRow < 1){
				logger.info("#### 사서함번호: " + StringUtil.nvl(mbtr01001vo.getPboxNo()) + "####");
				logger.info("#### insert 결과: Fail ####");
			}else{
				logger.info("#### insert 결과: Success ####");
			}
		} catch (Exception e) {
			e.getMessage();
		}
		
		
		//MBTT02001 정산이력 적재(20220614)
		mbtt02001vo.setPboxNo(StringUtil.nvl(jmvo.getSms_ts_bvan()));
		mbtt02001vo.setTlgIdVal("MMTI0213");
		mbtt02001vo.setEsbTrscId(StringUtil.nvl(jmvo.getZ_trsc_id()));
		if("".equals(jmvo.getPlno()) || null == jmvo.getPlno()){
			mbtt02001vo.setPlno(" ");
		} else {
			mbtt02001vo.setPlno(StringUtil.nvl(jmvo.getPlno()));
		}
		if("".equals(request.getParameter("exp_exca_plan_no")) || null == request.getParameter("exp_exca_plan_no")){
			mbtt02001vo.setPlanNo(" ");
		} else {
			mbtt02001vo.setPlanNo(StringUtil.nvl(request.getParameter("exp_exca_plan_no")));
		}
		if("".equals(request.getParameter("rnw_plno")) || null == request.getParameter("rnw_plno")){
			mbtt02001vo.setRnwPlno(" ");
		} else {
			mbtt02001vo.setRnwPlno(StringUtil.nvl(request.getParameter("rnw_plno")));
		}
		if("".equals(jmvo.getPbox_no_dvcd()) || null == jmvo.getPbox_no_dvcd()){
			mbtt02001vo.setPboxNoDvcd(" ");
		} else {
			mbtt02001vo.setPboxNoDvcd(StringUtil.nvl(jmvo.getPbox_no_dvcd()));
		}
		if("".equals(jmvo.getProc_dvn()) || null == jmvo.getProc_dvn()){
			mbtt02001vo.setProcDvn(" ");
		} else {
			mbtt02001vo.setProcDvn(StringUtil.nvl(jmvo.getProc_dvn()));
		}
		if("".equals(request.getParameter("hdlr_empno")) || null == request.getParameter("hdlr_empno")){
			mbtt02001vo.setHdlrEmpno(" ");
		} else {
			mbtt02001vo.setHdlrEmpno(StringUtil.nvl(request.getParameter("hdlr_empno")));
		}
		if("".equals(request.getParameter("trv_dstc_exp_exca_dvcd")) || null == request.getParameter("trv_dstc_exp_exca_dvcd")){
			mbtt02001vo.setTrvDstcExpExcaDvcd(" ");
		} else {
			mbtt02001vo.setTrvDstcExpExcaDvcd(StringUtil.nvl(request.getParameter("trv_dstc_exp_exca_dvcd")));
		}
		if("".equals(jmvo.getTrv_dstc_chng_aply_dvn()) || null == jmvo.getTrv_dstc_chng_aply_dvn()){
			mbtt02001vo.setTrvDstcChngAplyDvn(" ");
		} else {
			mbtt02001vo.setTrvDstcChngAplyDvn(StringUtil.nvl(jmvo.getTrv_dstc_chng_aply_dvn()));
		}
		if("".equals(jmvo.getHdlr_fire_yn()) || null == jmvo.getHdlr_fire_yn()){
			mbtt02001vo.setHdlrFireYn(" ");
		} else {
			mbtt02001vo.setHdlrFireYn(StringUtil.nvl(jmvo.getHdlr_fire_yn()));
		}
		if("".equals(request.getParameter("mtcc_yn")) || null == request.getParameter("mtcc_yn")){
			mbtt02001vo.setMtccYn(" ");
		} else {
			mbtt02001vo.setMtccYn(StringUtil.nvl(request.getParameter("mtcc_yn")));
		}
		if("".equals(request.getParameter("aut_cgnt_trv_dstc")) || null == request.getParameter("aut_cgnt_trv_dstc")){
			mbtt02001vo.setAutCgntTrvDstc(0);
		} else {
			mbtt02001vo.setAutCgntTrvDstc(Double.parseDouble(request.getParameter("aut_cgnt_trv_dstc")));
		}
		if("".equals(request.getParameter("aut_cgnt_trv_dstc_rsl_cd")) || null == request.getParameter("aut_cgnt_trv_dstc_rsl_cd")){
			mbtt02001vo.setAutCgntTrvDstcRslCd(" ");
		} else {
			mbtt02001vo.setAutCgntTrvDstcRslCd(StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc_rsl_cd")));
		}
		if("".equals(request.getParameter("pdc_sr_dvn")) || null == request.getParameter("pdc_sr_dvn")){
			mbtt02001vo.setPdcSrDvn(" ");
		} else {
			mbtt02001vo.setPdcSrDvn(StringUtil.nvl(request.getParameter("pdc_sr_dvn")));
		}
		if("".equals(request.getParameter("adc_rtrn_prm")) || null == request.getParameter("adc_rtrn_prm")){
			mbtt02001vo.setAdcRtrnPrm(0);
		} else {
			mbtt02001vo.setAdcRtrnPrm(Double.parseDouble(request.getParameter("adc_rtrn_prm")));
		}
		if("".equals(jmvo1.getAut_cgnt_trv_dstc_rsl_cd()) || null == jmvo1.getAut_cgnt_trv_dstc_rsl_cd()){
			mbtt02001vo.setAutCgntTrvDstcRslCd(" ");
		} else {
			mbtt02001vo.setAutCgntTrvDstcRslCd(StringUtil.nvl(jmvo1.getAut_cgnt_trv_dstc_rsl_cd()));
		}
		if("".equals(request.getParameter("mileage1")) || null == request.getParameter("mileage1")){
			mbtt02001vo.setInptTrvDstc(0);
		} else {
			mbtt02001vo.setInptTrvDstc(Double.parseDouble(request.getParameter("mileage1")));
		}
		if("".equals(request.getParameter("cnv_trv_dstc")) || null == request.getParameter("cnv_trv_dstc")){
			mbtt02001vo.setCnvTrvDstc(0);
		} else {
			mbtt02001vo.setCnvTrvDstc(Double.parseDouble(request.getParameter("cnv_trv_dstc")));
		}
		if("".equals(request.getParameter("exp_exca_plan_rsl_cd")) || null == request.getParameter("exp_exca_plan_rsl_cd")){
			mbtt02001vo.setExpExcaPlanRslCd(" ");
		} else {
			mbtt02001vo.setExpExcaPlanRslCd(StringUtil.nvl(request.getParameter("exp_exca_plan_rsl_cd")));
		}
		if("".equals(request.getParameter("excaBzProcDvn")) || null == request.getParameter("excaBzProcDvn")){
			mbtt02001vo.setExcaBzProcDvn(" ");
		} else {
			mbtt02001vo.setExcaBzProcDvn(StringUtil.nvl(request.getParameter("excaBzProcDvn")));
		}
		if("".equals(request.getParameter("excaRtrnDvn")) || null == request.getParameter("excaRtrnDvn")){
			mbtt02001vo.setExcaRtrnDvn(" ");
		} else {
			mbtt02001vo.setExcaRtrnDvn(StringUtil.nvl(request.getParameter("excaRtrnDvn")));
		}
		if("".equals(request.getParameter("trv_dstc_splc_exca_yn")) || null == request.getParameter("trv_dstc_splc_exca_yn")){
			mbtt02001vo.setTrvDstcSplcExcaYn(" ");
		} else {
			mbtt02001vo.setTrvDstcSplcExcaYn(StringUtil.nvl(request.getParameter("trv_dstc_splc_exca_yn")));
		}
		if("".equals(request.getParameter("imag_dup_yn")) || null == request.getParameter("imag_dup_yn")){
			mbtt02001vo.setImagDupYn(" ");
		} else {
			mbtt02001vo.setImagDupYn(StringUtil.nvl(request.getParameter("Imag_dup_yn")));
		}
		if("".equals(request.getParameter("nrm_proc_yn")) || null == request.getParameter("nrm_proc_yn")){
			mbtt02001vo.setNrmProcYn(" ");
		} else {
			mbtt02001vo.setNrmProcYn(StringUtil.nvl(request.getParameter("nrm_proc_yn")));
		}
		if("".equals(request.getParameter("crd_scn_cncl_pss_yn")) || null == request.getParameter("crd_scn_cncl_pss_yn")){
			mbtt02001vo.setCrdScnCnclPssYn(" ");
		} else {
			mbtt02001vo.setCrdScnCnclPssYn(StringUtil.nvl(request.getParameter("crd_scn_cncl_pss_yn")));
		}
		if("".equals(request.getParameter("adc_rtrn_dvn")) || null == request.getParameter("adc_rtrn_dvn")){
			mbtt02001vo.setAdcRtrnDvn(" ");
		} else {
			mbtt02001vo.setAdcRtrnDvn(StringUtil.nvl(request.getParameter("adc_rtrn_dvn")));
		}
		if("".equals(request.getParameter("scrn_proc_cd")) || null == request.getParameter("scrn_proc_cd")){
			mbtt02001vo.setScrnProcCd(" ");
		} else {
			mbtt02001vo.setScrnProcCd(StringUtil.nvl(request.getParameter("scrn_proc_cd")));
		}
		if("".equals(jmvo.getCtc_plno()) || null == jmvo.getCtc_plno()){
			mbtt02001vo.setCtcPlno(" ");
		} else {
			mbtt02001vo.setCtcPlno(StringUtil.nvl(jmvo.getCtc_plno()));
		}
		if("".equals(request.getParameter("trv_dstc_proc_dvcd")) || null == request.getParameter("trv_dstc_proc_dvcd")){
			mbtt02001vo.setTrvDstcProcDvcd(" ");
		} else {
			mbtt02001vo.setTrvDstcProcDvcd(StringUtil.nvl(request.getParameter("trv_dstc_proc_dvcd")));
		}
		if("".equals(request.getParameter("mbl_snd_no")) || null == request.getParameter("mbl_snd_no")){
			mbtt02001vo.setMblSndNo(" ");
		} else {
			mbtt02001vo.setMblSndNo(StringUtil.nvl(request.getParameter("mbl_snd_no")));
		}
		if("".equals(request.getParameter("plan_plno_dvcd")) || null == request.getParameter("plan_plno_dvcd")){
			mbtt02001vo.setPlanPlnoDvcd(" ");
		} else {
			mbtt02001vo.setPlanPlnoDvcd(StringUtil.nvl(request.getParameter("plan_plno_dvcd")));
		}
		if("".equals(request.getParameter("plan_plno")) || null == request.getParameter("plan_plno")){
			mbtt02001vo.setPlanPlno(" ");
		} else {
			mbtt02001vo.setPlanPlno(StringUtil.nvl(request.getParameter("plan_plno")));
		}
		if("".equals(jmvo.getChng_plan_no()) || null == jmvo.getChng_plan_no()){
			mbtt02001vo.setChngPlanNo(" ");
		} else {
			mbtt02001vo.setChngPlanNo(StringUtil.nvl(jmvo.getChng_plan_no()));
		}
		if("".equals(request.getParameter("dst_tty_dvn1")) || null == request.getParameter("dst_tty_dvn1")){
			mbtt02001vo.setDstTtyDvn1(" ");
		} else {
			mbtt02001vo.setDstTtyDvn1(StringUtil.nvl(request.getParameter("dst_tty_dvn1")));
		}
		if("".equals(request.getParameter("dst_tty_dvn2")) || null == request.getParameter("dst_tty_dvn2")){
			mbtt02001vo.setDstTtyDvn2(" ");
		} else {
			mbtt02001vo.setDstTtyDvn2(StringUtil.nvl(request.getParameter("dst_tty_dvn2")));
		}
		if("".equals(request.getParameter("dst_tty_dvn3")) || null == request.getParameter("dst_tty_dvn3")){
			mbtt02001vo.setDstTtyDvn3(" ");
		} else {
			mbtt02001vo.setDstTtyDvn3(StringUtil.nvl(request.getParameter("dst_tty_dvn3")));
		}
		if("".equals(request.getParameter("dst_tty_dvn4")) || null == request.getParameter("dst_tty_dvn4")){
			mbtt02001vo.setDstTtyDvn4(" ");
		} else {
			mbtt02001vo.setDstTtyDvn4(StringUtil.nvl(request.getParameter("dst_tty_dvn4")));
		}
		if("".equals(request.getParameter("dst_tty_dvn5")) || null == request.getParameter("dst_tty_dvn5")){
			mbtt02001vo.setDstTtyDvn5(" ");
		} else {
			mbtt02001vo.setDstTtyDvn5(StringUtil.nvl(request.getParameter("dst_tty_dvn5")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt1")) || null == request.getParameter("phgp_regt_tgt1")){
			mbtt02001vo.setPhgpRegtTgt1(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt1(StringUtil.nvl(request.getParameter("phgp_regt_tgt1")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt2")) || null == request.getParameter("phgp_regt_tgt2")){
			mbtt02001vo.setPhgpRegtTgt2(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt2(StringUtil.nvl(request.getParameter("phgp_regt_tgt2")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt3")) || null == request.getParameter("phgp_regt_tgt3")){
			mbtt02001vo.setPhgpRegtTgt3(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt3(StringUtil.nvl(request.getParameter("phgp_regt_tgt3")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt4")) || null == request.getParameter("phgp_regt_tgt4")){
			mbtt02001vo.setPhgpRegtTgt4(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt4(StringUtil.nvl(request.getParameter("phgp_regt_tgt4")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt5")) || null == request.getParameter("phgp_regt_tgt5")){
			mbtt02001vo.setPhgpRegtTgt5(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt5(StringUtil.nvl(request.getParameter("phgp_regt_tgt5")));
		}
		mbtt02001vo.setTlgProcRslCdVal(StringUtil.nvl(jmvo1.getZ_tlg_sp_cd()));
		mbtt02001vo.setTlgErrCdVal(StringUtil.nvl(jmvo1.getZ_trns_org_dvcd())+StringUtil.nvl(jmvo1.getZ_trns_org_cd()));
		mbtt02001vo.setRespCn(StringUtil.nvl(jmvo1.getZ_resp_cd()));
		mbtt02001vo.setRslCn(scrnNm + "_" + StringUtil.nvl(jmvo1.getZ_resp_msg()));
		mbtt02001vo.setFrstIpmnEmpno("82101685");
		mbtt02001vo.setFnalAmdrEmpno("82101685");
		
		logger.info("###### aiocrFileUploadOCR2 테스트1 ######");
		logger.info("###### request ######");
		logger.info("###### plno: " + StringUtil.nvl(request.getParameter("plno")));
		logger.info("###### plan_no: " + StringUtil.nvl(request.getParameter("exp_exca_plan_no")));
		logger.info("###### rnw_plno: " + StringUtil.nvl(request.getParameter("rnw_plno")));
		logger.info("###### pbox_no_dvcd: " + StringUtil.nvl(jmvo.getPbox_no_dvcd()));
		logger.info("###### proc_dvn: " + StringUtil.nvl(jmvo.getProc_dvn()));
		logger.info("###### hdlr_empno: " + StringUtil.nvl(request.getParameter("hdlr_empno")));
		logger.info("###### trv_dstc_exp_exca_dvcd: " + StringUtil.nvl(request.getParameter("trv_dstc_exp_exca_dvcd")));
		logger.info("###### trv_dstc_chng_aply_dvn: " + StringUtil.nvl(jmvo.getTrv_dstc_chng_aply_dvn()));
		logger.info("###### hdlr_fire_yn: " + StringUtil.nvl(jmvo.getHdlr_fire_yn()));
		logger.info("###### mtcc_yn: " + StringUtil.nvl(request.getParameter("mtcc_yn")));
		logger.info("###### aut_cgnt_trv_dstc: " + StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc")));
		logger.info("###### aut_cgnt_trv_dstc_rsl_cd: " + StringUtil.nvl(jmvo1.getAut_cgnt_trv_dstc_rsl_cd()));
		logger.info("###### pdc_sr_dvn: " + StringUtil.nvl(request.getParameter("pdc_sr_dvn")));
		logger.info("###### adc_rtrn_prm: " + StringUtil.nvl(request.getParameter("adc_rtrn_prm")));
		logger.info("###### inpt_trv_dstc: " + StringUtil.nvl(request.getParameter("inpt_trv_dstc")));
		logger.info("###### cnv_trv_dstc: " + StringUtil.nvl(request.getParameter("cnv_trv_dstc")));
		logger.info("###### exp_exca_plan_rsl_cd: " + StringUtil.nvl(request.getParameter("exp_exca_plan_rsl_cd")));
		logger.info("###### excaBzProcDvn: " + StringUtil.nvl(request.getParameter("excaBzProcDvn")));
		logger.info("###### excaRtrnDvn: " + StringUtil.nvl(request.getParameter("excaRtrnDvn")));
		logger.info("###### trv_dstc_splc_exca_yn: " + StringUtil.nvl(request.getParameter("trv_dstc_splc_exca_yn")));
		logger.info("###### imag_dup_yn: " + StringUtil.nvl(request.getParameter("imag_dup_yn")));
		logger.info("###### nrm_proc_yn: " + StringUtil.nvl(request.getParameter("nrm_proc_yn")));
		logger.info("###### crd_scn_cncl_pss_yn: " + StringUtil.nvl(request.getParameter("crd_scn_cncl_pss_yn")));
		
		//MMTI0259 insert
		insertRow = 0;
		
		logger.info("#### aiocrFileUploadOCR2 MMTI0259 insertJungsanTest before ####");
		insertRow = mileageTobeService.insertJungsanTest(mbtt02001vo);
		logger.info("#### aiocrFileUploadOCR2 MMTI0259 insertJungsanTest after ####");
		
		if(insertRow < 1){
			logger.info("#### 사서함번호: " + StringUtil.nvl(mbtt02001vo.getPboxNo()) + "####");
			logger.info("#### insert 결과: Fail ####");
		}else{
			logger.info("#### insert 결과: Success ####");
		}

		for(int i = 0; i < files.size(); i++) {
			File f = files.get(i);
			String fname = f.getName();
			/*String fsize = Long.toString(f.length());*/
			long fsz = f.length();
			String logg = String.valueOf(fsz);
			/*logger.debug("##파일사이즈: " + logg);*/
			logger.info("##파일사이즈: " + logg);
			// logger.debug("##파일사이즈: " + fsize);
			f.delete();
			logger.debug(fname + " 삭제");
		}
		
		map.put("errorCode",				jmvo1.getErrorCode());
		map.put("z_resp_msg",				jmvo1.getZ_resp_msg());
		map.put("exp_exca_plan_rsl_cd",		jmvo1.getExp_exca_plan_rsl_cd());
		map.put("adc_rtrn_dvn",				jmvo1.getAdc_rtrn_dvn());
		map.put("adc_rtrn_prm",				jmvo1.getAdc_rtrn_prm());
		map.put("plno",						jmvo1.getPlno());
		map.put("exp_exca_plan_no",			jmvo1.getExp_exca_plan_no());
		map.put("exp_exca_plan_bse_dd",		jmvo1.getExp_exca_plan_bse_dd());
		map.put("aut_cgnt_vh_no",			jmvo1.getAut_cgnt_vh_no());
		map.put("aut_cgnt_vh_no_rsl_cd",	jmvo1.getAut_cgnt_vh_no_rsl_cd());
		map.put("aut_cgnt_trv_dstc",		jmvo1.getAut_cgnt_trv_dstc());
		map.put("aut_cgnt_trv_dstc_rsl_cd",	jmvo1.getAut_cgnt_trv_dstc_rsl_cd());
		map.put("exp_exca_plan_proc_dvn",	jmvo1.getExp_exca_plan_proc_dvn());
		map.put("cnv_trv_dstc",				jmvo1.getCnv_trv_dstc());
		map.put("plhd_cust_nm", 			jmvo1.getPlhd_cust_nm());
		map.put("pdc_sr_dvn", 				jmvo1.getPdc_sr_dvn());
		
		//210714
		session.setAttribute("crd_scn_cncl_pss_yn", StringUtil.nvl(jmvo1.getCrd_scn_cncl_pss_yn()));
		session.setAttribute("stlm_cdcp_nm", StringUtil.nvl(jmvo1.getStlm_cdcp_nm()));
		session.setAttribute("stlm_crd_no", StringUtil.nvl(jmvo1.getStlm_crd_no()));
			
		// 201111 추가
		session.setAttribute("trv_dstc1", request.getParameter("mileage1"));
		// 210708 추가
		session.setAttribute("errorCode", jmvo1.getErrorCode());
		session.setAttribute("exp_exca_plan_rsl_cd", jmvo1.getExp_exca_plan_rsl_cd());
		
		session.setAttribute("cnv_trv_dstc", jmvo1.getCnv_trv_dstc());
		session.setAttribute("adc_rtrn_dvn", jmvo1.getAdc_rtrn_dvn());
		session.setAttribute("adc_rtrn_prm", jmvo1.getAdc_rtrn_prm());
		
		session.setAttribute("plno", jmvo1.getPlno());
		session.setAttribute("exp_exca_plan_no", jmvo1.getExp_exca_plan_no());
		session.setAttribute("exp_exca_plan_bse_dd", jmvo1.getExp_exca_plan_bse_dd());
		session.setAttribute("aut_cgnt_vh_no", jmvo1.getAut_cgnt_vh_no());
		session.setAttribute("aut_cgnt_vh_no_rsl_cd", jmvo1.getAut_cgnt_vh_no_rsl_cd());
		session.setAttribute("aut_cgnt_trv_dstc", jmvo1.getAut_cgnt_trv_dstc());
		session.setAttribute("aut_cgnt_trv_dstc_rsl_cd", jmvo1.getAut_cgnt_trv_dstc_rsl_cd());
		session.setAttribute("exp_exca_plan_proc_dvn", jmvo1.getExp_exca_plan_proc_dvn());
		session.setAttribute("cnv_trv_dstc", jmvo1.getCnv_trv_dstc());
		session.setAttribute("plhd_cust_nm", jmvo1.getPlhd_cust_nm());
		session.setAttribute("pdc_sr_dvn", jmvo1.getPdc_sr_dvn());
		
		return map;
	}
	
	//aiocr용
	@RequestMapping(value="/aiocrFileUploadOCR")
	public @ResponseBody Map<String, String> aiocrFileUploadOCR(MultipartHttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		Map<String, String> map = new HashMap<String, String>();
		String yyyymmdd = DateUtil.getDate("yyyymmdd");
		
		String phgp_rl_ptgr_dt			= StringUtil.nvl(request.getParameter("phgp_rl_ptgr_dt"));			// 사진실제촬영일자
		String phgp_apdx_way_cd			= StringUtil.nvl(request.getParameter("phgp_apdx_way_cd"));			// 사진첨부방식코드
		
		MMTI0213VO jmvo = new MMTI0213VO();
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("p")));
		jmvo = mileageTobeService.getMMTI0213VO(jmvo);
		
		String exifDate1 = StringUtil.nvl(request.getParameter("exifDate1"));
		
		if(exifDate1.indexOf(",gallery") > -1) {
			exifDate1 = exifDate1.substring(0, exifDate1.indexOf(",gallery"));
			if(StringUtil.isEmpty(exifDate1)) {
				exifDate1 = DateUtil.getDate();
			}
			else if(Integer.parseInt(exifDate1) > Integer.parseInt(DateUtil.getDate())) {
				map.put("errorCode", "f");
				return map;
			}
		}

		if(exifDate1.indexOf(",gallery") > -1) {
			exifDate1 = exifDate1.substring(0, exifDate1.indexOf(",gallery"));
		}

		ArrayList<File> files = mileageTobeService.aiocrUploadToWAS(request, jmvo.getSms_ts_bvan());
		
		String aut_cgnt_trv_dstc_rsl_cd = "";	// 자동인식주행거리결과코드
		String aut_cgnt_vh_no_rsl_cd = "";		// 자동인식차량번호결과코드
		String aut_cgnt_trv_dstc = "";			// 자동인식주행거리
		String aut_cgnt_vh_no = "";				// 자동인식차량번호
		
		String aut_cgnt_trv_dstc_1 = "";		// 자동인식주행거리1
		String aut_cgnt_trv_dstc_2 = "";		// 자동인식주행거리2
		String aut_cgnt_trv_dstc_3 = "";		// 자동인식주행거리3
		
		String a_i_o_c_r_rqst_dsky_val	= "";	// aiocr요청구분키값
		String a_i_o_c_r_resultCode 	= "";	// aiocr요청결과코드값
		String resultValue 				= "";	// 주행거리값1
		String dtcn_cgnt_rt 			= "";	// 검출인식률1
		String cgnt_cgnt_rt 			= "";	// 인식인식률1
		String resultValue2 			= "";	// 주행거리값2
		String dtcn_cgnt_rt2 			= "";	// 검출인식률2
		String cgnt_cgnt_rt2 			= "";	// 인식인식률2
		String resultValue3 			= "";	// 주행거리값3
		String dtcn_cgnt_rt3 			= "";	// 검출인식률3
		String cgnt_cgnt_rt3 			= "";	// 인식인식률3
		String RE_CODE 					= "";
		
		HashMap<String, String> resultMap = null;
		
		boolean flag1 = false;
		if(files.size() > 0) {
			FTPUtil ftp = null;
			// [200617]
			FileInputStream in = null;
			FileInputStream fis = null;
			FileOutputStream out = null;
			
			HttpResponse httpResp = null;
			HttpEntity respEntity = null;
			
			resultMap = new HashMap<String, String>();
			
			try {
				if("1".equals(jmvo.getAut_cgnt_nn_apcn_yn())) { // OCR서버 문제있으면...
					aut_cgnt_trv_dstc_rsl_cd = "03";
					aut_cgnt_vh_no_rsl_cd = "03";
				}
				else {
					String propsPath = this.getClass().getResource("").getPath();
					propsPath = propsPath.substring(0, propsPath.indexOf("/classes/")) + "/config/aiocr_ftp.properties";
					
					String aiocrURL = AIOCR_SERVER_PATH;
					CloseableHttpClient httpClient = HttpClients.createDefault();
					HttpPost httpPost = new HttpPost(aiocrURL);
					
					HttpEntity httpEntity = MultipartEntityBuilder.create()
							.addTextBody("templateName", "car.drivingdistance.workflow")
							.addTextBody("senderName", "SMZ")
							.addBinaryBody("Files", new File(files.get(0).toString()), ContentType.MULTIPART_FORM_DATA, files.get(0).toString()).build();
					
					httpPost.setEntity(httpEntity);
					
					CloseableHttpResponse response1 = httpClient.execute(httpPost);
					
					logger.debug("========== start ==========");
					logger.debug("Status Code : " + response1.getStatusLine().getStatusCode());
					logger.debug("========== end ==========");
					
					// json param setting start
					respEntity = response1.getEntity();
					
					String jsonResp = EntityUtils.toString(respEntity);
					logger.debug("AI OCR uploadAiOCR("+files.get(0).toString()+") 응답 json : " + jsonResp);
					
					JSONParser jsonParser = new JSONParser();
					JSONObject jsonObj = (JSONObject) jsonParser.parse(jsonResp);
					JSONArray jsonArray = (JSONArray) jsonObj.get("results");
					
					a_i_o_c_r_rqst_dsky_val	= (String) jsonObj.get("resultItemKey");	// aiocr요청구분키값
					a_i_o_c_r_resultCode = (String) jsonObj.get("resultCode"); // aiocr요청결과코드값(01:정상, 11~33:오류)
					
					
					if(response1.getStatusLine().getStatusCode() == 200){
						
						logger.debug("[거울]jsonArray : " + jsonArray.get(0) + "jsonArray size : " + jsonArray.size());
						
						if(jsonResp != null){
//							String ocrResultCode = (String) jsonObj.get("resultCode");
							if(!StringUtil.isEmpty(a_i_o_c_r_resultCode)){
								if("01".equals(a_i_o_c_r_resultCode)){
									if(jsonArray.size() > 0) {
										resultMap.put("RE_CODE", "2");
										aut_cgnt_trv_dstc_rsl_cd = "01";
										for(int s = 0; s < jsonArray.size(); s++){
											if(s == 0) {
												JSONObject jsonObject = (JSONObject) jsonArray.get(0);
												logger.debug("new resultValue = " + (String)jsonObject.get("resultValue"));
												logger.debug("new detectionConfidence = " + (String)jsonObject.get("detectionConfidence"));
												logger.debug("new recognitionConfidence = " + (String)jsonObject.get("recognitionConfidence"));
												
												resultMap.put("resultValue", (String)jsonObject.get("resultValue"));
												resultMap.put("detectionConfidence", (String)jsonObject.get("detectionConfidence"));
												resultMap.put("recognitionConfidence", (String)jsonObject.get("recognitionConfidence"));
											} else if(s == 1) {
												JSONObject jsonObject = (JSONObject) jsonArray.get(1);
												logger.debug("new resultValue2 = " + (String)jsonObject.get("resultValue"));
												logger.debug("new detectionConfidence2 = " + (String)jsonObject.get("detectionConfidence"));
												logger.debug("new recognitionConfidence2 = " + (String)jsonObject.get("recognitionConfidence"));
												
												resultMap.put("resultValue2", (String)jsonObject.get("resultValue"));
												resultMap.put("detectionConfidence2", (String)jsonObject.get("detectionConfidence"));
												resultMap.put("recognitionConfidence2", (String)jsonObject.get("recognitionConfidence"));
											} else {
												JSONObject jsonObject = (JSONObject) jsonArray.get(2);
												logger.debug("new resultValue3 = " + (String)jsonObject.get("resultValue"));
												logger.debug("new detectionConfidence3 = " + (String)jsonObject.get("detectionConfidence"));
												logger.debug("new recognitionConfidence3 = " + (String)jsonObject.get("recognitionConfidence"));
												
												resultMap.put("resultValue3", (String)jsonObject.get("resultValue"));
												resultMap.put("detectionConfidence3", (String)jsonObject.get("detectionConfidence"));
												resultMap.put("recognitionConfidence3", (String)jsonObject.get("recognitionConfidence"));
											}
										
											resultValue				= StringUtil.nvl((String)resultMap.get("resultValue"));			// 주행거리 인식값1
											dtcn_cgnt_rt 			= StringUtil.nvl((String)resultMap.get("detectionConfidence"));	// 검출인식률1
											cgnt_cgnt_rt 			= StringUtil.nvl((String)resultMap.get("recognitionConfidence"));	// 인식인식률1
											resultValue2			= StringUtil.nvl((String)resultMap.get("resultValue2"));			// 주행거리 인식값1
											dtcn_cgnt_rt2 			= StringUtil.nvl((String)resultMap.get("detectionConfidence2"));	// 검출인식률1
											cgnt_cgnt_rt2 			= StringUtil.nvl((String)resultMap.get("recognitionConfidence2"));	// 인식인식률1
											resultValue3			= StringUtil.nvl((String)resultMap.get("resultValue3"));			// 주행거리 인식값1
											dtcn_cgnt_rt3 			= StringUtil.nvl((String)resultMap.get("detectionConfidence3"));	// 검출인식률1
											cgnt_cgnt_rt3 			= StringUtil.nvl((String)resultMap.get("recognitionConfidence3"));	// 인식인식률1
										}
										logger.debug("[거울]resultValue = " + resultValue);
										logger.debug("[거울]dtcn_cgnt_rt = " + dtcn_cgnt_rt);
										logger.debug("[거울]cgnt_cgnt_rt = " + cgnt_cgnt_rt);
										logger.debug("[거울]resultValue2 = " + resultValue2);
										logger.debug("[거울]dtcn_cgnt_rt2 = " + dtcn_cgnt_rt2);
										logger.debug("[거울]cgnt_cgnt_rt2 = " + cgnt_cgnt_rt2);
										logger.debug("[거울]resultValue3 = " + resultValue3);
										logger.debug("[거울]dtcn_cgnt_rt3 = " + dtcn_cgnt_rt3);
										logger.debug("[거울]cgnt_cgnt_rt3 = " + cgnt_cgnt_rt3);
									}
								} else {
									resultMap.put("RE_CODE", "1");
									aut_cgnt_trv_dstc_rsl_cd = a_i_o_c_r_resultCode;
									logger.debug("[거울]aut_cgnt_trv_dstc_rsl_cd = " + aut_cgnt_trv_dstc_rsl_cd);
								}
							} else {
								aut_cgnt_trv_dstc_rsl_cd = "02"; //솔루션에서 보내주는 결과코드값이 없는 경우에 02로 세팅
							}
						}
					} else {
						aut_cgnt_trv_dstc_rsl_cd = a_i_o_c_r_resultCode;
						logger.debug("[거울]aut_cgnt_trv_dstc_rsl_cd = " + aut_cgnt_trv_dstc_rsl_cd);
						logger.error("AI OCR uploadAiOCR("+files.get(0).toString()+","+files.size()+") 시 Error 발생 : " + respEntity);
			                throw new Exception("AI OCR 실패 : " + files.get(0).toString() + "/ responseCode :" + response1.getStatusLine().getStatusCode() + "/ responseMsg :" + EntityUtils.toString(respEntity));
					}
					// json param setting end
					httpClient.close();
					// aiocr 서버 통신 end
					}
				}
				catch(Exception e) {
					logger.debug(e.getMessage());
//					aut_cgnt_trv_dstc_rsl_cd = "02";
					aut_cgnt_trv_dstc_rsl_cd = a_i_o_c_r_resultCode;
					if(!"1".equals(jmvo.getCm_yn())) {
						aut_cgnt_vh_no_rsl_cd = "02";
					}
				}
				
		} 
		
		HttpSession session = request.getSession();
		Object[] imgfile = new Object[files.size()];
		// [200617]
		FileInputStream fis = null;
		try {
			for(int i = 0; i < files.size(); i++) {
				File f = files.get(i);
				fis = new FileInputStream(f);
				byte[] file = new byte[(int) f.length()];
				fis.read(file);
				imgfile[i] = file;
				fis.close();
				fis = null;
				String fname = f.getName();
				f.delete();
				logger.debug(fname + " 삭제");
			}
		} catch (Exception e) {
			System.err.println("[MileageTobeController.mlFileUploadOCR()] Exception");
		}
		finally {
			try{
				if(fis!=null){
					fis.close();
				}
			}
			catch(IOException ee){
				System.err.println("[MileageTobeController.mlFileUploadOCR()] IOException 4");
		    }
		}
		session.setAttribute("imgfile", imgfile);
		
		logger.debug("a_i_o_c_r_rqst_dsky_val = " + a_i_o_c_r_rqst_dsky_val);
		logger.debug("dtcn_cgnt_rt = " + dtcn_cgnt_rt);
		logger.debug("cgnt_cgnt_rt = " + cgnt_cgnt_rt);
		
		map.put("errorCode",					"0");
//		map.put("aut_cgnt_trv_dstc_rsl_cd",		aut_cgnt_trv_dstc_rsl_cd);
		map.put("aut_cgnt_trv_dstc_rsl_cd",		a_i_o_c_r_resultCode);
		map.put("aut_cgnt_vh_no_rsl_cd",		aut_cgnt_vh_no_rsl_cd);
		map.put("aut_cgnt_trv_dstc",			resultValue);
		map.put("aut_cgnt_vh_no",				aut_cgnt_vh_no);
		
		map.put("aut_cgnt_trv_dstc_1",			resultValue);
		map.put("aut_cgnt_trv_dstc_2",			resultValue2);
		map.put("aut_cgnt_trv_dstc_3",			resultValue3);
		
		
		map.put("phgp_rl_ptgr_dt",				phgp_rl_ptgr_dt);
		map.put("phgp_apdx_way_cd",				phgp_apdx_way_cd);
		
		map.put("a_i_o_c_r_rqst_dsky_val", 		a_i_o_c_r_rqst_dsky_val);
		map.put("resultValue", 					resultValue);
		map.put("dtcn_cgnt_rt", 				dtcn_cgnt_rt);
		map.put("cgnt_cgnt_rt", 				cgnt_cgnt_rt);
		map.put("resultValue2", 				resultValue2);
		map.put("dtcn_cgnt_rt2", 				dtcn_cgnt_rt2);
		map.put("cgnt_cgnt_rt2", 				cgnt_cgnt_rt2);
		map.put("resultValue3", 				resultValue3);
		map.put("dtcn_cgnt_rt3", 				dtcn_cgnt_rt3);
		map.put("cgnt_cgnt_rt3", 				cgnt_cgnt_rt3);
		
		return map;
	}
	
	@RequestMapping(value="/mlFileUploadOCR")
	public @ResponseBody Map<String, String> mlFileUploadOCR(MultipartHttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		Map<String, String> map = new HashMap<String, String>();
		String yyyymmdd = DateUtil.getDate("yyyymmdd");
		
		String phgp_rl_ptgr_dt			= StringUtil.nvl(request.getParameter("phgp_rl_ptgr_dt"));			// 사진실제촬영일자
		String phgp_apdx_way_cd			= StringUtil.nvl(request.getParameter("phgp_apdx_way_cd"));			// 사진첨부방식코드
		
		MMTI0213VO jmvo = new MMTI0213VO();
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("p")));
		jmvo = mileageTobeService.getMMTI0213VO(jmvo);
		
		String exifDate1 = StringUtil.nvl(request.getParameter("exifDate1"));
		
		if(exifDate1.indexOf(",gallery") > -1) {
			exifDate1 = exifDate1.substring(0, exifDate1.indexOf(",gallery"));
			if(StringUtil.isEmpty(exifDate1)) {
				exifDate1 = DateUtil.getDate();
			}
			else if(Integer.parseInt(exifDate1) > Integer.parseInt(DateUtil.getDate())) {
				map.put("errorCode", "f");
				return map;
			}
		}

		if(exifDate1.indexOf(",gallery") > -1) {
			exifDate1 = exifDate1.substring(0, exifDate1.indexOf(",gallery"));
		}

		ArrayList<File> files = mileageTobeService.uploadToWAS(request, jmvo.getSms_ts_bvan());
		
		String aut_cgnt_trv_dstc_rsl_cd = "";	// 자동인식주행거리결과코드
		String aut_cgnt_vh_no_rsl_cd = "";		// 자동인식차량번호결과코드
		String aut_cgnt_trv_dstc = "";			// 자동인식주행거리
		String aut_cgnt_vh_no = "";				// 자동인식차량번호
		
		String aut_cgnt_trv_dstc_1 = "";		// 자동인식주행거리1
		String aut_cgnt_trv_dstc_2 = "";		// 자동인식주행거리2
		String aut_cgnt_trv_dstc_3 = "";		// 자동인식주행거리3
		
		
		boolean flag1 = false;
		if(files.size() > 0) {
			FTPUtil ftp = null;
			// [200617]
			FileInputStream in = null;
			FileInputStream fis = null;
			FileOutputStream out = null;
			
			try {
				if("1".equals(jmvo.getAut_cgnt_nn_apcn_yn())) { // OCR서버 문제있으면...
					aut_cgnt_trv_dstc_rsl_cd = "03";
					aut_cgnt_vh_no_rsl_cd = "03";
				}
				else {
					String propsPath = this.getClass().getResource("").getPath();
					propsPath = propsPath.substring(0, propsPath.indexOf("/classes/")) + "/config/ocr_ftp.properties";
					Properties p = new Properties();
					// [200617]
					in = new FileInputStream(propsPath);
					p.load(in);
					in.close();
					// [200617]
					in = null;
					
					String password = p.getProperty("password");
					String decPassword = aes256Decrypt(password);
					if(password.equals(decPassword) || StringUtil.isEmpty(decPassword)) {
						decPassword = password;
						String encPassword = aes256Encrypt(password);
						logger.debug("encPassword: " + encPassword);
						// [200617]
						out = new FileOutputStream(propsPath);
						p.setProperty("password", encPassword);
						p.store(out, "");
						out.close();
						// [200617]
						out = null;
					}
					
					ftp = new FTPUtil(p.getProperty("ip"), p.getProperty("user"), decPassword, Integer.parseInt(p.getProperty("port")));
					
					int working = 0;
					for(int i = 1; i <= 3; i++) {
						String[] ls = ftp.ls("/RECOG_JOB" + i + "/" + yyyymmdd);
						for(int j = 0; j < ls.length; j++) {
							if(".".equals(ls[j]) || "..".equals(ls[j])) continue;
							working++;
						}
					}
	
					if(working <= 6) {
						String filename1 = "";
						
						filename1 = ftp.uploadToOCR("/RECOG/" + yyyymmdd, files.get(0), "--D");

						logger.debug("filename1: " + filename1);

						
						logger.debug("--- 1초 대기 ---");
						Thread.sleep(1000);
						int retryNum = 7;
						for(int retry = 0; retry < retryNum; retry++) {
							String[] ls = ftp.ls("/RECOG_RESULT/" + yyyymmdd);
		
							for(int i = 0; i < ls.length; i++) {
								// logger.debug(ls[i]);
								if(!flag1 && ls[i].equals(filename1)) {
									flag1 = true;
								}
								
								if(flag1) break;
							}
		
							if((flag1) || retry == retryNum - 1) {
								break;
							}
							else {
								logger.debug("--- 0.6초 대기 ---");
								Thread.sleep(600);
							}
						}
						
						logger.debug("flag1: " + flag1);
						
						if(flag1) {
							// [210219]
							if(filename1 != null || !"".equals(filename1)){
								filename1 = filename1.replaceAll("/", "");
								filename1 = filename1.replaceAll("\\\\", "");
								filename1 = filename1.replaceAll("./", "");
								filename1 = filename1.replaceAll("../", "");
								filename1 = filename1.replaceAll("&", "");
							}
							
							String path = files.get(0).getParent() + File.separator + filename1;
							ftp.downloadFromOCR("/RECOG_RESULT/" + yyyymmdd, filename1, path);
							logger.debug("path: " + path);
							
							// [210219]
							File f = new File(files.get(0).getParent() + File.separator + filename1);
							// File f = new File(path);
		
							if(f.exists()) {
								Properties props = new Properties();
								// [210219]
								fis = new FileInputStream(files.get(0).getParent() + File.separator + filename1);
								props.load(fis);
								fis.close();
								// [200617]
								fis = null;
								
								if(!StringUtil.isEmpty(props.getProperty("ODO")) && !StringUtil.isEmpty(props.getProperty("RE_CODE"))) {
									aut_cgnt_trv_dstc = props.getProperty("ODO");
									aut_cgnt_trv_dstc_rsl_cd = "1".equals(props.getProperty("RE_CODE")) || "2".equals(props.getProperty("RE_CODE")) ? "01" : "02";
									
									aut_cgnt_trv_dstc_1 = props.getProperty("ODO");
									
									if(!StringUtil.isEmpty(props.getProperty("ODO2"))) {
										aut_cgnt_trv_dstc_2 = props.getProperty("ODO2");
									}
									
									if(!StringUtil.isEmpty(props.getProperty("ODO3"))) {
										aut_cgnt_trv_dstc_3 = props.getProperty("ODO3");
									}
								}
								
				            	if(f.delete()) {
									logger.debug("삭제: " + path);
								}
							}
						}
						else {
							aut_cgnt_trv_dstc_rsl_cd = "02";
						}						
					}
					else {
						aut_cgnt_trv_dstc_rsl_cd = "02";
						if(!"1".equals(jmvo.getCm_yn())) {
							aut_cgnt_vh_no_rsl_cd = "02";
						}
					}
				}
			}
			catch(Exception e) {
				logger.debug(e.getMessage());
				aut_cgnt_trv_dstc_rsl_cd = "02";
				if(!"1".equals(jmvo.getCm_yn())) {
					aut_cgnt_vh_no_rsl_cd = "02";
				}
			}
			finally {
				if(ftp != null) ftp.disconnect();
				// [200617]
				try{
		    	  	if(in != null){
		    	  		in.close();
		    	  	}
			      }catch(IOException ee){
			    	  System.err.println("[MileageTobeController.mlFileUploadOCR()] IOException 1");
			      }
				try{
		    	  	if(out != null){
		    	  		out.close();
		    	  	}
			      }catch(IOException ee){
			    	  System.err.println("[MileageTobeController.mlFileUploadOCR()] IOException 2");
			      }
				try{
		    	  	if(fis != null){
		    	  		fis.close();
		    	  	}
			      }catch(IOException ee){
			    	  System.err.println("[MileageTobeController.mlFileUploadOCR()] IOException 3");
			      }
			}
		}
		
		HttpSession session = request.getSession();
		Object[] imgfile = new Object[files.size()];
		// [200617]
		FileInputStream fis = null;
		try {
			for(int i = 0; i < files.size(); i++) {
				File f = files.get(i);
				fis = new FileInputStream(f);
				byte[] file = new byte[(int) f.length()];
				fis.read(file);
				imgfile[i] = file;
				fis.close();
				fis = null;
				String fname = f.getName();
				f.delete();
				logger.debug(fname + " 삭제");
			}
		} catch (Exception e) {
			System.err.println("[MileageTobeController.mlFileUploadOCR()] Exception");
		}
		finally {
			try{
				if(fis!=null){
					fis.close();
				}
			}
			catch(IOException ee){
				System.err.println("[MileageTobeController.mlFileUploadOCR()] IOException 4");
		    }
		}
		session.setAttribute("imgfile", imgfile);
		
		map.put("errorCode",					"0");
		map.put("aut_cgnt_trv_dstc_rsl_cd",		aut_cgnt_trv_dstc_rsl_cd);
		map.put("aut_cgnt_vh_no_rsl_cd",		aut_cgnt_vh_no_rsl_cd);
		map.put("aut_cgnt_trv_dstc",			aut_cgnt_trv_dstc);
		map.put("aut_cgnt_vh_no",				aut_cgnt_vh_no);
		
		map.put("aut_cgnt_trv_dstc_1",			aut_cgnt_trv_dstc_1);
		map.put("aut_cgnt_trv_dstc_2",			aut_cgnt_trv_dstc_2);
		map.put("aut_cgnt_trv_dstc_3",			aut_cgnt_trv_dstc_3);
		
		
		map.put("phgp_rl_ptgr_dt",			phgp_rl_ptgr_dt);
		map.put("phgp_apdx_way_cd",			phgp_apdx_way_cd);
			
		return map;
	}

	@RequestMapping(value="/mlFileUploadOCR2")
	public @ResponseBody Map<String, String> mlFileUploadOCR2(MultipartHttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		Map<String, String> map = new HashMap<String, String>();

		String aut_cgnt_trv_dstc_rsl_cd	= StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc_rsl_cd"));	// 자동인식주행거리결과코드
		String aut_cgnt_vh_no_rsl_cd	= StringUtil.nvl(request.getParameter("aut_cgnt_vh_no_rsl_cd"));	// 자동인식차량번호결과코드
		String aut_cgnt_trv_dstc		= StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc"));		// 자동인식주행거리
		String aut_cgnt_vh_no			= StringUtil.nvl(request.getParameter("aut_cgnt_vh_no"));			// 자동인식차량번호
		
		String aut_cgnt_trv_dstc_1		= StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc_1"));		// 자동인식주행거리
		String aut_cgnt_trv_dstc_2		= StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc_2"));		// 자동인식주행거리
		String aut_cgnt_trv_dstc_3		= StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc_3"));		// 자동인식주행거리
		
		// 020708
		String phgp_rl_ptgr_dt			= StringUtil.nvl(request.getParameter("phgp_rl_ptgr_dt"));			// 사진실제촬영일자
		String phgp_apdx_way_cd			= StringUtil.nvl(request.getParameter("phgp_apdx_way_cd"));			// 사진첨부방식코드
		
		MMTI0213VO jmvo = new MMTI0213VO();
		MBTT02001VO mbtt02001vo = new MBTT02001VO();
		String scrnNm = "mlFileUploadOCR2";
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("p")));
		jmvo = mileageTobeService.getMMTI0213VO(jmvo);
		
		String exifDate1 = StringUtil.nvl(request.getParameter("exifDate1"));
		String phgp_ptgr_dt = "";
		
		boolean empty = false;
		if(exifDate1.indexOf(",gallery") > -1) {
			exifDate1 = exifDate1.substring(0, exifDate1.indexOf(",gallery"));
			if(StringUtil.isEmpty(exifDate1)) {
				exifDate1 = DateUtil.getDate();
				empty = true;
			}
			else if(Integer.parseInt(exifDate1) > Integer.parseInt(DateUtil.getDate())) {
				map.put("errorCode", "f");
				return map;
			}
		}

		phgp_ptgr_dt = empty ? "" : exifDate1;
		
		if(exifDate1.indexOf(",gallery") > -1) {
			exifDate1 = exifDate1.substring(0, exifDate1.indexOf(",gallery"));
		}
		
		HttpSession session = request.getSession();
		session.setAttribute("exifDate", exifDate1);

		ArrayList<File> files = mileageTobeService.uploadToWAS(request, jmvo.getSms_ts_bvan());
		
		MMTI0259VO jmvo1 = new MMTI0259VO();
		jmvo1.setPbox_use_yn("1");
		jmvo1.setPbox_no(jmvo.getSms_ts_bvan());
		jmvo1.setPhgp_cnfm_dt(DateUtil.getDate());
		jmvo1.setPhgp_ptgr_dt(phgp_ptgr_dt);
		jmvo1.setPhgp_strg_yn("1");
		if("1".equals(jmvo.getAut_cgnt_nn_apcn_yn())) {
			jmvo1.setPbox_chr_nm(request.getParameter("mileage1"));
		}
		
		if("1".equals(jmvo.getPbox_no_dvcd())) {
			if(!"1".equals(jmvo.getCm_yn())) {
				jmvo1.setInpt_trv_dstc(request.getParameter("mileage1"));
				if(!StringUtil.isEmpty(aut_cgnt_vh_no)) {
					jmvo1.setAut_cgnt_vh_no(aut_cgnt_vh_no);
				}
				
				if(!StringUtil.isEmpty(aut_cgnt_vh_no_rsl_cd)) {
					jmvo1.setAut_cgnt_vh_no_rsl_cd(aut_cgnt_vh_no_rsl_cd);
				}
				else {
					jmvo1.setAut_cgnt_vh_no_rsl_cd("02");
				}
			}
				
			if(!StringUtil.isEmpty(aut_cgnt_trv_dstc)) {
				jmvo1.setAut_cgnt_trv_dstc(aut_cgnt_trv_dstc);
			}
			
			if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_rsl_cd)) {
				jmvo1.setAut_cgnt_trv_dstc_rsl_cd(aut_cgnt_trv_dstc_rsl_cd);
			}
			else {
				jmvo1.setAut_cgnt_trv_dstc_rsl_cd("02");
			}
			
			if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_1)) {
				jmvo1.setAut_cgnt_trv_dstc_1(aut_cgnt_trv_dstc_1);
			}
			
			if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_2)) {
				jmvo1.setAut_cgnt_trv_dstc_2(aut_cgnt_trv_dstc_2);
			}
			
			if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_3)) {
				jmvo1.setAut_cgnt_trv_dstc_3(aut_cgnt_trv_dstc_3);
			}
		}
		
		// 200708
		jmvo1.setPhgp_rl_ptgr_dt(phgp_rl_ptgr_dt);
		jmvo1.setPhgp_apdx_way_cd(phgp_apdx_way_cd);
		
		jmvo1 = mileageTobeService.getMMTI0259VO(jmvo1);
		MBTR01001VO mbtr01001vo = new MBTR01001VO();
		
		if("0".equals(jmvo1.getErrorCode()) && !"1".equals(jmvo.getCm_yn())) {
			jmvo1.setExp_exca_plan_proc_dvn("1");
			jmvo1.setPlno(jmvo.getPlno());
			
			// 200708
			jmvo1.setPhgp_rl_ptgr_dt(phgp_rl_ptgr_dt);
			jmvo1.setPhgp_apdx_way_cd(phgp_apdx_way_cd);
			
			jmvo1 = mileageTobeService.getMMTI0259VO(jmvo1);
			
			if("08".equals(jmvo.getProc_dvn())) {
				mbtr01001vo = mileageTobeService.regInfoToEdmsForMobileWeb2(request, jmvo.getNtft_srv_rc_ormm_cd(), files, jmvo.getPlno() + "," + jmvo.getChng_plan_no(), mbtr01001vo);
			}
			else if(!StringUtil.isEmpty(jmvo1.getPlno()) && !StringUtil.isEmpty(jmvo1.getExp_exca_plan_no())) {
				mbtr01001vo = mileageTobeService.regInfoToEdmsForMobileWeb2(request, jmvo.getNtft_srv_rc_ormm_cd(), files, jmvo1.getPlno() + "," + jmvo1.getExp_exca_plan_no(), mbtr01001vo);
			}
			else if(!StringUtil.isEmpty(jmvo1.getPlno()) && StringUtil.isEmpty(jmvo1.getExp_exca_plan_no())) {
				mbtr01001vo = mileageTobeService.regInfoToEdmsForMobileWeb2(request, jmvo.getNtft_srv_rc_ormm_cd(), files, jmvo1.getPlno(), mbtr01001vo);
			}
		}
		else {
			if("1".equals(jmvo.getCm_yn())) {
				mbtr01001vo = mileageTobeService.regInfoToEdmsForMobileWeb(request, jmvo.getSms_ts_bvan(), mbtr01001vo);
			}
			else {
				mbtr01001vo = mileageTobeService.regInfoToEdmsForMobileWeb2(request, jmvo.getNtft_srv_rc_ormm_cd(), files, jmvo1.getPlno(), mbtr01001vo);
			}
		}
		
		int insertRow = 0;
		
		// VO SET
		mbtr01001vo.setPboxNo(jmvo.getSms_ts_bvan());
		mbtr01001vo.setApdxFlRutNm("");
		mbtr01001vo.setFrstIpmnEmpno("82101685");
		mbtr01001vo.setFnalAmdrEmpno("82101685");
		
		if(mbtr01001vo.getProcRslMsgCn() != null){
			mbtr01001vo.getProcRslMsgCn();
			logger.info("#### procRslMsgCn = " + mbtr01001vo.getProcRslMsgCn());
		}
		
		try {
			insertRow = mileageTobeService.insertTest(mbtr01001vo);
			if(insertRow < 1){
				logger.info("#### 사서함번호: " + StringUtil.nvl(mbtr01001vo.getPboxNo()) + "####");
				logger.info("#### insert 결과: Fail ####");
			}else{
				logger.info("#### insert 결과: Success ####");
			}
		} catch (Exception e) {
			e.getMessage();
		}
		
		
		//MBTT02001 정산이력 적재(20220614)
		mbtt02001vo.setPboxNo(StringUtil.nvl(jmvo.getSms_ts_bvan()));
		mbtt02001vo.setTlgIdVal("MMTI0213");
		mbtt02001vo.setEsbTrscId(StringUtil.nvl(jmvo.getZ_trsc_id()));
		if("".equals(jmvo.getPlno()) || null == jmvo.getPlno()){
			mbtt02001vo.setPlno(" ");
		} else {
			mbtt02001vo.setPlno(StringUtil.nvl(jmvo.getPlno()));
		}
		if("".equals(request.getParameter("exp_exca_plan_no")) || null == request.getParameter("exp_exca_plan_no")){
			mbtt02001vo.setPlanNo(" ");
		} else {
			mbtt02001vo.setPlanNo(StringUtil.nvl(request.getParameter("exp_exca_plan_no")));
		}
		if("".equals(request.getParameter("rnw_plno")) || null == request.getParameter("rnw_plno")){
			mbtt02001vo.setRnwPlno(" ");
		} else {
			mbtt02001vo.setRnwPlno(StringUtil.nvl(request.getParameter("rnw_plno")));
		}
		if("".equals(jmvo.getPbox_no_dvcd()) || null == jmvo.getPbox_no_dvcd()){
			mbtt02001vo.setPboxNoDvcd(" ");
		} else {
			mbtt02001vo.setPboxNoDvcd(StringUtil.nvl(jmvo.getPbox_no_dvcd()));
		}
		if("".equals(jmvo.getProc_dvn()) || null == jmvo.getProc_dvn()){
			mbtt02001vo.setProcDvn(" ");
		} else {
			mbtt02001vo.setProcDvn(StringUtil.nvl(jmvo.getProc_dvn()));
		}
		if("".equals(request.getParameter("hdlr_empno")) || null == request.getParameter("hdlr_empno")){
			mbtt02001vo.setHdlrEmpno(" ");
		} else {
			mbtt02001vo.setHdlrEmpno(StringUtil.nvl(request.getParameter("hdlr_empno")));
		}
		if("".equals(request.getParameter("trv_dstc_exp_exca_dvcd")) || null == request.getParameter("trv_dstc_exp_exca_dvcd")){
			mbtt02001vo.setTrvDstcExpExcaDvcd(" ");
		} else {
			mbtt02001vo.setTrvDstcExpExcaDvcd(StringUtil.nvl(request.getParameter("trv_dstc_exp_exca_dvcd")));
		}
		if("".equals(jmvo.getTrv_dstc_chng_aply_dvn()) || null == jmvo.getTrv_dstc_chng_aply_dvn()){
			mbtt02001vo.setTrvDstcChngAplyDvn(" ");
		} else {
			mbtt02001vo.setTrvDstcChngAplyDvn(StringUtil.nvl(jmvo.getTrv_dstc_chng_aply_dvn()));
		}
		if("".equals(jmvo.getHdlr_fire_yn()) || null == jmvo.getHdlr_fire_yn()){
			mbtt02001vo.setHdlrFireYn(" ");
		} else {
			mbtt02001vo.setHdlrFireYn(StringUtil.nvl(jmvo.getHdlr_fire_yn()));
		}
		if("".equals(request.getParameter("mtcc_yn")) || null == request.getParameter("mtcc_yn")){
			mbtt02001vo.setMtccYn(" ");
		} else {
			mbtt02001vo.setMtccYn(StringUtil.nvl(request.getParameter("mtcc_yn")));
		}
		if("".equals(request.getParameter("aut_cgnt_trv_dstc")) || null == request.getParameter("aut_cgnt_trv_dstc")){
			mbtt02001vo.setAutCgntTrvDstc(0);
		} else {
			mbtt02001vo.setAutCgntTrvDstc(Double.parseDouble(request.getParameter("aut_cgnt_trv_dstc")));
		}
		if("".equals(request.getParameter("aut_cgnt_trv_dstc_rsl_cd")) || null == request.getParameter("aut_cgnt_trv_dstc_rsl_cd")){
			mbtt02001vo.setAutCgntTrvDstcRslCd(" ");
		} else {
			mbtt02001vo.setAutCgntTrvDstcRslCd(StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc_rsl_cd")));
		}
		if("".equals(request.getParameter("pdc_sr_dvn")) || null == request.getParameter("pdc_sr_dvn")){
			mbtt02001vo.setPdcSrDvn(" ");
		} else {
			mbtt02001vo.setPdcSrDvn(StringUtil.nvl(request.getParameter("pdc_sr_dvn")));
		}
		if("".equals(request.getParameter("adc_rtrn_prm")) || null == request.getParameter("adc_rtrn_prm")){
			mbtt02001vo.setAdcRtrnPrm(0);
		} else {
			mbtt02001vo.setAdcRtrnPrm(Double.parseDouble(request.getParameter("adc_rtrn_prm")));
		}
		if("".equals(jmvo1.getAut_cgnt_trv_dstc_rsl_cd()) || null == jmvo1.getAut_cgnt_trv_dstc_rsl_cd()){
			mbtt02001vo.setAutCgntTrvDstcRslCd(" ");
		} else {
			mbtt02001vo.setAutCgntTrvDstcRslCd(StringUtil.nvl(jmvo1.getAut_cgnt_trv_dstc_rsl_cd()));
		}
		if("".equals(request.getParameter("mileage1")) || null == request.getParameter("mileage1")){
			mbtt02001vo.setInptTrvDstc(0);
		} else {
			mbtt02001vo.setInptTrvDstc(Double.parseDouble(request.getParameter("mileage1")));
		}
		if("".equals(request.getParameter("cnv_trv_dstc")) || null == request.getParameter("cnv_trv_dstc")){
			mbtt02001vo.setCnvTrvDstc(0);
		} else {
			mbtt02001vo.setCnvTrvDstc(Double.parseDouble(request.getParameter("cnv_trv_dstc")));
		}
		if("".equals(request.getParameter("exp_exca_plan_rsl_cd")) || null == request.getParameter("exp_exca_plan_rsl_cd")){
			mbtt02001vo.setExpExcaPlanRslCd(" ");
		} else {
			mbtt02001vo.setExpExcaPlanRslCd(StringUtil.nvl(request.getParameter("exp_exca_plan_rsl_cd")));
		}
		if("".equals(request.getParameter("excaBzProcDvn")) || null == request.getParameter("excaBzProcDvn")){
			mbtt02001vo.setExcaBzProcDvn(" ");
		} else {
			mbtt02001vo.setExcaBzProcDvn(StringUtil.nvl(request.getParameter("excaBzProcDvn")));
		}
		if("".equals(request.getParameter("excaRtrnDvn")) || null == request.getParameter("excaRtrnDvn")){
			mbtt02001vo.setExcaRtrnDvn(" ");
		} else {
			mbtt02001vo.setExcaRtrnDvn(StringUtil.nvl(request.getParameter("excaRtrnDvn")));
		}
		if("".equals(request.getParameter("trv_dstc_splc_exca_yn")) || null == request.getParameter("trv_dstc_splc_exca_yn")){
			mbtt02001vo.setTrvDstcSplcExcaYn(" ");
		} else {
			mbtt02001vo.setTrvDstcSplcExcaYn(StringUtil.nvl(request.getParameter("trv_dstc_splc_exca_yn")));
		}
		if("".equals(request.getParameter("imag_dup_yn")) || null == request.getParameter("imag_dup_yn")){
			mbtt02001vo.setImagDupYn(" ");
		} else {
			mbtt02001vo.setImagDupYn(StringUtil.nvl(request.getParameter("Imag_dup_yn")));
		}
		if("".equals(request.getParameter("nrm_proc_yn")) || null == request.getParameter("nrm_proc_yn")){
			mbtt02001vo.setNrmProcYn(" ");
		} else {
			mbtt02001vo.setNrmProcYn(StringUtil.nvl(request.getParameter("nrm_proc_yn")));
		}
		if("".equals(request.getParameter("crd_scn_cncl_pss_yn")) || null == request.getParameter("crd_scn_cncl_pss_yn")){
			mbtt02001vo.setCrdScnCnclPssYn(" ");
		} else {
			mbtt02001vo.setCrdScnCnclPssYn(StringUtil.nvl(request.getParameter("crd_scn_cncl_pss_yn")));
		}
		if("".equals(request.getParameter("adc_rtrn_dvn")) || null == request.getParameter("adc_rtrn_dvn")){
			mbtt02001vo.setAdcRtrnDvn(" ");
		} else {
			mbtt02001vo.setAdcRtrnDvn(StringUtil.nvl(request.getParameter("adc_rtrn_dvn")));
		}
		if("".equals(request.getParameter("scrn_proc_cd")) || null == request.getParameter("scrn_proc_cd")){
			mbtt02001vo.setScrnProcCd(" ");
		} else {
			mbtt02001vo.setScrnProcCd(StringUtil.nvl(request.getParameter("scrn_proc_cd")));
		}
		if("".equals(jmvo.getCtc_plno()) || null == jmvo.getCtc_plno()){
			mbtt02001vo.setCtcPlno(" ");
		} else {
			mbtt02001vo.setCtcPlno(StringUtil.nvl(jmvo.getCtc_plno()));
		}
		if("".equals(request.getParameter("trv_dstc_proc_dvcd")) || null == request.getParameter("trv_dstc_proc_dvcd")){
			mbtt02001vo.setTrvDstcProcDvcd(" ");
		} else {
			mbtt02001vo.setTrvDstcProcDvcd(StringUtil.nvl(request.getParameter("trv_dstc_proc_dvcd")));
		}
		if("".equals(request.getParameter("mbl_snd_no")) || null == request.getParameter("mbl_snd_no")){
			mbtt02001vo.setMblSndNo(" ");
		} else {
			mbtt02001vo.setMblSndNo(StringUtil.nvl(request.getParameter("mbl_snd_no")));
		}
		if("".equals(request.getParameter("plan_plno_dvcd")) || null == request.getParameter("plan_plno_dvcd")){
			mbtt02001vo.setPlanPlnoDvcd(" ");
		} else {
			mbtt02001vo.setPlanPlnoDvcd(StringUtil.nvl(request.getParameter("plan_plno_dvcd")));
		}
		if("".equals(request.getParameter("plan_plno")) || null == request.getParameter("plan_plno")){
			mbtt02001vo.setPlanPlno(" ");
		} else {
			mbtt02001vo.setPlanPlno(StringUtil.nvl(request.getParameter("plan_plno")));
		}
		if("".equals(jmvo.getChng_plan_no()) || null == jmvo.getChng_plan_no()){
			mbtt02001vo.setChngPlanNo(" ");
		} else {
			mbtt02001vo.setChngPlanNo(StringUtil.nvl(jmvo.getChng_plan_no()));
		}
		if("".equals(request.getParameter("dst_tty_dvn1")) || null == request.getParameter("dst_tty_dvn1")){
			mbtt02001vo.setDstTtyDvn1(" ");
		} else {
			mbtt02001vo.setDstTtyDvn1(StringUtil.nvl(request.getParameter("dst_tty_dvn1")));
		}
		if("".equals(request.getParameter("dst_tty_dvn2")) || null == request.getParameter("dst_tty_dvn2")){
			mbtt02001vo.setDstTtyDvn2(" ");
		} else {
			mbtt02001vo.setDstTtyDvn2(StringUtil.nvl(request.getParameter("dst_tty_dvn2")));
		}
		if("".equals(request.getParameter("dst_tty_dvn3")) || null == request.getParameter("dst_tty_dvn3")){
			mbtt02001vo.setDstTtyDvn3(" ");
		} else {
			mbtt02001vo.setDstTtyDvn3(StringUtil.nvl(request.getParameter("dst_tty_dvn3")));
		}
		if("".equals(request.getParameter("dst_tty_dvn4")) || null == request.getParameter("dst_tty_dvn4")){
			mbtt02001vo.setDstTtyDvn4(" ");
		} else {
			mbtt02001vo.setDstTtyDvn4(StringUtil.nvl(request.getParameter("dst_tty_dvn4")));
		}
		if("".equals(request.getParameter("dst_tty_dvn5")) || null == request.getParameter("dst_tty_dvn5")){
			mbtt02001vo.setDstTtyDvn5(" ");
		} else {
			mbtt02001vo.setDstTtyDvn5(StringUtil.nvl(request.getParameter("dst_tty_dvn5")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt1")) || null == request.getParameter("phgp_regt_tgt1")){
			mbtt02001vo.setPhgpRegtTgt1(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt1(StringUtil.nvl(request.getParameter("phgp_regt_tgt1")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt2")) || null == request.getParameter("phgp_regt_tgt2")){
			mbtt02001vo.setPhgpRegtTgt2(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt2(StringUtil.nvl(request.getParameter("phgp_regt_tgt2")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt3")) || null == request.getParameter("phgp_regt_tgt3")){
			mbtt02001vo.setPhgpRegtTgt3(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt3(StringUtil.nvl(request.getParameter("phgp_regt_tgt3")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt4")) || null == request.getParameter("phgp_regt_tgt4")){
			mbtt02001vo.setPhgpRegtTgt4(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt4(StringUtil.nvl(request.getParameter("phgp_regt_tgt4")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt5")) || null == request.getParameter("phgp_regt_tgt5")){
			mbtt02001vo.setPhgpRegtTgt5(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt5(StringUtil.nvl(request.getParameter("phgp_regt_tgt5")));
		}
		mbtt02001vo.setTlgProcRslCdVal(StringUtil.nvl(jmvo1.getZ_tlg_sp_cd()));
		mbtt02001vo.setTlgErrCdVal(StringUtil.nvl(jmvo1.getZ_trns_org_dvcd())+StringUtil.nvl(jmvo1.getZ_trns_org_cd()));
		mbtt02001vo.setRespCn(StringUtil.nvl(jmvo1.getZ_resp_cd()));
		mbtt02001vo.setRslCn(scrnNm + "_" + StringUtil.nvl(jmvo1.getZ_resp_msg()));
		mbtt02001vo.setFrstIpmnEmpno("82101685");
		mbtt02001vo.setFnalAmdrEmpno("82101685");
		
		logger.info("###### mlFileUploadOCR2 테스트1 ######");
		logger.info("###### request ######");
		logger.info("###### plno: " + StringUtil.nvl(request.getParameter("plno")));
		logger.info("###### plan_no: " + StringUtil.nvl(request.getParameter("exp_exca_plan_no")));
		logger.info("###### rnw_plno: " + StringUtil.nvl(request.getParameter("rnw_plno")));
		logger.info("###### pbox_no_dvcd: " + StringUtil.nvl(jmvo.getPbox_no_dvcd()));
		logger.info("###### proc_dvn: " + StringUtil.nvl(jmvo.getProc_dvn()));
		logger.info("###### hdlr_empno: " + StringUtil.nvl(request.getParameter("hdlr_empno")));
		logger.info("###### trv_dstc_exp_exca_dvcd: " + StringUtil.nvl(request.getParameter("trv_dstc_exp_exca_dvcd")));
		logger.info("###### trv_dstc_chng_aply_dvn: " + StringUtil.nvl(jmvo.getTrv_dstc_chng_aply_dvn()));
		logger.info("###### hdlr_fire_yn: " + StringUtil.nvl(jmvo.getHdlr_fire_yn()));
		logger.info("###### mtcc_yn: " + StringUtil.nvl(request.getParameter("mtcc_yn")));
		logger.info("###### aut_cgnt_trv_dstc: " + StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc")));
		logger.info("###### aut_cgnt_trv_dstc_rsl_cd: " + StringUtil.nvl(jmvo1.getAut_cgnt_trv_dstc_rsl_cd()));
		logger.info("###### pdc_sr_dvn: " + StringUtil.nvl(request.getParameter("pdc_sr_dvn")));
		logger.info("###### adc_rtrn_prm: " + StringUtil.nvl(request.getParameter("adc_rtrn_prm")));
		logger.info("###### inpt_trv_dstc: " + StringUtil.nvl(request.getParameter("inpt_trv_dstc")));
		logger.info("###### cnv_trv_dstc: " + StringUtil.nvl(request.getParameter("cnv_trv_dstc")));
		logger.info("###### exp_exca_plan_rsl_cd: " + StringUtil.nvl(request.getParameter("exp_exca_plan_rsl_cd")));
		logger.info("###### excaBzProcDvn: " + StringUtil.nvl(request.getParameter("excaBzProcDvn")));
		logger.info("###### excaRtrnDvn: " + StringUtil.nvl(request.getParameter("excaRtrnDvn")));
		logger.info("###### trv_dstc_splc_exca_yn: " + StringUtil.nvl(request.getParameter("trv_dstc_splc_exca_yn")));
		logger.info("###### imag_dup_yn: " + StringUtil.nvl(request.getParameter("imag_dup_yn")));
		logger.info("###### nrm_proc_yn: " + StringUtil.nvl(request.getParameter("nrm_proc_yn")));
		logger.info("###### crd_scn_cncl_pss_yn: " + StringUtil.nvl(request.getParameter("crd_scn_cncl_pss_yn")));
		
		//MMTI0259 insert
		insertRow = 0;
		
		logger.info("#### mlFileUploadOCR2 MMTI0259 insertJungsanTest before ####");
		insertRow = mileageTobeService.insertJungsanTest(mbtt02001vo);
		logger.info("#### mlFileUploadOCR2 MMTI0259 insertJungsanTest after ####");
		
		if(insertRow < 1){
			logger.info("#### 사서함번호: " + StringUtil.nvl(mbtt02001vo.getPboxNo()) + "####");
			logger.info("#### insert 결과: Fail ####");
		}else{
			logger.info("#### insert 결과: Success ####");
		}

		for(int i = 0; i < files.size(); i++) {
			File f = files.get(i);
			String fname = f.getName();
			/*String fsize = Long.toString(f.length());*/
			long fsz = f.length();
			String logg = String.valueOf(fsz);
			/*logger.debug("##파일사이즈: " + logg);*/
			logger.info("##파일사이즈: " + logg);
			// logger.debug("##파일사이즈: " + fsize);
			f.delete();
			logger.debug(fname + " 삭제");
		}
		
		map.put("errorCode",				jmvo1.getErrorCode());
		map.put("z_resp_msg",				jmvo1.getZ_resp_msg());
		map.put("exp_exca_plan_rsl_cd",		jmvo1.getExp_exca_plan_rsl_cd());
		map.put("adc_rtrn_dvn",				jmvo1.getAdc_rtrn_dvn());
		map.put("adc_rtrn_prm",				jmvo1.getAdc_rtrn_prm());
		map.put("plno",						jmvo1.getPlno());
		map.put("exp_exca_plan_no",			jmvo1.getExp_exca_plan_no());
		map.put("exp_exca_plan_bse_dd",		jmvo1.getExp_exca_plan_bse_dd());
		map.put("aut_cgnt_vh_no",			jmvo1.getAut_cgnt_vh_no());
		map.put("aut_cgnt_vh_no_rsl_cd",	jmvo1.getAut_cgnt_vh_no_rsl_cd());
		map.put("aut_cgnt_trv_dstc",		jmvo1.getAut_cgnt_trv_dstc());
		map.put("aut_cgnt_trv_dstc_rsl_cd",	jmvo1.getAut_cgnt_trv_dstc_rsl_cd());
		map.put("exp_exca_plan_proc_dvn",	jmvo1.getExp_exca_plan_proc_dvn());
		map.put("cnv_trv_dstc",				jmvo1.getCnv_trv_dstc());
		map.put("plhd_cust_nm", 			jmvo1.getPlhd_cust_nm());
		map.put("pdc_sr_dvn", 				jmvo1.getPdc_sr_dvn());
		
		//210714
		session.setAttribute("crd_scn_cncl_pss_yn", StringUtil.nvl(jmvo1.getCrd_scn_cncl_pss_yn()));
		session.setAttribute("stlm_cdcp_nm", StringUtil.nvl(jmvo1.getStlm_cdcp_nm()));
		session.setAttribute("stlm_crd_no", StringUtil.nvl(jmvo1.getStlm_crd_no()));
			
		// 201111 추가
		session.setAttribute("trv_dstc1", request.getParameter("mileage1"));
		// 210708 추가
		session.setAttribute("errorCode", jmvo1.getErrorCode());
		session.setAttribute("exp_exca_plan_rsl_cd", jmvo1.getExp_exca_plan_rsl_cd());
		
		session.setAttribute("cnv_trv_dstc", jmvo1.getCnv_trv_dstc());
		session.setAttribute("adc_rtrn_dvn", jmvo1.getAdc_rtrn_dvn());
		session.setAttribute("adc_rtrn_prm", jmvo1.getAdc_rtrn_prm());
		
		session.setAttribute("plno", jmvo1.getPlno());
		session.setAttribute("exp_exca_plan_no", jmvo1.getExp_exca_plan_no());
		session.setAttribute("exp_exca_plan_bse_dd", jmvo1.getExp_exca_plan_bse_dd());
		session.setAttribute("aut_cgnt_vh_no", jmvo1.getAut_cgnt_vh_no());
		session.setAttribute("aut_cgnt_vh_no_rsl_cd", jmvo1.getAut_cgnt_vh_no_rsl_cd());
		session.setAttribute("aut_cgnt_trv_dstc", jmvo1.getAut_cgnt_trv_dstc());
		session.setAttribute("aut_cgnt_trv_dstc_rsl_cd", jmvo1.getAut_cgnt_trv_dstc_rsl_cd());
		session.setAttribute("exp_exca_plan_proc_dvn", jmvo1.getExp_exca_plan_proc_dvn());
		session.setAttribute("cnv_trv_dstc", jmvo1.getCnv_trv_dstc());
		session.setAttribute("plhd_cust_nm", jmvo1.getPlhd_cust_nm());
		session.setAttribute("pdc_sr_dvn", jmvo1.getPdc_sr_dvn());
		
		return map;
	}
	
	@RequestMapping(value="/up1")
	public String up1(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		HttpSession session = request.getSession();
		MMTI0217VO jmvo = new MMTI0217VO();

		jmvo.setMbl_snd_no(aes256Decrypt(StringUtil.nvl(request.getParameter("p"))));
		jmvo = mileageTobeService.getMMTI0217VO(jmvo);

		session.setAttribute("p", jmvo.getMbl_snd_no());
		request.setAttribute("p", StringUtil.nvl(request.getParameter("p")));
		request.setAttribute("jmvo", jmvo);
		
		return "/counter/carrider/tobe/up1";
	}

	@RequestMapping(value="/up2")
	public String up2(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		HttpSession session = request.getSession();
		MMTI0217VO jmvo = new MMTI0217VO();
		MMTI0213VO jmvo0213 = new MMTI0213VO();
		if(session.getAttribute("p") != null) {
			jmvo.setMbl_snd_no((String) session.getAttribute("p"));
		}
		else {
			jmvo.setMbl_snd_no(aes256Decrypt(StringUtil.nvl(request.getParameter("p"))));
		}
		jmvo = mileageTobeService.getMMTI0217VO(jmvo);

		request.setAttribute("p", StringUtil.nvl(request.getParameter("p")));
		request.setAttribute("jmvo", jmvo);
		
		// ocr 판독여부 가져오기
		for(int i=0; i<jmvo.getIner_mbl_snd_mtt__dst_tty_dvn().length; i++){
			if("01".equals(jmvo.getIner_mbl_snd_mtt__dst_tty_dvn()[i])){
				request.setAttribute("step", "01");
				jmvo0213.setSms_ts_bvan(jmvo.getIner_mbl_snd_mtt__pbox_no()[i]);
				jmvo0213 = mileageTobeService.getMMTI0213VO(jmvo0213);
				
				if("1".equals(jmvo0213.getO_c_r_cecd_yn())){
					request.setAttribute("ocr_yn", "1");
				}else{
					request.setAttribute("ocr_yn", "0");
				}
			}
		}
		
		return "/counter/carrider/tobe/up2";
	}
	
	//aiocr용
	@RequestMapping(value="/aiocr_up1")
	public String aiocr_up1(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		HttpSession session = request.getSession();
		MMTI0217VO jmvo = new MMTI0217VO();

		jmvo.setMbl_snd_no(aes256Decrypt(StringUtil.nvl(request.getParameter("p"))));
		jmvo = mileageTobeService.getMMTI0217VO(jmvo);

		session.setAttribute("p", jmvo.getMbl_snd_no());
		request.setAttribute("p", StringUtil.nvl(request.getParameter("p")));
		request.setAttribute("jmvo", jmvo);
		
		return "/counter/carrider/tobe/aiocr_up1";
	}
	
	//aiocr용
	@RequestMapping(value="/aiocr_up2")
	public String aiocr_up2(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		HttpSession session = request.getSession();
		MMTI0217VO jmvo = new MMTI0217VO();
		MMTI0213VO jmvo0213 = new MMTI0213VO();
		if(session.getAttribute("p") != null) {
			jmvo.setMbl_snd_no((String) session.getAttribute("p"));
		}
		else {
			jmvo.setMbl_snd_no(aes256Decrypt(StringUtil.nvl(request.getParameter("p"))));
		}
		jmvo = mileageTobeService.getMMTI0217VO(jmvo);

		request.setAttribute("p", StringUtil.nvl(request.getParameter("p")));
		request.setAttribute("jmvo", jmvo);
		
		// ocr 판독여부 가져오기
		for(int i=0; i<jmvo.getIner_mbl_snd_mtt__dst_tty_dvn().length; i++){
			if("01".equals(jmvo.getIner_mbl_snd_mtt__dst_tty_dvn()[i])){
				request.setAttribute("step", "01");
				jmvo0213.setSms_ts_bvan(jmvo.getIner_mbl_snd_mtt__pbox_no()[i]);
				jmvo0213 = mileageTobeService.getMMTI0213VO(jmvo0213);
				
				if("1".equals(jmvo0213.getO_c_r_cecd_yn())){
					request.setAttribute("ocr_yn", "1");
				}else{
					request.setAttribute("ocr_yn", "0");
				}
			}
		}
		
		return "/counter/carrider/tobe/aiocr_up2";
	}
	
	// 전자서명용 할인특약사진등록 추가
	@RequestMapping(value="/up3")
	public String up3(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		HttpSession session = request.getSession();

		MMTI0217VO jmvo = new MMTI0217VO();

		jmvo.setMbl_snd_no(aes256Decrypt(StringUtil.nvl(request.getParameter("p").replaceAll("/+/g", "%2B").replaceAll("/=/g","%3D").replaceAll("///g", "%2F").replaceAll(" ", "+"))));
		jmvo = mileageTobeService.getMMTI0217VO(jmvo);

		session.setAttribute("p", jmvo.getMbl_snd_no());
		logger.debug("up3 p = " + jmvo.getMbl_snd_no());
		request.setAttribute("p", StringUtil.nvl(request.getParameter("p")).replaceAll("/+/g", "%2B").replaceAll("/=/g","%3D").replaceAll("///g", "%2F").replaceAll(" ", "+").replaceAll("%20", "+"));
		logger.debug("up3 decode p = " + StringUtil.nvl(request.getParameter("p")).replaceAll("/+/g", "%2B").replaceAll("/=/g","%3D").replaceAll("///g", "%2F").replaceAll(" ", "+").replaceAll("%20", "+"));
		request.setAttribute("a", StringUtil.nvl(request.getParameter("a")).replaceAll("/+/g", "%2B").replaceAll("/=/g","%3D").replaceAll("///g", "%2F").replaceAll(" ", "+").replaceAll("%20", "+"));
		logger.debug("up3 decode a = " + StringUtil.nvl(request.getParameter("a")).replaceAll("/+/g", "%2B").replaceAll("/=/g","%3D").replaceAll("///g", "%2F").replaceAll(" ", "+").replaceAll("%20", "+"));
		request.setAttribute("pt", StringUtil.nvl(request.getParameter("pt")));
		request.setAttribute("chk", StringUtil.nvl(request.getParameter("chk")));
		request.setAttribute("mil_yn", StringUtil.nvl(request.getParameter("mil_yn"))); //주행거리대상여부
		request.setAttribute("bb_yn", StringUtil.nvl(request.getParameter("bb_yn"))); //블랙박스대상여부
		request.setAttribute("jmvo", jmvo);
		
		return "/counter/carrider/tobe/up3";
	}
	
	// 전자서명용 할인특약사진등록 추가
	@RequestMapping(value="/up4")
	public String up4(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		HttpSession session = request.getSession();
		MMTI0217VO jmvo = new MMTI0217VO();
		MMTI0213VO jmvo0213 = new MMTI0213VO();
		if(session.getAttribute("p") != null) {
			jmvo.setMbl_snd_no((String) session.getAttribute("p"));
		}
		else {
			jmvo.setMbl_snd_no(aes256Decrypt(StringUtil.nvl(request.getParameter("p"))));
		}
		jmvo = mileageTobeService.getMMTI0217VO(jmvo);

		request.setAttribute("p", StringUtil.nvl(request.getParameter("p").replaceAll("/+/g", "%2B").replaceAll("/=/g","%3D").replaceAll("///g", "%2F").replaceAll(" ", "+")));
		request.setAttribute("a", StringUtil.nvl(request.getParameter("a").replaceAll("/+/g", "%2B").replaceAll("/=/g","%3D").replaceAll("///g", "%2F").replaceAll(" ", "+")));
		logger.debug("up4 p = " + StringUtil.nvl(request.getParameter("p").replaceAll("/+/g", "%2B").replaceAll("/=/g","%3D").replaceAll("///g", "%2F").replaceAll(" ", "+")));
		logger.debug("up4 a = " + StringUtil.nvl(request.getParameter("a").replaceAll("/+/g", "%2B").replaceAll("/=/g","%3D").replaceAll("///g", "%2F").replaceAll(" ", "+")));
		request.setAttribute("pt", StringUtil.nvl(request.getParameter("pt")));
		request.setAttribute("chk", StringUtil.nvl(request.getParameter("chk")));
		request.setAttribute("mil_yn", StringUtil.nvl(request.getParameter("mil_yn")));
		request.setAttribute("bb_yn", StringUtil.nvl(request.getParameter("bb_yn")));
		request.setAttribute("jmvo", jmvo);
		
		// ocr 판독여부 가져오기
		for(int i=0; i<jmvo.getIner_mbl_snd_mtt__dst_tty_dvn().length; i++){
			if("01".equals(jmvo.getIner_mbl_snd_mtt__dst_tty_dvn()[i])){
				request.setAttribute("step", "01");
				jmvo0213.setSms_ts_bvan(jmvo.getIner_mbl_snd_mtt__pbox_no()[i]);
				jmvo0213 = mileageTobeService.getMMTI0213VO(jmvo0213);
				
				if("1".equals(jmvo0213.getO_c_r_cecd_yn())){
					request.setAttribute("ocr_yn", "1");
				}else{
					request.setAttribute("ocr_yn", "0");
				}
			}
		}
		
		return "/counter/carrider/tobe/up4";
	}
	
	// 전자서명용 할인특약사진등록 추가(aiocr용)
		@RequestMapping(value="/aiocr_up3")
		public String aiocr_up3(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
			HttpSession session = request.getSession();

			MMTI0217VO jmvo = new MMTI0217VO();

			jmvo.setMbl_snd_no(aes256Decrypt(StringUtil.nvl(request.getParameter("p").replaceAll("/+/g", "%2B").replaceAll("/=/g","%3D").replaceAll("///g", "%2F").replaceAll(" ", "+"))));
			jmvo = mileageTobeService.getMMTI0217VO(jmvo);

			session.setAttribute("p", jmvo.getMbl_snd_no());
			logger.debug("up3 p = " + jmvo.getMbl_snd_no());
			request.setAttribute("p", StringUtil.nvl(request.getParameter("p")).replaceAll("/+/g", "%2B").replaceAll("/=/g","%3D").replaceAll("///g", "%2F").replaceAll(" ", "+").replaceAll("%20", "+"));
			logger.debug("up3 decode p = " + StringUtil.nvl(request.getParameter("p")).replaceAll("/+/g", "%2B").replaceAll("/=/g","%3D").replaceAll("///g", "%2F").replaceAll(" ", "+").replaceAll("%20", "+"));
			request.setAttribute("a", StringUtil.nvl(request.getParameter("a")).replaceAll("/+/g", "%2B").replaceAll("/=/g","%3D").replaceAll("///g", "%2F").replaceAll(" ", "+").replaceAll("%20", "+"));
			logger.debug("up3 decode a = " + StringUtil.nvl(request.getParameter("a")).replaceAll("/+/g", "%2B").replaceAll("/=/g","%3D").replaceAll("///g", "%2F").replaceAll(" ", "+").replaceAll("%20", "+"));
			request.setAttribute("pt", StringUtil.nvl(request.getParameter("pt")));
			request.setAttribute("chk", StringUtil.nvl(request.getParameter("chk")));
			request.setAttribute("mil_yn", StringUtil.nvl(request.getParameter("mil_yn"))); //주행거리대상여부
			request.setAttribute("bb_yn", StringUtil.nvl(request.getParameter("bb_yn"))); //블랙박스대상여부
			request.setAttribute("jmvo", jmvo);
			
			return "/counter/carrider/tobe/aiocr_up3";
		}
		
		// 전자서명용 할인특약사진등록 추가(aiocr용)
		@RequestMapping(value="/aiocr_up4")
		public String aiocr_up4(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
			HttpSession session = request.getSession();
			MMTI0217VO jmvo = new MMTI0217VO();
			MMTI0213VO jmvo0213 = new MMTI0213VO();
			if(session.getAttribute("p") != null) {
				jmvo.setMbl_snd_no((String) session.getAttribute("p"));
			}
			else {
				jmvo.setMbl_snd_no(aes256Decrypt(StringUtil.nvl(request.getParameter("p"))));
			}
			jmvo = mileageTobeService.getMMTI0217VO(jmvo);

			request.setAttribute("p", StringUtil.nvl(request.getParameter("p").replaceAll("/+/g", "%2B").replaceAll("/=/g","%3D").replaceAll("///g", "%2F").replaceAll(" ", "+")));
			request.setAttribute("a", StringUtil.nvl(request.getParameter("a").replaceAll("/+/g", "%2B").replaceAll("/=/g","%3D").replaceAll("///g", "%2F").replaceAll(" ", "+")));
			logger.debug("up4 p = " + StringUtil.nvl(request.getParameter("p").replaceAll("/+/g", "%2B").replaceAll("/=/g","%3D").replaceAll("///g", "%2F").replaceAll(" ", "+")));
			logger.debug("up4 a = " + StringUtil.nvl(request.getParameter("a").replaceAll("/+/g", "%2B").replaceAll("/=/g","%3D").replaceAll("///g", "%2F").replaceAll(" ", "+")));
			request.setAttribute("pt", StringUtil.nvl(request.getParameter("pt")));
			request.setAttribute("chk", StringUtil.nvl(request.getParameter("chk")));
			request.setAttribute("mil_yn", StringUtil.nvl(request.getParameter("mil_yn")));
			request.setAttribute("bb_yn", StringUtil.nvl(request.getParameter("bb_yn")));
			request.setAttribute("jmvo", jmvo);
			
			// ocr 판독여부 가져오기
			for(int i=0; i<jmvo.getIner_mbl_snd_mtt__dst_tty_dvn().length; i++){
				if("01".equals(jmvo.getIner_mbl_snd_mtt__dst_tty_dvn()[i])){
					request.setAttribute("step", "01");
					jmvo0213.setSms_ts_bvan(jmvo.getIner_mbl_snd_mtt__pbox_no()[i]);
					jmvo0213 = mileageTobeService.getMMTI0213VO(jmvo0213);
					
					if("1".equals(jmvo0213.getO_c_r_cecd_yn())){
						request.setAttribute("ocr_yn", "1");
					}else{
						request.setAttribute("ocr_yn", "0");
					}
				}
			}
			
			return "/counter/carrider/tobe/aiocr_up4";
		}

	// 전자서명용 할인특약사진등록 추가(이륜차용)
	@RequestMapping(value="/up5")
	public String up5(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		HttpSession session = request.getSession();
		MMTI0213VO jmvo = new MMTI0213VO();

		logger.debug("/up5진입, num 변환 = " + request.getParameter("num").replaceAll("/+/g", "%2B").replaceAll("/=/g","%3D").replaceAll("///g", "%2F").replaceAll(" ", "+"));
		
		String num = request.getParameter("num").replaceAll("/+/g", "%2B").replaceAll("/=/g","%3D").replaceAll("///g", "%2F").replaceAll(" ", "+");
		logger.debug("MMTI0213 full num = " + num);

		jmvo.setSms_ts_bvan(aes256Decrypt(num));
		jmvo.setMtcc_yn(request.getParameter("mtcc_yn"));
		jmvo.setPdc_cd(request.getParameter("pdc_cd"));
		session.setAttribute("checkYn", request.getParameter("checkYn"));
		jmvo = mileageTobeService.getMMTI0213VO(jmvo);
		String view = "";
			
		if("2".equals(jmvo.getPbox_no_dvcd())) { // 블랙박스
			if("1".equals(jmvo.getMtcc_yn())||"20028".equals(jmvo.getPdc_cd())||"20030".equals(jmvo.getPdc_cd())||"20057".equals(jmvo.getPdc_cd())){ // 이륜차(오토바이) 블랙박스 장착인 경우
				view = "/counter/carrider/tobe/up5";
			} 
		}

		request.setAttribute("num", request.getParameter("num"));
		request.setAttribute("a", request.getParameter("a").replaceAll("/+/g", "%2B").replaceAll("/=/g","%3D").replaceAll("///g", "%2F").replaceAll(" ", "+"));
		request.setAttribute("pt", request.getParameter("pt"));
		request.setAttribute("mtcc_yn", jmvo.getMtcc_yn());
		request.setAttribute("pdc_cd", jmvo.getPdc_cd());
		request.setAttribute("jmvo", jmvo);
		return view;
	}
	
	// 전자서명용 할인특약사진등록 추가(이륜차용)
	@RequestMapping(value="/up6")
	public String up6(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		HttpSession session = request.getSession();
		MMTI0213VO jmvo = new MMTI0213VO();
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("num")));
		jmvo.setMtcc_yn(request.getParameter("mtcc_yn"));
		jmvo.setPdc_cd(request.getParameter("pdc_cd"));
		jmvo = mileageTobeService.getMMTI0213VO(jmvo);
		String checkYn = request.getParameter("checkYn");
		logger.debug(">>>> up6 checkYn = " + checkYn);
		String view = "";
		
		if("2".equals(jmvo.getPbox_no_dvcd())) { // 블랙박스
			if("1".equals(jmvo.getMtcc_yn())||"20028".equals(jmvo.getPdc_cd())||"20030".equals(jmvo.getPdc_cd())||"20057".equals(jmvo.getPdc_cd())){
				view = "/counter/carrider/tobe/up6"; //이륜차(오토바이) 블랙박스
			} 
		}

		request.setAttribute("num", request.getParameter("num"));
		session.setAttribute("checkYn", request.getParameter("checkYn"));
		request.setAttribute("mtcc_yn", jmvo.getMtcc_yn());
		request.setAttribute("pdc_cd", jmvo.getPdc_cd());
		request.setAttribute("a", request.getParameter("a"));
		request.setAttribute("pt", request.getParameter("pt"));
		request.setAttribute("chk", request.getParameter("chk"));
		request.setAttribute("jmvo", jmvo);
		return view;
	}

	@RequestMapping(value="/upStatus")
	public @ResponseBody Map<String, String> up_status(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		HttpSession session = request.getSession();
		Map<String, String> map = new HashMap<String, String>();
		MMTI0217VO jmvo = new MMTI0217VO();
		MMTI0218VO jmvo1 = new MMTI0218VO();

		if(session.getAttribute("p") != null) {
			jmvo.setMbl_snd_no((String) session.getAttribute("p"));
		}
		else {
			jmvo.setMbl_snd_no(aes256Decrypt(StringUtil.nvl(request.getParameter("p"))));
		}
		jmvo = mileageTobeService.getMMTI0217VO(jmvo);

		jmvo1.setMbl_snd_no(jmvo.getMbl_snd_no());
		jmvo1.setPlan_plno_dvcd(jmvo.getPlan_plno_dvcd());
		jmvo1.setPlan_plno(jmvo.getPlan_plno());
		jmvo1.setChng_plan_no(jmvo.getChng_plan_no());
		
		jmvo1 = mileageTobeService.getMMTI0218VO(jmvo1);
		for(int i = 0; i < jmvo1.getPhgp_regt_tgt__dst_tty_dvn().length; i++) {
			map.put("ok" + jmvo1.getPhgp_regt_tgt__dst_tty_dvn()[i], jmvo1.getPhgp_regt_tgt__phgp_regt_cplt_yn()[i]);
		}
		
		return map;
	}
	
	@RequestMapping(value="/upFileUpload")
	public @ResponseBody Map<String, String> upFileUpload(MultipartHttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		HttpSession session = request.getSession();
		Map<String, String> map = new HashMap<String, String>();
		String p = "";
		if(session.getAttribute("p") != null) {
			p = (String) session.getAttribute("p");
		}
		else {
			p = aes256Decrypt(StringUtil.nvl(request.getParameter("p")));
		}
		String dvn = StringUtil.nvl(request.getParameter("dvn"));
		String pbox_no = "";
		
		MBTR01001VO mbtr01001vo = new MBTR01001VO();
		MMTI0217VO jmvo = new MMTI0217VO();
		jmvo.setMbl_snd_no(p);
		jmvo = mileageTobeService.getMMTI0217VO(jmvo);
		
		if("01".equals(dvn) || "02".equals(dvn)) {
			try {
				for(int i = 0; i < jmvo.getIner_mbl_snd_mtt__dst_tty_dvn().length; i++) {
					if(dvn.equals(jmvo.getIner_mbl_snd_mtt__dst_tty_dvn()[i])) {
						pbox_no = jmvo.getIner_mbl_snd_mtt__pbox_no()[i];
						break;
					}
				}
				
				mbtr01001vo = mileageTobeService.regInfoToEdmsForMobileWeb(request, pbox_no, mbtr01001vo);
				
				MMTI0259VO jmvo1 = new MMTI0259VO();
				jmvo1.setPbox_use_yn("1");
				jmvo1.setPbox_no(pbox_no);
				jmvo1.setPhgp_cnfm_dt(DateUtil.getDate("yyyymmdd"));
				jmvo1.setPhgp_strg_yn("1");
				
				if(!"1".equals(jmvo.getCm_yn())) {
					jmvo1.setPbox_chr_nm(StringUtil.nvl(request.getParameter("mileage1")));
				}
				jmvo1 = mileageTobeService.getMMTI0259VO(jmvo1);
				
				int insertRow = 0;
				
				// VO SET
				mbtr01001vo.setPboxNo(jmvo1.getPbox_no());
				mbtr01001vo.setApdxFlRutNm("");
				mbtr01001vo.setFrstIpmnEmpno("82101685");
				mbtr01001vo.setFnalAmdrEmpno("82101685");
				
				if(mbtr01001vo.getProcRslMsgCn() != null){
					mbtr01001vo.getProcRslMsgCn();
					logger.info("#### procRslMsgCn = " + mbtr01001vo.getProcRslMsgCn());
				}
				
				insertRow = mileageTobeService.insertTest(mbtr01001vo);
				if(insertRow < 1){
					logger.info("#### 사서함번호: " + StringUtil.nvl(mbtr01001vo.getPboxNo()) + "####");
					logger.info("#### insert 결과: Fail ####");
				}else{
					logger.info("#### insert 결과: Success ####");
				}
				
				map.put("errorCode", jmvo1.getErrorCode());
			}
			catch(Exception e) {
				logger.debug(e.getMessage());
				map.put("errorCode", "-1");
			}
		}
		else if("03".equals(dvn) || "04".equals(dvn) || "05".equals(dvn)) {
			MMTI0289VO jmvo1 = new MMTI0289VO();
			
			jmvo1.setMbl_snd_no(p);
			jmvo1.setMbl_ts_dtl_dvcd("01");
			jmvo1.setPlan_plno(jmvo.getPlan_plno());
			
			if("03".equals(dvn)) jmvo1.setMbl_bz_dvcd("35");
			if("04".equals(dvn)) jmvo1.setMbl_bz_dvcd("43");
			if("05".equals(dvn)) jmvo1.setMbl_bz_dvcd("55");
			
			try {
				mileageTobeService.regInfoToEdmsForMobileWeb(request, jmvo1);
				map.put("errorCode", "0");
			}
			catch(Exception e) {
				logger.debug(e.getMessage());
				map.put("errorCode", "-1");
			}
		}
		
		if("0".equals(map.get("errorCode"))) {
			MMTI0218VO jmvo1 = new MMTI0218VO();
	
			jmvo1.setMbl_snd_no(jmvo.getMbl_snd_no());
			jmvo1.setPlan_plno_dvcd(jmvo.getPlan_plno_dvcd());
			jmvo1.setPlan_plno(jmvo.getPlan_plno());
			jmvo1.setChng_plan_no(jmvo.getChng_plan_no());
			
			jmvo1 = mileageTobeService.getMMTI0218VO(jmvo1);
			int count = 0;
			for(int i = 0; i < jmvo1.getPhgp_regt_tgt__dst_tty_dvn().length; i++) {
				if("Y".equals(jmvo1.getPhgp_regt_tgt__phgp_regt_cplt_yn()[i]) || "1".equals(jmvo1.getPhgp_regt_tgt__phgp_regt_cplt_yn()[i])) count++;
			}
			
			if(count > 0 && count == jmvo1.getPhgp_regt_tgt__dst_tty_dvn().length) map.put("errorCode", "1");
		}

		return map;
	}
	
	//aiocr용
	@RequestMapping(value="/aiocrUpFileUpload")
	public @ResponseBody Map<String, String> aiocrUpFileUpload(MultipartHttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		HttpSession session = request.getSession();
		Map<String, String> map = new HashMap<String, String>();
		String p = "";
		if(session.getAttribute("p") != null) {
			p = (String) session.getAttribute("p");
		}
		else {
			p = aes256Decrypt(StringUtil.nvl(request.getParameter("p")));
		}
		String dvn = StringUtil.nvl(request.getParameter("dvn"));
		String pbox_no = "";
		
		MBTR01001VO mbtr01001vo = new MBTR01001VO();
		MMTI0217VO jmvo = new MMTI0217VO();
		jmvo.setMbl_snd_no(p);
		jmvo = mileageTobeService.getMMTI0217VO(jmvo);
		
		if("01".equals(dvn) || "02".equals(dvn)) {
			try {
				for(int i = 0; i < jmvo.getIner_mbl_snd_mtt__dst_tty_dvn().length; i++) {
					if(dvn.equals(jmvo.getIner_mbl_snd_mtt__dst_tty_dvn()[i])) {
						pbox_no = jmvo.getIner_mbl_snd_mtt__pbox_no()[i];
						break;
					}
				}
				
				mbtr01001vo = mileageTobeService.aiocrRegInfoToEdmsForMobileWeb(request, pbox_no, mbtr01001vo);
				
				MMTI0259VO jmvo1 = new MMTI0259VO();
				jmvo1.setPbox_use_yn("1");
				jmvo1.setPbox_no(pbox_no);
				jmvo1.setPhgp_cnfm_dt(DateUtil.getDate("yyyymmdd"));
				jmvo1.setPhgp_strg_yn("1");
				
				if(!"1".equals(jmvo.getCm_yn())) {
					jmvo1.setPbox_chr_nm(StringUtil.nvl(request.getParameter("mileage1")));
				}
				jmvo1 = mileageTobeService.getMMTI0259VO(jmvo1);
				
				int insertRow = 0;
				
				// VO SET
				mbtr01001vo.setPboxNo(jmvo1.getPbox_no());
				mbtr01001vo.setApdxFlRutNm("");
				mbtr01001vo.setFrstIpmnEmpno("82101685");
				mbtr01001vo.setFnalAmdrEmpno("82101685");
				
				if(mbtr01001vo.getProcRslMsgCn() != null){
					mbtr01001vo.getProcRslMsgCn();
					logger.info("#### procRslMsgCn = " + mbtr01001vo.getProcRslMsgCn());
				}
				
				insertRow = mileageTobeService.insertTest(mbtr01001vo);
				if(insertRow < 1){
					logger.info("#### 사서함번호: " + StringUtil.nvl(mbtr01001vo.getPboxNo()) + "####");
					logger.info("#### insert 결과: Fail ####");
				}else{
					logger.info("#### insert 결과: Success ####");
				}
				
				map.put("errorCode", jmvo1.getErrorCode());
			}
			catch(Exception e) {
				logger.debug(e.getMessage());
				map.put("errorCode", "-1");
			}
		}
		else if("03".equals(dvn) || "04".equals(dvn) || "05".equals(dvn)) {
			MMTI0289VO jmvo1 = new MMTI0289VO();
			
			jmvo1.setMbl_snd_no(p);
			jmvo1.setMbl_ts_dtl_dvcd("01");
			jmvo1.setPlan_plno(jmvo.getPlan_plno());
			
			if("03".equals(dvn)) jmvo1.setMbl_bz_dvcd("35");
			if("04".equals(dvn)) jmvo1.setMbl_bz_dvcd("43");
			if("05".equals(dvn)) jmvo1.setMbl_bz_dvcd("55");
			
			try {
				mileageTobeService.regInfoToEdmsForMobileWeb(request, jmvo1);
				map.put("errorCode", "0");
			}
			catch(Exception e) {
				logger.debug(e.getMessage());
				map.put("errorCode", "-1");
			}
		}
		
		if("0".equals(map.get("errorCode"))) {
			MMTI0218VO jmvo1 = new MMTI0218VO();
	
			jmvo1.setMbl_snd_no(jmvo.getMbl_snd_no());
			jmvo1.setPlan_plno_dvcd(jmvo.getPlan_plno_dvcd());
			jmvo1.setPlan_plno(jmvo.getPlan_plno());
			jmvo1.setChng_plan_no(jmvo.getChng_plan_no());
			
			jmvo1 = mileageTobeService.getMMTI0218VO(jmvo1);
			int count = 0;
			for(int i = 0; i < jmvo1.getPhgp_regt_tgt__dst_tty_dvn().length; i++) {
				if("Y".equals(jmvo1.getPhgp_regt_tgt__phgp_regt_cplt_yn()[i]) || "1".equals(jmvo1.getPhgp_regt_tgt__phgp_regt_cplt_yn()[i])) count++;
			}
			
			if(count > 0 && count == jmvo1.getPhgp_regt_tgt__dst_tty_dvn().length) map.put("errorCode", "1");
		}

		return map;
	}
	
	@RequestMapping(value="/upFileUploadTest")
	public @ResponseBody Map<String, String> upFileUploadTest(MultipartHttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		HttpSession session = request.getSession();
		Map<String, String> map = new HashMap<String, String>();
		String p = "";
		if(session.getAttribute("p") != null) {
			p = (String) session.getAttribute("p");
		}
		else {
			p = aes256Decrypt(StringUtil.nvl(request.getParameter("p")));
		}
		String dvn = StringUtil.nvl(request.getParameter("dvn"));
		String pbox_no = "";
		
		MMTI0217VO jmvo = new MMTI0217VO();
		jmvo.setMbl_snd_no(p);
		jmvo = mileageTobeService.getMMTI0217VO(jmvo);
		
		if("01".equals(dvn) || "02".equals(dvn)) {
			try {
				for(int i = 0; i < jmvo.getIner_mbl_snd_mtt__dst_tty_dvn().length; i++) {
					if(dvn.equals(jmvo.getIner_mbl_snd_mtt__dst_tty_dvn()[i])) {
						pbox_no = jmvo.getIner_mbl_snd_mtt__pbox_no()[i];
						break;
					}
				}
				
				mileageTobeService.regInfoToEdmsForMobileWeb(request, pbox_no);
				
				MMTI0259VO jmvo1 = new MMTI0259VO();
				jmvo1.setPbox_use_yn("1");
				jmvo1.setPbox_no(pbox_no);
				jmvo1.setPhgp_cnfm_dt(DateUtil.getDate("yyyymmdd"));
				jmvo1.setPhgp_strg_yn("1");
				
				if(!"1".equals(jmvo.getCm_yn())) {
					jmvo1.setPbox_chr_nm(StringUtil.nvl(request.getParameter("mileage1")));
				}
				jmvo1 = mileageTobeService.getMMTI0259VO(jmvo1);
				
				map.put("errorCode", jmvo1.getErrorCode());
			}
			catch(Exception e) {
				logger.debug(e.getMessage());
				map.put("errorCode", "-1");
			}
		}
		
		if("0".equals(map.get("errorCode"))) {
			MMTI0218VO jmvo1 = new MMTI0218VO();
	
			jmvo1.setMbl_snd_no(jmvo.getMbl_snd_no());
			jmvo1.setPlan_plno_dvcd(jmvo.getPlan_plno_dvcd());
			jmvo1.setPlan_plno(jmvo.getPlan_plno());
			jmvo1.setChng_plan_no(jmvo.getChng_plan_no());
			
			jmvo1 = mileageTobeService.getMMTI0218VO(jmvo1);
			int count = 0;
			for(int i = 0; i < jmvo1.getPhgp_regt_tgt__dst_tty_dvn().length; i++) {
				if("Y".equals(jmvo1.getPhgp_regt_tgt__phgp_regt_cplt_yn()[i]) || "1".equals(jmvo1.getPhgp_regt_tgt__phgp_regt_cplt_yn()[i])) count++;
			}
			
			if(count > 0 && count == jmvo1.getPhgp_regt_tgt__dst_tty_dvn().length) map.put("errorCode", "1");
		}

		return map;
	}	
	
	//aiocr용
	@RequestMapping(value="/aiocrUpFileUploadTest")
	public @ResponseBody Map<String, String> aiocrUpFileUploadTest(MultipartHttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		HttpSession session = request.getSession();
		Map<String, String> map = new HashMap<String, String>();
		String p = "";
		if(session.getAttribute("p") != null) {
			p = (String) session.getAttribute("p");
		}
		else {
			p = aes256Decrypt(StringUtil.nvl(request.getParameter("p")));
		}
		String dvn = StringUtil.nvl(request.getParameter("dvn"));
		String pbox_no = "";
		
		MMTI0217VO jmvo = new MMTI0217VO();
		jmvo.setMbl_snd_no(p);
		jmvo = mileageTobeService.getMMTI0217VO(jmvo);
		
		if("01".equals(dvn) || "02".equals(dvn)) {
			try {
				for(int i = 0; i < jmvo.getIner_mbl_snd_mtt__dst_tty_dvn().length; i++) {
					if(dvn.equals(jmvo.getIner_mbl_snd_mtt__dst_tty_dvn()[i])) {
						pbox_no = jmvo.getIner_mbl_snd_mtt__pbox_no()[i];
						break;
					}
				}
				
				mileageTobeService.aiocrRegInfoToEdmsForMobileWeb(request, pbox_no);
				
				MMTI0259VO jmvo1 = new MMTI0259VO();
				jmvo1.setPbox_use_yn("1");
				jmvo1.setPbox_no(pbox_no);
				jmvo1.setPhgp_cnfm_dt(DateUtil.getDate("yyyymmdd"));
				jmvo1.setPhgp_strg_yn("1");
				
				if(!"1".equals(jmvo.getCm_yn())) {
					jmvo1.setPbox_chr_nm(StringUtil.nvl(request.getParameter("mileage1")));
				}
				jmvo1 = mileageTobeService.getMMTI0259VO(jmvo1);
				
				map.put("errorCode", jmvo1.getErrorCode());
			}
			catch(Exception e) {
				logger.debug(e.getMessage());
				map.put("errorCode", "-1");
			}
		}
		
		if("0".equals(map.get("errorCode"))) {
			MMTI0218VO jmvo1 = new MMTI0218VO();
	
			jmvo1.setMbl_snd_no(jmvo.getMbl_snd_no());
			jmvo1.setPlan_plno_dvcd(jmvo.getPlan_plno_dvcd());
			jmvo1.setPlan_plno(jmvo.getPlan_plno());
			jmvo1.setChng_plan_no(jmvo.getChng_plan_no());
			
			jmvo1 = mileageTobeService.getMMTI0218VO(jmvo1);
			int count = 0;
			for(int i = 0; i < jmvo1.getPhgp_regt_tgt__dst_tty_dvn().length; i++) {
				if("Y".equals(jmvo1.getPhgp_regt_tgt__phgp_regt_cplt_yn()[i]) || "1".equals(jmvo1.getPhgp_regt_tgt__phgp_regt_cplt_yn()[i])) count++;
			}
			
			if(count > 0 && count == jmvo1.getPhgp_regt_tgt__dst_tty_dvn().length) map.put("errorCode", "1");
		}

		return map;
	}
	
	@RequestMapping(value="/upMileageStep2")
	public @ResponseBody Map<String, String> upMileageStep2(MultipartHttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		HttpSession session = request.getSession();
		Map<String, String> map = new HashMap<String, String>();
		String yyyymmdd = DateUtil.getDate("yyyymmdd");
		
		String phgp_rl_ptgr_dt			= StringUtil.nvl(request.getParameter("phgp_rl_ptgr_dt"));			// 사진실제촬영일자
		String phgp_apdx_way_cd			= StringUtil.nvl(request.getParameter("phgp_apdx_way_cd"));			// 사진첨부방식코드
		
		MMTI0217VO jmvo0217 = new MMTI0217VO();
		MMTI0213VO jmvo0213 = new MMTI0213VO();
		
		if(session.getAttribute("p") != null) {
			jmvo0217.setMbl_snd_no((String) session.getAttribute("p"));
		}
		else {
			jmvo0217.setMbl_snd_no(aes256Decrypt(StringUtil.nvl(request.getParameter("p"))));
		}
		jmvo0217 = mileageTobeService.getMMTI0217VO(jmvo0217);
		
		for(int i=0; i<jmvo0217.getIner_mbl_snd_mtt__dst_tty_dvn().length; i++){
			if("01".equals(jmvo0217.getIner_mbl_snd_mtt__dst_tty_dvn()[i])){
				jmvo0213.setSms_ts_bvan(jmvo0217.getIner_mbl_snd_mtt__pbox_no()[i]);
				jmvo0213 = mileageTobeService.getMMTI0213VO(jmvo0213);
				if("1".equals(jmvo0213.getO_c_r_cecd_yn())){
					request.setAttribute("ocr_yn", "1");
				}else{
					request.setAttribute("ocr_yn", "0");
				}
				// request.setAttribute("ocr_yn", jmvo0213.getO_c_r_cecd_yn());
			}
		}
		
		String exifDate1 = StringUtil.nvl(request.getParameter("exifDate1"));
		
		if(exifDate1.indexOf(",gallery") > -1) {
			exifDate1 = exifDate1.substring(0, exifDate1.indexOf(",gallery"));
			if(StringUtil.isEmpty(exifDate1)) {
				exifDate1 = DateUtil.getDate();
			}
			else if(Integer.parseInt(exifDate1) > Integer.parseInt(DateUtil.getDate())) {
				map.put("errorCode", "f");
				return map;
			}
		}

		if(exifDate1.indexOf(",gallery") > -1) {
			exifDate1 = exifDate1.substring(0, exifDate1.indexOf(",gallery"));
		}

		ArrayList<File> files = mileageTobeService.uploadToWAS(request, jmvo0213.getSms_ts_bvan());
		
		String aut_cgnt_trv_dstc_rsl_cd = "";	// 자동인식주행거리결과코드
		String aut_cgnt_vh_no_rsl_cd = "";		// 자동인식차량번호결과코드
		String aut_cgnt_trv_dstc = "";			// 자동인식주행거리
		String aut_cgnt_vh_no = "";				// 자동인식차량번호
		
		String aut_cgnt_trv_dstc_1 = "";		// 자동인식주행거리1
		String aut_cgnt_trv_dstc_2 = "";		// 자동인식주행거리2
		String aut_cgnt_trv_dstc_3 = "";		// 자동인식주행거리3
		
		
		boolean flag1 = false;
		if(files.size() > 0) {
			FTPUtil ftp = null;
			FileInputStream in = null;
			FileInputStream fis = null;
			FileOutputStream out = null;
			
			try {
				if("1".equals(jmvo0213.getAut_cgnt_nn_apcn_yn())) { // OCR서버 문제있으면...
					aut_cgnt_trv_dstc_rsl_cd = "03";
					aut_cgnt_vh_no_rsl_cd = "03";
				}
				else {
					String propsPath = this.getClass().getResource("").getPath();
					propsPath = propsPath.substring(0, propsPath.indexOf("/classes/")) + "/config/ocr_ftp.properties";
					Properties p = new Properties();
					in = new FileInputStream(propsPath);
					p.load(in);
					in.close();
					in = null;
					
					String password = p.getProperty("password");
					String decPassword = aes256Decrypt(password);
					if(password.equals(decPassword) || StringUtil.isEmpty(decPassword)) {
						decPassword = password;
						String encPassword = aes256Encrypt(password);
						logger.debug("encPassword: " + encPassword);
						out = new FileOutputStream(propsPath);
						p.setProperty("password", encPassword);
						p.store(out, "");
						out.close();
						out = null;
					}
					
					ftp = new FTPUtil(p.getProperty("ip"), p.getProperty("user"), decPassword, Integer.parseInt(p.getProperty("port")));
					
					int working = 0;
					for(int i = 1; i <= 3; i++) {
						String[] ls = ftp.ls("/RECOG_JOB" + i + "/" + yyyymmdd);
						for(int j = 0; j < ls.length; j++) {
							if(".".equals(ls[j]) || "..".equals(ls[j])) continue;
							working++;
						}
					}
	
					if(working <= 6) {
						String filename1 = "";
						filename1 = ftp.uploadToOCR("/RECOG/" + yyyymmdd, files.get(0), "--D");
						logger.debug("filename1: " + filename1);
						logger.debug("--- 1초 대기 ---");
						Thread.sleep(1000);
						int retryNum = 7;
						for(int retry = 0; retry < retryNum; retry++) {
							String[] ls = ftp.ls("/RECOG_RESULT/" + yyyymmdd);
							for(int i = 0; i < ls.length; i++) {
								if(!flag1 && ls[i].equals(filename1)) {
									flag1 = true;
								}
								if(flag1) break;
							}
							if((flag1) || retry == retryNum - 1) {
								break;
							}
							else {
								logger.debug("--- 0.6초 대기 ---");
								Thread.sleep(600);
							}
						}
						
						logger.debug("flag1: " + flag1);
						
						if(flag1) {
							if(filename1 != null || !"".equals(filename1)){
								filename1 = filename1.replaceAll("/", "");
								filename1 = filename1.replaceAll("\\\\", "");
								filename1 = filename1.replaceAll("./", "");
								filename1 = filename1.replaceAll("../", "");
								filename1 = filename1.replaceAll("&", "");
							}
							
							String path = files.get(0).getParent() + File.separator + filename1;
							ftp.downloadFromOCR("/RECOG_RESULT/" + yyyymmdd, filename1, path);
							logger.debug("path: " + path);
							
							File f = new File(files.get(0).getParent() + File.separator + filename1);
		
							if(f.exists()) {
								Properties props = new Properties();
								fis = new FileInputStream(files.get(0).getParent() + File.separator + filename1);
								props.load(fis);
								fis.close();
								fis = null;
								
								if(!StringUtil.isEmpty(props.getProperty("ODO")) && !StringUtil.isEmpty(props.getProperty("RE_CODE"))) {
									aut_cgnt_trv_dstc = props.getProperty("ODO");
									aut_cgnt_trv_dstc_rsl_cd = "1".equals(props.getProperty("RE_CODE")) || "2".equals(props.getProperty("RE_CODE")) ? "01" : "02";
									
									aut_cgnt_trv_dstc_1 = props.getProperty("ODO");
									
									if(!StringUtil.isEmpty(props.getProperty("ODO2"))) {
										aut_cgnt_trv_dstc_2 = props.getProperty("ODO2");
									}
									
									if(!StringUtil.isEmpty(props.getProperty("ODO3"))) {
										aut_cgnt_trv_dstc_3 = props.getProperty("ODO3");
									}
								}
								
				            	if(f.delete()) {
									logger.debug("삭제: " + path);
								}
							}
						}
						else {
							aut_cgnt_trv_dstc_rsl_cd = "02";
						}						
					}
					else {
						aut_cgnt_trv_dstc_rsl_cd = "02";
						aut_cgnt_vh_no_rsl_cd = "02";
					}
				}
			}
			catch(Exception e) {
				logger.debug(e.getMessage());
				aut_cgnt_trv_dstc_rsl_cd = "02";
				aut_cgnt_vh_no_rsl_cd = "02";
			}
			finally {
				if(ftp != null) ftp.disconnect();
				try{
		    	  	if(in != null){
		    	  		in.close();
		    	  	}
			      }catch(IOException ee){
			    	  System.err.println("[MileageTobeController.upMileageStep2()] IOException 1");
			      }
				try{
		    	  	if(out != null){
		    	  		out.close();
		    	  	}
			      }catch(IOException ee){
			    	  System.err.println("[MileageTobeController.upMileageStep2()] IOException 2");
			      }
				try{
		    	  	if(fis != null){
		    	  		fis.close();
		    	  	}
			      }catch(IOException ee){
			    	  System.err.println("[MileageTobeController.upMileageStep2()] IOException 3");
			      }
			}
		}
		
		Object[] imgfile = new Object[files.size()];
		// [200617]
		FileInputStream fis = null;
		try {
			for(int i = 0; i < files.size(); i++) {
				File f = files.get(i);
				fis = new FileInputStream(f);
				byte[] file = new byte[(int) f.length()];
				fis.read(file);
				imgfile[i] = file;
				fis.close();
				fis = null;
				String fname = f.getName();
				f.delete();
				logger.debug(fname + " 삭제");
			}
		} catch (Exception e) {
			System.err.println("[MileageTobeController.upMileageStep2()] Exception");
		}
		finally {
			try{
				if(fis!=null){
					fis.close();
				}
			}
			catch(IOException ee){
				System.err.println("[MileageTobeController.upMileageStep2()] IOException 4");
		    }
		}
		session.setAttribute("imgfile", imgfile);
		
		// 주행거리 가입 확정처리 분기용 OCR 판독여부
		session.setAttribute("aut_cgnt_trv_dstc_rsl_cd", aut_cgnt_trv_dstc_rsl_cd);
		
		// 계좌환급 완료분기 신규 설계 보종 기준으로 해야함
		session.setAttribute("n_cm_yn", jmvo0213.getCm_yn());
		
		map.put("errorCode",					"0");
		map.put("aut_cgnt_trv_dstc_rsl_cd",		aut_cgnt_trv_dstc_rsl_cd);
		map.put("aut_cgnt_vh_no_rsl_cd",		aut_cgnt_vh_no_rsl_cd);
		map.put("aut_cgnt_trv_dstc",			aut_cgnt_trv_dstc);
		map.put("aut_cgnt_vh_no",				aut_cgnt_vh_no);
		map.put("aut_cgnt_trv_dstc_1",			aut_cgnt_trv_dstc_1);
		map.put("aut_cgnt_trv_dstc_2",			aut_cgnt_trv_dstc_2);
		map.put("aut_cgnt_trv_dstc_3",			aut_cgnt_trv_dstc_3);
		map.put("phgp_rl_ptgr_dt",				phgp_rl_ptgr_dt);
		map.put("phgp_apdx_way_cd",				phgp_apdx_way_cd);
			
		return map;
	}
	
	//aiocr용
	@RequestMapping(value="/aiocrUpMileageStep2")
	public @ResponseBody Map<String, String> aiocrUpMileageStep2(MultipartHttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		HttpSession session = request.getSession();
		Map<String, String> map = new HashMap<String, String>();
		String yyyymmdd = DateUtil.getDate("yyyymmdd");
		
		String phgp_rl_ptgr_dt			= StringUtil.nvl(request.getParameter("phgp_rl_ptgr_dt"));			// 사진실제촬영일자
		String phgp_apdx_way_cd			= StringUtil.nvl(request.getParameter("phgp_apdx_way_cd"));			// 사진첨부방식코드
		
		MMTI0217VO jmvo0217 = new MMTI0217VO();
		MMTI0213VO jmvo0213 = new MMTI0213VO();
		
		if(session.getAttribute("p") != null) {
			jmvo0217.setMbl_snd_no((String) session.getAttribute("p"));
		}
		else {
			jmvo0217.setMbl_snd_no(aes256Decrypt(StringUtil.nvl(request.getParameter("p"))));
		}
		jmvo0217 = mileageTobeService.getMMTI0217VO(jmvo0217);
		
		for(int i=0; i<jmvo0217.getIner_mbl_snd_mtt__dst_tty_dvn().length; i++){
			if("01".equals(jmvo0217.getIner_mbl_snd_mtt__dst_tty_dvn()[i])){
				jmvo0213.setSms_ts_bvan(jmvo0217.getIner_mbl_snd_mtt__pbox_no()[i]);
				jmvo0213 = mileageTobeService.getMMTI0213VO(jmvo0213);
				if("1".equals(jmvo0213.getO_c_r_cecd_yn())){
					request.setAttribute("ocr_yn", "1");
				}else{
					request.setAttribute("ocr_yn", "0");
				}
				// request.setAttribute("ocr_yn", jmvo0213.getO_c_r_cecd_yn());
			}
		}
		
		String exifDate1 = StringUtil.nvl(request.getParameter("exifDate1"));
		
		if(exifDate1.indexOf(",gallery") > -1) {
			exifDate1 = exifDate1.substring(0, exifDate1.indexOf(",gallery"));
			if(StringUtil.isEmpty(exifDate1)) {
				exifDate1 = DateUtil.getDate();
			}
			else if(Integer.parseInt(exifDate1) > Integer.parseInt(DateUtil.getDate())) {
				map.put("errorCode", "f");
				return map;
			}
		}

		if(exifDate1.indexOf(",gallery") > -1) {
			exifDate1 = exifDate1.substring(0, exifDate1.indexOf(",gallery"));
		}

		ArrayList<File> files = mileageTobeService.aiocrUploadToWAS(request, jmvo0213.getSms_ts_bvan());
		
		String aut_cgnt_trv_dstc_rsl_cd = "";	// 자동인식주행거리결과코드
		String aut_cgnt_vh_no_rsl_cd = "";		// 자동인식차량번호결과코드
		String aut_cgnt_trv_dstc = "";			// 자동인식주행거리
		String aut_cgnt_vh_no = "";				// 자동인식차량번호
		
		String aut_cgnt_trv_dstc_1 = "";		// 자동인식주행거리1
		String aut_cgnt_trv_dstc_2 = "";		// 자동인식주행거리2
		String aut_cgnt_trv_dstc_3 = "";		// 자동인식주행거리3
		
		String a_i_o_c_r_rqst_dsky_val	= "";	// aiocr요청구분키값
		String a_i_o_c_r_resultCode 	= "";	// aiocr요청결과코드값
		String resultValue 				= "";	// 주행거리값1
		String dtcn_cgnt_rt 			= "";	// 검출인식률1
		String cgnt_cgnt_rt 			= "";	// 인식인식률1
		String resultValue2 			= "";	// 주행거리값2
		String dtcn_cgnt_rt2 			= "";	// 검출인식률2
		String cgnt_cgnt_rt2 			= "";	// 인식인식률2
		String resultValue3 			= "";	// 주행거리값3
		String dtcn_cgnt_rt3 			= "";	// 검출인식률3
		String cgnt_cgnt_rt3 			= "";	// 인식인식률3
		String RE_CODE 					= "";
		
		HashMap<String, String> resultMap = null;
		
		boolean flag1 = false;
		if(files.size() > 0) {
			FTPUtil ftp = null;
			FileInputStream in = null;
			FileInputStream fis = null;
			FileOutputStream out = null;
			
			HttpResponse httpResp = null;
			HttpEntity respEntity = null;
			
			resultMap = new HashMap<String, String>();
			
			try {
				if("1".equals(jmvo0213.getAut_cgnt_nn_apcn_yn())) { // OCR서버 문제있으면...
					aut_cgnt_trv_dstc_rsl_cd = "03";
					aut_cgnt_vh_no_rsl_cd = "03";
				}
				else {
					String propsPath = this.getClass().getResource("").getPath();
					propsPath = propsPath.substring(0, propsPath.indexOf("/classes/")) + "/config/aiocr_ftp.properties";
					
					String aiocrURL = AIOCR_SERVER_PATH;
					CloseableHttpClient httpClient = HttpClients.createDefault();
					HttpPost httpPost = new HttpPost(aiocrURL);
					
					HttpEntity httpEntity = MultipartEntityBuilder.create()
							.addTextBody("templateName", "car.drivingdistance.workflow")
							.addTextBody("senderName", "SMZ")
							.addBinaryBody("Files", new File(files.get(0).toString()), ContentType.MULTIPART_FORM_DATA, files.get(0).toString()).build();
					
					httpPost.setEntity(httpEntity);
					
					CloseableHttpResponse response1 = httpClient.execute(httpPost);
					
					logger.debug("========== start ==========");
					logger.debug("Status Code : " + response1.getStatusLine().getStatusCode());
					logger.debug("========== end ==========");
					
					// json param setting start
					respEntity = response1.getEntity();
					
					String jsonResp = EntityUtils.toString(respEntity);
					logger.debug("AI OCR uploadAiOCR("+files.get(0).toString()+") 응답 json : " + jsonResp);
					
					JSONParser jsonParser = new JSONParser();
					JSONObject jsonObj = (JSONObject) jsonParser.parse(jsonResp);
					JSONArray jsonArray = (JSONArray) jsonObj.get("results");
					
					a_i_o_c_r_rqst_dsky_val	= (String) jsonObj.get("resultItemKey");	// aiocr요청구분키값
					a_i_o_c_r_resultCode = (String) jsonObj.get("resultCode"); // aiocr요청결과코드값(01:정상, 11~33:오류)
					
					if(response1.getStatusLine().getStatusCode() == 200){
						
						logger.debug("[거울]jsonArray : " + jsonArray.get(0) + "jsonArray size : " + jsonArray.size());
						
						if(jsonResp != null){
//							String ocrResultCode = (String) jsonObj.get("resultCode");
							if(!StringUtil.isEmpty(a_i_o_c_r_resultCode)){
								if("01".equals(a_i_o_c_r_resultCode)){
									if(jsonArray.size() > 0) {
										resultMap.put("RE_CODE", "2");
										aut_cgnt_trv_dstc_rsl_cd = "01";
										for(int s = 0; s < jsonArray.size(); s++){
											if(s == 0) {
												JSONObject jsonObject = (JSONObject) jsonArray.get(0);
												logger.debug("new resultValue = " + (String)jsonObject.get("resultValue"));
												logger.debug("new detectionConfidence = " + (String)jsonObject.get("detectionConfidence"));
												logger.debug("new recognitionConfidence = " + (String)jsonObject.get("recognitionConfidence"));
												
												resultMap.put("resultValue", (String)jsonObject.get("resultValue"));
												resultMap.put("detectionConfidence", (String)jsonObject.get("detectionConfidence"));
												resultMap.put("recognitionConfidence", (String)jsonObject.get("recognitionConfidence"));
											} else if(s == 1) {
												JSONObject jsonObject = (JSONObject) jsonArray.get(1);
												logger.debug("new resultValue2 = " + (String)jsonObject.get("resultValue"));
												logger.debug("new detectionConfidence2 = " + (String)jsonObject.get("detectionConfidence"));
												logger.debug("new recognitionConfidence2 = " + (String)jsonObject.get("recognitionConfidence"));
												
												resultMap.put("resultValue2", (String)jsonObject.get("resultValue"));
												resultMap.put("detectionConfidence2", (String)jsonObject.get("detectionConfidence"));
												resultMap.put("recognitionConfidence2", (String)jsonObject.get("recognitionConfidence"));
											} else {
												JSONObject jsonObject = (JSONObject) jsonArray.get(2);
												logger.debug("new resultValue3 = " + (String)jsonObject.get("resultValue"));
												logger.debug("new detectionConfidence3 = " + (String)jsonObject.get("detectionConfidence"));
												logger.debug("new recognitionConfidence3 = " + (String)jsonObject.get("recognitionConfidence"));
												
												resultMap.put("resultValue3", (String)jsonObject.get("resultValue"));
												resultMap.put("detectionConfidence3", (String)jsonObject.get("detectionConfidence"));
												resultMap.put("recognitionConfidence3", (String)jsonObject.get("recognitionConfidence"));
											}
										
											resultValue				= StringUtil.nvl((String)resultMap.get("resultValue"));			// 주행거리 인식값1
											dtcn_cgnt_rt 			= StringUtil.nvl((String)resultMap.get("detectionConfidence"));	// 검출인식률1
											cgnt_cgnt_rt 			= StringUtil.nvl((String)resultMap.get("recognitionConfidence"));	// 인식인식률1
											resultValue2			= StringUtil.nvl((String)resultMap.get("resultValue2"));			// 주행거리 인식값1
											dtcn_cgnt_rt2 			= StringUtil.nvl((String)resultMap.get("detectionConfidence2"));	// 검출인식률1
											cgnt_cgnt_rt2 			= StringUtil.nvl((String)resultMap.get("recognitionConfidence2"));	// 인식인식률1
											resultValue3			= StringUtil.nvl((String)resultMap.get("resultValue3"));			// 주행거리 인식값1
											dtcn_cgnt_rt3 			= StringUtil.nvl((String)resultMap.get("detectionConfidence3"));	// 검출인식률1
											cgnt_cgnt_rt3 			= StringUtil.nvl((String)resultMap.get("recognitionConfidence3"));	// 인식인식률1
										}
										logger.debug("[거울]resultValue = " + resultValue);
										logger.debug("[거울]dtcn_cgnt_rt = " + dtcn_cgnt_rt);
										logger.debug("[거울]cgnt_cgnt_rt = " + cgnt_cgnt_rt);
										logger.debug("[거울]resultValue2 = " + resultValue2);
										logger.debug("[거울]dtcn_cgnt_rt2 = " + dtcn_cgnt_rt2);
										logger.debug("[거울]cgnt_cgnt_rt2 = " + cgnt_cgnt_rt2);
										logger.debug("[거울]resultValue3 = " + resultValue3);
										logger.debug("[거울]dtcn_cgnt_rt3 = " + dtcn_cgnt_rt3);
										logger.debug("[거울]cgnt_cgnt_rt3 = " + cgnt_cgnt_rt3);
										
									}
								} else {
									resultMap.put("RE_CODE", "1");
									aut_cgnt_trv_dstc_rsl_cd = a_i_o_c_r_resultCode;
									logger.debug("[거울]aut_cgnt_trv_dstc_rsl_cd = " + aut_cgnt_trv_dstc_rsl_cd);
								}
							} else {
								aut_cgnt_trv_dstc_rsl_cd = "02"; //솔루션에서 보내주는 결과코드값이 없는 경우에 02로 세팅
							}
						}
					}
					else {
//						aut_cgnt_trv_dstc_rsl_cd = "02";
						aut_cgnt_trv_dstc_rsl_cd = a_i_o_c_r_resultCode;
						aut_cgnt_vh_no_rsl_cd = "02";
						logger.debug("[거울]aut_cgnt_trv_dstc_rsl_cd = " + aut_cgnt_trv_dstc_rsl_cd);
						logger.error("AI OCR uploadAiOCR("+files.get(0).toString()+","+files.size()+") 시 Error 발생 : " + respEntity);
		                throw new Exception("AI OCR 실패 : " + files.get(0).toString() + "/ responseCode :" + response1.getStatusLine().getStatusCode() + "/ responseMsg :" + EntityUtils.toString(respEntity));
					}
					// json param setting end
					httpClient.close();
					// aiocr 서버 통신 end
				}
			}
			catch(Exception e) {
				logger.debug(e.getMessage());
//				aut_cgnt_trv_dstc_rsl_cd = "02";
				aut_cgnt_trv_dstc_rsl_cd = a_i_o_c_r_resultCode;
				aut_cgnt_vh_no_rsl_cd = "02";
			}
			finally {
				if(ftp != null) ftp.disconnect();
				try{
		    	  	if(in != null){
		    	  		in.close();
		    	  	}
			      }catch(IOException ee){
			    	  System.err.println("[MileageTobeController.upMileageStep2()] IOException 1");
			      }
				try{
		    	  	if(out != null){
		    	  		out.close();
		    	  	}
			      }catch(IOException ee){
			    	  System.err.println("[MileageTobeController.upMileageStep2()] IOException 2");
			      }
				try{
		    	  	if(fis != null){
		    	  		fis.close();
		    	  	}
			      }catch(IOException ee){
			    	  System.err.println("[MileageTobeController.upMileageStep2()] IOException 3");
			      }
			}
		}
		
		Object[] imgfile = new Object[files.size()];
		// [200617]
		FileInputStream fis = null;
		try {
			for(int i = 0; i < files.size(); i++) {
				File f = files.get(i);
				fis = new FileInputStream(f);
				byte[] file = new byte[(int) f.length()];
				fis.read(file);
				imgfile[i] = file;
				fis.close();
				fis = null;
				String fname = f.getName();
				f.delete();
				logger.debug(fname + " 삭제");
			}
		} catch (Exception e) {
			System.err.println("[MileageTobeController.upMileageStep2()] Exception");
		}
		finally {
			try{
				if(fis!=null){
					fis.close();
				}
			}
			catch(IOException ee){
				System.err.println("[MileageTobeController.upMileageStep2()] IOException 4");
		    }
		}
		session.setAttribute("imgfile", imgfile);
		
		// 주행거리 가입 확정처리 분기용 OCR 판독여부
		session.setAttribute("aut_cgnt_trv_dstc_rsl_cd", aut_cgnt_trv_dstc_rsl_cd);
		
		// 계좌환급 완료분기 신규 설계 보종 기준으로 해야함
		session.setAttribute("n_cm_yn", jmvo0213.getCm_yn());
		
		map.put("errorCode",					"0");
		map.put("aut_cgnt_trv_dstc_rsl_cd",		aut_cgnt_trv_dstc_rsl_cd);
		map.put("aut_cgnt_vh_no_rsl_cd",		aut_cgnt_vh_no_rsl_cd);
		map.put("aut_cgnt_trv_dstc",			resultValue);
		map.put("aut_cgnt_vh_no",				aut_cgnt_vh_no);
		map.put("aut_cgnt_trv_dstc_1",			resultValue);
		map.put("aut_cgnt_trv_dstc_2",			resultValue2);
		map.put("aut_cgnt_trv_dstc_3",			resultValue3);
		map.put("phgp_rl_ptgr_dt",				phgp_rl_ptgr_dt);
		map.put("phgp_apdx_way_cd",				phgp_apdx_way_cd);
		
		map.put("a_i_o_c_r_rqst_dsky_val", 		a_i_o_c_r_rqst_dsky_val);
		map.put("resultValue", 					resultValue);
		map.put("dtcn_cgnt_rt", 				dtcn_cgnt_rt);
		map.put("cgnt_cgnt_rt", 				cgnt_cgnt_rt);
		map.put("resultValue2", 				resultValue2);
		map.put("dtcn_cgnt_rt2", 				dtcn_cgnt_rt2);
		map.put("cgnt_cgnt_rt2", 				cgnt_cgnt_rt2);
		map.put("resultValue3", 				resultValue3);
		map.put("dtcn_cgnt_rt3", 				dtcn_cgnt_rt3);
		map.put("cgnt_cgnt_rt3", 				cgnt_cgnt_rt3);
			
		return map;
	}
	
	@RequestMapping(value="/upMileageStep3")
	public String upMileageStep3(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		HttpSession session = request.getSession();
		
		MMTI0217VO jmvo0217 = new MMTI0217VO();
		MMTI0213VO jmvo0213 = new MMTI0213VO();
		
		if(session.getAttribute("p") != null) {
			jmvo0217.setMbl_snd_no((String) session.getAttribute("p"));
		}
		else {
			jmvo0217.setMbl_snd_no(aes256Decrypt(StringUtil.nvl(request.getParameter("p"))));
		}
		jmvo0217 = mileageTobeService.getMMTI0217VO(jmvo0217);
		
		for(int i=0; i<jmvo0217.getIner_mbl_snd_mtt__dst_tty_dvn().length; i++){
			if("01".equals(jmvo0217.getIner_mbl_snd_mtt__dst_tty_dvn()[i])){
				jmvo0213.setSms_ts_bvan(jmvo0217.getIner_mbl_snd_mtt__pbox_no()[i]);
				jmvo0213 = mileageTobeService.getMMTI0213VO(jmvo0213);
				if("1".equals(jmvo0213.getO_c_r_cecd_yn())){
					request.setAttribute("ocr_yn", "1");
				}else{
					request.setAttribute("ocr_yn", "0");
				}
				// request.setAttribute("ocr_yn", jmvo0213.getO_c_r_cecd_yn());
			}
		}
		
		Object[] imgfile = (Object[]) session.getAttribute("imgfile");
		if(imgfile != null) {
			byte[] file = (byte[]) imgfile[0];
			logger.debug("file.length: " + file.length);
			request.setAttribute("imgsrc", "data:image/jpeg;base64," + new String(Base64.encodeBase64(file)));
		}
		
		request.setAttribute("p", request.getParameter("p"));
		request.setAttribute("jmvo", jmvo0217);
		request.setAttribute("jmvo0213", jmvo0213);
		request.setAttribute("step", "02");
		request.setAttribute("dvn", "01");
		return "/counter/carrider/tobe/up2";
	}
	
	//aiocr용
	@RequestMapping(value="/aiocrUpMileageStep3")
	public String aiocrUpMileageStep3(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		HttpSession session = request.getSession();
		
		MMTI0217VO jmvo0217 = new MMTI0217VO();
		MMTI0213VO jmvo0213 = new MMTI0213VO();
		
		if(session.getAttribute("p") != null) {
			jmvo0217.setMbl_snd_no((String) session.getAttribute("p"));
		}
		else {
			jmvo0217.setMbl_snd_no(aes256Decrypt(StringUtil.nvl(request.getParameter("p"))));
		}
		jmvo0217 = mileageTobeService.getMMTI0217VO(jmvo0217);
		
		for(int i=0; i<jmvo0217.getIner_mbl_snd_mtt__dst_tty_dvn().length; i++){
			if("01".equals(jmvo0217.getIner_mbl_snd_mtt__dst_tty_dvn()[i])){
				jmvo0213.setSms_ts_bvan(jmvo0217.getIner_mbl_snd_mtt__pbox_no()[i]);
				jmvo0213 = mileageTobeService.getMMTI0213VO(jmvo0213);
				if("1".equals(jmvo0213.getO_c_r_cecd_yn())){
					request.setAttribute("ocr_yn", "1");
				}else{
					request.setAttribute("ocr_yn", "0");
				}
				// request.setAttribute("ocr_yn", jmvo0213.getO_c_r_cecd_yn());
			}
		}
		
		Object[] imgfile = (Object[]) session.getAttribute("imgfile");
		if(imgfile != null) {
			byte[] file = (byte[]) imgfile[0];
			logger.debug("file.length: " + file.length);
			request.setAttribute("imgsrc", "data:image/jpeg;base64," + new String(Base64.encodeBase64(file)));
		}
		
		request.setAttribute("p", request.getParameter("p"));
		request.setAttribute("jmvo", jmvo0217);
		request.setAttribute("jmvo0213", jmvo0213);
		request.setAttribute("step", "02");
		request.setAttribute("dvn", "01");
		return "/counter/carrider/tobe/aiocr_up2";
	}
	
	// 전자서명용 할인특약사진등록 추가(aiocr용)
	@RequestMapping(value="/aiocrUpMileageStep13")
	public String aiocrUpMileageStep13(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		HttpSession session = request.getSession();
		
		MMTI0217VO jmvo0217 = new MMTI0217VO();
		MMTI0213VO jmvo0213 = new MMTI0213VO();
		
		if(session.getAttribute("p") != null) {
			jmvo0217.setMbl_snd_no((String) session.getAttribute("p"));
		}
		else {
			jmvo0217.setMbl_snd_no(aes256Decrypt(StringUtil.nvl(request.getParameter("p"))));
		}
		jmvo0217 = mileageTobeService.getMMTI0217VO(jmvo0217);
		
		for(int i=0; i<jmvo0217.getIner_mbl_snd_mtt__dst_tty_dvn().length; i++){
			if("01".equals(jmvo0217.getIner_mbl_snd_mtt__dst_tty_dvn()[i])){
				jmvo0213.setSms_ts_bvan(jmvo0217.getIner_mbl_snd_mtt__pbox_no()[i]);
				jmvo0213 = mileageTobeService.getMMTI0213VO(jmvo0213);
				if("1".equals(jmvo0213.getO_c_r_cecd_yn())){
					request.setAttribute("ocr_yn", "1");
				}else{
					request.setAttribute("ocr_yn", "0");
				}
				// request.setAttribute("ocr_yn", jmvo0213.getO_c_r_cecd_yn());
			}
		}
		
		Object[] imgfile = (Object[]) session.getAttribute("imgfile");
		if(imgfile != null) {
			byte[] file = (byte[]) imgfile[0];
			logger.debug("file.length: " + file.length);
			request.setAttribute("imgsrc", "data:image/jpeg;base64," + new String(Base64.encodeBase64(file)));
		}
		
		request.setAttribute("p", request.getParameter("p"));
		request.setAttribute("jmvo", jmvo0217);
		request.setAttribute("jmvo0213", jmvo0213);
		request.setAttribute("step", "02");
		request.setAttribute("dvn", "01");
		
		request.setAttribute("a", StringUtil.nvl(request.getParameter("a")));
//		request.setAttribute("sid", StringUtil.nvl(request.getParameter("sid")));
		request.setAttribute("pt", StringUtil.nvl(request.getParameter("pt")));
		request.setAttribute("chk", StringUtil.nvl(request.getParameter("chk")));
		request.setAttribute("mil_yn", StringUtil.nvl(request.getParameter("mil_yn")));
		request.setAttribute("bb_yn", StringUtil.nvl(request.getParameter("bb_yn")));
		return "/counter/carrider/tobe/aiocr_up4";
	}
	
	// 전자서명용 할인특약사진등록 추가
		@RequestMapping(value="/upMileageStep13")
		public String upMileageStep13(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
			HttpSession session = request.getSession();
			
			MMTI0217VO jmvo0217 = new MMTI0217VO();
			MMTI0213VO jmvo0213 = new MMTI0213VO();
			
			if(session.getAttribute("p") != null) {
				jmvo0217.setMbl_snd_no((String) session.getAttribute("p"));
			}
			else {
				jmvo0217.setMbl_snd_no(aes256Decrypt(StringUtil.nvl(request.getParameter("p"))));
			}
			jmvo0217 = mileageTobeService.getMMTI0217VO(jmvo0217);
			
			for(int i=0; i<jmvo0217.getIner_mbl_snd_mtt__dst_tty_dvn().length; i++){
				if("01".equals(jmvo0217.getIner_mbl_snd_mtt__dst_tty_dvn()[i])){
					jmvo0213.setSms_ts_bvan(jmvo0217.getIner_mbl_snd_mtt__pbox_no()[i]);
					jmvo0213 = mileageTobeService.getMMTI0213VO(jmvo0213);
					if("1".equals(jmvo0213.getO_c_r_cecd_yn())){
						request.setAttribute("ocr_yn", "1");
					}else{
						request.setAttribute("ocr_yn", "0");
					}
					// request.setAttribute("ocr_yn", jmvo0213.getO_c_r_cecd_yn());
				}
			}
			
			Object[] imgfile = (Object[]) session.getAttribute("imgfile");
			if(imgfile != null) {
				byte[] file = (byte[]) imgfile[0];
				logger.debug("file.length: " + file.length);
				request.setAttribute("imgsrc", "data:image/jpeg;base64," + new String(Base64.encodeBase64(file)));
			}
			
			request.setAttribute("p", request.getParameter("p"));
			request.setAttribute("jmvo", jmvo0217);
			request.setAttribute("jmvo0213", jmvo0213);
			request.setAttribute("step", "02");
			request.setAttribute("dvn", "01");
			
			request.setAttribute("a", StringUtil.nvl(request.getParameter("a")));
//			request.setAttribute("sid", StringUtil.nvl(request.getParameter("sid")));
			request.setAttribute("pt", StringUtil.nvl(request.getParameter("pt")));
			request.setAttribute("chk", StringUtil.nvl(request.getParameter("chk")));
			request.setAttribute("mil_yn", StringUtil.nvl(request.getParameter("mil_yn")));
			request.setAttribute("bb_yn", StringUtil.nvl(request.getParameter("bb_yn")));
			return "/counter/carrider/tobe/up4";
		}
	
	@RequestMapping(value="/upMileageStep4")
	public @ResponseBody Map<String, String> upMileageStep4(MultipartHttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		HttpSession session = request.getSession();
		
		MMTI0217VO jmvo0217 = new MMTI0217VO();
		MMTI0213VO jmvo0213 = new MMTI0213VO();
		MBTR01001VO mbtr01001vo = new MBTR01001VO();
		
		String aut_cgnt_trv_dstc_rsl_cd	= StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc_rsl_cd"));	// 자동인식주행거리결과코드
		String aut_cgnt_vh_no_rsl_cd	= StringUtil.nvl(request.getParameter("aut_cgnt_vh_no_rsl_cd"));	// 자동인식차량번호결과코드
		String aut_cgnt_trv_dstc		= StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc"));		// 자동인식주행거리
		String aut_cgnt_vh_no			= StringUtil.nvl(request.getParameter("aut_cgnt_vh_no"));			// 자동인식차량번호
		
		String aut_cgnt_trv_dstc_1		= StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc_1"));		// 자동인식주행거리1
		String aut_cgnt_trv_dstc_2		= StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc_2"));		// 자동인식주행거리2
		String aut_cgnt_trv_dstc_3		= StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc_3"));		// 자동인식주행거리3
		
		String phgp_rl_ptgr_dt			= StringUtil.nvl(request.getParameter("phgp_rl_ptgr_dt"));			// 사진실제촬영일자
		String phgp_apdx_way_cd			= StringUtil.nvl(request.getParameter("phgp_apdx_way_cd"));			// 사진첨부방식코드
		
		Map<String, String> map = new HashMap<String, String>();
		
		if(session.getAttribute("p") != null) {
			jmvo0217.setMbl_snd_no((String) session.getAttribute("p"));
		}
		else {
			jmvo0217.setMbl_snd_no(aes256Decrypt(StringUtil.nvl(request.getParameter("p"))));
		}
		jmvo0217 = mileageTobeService.getMMTI0217VO(jmvo0217);
		
		for(int i=0; i<jmvo0217.getIner_mbl_snd_mtt__dst_tty_dvn().length; i++){
			if("01".equals(jmvo0217.getIner_mbl_snd_mtt__dst_tty_dvn()[i])){
				jmvo0213.setSms_ts_bvan(jmvo0217.getIner_mbl_snd_mtt__pbox_no()[i]);
				jmvo0213 = mileageTobeService.getMMTI0213VO(jmvo0213);
				if("1".equals(jmvo0213.getO_c_r_cecd_yn())){
					request.setAttribute("ocr_yn", "1");
				}else{
					request.setAttribute("ocr_yn", "0");
				}
				// request.setAttribute("ocr_yn", jmvo0213.getO_c_r_cecd_yn());
			}
		}
		
		String exifDate1 = StringUtil.nvl(request.getParameter("exifDate1"));
		
		String phgp_ptgr_dt = "";
		
		boolean empty = false;
		if(exifDate1.indexOf(",gallery") > -1) {
			exifDate1 = exifDate1.substring(0, exifDate1.indexOf(",gallery"));
			if(StringUtil.isEmpty(exifDate1)) {
				exifDate1 = DateUtil.getDate();
				empty = true;
			}
			else if(Integer.parseInt(exifDate1) > Integer.parseInt(DateUtil.getDate())) {
				map.put("errorCode", "f");
				return map;
			}
		}

		phgp_ptgr_dt = empty ? "" : exifDate1;
		
		if(exifDate1.indexOf(",gallery") > -1) {
			exifDate1 = exifDate1.substring(0, exifDate1.indexOf(",gallery"));
		}
		
		session.setAttribute("exifDate", exifDate1);
		
		MMTI0259VO jmvo0259 = new MMTI0259VO();
		jmvo0259.setPbox_use_yn("1");
		jmvo0259.setPbox_no(jmvo0213.getSms_ts_bvan());
		jmvo0259.setPhgp_cnfm_dt(DateUtil.getDate("yyyymmdd"));
		jmvo0259.setPhgp_ptgr_dt(phgp_ptgr_dt);
		jmvo0259.setPhgp_strg_yn("1");
		if("1".equals(jmvo0213.getAut_cgnt_nn_apcn_yn())) {
			jmvo0259.setPbox_chr_nm(request.getParameter("mileage1"));
		}
		
		jmvo0259.setInpt_trv_dstc(request.getParameter("mileage1"));
		
		if(!StringUtil.isEmpty(aut_cgnt_vh_no)) {
			jmvo0259.setAut_cgnt_vh_no(aut_cgnt_vh_no);
		}
		
		if(!StringUtil.isEmpty(aut_cgnt_vh_no_rsl_cd)) {
			jmvo0259.setAut_cgnt_vh_no_rsl_cd(aut_cgnt_vh_no_rsl_cd);
		} else {
			jmvo0259.setAut_cgnt_vh_no_rsl_cd("02");
		}
		
		if(!StringUtil.isEmpty(aut_cgnt_trv_dstc)) {
			jmvo0259.setAut_cgnt_trv_dstc(aut_cgnt_trv_dstc);
		}
		
		if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_rsl_cd)) {
			jmvo0259.setAut_cgnt_trv_dstc_rsl_cd(aut_cgnt_trv_dstc_rsl_cd);
		}
		else {
			jmvo0259.setAut_cgnt_trv_dstc_rsl_cd("02");
		}
		
		if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_1)) {
			jmvo0259.setAut_cgnt_trv_dstc_1(aut_cgnt_trv_dstc_1);
		}
		
		if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_2)) {
			jmvo0259.setAut_cgnt_trv_dstc_2(aut_cgnt_trv_dstc_2);
		}
		
		if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_3)) {
			jmvo0259.setAut_cgnt_trv_dstc_3(aut_cgnt_trv_dstc_3);
		}
		
		jmvo0259.setPhgp_rl_ptgr_dt(phgp_rl_ptgr_dt);
		jmvo0259.setPhgp_apdx_way_cd(phgp_apdx_way_cd);
		
		// jmvo1.setExp_exca_plan_proc_dvn("1");
		jmvo0259.setPlno(jmvo0213.getPlno());
		
		jmvo0259 = mileageTobeService.getMMTI0259VO(jmvo0259);
		session.setAttribute("mileage_0259", jmvo0259);
		
		if("0".equals(jmvo0259.getErrorCode())){
			mbtr01001vo = mileageTobeService.regInfoToEdmsForMobileWeb(request, jmvo0213.getSms_ts_bvan(), mbtr01001vo);
		}
		
		// 주행거리 수정한경우 1, 수정안한경우 0
		double inpt_mile = Double.parseDouble(jmvo0259.getInpt_trv_dstc());
		double auto_mile = Double.parseDouble(jmvo0259.getAut_cgnt_trv_dstc());
		
		if(Math.abs(inpt_mile-auto_mile) <= 250){
			session.setAttribute("modify_mile", "0");
		}else{
			session.setAttribute("modify_mile", "1");
		}
		/*
		if(jmvo0259.getInpt_trv_dstc().equals(jmvo0259.getAut_cgnt_trv_dstc())){
			session.setAttribute("modify_mile", "0");
		}else{
			session.setAttribute("modify_mile", "1");
		}
		*/
		
		int insertRow = 0;
		
		// VO SET
		mbtr01001vo.setPboxNo(jmvo0213.getSms_ts_bvan());
		mbtr01001vo.setApdxFlRutNm("");
		mbtr01001vo.setFrstIpmnEmpno("82101685");
		mbtr01001vo.setFnalAmdrEmpno("82101685");
		
		insertRow = mileageTobeService.insertTest(mbtr01001vo);
		if(insertRow < 1){
			logger.info("#### 사서함번호: " + StringUtil.nvl(mbtr01001vo.getPboxNo()) + "####");
			logger.info("#### insert 결과: Fail ####");
		}else{
			logger.info("#### insert 결과: Success ####");
		}
		
		map.put("errorCode", jmvo0259.getErrorCode());
		map.put("z_resp_msg", jmvo0259.getZ_resp_msg());
			
		return map;
	}
	
	//aiocr용
	@RequestMapping(value="/aiocrUpMileageStep4")
	public @ResponseBody Map<String, String> aiocrUpMileageStep4(MultipartHttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		HttpSession session = request.getSession();
		
		MMTI0217VO jmvo0217 = new MMTI0217VO();
		MMTI0213VO jmvo0213 = new MMTI0213VO();
		MBTR01001VO mbtr01001vo = new MBTR01001VO();
		
		String aut_cgnt_trv_dstc_rsl_cd	= StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc_rsl_cd"));	// 자동인식주행거리결과코드
		String aut_cgnt_vh_no_rsl_cd	= StringUtil.nvl(request.getParameter("aut_cgnt_vh_no_rsl_cd"));	// 자동인식차량번호결과코드
		String aut_cgnt_trv_dstc		= StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc"));		// 자동인식주행거리
		String aut_cgnt_vh_no			= StringUtil.nvl(request.getParameter("aut_cgnt_vh_no"));			// 자동인식차량번호
		
		String aut_cgnt_trv_dstc_1		= StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc_1"));		// 자동인식주행거리1
		String aut_cgnt_trv_dstc_2		= StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc_2"));		// 자동인식주행거리2
		String aut_cgnt_trv_dstc_3		= StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc_3"));		// 자동인식주행거리3
		
		String phgp_rl_ptgr_dt			= StringUtil.nvl(request.getParameter("phgp_rl_ptgr_dt"));			// 사진실제촬영일자
		String phgp_apdx_way_cd			= StringUtil.nvl(request.getParameter("phgp_apdx_way_cd"));			// 사진첨부방식코드
		
		String a_i_o_c_r_rqst_dsky_val	= StringUtil.nvl(request.getParameter("a_i_o_c_r_rqst_dsky_val"));	// aiocr요청구분키값
		String resultValue 				= StringUtil.nvl(request.getParameter("resultValue"));	// 주행거리값1
		String dtcn_cgnt_rt 			= StringUtil.nvl(request.getParameter("dtcn_cgnt_rt"));	// 검출인식률1
		String cgnt_cgnt_rt 			= StringUtil.nvl(request.getParameter("cgnt_cgnt_rt"));	// 인식인식률1
		String resultValue2 			= StringUtil.nvl(request.getParameter("resultValue2"));	// 주행거리값2
		String dtcn_cgnt_rt2 			= StringUtil.nvl(request.getParameter("dtcn_cgnt_rt2"));	// 검출인식률2
		String cgnt_cgnt_rt2 			= StringUtil.nvl(request.getParameter("cgnt_cgnt_rt2"));	// 인식인식률2
		String resultValue3 			= StringUtil.nvl(request.getParameter("resultValue3"));	// 주행거리값3
		String dtcn_cgnt_rt3 			= StringUtil.nvl(request.getParameter("dtcn_cgnt_rt3"));	// 검출인식률3
		String cgnt_cgnt_rt3 			= StringUtil.nvl(request.getParameter("cgnt_cgnt_rt3"));	// 인식인식률3
		String RE_CODE 					= StringUtil.nvl(request.getParameter("RE_CODE"));
		
		Map<String, String> map = new HashMap<String, String>();
		
		if(session.getAttribute("p") != null) {
			jmvo0217.setMbl_snd_no((String) session.getAttribute("p"));
		}
		else {
			jmvo0217.setMbl_snd_no(aes256Decrypt(StringUtil.nvl(request.getParameter("p"))));
		}
		jmvo0217 = mileageTobeService.getMMTI0217VO(jmvo0217);
		
		for(int i=0; i<jmvo0217.getIner_mbl_snd_mtt__dst_tty_dvn().length; i++){
			if("01".equals(jmvo0217.getIner_mbl_snd_mtt__dst_tty_dvn()[i])){
				jmvo0213.setSms_ts_bvan(jmvo0217.getIner_mbl_snd_mtt__pbox_no()[i]);
				jmvo0213 = mileageTobeService.getMMTI0213VO(jmvo0213);
				if("1".equals(jmvo0213.getO_c_r_cecd_yn())){
					request.setAttribute("ocr_yn", "1");
				}else{
					request.setAttribute("ocr_yn", "0");
				}
				// request.setAttribute("ocr_yn", jmvo0213.getO_c_r_cecd_yn());
			}
		}
		
		String exifDate1 = StringUtil.nvl(request.getParameter("exifDate1"));
		
		String phgp_ptgr_dt = "";
		
		boolean empty = false;
		if(exifDate1.indexOf(",gallery") > -1) {
			exifDate1 = exifDate1.substring(0, exifDate1.indexOf(",gallery"));
			if(StringUtil.isEmpty(exifDate1)) {
				exifDate1 = DateUtil.getDate();
				empty = true;
			}
			else if(Integer.parseInt(exifDate1) > Integer.parseInt(DateUtil.getDate())) {
				map.put("errorCode", "f");
				return map;
			}
		}

		phgp_ptgr_dt = empty ? "" : exifDate1;
		
		if(exifDate1.indexOf(",gallery") > -1) {
			exifDate1 = exifDate1.substring(0, exifDate1.indexOf(",gallery"));
		}
		
		session.setAttribute("exifDate", exifDate1);
		
		MMTI0259VO jmvo0259 = new MMTI0259VO();
		jmvo0259.setPbox_use_yn("1");
		jmvo0259.setPbox_no(jmvo0213.getSms_ts_bvan());
		jmvo0259.setPhgp_cnfm_dt(DateUtil.getDate("yyyymmdd"));
		jmvo0259.setPhgp_ptgr_dt(phgp_ptgr_dt);
		jmvo0259.setPhgp_strg_yn("1");
		if("1".equals(jmvo0213.getAut_cgnt_nn_apcn_yn())) {
			jmvo0259.setPbox_chr_nm(request.getParameter("mileage1"));
		}
		
		jmvo0259.setInpt_trv_dstc(request.getParameter("mileage1"));
		
		if(!StringUtil.isEmpty(aut_cgnt_vh_no)) {
			jmvo0259.setAut_cgnt_vh_no(aut_cgnt_vh_no);
		}
		
		if(!StringUtil.isEmpty(aut_cgnt_vh_no_rsl_cd)) {
			jmvo0259.setAut_cgnt_vh_no_rsl_cd(aut_cgnt_vh_no_rsl_cd);
		} else {
			jmvo0259.setAut_cgnt_vh_no_rsl_cd("02");
		}
		
		if(!StringUtil.isEmpty(aut_cgnt_trv_dstc)) {
			jmvo0259.setAut_cgnt_trv_dstc(aut_cgnt_trv_dstc);
		}
		
		if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_rsl_cd)) {
			jmvo0259.setAut_cgnt_trv_dstc_rsl_cd(aut_cgnt_trv_dstc_rsl_cd);
		}
		else {
			jmvo0259.setAut_cgnt_trv_dstc_rsl_cd("02");
		}
		
		if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_1)) {
			jmvo0259.setAut_cgnt_trv_dstc_1(aut_cgnt_trv_dstc_1);
		}
		
//		if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_2)) {
//			jmvo0259.setAut_cgnt_trv_dstc_2(aut_cgnt_trv_dstc_2);
//		}
//		
//		if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_3)) {
//			jmvo0259.setAut_cgnt_trv_dstc_3(aut_cgnt_trv_dstc_3);
//		}
		
		if(!StringUtil.isEmpty(a_i_o_c_r_rqst_dsky_val)) {
			jmvo0259.setA_i_o_c_r_rqst_dsky_val(a_i_o_c_r_rqst_dsky_val);
		}
		
		if(!StringUtil.isEmpty(dtcn_cgnt_rt)) {
			jmvo0259.setDtcn_cgnt_rt(dtcn_cgnt_rt);
		}
		
		if(!StringUtil.isEmpty(cgnt_cgnt_rt)) {
			jmvo0259.setCgnt_cgnt_rt(cgnt_cgnt_rt);
		}
		
		if(!StringUtil.isEmpty(resultValue2)) {
			jmvo0259.setAut_cgnt_trv_dstc_2(resultValue2);
		}
		
		if(!StringUtil.isEmpty(resultValue3)) {
			jmvo0259.setAut_cgnt_trv_dstc_3(resultValue3);
		}
		
		jmvo0259.setPhgp_rl_ptgr_dt(phgp_rl_ptgr_dt);
		jmvo0259.setPhgp_apdx_way_cd(phgp_apdx_way_cd);
		
		// jmvo1.setExp_exca_plan_proc_dvn("1");
		jmvo0259.setPlno(jmvo0213.getPlno());
		
		jmvo0259 = mileageTobeService.getMMTI0259VO(jmvo0259);
		session.setAttribute("mileage_0259", jmvo0259);
		
		if("0".equals(jmvo0259.getErrorCode())){
			mbtr01001vo = mileageTobeService.aiocrRegInfoToEdmsForMobileWeb(request, jmvo0213.getSms_ts_bvan(), mbtr01001vo);
		}
		
		// 주행거리 수정한경우 1, 수정안한경우 0
		double inpt_mile = Double.parseDouble(jmvo0259.getInpt_trv_dstc());
		double auto_mile = Double.parseDouble(jmvo0259.getAut_cgnt_trv_dstc());
		
		if(Math.abs(inpt_mile-auto_mile) <= 250){
			session.setAttribute("modify_mile", "0");
		}else{
			session.setAttribute("modify_mile", "1");
		}
		/*
		if(jmvo0259.getInpt_trv_dstc().equals(jmvo0259.getAut_cgnt_trv_dstc())){
			session.setAttribute("modify_mile", "0");
		}else{
			session.setAttribute("modify_mile", "1");
		}
		*/
		
		int insertRow = 0;
		
		// VO SET
		mbtr01001vo.setPboxNo(jmvo0213.getSms_ts_bvan());
		mbtr01001vo.setApdxFlRutNm("");
		mbtr01001vo.setFrstIpmnEmpno("82101685");
		mbtr01001vo.setFnalAmdrEmpno("82101685");
		
		insertRow = mileageTobeService.insertTest(mbtr01001vo);
		if(insertRow < 1){
			logger.info("#### 사서함번호: " + StringUtil.nvl(mbtr01001vo.getPboxNo()) + "####");
			logger.info("#### insert 결과: Fail ####");
		}else{
			logger.info("#### insert 결과: Success ####");
		}
		
		map.put("errorCode", jmvo0259.getErrorCode());
		map.put("z_resp_msg", jmvo0259.getZ_resp_msg());
			
		return map;
	}
	
	@RequestMapping(value="/upMileageStep5")
	public String upMileageStep5(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		
		HttpSession session = request.getSession();
		MMTI0217VO jmvo = new MMTI0217VO();
		MMTI0213VO mmti0213vo = new MMTI0213VO();
		MMTI0305VO mmti0305vo = new MMTI0305VO();
		
		if(session.getAttribute("p") != null) {
			jmvo.setMbl_snd_no((String) session.getAttribute("p"));
		}
		else {
			jmvo.setMbl_snd_no(aes256Decrypt(StringUtil.nvl(request.getParameter("p"))));
		}
		jmvo = mileageTobeService.getMMTI0217VO(jmvo);

		request.setAttribute("p", StringUtil.nvl(request.getParameter("p")));
		request.setAttribute("jmvo", jmvo);
		
		// ocr 판독여부 가져오기
		for(int i=0; i<jmvo.getIner_mbl_snd_mtt__dst_tty_dvn().length; i++){
			if("01".equals(jmvo.getIner_mbl_snd_mtt__dst_tty_dvn()[i])){
				mmti0213vo.setSms_ts_bvan(jmvo.getIner_mbl_snd_mtt__pbox_no()[i]);
				mmti0213vo = mileageTobeService.getMMTI0213VO(mmti0213vo);
				if("1".equals(mmti0213vo.getO_c_r_cecd_yn())){
					request.setAttribute("ocr_yn", "1");
				}else{
					request.setAttribute("ocr_yn", "0");
				}
			}
		}
		
		MMTI0218VO jmvo0218 = new MMTI0218VO();
		
		jmvo0218.setMbl_snd_no(jmvo.getMbl_snd_no());
		jmvo0218.setPlan_plno_dvcd(jmvo.getPlan_plno_dvcd());
		jmvo0218.setPlan_plno(jmvo.getPlan_plno());
		jmvo0218.setChng_plan_no(jmvo.getChng_plan_no());
		
		jmvo0218 = mileageTobeService.getMMTI0218VO(jmvo0218);
		int count = 0;
		for(int i = 0; i < jmvo0218.getPhgp_regt_tgt__dst_tty_dvn().length; i++) {
			if("Y".equals(jmvo0218.getPhgp_regt_tgt__phgp_regt_cplt_yn()[i]) || "1".equals(jmvo0218.getPhgp_regt_tgt__phgp_regt_cplt_yn()[i])) count++;
		}
		
		if(count > 0 && count == jmvo0218.getPhgp_regt_tgt__dst_tty_dvn().length){
			request.setAttribute("reg_yn", "1");
		}else{
			request.setAttribute("reg_yn", "0");
		}
		
		logger.info("########### 테스트 테스트 #######");
		logger.info("### reg_yn: " + request.getAttribute("reg_yn"));
		logger.info("### tgt_yn: " + mmti0213vo.getTrv_dstc_tty_exca_tgt_yn());
		logger.info("### aut_cgnt_cd: " + (String)session.getAttribute("aut_cgnt_trv_dstc_rsl_cd"));
		logger.info("### modify_mile: " + (String)session.getAttribute("modify_mile"));
		
		// 전계약 정산대상여부 확인(1: 정산대상)
		if("1".equals(mmti0213vo.getTrv_dstc_tty_exca_tgt_yn())){
			// OCR 정상인식 및 주행거리 미수정 확인(01: 정상판독, 0: 주행거리미수정)
			if("01".equals((String)session.getAttribute("aut_cgnt_trv_dstc_rsl_cd")) && "0".equals((String)session.getAttribute("modify_mile"))){
				// 전계약 정산 진행여부(1: 진행)
				session.setAttribute("ctn_yn", "1");
				
				// mmti0305vo.setSrch_cnd__vh_no(SeedUtil.encrypt(mmti0213vo.getVh_no()));
				mmti0305vo.setSrch_cnd__plno(mmti0213vo.getCtc_plno());
				mmti0305vo.setSrch_cnd__proc_dvn("01");
				mmti0305vo.setSrch_cnd__hdlr_empno("80000040");
				mmti0305vo.setSrch_cnd__trv_dstc_proc_dvcd("10");
				mmti0305vo = mileageTobeService.getMMTI0305VO(mmti0305vo);
				
				String arc_pd = mmti0305vo.getSrch_rsl__arc_pd().substring(0, 4)
						+ "." + mmti0305vo.getSrch_rsl__arc_pd().substring(4, 6)
						+ "." + mmti0305vo.getSrch_rsl__arc_pd().substring(6, 8);
				String arc_et = mmti0305vo.getSrch_rsl__arc_et().substring(0, 4)
						+ "." + mmti0305vo.getSrch_rsl__arc_et().substring(4, 6)
						+ "." + mmti0305vo.getSrch_rsl__arc_et().substring(6, 8);
				// 전계약 보험시기, 종기
				session.setAttribute("arc_pd", arc_pd);
				session.setAttribute("arc_et", arc_et);
			}else{
				// 전계약 정산 진행여부(0: 미진행)
				session.setAttribute("ctn_yn", "0");
			}
		}else{
			// 전계약 정산 진행여부(0: 미진행)
			session.setAttribute("ctn_yn", "0");
		}
		
		session.setAttribute("mmti0213vo", mmti0213vo);
		request.setAttribute("step", "03");
		request.setAttribute("dvn", "01");
		return "/counter/carrider/tobe/up2";
	}
	
	//aiocr용
	@RequestMapping(value="/aiocrUpMileageStep5")
	public String aiocrUpMileageStep5(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		
		HttpSession session = request.getSession();
		MMTI0217VO jmvo = new MMTI0217VO();
		MMTI0213VO mmti0213vo = new MMTI0213VO();
		MMTI0305VO mmti0305vo = new MMTI0305VO();
		
		if(session.getAttribute("p") != null) {
			jmvo.setMbl_snd_no((String) session.getAttribute("p"));
		}
		else {
			jmvo.setMbl_snd_no(aes256Decrypt(StringUtil.nvl(request.getParameter("p"))));
		}
		jmvo = mileageTobeService.getMMTI0217VO(jmvo);

		request.setAttribute("p", StringUtil.nvl(request.getParameter("p")));
		request.setAttribute("jmvo", jmvo);
		
		// ocr 판독여부 가져오기
		for(int i=0; i<jmvo.getIner_mbl_snd_mtt__dst_tty_dvn().length; i++){
			if("01".equals(jmvo.getIner_mbl_snd_mtt__dst_tty_dvn()[i])){
				mmti0213vo.setSms_ts_bvan(jmvo.getIner_mbl_snd_mtt__pbox_no()[i]);
				mmti0213vo = mileageTobeService.getMMTI0213VO(mmti0213vo);
				if("1".equals(mmti0213vo.getO_c_r_cecd_yn())){
					request.setAttribute("ocr_yn", "1");
				}else{
					request.setAttribute("ocr_yn", "0");
				}
			}
		}
		
		MMTI0218VO jmvo0218 = new MMTI0218VO();
		
		jmvo0218.setMbl_snd_no(jmvo.getMbl_snd_no());
		jmvo0218.setPlan_plno_dvcd(jmvo.getPlan_plno_dvcd());
		jmvo0218.setPlan_plno(jmvo.getPlan_plno());
		jmvo0218.setChng_plan_no(jmvo.getChng_plan_no());
		
		jmvo0218 = mileageTobeService.getMMTI0218VO(jmvo0218);
		int count = 0;
		for(int i = 0; i < jmvo0218.getPhgp_regt_tgt__dst_tty_dvn().length; i++) {
			if("Y".equals(jmvo0218.getPhgp_regt_tgt__phgp_regt_cplt_yn()[i]) || "1".equals(jmvo0218.getPhgp_regt_tgt__phgp_regt_cplt_yn()[i])) count++;
		}
		
		if(count > 0 && count == jmvo0218.getPhgp_regt_tgt__dst_tty_dvn().length){
			request.setAttribute("reg_yn", "1");
		}else{
			request.setAttribute("reg_yn", "0");
		}
		
		logger.info("########### 테스트 테스트 #######");
		logger.info("### reg_yn: " + request.getAttribute("reg_yn"));
		logger.info("### tgt_yn: " + mmti0213vo.getTrv_dstc_tty_exca_tgt_yn());
		logger.info("### aut_cgnt_cd: " + (String)session.getAttribute("aut_cgnt_trv_dstc_rsl_cd"));
		logger.info("### modify_mile: " + (String)session.getAttribute("modify_mile"));
		
		// 전계약 정산대상여부 확인(1: 정산대상)
		if("1".equals(mmti0213vo.getTrv_dstc_tty_exca_tgt_yn())){
			// OCR 정상인식 및 주행거리 미수정 확인(01: 정상판독, 0: 주행거리미수정)
			if("01".equals((String)session.getAttribute("aut_cgnt_trv_dstc_rsl_cd")) && "0".equals((String)session.getAttribute("modify_mile"))){
				// 전계약 정산 진행여부(1: 진행)
				session.setAttribute("ctn_yn", "1");
				
				// mmti0305vo.setSrch_cnd__vh_no(SeedUtil.encrypt(mmti0213vo.getVh_no()));
				mmti0305vo.setSrch_cnd__plno(mmti0213vo.getCtc_plno());
				mmti0305vo.setSrch_cnd__proc_dvn("01");
				mmti0305vo.setSrch_cnd__hdlr_empno("80000040");
				mmti0305vo.setSrch_cnd__trv_dstc_proc_dvcd("10");
				mmti0305vo = mileageTobeService.getMMTI0305VO(mmti0305vo);
				
				String arc_pd = mmti0305vo.getSrch_rsl__arc_pd().substring(0, 4)
						+ "." + mmti0305vo.getSrch_rsl__arc_pd().substring(4, 6)
						+ "." + mmti0305vo.getSrch_rsl__arc_pd().substring(6, 8);
				String arc_et = mmti0305vo.getSrch_rsl__arc_et().substring(0, 4)
						+ "." + mmti0305vo.getSrch_rsl__arc_et().substring(4, 6)
						+ "." + mmti0305vo.getSrch_rsl__arc_et().substring(6, 8);
				// 전계약 보험시기, 종기
				session.setAttribute("arc_pd", arc_pd);
				session.setAttribute("arc_et", arc_et);
			}else{
				// 전계약 정산 진행여부(0: 미진행)
				session.setAttribute("ctn_yn", "0");
			}
		}else{
			// 전계약 정산 진행여부(0: 미진행)
			session.setAttribute("ctn_yn", "0");
		}
		
		session.setAttribute("mmti0213vo", mmti0213vo);
		request.setAttribute("step", "03");
		request.setAttribute("dvn", "01");
		return "/counter/carrider/tobe/aiocr_up2";
	}
	
	@RequestMapping(value="/upMileageStep15")
	public String upMileageStep15(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		
		HttpSession session = request.getSession();
		MMTI0217VO jmvo = new MMTI0217VO();
		MMTI0213VO mmti0213vo = new MMTI0213VO();
		MMTI0305VO mmti0305vo = new MMTI0305VO();
		
		if(session.getAttribute("p") != null) {
			jmvo.setMbl_snd_no((String) session.getAttribute("p"));
		}
		else {
			jmvo.setMbl_snd_no(aes256Decrypt(StringUtil.nvl(request.getParameter("p"))));
		}
		jmvo = mileageTobeService.getMMTI0217VO(jmvo);

		request.setAttribute("p", StringUtil.nvl(request.getParameter("p")));
		request.setAttribute("jmvo", jmvo);
		
		// ocr 판독여부 가져오기
		for(int i=0; i<jmvo.getIner_mbl_snd_mtt__dst_tty_dvn().length; i++){
			if("01".equals(jmvo.getIner_mbl_snd_mtt__dst_tty_dvn()[i])){
				mmti0213vo.setSms_ts_bvan(jmvo.getIner_mbl_snd_mtt__pbox_no()[i]);
				mmti0213vo = mileageTobeService.getMMTI0213VO(mmti0213vo);
				if("1".equals(mmti0213vo.getO_c_r_cecd_yn())){
					request.setAttribute("ocr_yn", "1");
				}else{
					request.setAttribute("ocr_yn", "0");
				}
			}
		}
		
		MMTI0218VO jmvo0218 = new MMTI0218VO();
		
		jmvo0218.setMbl_snd_no(jmvo.getMbl_snd_no());
		jmvo0218.setPlan_plno_dvcd(jmvo.getPlan_plno_dvcd());
		jmvo0218.setPlan_plno(jmvo.getPlan_plno());
		jmvo0218.setChng_plan_no(jmvo.getChng_plan_no());
		
		jmvo0218 = mileageTobeService.getMMTI0218VO(jmvo0218);
		int count = 0;
		for(int i = 0; i < jmvo0218.getPhgp_regt_tgt__dst_tty_dvn().length; i++) {
			if("Y".equals(jmvo0218.getPhgp_regt_tgt__phgp_regt_cplt_yn()[i]) || "1".equals(jmvo0218.getPhgp_regt_tgt__phgp_regt_cplt_yn()[i])) count++;
		}
		
		if(count > 0 && count == jmvo0218.getPhgp_regt_tgt__dst_tty_dvn().length){
			request.setAttribute("reg_yn", "1");
		}else{
			request.setAttribute("reg_yn", "0");
		}
		
		logger.info("########### 전자서명용 할인특약사진등록 테스트 테스트 #######");
		logger.info("### reg_yn: " + request.getAttribute("reg_yn"));
		logger.info("### tgt_yn: " + mmti0213vo.getTrv_dstc_tty_exca_tgt_yn());
		logger.info("### aut_cgnt_cd: " + (String)session.getAttribute("aut_cgnt_trv_dstc_rsl_cd"));
		logger.info("### modify_mile: " + (String)session.getAttribute("modify_mile"));
		
		// 전계약 정산대상여부 확인(1: 정산대상)
		if("1".equals(mmti0213vo.getTrv_dstc_tty_exca_tgt_yn())){
			// OCR 정상인식 및 주행거리 미수정 확인(01: 정상판독, 0: 주행거리미수정)
			if("01".equals((String)session.getAttribute("aut_cgnt_trv_dstc_rsl_cd")) && "0".equals((String)session.getAttribute("modify_mile"))){
				// 전계약 정산 진행여부(1: 진행)
				session.setAttribute("ctn_yn", "1");
				
				// mmti0305vo.setSrch_cnd__vh_no(SeedUtil.encrypt(mmti0213vo.getVh_no()));
				mmti0305vo.setSrch_cnd__plno(mmti0213vo.getCtc_plno());
				mmti0305vo.setSrch_cnd__proc_dvn("01");
				mmti0305vo.setSrch_cnd__hdlr_empno("80000040");
				mmti0305vo.setSrch_cnd__trv_dstc_proc_dvcd("10");
				mmti0305vo = mileageTobeService.getMMTI0305VO(mmti0305vo);
				
				String arc_pd = mmti0305vo.getSrch_rsl__arc_pd().substring(0, 4)
						+ "." + mmti0305vo.getSrch_rsl__arc_pd().substring(4, 6)
						+ "." + mmti0305vo.getSrch_rsl__arc_pd().substring(6, 8);
				String arc_et = mmti0305vo.getSrch_rsl__arc_et().substring(0, 4)
						+ "." + mmti0305vo.getSrch_rsl__arc_et().substring(4, 6)
						+ "." + mmti0305vo.getSrch_rsl__arc_et().substring(6, 8);
				// 전계약 보험시기, 종기
				session.setAttribute("arc_pd", arc_pd);
				session.setAttribute("arc_et", arc_et);
				logger.info("### 정산대상, 정상판독, 주행거리미수정");
			}else{
				// 전계약 정산 진행여부(0: 미진행)
				session.setAttribute("ctn_yn", "0");
				logger.info("### 정산대상, 정상판독 아님");
			}
		}else{
			// 전계약 정산 진행여부(0: 미진행)
			session.setAttribute("ctn_yn", "0");
			logger.info("### 정산대상아님");
		}
		
		session.setAttribute("mmti0213vo", mmti0213vo);
		request.setAttribute("step", "03");
		request.setAttribute("dvn", "01");
		
		request.setAttribute("a", StringUtil.nvl(request.getParameter("a")));
//		request.setAttribute("sid", StringUtil.nvl(request.getParameter("sid")));
		request.setAttribute("pt", StringUtil.nvl(request.getParameter("pt")));
		request.setAttribute("chk", StringUtil.nvl(request.getParameter("chk")));
		request.setAttribute("mil_yn", StringUtil.nvl(request.getParameter("mil_yn")));
		request.setAttribute("bb_yn", StringUtil.nvl(request.getParameter("bb_yn")));
		request.setAttribute("ctn_yn", session.getAttribute("ctn_yn"));
		logger.info("### up4로 이동. ctn_yn = " + session.getAttribute("ctn_yn"));
		return "/counter/carrider/tobe/up4";
	}
	
	//aiocr용
	@RequestMapping(value="/aiocrUpMileageStep15")
	public String aiocrUpMileageStep15(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		
		HttpSession session = request.getSession();
		MMTI0217VO jmvo = new MMTI0217VO();
		MMTI0213VO mmti0213vo = new MMTI0213VO();
		MMTI0305VO mmti0305vo = new MMTI0305VO();
		
		if(session.getAttribute("p") != null) {
			jmvo.setMbl_snd_no((String) session.getAttribute("p"));
		}
		else {
			jmvo.setMbl_snd_no(aes256Decrypt(StringUtil.nvl(request.getParameter("p"))));
		}
		jmvo = mileageTobeService.getMMTI0217VO(jmvo);

		request.setAttribute("p", StringUtil.nvl(request.getParameter("p")));
		request.setAttribute("jmvo", jmvo);
		
		// ocr 판독여부 가져오기
		for(int i=0; i<jmvo.getIner_mbl_snd_mtt__dst_tty_dvn().length; i++){
			if("01".equals(jmvo.getIner_mbl_snd_mtt__dst_tty_dvn()[i])){
				mmti0213vo.setSms_ts_bvan(jmvo.getIner_mbl_snd_mtt__pbox_no()[i]);
				mmti0213vo = mileageTobeService.getMMTI0213VO(mmti0213vo);
				if("1".equals(mmti0213vo.getO_c_r_cecd_yn())){
					request.setAttribute("ocr_yn", "1");
				}else{
					request.setAttribute("ocr_yn", "0");
				}
			}
		}
		
		MMTI0218VO jmvo0218 = new MMTI0218VO();
		
		jmvo0218.setMbl_snd_no(jmvo.getMbl_snd_no());
		jmvo0218.setPlan_plno_dvcd(jmvo.getPlan_plno_dvcd());
		jmvo0218.setPlan_plno(jmvo.getPlan_plno());
		jmvo0218.setChng_plan_no(jmvo.getChng_plan_no());
		
		jmvo0218 = mileageTobeService.getMMTI0218VO(jmvo0218);
		int count = 0;
		for(int i = 0; i < jmvo0218.getPhgp_regt_tgt__dst_tty_dvn().length; i++) {
			if("Y".equals(jmvo0218.getPhgp_regt_tgt__phgp_regt_cplt_yn()[i]) || "1".equals(jmvo0218.getPhgp_regt_tgt__phgp_regt_cplt_yn()[i])) count++;
		}
		
		if(count > 0 && count == jmvo0218.getPhgp_regt_tgt__dst_tty_dvn().length){
			request.setAttribute("reg_yn", "1");
		}else{
			request.setAttribute("reg_yn", "0");
		}
		
		logger.info("########### 전자서명용 할인특약사진등록 테스트 테스트 #######");
		logger.info("### reg_yn: " + request.getAttribute("reg_yn"));
		logger.info("### tgt_yn: " + mmti0213vo.getTrv_dstc_tty_exca_tgt_yn());
		logger.info("### aut_cgnt_cd: " + (String)session.getAttribute("aut_cgnt_trv_dstc_rsl_cd"));
		logger.info("### modify_mile: " + (String)session.getAttribute("modify_mile"));
		
		// 전계약 정산대상여부 확인(1: 정산대상)
		if("1".equals(mmti0213vo.getTrv_dstc_tty_exca_tgt_yn())){
			// OCR 정상인식 및 주행거리 미수정 확인(01: 정상판독, 0: 주행거리미수정)
			if("01".equals((String)session.getAttribute("aut_cgnt_trv_dstc_rsl_cd")) && "0".equals((String)session.getAttribute("modify_mile"))){
				// 전계약 정산 진행여부(1: 진행)
				session.setAttribute("ctn_yn", "1");
				
				// mmti0305vo.setSrch_cnd__vh_no(SeedUtil.encrypt(mmti0213vo.getVh_no()));
				mmti0305vo.setSrch_cnd__plno(mmti0213vo.getCtc_plno());
				mmti0305vo.setSrch_cnd__proc_dvn("01");
				mmti0305vo.setSrch_cnd__hdlr_empno("80000040");
				mmti0305vo.setSrch_cnd__trv_dstc_proc_dvcd("10");
				mmti0305vo = mileageTobeService.getMMTI0305VO(mmti0305vo);
				
				String arc_pd = mmti0305vo.getSrch_rsl__arc_pd().substring(0, 4)
						+ "." + mmti0305vo.getSrch_rsl__arc_pd().substring(4, 6)
						+ "." + mmti0305vo.getSrch_rsl__arc_pd().substring(6, 8);
				String arc_et = mmti0305vo.getSrch_rsl__arc_et().substring(0, 4)
						+ "." + mmti0305vo.getSrch_rsl__arc_et().substring(4, 6)
						+ "." + mmti0305vo.getSrch_rsl__arc_et().substring(6, 8);
				// 전계약 보험시기, 종기
				session.setAttribute("arc_pd", arc_pd);
				session.setAttribute("arc_et", arc_et);
				logger.info("### 정산대상, 정상판독, 주행거리미수정");
			}else{
				// 전계약 정산 진행여부(0: 미진행)
				session.setAttribute("ctn_yn", "0");
				logger.info("### 정산대상, 정상판독 아님");
			}
		}else{
			// 전계약 정산 진행여부(0: 미진행)
			session.setAttribute("ctn_yn", "0");
			logger.info("### 정산대상아님");
		}
		
		session.setAttribute("mmti0213vo", mmti0213vo);
		request.setAttribute("step", "03");
		request.setAttribute("dvn", "01");
		
		request.setAttribute("a", StringUtil.nvl(request.getParameter("a")));
//		request.setAttribute("sid", StringUtil.nvl(request.getParameter("sid")));
		request.setAttribute("pt", StringUtil.nvl(request.getParameter("pt")));
		request.setAttribute("chk", StringUtil.nvl(request.getParameter("chk")));
		request.setAttribute("mil_yn", StringUtil.nvl(request.getParameter("mil_yn")));
		request.setAttribute("bb_yn", StringUtil.nvl(request.getParameter("bb_yn")));
		request.setAttribute("ctn_yn", session.getAttribute("ctn_yn"));
		logger.info("### aiocr_up4로 이동. ctn_yn = " + session.getAttribute("ctn_yn"));
		return "/counter/carrider/tobe/aiocr_up4";
	}

	/** 할인형특약 - 주행거리신규(OCR) 등록 후 전계약 정산 시작 */
	@RequestMapping(value="/upMileageStep6")
	public @ResponseBody Map<String, String> upMileageStep6(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
	// @RequestMapping(value="/upMileageStep6")d
	// public String upMileageStep6(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		HttpSession session = request.getSession();
		Map<String, String> map = new HashMap<String, String>();
		MMTI0213VO mmti0213vo = new MMTI0213VO();
		MMTI0217VO mmti0217vo = new MMTI0217VO();
		MBTR01001VO mbtr01001vo = new MBTR01001VO();
		MBTT02001VO mbtt02001vo = new MBTT02001VO();
		String scrnNm = "upMileageStep6";
		
		if(session.getAttribute("p") != null) {
			mmti0217vo.setMbl_snd_no((String) session.getAttribute("p"));
		}
		else {
			mmti0217vo.setMbl_snd_no(aes256Decrypt(StringUtil.nvl(request.getParameter("p"))));
		}
		mmti0217vo = mileageTobeService.getMMTI0217VO(mmti0217vo);
		
		request.setAttribute("mmti0217vo", mmti0217vo);
		session.setAttribute("mmti0217vo", mmti0217vo);
		
		// 직전계약정보
		MMTI0213VO pre_mmti0213vo = new MMTI0213VO();
		// 가입 시 주행거리입력정보
		MMTI0259VO mmti0259vo = new MMTI0259VO();
		// 전계약 정산 시 주행거리입력정보
		MMTI0259VO pre_mmti0259vo = new MMTI0259VO();
		// 전계약 사서함번호 조회용
		MMTI0305VO mmti0305vo = new MMTI0305VO();
		
		// 현계약에서 전계약증번 가져오기
		mmti0213vo = (MMTI0213VO)session.getAttribute("mmti0213vo");
		
		/*
		String sms_ts_bvan = (String)session.getAttribute("sms_ts_bvan");
		mmti0213vo.setSms_ts_bvan(sms_ts_bvan);
		mmti0213vo = mileageTobeService.getMMTI0213VO(mmti0213vo);
		*/
		
		// 전계약증번으로 전계약 사서함번호 가져오기
		mmti0305vo.setSrch_cnd__plno(mmti0213vo.getCtc_plno());
		// mmti0305vo.setSrch_cnd__plno("220201439395000");
		
		mmti0305vo.setSrch_cnd__proc_dvn("02");
		mmti0305vo.setSrch_cnd__hdlr_empno("80000040");
		mmti0305vo.setSrch_cnd__trv_dstc_proc_dvcd("10");
		mmti0305vo = mileageTobeService.getMMTI0305VO(mmti0305vo);
		
		String pbox_no = mmti0305vo.getSrch_rsl__pbox_no();
		// 전계약 사서함번호
		session.setAttribute("pbox_no", pbox_no);
		
		
		// 전계약 사서함번호로 전계약정보 가져오기
		pre_mmti0213vo.setSms_ts_bvan(pbox_no);
		pre_mmti0213vo = mileageTobeService.getMMTI0213VO(pre_mmti0213vo);
		
		// 전계약 차량번호
		session.setAttribute("vh_no", pre_mmti0213vo.getVh_no());
		
		// 259, 259, edms => 환급금 발생 x -> 환급보험료 없다는 안내화면 이동, 있으면 연환산주행거리, 환급보험료 보여줌
		
		// 환산주행거리: 259.cnv_trv_dstc
		// 추징환급보험료: 259.adc_rtrn_prm
		//
		
		// 가입 시 주행거리 입력정보
		mmti0259vo = (MMTI0259VO)session.getAttribute("mileage_0259");
		
		// 전계약정산 주행거리정보 세팅
		pre_mmti0259vo.setPbox_use_yn("1");
		pre_mmti0259vo.setPbox_no(pbox_no);
		pre_mmti0259vo.setPhgp_cnfm_dt(DateUtil.getDate());
		pre_mmti0259vo.setPhgp_ptgr_dt(mmti0259vo.getPhgp_ptgr_dt());
		pre_mmti0259vo.setPhgp_strg_yn("1");
		
		// 213 자동인식 미적용여부 1: 미적용
		if("1".equals(pre_mmti0213vo.getAut_cgnt_nn_apcn_yn())){
			pre_mmti0259vo.setPbox_chr_nm(mmti0259vo.getPbox_chr_nm());
		}
		// 사서함번호 구분코드 1:주행거리
		if("1".equals(pre_mmti0213vo.getPbox_no_dvcd())){
			
			// 입력주행거리
			pre_mmti0259vo.setInpt_trv_dstc(mmti0259vo.getInpt_trv_dstc());
			if(!StringUtil.isEmpty(mmti0259vo.getAut_cgnt_vh_no())){
				pre_mmti0259vo.setAut_cgnt_vh_no(mmti0259vo.getAut_cgnt_vh_no());
			}
			if(!StringUtil.isEmpty(mmti0259vo.getAut_cgnt_vh_no_rsl_cd())){
				pre_mmti0259vo.setAut_cgnt_vh_no_rsl_cd(mmti0259vo.getAut_cgnt_vh_no_rsl_cd());
			}else{
				pre_mmti0259vo.setAut_cgnt_vh_no_rsl_cd("02");
			}
			// 자동인식주행거리
			if(!StringUtil.isEmpty(mmti0259vo.getAut_cgnt_trv_dstc())){
				pre_mmti0259vo.setAut_cgnt_trv_dstc(mmti0259vo.getAut_cgnt_trv_dstc());
			}
			// 자동인식주행거리결과코드(01:정상, 02: 오류, 03: OCR미적용)
			if(!StringUtil.isEmpty(mmti0259vo.getAut_cgnt_trv_dstc_rsl_cd())){
				pre_mmti0259vo.setAut_cgnt_trv_dstc_rsl_cd(mmti0259vo.getAut_cgnt_trv_dstc_rsl_cd());
			}else{
				pre_mmti0259vo.setAut_cgnt_trv_dstc_rsl_cd("02");
			}
			if(!StringUtil.isEmpty(mmti0259vo.getAut_cgnt_trv_dstc_1())){
				pre_mmti0259vo.setAut_cgnt_trv_dstc_1(mmti0259vo.getAut_cgnt_trv_dstc_1());
			}
			if(!StringUtil.isEmpty(mmti0259vo.getAut_cgnt_trv_dstc_2())){
				pre_mmti0259vo.setAut_cgnt_trv_dstc_2(mmti0259vo.getAut_cgnt_trv_dstc_2());
			}
			if(!StringUtil.isEmpty(mmti0259vo.getAut_cgnt_trv_dstc_3())){
				pre_mmti0259vo.setAut_cgnt_trv_dstc_3(mmti0259vo.getAut_cgnt_trv_dstc_3());
			}
		}
		if(!StringUtil.isEmpty(mmti0259vo.getPhgp_rl_ptgr_dt())){
			pre_mmti0259vo.setPhgp_rl_ptgr_dt(mmti0259vo.getPhgp_rl_ptgr_dt());
		}
		if(!StringUtil.isEmpty(mmti0259vo.getPhgp_apdx_way_cd())){
			pre_mmti0259vo.setPhgp_apdx_way_cd(mmti0259vo.getPhgp_apdx_way_cd());
		}
		
		// aiocr용 추가
		if (!StringUtil.isEmpty(mmti0259vo.getA_i_o_c_r_rqst_dsky_val())) {
			pre_mmti0259vo.setA_i_o_c_r_rqst_dsky_val(mmti0259vo.getA_i_o_c_r_rqst_dsky_val());
		}
		if (!StringUtil.isEmpty(mmti0259vo.getDtcn_cgnt_rt())) {
			pre_mmti0259vo.setDtcn_cgnt_rt(mmti0259vo.getDtcn_cgnt_rt());
		}
		if (!StringUtil.isEmpty(mmti0259vo.getCgnt_cgnt_rt())) {
			pre_mmti0259vo.setCgnt_cgnt_rt(mmti0259vo.getCgnt_cgnt_rt());
		}
		
		pre_mmti0259vo = mileageTobeService.getMMTI0259VO(pre_mmti0259vo);
		
		String exifDt = StringUtil.nvl((String)session.getAttribute("exifDt"));
		if("0".equals(pre_mmti0259vo.getErrorCode())){
			
			pre_mmti0259vo.setExp_exca_plan_proc_dvn("1");
			pre_mmti0259vo.setPlno(pre_mmti0213vo.getPlno());
			pre_mmti0259vo = mileageTobeService.getMMTI0259VO(pre_mmti0259vo);

			Object[] imgfile = (Object[])session.getAttribute("imgfile");
			
			if(!StringUtil.isEmpty(pre_mmti0259vo.getPlno()) && !StringUtil.isEmpty(pre_mmti0259vo.getExp_exca_plan_no())) {
				mbtr01001vo = mileageTobeService.regInfoToEdmsForMobileWeb2(exifDt, pre_mmti0213vo.getNtft_srv_rc_ormm_cd(), imgfile[0], pre_mmti0259vo.getPlno() + "," + pre_mmti0259vo.getExp_exca_plan_no(), mbtr01001vo);
			}
			else if(!StringUtil.isEmpty(pre_mmti0259vo.getPlno()) && StringUtil.isEmpty(pre_mmti0259vo.getExp_exca_plan_no())) {
				mbtr01001vo = mileageTobeService.regInfoToEdmsForMobileWeb2(exifDt, pre_mmti0213vo.getNtft_srv_rc_ormm_cd(), imgfile[0], pre_mmti0259vo.getPlno(), mbtr01001vo);
			}
		}
		
		int insertRow = 0;
		
		// VO SET
		mbtr01001vo.setPboxNo(pre_mmti0213vo.getSms_ts_bvan());
		mbtr01001vo.setApdxFlRutNm("");
		mbtr01001vo.setFrstIpmnEmpno("82101685");
		mbtr01001vo.setFnalAmdrEmpno("82101685");
		
		insertRow = mileageTobeService.insertTest(mbtr01001vo);
		if(insertRow < 1){
			logger.info("#### 사서함번호: " + StringUtil.nvl(mbtr01001vo.getPboxNo()) + "####");
			logger.info("#### insert 결과: Fail ####");
		}else{
			logger.info("#### insert 결과: Success ####");
		}
		
		// 간편정산 -> 설계보관/추징 등 아니면 다 확정요청
		if("1".equals(pre_mmti0213vo.getTrv_dstc_splc_exca_yn())) {
			if(pre_mmti0259vo.getExp_exca_plan_rsl_cd().equals("11") || pre_mmti0259vo.getExp_exca_plan_rsl_cd().equals("13")
					|| pre_mmti0259vo.getExp_exca_plan_rsl_cd().equals("14")) {
				MMTI0291VO mmti0291vo = new MMTI0291VO();
				// 정산업무처리구분(2: 확정)
				mmti0291vo.setTrv_dstc_exca_mtt__exca_bz_proc_dvn("2");
				mmti0291vo.setTrv_dstc_exca_mtt__plno(StringUtil.nvl(pre_mmti0259vo.getPlno()));
				mmti0291vo.setTrv_dstc_exca_mtt__plan_no(StringUtil.nvl(pre_mmti0259vo.getExp_exca_plan_no()));
				// 정산환급구분(1:계좌환급, 2: 갱신계약활용, 확정인 경우만 필수 이외 null) -> 수정?
				mmti0291vo.setTrv_dstc_exca_mtt__exca_rtrn_dvn("");
				// 상품출처구분(TM,CM,TD)
				mmti0291vo.setTrv_dstc_exca_mtt__pdc_sr_dvn(StringUtil.nvl(pre_mmti0259vo.getPdc_sr_dvn()));
				// 추징환급구분(1:추징, 2:환급, 3:미발생, 환급인 경우만 확정처리함)
				mmti0291vo.setTrv_dstc_exca_mtt__adc_rtrn_dvn(StringUtil.nvl(pre_mmti0259vo.getAdc_rtrn_dvn()));
				// 추징환급보험료
				mmti0291vo.setTrv_dstc_exca_mtt__adc_rtrn_prm(StringUtil.nvl(pre_mmti0259vo.getAdc_rtrn_prm()));
				// 화면처리코드(259.만기정산설계결과코드)
				mmti0291vo.setTrv_dstc_exca_mtt__scrn_proc_cd(StringUtil.nvl(pre_mmti0259vo.getExp_exca_plan_rsl_cd()));
				// 주행거리간편정산여부(1: 주행거리간편정산)
				mmti0291vo.setTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn(pre_mmti0213vo.getTrv_dstc_splc_exca_yn());
				// 사서함번호
				mmti0291vo.setTrv_dstc_exca_mtt__pbox_no(pre_mmti0213vo.getSms_ts_bvan());
				mmti0291vo = mileageTobeService.getMMTI0291VO(mmti0291vo);
				
				request.setAttribute("z_resp_cd", mmti0291vo.getZ_resp_cd());
				request.setAttribute("z_resp_msg", mmti0291vo.getZ_resp_msg());
				// 화면분기용
				session.setAttribute("z_resp_cd", mmti0291vo.getZ_resp_cd());
				session.setAttribute("z_resp_msg", mmti0291vo.getZ_resp_msg());
				
				// 이미지 중복이면 확정신청페이지
				if("1".equals(mmti0291vo.getTrv_dstc_exca_mtt__imag_dup_yn())){
					pre_mmti0259vo.setExp_exca_plan_rsl_cd("14");
				}
				
				// CM 상품이고, 화면처리코드 IN(02, 14) or 이미지 중복
				
				if("CM".equals(mmti0291vo.getTrv_dstc_exca_mtt__pdc_sr_dvn()) && 
						("02".equals(mmti0291vo.getTrv_dstc_exca_mtt__scrn_proc_cd())
						|| "14".equals(mmti0291vo.getTrv_dstc_exca_mtt__scrn_proc_cd()))){
					
					MMTI0015VO mmti0015vo = new MMTI0015VO();
					mmti0015vo.setFunt_key("00");
					mmti0015vo.setPlan_no(mmti0291vo.getTrv_dstc_exca_mtt__plan_no());
					mmti0015vo = mileageTobeService.getMMTI0015VO(mmti0015vo);
					
					logger.debug("##### MMTI0015 시작 ##########################");
					logger.debug("##### 고객식별번호: " + mmti0015vo.getPlhd__cust_dcmt_no() + " ##########################");
					logger.debug("##### 고객번호: " + mmti0015vo.getPlhd__cust_no() + " ##########################");
					logger.debug("##### 고객명: " + mmti0015vo.getPlhd__cust_nm() + " ##########################");
					logger.debug("##### 이메일: " + mmti0015vo.getPlhd__eml() + " ##########################");
					logger.debug("##### 지역번호: " + mmti0015vo.getPlhd_cntp_if__tlp_arno() + " ##########################");
					logger.debug("##### 국번호: " + mmti0015vo.getPlhd_cntp_if__tlp_ofno() + " ##########################");
					logger.debug("##### 개별번호: " + mmti0015vo.getPlhd_cntp_if__tlp_idvno() + " ##########################");
					
					XTEM0021VO xtem0021vo = new XTEM0021VO();
					xtem0021vo.setCnsl_rpt_no("");						// 상담접수번호				
					xtem0021vo.setCm_bz_dvcd("05");
					xtem0021vo.setCnsl_typ_dvcd("07");
					xtem0021vo.setCm_plan_no(mmti0291vo.getTrv_dstc_exca_mtt__plan_no());
					xtem0021vo.setCnsl_rpy_dvcd("1");
					xtem0021vo.setCnsl_rpt_dttm(getDayTime());			// 현재년월일시분초 14자리
					xtem0021vo.setCust_nm(mmti0015vo.getPlhd__cust_nm());
					xtem0021vo.setCust_no(mmti0015vo.getPlhd__cust_no());
					
					String cust_dcmt_no = SeedUtil.decrypt(mmti0015vo.getPlhd__cust_dcmt_no());
					
					if("1".equals(cust_dcmt_no.substring(6, 7)) || "2".equals(cust_dcmt_no.substring(6, 7))
						|| "5".equals(cust_dcmt_no.substring(6, 7)) || "6".equals(cust_dcmt_no.substring(6, 7))){
						xtem0021vo.setBrth("19" + cust_dcmt_no.substring(0, 6));
					} else{
						xtem0021vo.setBrth("20" + cust_dcmt_no.substring(0, 6));
					}
					// xtem0021vo.setBrth("");  							// 생년월일
					xtem0021vo.setSx_cd(cust_dcmt_no.substring(6, 7));
					xtem0021vo.setEml_adr(mmti0015vo.getPlhd__eml());
					xtem0021vo.setClp_tlcno(mmti0015vo.getPlhd_cntp_if__tlp_arno());
					xtem0021vo.setClp_ofno(mmti0015vo.getPlhd_cntp_if__tlp_ofno());
					xtem0021vo.setClp_idvno(mmti0015vo.getPlhd_cntp_if__tlp_idvno());
					xtem0021vo.setCnsl_rsvt_dt("99990101");
					xtem0021vo.setCnsl_rsvt_time_cd("1");
					xtem0021vo.setCnsl_cn("최종주행거리사진등록/만기정산");
					xtem0021vo.setCnsl_aply_csn_yn("1");
					xtem0021vo.setUrl_adr("");
					xtem0021vo.setCm_ctrmf_tpcd("32");
					xtem0021vo.setFrst_ipmn_empno("80000028");
					xtem0021vo.setFrst_ipnpt_dttm(getDayTime());		// 현재년월일시분초 14자리	
					
					xtem0021vo = mileageTobeService.getXTEM0021VO(xtem0021vo);
					logger.debug("##### XTEM0021 시작 ##########################");
					logger.debug("##### 처리결과: [ " + xtem0021vo.getProc_rtn() + " ] ##########################");
				}
				
				//MMTI0291전문 정산이력테이블(MBTT02001) 적재
				mbtt02001vo.setPboxNo(StringUtil.nvl(mmti0213vo.getSms_ts_bvan()));
				mbtt02001vo.setTlgIdVal("MMTI0291");
				mbtt02001vo.setEsbTrscId(StringUtil.nvl(mmti0291vo.getZ_trsc_id()));
				if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__plno()) || null == mmti0291vo.getTrv_dstc_exca_mtt__plno()){
					mbtt02001vo.setPlno(" ");
				} else {
					mbtt02001vo.setPlno(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__plno()));
				}
				if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__plan_no()) || null == mmti0291vo.getTrv_dstc_exca_mtt__plan_no()){
					mbtt02001vo.setPlanNo(" ");
				} else {
					mbtt02001vo.setPlanNo(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__plan_no()));
				}
				if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__rnw_plno()) || null == mmti0291vo.getTrv_dstc_exca_mtt__rnw_plno()){
					mbtt02001vo.setRnwPlno(" ");
				} else {
					mbtt02001vo.setRnwPlno(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__rnw_plno()));
				}
				mbtt02001vo.setTlgProcRslCdVal(StringUtil.nvl(mmti0291vo.getZ_tlg_sp_cd()));
				mbtt02001vo.setTlgErrCdVal(StringUtil.nvl(mmti0291vo.getZ_trns_org_dvcd())+StringUtil.nvl(mmti0291vo.getZ_trns_org_cd()));
				if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__hdlr_empno()) || null == mmti0291vo.getTrv_dstc_exca_mtt__hdlr_empno()){
					mbtt02001vo.setHdlrEmpno(" ");
				} else {
					mbtt02001vo.setHdlrEmpno(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__hdlr_empno()));
				}
				if("".equals(request.getParameter("pbox_no_dvcd")) || null == request.getParameter("pbox_no_dvcd")){
					mbtt02001vo.setPboxNoDvcd(" ");
				} else {
					mbtt02001vo.setPboxNoDvcd(StringUtil.nvl(request.getParameter("pbox_no_dvcd")));
				}
				if("".equals(request.getParameter("proc_dvn")) || null == request.getParameter("proc_dvn")){
					mbtt02001vo.setProcDvn(" ");
				} else {
					mbtt02001vo.setProcDvn(StringUtil.nvl(request.getParameter("proc_dvn")));
				}
				if("".equals(request.getParameter("trv_dstc_exp_exca_dvcd")) || null == request.getParameter("trv_dstc_exp_exca_dvcd")){
					mbtt02001vo.setTrvDstcExpExcaDvcd(" ");
				} else {
					mbtt02001vo.setTrvDstcExpExcaDvcd(StringUtil.nvl(request.getParameter("trv_dstc_exp_exca_dvcd")));
				}
				if("".equals(request.getParameter("trv_dstc_chng_aply_dvn")) || null == request.getParameter("trv_dstc_chng_aply_dvn")){
					mbtt02001vo.setTrvDstcChngAplyDvn(" ");
				} else {
					mbtt02001vo.setTrvDstcChngAplyDvn(StringUtil.nvl(request.getParameter("trv_dstc_chng_aply_dvn")));
				}
				if("".equals(request.getParameter("hdlr_fire_yn")) || null == request.getParameter("hdlr_fire_yn")){
					mbtt02001vo.setHdlrFireYn(" ");
				} else {
					mbtt02001vo.setHdlrFireYn(StringUtil.nvl(request.getParameter("hdlr_fire_yn")));
				}
				if("".equals(request.getParameter("mtcc_yn")) || null == request.getParameter("mtcc_yn")){
					mbtt02001vo.setMtccYn(" ");
				} else {
					mbtt02001vo.setMtccYn(StringUtil.nvl(request.getParameter("mtcc_yn")));
				}
				if("".equals(request.getParameter("aut_cgnt_trv_dstc")) || null == request.getParameter("aut_cgnt_trv_dstc")){
					mbtt02001vo.setAutCgntTrvDstc(0);
				} else {
					mbtt02001vo.setAutCgntTrvDstc(Double.parseDouble(request.getParameter("aut_cgnt_trv_dstc")));
				}
				if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__aut_cgnt_trv_dstc_rsl_cd()) || null == mmti0291vo.getTrv_dstc_exca_mtt__aut_cgnt_trv_dstc_rsl_cd()){
					mbtt02001vo.setAutCgntTrvDstcRslCd(" ");
				} else {
					mbtt02001vo.setAutCgntTrvDstcRslCd(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__aut_cgnt_trv_dstc_rsl_cd()));
				}
				if("".equals(request.getParameter("inptTrvDstc")) || null == request.getParameter("inptTrvDstc")){
					mbtt02001vo.setInptTrvDstc(0);
				} else {
					mbtt02001vo.setInptTrvDstc(Double.parseDouble(request.getParameter("inptTrvDstc")));
				}
				if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__cnv_trv_dstc()) || null == mmti0291vo.getTrv_dstc_exca_mtt__cnv_trv_dstc()){
					mbtt02001vo.setCnvTrvDstc(0);
				} else {
					mbtt02001vo.setCnvTrvDstc(Double.parseDouble(mmti0291vo.getTrv_dstc_exca_mtt__cnv_trv_dstc()));
				}
				if("".equals(request.getParameter("exp_exca_plan_rsl_cd")) || null == request.getParameter("exp_exca_plan_rsl_cd")){
					mbtt02001vo.setExpExcaPlanRslCd(" ");
				} else {
					mbtt02001vo.setExpExcaPlanRslCd(StringUtil.nvl(request.getParameter("exp_exca_plan_rsl_cd")));
				}
				if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__exca_bz_proc_dvn()) || null == mmti0291vo.getTrv_dstc_exca_mtt__exca_bz_proc_dvn()){
					mbtt02001vo.setExcaBzProcDvn(" ");
				} else {
					mbtt02001vo.setExcaBzProcDvn(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__exca_bz_proc_dvn()));
				}
				if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__exca_rtrn_dvn()) || null == mmti0291vo.getTrv_dstc_exca_mtt__exca_rtrn_dvn()){
					mbtt02001vo.setExcaRtrnDvn(" ");
				} else {
					mbtt02001vo.setExcaRtrnDvn(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__exca_rtrn_dvn()));
				}
				if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__pdc_sr_dvn()) || null == mmti0291vo.getTrv_dstc_exca_mtt__pdc_sr_dvn()){
					mbtt02001vo.setPdcSrDvn(" ");
				} else {
					mbtt02001vo.setPdcSrDvn(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__pdc_sr_dvn()));
				}
				if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__adc_rtrn_prm()) || null == mmti0291vo.getTrv_dstc_exca_mtt__adc_rtrn_prm()){
					mbtt02001vo.setAdcRtrnPrm(0);
				} else {
					mbtt02001vo.setAdcRtrnPrm(Double.parseDouble(mmti0291vo.getTrv_dstc_exca_mtt__adc_rtrn_prm()));
				}
				if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn()) || null == mmti0291vo.getTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn()){
					mbtt02001vo.setTrvDstcSplcExcaYn(" ");
				} else {
					mbtt02001vo.setTrvDstcSplcExcaYn(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn()));
				}
				if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__imag_dup_yn()) || null == mmti0291vo.getTrv_dstc_exca_mtt__imag_dup_yn()){
					mbtt02001vo.setImagDupYn(" ");
				} else {
					mbtt02001vo.setImagDupYn(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__imag_dup_yn()));
				}
				if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__nrm_proc_yn()) || null == mmti0291vo.getTrv_dstc_exca_mtt__nrm_proc_yn()){
					mbtt02001vo.setNrmProcYn(" ");
				} else {
					mbtt02001vo.setNrmProcYn(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__nrm_proc_yn()));
				}
				if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__crd_scn_cncl_pss_yn()) || null == mmti0291vo.getTrv_dstc_exca_mtt__crd_scn_cncl_pss_yn()){
					mbtt02001vo.setCrdScnCnclPssYn(" ");
				} else {
					mbtt02001vo.setCrdScnCnclPssYn(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__crd_scn_cncl_pss_yn()));
				}
				mbtt02001vo.setRespCn(StringUtil.nvl(mmti0291vo.getZ_resp_cd()));
				mbtt02001vo.setRslCn(scrnNm + "_" + StringUtil.nvl(mmti0291vo.getZ_resp_msg()));
				mbtt02001vo.setFrstIpmnEmpno("82101685");
				mbtt02001vo.setFnalAmdrEmpno("82101685");
				if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__adc_rtrn_dvn()) || null == mmti0291vo.getTrv_dstc_exca_mtt__adc_rtrn_dvn()){
					mbtt02001vo.setAdcRtrnDvn(" ");
				} else {
					mbtt02001vo.setAdcRtrnDvn(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__adc_rtrn_dvn()));
				}
				if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__scrn_proc_cd()) || null == mmti0291vo.getTrv_dstc_exca_mtt__scrn_proc_cd()){
					mbtt02001vo.setScrnProcCd(" ");
				} else {
					mbtt02001vo.setScrnProcCd(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__scrn_proc_cd()));
				}
				if("".equals(request.getParameter("ctc_plno")) || null == request.getParameter("ctc_plno")){
					mbtt02001vo.setCtcPlno(" ");
				} else {
					mbtt02001vo.setCtcPlno(StringUtil.nvl(request.getParameter("ctc_plno")));
				}
				if("".equals(request.getParameter("trv_dstc_proc_dvcd")) || null == request.getParameter("trv_dstc_proc_dvcd")){
					mbtt02001vo.setTrvDstcProcDvcd(" ");
				} else {
					mbtt02001vo.setTrvDstcProcDvcd(StringUtil.nvl(request.getParameter("trv_dstc_proc_dvcd")));
				}
				if("".equals(request.getParameter("mbl_snd_no")) || null == request.getParameter("mbl_snd_no")){
					mbtt02001vo.setMblSndNo(" ");
				} else {
					mbtt02001vo.setMblSndNo(StringUtil.nvl(request.getParameter("mbl_snd_no")));
				}
				if("".equals(request.getParameter("plan_plno_dvcd")) || null == request.getParameter("plan_plno_dvcd")){
					mbtt02001vo.setPlanPlnoDvcd(" ");
				} else {
					mbtt02001vo.setPlanPlnoDvcd(StringUtil.nvl(request.getParameter("plan_plno_dvcd")));
				}
				if("".equals(request.getParameter("plan_plno")) || null == request.getParameter("plan_plno")){
					mbtt02001vo.setPlanPlno(" ");
				} else {
					mbtt02001vo.setPlanPlno(StringUtil.nvl(request.getParameter("plan_plno")));
				}
				if("".equals(request.getParameter("chng_plan_no")) || null == request.getParameter("chng_plan_no")){
					mbtt02001vo.setChngPlanNo(" ");
				} else {
					mbtt02001vo.setChngPlanNo(StringUtil.nvl(request.getParameter("chng_plan_no")));
				}
				if("".equals(request.getParameter("dst_tty_dvn1")) || null == request.getParameter("dst_tty_dvn1")){
					mbtt02001vo.setDstTtyDvn1(" ");
				} else {
					mbtt02001vo.setDstTtyDvn1(StringUtil.nvl(request.getParameter("dst_tty_dvn1")));
				}
				if("".equals(request.getParameter("dst_tty_dvn2")) || null == request.getParameter("dst_tty_dvn2")){
					mbtt02001vo.setDstTtyDvn2(" ");
				} else {
					mbtt02001vo.setDstTtyDvn2(StringUtil.nvl(request.getParameter("dst_tty_dvn2")));
				}
				if("".equals(request.getParameter("dst_tty_dvn3")) || null == request.getParameter("dst_tty_dvn3")){
					mbtt02001vo.setDstTtyDvn3(" ");
				} else {
					mbtt02001vo.setDstTtyDvn3(StringUtil.nvl(request.getParameter("dst_tty_dvn3")));
				}
				if("".equals(request.getParameter("dst_tty_dvn4")) || null == request.getParameter("dst_tty_dvn4")){
					mbtt02001vo.setDstTtyDvn4(" ");
				} else {
					mbtt02001vo.setDstTtyDvn4(StringUtil.nvl(request.getParameter("dst_tty_dvn4")));
				}
				if("".equals(request.getParameter("dst_tty_dvn5")) || null == request.getParameter("dst_tty_dvn5")){
					mbtt02001vo.setDstTtyDvn5(" ");
				} else {
					mbtt02001vo.setDstTtyDvn5(StringUtil.nvl(request.getParameter("dst_tty_dvn5")));
				}
				if("".equals(request.getParameter("phgp_regt_tgt1")) || null == request.getParameter("phgp_regt_tgt1")){
					mbtt02001vo.setPhgpRegtTgt1(" ");
				} else {
					mbtt02001vo.setPhgpRegtTgt1(StringUtil.nvl(request.getParameter("phgp_regt_tgt1")));
				}
				if("".equals(request.getParameter("phgp_regt_tgt2")) || null == request.getParameter("phgp_regt_tgt2")){
					mbtt02001vo.setPhgpRegtTgt2(" ");
				} else {
					mbtt02001vo.setPhgpRegtTgt2(StringUtil.nvl(request.getParameter("phgp_regt_tgt2")));
				}
				if("".equals(request.getParameter("phgp_regt_tgt3")) || null == request.getParameter("phgp_regt_tgt3")){
					mbtt02001vo.setPhgpRegtTgt3(" ");
				} else {
					mbtt02001vo.setPhgpRegtTgt3(StringUtil.nvl(request.getParameter("phgp_regt_tgt3")));
				}
				if("".equals(request.getParameter("phgp_regt_tgt4")) || null == request.getParameter("phgp_regt_tgt4")){
					mbtt02001vo.setPhgpRegtTgt4(" ");
				} else {
					mbtt02001vo.setPhgpRegtTgt4(StringUtil.nvl(request.getParameter("phgp_regt_tgt4")));
				}
				if("".equals(request.getParameter("phgp_regt_tgt5")) || null == request.getParameter("phgp_regt_tgt5")){
					mbtt02001vo.setPhgpRegtTgt5(" ");
				} else {
					mbtt02001vo.setPhgpRegtTgt5(StringUtil.nvl(request.getParameter("phgp_regt_tgt5")));
				}
				
				//MMTI0291 insert
				insertRow = 0;
				
				logger.info("#### upMileageStep6 MMTI0291 MBTT02001 before ####");
				insertRow = mileageTobeService.insertJungsanTest(mbtt02001vo);
				logger.info("#### upMileageStep6 MMTI0291 MBTT02001 after ####");
				
				if(insertRow < 1){
					logger.info("#### 사서함번호: " + StringUtil.nvl(mbtt02001vo.getPboxNo()) + "####");
					logger.info("#### insert 결과: Fail ####");
				}else{
					logger.info("#### insert 결과: Success ####");
				}
			}
		}
		
		session.setAttribute("pre_mmti0213vo", pre_mmti0213vo);
		session.setAttribute("pre_mmti0259vo", pre_mmti0259vo);
		
		
		request.setAttribute("dvn", "01");
		
		MMTI0218VO jmvo0218 = new MMTI0218VO();
		
		jmvo0218.setMbl_snd_no(mmti0217vo.getMbl_snd_no());
		jmvo0218.setPlan_plno_dvcd(mmti0217vo.getPlan_plno_dvcd());
		jmvo0218.setPlan_plno(mmti0217vo.getPlan_plno());
		jmvo0218.setChng_plan_no(mmti0217vo.getChng_plan_no());
		
		jmvo0218 = mileageTobeService.getMMTI0218VO(jmvo0218);
		int count = 0;
		for(int i = 0; i < jmvo0218.getPhgp_regt_tgt__dst_tty_dvn().length; i++) {
			if("Y".equals(jmvo0218.getPhgp_regt_tgt__phgp_regt_cplt_yn()[i]) || "1".equals(jmvo0218.getPhgp_regt_tgt__phgp_regt_cplt_yn()[i])) count++;
		}
		
		//MMTI0218전문 정산이력테이블(MBTT02001) 적재
		mbtt02001vo.setPboxNo(StringUtil.nvl(pre_mmti0213vo.getSms_ts_bvan()));
		mbtt02001vo.setTlgIdVal("MMTI0218");
		mbtt02001vo.setEsbTrscId(StringUtil.nvl(jmvo0218.getZ_trsc_id()));
		if("".equals(request.getParameter("plno")) || null == request.getParameter("plno")){
			mbtt02001vo.setPlno(" ");
		} else {
			mbtt02001vo.setPlno(StringUtil.nvl(request.getParameter("plno")));
		}
		if("".equals(request.getParameter("plan_no")) || null == request.getParameter("plan_no")){
			mbtt02001vo.setPlanNo(" ");
		} else {
			mbtt02001vo.setPlanNo(StringUtil.nvl(request.getParameter("plan_no")));
		}
		if("".equals(request.getParameter("rnw_plno")) || null == request.getParameter("rnw_plno")){
			mbtt02001vo.setRnwPlno(" ");
		} else {
			mbtt02001vo.setRnwPlno(StringUtil.nvl(request.getParameter("rnw_plno")));
		}
		mbtt02001vo.setTlgProcRslCdVal(StringUtil.nvl(jmvo0218.getZ_tlg_sp_cd()));
		mbtt02001vo.setTlgErrCdVal(StringUtil.nvl(jmvo0218.getZ_trns_org_dvcd())+StringUtil.nvl(jmvo0218.getZ_trns_org_cd()));
		if("".equals(request.getParameter("hdlr_empno")) || null == request.getParameter("hdlr_empno")){
			mbtt02001vo.setHdlrEmpno(" ");
		} else {
			mbtt02001vo.setHdlrEmpno(StringUtil.nvl(request.getParameter("hdlr_empno")));
		}
		if("".equals(request.getParameter("pbox_no_dvcd")) || null == request.getParameter("pbox_no_dvcd")){
			mbtt02001vo.setPboxNoDvcd(" ");
		} else {
			mbtt02001vo.setPboxNoDvcd(StringUtil.nvl(request.getParameter("pbox_no_dvcd")));
		}
		if("".equals(request.getParameter("proc_dvn")) || null == request.getParameter("proc_dvn")){
			mbtt02001vo.setProcDvn(" ");
		} else {
			mbtt02001vo.setProcDvn(StringUtil.nvl(request.getParameter("proc_dvn")));
		}
		if("".equals(request.getParameter("trv_dstc_exp_exca_dvcd")) || null == request.getParameter("trv_dstc_exp_exca_dvcd")){
			mbtt02001vo.setTrvDstcExpExcaDvcd(" ");
		} else {
			mbtt02001vo.setTrvDstcExpExcaDvcd(StringUtil.nvl(request.getParameter("trv_dstc_exp_exca_dvcd")));
		}
		if("".equals(request.getParameter("trv_dstc_chng_aply_dvn")) || null == request.getParameter("trv_dstc_chng_aply_dvn")){
			mbtt02001vo.setTrvDstcChngAplyDvn(" ");
		} else {
			mbtt02001vo.setTrvDstcChngAplyDvn(StringUtil.nvl(request.getParameter("trv_dstc_chng_aply_dvn")));
		}
		if("".equals(request.getParameter("hdlr_fire_yn")) || null == request.getParameter("hdlr_fire_yn")){
			mbtt02001vo.setHdlrFireYn(" ");
		} else {
			mbtt02001vo.setHdlrFireYn(StringUtil.nvl(request.getParameter("hdlr_fire_yn")));
		}
		if("".equals(request.getParameter("mtcc_yn")) || null == request.getParameter("mtcc_yn")){
			mbtt02001vo.setMtccYn(" ");
		} else {
			mbtt02001vo.setMtccYn(StringUtil.nvl(request.getParameter("mtcc_yn")));
		}
		if("".equals(request.getParameter("aut_cgnt_trv_dstc")) || null == request.getParameter("aut_cgnt_trv_dstc")){
			mbtt02001vo.setAutCgntTrvDstc(0);
		} else {
			mbtt02001vo.setAutCgntTrvDstc(Double.parseDouble(request.getParameter("aut_cgnt_trv_dstc")));
		}
		if("".equals(request.getParameter("aut_cgnt_trv_dstc_rsl_cd")) || null == request.getParameter("aut_cgnt_trv_dstc_rsl_cd")){
			mbtt02001vo.setAutCgntTrvDstcRslCd(" ");
		} else {
			mbtt02001vo.setAutCgntTrvDstcRslCd(StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc_rsl_cd")));
		}
		if("".equals(request.getParameter("inptTrvDstc")) || null == request.getParameter("inptTrvDstc")){
			mbtt02001vo.setInptTrvDstc(0);
		} else {
			mbtt02001vo.setInptTrvDstc(Double.parseDouble(request.getParameter("inptTrvDstc")));
		}
		if("".equals(request.getParameter("cnv_trv_dstc")) || null == request.getParameter("cnv_trv_dstc")){
			mbtt02001vo.setCnvTrvDstc(0);
		} else {
			mbtt02001vo.setCnvTrvDstc(Double.parseDouble(request.getParameter("cnv_trv_dstc")));
		}
		if("".equals(request.getParameter("exp_exca_plan_rsl_cd")) || null == request.getParameter("exp_exca_plan_rsl_cd")){
			mbtt02001vo.setExpExcaPlanRslCd(" ");
		} else {
			mbtt02001vo.setExpExcaPlanRslCd(StringUtil.nvl(request.getParameter("exp_exca_plan_rsl_cd")));
		}
		if("".equals(request.getParameter("exca_bz_proc_dvn")) || null == request.getParameter("exca_bz_proc_dvn")){
			mbtt02001vo.setExcaBzProcDvn(" ");
		} else {
			mbtt02001vo.setExcaBzProcDvn(StringUtil.nvl(request.getParameter("exca_bz_proc_dvn")));
		}
		if("".equals(request.getParameter("exca_rtrn_dvn")) || null == request.getParameter("exca_rtrn_dvn")){
			mbtt02001vo.setExcaRtrnDvn(" ");
		} else {
			mbtt02001vo.setExcaRtrnDvn(StringUtil.nvl(request.getParameter("exca_rtrn_dvn")));
		}
		if("".equals(request.getParameter("pdc_sr_dvn")) || null == request.getParameter("pdc_sr_dvn")){
			mbtt02001vo.setPdcSrDvn(" ");
		} else {
			mbtt02001vo.setPdcSrDvn(StringUtil.nvl(request.getParameter("pdc_sr_dvn")));
		}
		if("".equals(request.getParameter("adc_rtrn_prm")) || null == request.getParameter("adc_rtrn_prm")){
			mbtt02001vo.setAdcRtrnPrm(0);
		} else {
			mbtt02001vo.setAdcRtrnPrm(Double.parseDouble(request.getParameter("adc_rtrn_prm")));
		}
		if("".equals(request.getParameter("trv_dstc_splc_exca_yn")) || null == request.getParameter("trv_dstc_splc_exca_yn")){
			mbtt02001vo.setTrvDstcSplcExcaYn(" ");
		} else {
			mbtt02001vo.setTrvDstcSplcExcaYn(StringUtil.nvl(request.getParameter("trv_dstc_splc_exca_yn")));
		}
		if("".equals(request.getParameter("imag_dup_yn")) || null == request.getParameter("imag_dup_yn")){
			mbtt02001vo.setImagDupYn(" ");
		} else {
			mbtt02001vo.setImagDupYn(StringUtil.nvl(request.getParameter("imag_dup_yn")));
		}
		if("".equals(request.getParameter("nrm_proc_yn")) || null == request.getParameter("nrm_proc_yn")){
			mbtt02001vo.setNrmProcYn(" ");
		} else {
			mbtt02001vo.setNrmProcYn(StringUtil.nvl(request.getParameter("nrm_proc_yn")));
		}
		if("".equals(request.getParameter("crd_scn_cncl_pss_yn")) || null == request.getParameter("crd_scn_cncl_pss_yn")){
			mbtt02001vo.setCrdScnCnclPssYn(" ");
		} else {
			mbtt02001vo.setCrdScnCnclPssYn(StringUtil.nvl(request.getParameter("crd_scn_cncl_pss_yn")));
		}
		mbtt02001vo.setRespCn(StringUtil.nvl(jmvo0218.getZ_resp_cd()));
		mbtt02001vo.setRslCn(scrnNm + "_" + StringUtil.nvl(jmvo0218.getZ_resp_msg()));
		mbtt02001vo.setFrstIpmnEmpno("82101685");
		mbtt02001vo.setFnalAmdrEmpno("82101685");
		if("".equals(request.getParameter("adc_rtrn_dvn")) || null == request.getParameter("adc_rtrn_dvn")){
			mbtt02001vo.setAdcRtrnDvn(" ");
		} else {
			mbtt02001vo.setAdcRtrnDvn(StringUtil.nvl(request.getParameter("adc_rtrn_dvn")));
		}
		if("".equals(request.getParameter("scrn_proc_cd")) || null == request.getParameter("scrn_proc_cd")){
			mbtt02001vo.setScrnProcCd(" ");
		} else {
			mbtt02001vo.setScrnProcCd(StringUtil.nvl(request.getParameter("scrn_proc_cd")));
		}
		if("".equals(request.getParameter("ctc_plno")) || null == request.getParameter("ctc_plno")){
			mbtt02001vo.setCtcPlno(" ");
		} else {
			mbtt02001vo.setCtcPlno(StringUtil.nvl(request.getParameter("ctc_plno")));
		}
		if("".equals(request.getParameter("trv_dstc_proc_dvcd")) || null == request.getParameter("trv_dstc_proc_dvcd")){
			mbtt02001vo.setTrvDstcProcDvcd(" ");
		} else {
			mbtt02001vo.setTrvDstcProcDvcd(StringUtil.nvl(request.getParameter("trv_dstc_proc_dvcd")));
		}
		if("".equals(jmvo0218.getMbl_snd_no()) || null == jmvo0218.getMbl_snd_no()){
			mbtt02001vo.setMblSndNo(" ");
		} else {
			mbtt02001vo.setMblSndNo(StringUtil.nvl(jmvo0218.getMbl_snd_no()));
		}
		if("".equals(jmvo0218.getPlan_plno_dvcd()) || null == jmvo0218.getPlan_plno_dvcd()){
			mbtt02001vo.setPlanPlnoDvcd(" ");
		} else {
			mbtt02001vo.setPlanPlnoDvcd(StringUtil.nvl(jmvo0218.getPlan_plno_dvcd()));
		}
		if("".equals(jmvo0218.getPlan_plno()) || null == jmvo0218.getPlan_plno()){
			mbtt02001vo.setPlanPlno(" ");
		} else {
			mbtt02001vo.setPlanPlno(StringUtil.nvl(jmvo0218.getPlan_plno()));
		}
		if("".equals(jmvo0218.getChng_plan_no()) || null == jmvo0218.getChng_plan_no()){
			mbtt02001vo.setChngPlanNo(" ");
		} else {
			mbtt02001vo.setChngPlanNo(StringUtil.nvl(jmvo0218.getChng_plan_no()));
		}
		
		for(int i = 0; i < jmvo0218.getPhgp_regt_tgt__dst_tty_dvn().length; i++) {
			if(!"".equals(jmvo0218.getPhgp_regt_tgt__dst_tty_dvn()[i]) || null != jmvo0218.getPhgp_regt_tgt__dst_tty_dvn()[i]) {
				if("01".equals(jmvo0218.getPhgp_regt_tgt__dst_tty_dvn()[i])){
					mbtt02001vo.setDstTtyDvn1("01");
					mbtt02001vo.setPhgpRegtTgt1(jmvo0218.getPhgp_regt_tgt__phgp_regt_cplt_yn()[i]);
				}
				else if("02".equals(jmvo0218.getPhgp_regt_tgt__dst_tty_dvn()[i])){
					mbtt02001vo.setDstTtyDvn2("02");
					mbtt02001vo.setPhgpRegtTgt2(jmvo0218.getPhgp_regt_tgt__phgp_regt_cplt_yn()[i]);
				}
				else if("03".equals(jmvo0218.getPhgp_regt_tgt__dst_tty_dvn()[i])){
					mbtt02001vo.setDstTtyDvn3("03");
					mbtt02001vo.setPhgpRegtTgt3(jmvo0218.getPhgp_regt_tgt__phgp_regt_cplt_yn()[i]);
				}
				else if("04".equals(jmvo0218.getPhgp_regt_tgt__dst_tty_dvn()[i])){
					mbtt02001vo.setDstTtyDvn4("04");
					mbtt02001vo.setPhgpRegtTgt4(jmvo0218.getPhgp_regt_tgt__phgp_regt_cplt_yn()[i]);
				}
				else if("05".equals(jmvo0218.getPhgp_regt_tgt__dst_tty_dvn()[i])){
					mbtt02001vo.setDstTtyDvn5("05");
					mbtt02001vo.setPhgpRegtTgt5(jmvo0218.getPhgp_regt_tgt__phgp_regt_cplt_yn()[i]);
				}
			} 
		}
		if("".equals(mbtt02001vo.getDstTtyDvn1()) || null == mbtt02001vo.getDstTtyDvn1()){
			mbtt02001vo.setDstTtyDvn1(" ");
			mbtt02001vo.setPhgpRegtTgt1(" ");
		}
		if("".equals(mbtt02001vo.getDstTtyDvn2()) || null == mbtt02001vo.getDstTtyDvn2()){
			mbtt02001vo.setDstTtyDvn2(" ");
			mbtt02001vo.setPhgpRegtTgt2(" ");
		}
		if("".equals(mbtt02001vo.getDstTtyDvn3()) || null == mbtt02001vo.getDstTtyDvn3()){
			mbtt02001vo.setDstTtyDvn3(" ");
			mbtt02001vo.setPhgpRegtTgt3(" ");
		}
		if("".equals(mbtt02001vo.getDstTtyDvn4()) || null == mbtt02001vo.getDstTtyDvn4()){
			mbtt02001vo.setDstTtyDvn4(" ");
			mbtt02001vo.setPhgpRegtTgt4(" ");
		}
		if("".equals(mbtt02001vo.getDstTtyDvn5()) || null == mbtt02001vo.getDstTtyDvn5()){
			mbtt02001vo.setDstTtyDvn5(" ");
			mbtt02001vo.setPhgpRegtTgt5(" ");
		}
		
		//MMTI0218 insert
		insertRow = 0;
		
		logger.info("#### upMileageStep6 MMTI0218 MBTT02001 before ####");
		insertRow = mileageTobeService.insertJungsanTest(mbtt02001vo);
		logger.info("#### upMileageStep6 MMTI0218 MBTT02001 after ####");
		
		if(insertRow < 1){
			logger.info("#### 사서함번호: " + StringUtil.nvl(mbtt02001vo.getPboxNo()) + "####");
			logger.info("#### insert 결과: Fail ####");
		}else{
			logger.info("#### insert 결과: Success ####");
		}
		
		if(count > 0 && count == jmvo0218.getPhgp_regt_tgt__dst_tty_dvn().length){
			request.setAttribute("reg_yn", "1");
		}else{
			request.setAttribute("reg_yn", "0");
		}
		
		//MMTI0213전문 정산이력테이블(MBTT02001) 적재
		mbtt02001vo.setPboxNo(StringUtil.nvl(pre_mmti0213vo.getSms_ts_bvan()));
		mbtt02001vo.setTlgIdVal("MMTI0213");
		mbtt02001vo.setEsbTrscId(StringUtil.nvl(pre_mmti0213vo.getZ_trsc_id()));
		if("".equals(request.getParameter("plno")) || null == request.getParameter("plno")){
			mbtt02001vo.setPlno(" ");
		} else {
			mbtt02001vo.setPlno(StringUtil.nvl(request.getParameter("plno")));
		}
		if("".equals(request.getParameter("exp_exca_plan_no")) || null == request.getParameter("exp_exca_plan_no")){
			mbtt02001vo.setPlanNo(" ");
		} else {
			mbtt02001vo.setPlanNo(StringUtil.nvl(request.getParameter("exp_exca_plan_no")));
		}
		if("".equals(pre_mmti0213vo.getRnw_plno()) || null == pre_mmti0213vo.getRnw_plno()){
			mbtt02001vo.setRnwPlno(" ");
		} else {
			mbtt02001vo.setRnwPlno(StringUtil.nvl(pre_mmti0213vo.getRnw_plno()));
		}
		if("".equals(request.getParameter("hdlr_empno")) || null == request.getParameter("hdlr_empno")){
			mbtt02001vo.setHdlrEmpno(" ");
		} else {
			mbtt02001vo.setHdlrEmpno(StringUtil.nvl(request.getParameter("hdlr_empno")));
		}
		if("".equals(pre_mmti0213vo.getPbox_no_dvcd()) || null == pre_mmti0213vo.getPbox_no_dvcd()){
			mbtt02001vo.setPboxNoDvcd(" ");
		} else {
			mbtt02001vo.setPboxNoDvcd(StringUtil.nvl(pre_mmti0213vo.getPbox_no_dvcd()));
		}
		if("".equals(pre_mmti0213vo.getProc_dvn()) || null == pre_mmti0213vo.getProc_dvn()){
			mbtt02001vo.setProcDvn(" ");
		} else {
			mbtt02001vo.setProcDvn(StringUtil.nvl(pre_mmti0213vo.getProc_dvn()));
		}
		if("".equals(pre_mmti0213vo.getTrv_dstc_exp_exca_dvcd()) || null == pre_mmti0213vo.getTrv_dstc_exp_exca_dvcd()){
			mbtt02001vo.setTrvDstcExpExcaDvcd(" ");
		} else {
			mbtt02001vo.setTrvDstcExpExcaDvcd(StringUtil.nvl(pre_mmti0213vo.getTrv_dstc_exp_exca_dvcd()));
		}
		if("".equals(pre_mmti0213vo.getTrv_dstc_chng_aply_dvn()) || null == pre_mmti0213vo.getTrv_dstc_chng_aply_dvn()){
			mbtt02001vo.setTrvDstcChngAplyDvn(" ");
		} else {
			mbtt02001vo.setTrvDstcChngAplyDvn(StringUtil.nvl(pre_mmti0213vo.getTrv_dstc_chng_aply_dvn()));
		}
		if("".equals(pre_mmti0213vo.getHdlr_fire_yn()) || null == pre_mmti0213vo.getHdlr_fire_yn()){
			mbtt02001vo.setHdlrFireYn(" ");
		} else {
			mbtt02001vo.setHdlrFireYn(StringUtil.nvl(pre_mmti0213vo.getHdlr_fire_yn()));
		}
		if("".equals(pre_mmti0213vo.getMtcc_yn()) || null == pre_mmti0213vo.getMtcc_yn()){
			mbtt02001vo.setMtccYn(" ");
		} else {
			mbtt02001vo.setMtccYn(StringUtil.nvl(pre_mmti0213vo.getMtcc_yn()));
		}
		if("".equals(request.getParameter("aut_cgnt_trv_dstc")) || null == request.getParameter("aut_cgnt_trv_dstc")){
			mbtt02001vo.setAutCgntTrvDstc(0);
		} else {
			mbtt02001vo.setAutCgntTrvDstc(Double.parseDouble(request.getParameter("aut_cgnt_trv_dstc")));
		}
		if("".equals(request.getParameter("aut_cgnt_trv_dstc_rsl_cd")) || null == request.getParameter("aut_cgnt_trv_dstc_rsl_cd")){
			mbtt02001vo.setAutCgntTrvDstcRslCd(" ");
		} else {
			mbtt02001vo.setAutCgntTrvDstcRslCd(StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc_rsl_cd")));
		}
		if("".equals(request.getParameter("inptTrvDstc")) || null == request.getParameter("inptTrvDstc")){
			mbtt02001vo.setInptTrvDstc(0);
		} else {
			mbtt02001vo.setInptTrvDstc(Double.parseDouble(request.getParameter("inptTrvDstc")));
		}
		if("".equals(request.getParameter("cnv_trv_dstc")) || null == request.getParameter("cnv_trv_dstc")){
			mbtt02001vo.setCnvTrvDstc(0);
		} else {
			mbtt02001vo.setCnvTrvDstc(Double.parseDouble(request.getParameter("cnv_trv_dstc")));
		}
		if("".equals(request.getParameter("exp_exca_plan_rsl_cd")) || null == request.getParameter("exp_exca_plan_rsl_cd")){
			mbtt02001vo.setExpExcaPlanRslCd(" ");
		} else {
			mbtt02001vo.setExpExcaPlanRslCd(StringUtil.nvl(request.getParameter("exp_exca_plan_rsl_cd")));
		}
		if("".equals(request.getParameter("excaBzProcDvn")) || null == request.getParameter("excaBzProcDvn")){
			mbtt02001vo.setExcaBzProcDvn(" ");
		} else {
			mbtt02001vo.setExcaBzProcDvn(StringUtil.nvl(request.getParameter("excaBzProcDvn")));
		}
		if("".equals(request.getParameter("excaRtrnDvn")) || null == request.getParameter("excaRtrnDvn")){
			mbtt02001vo.setExcaRtrnDvn(" ");
		} else {
			mbtt02001vo.setExcaRtrnDvn(StringUtil.nvl(request.getParameter("excaRtrnPrm")));
		}
		if("".equals(request.getParameter("pdc_sr_dvn")) || null == request.getParameter("pdc_sr_dvn")){
			mbtt02001vo.setPdcSrDvn(" ");
		} else {
			mbtt02001vo.setPdcSrDvn(StringUtil.nvl(request.getParameter("pdc_sr_dvn")));
		}
		if("".equals(request.getParameter("adc_rtrn_prm")) || null == request.getParameter("adc_rtrn_prm")){
			mbtt02001vo.setAdcRtrnPrm(0);
		} else {
			mbtt02001vo.setAdcRtrnPrm(Double.parseDouble(request.getParameter("adc_rtrn_prm")));
		}
		if("".equals(request.getParameter("trv_dstc_splc_exca_yn")) || null == request.getParameter("trv_dstc_splc_exca_yn")){
			mbtt02001vo.setTrvDstcSplcExcaYn(" ");
		} else {
			mbtt02001vo.setTrvDstcSplcExcaYn(StringUtil.nvl(request.getParameter("trv_dstc_splc_exca_yn")));
		}
		if("".equals(request.getParameter("imag_dup_yn")) || null == request.getParameter("imag_dup_yn")){
			mbtt02001vo.setImagDupYn(" ");
		} else {
			mbtt02001vo.setImagDupYn(StringUtil.nvl(request.getParameter("imag_dup_yn")));
		}
		if("".equals(request.getParameter("nrm_proc_yn")) || null == request.getParameter("nrm_proc_yn")){
			mbtt02001vo.setNrmProcYn(" ");
		} else {
			mbtt02001vo.setNrmProcYn(StringUtil.nvl(request.getParameter("nrm_proc_yn")));
		}
		if("".equals(request.getParameter("crd_scn_cncl_pss_yn")) || null == request.getParameter("crd_scn_cncl_pss_yn")){
			mbtt02001vo.setCrdScnCnclPssYn(" ");
		} else {
			mbtt02001vo.setCrdScnCnclPssYn(StringUtil.nvl(request.getParameter("crd_scn_cncl_pss_yn")));
		}
		mbtt02001vo.setTlgProcRslCdVal(StringUtil.nvl(pre_mmti0213vo.getZ_tlg_sp_cd()));
		mbtt02001vo.setTlgErrCdVal(StringUtil.nvl(pre_mmti0213vo.getZ_trns_org_dvcd())+StringUtil.nvl(pre_mmti0213vo.getZ_trns_org_cd()));
		mbtt02001vo.setRespCn(StringUtil.nvl(pre_mmti0213vo.getZ_resp_cd()));
		mbtt02001vo.setRslCn(scrnNm + "_" + StringUtil.nvl(pre_mmti0213vo.getZ_resp_msg()));
		mbtt02001vo.setFrstIpmnEmpno("82101685");
		mbtt02001vo.setFnalAmdrEmpno("82101685");
		if("".equals(request.getParameter("adc_rtrn_dvn")) || null == request.getParameter("adc_rtrn_dvn")){
			mbtt02001vo.setAdcRtrnDvn(" ");
		} else {
			mbtt02001vo.setAdcRtrnDvn(StringUtil.nvl(request.getParameter("adc_rtrn_dvn")));
		}
		if("".equals(request.getParameter("scrn_proc_cd")) || null == request.getParameter("scrn_proc_cd")){
			mbtt02001vo.setScrnProcCd(" ");
		} else {
			mbtt02001vo.setScrnProcCd(StringUtil.nvl(request.getParameter("scrn_proc_cd")));
		}
		if("".equals(pre_mmti0213vo.getCtc_plno()) || null == pre_mmti0213vo.getCtc_plno()){
			mbtt02001vo.setCtcPlno(" ");
		} else {
			mbtt02001vo.setCtcPlno(StringUtil.nvl(pre_mmti0213vo.getCtc_plno()));
		}
		if("".equals(request.getParameter("trv_dstc_proc_dvcd")) || null == request.getParameter("trv_dstc_proc_dvcd")){
			mbtt02001vo.setTrvDstcProcDvcd(" ");
		} else {
			mbtt02001vo.setTrvDstcProcDvcd(StringUtil.nvl(request.getParameter("trv_dstc_proc_dvcd")));
		}
		if("".equals(request.getParameter("mbl_snd_no")) || null == request.getParameter("mbl_snd_no")){
			mbtt02001vo.setMblSndNo(" ");
		} else {
			mbtt02001vo.setMblSndNo(StringUtil.nvl(request.getParameter("mbl_snd_no")));
		}
		if("".equals(request.getParameter("plan_plno_dvcd")) || null == request.getParameter("plan_plno_dvcd")){
			mbtt02001vo.setPlanPlnoDvcd(" ");
		} else {
			mbtt02001vo.setPlanPlnoDvcd(StringUtil.nvl(request.getParameter("plan_plno_dvcd")));
		}
		if("".equals(request.getParameter("plan_plno")) || null == request.getParameter("plan_plno")){
			mbtt02001vo.setPlanPlno(" ");
		} else {
			mbtt02001vo.setPlanPlno(StringUtil.nvl(request.getParameter("plan_plno")));
		}
		if("".equals(pre_mmti0213vo.getChng_plan_no()) || null == pre_mmti0213vo.getChng_plan_no()){
			mbtt02001vo.setChngPlanNo(" ");
		} else {
			mbtt02001vo.setChngPlanNo(StringUtil.nvl(pre_mmti0213vo.getChng_plan_no()));
		}
		if("".equals(request.getParameter("dst_tty_dvn1")) || null == request.getParameter("dst_tty_dvn1")){
			mbtt02001vo.setDstTtyDvn1(" ");
		} else {
			mbtt02001vo.setDstTtyDvn1(StringUtil.nvl(request.getParameter("dst_tty_dvn1")));
		}
		if("".equals(request.getParameter("dst_tty_dvn2")) || null == request.getParameter("dst_tty_dvn2")){
			mbtt02001vo.setDstTtyDvn2(" ");
		} else {
			mbtt02001vo.setDstTtyDvn2(StringUtil.nvl(request.getParameter("dst_tty_dvn2")));
		}
		if("".equals(request.getParameter("dst_tty_dvn3")) || null == request.getParameter("dst_tty_dvn3")){
			mbtt02001vo.setDstTtyDvn3(" ");
		} else {
			mbtt02001vo.setDstTtyDvn3(StringUtil.nvl(request.getParameter("dst_tty_dvn3")));
		}
		if("".equals(request.getParameter("dst_tty_dvn4")) || null == request.getParameter("dst_tty_dvn4")){
			mbtt02001vo.setDstTtyDvn4(" ");
		} else {
			mbtt02001vo.setDstTtyDvn4(StringUtil.nvl(request.getParameter("dst_tty_dvn4")));
		}
		if("".equals(request.getParameter("dst_tty_dvn5")) || null == request.getParameter("dst_tty_dvn5")){
			mbtt02001vo.setDstTtyDvn5(" ");
		} else {
			mbtt02001vo.setDstTtyDvn5(StringUtil.nvl(request.getParameter("dst_tty_dvn5")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt1")) || null == request.getParameter("phgp_regt_tgt1")){
			mbtt02001vo.setPhgpRegtTgt1(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt1(StringUtil.nvl(request.getParameter("phgp_regt_tgt1")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt2")) || null == request.getParameter("phgp_regt_tgt2")){
			mbtt02001vo.setPhgpRegtTgt2(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt2(StringUtil.nvl(request.getParameter("phgp_regt_tgt2")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt3")) || null == request.getParameter("phgp_regt_tgt3")){
			mbtt02001vo.setPhgpRegtTgt3(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt3(StringUtil.nvl(request.getParameter("phgp_regt_tgt3")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt4")) || null == request.getParameter("phgp_regt_tgt4")){
			mbtt02001vo.setPhgpRegtTgt4(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt4(StringUtil.nvl(request.getParameter("phgp_regt_tgt4")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt5")) || null == request.getParameter("phgp_regt_tgt5")){
			mbtt02001vo.setPhgpRegtTgt5(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt5(StringUtil.nvl(request.getParameter("phgp_regt_tgt5")));
		}
		
		//MMTI0213 insert
		insertRow = 0;
		
		logger.info("#### upMileageStep6 insertJungsanTest before ####");
		insertRow = mileageTobeService.insertJungsanTest(mbtt02001vo);
		logger.info("#### upMileageStep6 insertJungsanTest after ####");
		
		if(insertRow < 1){
			logger.info("#### 사서함번호: " + StringUtil.nvl(mbtt02001vo.getPboxNo()) + "####");
			logger.info("#### insert 결과: Fail ####");
		}else{
			logger.info("#### insert 결과: Success ####");
		}
		
		//MMTI0259전문 정산이력테이블(MBTT02001) 적재
		mbtt02001vo.setPboxNo(StringUtil.nvl(pre_mmti0213vo.getSms_ts_bvan()));
		mbtt02001vo.setTlgIdVal("MMTI0259");
		mbtt02001vo.setEsbTrscId(StringUtil.nvl(pre_mmti0259vo.getZ_trsc_id()));
		if("".equals(pre_mmti0259vo.getPlno()) || null == pre_mmti0259vo.getPlno()){
			mbtt02001vo.setPlno(" ");
		} else {
			mbtt02001vo.setPlno(StringUtil.nvl(pre_mmti0259vo.getPlno()));
		}
		if("".equals(request.getParameter("plan_no")) || null == request.getParameter("plan_no")){
			mbtt02001vo.setPlanNo(" ");
		} else {
			mbtt02001vo.setPlanNo(StringUtil.nvl(request.getParameter("plan_no")));
		}
		if("".equals(request.getParameter("rnw_plno")) || null == request.getParameter("rnw_plno")){
			mbtt02001vo.setRnwPlno(" ");
		} else {
			mbtt02001vo.setRnwPlno(StringUtil.nvl(request.getParameter("rnw_plno")));
		}
		mbtt02001vo.setTlgProcRslCdVal(StringUtil.nvl(pre_mmti0259vo.getZ_tlg_sp_cd()));
		mbtt02001vo.setTlgErrCdVal(StringUtil.nvl(pre_mmti0259vo.getZ_trns_org_dvcd())+StringUtil.nvl(pre_mmti0259vo.getZ_trns_org_cd()));
		if("".equals(request.getParameter("hdlrEmpno")) || null == request.getParameter("hdlrEmpno")){
			mbtt02001vo.setHdlrEmpno(" ");
		} else {
			mbtt02001vo.setHdlrEmpno(StringUtil.nvl(request.getParameter("hdlrEmpno")));
		}
		if("".equals(request.getParameter("pbox_no_dvcd")) || null == request.getParameter("pbox_no_dvcd")){
			mbtt02001vo.setPboxNoDvcd(" ");
		} else {
			mbtt02001vo.setPboxNoDvcd(StringUtil.nvl(request.getParameter("pbox_no_dvcd")));
		}
		if("".equals(request.getParameter("proc_dvn")) || null == request.getParameter("proc_dvn")){
			mbtt02001vo.setProcDvn(" ");
		} else {
			mbtt02001vo.setProcDvn(StringUtil.nvl(request.getParameter("proc_dvn")));
		}
		if("".equals(request.getParameter("trv_dstc_exp_exca_dvcd")) || null == request.getParameter("trv_dstc_exp_exca_dvcd")){
			mbtt02001vo.setTrvDstcExpExcaDvcd(" ");
		} else {
			mbtt02001vo.setTrvDstcExpExcaDvcd(StringUtil.nvl(request.getParameter("trv_dstc_exp_exca_dvcd")));
		}
		if("".equals(request.getParameter("trv_dstc_chng_aply_dvn")) || null == request.getParameter("trv_dstc_chng_aply_dvn")){
			mbtt02001vo.setTrvDstcChngAplyDvn(" ");
		} else {
			mbtt02001vo.setTrvDstcChngAplyDvn(StringUtil.nvl(request.getParameter("trv_dstc_chng_aply_dvn")));
		}
		if("".equals(request.getParameter("hdlr_fire_yn")) || null == request.getParameter("hdlr_fire_yn")){
			mbtt02001vo.setHdlrFireYn(" ");
		} else {
			mbtt02001vo.setHdlrFireYn(StringUtil.nvl(request.getParameter("hdlr_fire_yn")));
		}
		if("".equals(request.getParameter("mtcc_yn")) || null == request.getParameter("mtcc_yn")){
			mbtt02001vo.setMtccYn(" ");
		} else {
			mbtt02001vo.setMtccYn(StringUtil.nvl(request.getParameter("mtcc_yn")));
		}
		if("".equals(pre_mmti0259vo.getAut_cgnt_trv_dstc()) || null == pre_mmti0259vo.getAut_cgnt_trv_dstc()){
			mbtt02001vo.setAutCgntTrvDstc(0);
		} else {
			mbtt02001vo.setAutCgntTrvDstc(Double.parseDouble(pre_mmti0259vo.getAut_cgnt_trv_dstc()));
		}
		if("".equals(pre_mmti0259vo.getAut_cgnt_trv_dstc_rsl_cd()) || null == pre_mmti0259vo.getAut_cgnt_trv_dstc_rsl_cd()){
			mbtt02001vo.setAutCgntTrvDstcRslCd(" ");
		} else {
			mbtt02001vo.setAutCgntTrvDstcRslCd(StringUtil.nvl(pre_mmti0259vo.getAut_cgnt_trv_dstc_rsl_cd()));
		}
		if("".equals(pre_mmti0259vo.getInpt_trv_dstc()) || null == pre_mmti0259vo.getInpt_trv_dstc()){
			mbtt02001vo.setInptTrvDstc(0);
		} else {
			mbtt02001vo.setInptTrvDstc(Double.parseDouble(pre_mmti0259vo.getInpt_trv_dstc()));
		}
		if("".equals(pre_mmti0259vo.getCnv_trv_dstc()) || null == pre_mmti0259vo.getCnv_trv_dstc()){
			mbtt02001vo.setCnvTrvDstc(0);
		} else {
			mbtt02001vo.setCnvTrvDstc(Double.parseDouble(pre_mmti0259vo.getCnv_trv_dstc()));
		}
		if("".equals(pre_mmti0259vo.getExp_exca_plan_rsl_cd()) || null == pre_mmti0259vo.getExp_exca_plan_rsl_cd()){
			mbtt02001vo.setExpExcaPlanRslCd(" ");
		} else {
			mbtt02001vo.setExpExcaPlanRslCd(StringUtil.nvl(pre_mmti0259vo.getExp_exca_plan_rsl_cd()));
		}
		if("".equals(request.getParameter("exca_bz_proc_dvn")) || null == request.getParameter("exca_bz_proc_dvn")){
			mbtt02001vo.setExcaBzProcDvn(" ");
		} else {
			mbtt02001vo.setExcaBzProcDvn(StringUtil.nvl(request.getParameter("exca_bz_proc_dvn")));
		}
		if("".equals(request.getParameter("exca_rtrn_dvn")) || null == request.getParameter("exca_rtrn_dvn")){
			mbtt02001vo.setExcaRtrnDvn(" ");
		} else {
			mbtt02001vo.setExcaRtrnDvn(StringUtil.nvl(request.getParameter("exca_rtrn_dvn")));
		}
		if("".equals(pre_mmti0259vo.getPdc_sr_dvn()) || null == pre_mmti0259vo.getPdc_sr_dvn()){
			mbtt02001vo.setPdcSrDvn(" ");
		} else {
			mbtt02001vo.setPdcSrDvn(StringUtil.nvl(pre_mmti0259vo.getPdc_sr_dvn()));
		}
		if("".equals(pre_mmti0259vo.getAdc_rtrn_prm()) || null == pre_mmti0259vo.getAdc_rtrn_prm()){
			mbtt02001vo.setAdcRtrnPrm(0);
		} else {
			mbtt02001vo.setAdcRtrnPrm(Double.parseDouble(pre_mmti0259vo.getAdc_rtrn_prm()));
		}
		if("".equals(request.getParameter("trv_dstc_splc_exca_yn")) || null == request.getParameter("trv_dstc_splc_exca_yn")){
			mbtt02001vo.setTrvDstcSplcExcaYn(" ");
		} else {
			mbtt02001vo.setTrvDstcSplcExcaYn(StringUtil.nvl(request.getParameter("trv_dstc_splc_exca_yn")));
		}
		if("".equals(request.getParameter("imag_dup_yn")) || null == request.getParameter("imag_dup_yn")){
			mbtt02001vo.setImagDupYn(" ");
		} else {
			mbtt02001vo.setImagDupYn(StringUtil.nvl(request.getParameter("imag_dup_yn")));
		}
		if("".equals(request.getParameter("nrm_proc_yn")) || null == request.getParameter("nrm_proc_yn")){
			mbtt02001vo.setNrmProcYn(" ");
		} else {
			mbtt02001vo.setNrmProcYn(StringUtil.nvl(request.getParameter("nrm_proc_yn")));
		}
		if("".equals(request.getParameter("crd_scn_cncl_pss_yn")) || null == request.getParameter("crd_scn_cncl_pss_yn")){
			mbtt02001vo.setCrdScnCnclPssYn(" ");
		} else {
			mbtt02001vo.setCrdScnCnclPssYn(StringUtil.nvl(request.getParameter("crd_scn_cncl_pss_yn")));
		}
		mbtt02001vo.setRespCn(StringUtil.nvl(pre_mmti0259vo.getZ_resp_cd()));
		mbtt02001vo.setRslCn(scrnNm + "_" + StringUtil.nvl(pre_mmti0259vo.getZ_resp_msg()));
		mbtt02001vo.setFrstIpmnEmpno("82101685");
		mbtt02001vo.setFnalAmdrEmpno("82101685");
		if("".equals(pre_mmti0259vo.getAdc_rtrn_dvn()) || null == pre_mmti0259vo.getAdc_rtrn_dvn()){
			mbtt02001vo.setAdcRtrnDvn(" ");
		} else {
			mbtt02001vo.setAdcRtrnDvn(StringUtil.nvl(pre_mmti0259vo.getAdc_rtrn_dvn()));
		}
		if("".equals(request.getParameter("scrn_proc_cd")) || null == request.getParameter("scrn_proc_cd")){
			mbtt02001vo.setScrnProcCd(" ");
		} else {
			mbtt02001vo.setScrnProcCd(StringUtil.nvl(request.getParameter("scrn_proc_cd")));
		}
		if("".equals(request.getParameter("ctc_plno")) || null == request.getParameter("ctc_plno")){
			mbtt02001vo.setCtcPlno(" ");
		} else {
			mbtt02001vo.setCtcPlno(StringUtil.nvl(request.getParameter("ctc_plno")));
		}
		if("".equals(request.getParameter("trv_dstc_proc_dvcd")) || null == request.getParameter("trv_dstc_proc_dvcd")){
			mbtt02001vo.setTrvDstcProcDvcd(" ");
		} else {
			mbtt02001vo.setTrvDstcProcDvcd(StringUtil.nvl(request.getParameter("trv_dstc_proc_dvcd")));
		}
		if("".equals(request.getParameter("mbl_snd_no")) || null == request.getParameter("mbl_snd_no")){
			mbtt02001vo.setMblSndNo(" ");
		} else {
			mbtt02001vo.setMblSndNo(StringUtil.nvl(request.getParameter("mbl_snd_no")));
		}
		if("".equals(request.getParameter("plan_plno_dvcd")) || null == request.getParameter("plan_plno_dvcd")){
			mbtt02001vo.setPlanPlnoDvcd(" ");
		} else {
			mbtt02001vo.setPlanPlnoDvcd(StringUtil.nvl(request.getParameter("plan_plno_dvcd")));
		}
		if("".equals(request.getParameter("plan_plno")) || null == request.getParameter("plan_plno")){
			mbtt02001vo.setPlanPlno(" ");
		} else {
			mbtt02001vo.setPlanPlno(StringUtil.nvl(request.getParameter("plan_plno")));
		}
		if("".equals(request.getParameter("chng_plan_no")) || null == request.getParameter("chng_plan_no")){
			mbtt02001vo.setChngPlanNo(" ");
		} else {
			mbtt02001vo.setChngPlanNo(StringUtil.nvl(request.getParameter("chng_plan_no")));
		}
		if("".equals(request.getParameter("dst_tty_dvn1")) || null == request.getParameter("dst_tty_dvn1")){
			mbtt02001vo.setDstTtyDvn1(" ");
		} else {
			mbtt02001vo.setDstTtyDvn1(StringUtil.nvl(request.getParameter("dst_tty_dvn1")));
		}
		if("".equals(request.getParameter("dst_tty_dvn2")) || null == request.getParameter("dst_tty_dvn2")){
			mbtt02001vo.setDstTtyDvn2(" ");
		} else {
			mbtt02001vo.setDstTtyDvn2(StringUtil.nvl(request.getParameter("dst_tty_dvn2")));
		}
		if("".equals(request.getParameter("dst_tty_dvn3")) || null == request.getParameter("dst_tty_dvn3")){
			mbtt02001vo.setDstTtyDvn3(" ");
		} else {
			mbtt02001vo.setDstTtyDvn3(StringUtil.nvl(request.getParameter("dst_tty_dvn3")));
		}
		if("".equals(request.getParameter("dst_tty_dvn4")) || null == request.getParameter("dst_tty_dvn4")){
			mbtt02001vo.setDstTtyDvn4(" ");
		} else {
			mbtt02001vo.setDstTtyDvn4(StringUtil.nvl(request.getParameter("dst_tty_dvn4")));
		}
		if("".equals(request.getParameter("dst_tty_dvn5")) || null == request.getParameter("dst_tty_dvn5")){
			mbtt02001vo.setDstTtyDvn5(" ");
		} else {
			mbtt02001vo.setDstTtyDvn5(StringUtil.nvl(request.getParameter("dst_tty_dvn5")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt1")) || null == request.getParameter("phgp_regt_tgt1")){
			mbtt02001vo.setPhgpRegtTgt1(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt1(StringUtil.nvl(request.getParameter("phgp_regt_tgt1")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt2")) || null == request.getParameter("phgp_regt_tgt2")){
			mbtt02001vo.setPhgpRegtTgt2(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt2(StringUtil.nvl(request.getParameter("phgp_regt_tgt2")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt3")) || null == request.getParameter("phgp_regt_tgt3")){
			mbtt02001vo.setPhgpRegtTgt3(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt3(StringUtil.nvl(request.getParameter("phgp_regt_tgt3")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt4")) || null == request.getParameter("phgp_regt_tgt4")){
			mbtt02001vo.setPhgpRegtTgt4(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt4(StringUtil.nvl(request.getParameter("phgp_regt_tgt4")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt5")) || null == request.getParameter("phgp_regt_tgt5")){
			mbtt02001vo.setPhgpRegtTgt5(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt5(StringUtil.nvl(request.getParameter("phgp_regt_tgt5")));
		}
		
		//MMTI0259 insert
		insertRow = 0;
		
		logger.info("#### upMileageStep6 MMTI0259 MBTT02001 before ####");
		insertRow = mileageTobeService.insertJungsanTest(mbtt02001vo);
		logger.info("#### upMileageStep6 MMTI0259 MBTT02001 after ####");
		
		if(insertRow < 1){
			logger.info("#### 사서함번호: " + StringUtil.nvl(mbtt02001vo.getPboxNo()) + "####");
			logger.info("#### insert 결과: Fail ####");
		}else{
			logger.info("#### insert 결과: Success ####");
		}
		
		// map.put("resultCode", pre_mmti0259vo.getErrorCode());
		map.put("reg_yn", (String) request.getAttribute("reg_yn"));
		return map;
		// return "/counter/carrider/tobe/upMileageStep6";
	}
	
	@RequestMapping(value="/upMileageStep6go")
	public String upMileageStep6go(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		HttpSession session = request.getSession();
		MMTI0217VO mmti0217vo = new MMTI0217VO();
		MMTI0218VO mmti0218vo = new MMTI0218VO();
		
		if(session.getAttribute("p") != null) {
			mmti0217vo.setMbl_snd_no((String) session.getAttribute("p"));
		}
		else {
			mmti0217vo.setMbl_snd_no(aes256Decrypt(StringUtil.nvl(request.getParameter("p"))));
		}
		mmti0217vo = mileageTobeService.getMMTI0217VO(mmti0217vo);
		request.setAttribute("mmti0217vo", mmti0217vo);
		
		mmti0218vo.setMbl_snd_no(mmti0217vo.getMbl_snd_no());
		mmti0218vo.setPlan_plno_dvcd(mmti0217vo.getPlan_plno_dvcd());
		mmti0218vo.setPlan_plno(mmti0217vo.getPlan_plno());
		mmti0218vo.setChng_plan_no(mmti0217vo.getChng_plan_no());
		
		mmti0218vo = mileageTobeService.getMMTI0218VO(mmti0218vo);
		int count = 0;
		for(int i = 0; i < mmti0218vo.getPhgp_regt_tgt__dst_tty_dvn().length; i++) {
			if("Y".equals(mmti0218vo.getPhgp_regt_tgt__phgp_regt_cplt_yn()[i]) || "1".equals(mmti0218vo.getPhgp_regt_tgt__phgp_regt_cplt_yn()[i])) count++;
		}
		
		if(count > 0 && count == mmti0218vo.getPhgp_regt_tgt__dst_tty_dvn().length){
			request.setAttribute("reg_yn", "1");
		}else{
			request.setAttribute("reg_yn", "0");
		}
		
		request.setAttribute("dvn", "01");
		return "/counter/carrider/tobe/upMileageStep6";
	}
	
	@RequestMapping(value="/upMileageStep7A")
	public String upMileageStep7A(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
	
		HttpSession session = request.getSession();
		MMTI0213VO pre_mmti0213vo = new MMTI0213VO();
		MMTI0259VO pre_mmti0259vo = new MMTI0259VO();
		pre_mmti0213vo = (MMTI0213VO) session.getAttribute("pre_mmti0213vo");
		pre_mmti0259vo = (MMTI0259VO) session.getAttribute("pre_mmti0259vo");
		MBTT02001VO mbtt02001vo = new MBTT02001VO();
		String scrnNm = "upMileageStep7A";
		
		String gubun = request.getParameter("gubun");
		request.setAttribute("gubun", gubun);
		
		MMTI0217VO mmti0217vo = new MMTI0217VO();
		
		if(session.getAttribute("p") != null) {
			mmti0217vo.setMbl_snd_no((String) session.getAttribute("p"));
		}
		else {
			mmti0217vo.setMbl_snd_no(aes256Decrypt(StringUtil.nvl(request.getParameter("p"))));
		}
		mmti0217vo = mileageTobeService.getMMTI0217VO(mmti0217vo);
		
		request.setAttribute("mmti0217vo", mmti0217vo);
		// session.setAttribute("mmti0217vo", mmti0217vo);
		
		//MMTI0213전문 정산이력테이블(MBTT02001) 적재
		mbtt02001vo.setPboxNo(StringUtil.nvl(pre_mmti0213vo.getSms_ts_bvan()));
		mbtt02001vo.setTlgIdVal("MMTI0213");
		mbtt02001vo.setEsbTrscId(StringUtil.nvl(pre_mmti0213vo.getZ_trsc_id()));
		if("".equals(request.getParameter("plno")) || null == request.getParameter("plno")){
			mbtt02001vo.setPlno(" ");
		} else {
			mbtt02001vo.setPlno(StringUtil.nvl(request.getParameter("plno")));
		}
		if("".equals(request.getParameter("exp_exca_plan_no")) || null == request.getParameter("exp_exca_plan_no")){
			mbtt02001vo.setPlanNo(" ");
		} else {
			mbtt02001vo.setPlanNo(StringUtil.nvl(request.getParameter("exp_exca_plan_no")));
		}
		if("".equals(pre_mmti0213vo.getRnw_plno()) || null == pre_mmti0213vo.getRnw_plno()){
			mbtt02001vo.setRnwPlno(" ");
		} else {
			mbtt02001vo.setRnwPlno(StringUtil.nvl(pre_mmti0213vo.getRnw_plno()));
		}
		if("".equals(request.getParameter("hdlr_empno")) || null == request.getParameter("hdlr_empno")){
			mbtt02001vo.setHdlrEmpno(" ");
		} else {
			mbtt02001vo.setHdlrEmpno(StringUtil.nvl(request.getParameter("hdlr_empno")));
		}
		if("".equals(pre_mmti0213vo.getPbox_no_dvcd()) || null == pre_mmti0213vo.getPbox_no_dvcd()){
			mbtt02001vo.setPboxNoDvcd(" ");
		} else {
			mbtt02001vo.setPboxNoDvcd(StringUtil.nvl(pre_mmti0213vo.getPbox_no_dvcd()));
		}
		if("".equals(pre_mmti0213vo.getProc_dvn()) || null == pre_mmti0213vo.getProc_dvn()){
			mbtt02001vo.setProcDvn(" ");
		} else {
			mbtt02001vo.setProcDvn(StringUtil.nvl(pre_mmti0213vo.getProc_dvn()));
		}
		if("".equals(pre_mmti0213vo.getTrv_dstc_exp_exca_dvcd()) || null == pre_mmti0213vo.getTrv_dstc_exp_exca_dvcd()){
			mbtt02001vo.setTrvDstcExpExcaDvcd(" ");
		} else {
			mbtt02001vo.setTrvDstcExpExcaDvcd(StringUtil.nvl(pre_mmti0213vo.getTrv_dstc_exp_exca_dvcd()));
		}
		if("".equals(pre_mmti0213vo.getTrv_dstc_chng_aply_dvn()) || null == pre_mmti0213vo.getTrv_dstc_chng_aply_dvn()){
			mbtt02001vo.setTrvDstcChngAplyDvn(" ");
		} else {
			mbtt02001vo.setTrvDstcChngAplyDvn(StringUtil.nvl(pre_mmti0213vo.getTrv_dstc_chng_aply_dvn()));
		}
		if("".equals(pre_mmti0213vo.getHdlr_fire_yn()) || null == pre_mmti0213vo.getHdlr_fire_yn()){
			mbtt02001vo.setHdlrFireYn(" ");
		} else {
			mbtt02001vo.setHdlrFireYn(StringUtil.nvl(pre_mmti0213vo.getHdlr_fire_yn()));
		}
		if("".equals(pre_mmti0213vo.getMtcc_yn()) || null == pre_mmti0213vo.getMtcc_yn()){
			mbtt02001vo.setMtccYn(" ");
		} else {
			mbtt02001vo.setMtccYn(StringUtil.nvl(pre_mmti0213vo.getMtcc_yn()));
		}
		if("".equals(request.getParameter("aut_cgnt_trv_dstc")) || null == request.getParameter("aut_cgnt_trv_dstc")){
			mbtt02001vo.setAutCgntTrvDstc(0);
		} else {
			mbtt02001vo.setAutCgntTrvDstc(Double.parseDouble(request.getParameter("aut_cgnt_trv_dstc")));
		}
		if("".equals(request.getParameter("aut_cgnt_trv_dstc_rsl_cd")) || null == request.getParameter("aut_cgnt_trv_dstc_rsl_cd")){
			mbtt02001vo.setAutCgntTrvDstcRslCd(" ");
		} else {
			mbtt02001vo.setAutCgntTrvDstcRslCd(StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc_rsl_cd")));
		}
		if("".equals(request.getParameter("inptTrvDstc")) || null == request.getParameter("inptTrvDstc")){
			mbtt02001vo.setInptTrvDstc(0);
		} else {
			mbtt02001vo.setInptTrvDstc(Double.parseDouble(request.getParameter("inptTrvDstc")));
		}
		if("".equals(request.getParameter("cnv_trv_dstc")) || null == request.getParameter("cnv_trv_dstc")){
			mbtt02001vo.setCnvTrvDstc(0);
		} else {
			mbtt02001vo.setCnvTrvDstc(Double.parseDouble(request.getParameter("cnv_trv_dstc")));
		}
		if("".equals(request.getParameter("exp_exca_plan_rsl_cd")) || null == request.getParameter("exp_exca_plan_rsl_cd")){
			mbtt02001vo.setExpExcaPlanRslCd(" ");
		} else {
			mbtt02001vo.setExpExcaPlanRslCd(StringUtil.nvl(request.getParameter("exp_exca_plan_rsl_cd")));
		}
		if("".equals(request.getParameter("excaBzProcDvn")) || null == request.getParameter("excaBzProcDvn")){
			mbtt02001vo.setExcaBzProcDvn(" ");
		} else {
			mbtt02001vo.setExcaBzProcDvn(StringUtil.nvl(request.getParameter("excaBzProcDvn")));
		}
		if("".equals(request.getParameter("excaRtrnDvn")) || null == request.getParameter("excaRtrnDvn")){
			mbtt02001vo.setExcaRtrnDvn(" ");
		} else {
			mbtt02001vo.setExcaRtrnDvn(StringUtil.nvl(request.getParameter("excaRtrnPrm")));
		}
		if("".equals(request.getParameter("pdc_sr_dvn")) || null == request.getParameter("pdc_sr_dvn")){
			mbtt02001vo.setPdcSrDvn(" ");
		} else {
			mbtt02001vo.setPdcSrDvn(StringUtil.nvl(request.getParameter("pdc_sr_dvn")));
		}
		if("".equals(request.getParameter("adc_rtrn_prm")) || null == request.getParameter("adc_rtrn_prm")){
			mbtt02001vo.setAdcRtrnPrm(0);
		} else {
			mbtt02001vo.setAdcRtrnPrm(Double.parseDouble(request.getParameter("adc_rtrn_prm")));
		}
		if("".equals(request.getParameter("trv_dstc_splc_exca_yn")) || null == request.getParameter("trv_dstc_splc_exca_yn")){
			mbtt02001vo.setTrvDstcSplcExcaYn(" ");
		} else {
			mbtt02001vo.setTrvDstcSplcExcaYn(StringUtil.nvl(request.getParameter("trv_dstc_splc_exca_yn")));
		}
		if("".equals(request.getParameter("imag_dup_yn")) || null == request.getParameter("imag_dup_yn")){
			mbtt02001vo.setImagDupYn(" ");
		} else {
			mbtt02001vo.setImagDupYn(StringUtil.nvl(request.getParameter("imag_dup_yn")));
		}
		if("".equals(request.getParameter("nrm_proc_yn")) || null == request.getParameter("nrm_proc_yn")){
			mbtt02001vo.setNrmProcYn(" ");
		} else {
			mbtt02001vo.setNrmProcYn(StringUtil.nvl(request.getParameter("nrm_proc_yn")));
		}
		if("".equals(request.getParameter("crd_scn_cncl_pss_yn")) || null == request.getParameter("crd_scn_cncl_pss_yn")){
			mbtt02001vo.setCrdScnCnclPssYn(" ");
		} else {
			mbtt02001vo.setCrdScnCnclPssYn(StringUtil.nvl(request.getParameter("crd_scn_cncl_pss_yn")));
		}
		mbtt02001vo.setTlgProcRslCdVal(StringUtil.nvl(pre_mmti0213vo.getZ_tlg_sp_cd()));
		mbtt02001vo.setTlgErrCdVal(StringUtil.nvl(pre_mmti0213vo.getZ_trns_org_dvcd())+StringUtil.nvl(pre_mmti0213vo.getZ_trns_org_cd()));
		mbtt02001vo.setRespCn(StringUtil.nvl(pre_mmti0213vo.getZ_resp_cd()));
		mbtt02001vo.setRslCn(scrnNm + "_" + StringUtil.nvl(pre_mmti0213vo.getZ_resp_msg()));
		mbtt02001vo.setFrstIpmnEmpno("82101685");
		mbtt02001vo.setFnalAmdrEmpno("82101685");
		if("".equals(request.getParameter("adc_rtrn_dvn")) || null == request.getParameter("adc_rtrn_dvn")){
			mbtt02001vo.setAdcRtrnDvn(" ");
		} else {
			mbtt02001vo.setAdcRtrnDvn(StringUtil.nvl(request.getParameter("adc_rtrn_dvn")));
		}
		if("".equals(request.getParameter("scrn_proc_cd")) || null == request.getParameter("scrn_proc_cd")){
			mbtt02001vo.setScrnProcCd(" ");
		} else {
			mbtt02001vo.setScrnProcCd(StringUtil.nvl(request.getParameter("scrn_proc_cd")));
		}
		if("".equals(pre_mmti0213vo.getCtc_plno()) || null == pre_mmti0213vo.getCtc_plno()){
			mbtt02001vo.setCtcPlno(" ");
		} else {
			mbtt02001vo.setCtcPlno(StringUtil.nvl(pre_mmti0213vo.getCtc_plno()));
		}
		if("".equals(request.getParameter("trv_dstc_proc_dvcd")) || null == request.getParameter("trv_dstc_proc_dvcd")){
			mbtt02001vo.setTrvDstcProcDvcd(" ");
		} else {
			mbtt02001vo.setTrvDstcProcDvcd(StringUtil.nvl(request.getParameter("trv_dstc_proc_dvcd")));
		}
		if("".equals(request.getParameter("mbl_snd_no")) || null == request.getParameter("mbl_snd_no")){
			mbtt02001vo.setMblSndNo(" ");
		} else {
			mbtt02001vo.setMblSndNo(StringUtil.nvl(request.getParameter("mbl_snd_no")));
		}
		if("".equals(request.getParameter("plan_plno_dvcd")) || null == request.getParameter("plan_plno_dvcd")){
			mbtt02001vo.setPlanPlnoDvcd(" ");
		} else {
			mbtt02001vo.setPlanPlnoDvcd(StringUtil.nvl(request.getParameter("plan_plno_dvcd")));
		}
		if("".equals(request.getParameter("plan_plno")) || null == request.getParameter("plan_plno")){
			mbtt02001vo.setPlanPlno(" ");
		} else {
			mbtt02001vo.setPlanPlno(StringUtil.nvl(request.getParameter("plan_plno")));
		}
		if("".equals(pre_mmti0213vo.getChng_plan_no()) || null == pre_mmti0213vo.getChng_plan_no()){
			mbtt02001vo.setChngPlanNo(" ");
		} else {
			mbtt02001vo.setChngPlanNo(StringUtil.nvl(pre_mmti0213vo.getChng_plan_no()));
		}
		if("".equals(request.getParameter("dst_tty_dvn1")) || null == request.getParameter("dst_tty_dvn1")){
			mbtt02001vo.setDstTtyDvn1(" ");
		} else {
			mbtt02001vo.setDstTtyDvn1(StringUtil.nvl(request.getParameter("dst_tty_dvn1")));
		}
		if("".equals(request.getParameter("dst_tty_dvn2")) || null == request.getParameter("dst_tty_dvn2")){
			mbtt02001vo.setDstTtyDvn2(" ");
		} else {
			mbtt02001vo.setDstTtyDvn2(StringUtil.nvl(request.getParameter("dst_tty_dvn2")));
		}
		if("".equals(request.getParameter("dst_tty_dvn3")) || null == request.getParameter("dst_tty_dvn3")){
			mbtt02001vo.setDstTtyDvn3(" ");
		} else {
			mbtt02001vo.setDstTtyDvn3(StringUtil.nvl(request.getParameter("dst_tty_dvn3")));
		}
		if("".equals(request.getParameter("dst_tty_dvn4")) || null == request.getParameter("dst_tty_dvn4")){
			mbtt02001vo.setDstTtyDvn4(" ");
		} else {
			mbtt02001vo.setDstTtyDvn4(StringUtil.nvl(request.getParameter("dst_tty_dvn4")));
		}
		if("".equals(request.getParameter("dst_tty_dvn5")) || null == request.getParameter("dst_tty_dvn5")){
			mbtt02001vo.setDstTtyDvn5(" ");
		} else {
			mbtt02001vo.setDstTtyDvn5(StringUtil.nvl(request.getParameter("dst_tty_dvn5")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt1")) || null == request.getParameter("phgp_regt_tgt1")){
			mbtt02001vo.setPhgpRegtTgt1(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt1(StringUtil.nvl(request.getParameter("phgp_regt_tgt1")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt2")) || null == request.getParameter("phgp_regt_tgt2")){
			mbtt02001vo.setPhgpRegtTgt2(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt2(StringUtil.nvl(request.getParameter("phgp_regt_tgt2")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt3")) || null == request.getParameter("phgp_regt_tgt3")){
			mbtt02001vo.setPhgpRegtTgt3(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt3(StringUtil.nvl(request.getParameter("phgp_regt_tgt3")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt4")) || null == request.getParameter("phgp_regt_tgt4")){
			mbtt02001vo.setPhgpRegtTgt4(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt4(StringUtil.nvl(request.getParameter("phgp_regt_tgt4")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt5")) || null == request.getParameter("phgp_regt_tgt5")){
			mbtt02001vo.setPhgpRegtTgt5(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt5(StringUtil.nvl(request.getParameter("phgp_regt_tgt5")));
		}
		
		//MMTI0213 insert
		int insertRow = 0;
		
		logger.info("#### upMileageStep7A insertJungsanTest before ####");
		insertRow = mileageTobeService.insertJungsanTest(mbtt02001vo);
		logger.info("#### upMileageStep7A insertJungsanTest after ####");
		
		if(insertRow < 1){
			logger.info("#### 사서함번호: " + StringUtil.nvl(mbtt02001vo.getPboxNo()) + "####");
			logger.info("#### insert 결과: Fail ####");
		}else{
			logger.info("#### insert 결과: Success ####");
		}
		
		//MMTI0259전문 정산이력테이블(MBTT02001) 적재
		mbtt02001vo.setPboxNo(StringUtil.nvl(pre_mmti0213vo.getSms_ts_bvan()));
		mbtt02001vo.setTlgIdVal("MMTI0259");
		mbtt02001vo.setEsbTrscId(StringUtil.nvl(pre_mmti0259vo.getZ_trsc_id()));
		if("".equals(pre_mmti0259vo.getPlno()) || null == pre_mmti0259vo.getPlno()){
			mbtt02001vo.setPlno(" ");
		} else {
			mbtt02001vo.setPlno(StringUtil.nvl(pre_mmti0259vo.getPlno()));
		}
		if("".equals(request.getParameter("plan_no")) || null == request.getParameter("plan_no")){
			mbtt02001vo.setPlanNo(" ");
		} else {
			mbtt02001vo.setPlanNo(StringUtil.nvl(request.getParameter("plan_no")));
		}
		if("".equals(request.getParameter("rnw_plno")) || null == request.getParameter("rnw_plno")){
			mbtt02001vo.setRnwPlno(" ");
		} else {
			mbtt02001vo.setRnwPlno(StringUtil.nvl(request.getParameter("rnw_plno")));
		}
		mbtt02001vo.setTlgProcRslCdVal(StringUtil.nvl(pre_mmti0259vo.getZ_tlg_sp_cd()));
		mbtt02001vo.setTlgErrCdVal(StringUtil.nvl(pre_mmti0259vo.getZ_trns_org_dvcd())+StringUtil.nvl(pre_mmti0259vo.getZ_trns_org_cd()));
		if("".equals(request.getParameter("hdlrEmpno")) || null == request.getParameter("hdlrEmpno")){
			mbtt02001vo.setHdlrEmpno(" ");
		} else {
			mbtt02001vo.setHdlrEmpno(StringUtil.nvl(request.getParameter("hdlrEmpno")));
		}
		if("".equals(request.getParameter("pbox_no_dvcd")) || null == request.getParameter("pbox_no_dvcd")){
			mbtt02001vo.setPboxNoDvcd(" ");
		} else {
			mbtt02001vo.setPboxNoDvcd(StringUtil.nvl(request.getParameter("pbox_no_dvcd")));
		}
		if("".equals(request.getParameter("proc_dvn")) || null == request.getParameter("proc_dvn")){
			mbtt02001vo.setProcDvn(" ");
		} else {
			mbtt02001vo.setProcDvn(StringUtil.nvl(request.getParameter("proc_dvn")));
		}
		if("".equals(request.getParameter("trv_dstc_exp_exca_dvcd")) || null == request.getParameter("trv_dstc_exp_exca_dvcd")){
			mbtt02001vo.setTrvDstcExpExcaDvcd(" ");
		} else {
			mbtt02001vo.setTrvDstcExpExcaDvcd(StringUtil.nvl(request.getParameter("trv_dstc_exp_exca_dvcd")));
		}
		if("".equals(request.getParameter("trv_dstc_chng_aply_dvn")) || null == request.getParameter("trv_dstc_chng_aply_dvn")){
			mbtt02001vo.setTrvDstcChngAplyDvn(" ");
		} else {
			mbtt02001vo.setTrvDstcChngAplyDvn(StringUtil.nvl(request.getParameter("trv_dstc_chng_aply_dvn")));
		}
		if("".equals(request.getParameter("hdlr_fire_yn")) || null == request.getParameter("hdlr_fire_yn")){
			mbtt02001vo.setHdlrFireYn(" ");
		} else {
			mbtt02001vo.setHdlrFireYn(StringUtil.nvl(request.getParameter("hdlr_fire_yn")));
		}
		if("".equals(request.getParameter("mtcc_yn")) || null == request.getParameter("mtcc_yn")){
			mbtt02001vo.setMtccYn(" ");
		} else {
			mbtt02001vo.setMtccYn(StringUtil.nvl(request.getParameter("mtcc_yn")));
		}
		if("".equals(pre_mmti0259vo.getAut_cgnt_trv_dstc()) || null == pre_mmti0259vo.getAut_cgnt_trv_dstc()){
			mbtt02001vo.setAutCgntTrvDstc(0);
		} else {
			mbtt02001vo.setAutCgntTrvDstc(Double.parseDouble(pre_mmti0259vo.getAut_cgnt_trv_dstc()));
		}
		if("".equals(pre_mmti0259vo.getAut_cgnt_trv_dstc_rsl_cd()) || null == pre_mmti0259vo.getAut_cgnt_trv_dstc_rsl_cd()){
			mbtt02001vo.setAutCgntTrvDstcRslCd(" ");
		} else {
			mbtt02001vo.setAutCgntTrvDstcRslCd(StringUtil.nvl(pre_mmti0259vo.getAut_cgnt_trv_dstc_rsl_cd()));
		}
		if("".equals(pre_mmti0259vo.getInpt_trv_dstc()) || null == pre_mmti0259vo.getInpt_trv_dstc()){
			mbtt02001vo.setInptTrvDstc(0);
		} else {
			mbtt02001vo.setInptTrvDstc(Double.parseDouble(pre_mmti0259vo.getInpt_trv_dstc()));
		}
		if("".equals(pre_mmti0259vo.getCnv_trv_dstc()) || null == pre_mmti0259vo.getCnv_trv_dstc()){
			mbtt02001vo.setCnvTrvDstc(0);
		} else {
			mbtt02001vo.setCnvTrvDstc(Double.parseDouble(pre_mmti0259vo.getCnv_trv_dstc()));
		}
		if("".equals(pre_mmti0259vo.getExp_exca_plan_rsl_cd()) || null == pre_mmti0259vo.getExp_exca_plan_rsl_cd()){
			mbtt02001vo.setExpExcaPlanRslCd(" ");
		} else {
			mbtt02001vo.setExpExcaPlanRslCd(StringUtil.nvl(pre_mmti0259vo.getExp_exca_plan_rsl_cd()));
		}
		if("".equals(request.getParameter("exca_bz_proc_dvn")) || null == request.getParameter("exca_bz_proc_dvn")){
			mbtt02001vo.setExcaBzProcDvn(" ");
		} else {
			mbtt02001vo.setExcaBzProcDvn(StringUtil.nvl(request.getParameter("exca_bz_proc_dvn")));
		}
		if("".equals(request.getParameter("exca_rtrn_dvn")) || null == request.getParameter("exca_rtrn_dvn")){
			mbtt02001vo.setExcaRtrnDvn(" ");
		} else {
			mbtt02001vo.setExcaRtrnDvn(StringUtil.nvl(request.getParameter("exca_rtrn_dvn")));
		}
		if("".equals(pre_mmti0259vo.getPdc_sr_dvn()) || null == pre_mmti0259vo.getPdc_sr_dvn()){
			mbtt02001vo.setPdcSrDvn(" ");
		} else {
			mbtt02001vo.setPdcSrDvn(StringUtil.nvl(pre_mmti0259vo.getPdc_sr_dvn()));
		}
		if("".equals(pre_mmti0259vo.getAdc_rtrn_prm()) || null == pre_mmti0259vo.getAdc_rtrn_prm()){
			mbtt02001vo.setAdcRtrnPrm(0);
		} else {
			mbtt02001vo.setAdcRtrnPrm(Double.parseDouble(pre_mmti0259vo.getAdc_rtrn_prm()));
		}
		if("".equals(request.getParameter("trv_dstc_splc_exca_yn")) || null == request.getParameter("trv_dstc_splc_exca_yn")){
			mbtt02001vo.setTrvDstcSplcExcaYn(" ");
		} else {
			mbtt02001vo.setTrvDstcSplcExcaYn(StringUtil.nvl(request.getParameter("trv_dstc_splc_exca_yn")));
		}
		if("".equals(request.getParameter("imag_dup_yn")) || null == request.getParameter("imag_dup_yn")){
			mbtt02001vo.setImagDupYn(" ");
		} else {
			mbtt02001vo.setImagDupYn(StringUtil.nvl(request.getParameter("imag_dup_yn")));
		}
		if("".equals(request.getParameter("nrm_proc_yn")) || null == request.getParameter("nrm_proc_yn")){
			mbtt02001vo.setNrmProcYn(" ");
		} else {
			mbtt02001vo.setNrmProcYn(StringUtil.nvl(request.getParameter("nrm_proc_yn")));
		}
		if("".equals(request.getParameter("crd_scn_cncl_pss_yn")) || null == request.getParameter("crd_scn_cncl_pss_yn")){
			mbtt02001vo.setCrdScnCnclPssYn(" ");
		} else {
			mbtt02001vo.setCrdScnCnclPssYn(StringUtil.nvl(request.getParameter("crd_scn_cncl_pss_yn")));
		}
		mbtt02001vo.setRespCn(StringUtil.nvl(pre_mmti0259vo.getZ_resp_cd()));
		mbtt02001vo.setRslCn(scrnNm + "_" + StringUtil.nvl(pre_mmti0259vo.getZ_resp_msg()));
		mbtt02001vo.setFrstIpmnEmpno("82101685");
		mbtt02001vo.setFnalAmdrEmpno("82101685");
		
		if("".equals(pre_mmti0259vo.getAdc_rtrn_dvn()) || null == pre_mmti0259vo.getAdc_rtrn_dvn()){
			mbtt02001vo.setAdcRtrnDvn(" ");
		} else {
			mbtt02001vo.setAdcRtrnDvn(StringUtil.nvl(pre_mmti0259vo.getAdc_rtrn_dvn()));
		}
		if("".equals(request.getParameter("scrn_proc_cd")) || null == request.getParameter("scrn_proc_cd")){
			mbtt02001vo.setScrnProcCd(" ");
		} else {
			mbtt02001vo.setScrnProcCd(StringUtil.nvl(request.getParameter("scrn_proc_cd")));
		}
		if("".equals(request.getParameter("ctc_plno")) || null == request.getParameter("ctc_plno")){
			mbtt02001vo.setCtcPlno(" ");
		} else {
			mbtt02001vo.setCtcPlno(StringUtil.nvl(request.getParameter("ctc_plno")));
		}
		if("".equals(request.getParameter("trv_dstc_proc_dvcd")) || null == request.getParameter("trv_dstc_proc_dvcd")){
			mbtt02001vo.setTrvDstcProcDvcd(" ");
		} else {
			mbtt02001vo.setTrvDstcProcDvcd(StringUtil.nvl(request.getParameter("trv_dstc_proc_dvcd")));
		}
		if("".equals(request.getParameter("mbl_snd_no")) || null == request.getParameter("mbl_snd_no")){
			mbtt02001vo.setMblSndNo(" ");
		} else {
			mbtt02001vo.setMblSndNo(StringUtil.nvl(request.getParameter("mbl_snd_no")));
		}
		if("".equals(request.getParameter("plan_plno_dvcd")) || null == request.getParameter("plan_plno_dvcd")){
			mbtt02001vo.setPlanPlnoDvcd(" ");
		} else {
			mbtt02001vo.setPlanPlnoDvcd(StringUtil.nvl(request.getParameter("plan_plno_dvcd")));
		}
		if("".equals(request.getParameter("plan_plno")) || null == request.getParameter("plan_plno")){
			mbtt02001vo.setPlanPlno(" ");
		} else {
			mbtt02001vo.setPlanPlno(StringUtil.nvl(request.getParameter("plan_plno")));
		}
		if("".equals(request.getParameter("chng_plan_no")) || null == request.getParameter("chng_plan_no")){
			mbtt02001vo.setChngPlanNo(" ");
		} else {
			mbtt02001vo.setChngPlanNo(StringUtil.nvl(request.getParameter("chng_plan_no")));
		}
		if("".equals(request.getParameter("dst_tty_dvn1")) || null == request.getParameter("dst_tty_dvn1")){
			mbtt02001vo.setDstTtyDvn1(" ");
		} else {
			mbtt02001vo.setDstTtyDvn1(StringUtil.nvl(request.getParameter("dst_tty_dvn1")));
		}
		if("".equals(request.getParameter("dst_tty_dvn2")) || null == request.getParameter("dst_tty_dvn2")){
			mbtt02001vo.setDstTtyDvn2(" ");
		} else {
			mbtt02001vo.setDstTtyDvn2(StringUtil.nvl(request.getParameter("dst_tty_dvn2")));
		}
		if("".equals(request.getParameter("dst_tty_dvn3")) || null == request.getParameter("dst_tty_dvn3")){
			mbtt02001vo.setDstTtyDvn3(" ");
		} else {
			mbtt02001vo.setDstTtyDvn3(StringUtil.nvl(request.getParameter("dst_tty_dvn3")));
		}
		if("".equals(request.getParameter("dst_tty_dvn4")) || null == request.getParameter("dst_tty_dvn4")){
			mbtt02001vo.setDstTtyDvn4(" ");
		} else {
			mbtt02001vo.setDstTtyDvn4(StringUtil.nvl(request.getParameter("dst_tty_dvn4")));
		}
		if("".equals(request.getParameter("dst_tty_dvn5")) || null == request.getParameter("dst_tty_dvn5")){
			mbtt02001vo.setDstTtyDvn5(" ");
		} else {
			mbtt02001vo.setDstTtyDvn5(StringUtil.nvl(request.getParameter("dst_tty_dvn5")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt1")) || null == request.getParameter("phgp_regt_tgt1")){
			mbtt02001vo.setPhgpRegtTgt1(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt1(StringUtil.nvl(request.getParameter("phgp_regt_tgt1")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt2")) || null == request.getParameter("phgp_regt_tgt2")){
			mbtt02001vo.setPhgpRegtTgt2(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt2(StringUtil.nvl(request.getParameter("phgp_regt_tgt2")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt3")) || null == request.getParameter("phgp_regt_tgt3")){
			mbtt02001vo.setPhgpRegtTgt3(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt3(StringUtil.nvl(request.getParameter("phgp_regt_tgt3")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt4")) || null == request.getParameter("phgp_regt_tgt4")){
			mbtt02001vo.setPhgpRegtTgt4(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt4(StringUtil.nvl(request.getParameter("phgp_regt_tgt4")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt5")) || null == request.getParameter("phgp_regt_tgt5")){
			mbtt02001vo.setPhgpRegtTgt5(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt5(StringUtil.nvl(request.getParameter("phgp_regt_tgt5")));
		}
		
		//MMTI0259 insert
		insertRow = 0;
		
		logger.info("#### upMileageStep7A MMTI0259 MBTT02001 before ####");
		insertRow = mileageTobeService.insertJungsanTest(mbtt02001vo);
		logger.info("#### upMileageStep7A MMTI0259 MBTT02001 after ####");
		
		if(insertRow < 1){
			logger.info("#### 사서함번호: " + StringUtil.nvl(mbtt02001vo.getPboxNo()) + "####");
			logger.info("#### insert 결과: Fail ####");
		}else{
			logger.info("#### insert 결과: Success ####");
		}
		
		if("3".equals(gubun)) {
			MMTI0291VO mmti0291vo = new MMTI0291VO();
			
			mmti0291vo.setTrv_dstc_exca_mtt__exca_bz_proc_dvn("2");
			mmti0291vo.setTrv_dstc_exca_mtt__plno(pre_mmti0259vo.getPlno());
			mmti0291vo.setTrv_dstc_exca_mtt__plan_no(pre_mmti0259vo.getExp_exca_plan_no());
			// 정산환급구분(1: 계좌환급)
			mmti0291vo.setTrv_dstc_exca_mtt__exca_rtrn_dvn("1");
			mmti0291vo.setTrv_dstc_exca_mtt__pdc_sr_dvn(pre_mmti0259vo.getPdc_sr_dvn());
			mmti0291vo.setTrv_dstc_exca_mtt__scrn_proc_cd(pre_mmti0259vo.getExp_exca_plan_rsl_cd());
			
			// 키패드
			String account = "";
			try {
				account = TransKey.decode("account", request);
			}
			catch(Exception e) {
				logger.debug(e.getMessage());
				account = request.getParameter("account");
			}
			logger.debug("account: " + account);
			mmti0291vo.setTrv_dstc_exca_mtt__bank_cd(request.getParameter("bank"));
			mmti0291vo.setTrv_dstc_exca_mtt__acc_no(account);
			// 키패드
			
			mmti0291vo.setTrv_dstc_exca_mtt__adc_rtrn_dvn(pre_mmti0259vo.getAdc_rtrn_dvn());
			mmti0291vo.setTrv_dstc_exca_mtt__adc_rtrn_prm(pre_mmti0259vo.getAdc_rtrn_prm());
			mmti0291vo.setTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn(pre_mmti0213vo.getTrv_dstc_splc_exca_yn());
			mmti0291vo.setTrv_dstc_exca_mtt__pbox_no(pre_mmti0213vo.getSms_ts_bvan());
			mmti0291vo = mileageTobeService.getMMTI0291VO(mmti0291vo);
			
			
			// 부적정/중복 이미지인 경우 화면처리코드 02 
			if("1".equals(mmti0291vo.getTrv_dstc_exca_mtt__imag_dup_yn())){
				mmti0291vo.setTrv_dstc_exca_mtt__scrn_proc_cd("02");
			}
			session.setAttribute("mmti0291vo", mmti0291vo);
			
			// CM 상품이고, 화면처리코드 IN(02, 14) or 이미지 중복
			
			if("CM".equals(mmti0291vo.getTrv_dstc_exca_mtt__pdc_sr_dvn()) && 
					("02".equals(mmti0291vo.getTrv_dstc_exca_mtt__scrn_proc_cd())
					|| "14".equals(mmti0291vo.getTrv_dstc_exca_mtt__scrn_proc_cd()))){
				
				MMTI0015VO mmti0015vo = new MMTI0015VO();
				mmti0015vo.setFunt_key("00");
				mmti0015vo.setPlan_no(mmti0291vo.getTrv_dstc_exca_mtt__plan_no());
				mmti0015vo = mileageTobeService.getMMTI0015VO(mmti0015vo);
				
				logger.debug("##### MMTI0015 시작 ##########################");
				logger.debug("##### 고객식별번호: " + mmti0015vo.getPlhd__cust_dcmt_no() + " ##########################");
				logger.debug("##### 고객번호: " + mmti0015vo.getPlhd__cust_no() + " ##########################");
				logger.debug("##### 고객명: " + mmti0015vo.getPlhd__cust_nm() + " ##########################");
				logger.debug("##### 이메일: " + mmti0015vo.getPlhd__eml() + " ##########################");
				logger.debug("##### 지역번호: " + mmti0015vo.getPlhd_cntp_if__tlp_arno() + " ##########################");
				logger.debug("##### 국번호: " + mmti0015vo.getPlhd_cntp_if__tlp_ofno() + " ##########################");
				logger.debug("##### 개별번호: " + mmti0015vo.getPlhd_cntp_if__tlp_idvno() + " ##########################");
				
				XTEM0021VO xtem0021vo = new XTEM0021VO();
				xtem0021vo.setCnsl_rpt_no("");						// 상담접수번호				
				xtem0021vo.setCm_bz_dvcd("05");
				xtem0021vo.setCnsl_typ_dvcd("07");
				xtem0021vo.setCm_plan_no(mmti0291vo.getTrv_dstc_exca_mtt__plan_no());
				xtem0021vo.setCnsl_rpy_dvcd("1");
				xtem0021vo.setCnsl_rpt_dttm(getDayTime());			// 현재년월일시분초 14자리
				xtem0021vo.setCust_nm(mmti0015vo.getPlhd__cust_nm());
				xtem0021vo.setCust_no(mmti0015vo.getPlhd__cust_no());
				
				String cust_dcmt_no = SeedUtil.decrypt(mmti0015vo.getPlhd__cust_dcmt_no());
				
				if("1".equals(cust_dcmt_no.substring(6, 7)) || "2".equals(cust_dcmt_no.substring(6, 7))
					|| "5".equals(cust_dcmt_no.substring(6, 7)) || "6".equals(cust_dcmt_no.substring(6, 7))){
					xtem0021vo.setBrth("19" + cust_dcmt_no.substring(0, 6));
				} else{
					xtem0021vo.setBrth("20" + cust_dcmt_no.substring(0, 6));
				}
				// xtem0021vo.setBrth("");  							// 생년월일
				xtem0021vo.setSx_cd(cust_dcmt_no.substring(6, 7));
				xtem0021vo.setEml_adr(mmti0015vo.getPlhd__eml());
				xtem0021vo.setClp_tlcno(mmti0015vo.getPlhd_cntp_if__tlp_arno());
				xtem0021vo.setClp_ofno(mmti0015vo.getPlhd_cntp_if__tlp_ofno());
				xtem0021vo.setClp_idvno(mmti0015vo.getPlhd_cntp_if__tlp_idvno());
				xtem0021vo.setCnsl_rsvt_dt("99990101");
				xtem0021vo.setCnsl_rsvt_time_cd("1");
				xtem0021vo.setCnsl_cn("최종주행거리사진등록/만기정산");
				xtem0021vo.setCnsl_aply_csn_yn("1");
				xtem0021vo.setUrl_adr("");
				xtem0021vo.setCm_ctrmf_tpcd("32");
				xtem0021vo.setFrst_ipmn_empno("80000028");
				xtem0021vo.setFrst_ipnpt_dttm(getDayTime());		// 현재년월일시분초 14자리	
				
				xtem0021vo = mileageTobeService.getXTEM0021VO(xtem0021vo);
				logger.debug("##### XTEM0021 시작 ##########################");
				logger.debug("##### 처리결과: [ " + xtem0021vo.getProc_rtn() + " ] ##########################");
			}
			
			//MMTI0291전문 정산이력테이블(MBTT02001) 적재
			mbtt02001vo.setPboxNo(StringUtil.nvl(pre_mmti0213vo.getSms_ts_bvan()));
			mbtt02001vo.setTlgIdVal("MMTI0291");
			mbtt02001vo.setEsbTrscId(StringUtil.nvl(mmti0291vo.getZ_trsc_id()));
			if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__plno()) || null == mmti0291vo.getTrv_dstc_exca_mtt__plno()){
				mbtt02001vo.setPlno(" ");
			} else {
				mbtt02001vo.setPlno(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__plno()));
			}
			if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__plan_no()) || null == mmti0291vo.getTrv_dstc_exca_mtt__plan_no()){
				mbtt02001vo.setPlanNo(" ");
			} else {
				mbtt02001vo.setPlanNo(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__plan_no()));
			}
			if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__rnw_plno()) || null == mmti0291vo.getTrv_dstc_exca_mtt__rnw_plno()){
				mbtt02001vo.setRnwPlno(" ");
			} else {
				mbtt02001vo.setRnwPlno(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__rnw_plno()));
			}
			mbtt02001vo.setTlgProcRslCdVal(StringUtil.nvl(mmti0291vo.getZ_tlg_sp_cd()));
			mbtt02001vo.setTlgErrCdVal(StringUtil.nvl(mmti0291vo.getZ_trns_org_dvcd())+StringUtil.nvl(mmti0291vo.getZ_trns_org_cd()));
			if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__hdlr_empno()) || null == mmti0291vo.getTrv_dstc_exca_mtt__hdlr_empno()){
				mbtt02001vo.setHdlrEmpno(" ");
			} else {
				mbtt02001vo.setHdlrEmpno(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__hdlr_empno()));
			}
			if("".equals(request.getParameter("pbox_no_dvcd")) || null == request.getParameter("pbox_no_dvcd")){
				mbtt02001vo.setPboxNoDvcd(" ");
			} else {
				mbtt02001vo.setPboxNoDvcd(StringUtil.nvl(request.getParameter("pbox_no_dvcd")));
			}
			if("".equals(request.getParameter("proc_dvn")) || null == request.getParameter("proc_dvn")){
				mbtt02001vo.setProcDvn(" ");
			} else {
				mbtt02001vo.setProcDvn(StringUtil.nvl(request.getParameter("proc_dvn")));
			}
			if("".equals(request.getParameter("trv_dstc_exp_exca_dvcd")) || null == request.getParameter("trv_dstc_exp_exca_dvcd")){
				mbtt02001vo.setTrvDstcExpExcaDvcd(" ");
			} else {
				mbtt02001vo.setTrvDstcExpExcaDvcd(StringUtil.nvl(request.getParameter("trv_dstc_exp_exca_dvcd")));
			}
			if("".equals(request.getParameter("trv_dstc_chng_aply_dvn")) || null == request.getParameter("trv_dstc_chng_aply_dvn")){
				mbtt02001vo.setTrvDstcChngAplyDvn(" ");
			} else {
				mbtt02001vo.setTrvDstcChngAplyDvn(StringUtil.nvl(request.getParameter("trv_dstc_chng_aply_dvn")));
			}
			if("".equals(request.getParameter("hdlr_fire_yn")) || null == request.getParameter("hdlr_fire_yn")){
				mbtt02001vo.setHdlrFireYn(" ");
			} else {
				mbtt02001vo.setHdlrFireYn(StringUtil.nvl(request.getParameter("hdlr_fire_yn")));
			}
			if("".equals(request.getParameter("mtcc_yn")) || null == request.getParameter("mtcc_yn")){
				mbtt02001vo.setMtccYn(" ");
			} else {
				mbtt02001vo.setMtccYn(StringUtil.nvl(request.getParameter("mtcc_yn")));
			}
			if("".equals(request.getParameter("aut_cgnt_trv_dstc")) || null == request.getParameter("aut_cgnt_trv_dstc")){
				mbtt02001vo.setAutCgntTrvDstc(0);
			} else {
				mbtt02001vo.setAutCgntTrvDstc(Double.parseDouble(request.getParameter("aut_cgnt_trv_dstc")));
			}
			if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__aut_cgnt_trv_dstc_rsl_cd()) || null == mmti0291vo.getTrv_dstc_exca_mtt__aut_cgnt_trv_dstc_rsl_cd()){
				mbtt02001vo.setAutCgntTrvDstcRslCd(" ");
			} else {
				mbtt02001vo.setAutCgntTrvDstcRslCd(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__aut_cgnt_trv_dstc_rsl_cd()));
			}
			if("".equals(request.getParameter("inptTrvDstc")) || null == request.getParameter("inptTrvDstc")){
				mbtt02001vo.setInptTrvDstc(0);
			} else {
				mbtt02001vo.setInptTrvDstc(Double.parseDouble(request.getParameter("inptTrvDstc")));
			}
			if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__cnv_trv_dstc()) || null == mmti0291vo.getTrv_dstc_exca_mtt__cnv_trv_dstc()){
				mbtt02001vo.setCnvTrvDstc(0);
			} else {
				mbtt02001vo.setCnvTrvDstc(Double.parseDouble(mmti0291vo.getTrv_dstc_exca_mtt__cnv_trv_dstc()));
			}
			if("".equals(request.getParameter("exp_exca_plan_rsl_cd")) || null == request.getParameter("exp_exca_plan_rsl_cd")){
				mbtt02001vo.setExpExcaPlanRslCd(" ");
			} else {
				mbtt02001vo.setExpExcaPlanRslCd(StringUtil.nvl(request.getParameter("exp_exca_plan_rsl_cd")));
			}
			if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__exca_bz_proc_dvn()) || null == mmti0291vo.getTrv_dstc_exca_mtt__exca_bz_proc_dvn()){
				mbtt02001vo.setExcaBzProcDvn(" ");
			} else {
				mbtt02001vo.setExcaBzProcDvn(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__exca_bz_proc_dvn()));
			}
			if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__exca_rtrn_dvn()) || null == mmti0291vo.getTrv_dstc_exca_mtt__exca_rtrn_dvn()){
				mbtt02001vo.setExcaRtrnDvn(" ");
			} else {
				mbtt02001vo.setExcaRtrnDvn(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__exca_rtrn_dvn()));
			}
			if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__pdc_sr_dvn()) || null == mmti0291vo.getTrv_dstc_exca_mtt__pdc_sr_dvn()){
				mbtt02001vo.setPdcSrDvn(" ");
			} else {
				mbtt02001vo.setPdcSrDvn(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__pdc_sr_dvn()));
			}
			if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__adc_rtrn_prm()) || null == mmti0291vo.getTrv_dstc_exca_mtt__adc_rtrn_prm()){
				mbtt02001vo.setAdcRtrnPrm(0);
			} else {
				mbtt02001vo.setAdcRtrnPrm(Double.parseDouble(mmti0291vo.getTrv_dstc_exca_mtt__adc_rtrn_prm()));
			}
			if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn()) || null == mmti0291vo.getTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn()){
				mbtt02001vo.setTrvDstcSplcExcaYn(" ");
			} else {
				mbtt02001vo.setTrvDstcSplcExcaYn(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn()));
			}
			if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__imag_dup_yn()) || null == mmti0291vo.getTrv_dstc_exca_mtt__imag_dup_yn()){
				mbtt02001vo.setImagDupYn(" ");
			} else {
				mbtt02001vo.setImagDupYn(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__imag_dup_yn()));
			}
			if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__nrm_proc_yn()) || null == mmti0291vo.getTrv_dstc_exca_mtt__nrm_proc_yn()){
				mbtt02001vo.setNrmProcYn(" ");
			} else {
				mbtt02001vo.setNrmProcYn(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__nrm_proc_yn()));
			}
			if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__crd_scn_cncl_pss_yn()) || null == mmti0291vo.getTrv_dstc_exca_mtt__crd_scn_cncl_pss_yn()){
				mbtt02001vo.setCrdScnCnclPssYn(" ");
			} else {
				mbtt02001vo.setCrdScnCnclPssYn(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__crd_scn_cncl_pss_yn()));
			}
			mbtt02001vo.setRespCn(StringUtil.nvl(mmti0291vo.getZ_resp_cd()));
			mbtt02001vo.setRslCn(scrnNm + "_" + StringUtil.nvl(mmti0291vo.getZ_resp_msg()));
			mbtt02001vo.setFrstIpmnEmpno("82101685");
			mbtt02001vo.setFnalAmdrEmpno("82101685");
			if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__adc_rtrn_dvn()) || null == mmti0291vo.getTrv_dstc_exca_mtt__adc_rtrn_dvn()){
				mbtt02001vo.setAdcRtrnDvn(" ");
			} else {
				mbtt02001vo.setAdcRtrnDvn(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__adc_rtrn_dvn()));
			}
			if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__scrn_proc_cd()) || null == mmti0291vo.getTrv_dstc_exca_mtt__scrn_proc_cd()){
				mbtt02001vo.setScrnProcCd(" ");
			} else {
				mbtt02001vo.setScrnProcCd(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__scrn_proc_cd()));
			}
			if("".equals(request.getParameter("ctc_plno")) || null == request.getParameter("ctc_plno")){
				mbtt02001vo.setCtcPlno(" ");
			} else {
				mbtt02001vo.setCtcPlno(StringUtil.nvl(request.getParameter("ctc_plno")));
			}
			if("".equals(request.getParameter("trv_dstc_proc_dvcd")) || null == request.getParameter("trv_dstc_proc_dvcd")){
				mbtt02001vo.setTrvDstcProcDvcd(" ");
			} else {
				mbtt02001vo.setTrvDstcProcDvcd(StringUtil.nvl(request.getParameter("trv_dstc_proc_dvcd")));
			}
			if("".equals(request.getParameter("mbl_snd_no")) || null == request.getParameter("mbl_snd_no")){
				mbtt02001vo.setMblSndNo(" ");
			} else {
				mbtt02001vo.setMblSndNo(StringUtil.nvl(request.getParameter("mbl_snd_no")));
			}
			if("".equals(request.getParameter("plan_plno_dvcd")) || null == request.getParameter("plan_plno_dvcd")){
				mbtt02001vo.setPlanPlnoDvcd(" ");
			} else {
				mbtt02001vo.setPlanPlnoDvcd(StringUtil.nvl(request.getParameter("plan_plno_dvcd")));
			}
			if("".equals(request.getParameter("plan_plno")) || null == request.getParameter("plan_plno")){
				mbtt02001vo.setPlanPlno(" ");
			} else {
				mbtt02001vo.setPlanPlno(StringUtil.nvl(request.getParameter("plan_plno")));
			}
			if("".equals(request.getParameter("chng_plan_no")) || null == request.getParameter("chng_plan_no")){
				mbtt02001vo.setChngPlanNo(" ");
			} else {
				mbtt02001vo.setChngPlanNo(StringUtil.nvl(request.getParameter("chng_plan_no")));
			}
			if("".equals(request.getParameter("dst_tty_dvn1")) || null == request.getParameter("dst_tty_dvn1")){
				mbtt02001vo.setDstTtyDvn1(" ");
			} else {
				mbtt02001vo.setDstTtyDvn1(StringUtil.nvl(request.getParameter("dst_tty_dvn1")));
			}
			if("".equals(request.getParameter("dst_tty_dvn2")) || null == request.getParameter("dst_tty_dvn2")){
				mbtt02001vo.setDstTtyDvn2(" ");
			} else {
				mbtt02001vo.setDstTtyDvn2(StringUtil.nvl(request.getParameter("dst_tty_dvn2")));
			}
			if("".equals(request.getParameter("dst_tty_dvn3")) || null == request.getParameter("dst_tty_dvn3")){
				mbtt02001vo.setDstTtyDvn3(" ");
			} else {
				mbtt02001vo.setDstTtyDvn3(StringUtil.nvl(request.getParameter("dst_tty_dvn3")));
			}
			if("".equals(request.getParameter("dst_tty_dvn4")) || null == request.getParameter("dst_tty_dvn4")){
				mbtt02001vo.setDstTtyDvn4(" ");
			} else {
				mbtt02001vo.setDstTtyDvn4(StringUtil.nvl(request.getParameter("dst_tty_dvn4")));
			}
			if("".equals(request.getParameter("dst_tty_dvn5")) || null == request.getParameter("dst_tty_dvn5")){
				mbtt02001vo.setDstTtyDvn5(" ");
			} else {
				mbtt02001vo.setDstTtyDvn5(StringUtil.nvl(request.getParameter("dst_tty_dvn5")));
			}
			if("".equals(request.getParameter("phgp_regt_tgt1")) || null == request.getParameter("phgp_regt_tgt1")){
				mbtt02001vo.setPhgpRegtTgt1(" ");
			} else {
				mbtt02001vo.setPhgpRegtTgt1(StringUtil.nvl(request.getParameter("phgp_regt_tgt1")));
			}
			if("".equals(request.getParameter("phgp_regt_tgt2")) || null == request.getParameter("phgp_regt_tgt2")){
				mbtt02001vo.setPhgpRegtTgt2(" ");
			} else {
				mbtt02001vo.setPhgpRegtTgt2(StringUtil.nvl(request.getParameter("phgp_regt_tgt2")));
			}
			if("".equals(request.getParameter("phgp_regt_tgt3")) || null == request.getParameter("phgp_regt_tgt3")){
				mbtt02001vo.setPhgpRegtTgt3(" ");
			} else {
				mbtt02001vo.setPhgpRegtTgt3(StringUtil.nvl(request.getParameter("phgp_regt_tgt3")));
			}
			if("".equals(request.getParameter("phgp_regt_tgt4")) || null == request.getParameter("phgp_regt_tgt4")){
				mbtt02001vo.setPhgpRegtTgt4(" ");
			} else {
				mbtt02001vo.setPhgpRegtTgt4(StringUtil.nvl(request.getParameter("phgp_regt_tgt4")));
			}
			if("".equals(request.getParameter("phgp_regt_tgt5")) || null == request.getParameter("phgp_regt_tgt5")){
				mbtt02001vo.setPhgpRegtTgt5(" ");
			} else {
				mbtt02001vo.setPhgpRegtTgt5(StringUtil.nvl(request.getParameter("phgp_regt_tgt5")));
			}
			
			//MMTI0291 insert
			insertRow = 0;
			
			logger.info("#### upMileageStep7A MMTI0291 MBTT02001 before ####");
			insertRow = mileageTobeService.insertJungsanTest(mbtt02001vo);
			logger.info("#### upMileageStep7A MMTI0291 MBTT02001 after ####");
			
			if(insertRow < 1){
				logger.info("#### 사서함번호: " + StringUtil.nvl(mbtt02001vo.getPboxNo()) + "####");
				logger.info("#### insert 결과: Fail ####");
			}else{
				logger.info("#### insert 결과: Success ####");
			}
		}
		
		MMTI0218VO jmvo0218 = new MMTI0218VO();
		
		jmvo0218.setMbl_snd_no(mmti0217vo.getMbl_snd_no());
		jmvo0218.setPlan_plno_dvcd(mmti0217vo.getPlan_plno_dvcd());
		jmvo0218.setPlan_plno(mmti0217vo.getPlan_plno());
		jmvo0218.setChng_plan_no(mmti0217vo.getChng_plan_no());
		
		jmvo0218 = mileageTobeService.getMMTI0218VO(jmvo0218);
		int count = 0;
		for(int i = 0; i < jmvo0218.getPhgp_regt_tgt__dst_tty_dvn().length; i++) {
			if("Y".equals(jmvo0218.getPhgp_regt_tgt__phgp_regt_cplt_yn()[i]) || "1".equals(jmvo0218.getPhgp_regt_tgt__phgp_regt_cplt_yn()[i])) count++;
		}
		
		if(count > 0 && count == jmvo0218.getPhgp_regt_tgt__dst_tty_dvn().length){
			request.setAttribute("reg_yn", "1");
		}else{
			request.setAttribute("reg_yn", "0");
		}
		
		//MMTI0218전문 정산이력테이블(MBTT02001) 적재
		mbtt02001vo.setPboxNo(StringUtil.nvl(pre_mmti0213vo.getSms_ts_bvan()));
		mbtt02001vo.setTlgIdVal("MMTI0218");
		mbtt02001vo.setEsbTrscId(StringUtil.nvl(jmvo0218.getZ_trsc_id()));
		if("".equals(request.getParameter("plno")) || null == request.getParameter("plno")){
			mbtt02001vo.setPlno(" ");
		} else {
			mbtt02001vo.setPlno(StringUtil.nvl(request.getParameter("plno")));
		}
		if("".equals(request.getParameter("plan_no")) || null == request.getParameter("plan_no")){
			mbtt02001vo.setPlanNo(" ");
		} else {
			mbtt02001vo.setPlanNo(StringUtil.nvl(request.getParameter("plan_no")));
		}
		if("".equals(request.getParameter("rnw_plno")) || null == request.getParameter("rnw_plno")){
			mbtt02001vo.setRnwPlno(" ");
		} else {
			mbtt02001vo.setRnwPlno(StringUtil.nvl(request.getParameter("rnw_plno")));
		}
		mbtt02001vo.setTlgProcRslCdVal(StringUtil.nvl(jmvo0218.getZ_tlg_sp_cd()));
		mbtt02001vo.setTlgErrCdVal(StringUtil.nvl(jmvo0218.getZ_trns_org_dvcd())+StringUtil.nvl(jmvo0218.getZ_trns_org_cd()));
		if("".equals(request.getParameter("hdlr_empno")) || null == request.getParameter("hdlr_empno")){
			mbtt02001vo.setHdlrEmpno(" ");
		} else {
			mbtt02001vo.setHdlrEmpno(StringUtil.nvl(request.getParameter("hdlr_empno")));
		}
		if("".equals(request.getParameter("pbox_no_dvcd")) || null == request.getParameter("pbox_no_dvcd")){
			mbtt02001vo.setPboxNoDvcd(" ");
		} else {
			mbtt02001vo.setPboxNoDvcd(StringUtil.nvl(request.getParameter("pbox_no_dvcd")));
		}
		if("".equals(request.getParameter("proc_dvn")) || null == request.getParameter("proc_dvn")){
			mbtt02001vo.setProcDvn(" ");
		} else {
			mbtt02001vo.setProcDvn(StringUtil.nvl(request.getParameter("proc_dvn")));
		}
		if("".equals(request.getParameter("trv_dstc_exp_exca_dvcd")) || null == request.getParameter("trv_dstc_exp_exca_dvcd")){
			mbtt02001vo.setTrvDstcExpExcaDvcd(" ");
		} else {
			mbtt02001vo.setTrvDstcExpExcaDvcd(StringUtil.nvl(request.getParameter("trv_dstc_exp_exca_dvcd")));
		}
		if("".equals(request.getParameter("trv_dstc_chng_aply_dvn")) || null == request.getParameter("trv_dstc_chng_aply_dvn")){
			mbtt02001vo.setTrvDstcChngAplyDvn(" ");
		} else {
			mbtt02001vo.setTrvDstcChngAplyDvn(StringUtil.nvl(request.getParameter("trv_dstc_chng_aply_dvn")));
		}
		if("".equals(request.getParameter("hdlr_fire_yn")) || null == request.getParameter("hdlr_fire_yn")){
			mbtt02001vo.setHdlrFireYn(" ");
		} else {
			mbtt02001vo.setHdlrFireYn(StringUtil.nvl(request.getParameter("hdlr_fire_yn")));
		}
		if("".equals(request.getParameter("mtcc_yn")) || null == request.getParameter("mtcc_yn")){
			mbtt02001vo.setMtccYn(" ");
		} else {
			mbtt02001vo.setMtccYn(StringUtil.nvl(request.getParameter("mtcc_yn")));
		}
		if("".equals(request.getParameter("aut_cgnt_trv_dstc")) || null == request.getParameter("aut_cgnt_trv_dstc")){
			mbtt02001vo.setAutCgntTrvDstc(0);
		} else {
			mbtt02001vo.setAutCgntTrvDstc(Double.parseDouble(request.getParameter("aut_cgnt_trv_dstc")));
		}
		if("".equals(request.getParameter("aut_cgnt_trv_dstc_rsl_cd")) || null == request.getParameter("aut_cgnt_trv_dstc_rsl_cd")){
			mbtt02001vo.setAutCgntTrvDstcRslCd(" ");
		} else {
			mbtt02001vo.setAutCgntTrvDstcRslCd(StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc_rsl_cd")));
		}
		if("".equals(request.getParameter("inptTrvDstc")) || null == request.getParameter("inptTrvDstc")){
			mbtt02001vo.setInptTrvDstc(0);
		} else {
			mbtt02001vo.setInptTrvDstc(Double.parseDouble(request.getParameter("inptTrvDstc")));
		}
		if("".equals(request.getParameter("cnv_trv_dstc")) || null == request.getParameter("cnv_trv_dstc")){
			mbtt02001vo.setCnvTrvDstc(0);
		} else {
			mbtt02001vo.setCnvTrvDstc(Double.parseDouble(request.getParameter("cnv_trv_dstc")));
		}
		if("".equals(request.getParameter("exp_exca_plan_rsl_cd")) || null == request.getParameter("exp_exca_plan_rsl_cd")){
			mbtt02001vo.setExpExcaPlanRslCd(" ");
		} else {
			mbtt02001vo.setExpExcaPlanRslCd(StringUtil.nvl(request.getParameter("exp_exca_plan_rsl_cd")));
		}
		if("".equals(request.getParameter("exca_bz_proc_dvn")) || null == request.getParameter("exca_bz_proc_dvn")){
			mbtt02001vo.setExcaBzProcDvn(" ");
		} else {
			mbtt02001vo.setExcaBzProcDvn(StringUtil.nvl(request.getParameter("exca_bz_proc_dvn")));
		}
		if("".equals(request.getParameter("exca_rtrn_dvn")) || null == request.getParameter("exca_rtrn_dvn")){
			mbtt02001vo.setExcaRtrnDvn(" ");
		} else {
			mbtt02001vo.setExcaRtrnDvn(StringUtil.nvl(request.getParameter("exca_rtrn_dvn")));
		}
		if("".equals(request.getParameter("pdc_sr_dvn")) || null == request.getParameter("pdc_sr_dvn")){
			mbtt02001vo.setPdcSrDvn(" ");
		} else {
			mbtt02001vo.setPdcSrDvn(StringUtil.nvl(request.getParameter("pdc_sr_dvn")));
		}
		if("".equals(request.getParameter("adc_rtrn_prm")) || null == request.getParameter("adc_rtrn_prm")){
			mbtt02001vo.setAdcRtrnPrm(0);
		} else {
			mbtt02001vo.setAdcRtrnPrm(Double.parseDouble(request.getParameter("adc_rtrn_prm")));
		}
		if("".equals(request.getParameter("trv_dstc_splc_exca_yn")) || null == request.getParameter("trv_dstc_splc_exca_yn")){
			mbtt02001vo.setTrvDstcSplcExcaYn(" ");
		} else {
			mbtt02001vo.setTrvDstcSplcExcaYn(StringUtil.nvl(request.getParameter("trv_dstc_splc_exca_yn")));
		}
		if("".equals(request.getParameter("imag_dup_yn")) || null == request.getParameter("imag_dup_yn")){
			mbtt02001vo.setImagDupYn(" ");
		} else {
			mbtt02001vo.setImagDupYn(StringUtil.nvl(request.getParameter("imag_dup_yn")));
		}
		if("".equals(request.getParameter("nrm_proc_yn")) || null == request.getParameter("nrm_proc_yn")){
			mbtt02001vo.setNrmProcYn(" ");
		} else {
			mbtt02001vo.setNrmProcYn(StringUtil.nvl(request.getParameter("nrm_proc_yn")));
		}
		if("".equals(request.getParameter("crd_scn_cncl_pss_yn")) || null == request.getParameter("crd_scn_cncl_pss_yn")){
			mbtt02001vo.setCrdScnCnclPssYn(" ");
		} else {
			mbtt02001vo.setCrdScnCnclPssYn(StringUtil.nvl(request.getParameter("crd_scn_cncl_pss_yn")));
		}
		mbtt02001vo.setRespCn(StringUtil.nvl(jmvo0218.getZ_resp_cd()));
		mbtt02001vo.setRslCn(scrnNm + "_" + StringUtil.nvl(jmvo0218.getZ_resp_msg()));
		mbtt02001vo.setFrstIpmnEmpno("82101685");
		mbtt02001vo.setFnalAmdrEmpno("82101685");
		if("".equals(request.getParameter("adc_rtrn_dvn")) || null == request.getParameter("adc_rtrn_dvn")){
			mbtt02001vo.setAdcRtrnDvn(" ");
		} else {
			mbtt02001vo.setAdcRtrnDvn(StringUtil.nvl(request.getParameter("adc_rtrn_dvn")));
		}
		if("".equals(request.getParameter("scrn_proc_cd")) || null == request.getParameter("scrn_proc_cd")){
			mbtt02001vo.setScrnProcCd(" ");
		} else {
			mbtt02001vo.setScrnProcCd(StringUtil.nvl(request.getParameter("scrn_proc_cd")));
		}
		if("".equals(request.getParameter("ctc_plno")) || null == request.getParameter("ctc_plno")){
			mbtt02001vo.setCtcPlno(" ");
		} else {
			mbtt02001vo.setCtcPlno(StringUtil.nvl(request.getParameter("ctc_plno")));
		}
		if("".equals(request.getParameter("trv_dstc_proc_dvcd")) || null == request.getParameter("trv_dstc_proc_dvcd")){
			mbtt02001vo.setTrvDstcProcDvcd(" ");
		} else {
			mbtt02001vo.setTrvDstcProcDvcd(StringUtil.nvl(request.getParameter("trv_dstc_proc_dvcd")));
		}
		if("".equals(jmvo0218.getMbl_snd_no()) || null == jmvo0218.getMbl_snd_no()){
			mbtt02001vo.setMblSndNo(" ");
		} else {
			mbtt02001vo.setMblSndNo(StringUtil.nvl(jmvo0218.getMbl_snd_no()));
		}
		if("".equals(jmvo0218.getPlan_plno_dvcd()) || null == jmvo0218.getPlan_plno_dvcd()){
			mbtt02001vo.setPlanPlnoDvcd(" ");
		} else {
			mbtt02001vo.setPlanPlnoDvcd(StringUtil.nvl(jmvo0218.getPlan_plno_dvcd()));
		}
		if("".equals(jmvo0218.getPlan_plno()) || null == jmvo0218.getPlan_plno()){
			mbtt02001vo.setPlanPlno(" ");
		} else {
			mbtt02001vo.setPlanPlno(StringUtil.nvl(jmvo0218.getPlan_plno()));
		}
		if("".equals(jmvo0218.getChng_plan_no()) || null == jmvo0218.getChng_plan_no()){
			mbtt02001vo.setChngPlanNo(" ");
		} else {
			mbtt02001vo.setChngPlanNo(StringUtil.nvl(jmvo0218.getChng_plan_no()));
		}
		
		for(int i = 0; i < jmvo0218.getPhgp_regt_tgt__dst_tty_dvn().length; i++) {
			if(!"".equals(jmvo0218.getPhgp_regt_tgt__dst_tty_dvn()[i]) || null != jmvo0218.getPhgp_regt_tgt__dst_tty_dvn()[i]) {
				if("01".equals(jmvo0218.getPhgp_regt_tgt__dst_tty_dvn()[i])){
					mbtt02001vo.setDstTtyDvn1("01");
					mbtt02001vo.setPhgpRegtTgt1(jmvo0218.getPhgp_regt_tgt__phgp_regt_cplt_yn()[i]);
				}
				else if("02".equals(jmvo0218.getPhgp_regt_tgt__dst_tty_dvn()[i])){
					mbtt02001vo.setDstTtyDvn2("02");
					mbtt02001vo.setPhgpRegtTgt2(jmvo0218.getPhgp_regt_tgt__phgp_regt_cplt_yn()[i]);
				}
				else if("03".equals(jmvo0218.getPhgp_regt_tgt__dst_tty_dvn()[i])){
					mbtt02001vo.setDstTtyDvn3("03");
					mbtt02001vo.setPhgpRegtTgt3(jmvo0218.getPhgp_regt_tgt__phgp_regt_cplt_yn()[i]);
				}
				else if("04".equals(jmvo0218.getPhgp_regt_tgt__dst_tty_dvn()[i])){
					mbtt02001vo.setDstTtyDvn4("04");
					mbtt02001vo.setPhgpRegtTgt4(jmvo0218.getPhgp_regt_tgt__phgp_regt_cplt_yn()[i]);
				}
				else if("05".equals(jmvo0218.getPhgp_regt_tgt__dst_tty_dvn()[i])){
					mbtt02001vo.setDstTtyDvn5("05");
					mbtt02001vo.setPhgpRegtTgt5(jmvo0218.getPhgp_regt_tgt__phgp_regt_cplt_yn()[i]);
				}
			}
		}
		if("".equals(mbtt02001vo.getDstTtyDvn1()) || null == mbtt02001vo.getDstTtyDvn1()){
			mbtt02001vo.setDstTtyDvn1(" ");
			mbtt02001vo.setPhgpRegtTgt1(" ");
		}
		if("".equals(mbtt02001vo.getDstTtyDvn2()) || null == mbtt02001vo.getDstTtyDvn2()){
			mbtt02001vo.setDstTtyDvn2(" ");
			mbtt02001vo.setPhgpRegtTgt2(" ");
		}
		if("".equals(mbtt02001vo.getDstTtyDvn3()) || null == mbtt02001vo.getDstTtyDvn3()){
			mbtt02001vo.setDstTtyDvn3(" ");
			mbtt02001vo.setPhgpRegtTgt3(" ");
		}
		if("".equals(mbtt02001vo.getDstTtyDvn4()) || null == mbtt02001vo.getDstTtyDvn4()){
			mbtt02001vo.setDstTtyDvn4(" ");
			mbtt02001vo.setPhgpRegtTgt4(" ");
		}
		if("".equals(mbtt02001vo.getDstTtyDvn5()) || null == mbtt02001vo.getDstTtyDvn5()){
			mbtt02001vo.setDstTtyDvn5(" ");
			mbtt02001vo.setPhgpRegtTgt5(" ");
		}
		
		//MMTI0218 insert
		insertRow = 0;
		
		logger.info("#### upMileageStep7A MMTI0218 MBTT02001 before ####");
		insertRow = mileageTobeService.insertJungsanTest(mbtt02001vo);
		logger.info("#### upMileageStep7A MMTI0218 MBTT02001 after ####");
		
		if(insertRow < 1){
			logger.info("#### 사서함번호: " + StringUtil.nvl(mbtt02001vo.getPboxNo()) + "####");
			logger.info("#### insert 결과: Fail ####");
		}else{
			logger.info("#### insert 결과: Success ####");
		}
		
		request.setAttribute("dvn", "01");
		return "/counter/carrider/tobe/upMileageStep7A";
	}
	
	// 갱신보험료 차감 선택 시
	@RequestMapping(value="/upMileageStep7B")
	public String upMileageStep7B(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		
		HttpSession session = request.getSession();
		session.setAttribute("renewal", "01");
		
		request.setAttribute("dvn", "01");
		return "/counter/carrider/tobe/upMileageStep7B";
	}
	
	// 갱신보험료 차감
	@RequestMapping(value="/upMileageStep7B2")
	public String upMileageStep7B2(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
	
		HttpSession session = request.getSession();
		MMTI0213VO pre_mmti0213vo = new MMTI0213VO();
		MMTI0259VO pre_mmti0259vo = new MMTI0259VO();
		MMTI0291VO mmti0291vo = new MMTI0291VO();
		
		pre_mmti0213vo = (MMTI0213VO)session.getAttribute("pre_mmti0213vo");
		pre_mmti0259vo = (MMTI0259VO)session.getAttribute("pre_mmti0259vo");
		
		MBTT02001VO mbtt02001vo = new MBTT02001VO();
		String scrnNm = "upMileageStep7B2";
		
		//MMTI0213전문 정산이력테이블(MBTT02001) 적재
		mbtt02001vo.setPboxNo(StringUtil.nvl(pre_mmti0213vo.getSms_ts_bvan()));
		mbtt02001vo.setTlgIdVal("MMTI0213");
		mbtt02001vo.setEsbTrscId(StringUtil.nvl(pre_mmti0213vo.getZ_trsc_id()));
		if("".equals(pre_mmti0213vo.getPlno()) || null == pre_mmti0213vo.getPlno()){
			mbtt02001vo.setPlno(" ");
		} else {
			mbtt02001vo.setPlno(StringUtil.nvl(pre_mmti0213vo.getPlno()));
		}
		if("".equals(request.getParameter("exp_exca_plan_no")) || null == request.getParameter("exp_exca_plan_no")){
			mbtt02001vo.setPlanNo(" ");
		} else {
			mbtt02001vo.setPlanNo(StringUtil.nvl(request.getParameter("exp_exca_plan_no")));
		}
		if("".equals(pre_mmti0213vo.getRnw_plno()) || null == pre_mmti0213vo.getRnw_plno()){
			mbtt02001vo.setRnwPlno(" ");
		} else {
			mbtt02001vo.setRnwPlno(StringUtil.nvl(pre_mmti0213vo.getRnw_plno()));
		}
		if("".equals(request.getParameter("hdlr_empno")) || null == request.getParameter("hdlr_empno")){
			mbtt02001vo.setHdlrEmpno(" ");
		} else {
			mbtt02001vo.setHdlrEmpno(StringUtil.nvl(request.getParameter("hdlr_empno")));
		}
		if("".equals(pre_mmti0213vo.getPbox_no_dvcd()) || null == pre_mmti0213vo.getPbox_no_dvcd()){
			mbtt02001vo.setPboxNoDvcd(" ");
		} else {
			mbtt02001vo.setPboxNoDvcd(StringUtil.nvl(pre_mmti0213vo.getPbox_no_dvcd()));
		}
		if("".equals(pre_mmti0213vo.getProc_dvn()) || null == pre_mmti0213vo.getProc_dvn()){
			mbtt02001vo.setProcDvn(" ");
		} else {
			mbtt02001vo.setProcDvn(StringUtil.nvl(pre_mmti0213vo.getProc_dvn()));
		}
		if("".equals(pre_mmti0213vo.getTrv_dstc_exp_exca_dvcd()) || null == pre_mmti0213vo.getTrv_dstc_exp_exca_dvcd()){
			mbtt02001vo.setTrvDstcExpExcaDvcd(" ");
		} else {
			mbtt02001vo.setTrvDstcExpExcaDvcd(StringUtil.nvl(pre_mmti0213vo.getTrv_dstc_exp_exca_dvcd()));
		}
		if("".equals(pre_mmti0213vo.getTrv_dstc_chng_aply_dvn()) || null == pre_mmti0213vo.getTrv_dstc_chng_aply_dvn()){
			mbtt02001vo.setTrvDstcChngAplyDvn(" ");
		} else {
			mbtt02001vo.setTrvDstcChngAplyDvn(StringUtil.nvl(pre_mmti0213vo.getTrv_dstc_chng_aply_dvn()));
		}
		if("".equals(pre_mmti0213vo.getHdlr_fire_yn()) || null == pre_mmti0213vo.getHdlr_fire_yn()){
			mbtt02001vo.setHdlrFireYn(" ");
		} else {
			mbtt02001vo.setHdlrFireYn(StringUtil.nvl(pre_mmti0213vo.getHdlr_fire_yn()));
		}
		if("".equals(pre_mmti0213vo.getMtcc_yn()) || null == pre_mmti0213vo.getMtcc_yn()){
			mbtt02001vo.setMtccYn(" ");
		} else {
			mbtt02001vo.setMtccYn(StringUtil.nvl(pre_mmti0213vo.getMtcc_yn()));
		}
		if("".equals(request.getParameter("aut_cgnt_trv_dstc")) || null == request.getParameter("aut_cgnt_trv_dstc")){
			mbtt02001vo.setAutCgntTrvDstc(0);
		} else {
			mbtt02001vo.setAutCgntTrvDstc(Double.parseDouble(request.getParameter("aut_cgnt_trv_dstc")));
		}
		if("".equals(request.getParameter("aut_cgnt_trv_dstc_rsl_cd")) || null == request.getParameter("aut_cgnt_trv_dstc_rsl_cd")){
			mbtt02001vo.setAutCgntTrvDstcRslCd(" ");
		} else {
			mbtt02001vo.setAutCgntTrvDstcRslCd(StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc_rsl_cd")));
		}
		if("".equals(request.getParameter("cnv_trv_dstc")) || null == request.getParameter("cnv_trv_dstc")){
			mbtt02001vo.setCnvTrvDstc(0);
		} else {
			mbtt02001vo.setCnvTrvDstc(Double.parseDouble(request.getParameter("cnv_trv_dstc")));
		}
		if("".equals(request.getParameter("inptTrvDstc")) || null == request.getParameter("inptTrvDstc")){
			mbtt02001vo.setInptTrvDstc(0);
		} else {
			mbtt02001vo.setInptTrvDstc(Double.parseDouble(request.getParameter("inptTrvDstc")));
		}
		if("".equals(request.getParameter("exp_exca_plan_rsl_cd")) || null == request.getParameter("exp_exca_plan_rsl_cd")){
			mbtt02001vo.setExpExcaPlanRslCd(" ");
		} else {
			mbtt02001vo.setExpExcaPlanRslCd(StringUtil.nvl(request.getParameter("exp_exca_plan_rsl_cd")));
		}
		if("".equals(request.getParameter("excaBzProcDvn")) || null == request.getParameter("excaBzProcDvn")){
			mbtt02001vo.setExcaBzProcDvn(" ");
		} else {
			mbtt02001vo.setExcaBzProcDvn(StringUtil.nvl(request.getParameter("excaBzProcDvn")));
		}
		if("".equals(request.getParameter("excaRtrnDvn")) || null == request.getParameter("excaRtrnDvn")){
			mbtt02001vo.setExcaRtrnDvn(" ");
		} else {
			mbtt02001vo.setExcaRtrnDvn(StringUtil.nvl(request.getParameter("excaRtrnPrm")));
		}
		if("".equals(request.getParameter("pdc_sr_dvn")) || null == request.getParameter("pdc_sr_dvn")){
			mbtt02001vo.setPdcSrDvn(" ");
		} else {
			mbtt02001vo.setPdcSrDvn(StringUtil.nvl(request.getParameter("pdc_sr_dvn")));
		}
		if("".equals(request.getParameter("adc_rtrn_prm")) || null == request.getParameter("adc_rtrn_prm")){
			mbtt02001vo.setAdcRtrnPrm(0);
		} else {
			mbtt02001vo.setAdcRtrnPrm(Double.parseDouble(request.getParameter("adc_rtrn_prm")));
		}
		if("".equals(request.getParameter("trv_dstc_splc_exca_yn")) || null == request.getParameter("trv_dstc_splc_exca_yn")){
			mbtt02001vo.setTrvDstcSplcExcaYn(" ");
		} else {
			mbtt02001vo.setTrvDstcSplcExcaYn(StringUtil.nvl(request.getParameter("trv_dstc_splc_exca_yn")));
		}
		if("".equals(request.getParameter("imag_dup_yn")) || null == request.getParameter("imag_dup_yn")){
			mbtt02001vo.setImagDupYn(" ");
		} else {
			mbtt02001vo.setImagDupYn(StringUtil.nvl(request.getParameter("imag_dup_yn")));
		}
		if("".equals(request.getParameter("nrm_proc_yn")) || null == request.getParameter("nrm_proc_yn")){
			mbtt02001vo.setNrmProcYn(" ");
		} else {
			mbtt02001vo.setNrmProcYn(StringUtil.nvl(request.getParameter("nrm_proc_yn")));
		}
		if("".equals(request.getParameter("crd_scn_cncl_pss_yn")) || null == request.getParameter("crd_scn_cncl_pss_yn")){
			mbtt02001vo.setCrdScnCnclPssYn(" ");
		} else {
			mbtt02001vo.setCrdScnCnclPssYn(StringUtil.nvl(request.getParameter("crd_scn_cncl_pss_yn")));
		}
		mbtt02001vo.setTlgProcRslCdVal(StringUtil.nvl(pre_mmti0213vo.getZ_tlg_sp_cd()));
		mbtt02001vo.setTlgErrCdVal(StringUtil.nvl(pre_mmti0213vo.getZ_trns_org_dvcd())+StringUtil.nvl(pre_mmti0213vo.getZ_trns_org_cd()));
		mbtt02001vo.setRespCn(StringUtil.nvl(pre_mmti0213vo.getZ_resp_cd()));
		mbtt02001vo.setRslCn(scrnNm + "_" + StringUtil.nvl(pre_mmti0213vo.getZ_resp_msg()));
		mbtt02001vo.setFrstIpmnEmpno("82101685");
		mbtt02001vo.setFnalAmdrEmpno("82101685");
		if("".equals(request.getParameter("adc_rtrn_dvn")) || null == request.getParameter("adc_rtrn_dvn")){
			mbtt02001vo.setAdcRtrnDvn(" ");
		} else {
			mbtt02001vo.setAdcRtrnDvn(StringUtil.nvl(request.getParameter("adc_rtrn_dvn")));
		}
		if("".equals(request.getParameter("scrn_proc_cd")) || null == request.getParameter("scrn_proc_cd")){
			mbtt02001vo.setScrnProcCd(" ");
		} else {
			mbtt02001vo.setScrnProcCd(StringUtil.nvl(request.getParameter("scrn_proc_cd")));
		}
		if("".equals(pre_mmti0213vo.getCtc_plno()) || null == pre_mmti0213vo.getCtc_plno()){
			mbtt02001vo.setCtcPlno(" ");
		} else {
			mbtt02001vo.setCtcPlno(StringUtil.nvl(pre_mmti0213vo.getCtc_plno()));
		}
		if("".equals(request.getParameter("trv_dstc_proc_dvcd")) || null == request.getParameter("trv_dstc_proc_dvcd")){
			mbtt02001vo.setTrvDstcProcDvcd(" ");
		} else {
			mbtt02001vo.setTrvDstcProcDvcd(StringUtil.nvl(request.getParameter("trv_dstc_proc_dvcd")));
		}
		if("".equals(request.getParameter("mbl_snd_no")) || null == request.getParameter("mbl_snd_no")){
			mbtt02001vo.setMblSndNo(" ");
		} else {
			mbtt02001vo.setMblSndNo(StringUtil.nvl(request.getParameter("mbl_snd_no")));
		}
		if("".equals(request.getParameter("plan_plno_dvcd")) || null == request.getParameter("plan_plno_dvcd")){
			mbtt02001vo.setPlanPlnoDvcd(" ");
		} else {
			mbtt02001vo.setPlanPlnoDvcd(StringUtil.nvl(request.getParameter("plan_plno_dvcd")));
		}
		if("".equals(request.getParameter("plan_plno")) || null == request.getParameter("plan_plno")){
			mbtt02001vo.setPlanPlno(" ");
		} else {
			mbtt02001vo.setPlanPlno(StringUtil.nvl(request.getParameter("plan_plno")));
		}
		if("".equals(pre_mmti0213vo.getChng_plan_no()) || null == pre_mmti0213vo.getChng_plan_no()){
			mbtt02001vo.setChngPlanNo(" ");
		} else {
			mbtt02001vo.setChngPlanNo(StringUtil.nvl(pre_mmti0213vo.getChng_plan_no()));
		}
		if("".equals(request.getParameter("dst_tty_dvn1")) || null == request.getParameter("dst_tty_dvn1")){
			mbtt02001vo.setDstTtyDvn1(" ");
		} else {
			mbtt02001vo.setDstTtyDvn1(StringUtil.nvl(request.getParameter("dst_tty_dvn1")));
		}
		if("".equals(request.getParameter("dst_tty_dvn2")) || null == request.getParameter("dst_tty_dvn2")){
			mbtt02001vo.setDstTtyDvn2(" ");
		} else {
			mbtt02001vo.setDstTtyDvn2(StringUtil.nvl(request.getParameter("dst_tty_dvn2")));
		}
		if("".equals(request.getParameter("dst_tty_dvn3")) || null == request.getParameter("dst_tty_dvn3")){
			mbtt02001vo.setDstTtyDvn3(" ");
		} else {
			mbtt02001vo.setDstTtyDvn3(StringUtil.nvl(request.getParameter("dst_tty_dvn3")));
		}
		if("".equals(request.getParameter("dst_tty_dvn4")) || null == request.getParameter("dst_tty_dvn4")){
			mbtt02001vo.setDstTtyDvn4(" ");
		} else {
			mbtt02001vo.setDstTtyDvn4(StringUtil.nvl(request.getParameter("dst_tty_dvn4")));
		}
		if("".equals(request.getParameter("dst_tty_dvn5")) || null == request.getParameter("dst_tty_dvn5")){
			mbtt02001vo.setDstTtyDvn5(" ");
		} else {
			mbtt02001vo.setDstTtyDvn5(StringUtil.nvl(request.getParameter("dst_tty_dvn5")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt1")) || null == request.getParameter("phgp_regt_tgt1")){
			mbtt02001vo.setPhgpRegtTgt1(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt1(StringUtil.nvl(request.getParameter("phgp_regt_tgt1")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt2")) || null == request.getParameter("phgp_regt_tgt2")){
			mbtt02001vo.setPhgpRegtTgt2(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt2(StringUtil.nvl(request.getParameter("phgp_regt_tgt2")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt3")) || null == request.getParameter("phgp_regt_tgt3")){
			mbtt02001vo.setPhgpRegtTgt3(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt3(StringUtil.nvl(request.getParameter("phgp_regt_tgt3")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt4")) || null == request.getParameter("phgp_regt_tgt4")){
			mbtt02001vo.setPhgpRegtTgt4(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt4(StringUtil.nvl(request.getParameter("phgp_regt_tgt4")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt5")) || null == request.getParameter("phgp_regt_tgt5")){
			mbtt02001vo.setPhgpRegtTgt5(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt5(StringUtil.nvl(request.getParameter("phgp_regt_tgt5")));
		}
		
		//MMTI0213 insert
		int insertRow = 0;
		
		logger.info("#### upMileageStep7B2 insertJungsanTest before ####");
		insertRow = mileageTobeService.insertJungsanTest(mbtt02001vo);
		logger.info("#### upMileageStep7B2 insertJungsanTest after ####");
		
		if(insertRow < 1){
			logger.info("#### 사서함번호: " + StringUtil.nvl(mbtt02001vo.getPboxNo()) + "####");
			logger.info("#### insert 결과: Fail ####");
		}else{
			logger.info("#### insert 결과: Success ####");
		}
		
		//MMTI0259전문 정산이력테이블(MBTT02001) 적재
		mbtt02001vo.setPboxNo(StringUtil.nvl(pre_mmti0213vo.getSms_ts_bvan()));
		mbtt02001vo.setTlgIdVal("MMTI0259");
		mbtt02001vo.setEsbTrscId(StringUtil.nvl(pre_mmti0259vo.getZ_trsc_id()));
		if("".equals(pre_mmti0259vo.getPlno()) || null == pre_mmti0259vo.getPlno()){
			mbtt02001vo.setPlno(" ");
		} else {
			mbtt02001vo.setPlno(StringUtil.nvl(pre_mmti0259vo.getPlno()));
		}
		if("".equals(request.getParameter("plan_no")) || null == request.getParameter("plan_no")){
			mbtt02001vo.setPlanNo(" ");
		} else {
			mbtt02001vo.setPlanNo(StringUtil.nvl(request.getParameter("plan_no")));
		}
		if("".equals(request.getParameter("rnw_plno")) || null == request.getParameter("rnw_plno")){
			mbtt02001vo.setRnwPlno(" ");
		} else {
			mbtt02001vo.setRnwPlno(StringUtil.nvl(request.getParameter("rnw_plno")));
		}
		mbtt02001vo.setTlgProcRslCdVal(StringUtil.nvl(pre_mmti0259vo.getZ_tlg_sp_cd()));
		mbtt02001vo.setTlgErrCdVal(StringUtil.nvl(pre_mmti0259vo.getZ_trns_org_dvcd())+StringUtil.nvl(pre_mmti0259vo.getZ_trns_org_cd()));
		if("".equals(request.getParameter("hdlrEmpno")) || null == request.getParameter("hdlrEmpno")){
			mbtt02001vo.setHdlrEmpno(" ");
		} else {
			mbtt02001vo.setHdlrEmpno(StringUtil.nvl(request.getParameter("hdlrEmpno")));
		}
		if("".equals(request.getParameter("pbox_no_dvcd")) || null == request.getParameter("pbox_no_dvcd")){
			mbtt02001vo.setPboxNoDvcd(" ");
		} else {
			mbtt02001vo.setPboxNoDvcd(StringUtil.nvl(request.getParameter("pbox_no_dvcd")));
		}
		if("".equals(request.getParameter("proc_dvn")) || null == request.getParameter("proc_dvn")){
			mbtt02001vo.setProcDvn(" ");
		} else {
			mbtt02001vo.setProcDvn(StringUtil.nvl(request.getParameter("proc_dvn")));
		}
		if("".equals(request.getParameter("trv_dstc_exp_exca_dvcd")) || null == request.getParameter("trv_dstc_exp_exca_dvcd")){
			mbtt02001vo.setTrvDstcExpExcaDvcd(" ");
		} else {
			mbtt02001vo.setTrvDstcExpExcaDvcd(StringUtil.nvl(request.getParameter("trv_dstc_exp_exca_dvcd")));
		}
		if("".equals(request.getParameter("trv_dstc_chng_aply_dvn")) || null == request.getParameter("trv_dstc_chng_aply_dvn")){
			mbtt02001vo.setTrvDstcChngAplyDvn(" ");
		} else {
			mbtt02001vo.setTrvDstcChngAplyDvn(StringUtil.nvl(request.getParameter("trv_dstc_chng_aply_dvn")));
		}
		if("".equals(request.getParameter("hdlr_fire_yn")) || null == request.getParameter("hdlr_fire_yn")){
			mbtt02001vo.setHdlrFireYn(" ");
		} else {
			mbtt02001vo.setHdlrFireYn(StringUtil.nvl(request.getParameter("hdlr_fire_yn")));
		}
		if("".equals(request.getParameter("mtcc_yn")) || null == request.getParameter("mtcc_yn")){
			mbtt02001vo.setMtccYn(" ");
		} else {
			mbtt02001vo.setMtccYn(StringUtil.nvl(request.getParameter("mtcc_yn")));
		}
		if("".equals(pre_mmti0259vo.getAut_cgnt_trv_dstc()) || null == pre_mmti0259vo.getAut_cgnt_trv_dstc()){
			mbtt02001vo.setAutCgntTrvDstc(0);
		} else {
			mbtt02001vo.setAutCgntTrvDstc(Double.parseDouble(pre_mmti0259vo.getAut_cgnt_trv_dstc()));
		}
		if("".equals(pre_mmti0259vo.getAut_cgnt_trv_dstc_rsl_cd()) || null == pre_mmti0259vo.getAut_cgnt_trv_dstc_rsl_cd()){
			mbtt02001vo.setAutCgntTrvDstcRslCd(" ");
		} else {
			mbtt02001vo.setAutCgntTrvDstcRslCd(StringUtil.nvl(pre_mmti0259vo.getAut_cgnt_trv_dstc_rsl_cd()));
		}
		if("".equals(pre_mmti0259vo.getInpt_trv_dstc()) || null == pre_mmti0259vo.getInpt_trv_dstc()){
			mbtt02001vo.setInptTrvDstc(0);
		} else {
			mbtt02001vo.setInptTrvDstc(Double.parseDouble(pre_mmti0259vo.getInpt_trv_dstc()));
		}
		if("".equals(pre_mmti0259vo.getCnv_trv_dstc()) || null == pre_mmti0259vo.getCnv_trv_dstc()){
			mbtt02001vo.setCnvTrvDstc(0);
		} else {
			mbtt02001vo.setCnvTrvDstc(Double.parseDouble(pre_mmti0259vo.getCnv_trv_dstc()));
		}
		if("".equals(pre_mmti0259vo.getExp_exca_plan_rsl_cd()) || null == pre_mmti0259vo.getExp_exca_plan_rsl_cd()){
			mbtt02001vo.setExpExcaPlanRslCd(" ");
		} else {
			mbtt02001vo.setExpExcaPlanRslCd(StringUtil.nvl(pre_mmti0259vo.getExp_exca_plan_rsl_cd()));
		}
		if("".equals(request.getParameter("exca_bz_proc_dvn")) || null == request.getParameter("exca_bz_proc_dvn")){
			mbtt02001vo.setExcaBzProcDvn(" ");
		} else {
			mbtt02001vo.setExcaBzProcDvn(StringUtil.nvl(request.getParameter("exca_bz_proc_dvn")));
		}
		if("".equals(request.getParameter("exca_rtrn_dvn")) || null == request.getParameter("exca_rtrn_dvn")){
			mbtt02001vo.setExcaRtrnDvn(" ");
		} else {
			mbtt02001vo.setExcaRtrnDvn(StringUtil.nvl(request.getParameter("exca_rtrn_dvn")));
		}
		if("".equals(pre_mmti0259vo.getPdc_sr_dvn()) || null == pre_mmti0259vo.getPdc_sr_dvn()){
			mbtt02001vo.setPdcSrDvn(" ");
		} else {
			mbtt02001vo.setPdcSrDvn(StringUtil.nvl(pre_mmti0259vo.getPdc_sr_dvn()));
		}
		if("".equals(pre_mmti0259vo.getAdc_rtrn_prm()) || null == pre_mmti0259vo.getAdc_rtrn_prm()){
			mbtt02001vo.setAdcRtrnPrm(0);
		} else {
			mbtt02001vo.setAdcRtrnPrm(Double.parseDouble(pre_mmti0259vo.getAdc_rtrn_prm()));
		}
		if("".equals(request.getParameter("trv_dstc_splc_exca_yn")) || null == request.getParameter("trv_dstc_splc_exca_yn")){
			mbtt02001vo.setTrvDstcSplcExcaYn(" ");
		} else {
			mbtt02001vo.setTrvDstcSplcExcaYn(StringUtil.nvl(request.getParameter("trv_dstc_splc_exca_yn")));
		}
		if("".equals(request.getParameter("imag_dup_yn")) || null == request.getParameter("imag_dup_yn")){
			mbtt02001vo.setImagDupYn(" ");
		} else {
			mbtt02001vo.setImagDupYn(StringUtil.nvl(request.getParameter("imag_dup_yn")));
		}
		if("".equals(request.getParameter("nrm_proc_yn")) || null == request.getParameter("nrm_proc_yn")){
			mbtt02001vo.setNrmProcYn(" ");
		} else {
			mbtt02001vo.setNrmProcYn(StringUtil.nvl(request.getParameter("nrm_proc_yn")));
		}
		if("".equals(request.getParameter("crd_scn_cncl_pss_yn")) || null == request.getParameter("crd_scn_cncl_pss_yn")){
			mbtt02001vo.setCrdScnCnclPssYn(" ");
		} else {
			mbtt02001vo.setCrdScnCnclPssYn(StringUtil.nvl(request.getParameter("crd_scn_cncl_pss_yn")));
		}
		mbtt02001vo.setRespCn(StringUtil.nvl(pre_mmti0259vo.getZ_resp_cd()));
		mbtt02001vo.setRslCn(scrnNm + "_" + StringUtil.nvl(pre_mmti0259vo.getZ_resp_msg()));
		mbtt02001vo.setFrstIpmnEmpno("82101685");
		mbtt02001vo.setFnalAmdrEmpno("82101685");
		
		if("".equals(pre_mmti0259vo.getAdc_rtrn_dvn()) || null == pre_mmti0259vo.getAdc_rtrn_dvn()){
			mbtt02001vo.setAdcRtrnDvn(" ");
		} else {
			mbtt02001vo.setAdcRtrnDvn(StringUtil.nvl(pre_mmti0259vo.getAdc_rtrn_dvn()));
		}
		if("".equals(request.getParameter("scrn_proc_cd")) || null == request.getParameter("scrn_proc_cd")){
			mbtt02001vo.setScrnProcCd(" ");
		} else {
			mbtt02001vo.setScrnProcCd(StringUtil.nvl(request.getParameter("scrn_proc_cd")));
		}
		if("".equals(request.getParameter("ctc_plno")) || null == request.getParameter("ctc_plno")){
			mbtt02001vo.setCtcPlno(" ");
		} else {
			mbtt02001vo.setCtcPlno(StringUtil.nvl(request.getParameter("ctc_plno")));
		}
		if("".equals(request.getParameter("trv_dstc_proc_dvcd")) || null == request.getParameter("trv_dstc_proc_dvcd")){
			mbtt02001vo.setTrvDstcProcDvcd(" ");
		} else {
			mbtt02001vo.setTrvDstcProcDvcd(StringUtil.nvl(request.getParameter("trv_dstc_proc_dvcd")));
		}
		if("".equals(request.getParameter("mbl_snd_no")) || null == request.getParameter("mbl_snd_no")){
			mbtt02001vo.setMblSndNo(" ");
		} else {
			mbtt02001vo.setMblSndNo(StringUtil.nvl(request.getParameter("mbl_snd_no")));
		}
		if("".equals(request.getParameter("plan_plno_dvcd")) || null == request.getParameter("plan_plno_dvcd")){
			mbtt02001vo.setPlanPlnoDvcd(" ");
		} else {
			mbtt02001vo.setPlanPlnoDvcd(StringUtil.nvl(request.getParameter("plan_plno_dvcd")));
		}
		if("".equals(request.getParameter("plan_plno")) || null == request.getParameter("plan_plno")){
			mbtt02001vo.setPlanPlno(" ");
		} else {
			mbtt02001vo.setPlanPlno(StringUtil.nvl(request.getParameter("plan_plno")));
		}
		if("".equals(request.getParameter("chng_plan_no")) || null == request.getParameter("chng_plan_no")){
			mbtt02001vo.setChngPlanNo(" ");
		} else {
			mbtt02001vo.setChngPlanNo(StringUtil.nvl(request.getParameter("chng_plan_no")));
		}
		if("".equals(request.getParameter("dst_tty_dvn1")) || null == request.getParameter("dst_tty_dvn1")){
			mbtt02001vo.setDstTtyDvn1(" ");
		} else {
			mbtt02001vo.setDstTtyDvn1(StringUtil.nvl(request.getParameter("dst_tty_dvn1")));
		}
		if("".equals(request.getParameter("dst_tty_dvn2")) || null == request.getParameter("dst_tty_dvn2")){
			mbtt02001vo.setDstTtyDvn2(" ");
		} else {
			mbtt02001vo.setDstTtyDvn2(StringUtil.nvl(request.getParameter("dst_tty_dvn2")));
		}
		if("".equals(request.getParameter("dst_tty_dvn3")) || null == request.getParameter("dst_tty_dvn3")){
			mbtt02001vo.setDstTtyDvn3(" ");
		} else {
			mbtt02001vo.setDstTtyDvn3(StringUtil.nvl(request.getParameter("dst_tty_dvn3")));
		}
		if("".equals(request.getParameter("dst_tty_dvn4")) || null == request.getParameter("dst_tty_dvn4")){
			mbtt02001vo.setDstTtyDvn4(" ");
		} else {
			mbtt02001vo.setDstTtyDvn4(StringUtil.nvl(request.getParameter("dst_tty_dvn4")));
		}
		if("".equals(request.getParameter("dst_tty_dvn5")) || null == request.getParameter("dst_tty_dvn5")){
			mbtt02001vo.setDstTtyDvn5(" ");
		} else {
			mbtt02001vo.setDstTtyDvn5(StringUtil.nvl(request.getParameter("dst_tty_dvn5")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt1")) || null == request.getParameter("phgp_regt_tgt1")){
			mbtt02001vo.setPhgpRegtTgt1(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt1(StringUtil.nvl(request.getParameter("phgp_regt_tgt1")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt2")) || null == request.getParameter("phgp_regt_tgt2")){
			mbtt02001vo.setPhgpRegtTgt2(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt2(StringUtil.nvl(request.getParameter("phgp_regt_tgt2")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt3")) || null == request.getParameter("phgp_regt_tgt3")){
			mbtt02001vo.setPhgpRegtTgt3(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt3(StringUtil.nvl(request.getParameter("phgp_regt_tgt3")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt4")) || null == request.getParameter("phgp_regt_tgt4")){
			mbtt02001vo.setPhgpRegtTgt4(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt4(StringUtil.nvl(request.getParameter("phgp_regt_tgt4")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt5")) || null == request.getParameter("phgp_regt_tgt5")){
			mbtt02001vo.setPhgpRegtTgt5(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt5(StringUtil.nvl(request.getParameter("phgp_regt_tgt5")));
		}
		
		//MMTI0259 insert
		insertRow = 0;
		
		logger.info("#### upMileageStep7B2 MMTI0259 MBTT02001 before ####");
		insertRow = mileageTobeService.insertJungsanTest(mbtt02001vo);
		logger.info("#### upMileageStep7B2 MMTI0259 MBTT02001 after ####");
		
		if(insertRow < 1){
			logger.info("#### 사서함번호: " + StringUtil.nvl(mbtt02001vo.getPboxNo()) + "####");
			logger.info("#### insert 결과: Fail ####");
		}else{
			logger.info("#### insert 결과: Success ####");
		}
		
		mmti0291vo.setTrv_dstc_exca_mtt__exca_bz_proc_dvn("2");													// 정산업무처리구분 2:확정
		mmti0291vo.setTrv_dstc_exca_mtt__plno(pre_mmti0259vo.getPlno());										// 증권번호
		mmti0291vo.setTrv_dstc_exca_mtt__plan_no(pre_mmti0259vo.getExp_exca_plan_no());							// 설계번호
		mmti0291vo.setTrv_dstc_exca_mtt__exca_rtrn_dvn("2");													// 갱신환급구분 2:갱신계약활용
		mmti0291vo.setTrv_dstc_exca_mtt__pdc_sr_dvn(pre_mmti0259vo.getPdc_sr_dvn());							// 상품출처구분
		mmti0291vo.setTrv_dstc_exca_mtt__scrn_proc_cd(pre_mmti0259vo.getExp_exca_plan_rsl_cd());				// 화면처리코드
		mmti0291vo.setTrv_dstc_exca_mtt__adc_rtrn_dvn(pre_mmti0259vo.getAdc_rtrn_dvn());						// 추징환급구분
		mmti0291vo.setTrv_dstc_exca_mtt__adc_rtrn_prm(pre_mmti0259vo.getAdc_rtrn_prm());						// 추징환급보험료
		mmti0291vo.setTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn(pre_mmti0213vo.getTrv_dstc_splc_exca_yn());		// 주행거리간편정산여부
		mmti0291vo.setTrv_dstc_exca_mtt__pbox_no(pre_mmti0213vo.getSms_ts_bvan());								// 사서함번호
		mmti0291vo = mileageTobeService.getMMTI0291VO(mmti0291vo);
		
		// 미환급대체 완료화면 CM상품 분기용
		session.setAttribute("sr_dvn", mmti0291vo.getTrv_dstc_exca_mtt__pdc_sr_dvn());
		
		// 부적정/중복 이미지인 경우 화면처리코드 02 
		if("1".equals(mmti0291vo.getTrv_dstc_exca_mtt__imag_dup_yn())){
			mmti0291vo.setTrv_dstc_exca_mtt__scrn_proc_cd("02");
		}
		session.setAttribute("mmti0291vo", mmti0291vo);
		
		// CM 상품이고, 화면처리코드 IN(02, 14) or 이미지 중복
		
		if("CM".equals(mmti0291vo.getTrv_dstc_exca_mtt__pdc_sr_dvn()) && 
				("02".equals(mmti0291vo.getTrv_dstc_exca_mtt__scrn_proc_cd())
				|| "14".equals(mmti0291vo.getTrv_dstc_exca_mtt__scrn_proc_cd()))){
			
			MMTI0015VO mmti0015vo = new MMTI0015VO();
			mmti0015vo.setFunt_key("00");
			mmti0015vo.setPlan_no(mmti0291vo.getTrv_dstc_exca_mtt__plan_no());
			mmti0015vo = mileageTobeService.getMMTI0015VO(mmti0015vo);
			
			logger.debug("##### MMTI0015 시작 ##########################");
			logger.debug("##### 고객식별번호: " + mmti0015vo.getPlhd__cust_dcmt_no() + " ##########################");
			logger.debug("##### 고객번호: " + mmti0015vo.getPlhd__cust_no() + " ##########################");
			logger.debug("##### 고객명: " + mmti0015vo.getPlhd__cust_nm() + " ##########################");
			logger.debug("##### 이메일: " + mmti0015vo.getPlhd__eml() + " ##########################");
			logger.debug("##### 지역번호: " + mmti0015vo.getPlhd_cntp_if__tlp_arno() + " ##########################");
			logger.debug("##### 국번호: " + mmti0015vo.getPlhd_cntp_if__tlp_ofno() + " ##########################");
			logger.debug("##### 개별번호: " + mmti0015vo.getPlhd_cntp_if__tlp_idvno() + " ##########################");
			
			XTEM0021VO xtem0021vo = new XTEM0021VO();
			xtem0021vo.setCnsl_rpt_no("");						// 상담접수번호				
			xtem0021vo.setCm_bz_dvcd("05");
			xtem0021vo.setCnsl_typ_dvcd("07");
			xtem0021vo.setCm_plan_no(mmti0291vo.getTrv_dstc_exca_mtt__plan_no());
			xtem0021vo.setCnsl_rpy_dvcd("1");
			xtem0021vo.setCnsl_rpt_dttm(getDayTime());			// 현재년월일시분초 14자리
			xtem0021vo.setCust_nm(mmti0015vo.getPlhd__cust_nm());
			xtem0021vo.setCust_no(mmti0015vo.getPlhd__cust_no());
			
			String cust_dcmt_no = SeedUtil.decrypt(mmti0015vo.getPlhd__cust_dcmt_no());
			
			if("1".equals(cust_dcmt_no.substring(6, 7)) || "2".equals(cust_dcmt_no.substring(6, 7))
				|| "5".equals(cust_dcmt_no.substring(6, 7)) || "6".equals(cust_dcmt_no.substring(6, 7))){
				xtem0021vo.setBrth("19" + cust_dcmt_no.substring(0, 6));
			} else{
				xtem0021vo.setBrth("20" + cust_dcmt_no.substring(0, 6));
			}
			xtem0021vo.setSx_cd(cust_dcmt_no.substring(6, 7));
			xtem0021vo.setEml_adr(mmti0015vo.getPlhd__eml());
			xtem0021vo.setClp_tlcno(mmti0015vo.getPlhd_cntp_if__tlp_arno());
			xtem0021vo.setClp_ofno(mmti0015vo.getPlhd_cntp_if__tlp_ofno());
			xtem0021vo.setClp_idvno(mmti0015vo.getPlhd_cntp_if__tlp_idvno());
			xtem0021vo.setCnsl_rsvt_dt("99990101");
			xtem0021vo.setCnsl_rsvt_time_cd("1");
			xtem0021vo.setCnsl_cn("최종주행거리사진등록/만기정산");
			xtem0021vo.setCnsl_aply_csn_yn("1");
			xtem0021vo.setUrl_adr("");
			xtem0021vo.setCm_ctrmf_tpcd("32");
			xtem0021vo.setFrst_ipmn_empno("80000028");
			xtem0021vo.setFrst_ipnpt_dttm(getDayTime());		// 현재년월일시분초 14자리	
			
			xtem0021vo = mileageTobeService.getXTEM0021VO(xtem0021vo);
			logger.debug("##### XTEM0021 시작 ##########################");
			logger.debug("##### 처리결과: [ " + xtem0021vo.getProc_rtn() + " ] ##########################");
		}
		
		//MMTI0291전문 정산이력테이블(MBTT02001) 적재
		mbtt02001vo.setPboxNo(StringUtil.nvl(pre_mmti0213vo.getSms_ts_bvan()));
		mbtt02001vo.setTlgIdVal("MMTI0291");
		mbtt02001vo.setEsbTrscId(StringUtil.nvl(mmti0291vo.getZ_trsc_id()));
		if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__plno()) || null == mmti0291vo.getTrv_dstc_exca_mtt__plno()){
			mbtt02001vo.setPlno(" ");
		} else {
			mbtt02001vo.setPlno(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__plno()));
		}
		if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__plan_no()) || null == mmti0291vo.getTrv_dstc_exca_mtt__plan_no()){
			mbtt02001vo.setPlanNo(" ");
		} else {
			mbtt02001vo.setPlanNo(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__plan_no()));
		}
		if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__rnw_plno()) || null == mmti0291vo.getTrv_dstc_exca_mtt__rnw_plno()){
			mbtt02001vo.setRnwPlno(" ");
		} else {
			mbtt02001vo.setRnwPlno(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__rnw_plno()));
		}
		mbtt02001vo.setTlgProcRslCdVal(StringUtil.nvl(mmti0291vo.getZ_tlg_sp_cd()));
		mbtt02001vo.setTlgErrCdVal(StringUtil.nvl(mmti0291vo.getZ_trns_org_dvcd())+StringUtil.nvl(mmti0291vo.getZ_trns_org_cd()));
		if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__hdlr_empno()) || null == mmti0291vo.getTrv_dstc_exca_mtt__hdlr_empno()){
			mbtt02001vo.setHdlrEmpno(" ");
		} else {
			mbtt02001vo.setHdlrEmpno(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__hdlr_empno()));
		}
		if("".equals(request.getParameter("pbox_no_dvcd")) || null == request.getParameter("pbox_no_dvcd")){
			mbtt02001vo.setPboxNoDvcd(" ");
		} else {
			mbtt02001vo.setPboxNoDvcd(StringUtil.nvl(request.getParameter("pbox_no_dvcd")));
		}
		if("".equals(request.getParameter("proc_dvn")) || null == request.getParameter("proc_dvn")){
			mbtt02001vo.setProcDvn(" ");
		} else {
			mbtt02001vo.setProcDvn(StringUtil.nvl(request.getParameter("proc_dvn")));
		}
		if("".equals(request.getParameter("trv_dstc_exp_exca_dvcd")) || null == request.getParameter("trv_dstc_exp_exca_dvcd")){
			mbtt02001vo.setTrvDstcExpExcaDvcd(" ");
		} else {
			mbtt02001vo.setTrvDstcExpExcaDvcd(StringUtil.nvl(request.getParameter("trv_dstc_exp_exca_dvcd")));
		}
		if("".equals(request.getParameter("trv_dstc_chng_aply_dvn")) || null == request.getParameter("trv_dstc_chng_aply_dvn")){
			mbtt02001vo.setTrvDstcChngAplyDvn(" ");
		} else {
			mbtt02001vo.setTrvDstcChngAplyDvn(StringUtil.nvl(request.getParameter("trv_dstc_chng_aply_dvn")));
		}
		if("".equals(request.getParameter("hdlr_fire_yn")) || null == request.getParameter("hdlr_fire_yn")){
			mbtt02001vo.setHdlrFireYn(" ");
		} else {
			mbtt02001vo.setHdlrFireYn(StringUtil.nvl(request.getParameter("hdlr_fire_yn")));
		}
		if("".equals(request.getParameter("mtcc_yn")) || null == request.getParameter("mtcc_yn")){
			mbtt02001vo.setMtccYn(" ");
		} else {
			mbtt02001vo.setMtccYn(StringUtil.nvl(request.getParameter("mtcc_yn")));
		}
		if("".equals(request.getParameter("aut_cgnt_trv_dstc")) || null == request.getParameter("aut_cgnt_trv_dstc")){
			mbtt02001vo.setAutCgntTrvDstc(0);
		} else {
			mbtt02001vo.setAutCgntTrvDstc(Double.parseDouble(request.getParameter("aut_cgnt_trv_dstc")));
		}
		if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__aut_cgnt_trv_dstc_rsl_cd()) || null == mmti0291vo.getTrv_dstc_exca_mtt__aut_cgnt_trv_dstc_rsl_cd()){
			mbtt02001vo.setAutCgntTrvDstcRslCd(" ");
		} else {
			mbtt02001vo.setAutCgntTrvDstcRslCd(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__aut_cgnt_trv_dstc_rsl_cd()));
		}
		if("".equals(request.getParameter("inptTrvDstc")) || null == request.getParameter("inptTrvDstc")){
			mbtt02001vo.setInptTrvDstc(0);
		} else {
			mbtt02001vo.setInptTrvDstc(Double.parseDouble(request.getParameter("inptTrvDstc")));
		}
		if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__cnv_trv_dstc()) || null == mmti0291vo.getTrv_dstc_exca_mtt__cnv_trv_dstc()){
			mbtt02001vo.setCnvTrvDstc(0);
		} else {
			mbtt02001vo.setCnvTrvDstc(Double.parseDouble(mmti0291vo.getTrv_dstc_exca_mtt__cnv_trv_dstc()));
		}
		if("".equals(request.getParameter("exp_exca_plan_rsl_cd")) || null == request.getParameter("exp_exca_plan_rsl_cd")){
			mbtt02001vo.setExpExcaPlanRslCd(" ");
		} else {
			mbtt02001vo.setExpExcaPlanRslCd(StringUtil.nvl(request.getParameter("exp_exca_plan_rsl_cd")));
		}
		if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__exca_bz_proc_dvn()) || null == mmti0291vo.getTrv_dstc_exca_mtt__exca_bz_proc_dvn()){
			mbtt02001vo.setExcaBzProcDvn(" ");
		} else {
			mbtt02001vo.setExcaBzProcDvn(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__exca_bz_proc_dvn()));
		}
		if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__exca_rtrn_dvn()) || null == mmti0291vo.getTrv_dstc_exca_mtt__exca_rtrn_dvn()){
			mbtt02001vo.setExcaRtrnDvn(" ");
		} else {
			mbtt02001vo.setExcaRtrnDvn(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__exca_rtrn_dvn()));
		}
		if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__pdc_sr_dvn()) || null == mmti0291vo.getTrv_dstc_exca_mtt__pdc_sr_dvn()){
			mbtt02001vo.setPdcSrDvn(" ");
		} else {
			mbtt02001vo.setPdcSrDvn(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__pdc_sr_dvn()));
		}
		if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__adc_rtrn_prm()) || null == mmti0291vo.getTrv_dstc_exca_mtt__adc_rtrn_prm()){
			mbtt02001vo.setAdcRtrnPrm(0);
		} else {
			mbtt02001vo.setAdcRtrnPrm(Double.parseDouble(mmti0291vo.getTrv_dstc_exca_mtt__adc_rtrn_prm()));
		}
		if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn()) || null == mmti0291vo.getTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn()){
			mbtt02001vo.setTrvDstcSplcExcaYn(" ");
		} else {
			mbtt02001vo.setTrvDstcSplcExcaYn(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn()));
		}
		if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__imag_dup_yn()) || null == mmti0291vo.getTrv_dstc_exca_mtt__imag_dup_yn()){
			mbtt02001vo.setImagDupYn(" ");
		} else {
			mbtt02001vo.setImagDupYn(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__imag_dup_yn()));
		}
		if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__nrm_proc_yn()) || null == mmti0291vo.getTrv_dstc_exca_mtt__nrm_proc_yn()){
			mbtt02001vo.setNrmProcYn(" ");
		} else {
			mbtt02001vo.setNrmProcYn(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__nrm_proc_yn()));
		}
		if("".equals(request.getParameter("crdScnCnclPssYn")) || null == request.getParameter("crdScnCnclPssYn")){
			mbtt02001vo.setCrdScnCnclPssYn(" ");
		} else {
			mbtt02001vo.setCrdScnCnclPssYn(StringUtil.nvl(request.getParameter("crdScnCnclPssYn")));
		}
		mbtt02001vo.setRespCn(StringUtil.nvl(mmti0291vo.getZ_resp_cd()));
		mbtt02001vo.setRslCn(scrnNm + "_" + StringUtil.nvl(mmti0291vo.getZ_resp_msg()));
		mbtt02001vo.setFrstIpmnEmpno("82101685");
		mbtt02001vo.setFnalAmdrEmpno("82101685");
		if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__adc_rtrn_dvn()) || null == mmti0291vo.getTrv_dstc_exca_mtt__adc_rtrn_dvn()){
			mbtt02001vo.setAdcRtrnDvn(" ");
		} else {
			mbtt02001vo.setAdcRtrnDvn(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__adc_rtrn_dvn()));
		}
		if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__scrn_proc_cd()) || null == mmti0291vo.getTrv_dstc_exca_mtt__scrn_proc_cd()){
			mbtt02001vo.setScrnProcCd(" ");
		} else {
			mbtt02001vo.setScrnProcCd(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__scrn_proc_cd()));
		}
		if("".equals(request.getParameter("ctc_plno")) || null == request.getParameter("ctc_plno")){
			mbtt02001vo.setCtcPlno(" ");
		} else {
			mbtt02001vo.setCtcPlno(StringUtil.nvl(request.getParameter("ctc_plno")));
		}
		if("".equals(request.getParameter("trv_dstc_proc_dvcd")) || null == request.getParameter("trv_dstc_proc_dvcd")){
			mbtt02001vo.setTrvDstcProcDvcd(" ");
		} else {
			mbtt02001vo.setTrvDstcProcDvcd(StringUtil.nvl(request.getParameter("trv_dstc_proc_dvcd")));
		}
		if("".equals(request.getParameter("mbl_snd_no")) || null == request.getParameter("mbl_snd_no")){
			mbtt02001vo.setMblSndNo(" ");
		} else {
			mbtt02001vo.setMblSndNo(StringUtil.nvl(request.getParameter("mbl_snd_no")));
		}
		if("".equals(request.getParameter("plan_plno_dvcd")) || null == request.getParameter("plan_plno_dvcd")){
			mbtt02001vo.setPlanPlnoDvcd(" ");
		} else {
			mbtt02001vo.setPlanPlnoDvcd(StringUtil.nvl(request.getParameter("plan_plno_dvcd")));
		}
		if("".equals(request.getParameter("plan_plno")) || null == request.getParameter("plan_plno")){
			mbtt02001vo.setPlanPlno(" ");
		} else {
			mbtt02001vo.setPlanPlno(StringUtil.nvl(request.getParameter("plan_plno")));
		}
		if("".equals(request.getParameter("chng_plan_no")) || null == request.getParameter("chng_plan_no")){
			mbtt02001vo.setChngPlanNo(" ");
		} else {
			mbtt02001vo.setChngPlanNo(StringUtil.nvl(request.getParameter("chng_plan_no")));
		}
		if("".equals(request.getParameter("dst_tty_dvn1")) || null == request.getParameter("dst_tty_dvn1")){
			mbtt02001vo.setDstTtyDvn1(" ");
		} else {
			mbtt02001vo.setDstTtyDvn1(StringUtil.nvl(request.getParameter("dst_tty_dvn1")));
		}
		if("".equals(request.getParameter("dst_tty_dvn2")) || null == request.getParameter("dst_tty_dvn2")){
			mbtt02001vo.setDstTtyDvn2(" ");
		} else {
			mbtt02001vo.setDstTtyDvn2(StringUtil.nvl(request.getParameter("dst_tty_dvn2")));
		}
		if("".equals(request.getParameter("dst_tty_dvn3")) || null == request.getParameter("dst_tty_dvn3")){
			mbtt02001vo.setDstTtyDvn3(" ");
		} else {
			mbtt02001vo.setDstTtyDvn3(StringUtil.nvl(request.getParameter("dst_tty_dvn3")));
		}
		if("".equals(request.getParameter("dst_tty_dvn4")) || null == request.getParameter("dst_tty_dvn4")){
			mbtt02001vo.setDstTtyDvn4(" ");
		} else {
			mbtt02001vo.setDstTtyDvn4(StringUtil.nvl(request.getParameter("dst_tty_dvn4")));
		}
		if("".equals(request.getParameter("dst_tty_dvn5")) || null == request.getParameter("dst_tty_dvn5")){
			mbtt02001vo.setDstTtyDvn5(" ");
		} else {
			mbtt02001vo.setDstTtyDvn5(StringUtil.nvl(request.getParameter("dst_tty_dvn5")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt1")) || null == request.getParameter("phgp_regt_tgt1")){
			mbtt02001vo.setPhgpRegtTgt1(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt1(StringUtil.nvl(request.getParameter("phgp_regt_tgt1")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt2")) || null == request.getParameter("phgp_regt_tgt2")){
			mbtt02001vo.setPhgpRegtTgt2(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt2(StringUtil.nvl(request.getParameter("phgp_regt_tgt2")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt3")) || null == request.getParameter("phgp_regt_tgt3")){
			mbtt02001vo.setPhgpRegtTgt3(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt3(StringUtil.nvl(request.getParameter("phgp_regt_tgt3")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt4")) || null == request.getParameter("phgp_regt_tgt4")){
			mbtt02001vo.setPhgpRegtTgt4(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt4(StringUtil.nvl(request.getParameter("phgp_regt_tgt4")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt5")) || null == request.getParameter("phgp_regt_tgt5")){
			mbtt02001vo.setPhgpRegtTgt5(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt5(StringUtil.nvl(request.getParameter("phgp_regt_tgt5")));
		}
		
		//MMTI0291 insert
		insertRow = 0;
		
		logger.info("#### upMileageStep7B2 MMTI0291 MBTT02001 before ####");
		insertRow = mileageTobeService.insertJungsanTest(mbtt02001vo);
		logger.info("#### upMileageStep7B2 MMTI0291 MBTT02001 after ####");
		
		if(insertRow < 1){
			logger.info("#### 사서함번호: " + StringUtil.nvl(mbtt02001vo.getPboxNo()) + "####");
			logger.info("#### insert 결과: Fail ####");
		}else{
			logger.info("#### insert 결과: Success ####");
		}
		
		MMTI0217VO mmti0217vo = new MMTI0217VO();
		
		if(session.getAttribute("p") != null) {
			mmti0217vo.setMbl_snd_no((String) session.getAttribute("p"));
		}
		else {
			mmti0217vo.setMbl_snd_no(aes256Decrypt(StringUtil.nvl(request.getParameter("p"))));
		}
		mmti0217vo = mileageTobeService.getMMTI0217VO(mmti0217vo);
		
		MMTI0218VO jmvo0218 = new MMTI0218VO();
		
		jmvo0218.setMbl_snd_no(mmti0217vo.getMbl_snd_no());
		jmvo0218.setPlan_plno_dvcd(mmti0217vo.getPlan_plno_dvcd());
		jmvo0218.setPlan_plno(mmti0217vo.getPlan_plno());
		jmvo0218.setChng_plan_no(mmti0217vo.getChng_plan_no());
		
		jmvo0218 = mileageTobeService.getMMTI0218VO(jmvo0218);
		int count = 0;
		for(int i = 0; i < jmvo0218.getPhgp_regt_tgt__dst_tty_dvn().length; i++) {
			if("Y".equals(jmvo0218.getPhgp_regt_tgt__phgp_regt_cplt_yn()[i]) || "1".equals(jmvo0218.getPhgp_regt_tgt__phgp_regt_cplt_yn()[i])) count++;
		}
		
		//MMTI0218전문 정산이력테이블(MBTT02001) 적재
		mbtt02001vo.setPboxNo(StringUtil.nvl(pre_mmti0213vo.getSms_ts_bvan()));
		mbtt02001vo.setTlgIdVal("MMTI0218");
		mbtt02001vo.setEsbTrscId(StringUtil.nvl(jmvo0218.getZ_trsc_id()));
		if("".equals(request.getParameter("plno")) || null == request.getParameter("plno")){
			mbtt02001vo.setPlno(" ");
		} else {
			mbtt02001vo.setPlno(StringUtil.nvl(request.getParameter("plno")));
		}
		if("".equals(request.getParameter("plan_no")) || null == request.getParameter("plan_no")){
			mbtt02001vo.setPlanNo(" ");
		} else {
			mbtt02001vo.setPlanNo(StringUtil.nvl(request.getParameter("plan_no")));
		}
		if("".equals(request.getParameter("rnw_plno")) || null == request.getParameter("rnw_plno")){
			mbtt02001vo.setRnwPlno(" ");
		} else {
			mbtt02001vo.setRnwPlno(StringUtil.nvl(request.getParameter("rnw_plno")));
		}
		mbtt02001vo.setTlgProcRslCdVal(StringUtil.nvl(jmvo0218.getZ_tlg_sp_cd()));
		mbtt02001vo.setTlgErrCdVal(StringUtil.nvl(jmvo0218.getZ_trns_org_dvcd())+StringUtil.nvl(jmvo0218.getZ_trns_org_cd()));
		if("".equals(request.getParameter("hdlr_empno")) || null == request.getParameter("hdlr_empno")){
			mbtt02001vo.setHdlrEmpno(" ");
		} else {
			mbtt02001vo.setHdlrEmpno(StringUtil.nvl(request.getParameter("hdlr_empno")));
		}
		if("".equals(request.getParameter("pbox_no_dvcd")) || null == request.getParameter("pbox_no_dvcd")){
			mbtt02001vo.setPboxNoDvcd(" ");
		} else {
			mbtt02001vo.setPboxNoDvcd(StringUtil.nvl(request.getParameter("pbox_no_dvcd")));
		}
		if("".equals(request.getParameter("proc_dvn")) || null == request.getParameter("proc_dvn")){
			mbtt02001vo.setProcDvn(" ");
		} else {
			mbtt02001vo.setProcDvn(StringUtil.nvl(request.getParameter("proc_dvn")));
		}
		if("".equals(request.getParameter("trv_dstc_exp_exca_dvcd")) || null == request.getParameter("trv_dstc_exp_exca_dvcd")){
			mbtt02001vo.setTrvDstcExpExcaDvcd(" ");
		} else {
			mbtt02001vo.setTrvDstcExpExcaDvcd(StringUtil.nvl(request.getParameter("trv_dstc_exp_exca_dvcd")));
		}
		if("".equals(request.getParameter("trv_dstc_chng_aply_dvn")) || null == request.getParameter("trv_dstc_chng_aply_dvn")){
			mbtt02001vo.setTrvDstcChngAplyDvn(" ");
		} else {
			mbtt02001vo.setTrvDstcChngAplyDvn(StringUtil.nvl(request.getParameter("trv_dstc_chng_aply_dvn")));
		}
		if("".equals(request.getParameter("hdlr_fire_yn")) || null == request.getParameter("hdlr_fire_yn")){
			mbtt02001vo.setHdlrFireYn(" ");
		} else {
			mbtt02001vo.setHdlrFireYn(StringUtil.nvl(request.getParameter("hdlr_fire_yn")));
		}
		if("".equals(request.getParameter("mtcc_yn")) || null == request.getParameter("mtcc_yn")){
			mbtt02001vo.setMtccYn(" ");
		} else {
			mbtt02001vo.setMtccYn(StringUtil.nvl(request.getParameter("mtcc_yn")));
		}
		if("".equals(request.getParameter("aut_cgnt_trv_dstc")) || null == request.getParameter("aut_cgnt_trv_dstc")){
			mbtt02001vo.setAutCgntTrvDstc(0);
		} else {
			mbtt02001vo.setAutCgntTrvDstc(Double.parseDouble(request.getParameter("aut_cgnt_trv_dstc")));
		}
		if("".equals(request.getParameter("aut_cgnt_trv_dstc_rsl_cd")) || null == request.getParameter("aut_cgnt_trv_dstc_rsl_cd")){
			mbtt02001vo.setAutCgntTrvDstcRslCd(" ");
		} else {
			mbtt02001vo.setAutCgntTrvDstcRslCd(StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc_rsl_cd")));
		}
		if("".equals(request.getParameter("inptTrvDstc")) || null == request.getParameter("inptTrvDstc")){
			mbtt02001vo.setInptTrvDstc(0);
		} else {
			mbtt02001vo.setInptTrvDstc(Double.parseDouble(request.getParameter("inptTrvDstc")));
		}
		if("".equals(request.getParameter("cnv_trv_dstc")) || null == request.getParameter("cnv_trv_dstc")){
			mbtt02001vo.setCnvTrvDstc(0);
		} else {
			mbtt02001vo.setCnvTrvDstc(Double.parseDouble(request.getParameter("cnv_trv_dstc")));
		}
		if("".equals(request.getParameter("exp_exca_plan_rsl_cd")) || null == request.getParameter("exp_exca_plan_rsl_cd")){
			mbtt02001vo.setExpExcaPlanRslCd(" ");
		} else {
			mbtt02001vo.setExpExcaPlanRslCd(StringUtil.nvl(request.getParameter("exp_exca_plan_rsl_cd")));
		}
		if("".equals(request.getParameter("exca_bz_proc_dvn")) || null == request.getParameter("exca_bz_proc_dvn")){
			mbtt02001vo.setExcaBzProcDvn(" ");
		} else {
			mbtt02001vo.setExcaBzProcDvn(StringUtil.nvl(request.getParameter("exca_bz_proc_dvn")));
		}
		if("".equals(request.getParameter("exca_rtrn_dvn")) || null == request.getParameter("exca_rtrn_dvn")){
			mbtt02001vo.setExcaRtrnDvn(" ");
		} else {
			mbtt02001vo.setExcaRtrnDvn(StringUtil.nvl(request.getParameter("exca_rtrn_dvn")));
		}
		if("".equals(request.getParameter("pdc_sr_dvn")) || null == request.getParameter("pdc_sr_dvn")){
			mbtt02001vo.setPdcSrDvn(" ");
		} else {
			mbtt02001vo.setPdcSrDvn(StringUtil.nvl(request.getParameter("pdc_sr_dvn")));
		}
		if("".equals(request.getParameter("adc_rtrn_prm")) || null == request.getParameter("adc_rtrn_prm")){
			mbtt02001vo.setAdcRtrnPrm(0);
		} else {
			mbtt02001vo.setAdcRtrnPrm(Double.parseDouble(request.getParameter("adc_rtrn_prm")));
		}
		if("".equals(request.getParameter("trv_dstc_splc_exca_yn")) || null == request.getParameter("trv_dstc_splc_exca_yn")){
			mbtt02001vo.setTrvDstcSplcExcaYn(" ");
		} else {
			mbtt02001vo.setTrvDstcSplcExcaYn(StringUtil.nvl(request.getParameter("trv_dstc_splc_exca_yn")));
		}
		if("".equals(request.getParameter("imag_dup_yn")) || null == request.getParameter("imag_dup_yn")){
			mbtt02001vo.setImagDupYn(" ");
		} else {
			mbtt02001vo.setImagDupYn(StringUtil.nvl(request.getParameter("imag_dup_yn")));
		}
		if("".equals(request.getParameter("nrm_proc_yn")) || null == request.getParameter("nrm_proc_yn")){
			mbtt02001vo.setNrmProcYn(" ");
		} else {
			mbtt02001vo.setNrmProcYn(StringUtil.nvl(request.getParameter("nrm_proc_yn")));
		}
		if("".equals(request.getParameter("crd_scn_cncl_pss_yn")) || null == request.getParameter("crd_scn_cncl_pss_yn")){
			mbtt02001vo.setCrdScnCnclPssYn(" ");
		} else {
			mbtt02001vo.setCrdScnCnclPssYn(StringUtil.nvl(request.getParameter("crd_scn_cncl_pss_yn")));
		}
		mbtt02001vo.setRespCn(StringUtil.nvl(jmvo0218.getZ_resp_cd()));
		mbtt02001vo.setRslCn(scrnNm + "_" + StringUtil.nvl(jmvo0218.getZ_resp_msg()));
		mbtt02001vo.setFrstIpmnEmpno("82101685");
		mbtt02001vo.setFnalAmdrEmpno("82101685");
		if("".equals(request.getParameter("adc_rtrn_dvn")) || null == request.getParameter("adc_rtrn_dvn")){
			mbtt02001vo.setAdcRtrnDvn(" ");
		} else {
			mbtt02001vo.setAdcRtrnDvn(StringUtil.nvl(request.getParameter("adc_rtrn_dvn")));
		}
		if("".equals(request.getParameter("scrn_proc_cd")) || null == request.getParameter("scrn_proc_cd")){
			mbtt02001vo.setScrnProcCd(" ");
		} else {
			mbtt02001vo.setScrnProcCd(StringUtil.nvl(request.getParameter("scrn_proc_cd")));
		}
		if("".equals(request.getParameter("ctc_plno")) || null == request.getParameter("ctc_plno")){
			mbtt02001vo.setCtcPlno(" ");
		} else {
			mbtt02001vo.setCtcPlno(StringUtil.nvl(request.getParameter("ctc_plno")));
		}
		if("".equals(request.getParameter("trv_dstc_proc_dvcd")) || null == request.getParameter("trv_dstc_proc_dvcd")){
			mbtt02001vo.setTrvDstcProcDvcd(" ");
		} else {
			mbtt02001vo.setTrvDstcProcDvcd(StringUtil.nvl(request.getParameter("trv_dstc_proc_dvcd")));
		}
		if("".equals(jmvo0218.getMbl_snd_no()) || null == jmvo0218.getMbl_snd_no()){
			mbtt02001vo.setMblSndNo(" ");
		} else {
			mbtt02001vo.setMblSndNo(StringUtil.nvl(jmvo0218.getMbl_snd_no()));
		}
		if("".equals(jmvo0218.getPlan_plno_dvcd()) || null == jmvo0218.getPlan_plno_dvcd()){
			mbtt02001vo.setPlanPlnoDvcd(" ");
		} else {
			mbtt02001vo.setPlanPlnoDvcd(StringUtil.nvl(jmvo0218.getPlan_plno_dvcd()));
		}
		if("".equals(jmvo0218.getPlan_plno()) || null == jmvo0218.getPlan_plno()){
			mbtt02001vo.setPlanPlno(" ");
		} else {
			mbtt02001vo.setPlanPlno(StringUtil.nvl(jmvo0218.getPlan_plno()));
		}
		if("".equals(jmvo0218.getChng_plan_no()) || null == jmvo0218.getChng_plan_no()){
			mbtt02001vo.setChngPlanNo(" ");
		} else {
			mbtt02001vo.setChngPlanNo(StringUtil.nvl(jmvo0218.getChng_plan_no()));
		}
		
		for(int i = 0; i < jmvo0218.getPhgp_regt_tgt__dst_tty_dvn().length; i++) {
			if(!"".equals(jmvo0218.getPhgp_regt_tgt__dst_tty_dvn()[i]) || null != jmvo0218.getPhgp_regt_tgt__dst_tty_dvn()[i]) {
				if("01".equals(jmvo0218.getPhgp_regt_tgt__dst_tty_dvn()[i])){
					mbtt02001vo.setDstTtyDvn1("01");
					mbtt02001vo.setPhgpRegtTgt1(jmvo0218.getPhgp_regt_tgt__phgp_regt_cplt_yn()[i]);
				}
				else if("02".equals(jmvo0218.getPhgp_regt_tgt__dst_tty_dvn()[i])){
					mbtt02001vo.setDstTtyDvn2("02");
					mbtt02001vo.setPhgpRegtTgt2(jmvo0218.getPhgp_regt_tgt__phgp_regt_cplt_yn()[i]);
				}
				else if("03".equals(jmvo0218.getPhgp_regt_tgt__dst_tty_dvn()[i])){
					mbtt02001vo.setDstTtyDvn3("03");
					mbtt02001vo.setPhgpRegtTgt3(jmvo0218.getPhgp_regt_tgt__phgp_regt_cplt_yn()[i]);
				}
				else if("04".equals(jmvo0218.getPhgp_regt_tgt__dst_tty_dvn()[i])){
					mbtt02001vo.setDstTtyDvn4("04");
					mbtt02001vo.setPhgpRegtTgt4(jmvo0218.getPhgp_regt_tgt__phgp_regt_cplt_yn()[i]);
				}
				else if("05".equals(jmvo0218.getPhgp_regt_tgt__dst_tty_dvn()[i])){
					mbtt02001vo.setDstTtyDvn5("05");
					mbtt02001vo.setPhgpRegtTgt5(jmvo0218.getPhgp_regt_tgt__phgp_regt_cplt_yn()[i]);
				}
			}
		}
		if("".equals(mbtt02001vo.getDstTtyDvn1()) || null == mbtt02001vo.getDstTtyDvn1()){
			mbtt02001vo.setDstTtyDvn1(" ");
			mbtt02001vo.setPhgpRegtTgt1(" ");
		}
		if("".equals(mbtt02001vo.getDstTtyDvn2()) || null == mbtt02001vo.getDstTtyDvn2()){
			mbtt02001vo.setDstTtyDvn2(" ");
			mbtt02001vo.setPhgpRegtTgt2(" ");
		}
		if("".equals(mbtt02001vo.getDstTtyDvn3()) || null == mbtt02001vo.getDstTtyDvn3()){
			mbtt02001vo.setDstTtyDvn3(" ");
			mbtt02001vo.setPhgpRegtTgt3(" ");
		}
		if("".equals(mbtt02001vo.getDstTtyDvn4()) || null == mbtt02001vo.getDstTtyDvn4()){
			mbtt02001vo.setDstTtyDvn4(" ");
			mbtt02001vo.setPhgpRegtTgt4(" ");
		}
		if("".equals(mbtt02001vo.getDstTtyDvn5()) || null == mbtt02001vo.getDstTtyDvn5()){
			mbtt02001vo.setDstTtyDvn5(" ");
			mbtt02001vo.setPhgpRegtTgt5(" ");
		}
		
		//MMTI0218 insert
		insertRow = 0;
		
		logger.info("#### upMileageStep7B2 MMTI0218 MBTT02001 before ####");
		insertRow = mileageTobeService.insertJungsanTest(mbtt02001vo);
		logger.info("#### upMileageStep7B2 MMTI0218 MBTT02001 after ####");
		
		if(insertRow < 1){
			logger.info("#### 사서함번호: " + StringUtil.nvl(mbtt02001vo.getPboxNo()) + "####");
			logger.info("#### insert 결과: Fail ####");
		}else{
			logger.info("#### insert 결과: Success ####");
		}
		
		if(count > 0 && count == jmvo0218.getPhgp_regt_tgt__dst_tty_dvn().length){
			request.setAttribute("reg_yn", "1");
		}else{
			request.setAttribute("reg_yn", "0");
		}
		
		session.setAttribute("renewal", "02");
		request.setAttribute("dvn", "01");
		return "/counter/carrider/tobe/upMileageStep7B";
	}
	
	@RequestMapping(value="/upMileageStep7C")
	public @ResponseBody Map<String, String> upMileageStep7C(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		HttpSession session = request.getSession();
		Map<String, String> map = new HashMap<String, String>();
		MMTI0213VO pre_mmti0213vo = new MMTI0213VO();
		MMTI0259VO pre_mmti0259vo = new MMTI0259VO();
		pre_mmti0213vo = (MMTI0213VO)session.getAttribute("pre_mmti0213vo");
		pre_mmti0259vo = (MMTI0259VO)session.getAttribute("pre_mmti0259vo");
		MBTT02001VO mbtt02001vo = new MBTT02001VO();
		String scrnNm = "upMileageStep7C";

		//MMTI0213전문 정산이력테이블(MBTT02001) 적재
		mbtt02001vo.setPboxNo(StringUtil.nvl(pre_mmti0213vo.getSms_ts_bvan()));
		mbtt02001vo.setTlgIdVal("MMTI0213");
		mbtt02001vo.setEsbTrscId(StringUtil.nvl(pre_mmti0213vo.getZ_trsc_id()));
		if("".equals(pre_mmti0213vo.getPlno()) || null == pre_mmti0213vo.getPlno()){
			mbtt02001vo.setPlno(" ");
		} else {
			mbtt02001vo.setPlno(StringUtil.nvl(pre_mmti0213vo.getPlno()));
		}
		if("".equals(request.getParameter("exp_exca_plan_no")) || null == request.getParameter("exp_exca_plan_no")){
			mbtt02001vo.setPlanNo(" ");
		} else {
			mbtt02001vo.setPlanNo(StringUtil.nvl(request.getParameter("exp_exca_plan_no")));
		}
		if("".equals(pre_mmti0213vo.getRnw_plno()) || null == pre_mmti0213vo.getRnw_plno()){
			mbtt02001vo.setRnwPlno(" ");
		} else {
			mbtt02001vo.setRnwPlno(StringUtil.nvl(pre_mmti0213vo.getRnw_plno()));
		}
		if("".equals(request.getParameter("hdlr_empno")) || null == request.getParameter("hdlr_empno")){
			mbtt02001vo.setHdlrEmpno(" ");
		} else {
			mbtt02001vo.setHdlrEmpno(StringUtil.nvl(request.getParameter("hdlr_empno")));
		}
		if("".equals(pre_mmti0213vo.getPbox_no_dvcd()) || null == pre_mmti0213vo.getPbox_no_dvcd()){
			mbtt02001vo.setPboxNoDvcd(" ");
		} else {
			mbtt02001vo.setPboxNoDvcd(StringUtil.nvl(pre_mmti0213vo.getPbox_no_dvcd()));
		}
		if("".equals(pre_mmti0213vo.getProc_dvn()) || null == pre_mmti0213vo.getProc_dvn()){
			mbtt02001vo.setProcDvn(" ");
		} else {
			mbtt02001vo.setProcDvn(StringUtil.nvl(pre_mmti0213vo.getProc_dvn()));
		}
		if("".equals(pre_mmti0213vo.getTrv_dstc_exp_exca_dvcd()) || null == pre_mmti0213vo.getTrv_dstc_exp_exca_dvcd()){
			mbtt02001vo.setTrvDstcExpExcaDvcd(" ");
		} else {
			mbtt02001vo.setTrvDstcExpExcaDvcd(StringUtil.nvl(pre_mmti0213vo.getTrv_dstc_exp_exca_dvcd()));
		}
		if("".equals(pre_mmti0213vo.getTrv_dstc_chng_aply_dvn()) || null == pre_mmti0213vo.getTrv_dstc_chng_aply_dvn()){
			mbtt02001vo.setTrvDstcChngAplyDvn(" ");
		} else {
			mbtt02001vo.setTrvDstcChngAplyDvn(StringUtil.nvl(pre_mmti0213vo.getTrv_dstc_chng_aply_dvn()));
		}
		if("".equals(pre_mmti0213vo.getHdlr_fire_yn()) || null == pre_mmti0213vo.getHdlr_fire_yn()){
			mbtt02001vo.setHdlrFireYn(" ");
		} else {
			mbtt02001vo.setHdlrFireYn(StringUtil.nvl(pre_mmti0213vo.getHdlr_fire_yn()));
		}
		if("".equals(pre_mmti0213vo.getMtcc_yn()) || null == pre_mmti0213vo.getMtcc_yn()){
			mbtt02001vo.setMtccYn(" ");
		} else {
			mbtt02001vo.setMtccYn(StringUtil.nvl(pre_mmti0213vo.getMtcc_yn()));
		}
		if("".equals(request.getParameter("aut_cgnt_trv_dstc")) || null == request.getParameter("aut_cgnt_trv_dstc")){
			mbtt02001vo.setAutCgntTrvDstc(0);
		} else {
			mbtt02001vo.setAutCgntTrvDstc(Double.parseDouble(request.getParameter("aut_cgnt_trv_dstc")));
		}
		if("".equals(request.getParameter("aut_cgnt_trv_dstc_rsl_cd")) || null == request.getParameter("aut_cgnt_trv_dstc_rsl_cd")){
			mbtt02001vo.setAutCgntTrvDstcRslCd(" ");
		} else {
			mbtt02001vo.setAutCgntTrvDstcRslCd(StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc_rsl_cd")));
		}
		if("".equals(request.getParameter("inptTrvDstc")) || null == request.getParameter("inptTrvDstc")){
			mbtt02001vo.setInptTrvDstc(0);
		} else {
			mbtt02001vo.setInptTrvDstc(Double.parseDouble(request.getParameter("inptTrvDstc")));
		}
		if("".equals(request.getParameter("cnv_trv_dstc")) || null == request.getParameter("cnv_trv_dstc")){
			mbtt02001vo.setCnvTrvDstc(0);
		} else {
			mbtt02001vo.setCnvTrvDstc(Double.parseDouble(request.getParameter("cnv_trv_dstc")));
		}
		if("".equals(request.getParameter("exp_exca_plan_rsl_cd")) || null == request.getParameter("exp_exca_plan_rsl_cd")){
			mbtt02001vo.setExpExcaPlanRslCd(" ");
		} else {
			mbtt02001vo.setExpExcaPlanRslCd(StringUtil.nvl(request.getParameter("exp_exca_plan_rsl_cd")));
		}
		if("".equals(request.getParameter("excaBzProcDvn")) || null == request.getParameter("excaBzProcDvn")){
			mbtt02001vo.setExcaBzProcDvn(" ");
		} else {
			mbtt02001vo.setExcaBzProcDvn(StringUtil.nvl(request.getParameter("excaBzProcDvn")));
		}
		if("".equals(request.getParameter("excaRtrnDvn")) || null == request.getParameter("excaRtrnDvn")){
			mbtt02001vo.setExcaRtrnDvn(" ");
		} else {
			mbtt02001vo.setExcaRtrnDvn(StringUtil.nvl(request.getParameter("excaRtrnPrm")));
		}
		if("".equals(request.getParameter("pdc_sr_dvn")) || null == request.getParameter("pdc_sr_dvn")){
			mbtt02001vo.setPdcSrDvn(" ");
		} else {
			mbtt02001vo.setPdcSrDvn(StringUtil.nvl(request.getParameter("pdc_sr_dvn")));
		}
		if("".equals(request.getParameter("adc_rtrn_prm")) || null == request.getParameter("adc_rtrn_prm")){
			mbtt02001vo.setAdcRtrnPrm(0);
		} else {
			mbtt02001vo.setAdcRtrnPrm(Double.parseDouble(request.getParameter("adc_rtrn_prm")));
		}
		if("".equals(request.getParameter("trv_dstc_splc_exca_yn")) || null == request.getParameter("trv_dstc_splc_exca_yn")){
			mbtt02001vo.setTrvDstcSplcExcaYn(" ");
		} else {
			mbtt02001vo.setTrvDstcSplcExcaYn(StringUtil.nvl(request.getParameter("trv_dstc_splc_exca_yn")));
		}
		if("".equals(request.getParameter("imag_dup_yn")) || null == request.getParameter("imag_dup_yn")){
			mbtt02001vo.setImagDupYn(" ");
		} else {
			mbtt02001vo.setImagDupYn(StringUtil.nvl(request.getParameter("imag_dup_yn")));
		}
		if("".equals(request.getParameter("nrm_proc_yn")) || null == request.getParameter("nrm_proc_yn")){
			mbtt02001vo.setNrmProcYn(" ");
		} else {
			mbtt02001vo.setNrmProcYn(StringUtil.nvl(request.getParameter("nrm_proc_yn")));
		}
		if("".equals(request.getParameter("crd_scn_cncl_pss_yn")) || null == request.getParameter("crd_scn_cncl_pss_yn")){
			mbtt02001vo.setCrdScnCnclPssYn(" ");
		} else {
			mbtt02001vo.setCrdScnCnclPssYn(StringUtil.nvl(request.getParameter("crd_scn_cncl_pss_yn")));
		}
		mbtt02001vo.setTlgProcRslCdVal(StringUtil.nvl(pre_mmti0213vo.getZ_tlg_sp_cd()));
		mbtt02001vo.setTlgErrCdVal(StringUtil.nvl(pre_mmti0213vo.getZ_trns_org_dvcd())+StringUtil.nvl(pre_mmti0213vo.getZ_trns_org_cd()));
		mbtt02001vo.setRespCn(StringUtil.nvl(pre_mmti0213vo.getZ_resp_cd()));
		mbtt02001vo.setRslCn(scrnNm + "_" + StringUtil.nvl(pre_mmti0213vo.getZ_resp_msg()));
		mbtt02001vo.setFrstIpmnEmpno("82101685");
		mbtt02001vo.setFnalAmdrEmpno("82101685");
		if("".equals(request.getParameter("adc_rtrn_dvn")) || null == request.getParameter("adc_rtrn_dvn")){
			mbtt02001vo.setAdcRtrnDvn(" ");
		} else {
			mbtt02001vo.setAdcRtrnDvn(StringUtil.nvl(request.getParameter("adc_rtrn_dvn")));
		}
		if("".equals(request.getParameter("scrn_proc_cd")) || null == request.getParameter("scrn_proc_cd")){
			mbtt02001vo.setScrnProcCd(" ");
		} else {
			mbtt02001vo.setScrnProcCd(StringUtil.nvl(request.getParameter("scrn_proc_cd")));
		}
		if("".equals(pre_mmti0213vo.getCtc_plno()) || null == pre_mmti0213vo.getCtc_plno()){
			mbtt02001vo.setCtcPlno(" ");
		} else {
			mbtt02001vo.setCtcPlno(StringUtil.nvl(pre_mmti0213vo.getCtc_plno()));
		}
		if("".equals(request.getParameter("trv_dstc_proc_dvcd")) || null == request.getParameter("trv_dstc_proc_dvcd")){
			mbtt02001vo.setTrvDstcProcDvcd(" ");
		} else {
			mbtt02001vo.setTrvDstcProcDvcd(StringUtil.nvl(request.getParameter("trv_dstc_proc_dvcd")));
		}
		if("".equals(request.getParameter("mbl_snd_no")) || null == request.getParameter("mbl_snd_no")){
			mbtt02001vo.setMblSndNo(" ");
		} else {
			mbtt02001vo.setMblSndNo(StringUtil.nvl(request.getParameter("mbl_snd_no")));
		}
		if("".equals(request.getParameter("plan_plno_dvcd")) || null == request.getParameter("plan_plno_dvcd")){
			mbtt02001vo.setPlanPlnoDvcd(" ");
		} else {
			mbtt02001vo.setPlanPlnoDvcd(StringUtil.nvl(request.getParameter("plan_plno_dvcd")));
		}
		if("".equals(request.getParameter("plan_plno")) || null == request.getParameter("plan_plno")){
			mbtt02001vo.setPlanPlno(" ");
		} else {
			mbtt02001vo.setPlanPlno(StringUtil.nvl(request.getParameter("plan_plno")));
		}
		if("".equals(pre_mmti0213vo.getChng_plan_no()) || null == pre_mmti0213vo.getChng_plan_no()){
			mbtt02001vo.setChngPlanNo(" ");
		} else {
			mbtt02001vo.setChngPlanNo(StringUtil.nvl(pre_mmti0213vo.getChng_plan_no()));
		}
		if("".equals(request.getParameter("dst_tty_dvn1")) || null == request.getParameter("dst_tty_dvn1")){
			mbtt02001vo.setDstTtyDvn1(" ");
		} else {
			mbtt02001vo.setDstTtyDvn1(StringUtil.nvl(request.getParameter("dst_tty_dvn1")));
		}
		if("".equals(request.getParameter("dst_tty_dvn2")) || null == request.getParameter("dst_tty_dvn2")){
			mbtt02001vo.setDstTtyDvn2(" ");
		} else {
			mbtt02001vo.setDstTtyDvn2(StringUtil.nvl(request.getParameter("dst_tty_dvn2")));
		}
		if("".equals(request.getParameter("dst_tty_dvn3")) || null == request.getParameter("dst_tty_dvn3")){
			mbtt02001vo.setDstTtyDvn3(" ");
		} else {
			mbtt02001vo.setDstTtyDvn3(StringUtil.nvl(request.getParameter("dst_tty_dvn3")));
		}
		if("".equals(request.getParameter("dst_tty_dvn4")) || null == request.getParameter("dst_tty_dvn4")){
			mbtt02001vo.setDstTtyDvn4(" ");
		} else {
			mbtt02001vo.setDstTtyDvn4(StringUtil.nvl(request.getParameter("dst_tty_dvn4")));
		}
		if("".equals(request.getParameter("dst_tty_dvn5")) || null == request.getParameter("dst_tty_dvn5")){
			mbtt02001vo.setDstTtyDvn5(" ");
		} else {
			mbtt02001vo.setDstTtyDvn5(StringUtil.nvl(request.getParameter("dst_tty_dvn5")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt1")) || null == request.getParameter("phgp_regt_tgt1")){
			mbtt02001vo.setPhgpRegtTgt1(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt1(StringUtil.nvl(request.getParameter("phgp_regt_tgt1")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt2")) || null == request.getParameter("phgp_regt_tgt2")){
			mbtt02001vo.setPhgpRegtTgt2(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt2(StringUtil.nvl(request.getParameter("phgp_regt_tgt2")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt3")) || null == request.getParameter("phgp_regt_tgt3")){
			mbtt02001vo.setPhgpRegtTgt3(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt3(StringUtil.nvl(request.getParameter("phgp_regt_tgt3")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt4")) || null == request.getParameter("phgp_regt_tgt4")){
			mbtt02001vo.setPhgpRegtTgt4(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt4(StringUtil.nvl(request.getParameter("phgp_regt_tgt4")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt5")) || null == request.getParameter("phgp_regt_tgt5")){
			mbtt02001vo.setPhgpRegtTgt5(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt5(StringUtil.nvl(request.getParameter("phgp_regt_tgt5")));
		}
		
		//MMTI0213 insert
		int insertRow = 0;
		
		logger.info("#### upMileageStep7C insertJungsanTest before ####");
		insertRow = mileageTobeService.insertJungsanTest(mbtt02001vo);
		logger.info("#### upMileageStep7C insertJungsanTest after ####");
		
		if(insertRow < 1){
			logger.info("#### 사서함번호: " + StringUtil.nvl(mbtt02001vo.getPboxNo()) + "####");
			logger.info("#### insert 결과: Fail ####");
		}else{
			logger.info("#### insert 결과: Success ####");
		}
		
		//MMTI0259전문 정산이력테이블(MBTT02001) 적재
		mbtt02001vo.setPboxNo(StringUtil.nvl(pre_mmti0213vo.getSms_ts_bvan()));
		mbtt02001vo.setTlgIdVal("MMTI0259");
		mbtt02001vo.setEsbTrscId(StringUtil.nvl(pre_mmti0259vo.getZ_trsc_id()));
		if("".equals(pre_mmti0259vo.getPlno()) || null == pre_mmti0259vo.getPlno()){
			mbtt02001vo.setPlno(" ");
		} else {
			mbtt02001vo.setPlno(StringUtil.nvl(pre_mmti0259vo.getPlno()));
		}
		if("".equals(request.getParameter("plan_no")) || null == request.getParameter("plan_no")){
			mbtt02001vo.setPlanNo(" ");
		} else {
			mbtt02001vo.setPlanNo(StringUtil.nvl(request.getParameter("plan_no")));
		}
		if("".equals(request.getParameter("rnw_plno")) || null == request.getParameter("rnw_plno")){
			mbtt02001vo.setRnwPlno(" ");
		} else {
			mbtt02001vo.setRnwPlno(StringUtil.nvl(request.getParameter("rnw_plno")));
		}
		mbtt02001vo.setTlgProcRslCdVal(StringUtil.nvl(pre_mmti0259vo.getZ_tlg_sp_cd()));
		mbtt02001vo.setTlgErrCdVal(StringUtil.nvl(pre_mmti0259vo.getZ_trns_org_dvcd())+StringUtil.nvl(pre_mmti0259vo.getZ_trns_org_cd()));
		if("".equals(request.getParameter("hdlrEmpno")) || null == request.getParameter("hdlrEmpno")){
			mbtt02001vo.setHdlrEmpno(" ");
		} else {
			mbtt02001vo.setHdlrEmpno(StringUtil.nvl(request.getParameter("hdlrEmpno")));
		}
		if("".equals(request.getParameter("pbox_no_dvcd")) || null == request.getParameter("pbox_no_dvcd")){
			mbtt02001vo.setPboxNoDvcd(" ");
		} else {
			mbtt02001vo.setPboxNoDvcd(StringUtil.nvl(request.getParameter("pbox_no_dvcd")));
		}
		if("".equals(request.getParameter("proc_dvn")) || null == request.getParameter("proc_dvn")){
			mbtt02001vo.setProcDvn(" ");
		} else {
			mbtt02001vo.setProcDvn(StringUtil.nvl(request.getParameter("proc_dvn")));
		}
		if("".equals(request.getParameter("trv_dstc_exp_exca_dvcd")) || null == request.getParameter("trv_dstc_exp_exca_dvcd")){
			mbtt02001vo.setTrvDstcExpExcaDvcd(" ");
		} else {
			mbtt02001vo.setTrvDstcExpExcaDvcd(StringUtil.nvl(request.getParameter("trv_dstc_exp_exca_dvcd")));
		}
		if("".equals(request.getParameter("trv_dstc_chng_aply_dvn")) || null == request.getParameter("trv_dstc_chng_aply_dvn")){
			mbtt02001vo.setTrvDstcChngAplyDvn(" ");
		} else {
			mbtt02001vo.setTrvDstcChngAplyDvn(StringUtil.nvl(request.getParameter("trv_dstc_chng_aply_dvn")));
		}
		if("".equals(request.getParameter("hdlr_fire_yn")) || null == request.getParameter("hdlr_fire_yn")){
			mbtt02001vo.setHdlrFireYn(" ");
		} else {
			mbtt02001vo.setHdlrFireYn(StringUtil.nvl(request.getParameter("hdlr_fire_yn")));
		}
		if("".equals(request.getParameter("mtcc_yn")) || null == request.getParameter("mtcc_yn")){
			mbtt02001vo.setMtccYn(" ");
		} else {
			mbtt02001vo.setMtccYn(StringUtil.nvl(request.getParameter("mtcc_yn")));
		}
		if("".equals(pre_mmti0259vo.getAut_cgnt_trv_dstc()) || null == pre_mmti0259vo.getAut_cgnt_trv_dstc()){
			mbtt02001vo.setAutCgntTrvDstc(0);
		} else {
			mbtt02001vo.setAutCgntTrvDstc(Double.parseDouble(pre_mmti0259vo.getAut_cgnt_trv_dstc()));
		}
		if("".equals(pre_mmti0259vo.getAut_cgnt_trv_dstc_rsl_cd()) || null == pre_mmti0259vo.getAut_cgnt_trv_dstc_rsl_cd()){
			mbtt02001vo.setAutCgntTrvDstcRslCd(" ");
		} else {
			mbtt02001vo.setAutCgntTrvDstcRslCd(StringUtil.nvl(pre_mmti0259vo.getAut_cgnt_trv_dstc_rsl_cd()));
		}
		if("".equals(pre_mmti0259vo.getInpt_trv_dstc()) || null == pre_mmti0259vo.getInpt_trv_dstc()){
			mbtt02001vo.setInptTrvDstc(0);
		} else {
			mbtt02001vo.setInptTrvDstc(Double.parseDouble(pre_mmti0259vo.getInpt_trv_dstc()));
		}
		if("".equals(pre_mmti0259vo.getCnv_trv_dstc()) || null == pre_mmti0259vo.getCnv_trv_dstc()){
			mbtt02001vo.setCnvTrvDstc(0);
		} else {
			mbtt02001vo.setCnvTrvDstc(Double.parseDouble(pre_mmti0259vo.getCnv_trv_dstc()));
		}
		if("".equals(pre_mmti0259vo.getExp_exca_plan_rsl_cd()) || null == pre_mmti0259vo.getExp_exca_plan_rsl_cd()){
			mbtt02001vo.setExpExcaPlanRslCd(" ");
		} else {
			mbtt02001vo.setExpExcaPlanRslCd(StringUtil.nvl(pre_mmti0259vo.getExp_exca_plan_rsl_cd()));
		}
		if("".equals(request.getParameter("exca_bz_proc_dvn")) || null == request.getParameter("exca_bz_proc_dvn")){
			mbtt02001vo.setExcaBzProcDvn(" ");
		} else {
			mbtt02001vo.setExcaBzProcDvn(StringUtil.nvl(request.getParameter("exca_bz_proc_dvn")));
		}
		if("".equals(request.getParameter("exca_rtrn_dvn")) || null == request.getParameter("exca_rtrn_dvn")){
			mbtt02001vo.setExcaRtrnDvn(" ");
		} else {
			mbtt02001vo.setExcaRtrnDvn(StringUtil.nvl(request.getParameter("exca_rtrn_dvn")));
		}
		if("".equals(pre_mmti0259vo.getPdc_sr_dvn()) || null == pre_mmti0259vo.getPdc_sr_dvn()){
			mbtt02001vo.setPdcSrDvn(" ");
		} else {
			mbtt02001vo.setPdcSrDvn(StringUtil.nvl(pre_mmti0259vo.getPdc_sr_dvn()));
		}
		if("".equals(pre_mmti0259vo.getAdc_rtrn_prm()) || null == pre_mmti0259vo.getAdc_rtrn_prm()){
			mbtt02001vo.setAdcRtrnPrm(0);
		} else {
			mbtt02001vo.setAdcRtrnPrm(Double.parseDouble(pre_mmti0259vo.getAdc_rtrn_prm()));
		}
		if("".equals(request.getParameter("trv_dstc_splc_exca_yn")) || null == request.getParameter("trv_dstc_splc_exca_yn")){
			mbtt02001vo.setTrvDstcSplcExcaYn(" ");
		} else {
			mbtt02001vo.setTrvDstcSplcExcaYn(StringUtil.nvl(request.getParameter("trv_dstc_splc_exca_yn")));
		}
		if("".equals(request.getParameter("imag_dup_yn")) || null == request.getParameter("imag_dup_yn")){
			mbtt02001vo.setImagDupYn(" ");
		} else {
			mbtt02001vo.setImagDupYn(StringUtil.nvl(request.getParameter("imag_dup_yn")));
		}
		if("".equals(request.getParameter("nrm_proc_yn")) || null == request.getParameter("nrm_proc_yn")){
			mbtt02001vo.setNrmProcYn(" ");
		} else {
			mbtt02001vo.setNrmProcYn(StringUtil.nvl(request.getParameter("nrm_proc_yn")));
		}
		if("".equals(request.getParameter("crd_scn_cncl_pss_yn")) || null == request.getParameter("crd_scn_cncl_pss_yn")){
			mbtt02001vo.setCrdScnCnclPssYn(" ");
		} else {
			mbtt02001vo.setCrdScnCnclPssYn(StringUtil.nvl(request.getParameter("crd_scn_cncl_pss_yn")));
		}
		mbtt02001vo.setRespCn(StringUtil.nvl(pre_mmti0259vo.getZ_resp_cd()));
		mbtt02001vo.setRslCn(scrnNm + "_" + StringUtil.nvl(pre_mmti0259vo.getZ_resp_msg()));
		mbtt02001vo.setFrstIpmnEmpno("82101685");
		mbtt02001vo.setFnalAmdrEmpno("82101685");
		
		if("".equals(pre_mmti0259vo.getAdc_rtrn_dvn()) || null == pre_mmti0259vo.getAdc_rtrn_dvn()){
			mbtt02001vo.setAdcRtrnDvn(" ");
		} else {
			mbtt02001vo.setAdcRtrnDvn(StringUtil.nvl(pre_mmti0259vo.getAdc_rtrn_dvn()));
		}
		if("".equals(request.getParameter("scrn_proc_cd")) || null == request.getParameter("scrn_proc_cd")){
			mbtt02001vo.setScrnProcCd(" ");
		} else {
			mbtt02001vo.setScrnProcCd(StringUtil.nvl(request.getParameter("scrn_proc_cd")));
		}
		if("".equals(request.getParameter("ctc_plno")) || null == request.getParameter("ctc_plno")){
			mbtt02001vo.setCtcPlno(" ");
		} else {
			mbtt02001vo.setCtcPlno(StringUtil.nvl(request.getParameter("ctc_plno")));
		}
		if("".equals(request.getParameter("trv_dstc_proc_dvcd")) || null == request.getParameter("trv_dstc_proc_dvcd")){
			mbtt02001vo.setTrvDstcProcDvcd(" ");
		} else {
			mbtt02001vo.setTrvDstcProcDvcd(StringUtil.nvl(request.getParameter("trv_dstc_proc_dvcd")));
		}
		if("".equals(request.getParameter("mbl_snd_no")) || null == request.getParameter("mbl_snd_no")){
			mbtt02001vo.setMblSndNo(" ");
		} else {
			mbtt02001vo.setMblSndNo(StringUtil.nvl(request.getParameter("mbl_snd_no")));
		}
		if("".equals(request.getParameter("plan_plno_dvcd")) || null == request.getParameter("plan_plno_dvcd")){
			mbtt02001vo.setPlanPlnoDvcd(" ");
		} else {
			mbtt02001vo.setPlanPlnoDvcd(StringUtil.nvl(request.getParameter("plan_plno_dvcd")));
		}
		if("".equals(request.getParameter("plan_plno")) || null == request.getParameter("plan_plno")){
			mbtt02001vo.setPlanPlno(" ");
		} else {
			mbtt02001vo.setPlanPlno(StringUtil.nvl(request.getParameter("plan_plno")));
		}
		if("".equals(request.getParameter("chng_plan_no")) || null == request.getParameter("chng_plan_no")){
			mbtt02001vo.setChngPlanNo(" ");
		} else {
			mbtt02001vo.setChngPlanNo(StringUtil.nvl(request.getParameter("chng_plan_no")));
		}
		if("".equals(request.getParameter("dst_tty_dvn1")) || null == request.getParameter("dst_tty_dvn1")){
			mbtt02001vo.setDstTtyDvn1(" ");
		} else {
			mbtt02001vo.setDstTtyDvn1(StringUtil.nvl(request.getParameter("dst_tty_dvn1")));
		}
		if("".equals(request.getParameter("dst_tty_dvn2")) || null == request.getParameter("dst_tty_dvn2")){
			mbtt02001vo.setDstTtyDvn2(" ");
		} else {
			mbtt02001vo.setDstTtyDvn2(StringUtil.nvl(request.getParameter("dst_tty_dvn2")));
		}
		if("".equals(request.getParameter("dst_tty_dvn3")) || null == request.getParameter("dst_tty_dvn3")){
			mbtt02001vo.setDstTtyDvn3(" ");
		} else {
			mbtt02001vo.setDstTtyDvn3(StringUtil.nvl(request.getParameter("dst_tty_dvn3")));
		}
		if("".equals(request.getParameter("dst_tty_dvn4")) || null == request.getParameter("dst_tty_dvn4")){
			mbtt02001vo.setDstTtyDvn4(" ");
		} else {
			mbtt02001vo.setDstTtyDvn4(StringUtil.nvl(request.getParameter("dst_tty_dvn4")));
		}
		if("".equals(request.getParameter("dst_tty_dvn5")) || null == request.getParameter("dst_tty_dvn5")){
			mbtt02001vo.setDstTtyDvn5(" ");
		} else {
			mbtt02001vo.setDstTtyDvn5(StringUtil.nvl(request.getParameter("dst_tty_dvn5")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt1")) || null == request.getParameter("phgp_regt_tgt1")){
			mbtt02001vo.setPhgpRegtTgt1(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt1(StringUtil.nvl(request.getParameter("phgp_regt_tgt1")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt2")) || null == request.getParameter("phgp_regt_tgt2")){
			mbtt02001vo.setPhgpRegtTgt2(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt2(StringUtil.nvl(request.getParameter("phgp_regt_tgt2")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt3")) || null == request.getParameter("phgp_regt_tgt3")){
			mbtt02001vo.setPhgpRegtTgt3(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt3(StringUtil.nvl(request.getParameter("phgp_regt_tgt3")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt4")) || null == request.getParameter("phgp_regt_tgt4")){
			mbtt02001vo.setPhgpRegtTgt4(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt4(StringUtil.nvl(request.getParameter("phgp_regt_tgt4")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt5")) || null == request.getParameter("phgp_regt_tgt5")){
			mbtt02001vo.setPhgpRegtTgt5(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt5(StringUtil.nvl(request.getParameter("phgp_regt_tgt5")));
		}
		
		//MMTI0259 insert
		insertRow = 0;
		
		logger.info("#### upMileageStep7C MMTI0259 MBTT02001 before ####");
		insertRow = mileageTobeService.insertJungsanTest(mbtt02001vo);
		logger.info("#### upMileageStep7C MMTI0259 MBTT02001 after ####");
		
		if(insertRow < 1){
			logger.info("#### 사서함번호: " + StringUtil.nvl(mbtt02001vo.getPboxNo()) + "####");
			logger.info("#### insert 결과: Fail ####");
		}else{
			logger.info("#### insert 결과: Success ####");
		}
	
		MMTI0291VO pre_mmti0291vo = new MMTI0291VO();
		pre_mmti0291vo.setTrv_dstc_exca_mtt__exca_bz_proc_dvn("2");												// 정산업무처리구분 2:확정
		pre_mmti0291vo.setTrv_dstc_exca_mtt__plno(pre_mmti0259vo.getPlno());									// 증권번호
		pre_mmti0291vo.setTrv_dstc_exca_mtt__plan_no(pre_mmti0259vo.getExp_exca_plan_no());						// 설계번호
		pre_mmti0291vo.setTrv_dstc_exca_mtt__exca_rtrn_dvn("3");												// 갱신환급구분 3:카드부분취소
		pre_mmti0291vo.setTrv_dstc_exca_mtt__pdc_sr_dvn(pre_mmti0259vo.getPdc_sr_dvn());						// 상품출처구분
		pre_mmti0291vo.setTrv_dstc_exca_mtt__scrn_proc_cd(pre_mmti0259vo.getExp_exca_plan_rsl_cd());			// 화면처리코드
		pre_mmti0291vo.setTrv_dstc_exca_mtt__adc_rtrn_dvn(pre_mmti0259vo.getAdc_rtrn_dvn());					// 추징환급구분
		pre_mmti0291vo.setTrv_dstc_exca_mtt__adc_rtrn_prm(pre_mmti0259vo.getAdc_rtrn_prm());					// 추징환급보험료
		pre_mmti0291vo.setTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn(pre_mmti0213vo.getTrv_dstc_splc_exca_yn());	// 주행거리간편정산여부
		pre_mmti0291vo.setTrv_dstc_exca_mtt__pbox_no(pre_mmti0213vo.getSms_ts_bvan());							// 사서함번호
		
		pre_mmti0291vo.setTrv_dstc_exca_mtt__crd_scn_cncl_pss_yn(pre_mmti0259vo.getCrd_scn_cncl_pss_yn()); 		// 카드부분취소가능여부
		pre_mmti0291vo.setTrv_dstc_exca_mtt__stlm_cdcp_nm(pre_mmti0259vo.getStlm_cdcp_nm());					// 결제카드사명
		pre_mmti0291vo.setTrv_dstc_exca_mtt__stlm_crd_no(pre_mmti0259vo.getStlm_crd_no());						// 결제카드번호
		pre_mmti0291vo = mileageTobeService.getMMTI0291VO(pre_mmti0291vo);
		
		if(pre_mmti0291vo.getErrorCode().equals("0")){
			map.put("result", "y");
			session.setAttribute("scrn_proc_cd", pre_mmti0291vo.getTrv_dstc_exca_mtt__scrn_proc_cd());
			session.setAttribute("rnw_plno", pre_mmti0291vo.getTrv_dstc_exca_mtt__rnw_plno());
			session.setAttribute("pdc_sr_dvn", pre_mmti0291vo.getTrv_dstc_exca_mtt__pdc_sr_dvn());
			
			// 아래 데이터 + 갱신증번: 추가가입위해 저장
			session.setAttribute("trv_dstc_exca_mtt__plno", pre_mmti0291vo.getTrv_dstc_exca_mtt__plno());
			session.setAttribute("trv_dstc_exca_mtt__plan_no", pre_mmti0291vo.getTrv_dstc_exca_mtt__plan_no());
			session.setAttribute("trv_dstc_exca_mtt__plan_dt", pre_mmti0291vo.getTrv_dstc_exca_mtt__plan_dt());
			session.setAttribute("trv_dstc_exca_mtt__hdlr_empno", pre_mmti0291vo.getTrv_dstc_exca_mtt__hdlr_empno());
			
			// 부적정/중복 이미지인 경우 화면처리코드 02 
			if("1".equals(pre_mmti0291vo.getTrv_dstc_exca_mtt__imag_dup_yn())){
				pre_mmti0291vo.setTrv_dstc_exca_mtt__scrn_proc_cd("02");
			}
			
			// CM 상품이고, 화면처리코드 IN(02, 14) or 이미지 중복
			
			if("CM".equals(pre_mmti0291vo.getTrv_dstc_exca_mtt__pdc_sr_dvn()) && 
					("02".equals(pre_mmti0291vo.getTrv_dstc_exca_mtt__scrn_proc_cd())
					|| "14".equals(pre_mmti0291vo.getTrv_dstc_exca_mtt__scrn_proc_cd()))){
				
				MMTI0015VO mmti0015vo = new MMTI0015VO();
				mmti0015vo.setFunt_key("00");
				mmti0015vo.setPlan_no(pre_mmti0291vo.getTrv_dstc_exca_mtt__plan_no());
				mmti0015vo = mileageTobeService.getMMTI0015VO(mmti0015vo);
				
				logger.debug("##### MMTI0015 시작 ##########################");
				logger.debug("##### 고객식별번호: " + mmti0015vo.getPlhd__cust_dcmt_no() + " ##########################");
				logger.debug("##### 고객번호: " + mmti0015vo.getPlhd__cust_no() + " ##########################");
				logger.debug("##### 고객명: " + mmti0015vo.getPlhd__cust_nm() + " ##########################");
				logger.debug("##### 이메일: " + mmti0015vo.getPlhd__eml() + " ##########################");
				logger.debug("##### 지역번호: " + mmti0015vo.getPlhd_cntp_if__tlp_arno() + " ##########################");
				logger.debug("##### 국번호: " + mmti0015vo.getPlhd_cntp_if__tlp_ofno() + " ##########################");
				logger.debug("##### 개별번호: " + mmti0015vo.getPlhd_cntp_if__tlp_idvno() + " ##########################");
				
				XTEM0021VO xtem0021vo = new XTEM0021VO();
				xtem0021vo.setCnsl_rpt_no("");						// 상담접수번호				
				xtem0021vo.setCm_bz_dvcd("05");
				xtem0021vo.setCnsl_typ_dvcd("07");
				xtem0021vo.setCm_plan_no(pre_mmti0291vo.getTrv_dstc_exca_mtt__plan_no());
				xtem0021vo.setCnsl_rpy_dvcd("1");
				xtem0021vo.setCnsl_rpt_dttm(getDayTime());			// 현재년월일시분초 14자리
				xtem0021vo.setCust_nm(mmti0015vo.getPlhd__cust_nm());
				xtem0021vo.setCust_no(mmti0015vo.getPlhd__cust_no());
				
				String cust_dcmt_no = SeedUtil.decrypt(mmti0015vo.getPlhd__cust_dcmt_no());
				
				if("1".equals(cust_dcmt_no.substring(6, 7)) || "2".equals(cust_dcmt_no.substring(6, 7))
					|| "5".equals(cust_dcmt_no.substring(6, 7)) || "6".equals(cust_dcmt_no.substring(6, 7))){
					xtem0021vo.setBrth("19" + cust_dcmt_no.substring(0, 6));
				} else{
					xtem0021vo.setBrth("20" + cust_dcmt_no.substring(0, 6));
				}
				xtem0021vo.setSx_cd(cust_dcmt_no.substring(6, 7));
				xtem0021vo.setEml_adr(mmti0015vo.getPlhd__eml());
				xtem0021vo.setClp_tlcno(mmti0015vo.getPlhd_cntp_if__tlp_arno());
				xtem0021vo.setClp_ofno(mmti0015vo.getPlhd_cntp_if__tlp_ofno());
				xtem0021vo.setClp_idvno(mmti0015vo.getPlhd_cntp_if__tlp_idvno());
				xtem0021vo.setCnsl_rsvt_dt("99990101");
				xtem0021vo.setCnsl_rsvt_time_cd("1");
				xtem0021vo.setCnsl_cn("최종주행거리사진등록/만기정산");
				xtem0021vo.setCnsl_aply_csn_yn("1");
				xtem0021vo.setUrl_adr("");
				xtem0021vo.setCm_ctrmf_tpcd("32");
				xtem0021vo.setFrst_ipmn_empno("80000028");
				xtem0021vo.setFrst_ipnpt_dttm(getDayTime());		// 현재년월일시분초 14자리	
				
				xtem0021vo = mileageTobeService.getXTEM0021VO(xtem0021vo);
				logger.debug("##### XTEM0021 시작 ##########################");
				logger.debug("##### 처리결과: [ " + xtem0021vo.getProc_rtn() + " ] ##########################");
			}
		}else{
			map.put("result", "n");
			map.put("z_resp_msg", pre_mmti0291vo.getZ_resp_msg());
		}
		
		//MMTI0291전문 정산이력테이블(MBTT02001) 적재
		mbtt02001vo.setPboxNo(StringUtil.nvl(pre_mmti0213vo.getSms_ts_bvan()));
		mbtt02001vo.setTlgIdVal("MMTI0291");
		mbtt02001vo.setEsbTrscId(StringUtil.nvl(pre_mmti0291vo.getZ_trsc_id()));
		if("".equals(pre_mmti0291vo.getTrv_dstc_exca_mtt__plno()) || null == pre_mmti0291vo.getTrv_dstc_exca_mtt__plno()){
			mbtt02001vo.setPlno(" ");
		} else {
			mbtt02001vo.setPlno(StringUtil.nvl(pre_mmti0291vo.getTrv_dstc_exca_mtt__plno()));
		}
		if("".equals(pre_mmti0291vo.getTrv_dstc_exca_mtt__plan_no()) || null == pre_mmti0291vo.getTrv_dstc_exca_mtt__plan_no()){
			mbtt02001vo.setPlanNo(" ");
		} else {
			mbtt02001vo.setPlanNo(StringUtil.nvl(pre_mmti0291vo.getTrv_dstc_exca_mtt__plan_no()));
		}
		if("".equals(pre_mmti0291vo.getTrv_dstc_exca_mtt__rnw_plno()) || null == pre_mmti0291vo.getTrv_dstc_exca_mtt__rnw_plno()){
			mbtt02001vo.setRnwPlno(" ");
		} else {
			mbtt02001vo.setRnwPlno(StringUtil.nvl(pre_mmti0291vo.getTrv_dstc_exca_mtt__rnw_plno()));
		}
		mbtt02001vo.setTlgProcRslCdVal(StringUtil.nvl(pre_mmti0291vo.getZ_tlg_sp_cd()));
		mbtt02001vo.setTlgErrCdVal(StringUtil.nvl(pre_mmti0291vo.getZ_trns_org_dvcd())+StringUtil.nvl(pre_mmti0291vo.getZ_trns_org_cd()));
		if("".equals(pre_mmti0291vo.getTrv_dstc_exca_mtt__hdlr_empno()) || null == pre_mmti0291vo.getTrv_dstc_exca_mtt__hdlr_empno()){
			mbtt02001vo.setHdlrEmpno(" ");
		} else {
			mbtt02001vo.setHdlrEmpno(StringUtil.nvl(pre_mmti0291vo.getTrv_dstc_exca_mtt__hdlr_empno()));
		}
		if("".equals(request.getParameter("pbox_no_dvcd")) || null == request.getParameter("pbox_no_dvcd")){
			mbtt02001vo.setPboxNoDvcd(" ");
		} else {
			mbtt02001vo.setPboxNoDvcd(StringUtil.nvl(request.getParameter("pbox_no_dvcd")));
		}
		if("".equals(request.getParameter("proc_dvn")) || null == request.getParameter("proc_dvn")){
			mbtt02001vo.setProcDvn(" ");
		} else {
			mbtt02001vo.setProcDvn(StringUtil.nvl(request.getParameter("proc_dvn")));
		}
		if("".equals(request.getParameter("trv_dstc_exp_exca_dvcd")) || null == request.getParameter("trv_dstc_exp_exca_dvcd")){
			mbtt02001vo.setTrvDstcExpExcaDvcd(" ");
		} else {
			mbtt02001vo.setTrvDstcExpExcaDvcd(StringUtil.nvl(request.getParameter("trv_dstc_exp_exca_dvcd")));
		}
		if("".equals(request.getParameter("trv_dstc_chng_aply_dvn")) || null == request.getParameter("trv_dstc_chng_aply_dvn")){
			mbtt02001vo.setTrvDstcChngAplyDvn(" ");
		} else {
			mbtt02001vo.setTrvDstcChngAplyDvn(StringUtil.nvl(request.getParameter("trv_dstc_chng_aply_dvn")));
		}
		if("".equals(request.getParameter("hdlr_fire_yn")) || null == request.getParameter("hdlr_fire_yn")){
			mbtt02001vo.setHdlrFireYn(" ");
		} else {
			mbtt02001vo.setHdlrFireYn(StringUtil.nvl(request.getParameter("hdlr_fire_yn")));
		}
		if("".equals(request.getParameter("mtcc_yn")) || null == request.getParameter("mtcc_yn")){
			mbtt02001vo.setMtccYn(" ");
		} else {
			mbtt02001vo.setMtccYn(StringUtil.nvl(request.getParameter("mtcc_yn")));
		}
		if("".equals(request.getParameter("aut_cgnt_trv_dstc")) || null == request.getParameter("aut_cgnt_trv_dstc")){
			mbtt02001vo.setAutCgntTrvDstc(0);
		} else {
			mbtt02001vo.setAutCgntTrvDstc(Double.parseDouble(request.getParameter("aut_cgnt_trv_dstc")));
		}
		if("".equals(pre_mmti0291vo.getTrv_dstc_exca_mtt__aut_cgnt_trv_dstc_rsl_cd()) || null == pre_mmti0291vo.getTrv_dstc_exca_mtt__aut_cgnt_trv_dstc_rsl_cd()){
			mbtt02001vo.setAutCgntTrvDstcRslCd(" ");
		} else {
			mbtt02001vo.setAutCgntTrvDstcRslCd(StringUtil.nvl(pre_mmti0291vo.getTrv_dstc_exca_mtt__aut_cgnt_trv_dstc_rsl_cd()));
		}
		if("".equals(request.getParameter("inptTrvDstc")) || null == request.getParameter("inptTrvDstc")){
			mbtt02001vo.setInptTrvDstc(0);
		} else {
			mbtt02001vo.setInptTrvDstc(Double.parseDouble(request.getParameter("inptTrvDstc")));
		}
		if("".equals(pre_mmti0291vo.getTrv_dstc_exca_mtt__cnv_trv_dstc()) || null == pre_mmti0291vo.getTrv_dstc_exca_mtt__cnv_trv_dstc()){
			mbtt02001vo.setCnvTrvDstc(0);
		} else {
			mbtt02001vo.setCnvTrvDstc(Double.parseDouble(pre_mmti0291vo.getTrv_dstc_exca_mtt__cnv_trv_dstc()));
		}
		if("".equals(request.getParameter("exp_exca_plan_rsl_cd")) || null == request.getParameter("exp_exca_plan_rsl_cd")){
			mbtt02001vo.setExpExcaPlanRslCd(" ");
		} else {
			mbtt02001vo.setExpExcaPlanRslCd(StringUtil.nvl(request.getParameter("exp_exca_plan_rsl_cd")));
		}
		if("".equals(pre_mmti0291vo.getTrv_dstc_exca_mtt__exca_bz_proc_dvn()) || null == pre_mmti0291vo.getTrv_dstc_exca_mtt__exca_bz_proc_dvn()){
			mbtt02001vo.setExcaBzProcDvn(" ");
		} else {
			mbtt02001vo.setExcaBzProcDvn(StringUtil.nvl(pre_mmti0291vo.getTrv_dstc_exca_mtt__exca_bz_proc_dvn()));
		}
		if("".equals(pre_mmti0291vo.getTrv_dstc_exca_mtt__exca_rtrn_dvn()) || null == pre_mmti0291vo.getTrv_dstc_exca_mtt__exca_rtrn_dvn()){
			mbtt02001vo.setExcaRtrnDvn(" ");
		} else {
			mbtt02001vo.setExcaRtrnDvn(StringUtil.nvl(pre_mmti0291vo.getTrv_dstc_exca_mtt__exca_rtrn_dvn()));
		}
		if("".equals(pre_mmti0291vo.getTrv_dstc_exca_mtt__pdc_sr_dvn()) || null == pre_mmti0291vo.getTrv_dstc_exca_mtt__pdc_sr_dvn()){
			mbtt02001vo.setPdcSrDvn(" ");
		} else {
			mbtt02001vo.setPdcSrDvn(StringUtil.nvl(pre_mmti0291vo.getTrv_dstc_exca_mtt__pdc_sr_dvn()));
		}
		if("".equals(pre_mmti0291vo.getTrv_dstc_exca_mtt__adc_rtrn_prm()) || null == pre_mmti0291vo.getTrv_dstc_exca_mtt__adc_rtrn_prm()){
			mbtt02001vo.setAdcRtrnPrm(0);
		} else {
			mbtt02001vo.setAdcRtrnPrm(Double.parseDouble(pre_mmti0291vo.getTrv_dstc_exca_mtt__adc_rtrn_prm()));
		}
		if("".equals(pre_mmti0291vo.getTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn()) || null == pre_mmti0291vo.getTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn()){
			mbtt02001vo.setTrvDstcSplcExcaYn(" ");
		} else {
			mbtt02001vo.setTrvDstcSplcExcaYn(StringUtil.nvl(pre_mmti0291vo.getTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn()));
		}
		if("".equals(pre_mmti0291vo.getTrv_dstc_exca_mtt__imag_dup_yn()) || null == pre_mmti0291vo.getTrv_dstc_exca_mtt__imag_dup_yn()){
			mbtt02001vo.setImagDupYn(" ");
		} else {
			mbtt02001vo.setImagDupYn(StringUtil.nvl(pre_mmti0291vo.getTrv_dstc_exca_mtt__imag_dup_yn()));
		}
		if("".equals(pre_mmti0291vo.getTrv_dstc_exca_mtt__nrm_proc_yn()) || null == pre_mmti0291vo.getTrv_dstc_exca_mtt__nrm_proc_yn()){
			mbtt02001vo.setNrmProcYn(" ");
		} else {
			mbtt02001vo.setNrmProcYn(StringUtil.nvl(pre_mmti0291vo.getTrv_dstc_exca_mtt__nrm_proc_yn()));
		}
		if("".equals(request.getParameter("crdScnCnclPssYn")) || null == request.getParameter("crdScnCnclPssYn")){
			mbtt02001vo.setCrdScnCnclPssYn(" ");
		} else {
			mbtt02001vo.setCrdScnCnclPssYn(StringUtil.nvl(request.getParameter("crdScnCnclPssYn")));
		}
		mbtt02001vo.setRespCn(StringUtil.nvl(pre_mmti0291vo.getZ_resp_cd()));
		mbtt02001vo.setRslCn(scrnNm + "_" + StringUtil.nvl(pre_mmti0291vo.getZ_resp_msg()));
		mbtt02001vo.setFrstIpmnEmpno("82101685");
		mbtt02001vo.setFnalAmdrEmpno("82101685");
		if("".equals(pre_mmti0291vo.getTrv_dstc_exca_mtt__adc_rtrn_dvn()) || null == pre_mmti0291vo.getTrv_dstc_exca_mtt__adc_rtrn_dvn()){
			mbtt02001vo.setAdcRtrnDvn(" ");
		} else {
			mbtt02001vo.setAdcRtrnDvn(StringUtil.nvl(pre_mmti0291vo.getTrv_dstc_exca_mtt__adc_rtrn_dvn()));
		}
		if("".equals(pre_mmti0291vo.getTrv_dstc_exca_mtt__scrn_proc_cd()) || null == pre_mmti0291vo.getTrv_dstc_exca_mtt__scrn_proc_cd()){
			mbtt02001vo.setScrnProcCd(" ");
		} else {
			mbtt02001vo.setScrnProcCd(StringUtil.nvl(pre_mmti0291vo.getTrv_dstc_exca_mtt__scrn_proc_cd()));
		}
		if("".equals(request.getParameter("ctc_plno")) || null == request.getParameter("ctc_plno")){
			mbtt02001vo.setCtcPlno(" ");
		} else {
			mbtt02001vo.setCtcPlno(StringUtil.nvl(request.getParameter("ctc_plno")));
		}
		if("".equals(request.getParameter("trv_dstc_proc_dvcd")) || null == request.getParameter("trv_dstc_proc_dvcd")){
			mbtt02001vo.setTrvDstcProcDvcd(" ");
		} else {
			mbtt02001vo.setTrvDstcProcDvcd(StringUtil.nvl(request.getParameter("trv_dstc_proc_dvcd")));
		}
		if("".equals(request.getParameter("mbl_snd_no")) || null == request.getParameter("mbl_snd_no")){
			mbtt02001vo.setMblSndNo(" ");
		} else {
			mbtt02001vo.setMblSndNo(StringUtil.nvl(request.getParameter("mbl_snd_no")));
		}
		if("".equals(request.getParameter("plan_plno_dvcd")) || null == request.getParameter("plan_plno_dvcd")){
			mbtt02001vo.setPlanPlnoDvcd(" ");
		} else {
			mbtt02001vo.setPlanPlnoDvcd(StringUtil.nvl(request.getParameter("plan_plno_dvcd")));
		}
		if("".equals(request.getParameter("plan_plno")) || null == request.getParameter("plan_plno")){
			mbtt02001vo.setPlanPlno(" ");
		} else {
			mbtt02001vo.setPlanPlno(StringUtil.nvl(request.getParameter("plan_plno")));
		}
		if("".equals(request.getParameter("chng_plan_no")) || null == request.getParameter("chng_plan_no")){
			mbtt02001vo.setChngPlanNo(" ");
		} else {
			mbtt02001vo.setChngPlanNo(StringUtil.nvl(request.getParameter("chng_plan_no")));
		}
		if("".equals(request.getParameter("dst_tty_dvn1")) || null == request.getParameter("dst_tty_dvn1")){
			mbtt02001vo.setDstTtyDvn1(" ");
		} else {
			mbtt02001vo.setDstTtyDvn1(StringUtil.nvl(request.getParameter("dst_tty_dvn1")));
		}
		if("".equals(request.getParameter("dst_tty_dvn2")) || null == request.getParameter("dst_tty_dvn2")){
			mbtt02001vo.setDstTtyDvn2(" ");
		} else {
			mbtt02001vo.setDstTtyDvn2(StringUtil.nvl(request.getParameter("dst_tty_dvn2")));
		}
		if("".equals(request.getParameter("dst_tty_dvn3")) || null == request.getParameter("dst_tty_dvn3")){
			mbtt02001vo.setDstTtyDvn3(" ");
		} else {
			mbtt02001vo.setDstTtyDvn3(StringUtil.nvl(request.getParameter("dst_tty_dvn3")));
		}
		if("".equals(request.getParameter("dst_tty_dvn4")) || null == request.getParameter("dst_tty_dvn4")){
			mbtt02001vo.setDstTtyDvn4(" ");
		} else {
			mbtt02001vo.setDstTtyDvn4(StringUtil.nvl(request.getParameter("dst_tty_dvn4")));
		}
		if("".equals(request.getParameter("dst_tty_dvn5")) || null == request.getParameter("dst_tty_dvn5")){
			mbtt02001vo.setDstTtyDvn5(" ");
		} else {
			mbtt02001vo.setDstTtyDvn5(StringUtil.nvl(request.getParameter("dst_tty_dvn5")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt1")) || null == request.getParameter("phgp_regt_tgt1")){
			mbtt02001vo.setPhgpRegtTgt1(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt1(StringUtil.nvl(request.getParameter("phgp_regt_tgt1")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt2")) || null == request.getParameter("phgp_regt_tgt2")){
			mbtt02001vo.setPhgpRegtTgt2(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt2(StringUtil.nvl(request.getParameter("phgp_regt_tgt2")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt3")) || null == request.getParameter("phgp_regt_tgt3")){
			mbtt02001vo.setPhgpRegtTgt3(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt3(StringUtil.nvl(request.getParameter("phgp_regt_tgt3")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt4")) || null == request.getParameter("phgp_regt_tgt4")){
			mbtt02001vo.setPhgpRegtTgt4(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt4(StringUtil.nvl(request.getParameter("phgp_regt_tgt4")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt5")) || null == request.getParameter("phgp_regt_tgt5")){
			mbtt02001vo.setPhgpRegtTgt5(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt5(StringUtil.nvl(request.getParameter("phgp_regt_tgt5")));
		}
		
		//MMTI0291 insert
		insertRow = 0;
		
		logger.info("#### upMileageStep7C MMTI0291 MBTT02001 before ####");
		insertRow = mileageTobeService.insertJungsanTest(mbtt02001vo);
		logger.info("#### upMileageStep7C MMTI0291 MBTT02001 after ####");
		
		if(insertRow < 1){
			logger.info("#### 사서함번호: " + StringUtil.nvl(mbtt02001vo.getPboxNo()) + "####");
			logger.info("#### insert 결과: Fail ####");
		}else{
			logger.info("#### insert 결과: Success ####");
		}
		
		return map;	
	}
	
	@RequestMapping(value="/upMileageStep7C2")
	public String upMileageStep7C2(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		HttpSession session = request.getSession();
		MMTI0217VO mmti0217vo = new MMTI0217VO();
		Map<String, String> map = new HashMap<String, String>();
		
		MMTI0213VO pre_mmti0213vo = new MMTI0213VO();
		pre_mmti0213vo = (MMTI0213VO)session.getAttribute("pre_mmti0213vo");
		
		if(session.getAttribute("p") != null) {
			mmti0217vo.setMbl_snd_no((String) session.getAttribute("p"));
		}
		else {
			mmti0217vo.setMbl_snd_no(aes256Decrypt(StringUtil.nvl(request.getParameter("p"))));
		}
		mmti0217vo = mileageTobeService.getMMTI0217VO(mmti0217vo);
		
		MMTI0218VO jmvo0218 = new MMTI0218VO();
		MBTT02001VO mbtt02001vo = new MBTT02001VO();
		String scrnNm = "upMileageStep7C2";
		
		jmvo0218.setMbl_snd_no(mmti0217vo.getMbl_snd_no());
		jmvo0218.setPlan_plno_dvcd(mmti0217vo.getPlan_plno_dvcd());
		jmvo0218.setPlan_plno(mmti0217vo.getPlan_plno());
		jmvo0218.setChng_plan_no(mmti0217vo.getChng_plan_no());
		
		jmvo0218 = mileageTobeService.getMMTI0218VO(jmvo0218);
		int count = 0;
		for(int i = 0; i < jmvo0218.getPhgp_regt_tgt__dst_tty_dvn().length; i++) {
			if("Y".equals(jmvo0218.getPhgp_regt_tgt__phgp_regt_cplt_yn()[i]) || "1".equals(jmvo0218.getPhgp_regt_tgt__phgp_regt_cplt_yn()[i])) count++;
		}
		
		if(count > 0 && count == jmvo0218.getPhgp_regt_tgt__dst_tty_dvn().length){
			request.setAttribute("reg_yn", "1");
		}else{
			request.setAttribute("reg_yn", "0");
		}
		
		request.setAttribute("dvn", "01");

		//MMTI0218전문 정산이력테이블(MBTT02001) 적재
		mbtt02001vo.setPboxNo(StringUtil.nvl(pre_mmti0213vo.getSms_ts_bvan()));
		mbtt02001vo.setTlgIdVal("MMTI0218");
		mbtt02001vo.setEsbTrscId(StringUtil.nvl(jmvo0218.getZ_trsc_id()));
		if("".equals(jmvo0218.getPlan_plno()) || null == jmvo0218.getPlan_plno()){
			mbtt02001vo.setPlno(" ");
		} else {
			mbtt02001vo.setPlno(StringUtil.nvl(jmvo0218.getPlan_plno()));
		}
		if("".equals(request.getParameter("plan_no")) || null == request.getParameter("plan_no")){
			mbtt02001vo.setPlanNo(" ");
		} else {
			mbtt02001vo.setPlanNo(StringUtil.nvl(request.getParameter("plan_no")));
		}
		if("".equals(request.getParameter("rnw_plno")) || null == request.getParameter("rnw_plno")){
			mbtt02001vo.setRnwPlno(" ");
		} else {
			mbtt02001vo.setRnwPlno(StringUtil.nvl(request.getParameter("rnw_plno")));
		}
		mbtt02001vo.setTlgProcRslCdVal(StringUtil.nvl(jmvo0218.getZ_tlg_sp_cd()));
		mbtt02001vo.setTlgErrCdVal(StringUtil.nvl(jmvo0218.getZ_trns_org_dvcd())+StringUtil.nvl(jmvo0218.getZ_trns_org_cd()));
		if("".equals(request.getParameter("hdlr_empno")) || null == request.getParameter("hdlr_empno")){
			mbtt02001vo.setHdlrEmpno(" ");
		} else {
			mbtt02001vo.setHdlrEmpno(StringUtil.nvl(request.getParameter("hdlr_empno")));
		}
		if("".equals(request.getParameter("pbox_no_dvcd")) || null == request.getParameter("pbox_no_dvcd")){
			mbtt02001vo.setPboxNoDvcd(" ");
		} else {
			mbtt02001vo.setPboxNoDvcd(StringUtil.nvl(request.getParameter("pbox_no_dvcd")));
		}
		if("".equals(request.getParameter("proc_dvn")) || null == request.getParameter("proc_dvn")){
			mbtt02001vo.setProcDvn(" ");
		} else {
			mbtt02001vo.setProcDvn(StringUtil.nvl(request.getParameter("proc_dvn")));
		}
		if("".equals(request.getParameter("trv_dstc_exp_exca_dvcd")) || null == request.getParameter("trv_dstc_exp_exca_dvcd")){
			mbtt02001vo.setTrvDstcExpExcaDvcd(" ");
		} else {
			mbtt02001vo.setTrvDstcExpExcaDvcd(StringUtil.nvl(request.getParameter("trv_dstc_exp_exca_dvcd")));
		}
		if("".equals(request.getParameter("trv_dstc_chng_aply_dvn")) || null == request.getParameter("trv_dstc_chng_aply_dvn")){
			mbtt02001vo.setTrvDstcChngAplyDvn(" ");
		} else {
			mbtt02001vo.setTrvDstcChngAplyDvn(StringUtil.nvl(request.getParameter("trv_dstc_chng_aply_dvn")));
		}
		if("".equals(request.getParameter("hdlr_fire_yn")) || null == request.getParameter("hdlr_fire_yn")){
			mbtt02001vo.setHdlrFireYn(" ");
		} else {
			mbtt02001vo.setHdlrFireYn(StringUtil.nvl(request.getParameter("hdlr_fire_yn")));
		}
		if("".equals(request.getParameter("mtcc_yn")) || null == request.getParameter("mtcc_yn")){
			mbtt02001vo.setMtccYn(" ");
		} else {
			mbtt02001vo.setMtccYn(StringUtil.nvl(request.getParameter("mtcc_yn")));
		}
		if("".equals(request.getParameter("aut_cgnt_trv_dstc")) || null == request.getParameter("aut_cgnt_trv_dstc")){
			mbtt02001vo.setAutCgntTrvDstc(0);
		} else {
			mbtt02001vo.setAutCgntTrvDstc(Double.parseDouble(request.getParameter("aut_cgnt_trv_dstc")));
		}
		if("".equals(request.getParameter("aut_cgnt_trv_dstc_rsl_cd")) || null == request.getParameter("aut_cgnt_trv_dstc_rsl_cd")){
			mbtt02001vo.setAutCgntTrvDstcRslCd(" ");
		} else {
			mbtt02001vo.setAutCgntTrvDstcRslCd(StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc_rsl_cd")));
		}
		if("".equals(request.getParameter("inptTrvDstc")) || null == request.getParameter("inptTrvDstc")){
			mbtt02001vo.setInptTrvDstc(0);
		} else {
			mbtt02001vo.setInptTrvDstc(Double.parseDouble(request.getParameter("inptTrvDstc")));
		}
		if("".equals(request.getParameter("cnv_trv_dstc")) || null == request.getParameter("cnv_trv_dstc")){
			mbtt02001vo.setCnvTrvDstc(0);
		} else {
			mbtt02001vo.setCnvTrvDstc(Double.parseDouble(request.getParameter("cnv_trv_dstc")));
		}
		if("".equals(request.getParameter("exp_exca_plan_rsl_cd")) || null == request.getParameter("exp_exca_plan_rsl_cd")){
			mbtt02001vo.setExpExcaPlanRslCd(" ");
		} else {
			mbtt02001vo.setExpExcaPlanRslCd(StringUtil.nvl(request.getParameter("exp_exca_plan_rsl_cd")));
		}
		if("".equals(request.getParameter("exca_bz_proc_dvn")) || null == request.getParameter("exca_bz_proc_dvn")){
			mbtt02001vo.setExcaBzProcDvn(" ");
		} else {
			mbtt02001vo.setExcaBzProcDvn(StringUtil.nvl(request.getParameter("exca_bz_proc_dvn")));
		}
		if("".equals(request.getParameter("exca_rtrn_dvn")) || null == request.getParameter("exca_rtrn_dvn")){
			mbtt02001vo.setExcaRtrnDvn(" ");
		} else {
			mbtt02001vo.setExcaRtrnDvn(StringUtil.nvl(request.getParameter("exca_rtrn_dvn")));
		}
		if("".equals(request.getParameter("pdc_sr_dvn")) || null == request.getParameter("pdc_sr_dvn")){
			mbtt02001vo.setPdcSrDvn(" ");
		} else {
			mbtt02001vo.setPdcSrDvn(StringUtil.nvl(request.getParameter("pdc_sr_dvn")));
		}
		if("".equals(request.getParameter("adc_rtrn_prm")) || null == request.getParameter("adc_rtrn_prm")){
			mbtt02001vo.setAdcRtrnPrm(0);
		} else {
			mbtt02001vo.setAdcRtrnPrm(Double.parseDouble(request.getParameter("adc_rtrn_prm")));
		}
		if("".equals(request.getParameter("trv_dstc_splc_exca_yn")) || null == request.getParameter("trv_dstc_splc_exca_yn")){
			mbtt02001vo.setTrvDstcSplcExcaYn(" ");
		} else {
			mbtt02001vo.setTrvDstcSplcExcaYn(StringUtil.nvl(request.getParameter("trv_dstc_splc_exca_yn")));
		}
		if("".equals(request.getParameter("imag_dup_yn")) || null == request.getParameter("imag_dup_yn")){
			mbtt02001vo.setImagDupYn(" ");
		} else {
			mbtt02001vo.setImagDupYn(StringUtil.nvl(request.getParameter("imag_dup_yn")));
		}
		if("".equals(request.getParameter("nrm_proc_yn")) || null == request.getParameter("nrm_proc_yn")){
			mbtt02001vo.setNrmProcYn(" ");
		} else {
			mbtt02001vo.setNrmProcYn(StringUtil.nvl(request.getParameter("nrm_proc_yn")));
		}
		if("".equals(request.getParameter("crd_scn_cncl_pss_yn")) || null == request.getParameter("crd_scn_cncl_pss_yn")){
			mbtt02001vo.setCrdScnCnclPssYn(" ");
		} else {
			mbtt02001vo.setCrdScnCnclPssYn(StringUtil.nvl(request.getParameter("crd_scn_cncl_pss_yn")));
		}
		mbtt02001vo.setRespCn(StringUtil.nvl(jmvo0218.getZ_resp_cd()));
		mbtt02001vo.setRslCn(scrnNm + "_" + StringUtil.nvl(jmvo0218.getZ_resp_msg()));
		mbtt02001vo.setFrstIpmnEmpno("82101685");
		mbtt02001vo.setFnalAmdrEmpno("82101685");
		if("".equals(request.getParameter("adc_rtrn_dvn")) || null == request.getParameter("adc_rtrn_dvn")){
			mbtt02001vo.setAdcRtrnDvn(" ");
		} else {
			mbtt02001vo.setAdcRtrnDvn(StringUtil.nvl(request.getParameter("adc_rtrn_dvn")));
		}
		if("".equals(request.getParameter("scrn_proc_cd")) || null == request.getParameter("scrn_proc_cd")){
			mbtt02001vo.setScrnProcCd(" ");
		} else {
			mbtt02001vo.setScrnProcCd(StringUtil.nvl(request.getParameter("scrn_proc_cd")));
		}
		if("".equals(request.getParameter("ctc_plno")) || null == request.getParameter("ctc_plno")){
			mbtt02001vo.setCtcPlno(" ");
		} else {
			mbtt02001vo.setCtcPlno(StringUtil.nvl(request.getParameter("ctc_plno")));
		}
		if("".equals(request.getParameter("trv_dstc_proc_dvcd")) || null == request.getParameter("trv_dstc_proc_dvcd")){
			mbtt02001vo.setTrvDstcProcDvcd(" ");
		} else {
			mbtt02001vo.setTrvDstcProcDvcd(StringUtil.nvl(request.getParameter("trv_dstc_proc_dvcd")));
		}
		if("".equals(jmvo0218.getMbl_snd_no()) || null == jmvo0218.getMbl_snd_no()){
			mbtt02001vo.setMblSndNo(" ");
		} else {
			mbtt02001vo.setMblSndNo(StringUtil.nvl(jmvo0218.getMbl_snd_no()));
		}
		if("".equals(jmvo0218.getPlan_plno_dvcd()) || null == jmvo0218.getPlan_plno_dvcd()){
			mbtt02001vo.setPlanPlnoDvcd(" ");
		} else {
			mbtt02001vo.setPlanPlnoDvcd(StringUtil.nvl(jmvo0218.getPlan_plno_dvcd()));
		}
		if("".equals(jmvo0218.getPlan_plno()) || null == jmvo0218.getPlan_plno()){
			mbtt02001vo.setPlanPlno(" ");
		} else {
			mbtt02001vo.setPlanPlno(StringUtil.nvl(jmvo0218.getPlan_plno()));
		}
		if("".equals(jmvo0218.getChng_plan_no()) || null == jmvo0218.getChng_plan_no()){
			mbtt02001vo.setChngPlanNo(" ");
		} else {
			mbtt02001vo.setChngPlanNo(StringUtil.nvl(jmvo0218.getChng_plan_no()));
		}
		
		for(int i = 0; i < jmvo0218.getPhgp_regt_tgt__dst_tty_dvn().length; i++) {
			if(!"".equals(jmvo0218.getPhgp_regt_tgt__dst_tty_dvn()[i]) || null != jmvo0218.getPhgp_regt_tgt__dst_tty_dvn()[i]) {
				if("01".equals(jmvo0218.getPhgp_regt_tgt__dst_tty_dvn()[i])){
					mbtt02001vo.setDstTtyDvn1("01");
					mbtt02001vo.setPhgpRegtTgt1(jmvo0218.getPhgp_regt_tgt__phgp_regt_cplt_yn()[i]);
				}
				else if("02".equals(jmvo0218.getPhgp_regt_tgt__dst_tty_dvn()[i])){
					mbtt02001vo.setDstTtyDvn2("02");
					mbtt02001vo.setPhgpRegtTgt2(jmvo0218.getPhgp_regt_tgt__phgp_regt_cplt_yn()[i]);
				}
				else if("03".equals(jmvo0218.getPhgp_regt_tgt__dst_tty_dvn()[i])){
					mbtt02001vo.setDstTtyDvn3("03");
					mbtt02001vo.setPhgpRegtTgt3(jmvo0218.getPhgp_regt_tgt__phgp_regt_cplt_yn()[i]);
				}
				else if("04".equals(jmvo0218.getPhgp_regt_tgt__dst_tty_dvn()[i])){
					mbtt02001vo.setDstTtyDvn4("04");
					mbtt02001vo.setPhgpRegtTgt4(jmvo0218.getPhgp_regt_tgt__phgp_regt_cplt_yn()[i]);
				}
				else if("05".equals(jmvo0218.getPhgp_regt_tgt__dst_tty_dvn()[i])){
					mbtt02001vo.setDstTtyDvn5("05");
					mbtt02001vo.setPhgpRegtTgt5(jmvo0218.getPhgp_regt_tgt__phgp_regt_cplt_yn()[i]);
				}
			}
		}
		if("".equals(mbtt02001vo.getDstTtyDvn1()) || null == mbtt02001vo.getDstTtyDvn1()){
			mbtt02001vo.setDstTtyDvn1(" ");
			mbtt02001vo.setPhgpRegtTgt1(" ");
		}
		if("".equals(mbtt02001vo.getDstTtyDvn2()) || null == mbtt02001vo.getDstTtyDvn2()){
			mbtt02001vo.setDstTtyDvn2(" ");
			mbtt02001vo.setPhgpRegtTgt2(" ");
		}
		if("".equals(mbtt02001vo.getDstTtyDvn3()) || null == mbtt02001vo.getDstTtyDvn3()){
			mbtt02001vo.setDstTtyDvn3(" ");
			mbtt02001vo.setPhgpRegtTgt3(" ");
		}
		if("".equals(mbtt02001vo.getDstTtyDvn4()) || null == mbtt02001vo.getDstTtyDvn4()){
			mbtt02001vo.setDstTtyDvn4(" ");
			mbtt02001vo.setPhgpRegtTgt4(" ");
		}
		if("".equals(mbtt02001vo.getDstTtyDvn5()) || null == mbtt02001vo.getDstTtyDvn5()){
			mbtt02001vo.setDstTtyDvn5(" ");
			mbtt02001vo.setPhgpRegtTgt5(" ");
		}
		
		//MMTI0218 insert
		int insertRow = 0;
		
		logger.info("#### upMileageStep7C2 MMTI0218 MBTT02001 before ####");
		insertRow = mileageTobeService.insertJungsanTest(mbtt02001vo);
		logger.info("#### upMileageStep7C2 MMTI0218 MBTT02001 after ####");
		
		if(insertRow < 1){
			logger.info("#### 사서함번호: " + StringUtil.nvl(mbtt02001vo.getPboxNo()) + "####");
			logger.info("#### insert 결과: Fail ####");
		}else{
			logger.info("#### insert 결과: Success ####");
		}
		
		return "/counter/carrider/tobe/upMileageStep7C2";
	}
	
	@RequestMapping(value="/updatejungsan")
	public @ResponseBody Map<String, String> updatejungsan(HttpServletRequest request, Model model) throws Exception{
		Map<String, String> map = new HashMap<String, String>();
		try {
			map = new HashMap<String, String>();
			XIDB0004VO vo = new XIDB0004VO();
			String seq = StringUtil.nvl(request.getParameter("seq"));
			String stat = StringUtil.nvl(request.getParameter("stat"));
			String msg = StringUtil.nvl(request.getParameter("msg"));
			String eta_dtl_cn = StringUtil.nvl(request.getParameter("eta_dtl_cn"));
			logger.debug("#### XIDB004 ####");
			logger.debug("updatejungsan seq: " + seq);
			logger.debug("updatejungsan stat: " + stat);
			logger.debug("updatejungsan msg: " + msg);
			logger.debug("updatejungsan eta_dtl_cn: " + msg);
			
			vo.setSeq(seq);
			vo.setStat(stat);
			vo.setMsg(msg);
			vo.setEta_dtl_cn(eta_dtl_cn);
			mileageTobeService.getXIDB0004VO(vo);
			map.put("result", "y");
		} catch (Exception e) {
			map.put("result", "n");
			logger.debug("updatejungsan : " + e.getMessage());
		}
		return map;
	}
	
	@RequestMapping(value="/chatMileage01")
	public String chatMileage01(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception{
		
		MMTI0213VO jmvo = new MMTI0213VO();
		MMTI0305VO jmvo1 = new MMTI0305VO();
		
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("num")));
		String ch_dvn = request.getParameter("ch_dvn");
		
		jmvo = mileageTobeService.chatMMTI0213VO(jmvo);
		
		jmvo1.setSrch_cnd__vh_no(SeedUtil.encrypt(jmvo.getVh_no()));
		jmvo1.setSrch_cnd__plno(jmvo.getPlno());
		jmvo1.setSrch_cnd__proc_dvn("01");
		jmvo1.setSrch_cnd__hdlr_empno("80000176");
		jmvo1.setSrch_cnd__trv_dstc_proc_dvcd(jmvo.getProc_dvn());
		jmvo1 = mileageTobeService.chatMMTI0305VO(jmvo1);
		
		String tty_eny_yn = jmvo1.getSrch_rsl__tty_eny_yn() == null ? "" : jmvo1.getSrch_rsl__tty_eny_yn();
		logger.debug("tty_eny_yn: " + tty_eny_yn);
	
		request.setAttribute("num", request.getParameter("num"));
		request.setAttribute("jmvo", jmvo);
		request.setAttribute("tty_eny_yn", tty_eny_yn);
		request.setAttribute("ch_dvn", ch_dvn);
		return "/counter/carrider/tobe/chat_mileage01";
	}
	
	@RequestMapping(value="/chatMileage02")
	public String chatMileage02(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		MMTI0213VO jmvo = new MMTI0213VO();
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("num")));
		jmvo = mileageTobeService.chatMMTI0213VO(jmvo);
		request.setAttribute("num", request.getParameter("num"));
		request.setAttribute("jmvo", jmvo);
		request.setAttribute("ch_dvn", request.getParameter("ch_dvn"));
		return "/counter/carrider/tobe/chat_mileage02";
	}
	
	@RequestMapping(value="/chatMileageFileUpload")
	public @ResponseBody Map<String, String> chatMileageFileUpload(MultipartHttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		
		logger.debug(StringUtil.nvl(request.getParameter("ch_dvn")));
		logger.debug(aes256Decrypt(request.getParameter("num")));
		
		Map<String, String> map = new HashMap<String, String>();
		
		String ch_dvn = StringUtil.nvl(request.getParameter("ch_dvn"));
		
		MMTI0213VO jmvo = new MMTI0213VO();
		MBTR01001VO mbtr01001vo = new MBTR01001VO();
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("num")));
		jmvo = mileageTobeService.chatMMTI0213VO(jmvo);

		mbtr01001vo = mileageTobeService.regInfoToEdmsForMobileWeb(request, jmvo.getSms_ts_bvan(), mbtr01001vo);
		
		MMTI0259VO jmvo1 = new MMTI0259VO();
		jmvo1.setPbox_use_yn("1");
		jmvo1.setPbox_no(jmvo.getSms_ts_bvan());
		jmvo1.setPhgp_cnfm_dt(DateUtil.getDate("yyyymmdd"));
		jmvo1.setPhgp_strg_yn("1");
		
		// cm_yn!=1 제거
		if("1".equals(jmvo.getPbox_no_dvcd())) { 
			if("03".equals(jmvo.getProc_dvn())) {
				jmvo1.setPbox_chr_nm(request.getParameter("mileage1") + "/" + request.getParameter("mileage2"));
			}
			else {
				jmvo1.setPbox_chr_nm(request.getParameter("mileage1"));
			}
		}
		
		jmvo1 = mileageTobeService.chatMMTI0259VO(jmvo1);
		
		map.put("errorCode", jmvo1.getErrorCode());
		logger.debug("errorCode: " + jmvo1.getErrorCode());
		
		ch_dvn="01";
		
		if("0".equals(jmvo1.getErrorCode()) && "01".equals(ch_dvn)){
			MMTI0305VO jmvo2 = new MMTI0305VO();
			jmvo2.setSrch_cnd__proc_dvn("03");
			jmvo2.setSrch_cnd__plno(jmvo.getPlno());
			jmvo2.setSrch_cnd__plan_no(jmvo.getPlan_no());
			jmvo2.setSrch_cnd__hdlr_empno("80000176");
			jmvo2 = mileageTobeService.chatMMTI0305VO(jmvo2);
			logger.debug("rtun_cd: " + jmvo2.getSrch_rsl__rtun_cd() + ", rtun_msg: " + jmvo2.getSrch_rsl__rtun_msg());
			map.put("rtun_cd", jmvo2.getSrch_rsl__rtun_cd());
			map.put("rtun_msg", jmvo2.getSrch_rsl__rtun_msg());
		}
		
		int insertRow = 0;
		
		// VO SET
		mbtr01001vo.setPboxNo(jmvo.getSms_ts_bvan());
		mbtr01001vo.setApdxFlRutNm("");
		mbtr01001vo.setFrstIpmnEmpno("82101685");
		mbtr01001vo.setFnalAmdrEmpno("82101685");
		
		insertRow = mileageTobeService.insertTest(mbtr01001vo);
		if(insertRow < 1){
			logger.info("#### 사서함번호: " + StringUtil.nvl(mbtr01001vo.getPboxNo()) + "####");
			logger.info("#### insert 결과: Fail ####");
		}else{
			logger.info("#### insert 결과: Success ####");
		}
		
		return map;
	}
	
	//aiocr용
	@RequestMapping(value="/aiocrChatMileage01")
	public String aiocrChatMileage01(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception{
		
		MMTI0213VO jmvo = new MMTI0213VO();
		MMTI0305VO jmvo1 = new MMTI0305VO();
		
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("num")));
		String ch_dvn = request.getParameter("ch_dvn");
		
		jmvo = mileageTobeService.chatMMTI0213VO(jmvo);
		
		jmvo1.setSrch_cnd__vh_no(SeedUtil.encrypt(jmvo.getVh_no()));
		jmvo1.setSrch_cnd__plno(jmvo.getPlno());
		jmvo1.setSrch_cnd__proc_dvn("01");
		jmvo1.setSrch_cnd__hdlr_empno("80000176");
		jmvo1.setSrch_cnd__trv_dstc_proc_dvcd(jmvo.getProc_dvn());
		jmvo1 = mileageTobeService.chatMMTI0305VO(jmvo1);
		
		String tty_eny_yn = jmvo1.getSrch_rsl__tty_eny_yn() == null ? "" : jmvo1.getSrch_rsl__tty_eny_yn();
		logger.debug("tty_eny_yn: " + tty_eny_yn);
	
		request.setAttribute("num", request.getParameter("num"));
		request.setAttribute("jmvo", jmvo);
		request.setAttribute("tty_eny_yn", tty_eny_yn);
		request.setAttribute("ch_dvn", ch_dvn);
		return "/counter/carrider/tobe/aiocr_chat_mileage01";
	}
	
	//aiocr용
	@RequestMapping(value="/aiocrChatMileage02")
	public String aiocrChatMileage02(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		MMTI0213VO jmvo = new MMTI0213VO();
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("num")));
		jmvo = mileageTobeService.chatMMTI0213VO(jmvo);
		request.setAttribute("num", request.getParameter("num"));
		request.setAttribute("jmvo", jmvo);
		request.setAttribute("ch_dvn", request.getParameter("ch_dvn"));
		return "/counter/carrider/tobe/aiocr_chat_mileage02";
	}
	
	//aiocr용
	@RequestMapping(value="/aiocrChatMileageFileUpload")
	public @ResponseBody Map<String, String> aiocrChatMileageFileUpload(MultipartHttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		
		logger.debug(StringUtil.nvl(request.getParameter("ch_dvn")));
		logger.debug(aes256Decrypt(request.getParameter("num")));
		
		Map<String, String> map = new HashMap<String, String>();
		
		String ch_dvn = StringUtil.nvl(request.getParameter("ch_dvn"));
		
		MMTI0213VO jmvo = new MMTI0213VO();
		MBTR01001VO mbtr01001vo = new MBTR01001VO();
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("num")));
		jmvo = mileageTobeService.chatMMTI0213VO(jmvo);

		mbtr01001vo = mileageTobeService.aiocrRegInfoToEdmsForMobileWeb(request, jmvo.getSms_ts_bvan(), mbtr01001vo);
		
		MMTI0259VO jmvo1 = new MMTI0259VO();
		jmvo1.setPbox_use_yn("1");
		jmvo1.setPbox_no(jmvo.getSms_ts_bvan());
		jmvo1.setPhgp_cnfm_dt(DateUtil.getDate("yyyymmdd"));
		jmvo1.setPhgp_strg_yn("1");
		
		// cm_yn!=1 제거
		if("1".equals(jmvo.getPbox_no_dvcd())) { 
			if("03".equals(jmvo.getProc_dvn())) {
				jmvo1.setPbox_chr_nm(request.getParameter("mileage1") + "/" + request.getParameter("mileage2"));
			}
			else {
				jmvo1.setPbox_chr_nm(request.getParameter("mileage1"));
			}
		}
		
		jmvo1 = mileageTobeService.chatMMTI0259VO(jmvo1);
		
		map.put("errorCode", jmvo1.getErrorCode());
		logger.debug("errorCode: " + jmvo1.getErrorCode());
		
		ch_dvn="01";
		
		if("0".equals(jmvo1.getErrorCode()) && "01".equals(ch_dvn)){
			MMTI0305VO jmvo2 = new MMTI0305VO();
			jmvo2.setSrch_cnd__proc_dvn("03");
			jmvo2.setSrch_cnd__plno(jmvo.getPlno());
			jmvo2.setSrch_cnd__plan_no(jmvo.getPlan_no());
			jmvo2.setSrch_cnd__hdlr_empno("80000176");
			jmvo2 = mileageTobeService.chatMMTI0305VO(jmvo2);
			logger.debug("rtun_cd: " + jmvo2.getSrch_rsl__rtun_cd() + ", rtun_msg: " + jmvo2.getSrch_rsl__rtun_msg());
			map.put("rtun_cd", jmvo2.getSrch_rsl__rtun_cd());
			map.put("rtun_msg", jmvo2.getSrch_rsl__rtun_msg());

			map.put("z_resp_cd", jmvo2.getZ_resp_cd());
			map.put("z_resp_msg", jmvo2.getZ_resp_msg());
		}
		
		int insertRow = 0;
		
		// VO SET
		mbtr01001vo.setPboxNo(jmvo.getSms_ts_bvan());
		mbtr01001vo.setApdxFlRutNm("");
		mbtr01001vo.setFrstIpmnEmpno("82101685");
		mbtr01001vo.setFnalAmdrEmpno("82101685");
		
		insertRow = mileageTobeService.insertTest(mbtr01001vo);
		if(insertRow < 1){
			logger.info("#### 사서함번호: " + StringUtil.nvl(mbtr01001vo.getPboxNo()) + "####");
			logger.info("#### insert 결과: Fail ####");
		}else{
			logger.info("#### insert 결과: Success ####");
		}
		
		return map;
	}
	
	//aiocr용
	@RequestMapping(value="/aiocr_chat_ml1")
	public String aiocr_chat_ml1(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		MMTI0213VO jmvo = new MMTI0213VO();
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("p")));
		jmvo = mileageTobeService.chatMMTI0213VO(jmvo);
		String ch_dvn = StringUtil.nvl(request.getParameter("ch_dvn"));
		HttpSession session = request.getSession();
		session.setAttribute("ch_dvn", ch_dvn);

		request.setAttribute("p", request.getParameter("p"));
		request.setAttribute("ch_dvn", ch_dvn);
		request.setAttribute("jmvo", jmvo);
		return "/counter/carrider/tobe/aiocr_chat_ml1";
	}
	
	//aiocr용
	@RequestMapping(value="/aiocr_chat_ml2")
	public String aiocr_chat_ml2(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		MMTI0213VO jmvo = new MMTI0213VO();
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("p")));
		jmvo = mileageTobeService.chatMMTI0213VO(jmvo);
		String ch_dvn = StringUtil.nvl(request.getParameter("ch_dvn"));
		
		request.setAttribute("p", request.getParameter("p"));
		request.setAttribute("ch_dvn", ch_dvn);
		request.setAttribute("jmvo", jmvo);
		return "/counter/carrider/tobe/aiocr_chat_ml2";
	}
	
	//aiocr용
	@RequestMapping(value="/aiocr_chat_ml2_1")
	public String aiocr_chat_ml2_1(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		MMTI0213VO jmvo = new MMTI0213VO();
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("p")));
		String ch_dvn = StringUtil.nvl(request.getParameter("ch_dvn"));
		jmvo = mileageTobeService.chatMMTI0213VO(jmvo);
		
		HttpSession session = request.getSession();
		Object[] imgfile = (Object[]) session.getAttribute("imgfile");
		if(imgfile != null) {
			byte[] file = (byte[]) imgfile[0];
			logger.debug("file.length: " + file.length);
			request.setAttribute("imgsrc", "data:image/jpeg;base64," + new String(Base64.encodeBase64(file)));
		}
		
		request.setAttribute("p", request.getParameter("p"));
		session.setAttribute("p", request.getParameter("p"));
		request.setAttribute("ch_dvn", ch_dvn);
		request.setAttribute("jmvo", jmvo);
		return "/counter/carrider/tobe/aiocr_chat_ml2_1";
	}
	
	@RequestMapping(value="/chat_ml1")
	public String chat_ml1(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		MMTI0213VO jmvo = new MMTI0213VO();
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("p")));
		jmvo = mileageTobeService.chatMMTI0213VO(jmvo);
		String ch_dvn = StringUtil.nvl(request.getParameter("ch_dvn"));
		HttpSession session = request.getSession();
		session.setAttribute("ch_dvn", ch_dvn);

		request.setAttribute("p", request.getParameter("p"));
		request.setAttribute("ch_dvn", ch_dvn);
		request.setAttribute("jmvo", jmvo);
		return "/counter/carrider/tobe/chat_ml1";
	}
	
	@RequestMapping(value="/chat_ml2")
	public String chat_ml2(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		MMTI0213VO jmvo = new MMTI0213VO();
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("p")));
		jmvo = mileageTobeService.chatMMTI0213VO(jmvo);
		String ch_dvn = StringUtil.nvl(request.getParameter("ch_dvn"));
		
		request.setAttribute("p", request.getParameter("p"));
		request.setAttribute("ch_dvn", ch_dvn);
		request.setAttribute("jmvo", jmvo);
		return "/counter/carrider/tobe/chat_ml2";
	}
	
	@RequestMapping(value="/chat_ml2_1")
	public String chat_ml2_1(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		MMTI0213VO jmvo = new MMTI0213VO();
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("p")));
		String ch_dvn = StringUtil.nvl(request.getParameter("ch_dvn"));
		jmvo = mileageTobeService.chatMMTI0213VO(jmvo);
		
		HttpSession session = request.getSession();
		Object[] imgfile = (Object[]) session.getAttribute("imgfile");
		if(imgfile != null) {
			byte[] file = (byte[]) imgfile[0];
			logger.debug("file.length: " + file.length);
			request.setAttribute("imgsrc", "data:image/jpeg;base64," + new String(Base64.encodeBase64(file)));
		}
		
		request.setAttribute("p", request.getParameter("p"));
		session.setAttribute("p", request.getParameter("p"));
		request.setAttribute("ch_dvn", ch_dvn);
		request.setAttribute("jmvo", jmvo);
		return "/counter/carrider/tobe/chat_ml2_1";
	}
	
	@RequestMapping(value="/chat_ml3")
	public String chat_ml3(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		HttpSession session = request.getSession();
		MMTI0213VO jmvo = new MMTI0213VO();		
//		MBTT02001VO mbtt02001vo = new MBTT02001VO();
//		String scrnNm = "chat_ml3";
		
//		jmvo.setSms_ts_bvan(aes256Decrypt((String)session.getAttribute("p")));
		jmvo.setSms_ts_bvan(StringUtil.nvl(aes256Decrypt((String)session.getAttribute("p"))));
		jmvo = mileageTobeService.chatMMTI0213VO(jmvo);
		
		String ch_dvn = StringUtil.nvl(request.getParameter("ch_dvn"));
		
		String exp_exca_plan_rsl_cd = (String)session.getAttribute("exp_exca_plan_rsl_cd");
		if("1".equals(jmvo.getTrv_dstc_splc_exca_yn())) {
			if(exp_exca_plan_rsl_cd.equals("11") || exp_exca_plan_rsl_cd.equals("13") || exp_exca_plan_rsl_cd.equals("14")) {

				MMTI0291VO jmvo1 = new MMTI0291VO();
				jmvo1.setTrv_dstc_exca_mtt__exca_bz_proc_dvn("2");
				jmvo1.setTrv_dstc_exca_mtt__plno(StringUtil.nvl(request.getParameter("plno")));
				jmvo1.setTrv_dstc_exca_mtt__plan_no(StringUtil.nvl(request.getParameter("exp_exca_plan_no")));
				jmvo1.setTrv_dstc_exca_mtt__exca_rtrn_dvn("");
				jmvo1.setTrv_dstc_exca_mtt__pdc_sr_dvn(StringUtil.nvl(request.getParameter("pdc_sr_dvn")));
				jmvo1.setTrv_dstc_exca_mtt__adc_rtrn_dvn(StringUtil.nvl(request.getParameter("adc_rtrn_dvn")));
				jmvo1.setTrv_dstc_exca_mtt__adc_rtrn_prm(StringUtil.nvl(request.getParameter("adc_rtrn_prm")));
				jmvo1.setTrv_dstc_exca_mtt__scrn_proc_cd(StringUtil.nvl(request.getParameter("exp_exca_plan_rsl_cd")));
				jmvo1.setTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn(jmvo.getTrv_dstc_splc_exca_yn());
				jmvo1.setTrv_dstc_exca_mtt__pbox_no(jmvo.getSms_ts_bvan());
				jmvo1.setTrv_dstc_exca_mtt__hdlr_empno("80000176");
				jmvo1 = mileageTobeService.chatMMTI0291VO(jmvo1);
				
				request.setAttribute("z_resp_cd", jmvo1.getZ_resp_cd());
				request.setAttribute("z_resp_msg", jmvo1.getZ_resp_msg());
				session.setAttribute("z_resp_cd", jmvo1.getZ_resp_cd());
				session.setAttribute("z_resp_msg", jmvo1.getZ_resp_msg());
				
				// 이미지 중복이면 확정신청페이지
				if("1".equals(jmvo1.getTrv_dstc_exca_mtt__imag_dup_yn())){
					exp_exca_plan_rsl_cd = "14";
				}
				
				// CM 상품이고, 화면처리코드 IN(02, 14) or 이미지 중복
				
				if("CM".equals(jmvo1.getTrv_dstc_exca_mtt__pdc_sr_dvn()) && 
						("02".equals(jmvo1.getTrv_dstc_exca_mtt__scrn_proc_cd())
						|| "14".equals(jmvo1.getTrv_dstc_exca_mtt__scrn_proc_cd()))){
					
					MMTI0015VO mmti0015vo = new MMTI0015VO();
					mmti0015vo.setFunt_key("00");
					mmti0015vo.setPlan_no(jmvo1.getTrv_dstc_exca_mtt__plan_no());
					mmti0015vo = mileageTobeService.getMMTI0015VO(mmti0015vo);
					
					logger.debug("##### MMTI0015 시작 ##########################");
					logger.debug("##### 고객식별번호: " + mmti0015vo.getPlhd__cust_dcmt_no() + " ##########################");
					logger.debug("##### 고객번호: " + mmti0015vo.getPlhd__cust_no() + " ##########################");
					logger.debug("##### 고객명: " + mmti0015vo.getPlhd__cust_nm() + " ##########################");
					logger.debug("##### 이메일: " + mmti0015vo.getPlhd__eml() + " ##########################");
					logger.debug("##### 지역번호: " + mmti0015vo.getPlhd_cntp_if__tlp_arno() + " ##########################");
					logger.debug("##### 국번호: " + mmti0015vo.getPlhd_cntp_if__tlp_ofno() + " ##########################");
					logger.debug("##### 개별번호: " + mmti0015vo.getPlhd_cntp_if__tlp_idvno() + " ##########################");
					
					XTEM0021VO xtem0021vo = new XTEM0021VO();
					xtem0021vo.setCnsl_rpt_no("");						// 상담접수번호				
					xtem0021vo.setCm_bz_dvcd("05");
					xtem0021vo.setCnsl_typ_dvcd("07");
					xtem0021vo.setCm_plan_no(jmvo1.getTrv_dstc_exca_mtt__plan_no());
					xtem0021vo.setCnsl_rpy_dvcd("1");
					xtem0021vo.setCnsl_rpt_dttm(getDayTime());			// 현재년월일시분초 14자리
					xtem0021vo.setCust_nm(mmti0015vo.getPlhd__cust_nm());
					xtem0021vo.setCust_no(mmti0015vo.getPlhd__cust_no());
					
					String cust_dcmt_no = SeedUtil.decrypt(mmti0015vo.getPlhd__cust_dcmt_no());
					
					if("1".equals(cust_dcmt_no.substring(6, 7)) || "2".equals(cust_dcmt_no.substring(6, 7))
						|| "5".equals(cust_dcmt_no.substring(6, 7)) || "6".equals(cust_dcmt_no.substring(6, 7))){
						xtem0021vo.setBrth("19" + cust_dcmt_no.substring(0, 6));
					} else{
						xtem0021vo.setBrth("20" + cust_dcmt_no.substring(0, 6));
					}
					// xtem0021vo.setBrth("");  							// 생년월일
					xtem0021vo.setSx_cd(cust_dcmt_no.substring(6, 7));
					xtem0021vo.setEml_adr(mmti0015vo.getPlhd__eml());
					xtem0021vo.setClp_tlcno(mmti0015vo.getPlhd_cntp_if__tlp_arno());
					xtem0021vo.setClp_ofno(mmti0015vo.getPlhd_cntp_if__tlp_ofno());
					xtem0021vo.setClp_idvno(mmti0015vo.getPlhd_cntp_if__tlp_idvno());
					xtem0021vo.setCnsl_rsvt_dt("99990101");
					xtem0021vo.setCnsl_rsvt_time_cd("1");
					xtem0021vo.setCnsl_cn("최종주행거리사진등록/만기정산");
					xtem0021vo.setCnsl_aply_csn_yn("1");
					xtem0021vo.setUrl_adr("");
					xtem0021vo.setCm_ctrmf_tpcd("32");
					xtem0021vo.setFrst_ipmn_empno("80000028");
					xtem0021vo.setFrst_ipnpt_dttm(getDayTime());		// 현재년월일시분초 14자리	
					
					xtem0021vo = mileageTobeService.getXTEM0021VO(xtem0021vo);
					logger.debug("##### XTEM0021 시작 ##########################");
					logger.debug("##### 처리결과: [ " + xtem0021vo.getProc_rtn() + " ] ##########################");
				}
			}
		}
		
		request.setAttribute("p",							request.getParameter("p"));
		request.setAttribute("jmvo",						jmvo);
		request.setAttribute("exp_exca_plan_rsl_cd",		exp_exca_plan_rsl_cd);
		request.setAttribute("adc_rtrn_dvn",				request.getParameter("adc_rtrn_dvn"));
		request.setAttribute("adc_rtrn_prm",				request.getParameter("adc_rtrn_prm"));
		request.setAttribute("plno",						request.getParameter("plno"));
		request.setAttribute("exp_exca_plan_no",			request.getParameter("exp_exca_plan_no"));
		request.setAttribute("exp_exca_plan_bse_dd",		request.getParameter("exp_exca_plan_bse_dd"));
		request.setAttribute("aut_cgnt_vh_no",				request.getParameter("aut_cgnt_vh_no"));
		request.setAttribute("aut_cgnt_vh_no_rsl_cd",		request.getParameter("aut_cgnt_vh_no_rsl_cd"));
		request.setAttribute("aut_cgnt_trv_dstc",			request.getParameter("aut_cgnt_trv_dstc"));
		request.setAttribute("aut_cgnt_trv_dstc_rsl_cd",	request.getParameter("aut_cgnt_trv_dstc_rsl_cd"));
		request.setAttribute("exp_exca_plan_proc_dvn",		request.getParameter("exp_exca_plan_proc_dvn"));
		request.setAttribute("cnv_trv_dstc",				request.getParameter("cnv_trv_dstc"));
		request.setAttribute("plhd_cust_nm",				request.getParameter("plhd_cust_nm"));
		request.setAttribute("pdc_sr_dvn",					request.getParameter("pdc_sr_dvn"));
		request.setAttribute("errorCode",					request.getParameter("errorCode"));
		request.setAttribute("ch_dvn",						ch_dvn);
		
		session.setAttribute("p",							session.getAttribute("p"));
		session.setAttribute("jmvo",						jmvo);
		session.setAttribute("exp_exca_plan_rsl_cd",		exp_exca_plan_rsl_cd);
		session.setAttribute("adc_rtrn_dvn",				session.getAttribute("adc_rtrn_dvn"));
		session.setAttribute("adc_rtrn_prm",				session.getAttribute("adc_rtrn_prm"));
		session.setAttribute("plno",						session.getAttribute("plno"));
		session.setAttribute("exp_exca_plan_no",			session.getAttribute("exp_exca_plan_no"));
		session.setAttribute("exp_exca_plan_bse_dd",		session.getAttribute("exp_exca_plan_bse_dd"));
		session.setAttribute("aut_cgnt_vh_no",				session.getAttribute("aut_cgnt_vh_no"));
		session.setAttribute("aut_cgnt_vh_no_rsl_cd",		session.getAttribute("aut_cgnt_vh_no_rsl_cd"));
		session.setAttribute("aut_cgnt_trv_dstc",			session.getAttribute("aut_cgnt_trv_dstc"));
		session.setAttribute("aut_cgnt_trv_dstc_rsl_cd",	session.getAttribute("aut_cgnt_trv_dstc_rsl_cd"));
		session.setAttribute("exp_exca_plan_proc_dvn",		session.getAttribute("exp_exca_plan_proc_dvn"));
		session.setAttribute("cnv_trv_dstc",				session.getAttribute("cnv_trv_dstc"));
		session.setAttribute("plhd_cust_nm",				session.getAttribute("plhd_cust_nm"));
		session.setAttribute("pdc_sr_dvn",					session.getAttribute("pdc_sr_dvn"));
		session.setAttribute("errorCode",					session.getAttribute("errorCode"));
		request.setAttribute("ch_dvn",						ch_dvn);
		
		return "/counter/carrider/tobe/chat_ml3";
	}
	
	@RequestMapping(value="/chat_ml3_1")
	public @ResponseBody Map<String, String> chat_ml3_1(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		Map<String, String> map = new HashMap<String, String>();
		MMTI0291VO jmvo = new MMTI0291VO();
//		MBTT02001VO mbtt02001vo = new MBTT02001VO();
		HttpSession session = request.getSession();
//		String scrnNm = "chat_ml3_1";
		jmvo.setTrv_dstc_exca_mtt__exca_bz_proc_dvn("2");
		jmvo.setTrv_dstc_exca_mtt__plno(StringUtil.nvl(request.getParameter("plno")));
		jmvo.setTrv_dstc_exca_mtt__plan_no(StringUtil.nvl(request.getParameter("exp_exca_plan_no")));
		jmvo.setTrv_dstc_exca_mtt__exca_rtrn_dvn("");
		jmvo.setTrv_dstc_exca_mtt__pdc_sr_dvn(StringUtil.nvl(request.getParameter("pdc_sr_dvn")));
		jmvo.setTrv_dstc_exca_mtt__adc_rtrn_dvn(StringUtil.nvl(request.getParameter("adc_rtrn_dvn")));
		jmvo.setTrv_dstc_exca_mtt__adc_rtrn_prm(StringUtil.nvl(request.getParameter("adc_rtrn_prm")));
		jmvo.setTrv_dstc_exca_mtt__scrn_proc_cd(StringUtil.nvl(request.getParameter("exp_exca_plan_rsl_cd")));
		jmvo.setTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn(StringUtil.nvl(request.getParameter("trv_dstc_splc_exca_yn")));
		jmvo.setTrv_dstc_exca_mtt__pbox_no(StringUtil.nvl(request.getParameter("pbox_no")));
		jmvo = mileageTobeService.chatMMTI0291VO(jmvo);

		map.put("trv_dstc_exca_mtt__exca_bz_proc_dvn",			jmvo.getTrv_dstc_exca_mtt__exca_bz_proc_dvn());
		map.put("trv_dstc_exca_mtt__plno", 						jmvo.getTrv_dstc_exca_mtt__plno());
		map.put("trv_dstc_exca_mtt__plan_no", 					jmvo.getTrv_dstc_exca_mtt__plan_no());
		map.put("trv_dstc_exca_mtt__plan_dt", 					jmvo.getTrv_dstc_exca_mtt__plan_dt());
		map.put("trv_dstc_exca_mtt__exca_rtrn_dvn", 			jmvo.getTrv_dstc_exca_mtt__exca_rtrn_dvn());
		map.put("trv_dstc_exca_mtt__bank_cd", 					jmvo.getTrv_dstc_exca_mtt__bank_cd());
		map.put("trv_dstc_exca_mtt__acc_no", 					jmvo.getTrv_dstc_exca_mtt__acc_no());
		map.put("trv_dstc_exca_mtt__adc_rtrn_dvn", 				jmvo.getTrv_dstc_exca_mtt__adc_rtrn_dvn());
		map.put("trv_dstc_exca_mtt__adc_rtrn_prm", 				jmvo.getTrv_dstc_exca_mtt__adc_rtrn_prm());
		map.put("trv_dstc_exca_mtt__cnv_trv_dstc", 				jmvo.getTrv_dstc_exca_mtt__cnv_trv_dstc());
		map.put("trv_dstc_exca_mtt__nrm_proc_yn", 				jmvo.getTrv_dstc_exca_mtt__nrm_proc_yn());
		map.put("trv_dstc_exca_mtt__aut_cgnt_vh_no_eqal_yn", 	jmvo.getTrv_dstc_exca_mtt__aut_cgnt_vh_no_eqal_yn());
		map.put("trv_dstc_exca_mtt__aut_cgnt_trv_dstc_eqal_yn",	jmvo.getTrv_dstc_exca_mtt__aut_cgnt_trv_dstc_eqal_yn());
		map.put("trv_dstc_exca_mtt__rnw_plno", 					jmvo.getTrv_dstc_exca_mtt__rnw_plno());
		map.put("trv_dstc_exca_mtt__hdlr_empno", 				jmvo.getTrv_dstc_exca_mtt__hdlr_empno());
		map.put("trv_dstc_exca_mtt__aut_cgnt_trv_dstc_rsl_cd", 	jmvo.getTrv_dstc_exca_mtt__aut_cgnt_trv_dstc_rsl_cd());
		map.put("trv_dstc_exca_mtt__plhd_cust_nm", 				jmvo.getTrv_dstc_exca_mtt__plhd_cust_nm());
		map.put("trv_dstc_exca_mtt__pdc_sr_dvn", 				jmvo.getTrv_dstc_exca_mtt__pdc_sr_dvn());
		map.put("trv_dstc_exca_mtt__scrn_proc_cd", 				jmvo.getTrv_dstc_exca_mtt__scrn_proc_cd());
		map.put("trv_dstc_exca_mtt__arc_trm_str_dt", 			jmvo.getTrv_dstc_exca_mtt__arc_trm_str_dt());
		map.put("z_resp_cd",									jmvo.getZ_resp_cd());
		
		return map;
	}
	
	@RequestMapping(value="/chat_ml4")
	public String chat_ml4(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		MMTI0213VO jmvo = new MMTI0213VO();
//		MBTT02001VO mbtt02001vo = new MBTT02001VO();
//		String scrnNm = "chat_ml4";
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("p")));
		jmvo = mileageTobeService.chatMMTI0213VO(jmvo);

		String gubun = request.getParameter("gubun");
		String ch_dvn = StringUtil.nvl(request.getParameter("ch_dvn"));
		request.setAttribute("p",							request.getParameter("p"));
		request.setAttribute("jmvo",						jmvo);
		request.setAttribute("exp_exca_plan_rsl_cd",		request.getParameter("exp_exca_plan_rsl_cd"));
		request.setAttribute("adc_rtrn_dvn",				request.getParameter("adc_rtrn_dvn"));
		request.setAttribute("adc_rtrn_prm",				request.getParameter("adc_rtrn_prm"));
		request.setAttribute("plno",						request.getParameter("plno"));
		request.setAttribute("exp_exca_plan_no",			request.getParameter("exp_exca_plan_no"));
		request.setAttribute("exp_exca_plan_bse_dd",		request.getParameter("exp_exca_plan_bse_dd"));
		request.setAttribute("aut_cgnt_vh_no",				request.getParameter("aut_cgnt_vh_no"));
		request.setAttribute("aut_cgnt_vh_no_rsl_cd",		request.getParameter("aut_cgnt_vh_no_rsl_cd"));
		request.setAttribute("aut_cgnt_trv_dstc",			request.getParameter("aut_cgnt_trv_dstc"));
		request.setAttribute("aut_cgnt_trv_dstc_rsl_cd",	request.getParameter("aut_cgnt_trv_dstc_rsl_cd"));
		request.setAttribute("cnv_trv_dstc",				request.getParameter("cnv_trv_dstc"));
		request.setAttribute("plhd_cust_nm",				request.getParameter("plhd_cust_nm"));
		request.setAttribute("pdc_sr_dvn",					request.getParameter("pdc_sr_dvn"));
		request.setAttribute("gubun",						gubun);
		request.setAttribute("ch_dvn", 						ch_dvn);
		
		if("2".equals(gubun) || "3".equals(gubun)) {
			MMTI0291VO jmvo1 = new MMTI0291VO();
			
			if("1".equals(request.getParameter("skip"))) {
				jmvo1.setTrv_dstc_exca_mtt__exca_bz_proc_dvn(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__exca_bz_proc_dvn")));
				jmvo1.setTrv_dstc_exca_mtt__plno(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__plno")));
				jmvo1.setTrv_dstc_exca_mtt__plan_no(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__plan_no")));
				jmvo1.setTrv_dstc_exca_mtt__plan_dt(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__plan_dt")));
				jmvo1.setTrv_dstc_exca_mtt__exca_rtrn_dvn(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__exca_rtrn_dvn")));
				jmvo1.setTrv_dstc_exca_mtt__bank_cd(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__bank_cd")));
				jmvo1.setTrv_dstc_exca_mtt__acc_no(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__acc_no")));
				jmvo1.setTrv_dstc_exca_mtt__adc_rtrn_dvn(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__adc_rtrn_dvn")));
				jmvo1.setTrv_dstc_exca_mtt__adc_rtrn_prm(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__adc_rtrn_prm")));
				jmvo1.setTrv_dstc_exca_mtt__cnv_trv_dstc(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__cnv_trv_dstc")));
				jmvo1.setTrv_dstc_exca_mtt__nrm_proc_yn(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__nrm_proc_yn")));
				jmvo1.setTrv_dstc_exca_mtt__aut_cgnt_vh_no_eqal_yn(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__aut_cgnt_vh_no_eqal_yn")));
				jmvo1.setTrv_dstc_exca_mtt__aut_cgnt_trv_dstc_eqal_yn(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__aut_cgnt_trv_dstc_eqal_yn")));
				jmvo1.setTrv_dstc_exca_mtt__rnw_plno(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__rnw_plno")));
				jmvo1.setTrv_dstc_exca_mtt__hdlr_empno("80000176");
				jmvo1.setTrv_dstc_exca_mtt__aut_cgnt_trv_dstc_rsl_cd(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__aut_cgnt_trv_dstc_rsl_cd")));
				jmvo1.setTrv_dstc_exca_mtt__plhd_cust_nm(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__plhd_cust_nm")));
				jmvo1.setTrv_dstc_exca_mtt__pdc_sr_dvn(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__pdc_sr_dvn")));
				jmvo1.setTrv_dstc_exca_mtt__scrn_proc_cd(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__scrn_proc_cd")));
				jmvo1.setTrv_dstc_exca_mtt__arc_trm_str_dt(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__arc_trm_str_dt")));
				jmvo1.setZ_resp_cd(StringUtil.nvl(request.getParameter("z_resp_cd")));
			}
			else {
				jmvo1.setTrv_dstc_exca_mtt__exca_bz_proc_dvn("2");
				jmvo1.setTrv_dstc_exca_mtt__plno(request.getParameter("plno"));
				jmvo1.setTrv_dstc_exca_mtt__plan_no(request.getParameter("exp_exca_plan_no"));
				jmvo1.setTrv_dstc_exca_mtt__exca_rtrn_dvn("3".equals(gubun) ? "1" : "2");
				jmvo1.setTrv_dstc_exca_mtt__pdc_sr_dvn(request.getParameter("pdc_sr_dvn"));
				jmvo1.setTrv_dstc_exca_mtt__scrn_proc_cd(request.getParameter("exp_exca_plan_rsl_cd"));
				
				if("3".equals(gubun)) {
					String account = "";
					try {
						account = TransKey.decode("account", request);
					}
					catch(Exception e) {
						logger.debug(e.getMessage());
						account = request.getParameter("account");
					}
					logger.debug("account: " + account);
					jmvo1.setTrv_dstc_exca_mtt__bank_cd(request.getParameter("bank"));
					jmvo1.setTrv_dstc_exca_mtt__acc_no(account);
				}
				jmvo1.setTrv_dstc_exca_mtt__adc_rtrn_dvn(request.getParameter("adc_rtrn_dvn"));
				jmvo1.setTrv_dstc_exca_mtt__adc_rtrn_prm(request.getParameter("adc_rtrn_prm"));
				jmvo1.setTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn(jmvo.getTrv_dstc_splc_exca_yn());
				jmvo1.setTrv_dstc_exca_mtt__pbox_no(jmvo.getSms_ts_bvan());
				jmvo1.setTrv_dstc_exca_mtt__hdlr_empno("80000176");
				jmvo1 = mileageTobeService.chatMMTI0291VO(jmvo1);
			}
			
			// 부적정/중복 이미지인 경우 화면처리코드 02 
			if("1".equals(jmvo1.getTrv_dstc_exca_mtt__imag_dup_yn())){
				jmvo1.setTrv_dstc_exca_mtt__scrn_proc_cd("02");
			}
			
			// CM 상품이고, 화면처리코드 IN(02, 14) or 이미지 중복
			
			if("CM".equals(jmvo1.getTrv_dstc_exca_mtt__pdc_sr_dvn()) && 
					("02".equals(jmvo1.getTrv_dstc_exca_mtt__scrn_proc_cd())
					|| "14".equals(jmvo1.getTrv_dstc_exca_mtt__scrn_proc_cd()))){
				
				MMTI0015VO mmti0015vo = new MMTI0015VO();
				mmti0015vo.setFunt_key("00");
				mmti0015vo.setPlan_no(jmvo1.getTrv_dstc_exca_mtt__plan_no());
				mmti0015vo = mileageTobeService.getMMTI0015VO(mmti0015vo);
				
				logger.debug("##### MMTI0015 시작 ##########################");
				logger.debug("##### 고객식별번호: " + mmti0015vo.getPlhd__cust_dcmt_no() + " ##########################");
				logger.debug("##### 고객번호: " + mmti0015vo.getPlhd__cust_no() + " ##########################");
				logger.debug("##### 고객명: " + mmti0015vo.getPlhd__cust_nm() + " ##########################");
				logger.debug("##### 이메일: " + mmti0015vo.getPlhd__eml() + " ##########################");
				logger.debug("##### 지역번호: " + mmti0015vo.getPlhd_cntp_if__tlp_arno() + " ##########################");
				logger.debug("##### 국번호: " + mmti0015vo.getPlhd_cntp_if__tlp_ofno() + " ##########################");
				logger.debug("##### 개별번호: " + mmti0015vo.getPlhd_cntp_if__tlp_idvno() + " ##########################");
				
				XTEM0021VO xtem0021vo = new XTEM0021VO();
				xtem0021vo.setCnsl_rpt_no("");						// 상담접수번호				
				xtem0021vo.setCm_bz_dvcd("05");
				xtem0021vo.setCnsl_typ_dvcd("07");
				xtem0021vo.setCm_plan_no(jmvo1.getTrv_dstc_exca_mtt__plan_no());
				xtem0021vo.setCnsl_rpy_dvcd("1");
				xtem0021vo.setCnsl_rpt_dttm(getDayTime());			// 현재년월일시분초 14자리
				xtem0021vo.setCust_nm(mmti0015vo.getPlhd__cust_nm());
				xtem0021vo.setCust_no(mmti0015vo.getPlhd__cust_no());
				
				String cust_dcmt_no = SeedUtil.decrypt(mmti0015vo.getPlhd__cust_dcmt_no());
				
				if("1".equals(cust_dcmt_no.substring(6, 7)) || "2".equals(cust_dcmt_no.substring(6, 7))
					|| "5".equals(cust_dcmt_no.substring(6, 7)) || "6".equals(cust_dcmt_no.substring(6, 7))){
					xtem0021vo.setBrth("19" + cust_dcmt_no.substring(0, 6));
				} else{
					xtem0021vo.setBrth("20" + cust_dcmt_no.substring(0, 6));
				}
				// xtem0021vo.setBrth("");  							// 생년월일
				xtem0021vo.setSx_cd(cust_dcmt_no.substring(6, 7));
				xtem0021vo.setEml_adr(mmti0015vo.getPlhd__eml());
				xtem0021vo.setClp_tlcno(mmti0015vo.getPlhd_cntp_if__tlp_arno());
				xtem0021vo.setClp_ofno(mmti0015vo.getPlhd_cntp_if__tlp_ofno());
				xtem0021vo.setClp_idvno(mmti0015vo.getPlhd_cntp_if__tlp_idvno());
				xtem0021vo.setCnsl_rsvt_dt("99990101");
				xtem0021vo.setCnsl_rsvt_time_cd("1");
				xtem0021vo.setCnsl_cn("최종주행거리사진등록/만기정산");
				xtem0021vo.setCnsl_aply_csn_yn("1");
				xtem0021vo.setUrl_adr("");
				xtem0021vo.setCm_ctrmf_tpcd("32");
				xtem0021vo.setFrst_ipmn_empno("80000028");
				xtem0021vo.setFrst_ipnpt_dttm(getDayTime());		// 현재년월일시분초 14자리	
				
				xtem0021vo = mileageTobeService.getXTEM0021VO(xtem0021vo);
				logger.debug("##### XTEM0021 시작 ##########################");
				logger.debug("##### 처리결과: [ " + xtem0021vo.getProc_rtn() + " ] ##########################");
			}
			
			request.setAttribute("jmvo1", jmvo1);		
		}
		
		return "/counter/carrider/tobe/chat_ml4";
	}

	@RequestMapping(value="/chat_ml4_1")
	public String chat_ml4_1(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
	
		HttpSession session = request.getSession();
		
		logger.debug("####### chat_ml4_1 값 확인 #######");
		logger.debug("p: " + StringUtil.nvl(request.getParameter("p")));
		logger.debug("plno: " + request.getParameter("plno"));
		logger.debug("exp_exca_plan_no: " + request.getParameter("exp_exca_plan_no"));
		logger.debug("cnv_trv_dstc: " + request.getParameter("cnv_trv_dstc"));
		logger.debug("pdc_sr_dvn: " + request.getParameter("pdc_sr_dvn"));
		logger.debug("exp_exca_plan_rsl_cd: " + request.getParameter("exp_exca_plan_rsl_cd"));
		logger.debug("adc_rtrn_dvn: " + request.getParameter("adc_rtrn_dvn"));
		logger.debug("adc_rtrn_prm: " + request.getParameter("adc_rtrn_prm"));
		
		session.setAttribute("p", request.getParameter("p"));
//		model.addAttribute("exp_exca_plan_rsl_cd",		request.getParameter("exp_exca_plan_rsl_cd"));
//		model.addAttribute("adc_rtrn_dvn",				request.getParameter("adc_rtrn_dvn"));
		
		// 증번 설번
		session.setAttribute("plno", request.getParameter("plno"));
		session.setAttribute("exp_exca_plan_no", request.getParameter("exp_exca_plan_no"));
//		model.addAttribute("exp_exca_plan_bse_dd",		request.getParameter("exp_exca_plan_bse_dd"));
//		model.addAttribute("aut_cgnt_vh_no",			request.getParameter("aut_cgnt_vh_no"));
//		model.addAttribute("aut_cgnt_vh_no_rsl_cd",		request.getParameter("aut_cgnt_vh_no_rsl_cd"));
//		model.addAttribute("aut_cgnt_trv_dstc",			request.getParameter("aut_cgnt_trv_dstc"));
//		model.addAttribute("aut_cgnt_trv_dstc_rsl_cd",	request.getParameter("aut_cgnt_trv_dstc_rsl_cd"));
		// 연환산 주행거리
		session.setAttribute("cnv_trv_dstc", request.getParameter("cnv_trv_dstc"));
		// 상품출처
		session.setAttribute("pdc_sr_dvn", request.getParameter("pdc_sr_dvn"));
		// 화면처리코드, 추징환급구분
		session.setAttribute("exp_exca_plan_rsl_cd", request.getParameter("exp_exca_plan_rsl_cd"));
		session.setAttribute("adc_rtrn_dvn", request.getParameter("adc_rtrn_dvn"));
		// 추징환급보험료(갱신보험료 차감금액)
		session.setAttribute("adc_rtrn_prm", request.getParameter("adc_rtrn_prm"));
		// 입력주행거리(ocr2에서 넘김)
		// model.addAttribute("trv_dstc1", request.getParameter("mileage1"));
		session.setAttribute("renewal", "01");
		
		return "/counter/carrider/tobe/chat_ml4_1";
	}
	
	@RequestMapping(value="/chat_ml4_2")
	public String chat_ml4_2(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
	
		HttpSession session = request.getSession();
		
		logger.debug("####### chat_ml4_2 값 확인 #######");
		logger.debug("p: " + (String)session.getAttribute("p"));
		logger.debug("plno: " + (String)session.getAttribute("plno"));
		logger.debug("exp_exca_plan_no: " + (String)session.getAttribute("exp_exca_plan_no"));
		//logger.debug("cnv_trv_dstc: " + (String)session.getAttribute("cnv_trv_dstc"));
		logger.debug("pdc_sr_dvn: " + (String)session.getAttribute("pdc_sr_dvn"));
		//logger.debug("appSeq: " + (String)session.getAttribute("appSeq"));
		logger.debug("exp_exca_plan_rsl_cd: " + (String)session.getAttribute("exp_exca_plan_rsl_cd"));
		logger.debug("adc_rtrn_dvn: " + (String)session.getAttribute("adc_rtrn_dvn"));
		logger.debug("adc_rtrn_prm: " + (String)session.getAttribute("adc_rtrn_prm"));
		
		MMTI0213VO jmvo = new MMTI0213VO();
		String p = (String) session.getAttribute("p");
		jmvo.setSms_ts_bvan(aes256Decrypt(p));
		jmvo = mileageTobeService.chatMMTI0213VO(jmvo);
		
		MMTI0291VO jmvo1 = new MMTI0291VO();
		jmvo1.setTrv_dstc_exca_mtt__exca_bz_proc_dvn("2");												// 정산업무처리구분 2:확정
		jmvo1.setTrv_dstc_exca_mtt__plno((String)session.getAttribute("plno"));							// 증권번호
		jmvo1.setTrv_dstc_exca_mtt__plan_no((String)session.getAttribute("exp_exca_plan_no"));			// 설계번호
		jmvo1.setTrv_dstc_exca_mtt__exca_rtrn_dvn("2");													// 갱신환급구분 2:갱신계약활용
		jmvo1.setTrv_dstc_exca_mtt__pdc_sr_dvn((String)session.getAttribute("pdc_sr_dvn"));				// 상품출처구분
		jmvo1.setTrv_dstc_exca_mtt__scrn_proc_cd((String)session.getAttribute("exp_exca_plan_rsl_cd"));	// 화면처리코드
		jmvo1.setTrv_dstc_exca_mtt__adc_rtrn_dvn((String)session.getAttribute("adc_rtrn_dvn"));			// 추징환급구분
		jmvo1.setTrv_dstc_exca_mtt__adc_rtrn_prm((String)session.getAttribute("adc_rtrn_prm"));			// 추징환급보험료
		jmvo1.setTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn(jmvo.getTrv_dstc_splc_exca_yn());				// 주행거리간편정산여부
		jmvo1.setTrv_dstc_exca_mtt__pbox_no(jmvo.getSms_ts_bvan());										// 사서함번호
		jmvo1.setTrv_dstc_exca_mtt__hdlr_empno("80000176");
		jmvo1 = mileageTobeService.chatMMTI0291VO(jmvo1);
		
		// 미환급대체 완료화면 CM상품 분기용
		session.setAttribute("sr_dvn", jmvo1.getTrv_dstc_exca_mtt__pdc_sr_dvn());
		
		// 부적정/중복 이미지인 경우 화면처리코드 02 
		if("1".equals(jmvo1.getTrv_dstc_exca_mtt__imag_dup_yn())){
			jmvo1.setTrv_dstc_exca_mtt__scrn_proc_cd("02");
		}
		request.setAttribute("jmvo1", jmvo1);
		
		// CM 상품이고, 화면처리코드 IN(02, 14) or 이미지 중복
		
		if("CM".equals(jmvo1.getTrv_dstc_exca_mtt__pdc_sr_dvn()) && 
				("02".equals(jmvo1.getTrv_dstc_exca_mtt__scrn_proc_cd())
				|| "14".equals(jmvo1.getTrv_dstc_exca_mtt__scrn_proc_cd()))){
			
			MMTI0015VO mmti0015vo = new MMTI0015VO();
			mmti0015vo.setFunt_key("00");
			mmti0015vo.setPlan_no(jmvo1.getTrv_dstc_exca_mtt__plan_no());
			mmti0015vo = mileageTobeService.getMMTI0015VO(mmti0015vo);
			
			logger.debug("##### MMTI0015 시작 ##########################");
			logger.debug("##### 고객식별번호: " + mmti0015vo.getPlhd__cust_dcmt_no() + " ##########################");
			logger.debug("##### 고객번호: " + mmti0015vo.getPlhd__cust_no() + " ##########################");
			logger.debug("##### 고객명: " + mmti0015vo.getPlhd__cust_nm() + " ##########################");
			logger.debug("##### 이메일: " + mmti0015vo.getPlhd__eml() + " ##########################");
			logger.debug("##### 지역번호: " + mmti0015vo.getPlhd_cntp_if__tlp_arno() + " ##########################");
			logger.debug("##### 국번호: " + mmti0015vo.getPlhd_cntp_if__tlp_ofno() + " ##########################");
			logger.debug("##### 개별번호: " + mmti0015vo.getPlhd_cntp_if__tlp_idvno() + " ##########################");
			
			XTEM0021VO xtem0021vo = new XTEM0021VO();
			xtem0021vo.setCnsl_rpt_no("");						// 상담접수번호				
			xtem0021vo.setCm_bz_dvcd("05");
			xtem0021vo.setCnsl_typ_dvcd("07");
			xtem0021vo.setCm_plan_no(jmvo1.getTrv_dstc_exca_mtt__plan_no());
			xtem0021vo.setCnsl_rpy_dvcd("1");
			xtem0021vo.setCnsl_rpt_dttm(getDayTime());			// 현재년월일시분초 14자리
			xtem0021vo.setCust_nm(mmti0015vo.getPlhd__cust_nm());
			xtem0021vo.setCust_no(mmti0015vo.getPlhd__cust_no());
			
			String cust_dcmt_no = SeedUtil.decrypt(mmti0015vo.getPlhd__cust_dcmt_no());
			
			if("1".equals(cust_dcmt_no.substring(6, 7)) || "2".equals(cust_dcmt_no.substring(6, 7))
				|| "5".equals(cust_dcmt_no.substring(6, 7)) || "6".equals(cust_dcmt_no.substring(6, 7))){
				xtem0021vo.setBrth("19" + cust_dcmt_no.substring(0, 6));
			} else{
				xtem0021vo.setBrth("20" + cust_dcmt_no.substring(0, 6));
			}
			xtem0021vo.setSx_cd(cust_dcmt_no.substring(6, 7));
			xtem0021vo.setEml_adr(mmti0015vo.getPlhd__eml());
			xtem0021vo.setClp_tlcno(mmti0015vo.getPlhd_cntp_if__tlp_arno());
			xtem0021vo.setClp_ofno(mmti0015vo.getPlhd_cntp_if__tlp_ofno());
			xtem0021vo.setClp_idvno(mmti0015vo.getPlhd_cntp_if__tlp_idvno());
			xtem0021vo.setCnsl_rsvt_dt("99990101");
			xtem0021vo.setCnsl_rsvt_time_cd("1");
			xtem0021vo.setCnsl_cn("최종주행거리사진등록/만기정산");
			xtem0021vo.setCnsl_aply_csn_yn("1");
			xtem0021vo.setUrl_adr("");
			xtem0021vo.setCm_ctrmf_tpcd("32");
			xtem0021vo.setFrst_ipmn_empno("80000028");
			xtem0021vo.setFrst_ipnpt_dttm(getDayTime());		// 현재년월일시분초 14자리	
			
			xtem0021vo = mileageTobeService.getXTEM0021VO(xtem0021vo);
			logger.debug("##### XTEM0021 시작 ##########################");
			logger.debug("##### 처리결과: [ " + xtem0021vo.getProc_rtn() + " ] ##########################");
		}
		// model.addAttribute("trv_dstc1", request.getParameter("mileage1"));

		session.setAttribute("renewal", "02");
		return "/counter/carrider/tobe/chat_ml4_1";
	}
	
	
	@RequestMapping(value="/chat_ml5")
	public String chat_ml5(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		HttpSession session = request.getSession();
		MMTI0294VO jmvo = new MMTI0294VO();
		String ch_dvn = StringUtil.nvl(request.getParameter("ch_dvn"));
		String empno = StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__hdlr_empno"));
		empno = "80000176";
		String isCrd = StringUtil.nvl(request.getParameter("isCrd"));
		
		logger.info("######################### chat_ml5 test ");
		logger.info("isCrd: " + isCrd);
		
		if("Y".equals(isCrd)){
			// 카드취소에서 넘어온 추가가입: session
			logger.info("취급자사번: " + StringUtil.nvl((String)session.getAttribute("trv_dstc_exca_mtt__hdlr_empno")));
			logger.info("증번: " + StringUtil.nvl((String)session.getAttribute("trv_dstc_exca_mtt__plno")));
			logger.info("설번: " + StringUtil.nvl((String)session.getAttribute("trv_dstc_exca_mtt__plan_no")));
			logger.info("날짜" + StringUtil.nvl((String)session.getAttribute("rnw_plno")));
			logger.info("갱신증번: " + StringUtil.nvl((String)session.getAttribute("rnw_plno")));
			
			empno = StringUtil.nvl((String)session.getAttribute("trv_dstc_exca_mtt__hdlr_empno"));
			jmvo.setTrv_dstc_exca_mtt__plno(StringUtil.nvl((String)session.getAttribute("trv_dstc_exca_mtt__plno")));
			jmvo.setTrv_dstc_exca_mtt__plan_no(StringUtil.nvl((String)session.getAttribute("trv_dstc_exca_mtt__plan_no")));
			jmvo.setTrv_dstc_exca_mtt__plan_dt(StringUtil.nvl((String)session.getAttribute("trv_dstc_exca_mtt__plan_dt")));
			jmvo.setTrv_dstc_exca_mtt__rnw_plno(StringUtil.nvl((String)session.getAttribute("rnw_plno")));
			jmvo.setTrv_dstc_exca_mtt__hdlr_empno(empno);
		}else{ // 계좌환급에서 넘어온 추가가입: request
			empno = StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__hdlr_empno"));
			jmvo.setTrv_dstc_exca_mtt__plno(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__plno")));
			jmvo.setTrv_dstc_exca_mtt__plan_no(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__plan_no")));
			jmvo.setTrv_dstc_exca_mtt__plan_dt(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__plan_dt")));
			jmvo.setTrv_dstc_exca_mtt__rnw_plno(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__rnw_plno")));
			jmvo.setTrv_dstc_exca_mtt__hdlr_empno(empno);
		}
		
		jmvo = mileageTobeService.chatMMTI0294VO(jmvo);
		
		if("ZH001".equals(jmvo.getZ_resp_cd()) && session.getAttribute("imgfile") != null && session.getAttribute("exifDate") != null && !StringUtil.isEmpty(empno)) {
			Object[] imgfile = (Object[]) session.getAttribute("imgfile");
			String exifDate = (String) session.getAttribute("exifDate");

			mileageTobeService.regInfoToEdmsForMobileWeb3(empno, imgfile[0], exifDate, jmvo.getTrv_dstc_exca_mtt__rnw_plno() + "," + jmvo.getTrv_dstc_exca_mtt__rnw_plan_no());
		}
		
		request.setAttribute("jmvo", jmvo);
		request.setAttribute("ch_dvn", ch_dvn);
		
		return "/counter/carrider/tobe/chat_ml5";
	}
	
	@RequestMapping(value="/chatMlCancelCard")
	public @ResponseBody Map<String, String> chatMlCancelCard(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		HttpSession session = request.getSession();
		Map<String, String> map = new HashMap<String, String>();
		MMTI0213VO mmti0213vo = new MMTI0213VO();
		mmti0213vo.setSms_ts_bvan(aes256Decrypt((String)session.getAttribute("p")));
		String ch_dvn = StringUtil.nvl(request.getParameter("ch_dvn"));
		
		mmti0213vo = mileageTobeService.chatMMTI0213VO(mmti0213vo);
		
		MMTI0291VO mmti0291vo = new MMTI0291VO();
		mmti0291vo.setTrv_dstc_exca_mtt__exca_bz_proc_dvn("2");													// 정산업무처리구분 2:확정
		mmti0291vo.setTrv_dstc_exca_mtt__plno((String)session.getAttribute("plno"));							// 증권번호
		mmti0291vo.setTrv_dstc_exca_mtt__plan_no((String)session.getAttribute("exp_exca_plan_no"));				// 설계번호
		mmti0291vo.setTrv_dstc_exca_mtt__exca_rtrn_dvn("3");													// 갱신환급구분 3:카드부분취소
		mmti0291vo.setTrv_dstc_exca_mtt__pdc_sr_dvn((String)session.getAttribute("pdc_sr_dvn"));				// 상품출처구분
		mmti0291vo.setTrv_dstc_exca_mtt__scrn_proc_cd((String)session.getAttribute("exp_exca_plan_rsl_cd"));	// 화면처리코드
		mmti0291vo.setTrv_dstc_exca_mtt__adc_rtrn_dvn((String)session.getAttribute("adc_rtrn_dvn"));			// 추징환급구분
		mmti0291vo.setTrv_dstc_exca_mtt__adc_rtrn_prm((String)session.getAttribute("adc_rtrn_prm"));			// 추징환급보험료
		mmti0291vo.setTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn(mmti0213vo.getTrv_dstc_splc_exca_yn());			// 주행거리간편정산여부
		mmti0291vo.setTrv_dstc_exca_mtt__pbox_no(mmti0213vo.getSms_ts_bvan());									// 사서함번호
		
		mmti0291vo.setTrv_dstc_exca_mtt__crd_scn_cncl_pss_yn((String)session.getAttribute("crd_scn_cncl_pss_yn")); // 카드부분취소가능여부
		mmti0291vo.setTrv_dstc_exca_mtt__stlm_cdcp_nm((String)session.getAttribute("stlm_cdcp_nm"));			// 결제카드사명
		mmti0291vo.setTrv_dstc_exca_mtt__stlm_crd_no((String)session.getAttribute("stlm_crd_no"));				// 결제카드번호
		mmti0291vo = mileageTobeService.chatMMTI0291VO(mmti0291vo);
		
		if(mmti0291vo.getErrorCode().equals("0")){
			map.put("result", "y");
			session.setAttribute("scrn_proc_cd", mmti0291vo.getTrv_dstc_exca_mtt__scrn_proc_cd());
			session.setAttribute("rnw_plno", mmti0291vo.getTrv_dstc_exca_mtt__rnw_plno());
			session.setAttribute("pdc_sr_dvn", mmti0291vo.getTrv_dstc_exca_mtt__pdc_sr_dvn());
			
			// 아래 데이터 + 갱신증번: 추가가입위해 저장
			session.setAttribute("trv_dstc_exca_mtt__plno", mmti0291vo.getTrv_dstc_exca_mtt__plno());
			session.setAttribute("trv_dstc_exca_mtt__plan_no", mmti0291vo.getTrv_dstc_exca_mtt__plan_no());
			session.setAttribute("trv_dstc_exca_mtt__plan_dt", mmti0291vo.getTrv_dstc_exca_mtt__plan_dt());
			session.setAttribute("trv_dstc_exca_mtt__hdlr_empno", mmti0291vo.getTrv_dstc_exca_mtt__hdlr_empno());
			
			// 부적정/중복 이미지인 경우 화면처리코드 02 
			if("1".equals(mmti0291vo.getTrv_dstc_exca_mtt__imag_dup_yn())){
				mmti0291vo.setTrv_dstc_exca_mtt__scrn_proc_cd("02");
			}
			
			// CM 상품이고, 화면처리코드 IN(02, 14) or 이미지 중복
			
			if("CM".equals(mmti0291vo.getTrv_dstc_exca_mtt__pdc_sr_dvn()) && 
					("02".equals(mmti0291vo.getTrv_dstc_exca_mtt__scrn_proc_cd())
					|| "14".equals(mmti0291vo.getTrv_dstc_exca_mtt__scrn_proc_cd()))){
				
				MMTI0015VO mmti0015vo = new MMTI0015VO();
				mmti0015vo.setFunt_key("00");
				mmti0015vo.setPlan_no(mmti0291vo.getTrv_dstc_exca_mtt__plan_no());
				mmti0015vo = mileageTobeService.getMMTI0015VO(mmti0015vo);
				
				logger.debug("##### MMTI0015 시작 ##########################");
				logger.debug("##### 고객식별번호: " + mmti0015vo.getPlhd__cust_dcmt_no() + " ##########################");
				logger.debug("##### 고객번호: " + mmti0015vo.getPlhd__cust_no() + " ##########################");
				logger.debug("##### 고객명: " + mmti0015vo.getPlhd__cust_nm() + " ##########################");
				logger.debug("##### 이메일: " + mmti0015vo.getPlhd__eml() + " ##########################");
				logger.debug("##### 지역번호: " + mmti0015vo.getPlhd_cntp_if__tlp_arno() + " ##########################");
				logger.debug("##### 국번호: " + mmti0015vo.getPlhd_cntp_if__tlp_ofno() + " ##########################");
				logger.debug("##### 개별번호: " + mmti0015vo.getPlhd_cntp_if__tlp_idvno() + " ##########################");
				
				XTEM0021VO xtem0021vo = new XTEM0021VO();
				xtem0021vo.setCnsl_rpt_no("");						// 상담접수번호				
				xtem0021vo.setCm_bz_dvcd("05");
				xtem0021vo.setCnsl_typ_dvcd("07");
				xtem0021vo.setCm_plan_no(mmti0291vo.getTrv_dstc_exca_mtt__plan_no());
				xtem0021vo.setCnsl_rpy_dvcd("1");
				xtem0021vo.setCnsl_rpt_dttm(getDayTime());			// 현재년월일시분초 14자리
				xtem0021vo.setCust_nm(mmti0015vo.getPlhd__cust_nm());
				xtem0021vo.setCust_no(mmti0015vo.getPlhd__cust_no());
				
				String cust_dcmt_no = SeedUtil.decrypt(mmti0015vo.getPlhd__cust_dcmt_no());
				
				if("1".equals(cust_dcmt_no.substring(6, 7)) || "2".equals(cust_dcmt_no.substring(6, 7))
					|| "5".equals(cust_dcmt_no.substring(6, 7)) || "6".equals(cust_dcmt_no.substring(6, 7))){
					xtem0021vo.setBrth("19" + cust_dcmt_no.substring(0, 6));
				} else{
					xtem0021vo.setBrth("20" + cust_dcmt_no.substring(0, 6));
				}
				xtem0021vo.setSx_cd(cust_dcmt_no.substring(6, 7));
				xtem0021vo.setEml_adr(mmti0015vo.getPlhd__eml());
				xtem0021vo.setClp_tlcno(mmti0015vo.getPlhd_cntp_if__tlp_arno());
				xtem0021vo.setClp_ofno(mmti0015vo.getPlhd_cntp_if__tlp_ofno());
				xtem0021vo.setClp_idvno(mmti0015vo.getPlhd_cntp_if__tlp_idvno());
				xtem0021vo.setCnsl_rsvt_dt("99990101");
				xtem0021vo.setCnsl_rsvt_time_cd("1");
				xtem0021vo.setCnsl_cn("최종주행거리사진등록/만기정산");
				xtem0021vo.setCnsl_aply_csn_yn("1");
				xtem0021vo.setUrl_adr("");
				xtem0021vo.setCm_ctrmf_tpcd("32");
				xtem0021vo.setFrst_ipmn_empno("80000028");
				xtem0021vo.setFrst_ipnpt_dttm(getDayTime());		// 현재년월일시분초 14자리	
				
				xtem0021vo = mileageTobeService.getXTEM0021VO(xtem0021vo);
				logger.debug("##### XTEM0021 시작 ##########################");
				logger.debug("##### 처리결과: [ " + xtem0021vo.getProc_rtn() + " ] ##########################");
			}
		}else{
			map.put("result", "n");
			map.put("z_resp_msg", mmti0291vo.getZ_resp_msg());
		}
/*		
		//MMTI0213전문 정산이력테이블(MBTT02001) 적재
		MBTT02001VO mbtt02001vo = new MBTT02001VO();
		String scrnNm = "chatMlCancelCard";
		
		mbtt02001vo.setPboxNo(StringUtil.nvl(mmti0213vo.getSms_ts_bvan()));
		mbtt02001vo.setTlgIdVal("MMTI0213");
		mbtt02001vo.setEsbTrscId(StringUtil.nvl(mmti0213vo.getZ_trsc_id()));
		if("".equals(mmti0213vo.getPlno()) || null == mmti0213vo.getPlno()){
			mbtt02001vo.setPlno(" ");
		} else {
			mbtt02001vo.setPlno(StringUtil.nvl(mmti0213vo.getPlno()));
		}
		if("".equals(request.getParameter("exp_exca_plan_no")) || null == request.getParameter("exp_exca_plan_no")){
			mbtt02001vo.setPlanNo(" ");
		} else {
			mbtt02001vo.setPlanNo(StringUtil.nvl(request.getParameter("exp_exca_plan_no")));
		}
		if("".equals(mmti0213vo.getRnw_plno()) || null == mmti0213vo.getRnw_plno()){
			mbtt02001vo.setRnwPlno(" ");
		} else {
			mbtt02001vo.setRnwPlno(StringUtil.nvl(mmti0213vo.getRnw_plno()));
		}
		mbtt02001vo.setTlgProcRslCdVal(StringUtil.nvl(mmti0213vo.getZ_tlg_sp_cd()));
		mbtt02001vo.setTlgErrCdVal(StringUtil.nvl(mmti0213vo.getZ_trns_org_dvcd())+StringUtil.nvl(mmti0213vo.getZ_trns_org_cd()));
		if("".equals(request.getParameter("hdlrEmpno")) || null == request.getParameter("hdlrEmpno")){
			mbtt02001vo.setHdlrEmpno(" ");
		} else {
			mbtt02001vo.setHdlrEmpno(StringUtil.nvl(request.getParameter("hdlrEmpno")));
		}
		if("".equals(mmti0213vo.getPbox_no_dvcd()) || null == mmti0213vo.getPbox_no_dvcd()){
			mbtt02001vo.setPboxNoDvcd(" ");
		} else {
			mbtt02001vo.setPboxNoDvcd(StringUtil.nvl(mmti0213vo.getPbox_no_dvcd()));
		}
		if("".equals(mmti0213vo.getProc_dvn()) || null == mmti0213vo.getProc_dvn()){
			mbtt02001vo.setProcDvn(" ");
		} else {
			mbtt02001vo.setProcDvn(StringUtil.nvl(mmti0213vo.getProc_dvn()));
		}
		if("".equals(mmti0213vo.getTrv_dstc_exp_exca_dvcd()) || null == mmti0213vo.getTrv_dstc_exp_exca_dvcd()){
			mbtt02001vo.setTrvDstcExpExcaDvcd(" ");
		} else {
			mbtt02001vo.setTrvDstcExpExcaDvcd(StringUtil.nvl(mmti0213vo.getTrv_dstc_exp_exca_dvcd()));
		}
		if("".equals(mmti0213vo.getTrv_dstc_chng_aply_dvn()) || null == mmti0213vo.getTrv_dstc_chng_aply_dvn()){
			mbtt02001vo.setTrvDstcChngAplyDvn(" ");
		} else {
			mbtt02001vo.setTrvDstcChngAplyDvn(StringUtil.nvl(mmti0213vo.getTrv_dstc_chng_aply_dvn()));
		}
		mbtt02001vo.setHdlrFireYn(StringUtil.nvl(mmti0213vo.getHdlr_fire_yn()));
		if("".equals(mmti0213vo.getMtcc_yn()) || null == mmti0213vo.getMtcc_yn()){
			mbtt02001vo.setMtccYn(" ");
		} else {
			mbtt02001vo.setMtccYn(StringUtil.nvl(mmti0213vo.getMtcc_yn()));
		}
		if("".equals(request.getParameter("aut_cgnt_trv_dstc")) || null == request.getParameter("aut_cgnt_trv_dstc")){
			mbtt02001vo.setAutCgntTrvDstc(0);
		} else {
			mbtt02001vo.setAutCgntTrvDstc(Double.parseDouble(request.getParameter("aut_cgnt_trv_dstc")));
		}
		if("".equals(request.getParameter("autCgntTrvDstcRslCd")) || null == request.getParameter("autCgntTrvDstcRslCd")){
			mbtt02001vo.setAutCgntTrvDstcRslCd(" ");
		} else {
			mbtt02001vo.setAutCgntTrvDstcRslCd(StringUtil.nvl(request.getParameter("autCgntTrvDstcRslCd")));
		}
		if("".equals(request.getParameter("inptTrvDstc")) || null == request.getParameter("inptTrvDstc")){
			mbtt02001vo.setInptTrvDstc(0);
		} else {
			mbtt02001vo.setInptTrvDstc(Double.parseDouble(request.getParameter("inptTrvDstc")));
		}
		if("".equals(request.getParameter("cnv_trv_dstc")) || null == request.getParameter("cnv_trv_dstc")){
			mbtt02001vo.setCnvTrvDstc(0);
		} else {
			mbtt02001vo.setCnvTrvDstc(Double.parseDouble(request.getParameter("cnv_trv_dstc")));
		}
		if("".equals(request.getParameter("exp_exca_plan_rsl_cd")) || null == request.getParameter("exp_exca_plan_rsl_cd")){
			mbtt02001vo.setExpExcaPlanRslCd(" ");
		} else {
			mbtt02001vo.setExpExcaPlanRslCd(StringUtil.nvl(request.getParameter("exp_exca_plan_rsl_cd")));
		}
		if("".equals(request.getParameter("excaBzProcDvn")) || null == request.getParameter("excaBzProcDvn")){
			mbtt02001vo.setExcaBzProcDvn(" ");
		} else {
			mbtt02001vo.setExcaBzProcDvn(StringUtil.nvl(request.getParameter("excaBzProcDvn")));
		}
		if("".equals(request.getParameter("excaRtrnDvn")) || null == request.getParameter("excaRtrnDvn")){
			mbtt02001vo.setExcaRtrnDvn(" ");
		} else {
			mbtt02001vo.setExcaRtrnDvn(StringUtil.nvl(request.getParameter("excaRtrnPrm")));
		}
		if("".equals(request.getParameter("pdc_sr_dvn")) || null == request.getParameter("pdc_sr_dvn")){
			mbtt02001vo.setPdcSrDvn(" ");
		} else {
			mbtt02001vo.setPdcSrDvn(StringUtil.nvl(request.getParameter("pdc_sr_dvn")));
		}
		if("".equals(request.getParameter("adc_rtrn_prm")) || null == request.getParameter("adc_rtrn_prm")){
			mbtt02001vo.setAdcRtrnPrm(0);
		} else {
			mbtt02001vo.setAdcRtrnPrm(Double.parseDouble(request.getParameter("adc_rtrn_prm")));
		}
		if("".equals(request.getParameter("trvDstcSplcExcaYn")) || null == request.getParameter("trvDstcSplcExcaYn")){
			mbtt02001vo.setTrvDstcSplcExcaYn(" ");
		} else {
			mbtt02001vo.setTrvDstcSplcExcaYn(StringUtil.nvl(request.getParameter("trvDstcSplcExcaYn")));
		}
		if("".equals(request.getParameter("imagDupYn")) || null == request.getParameter("imagDupYn")){
			mbtt02001vo.setImagDupYn(" ");
		} else {
			mbtt02001vo.setImagDupYn(StringUtil.nvl(request.getParameter("imagDupYn")));
		}
		if("".equals(request.getParameter("nrmProcYn")) || null == request.getParameter("nrmProcYn")){
			mbtt02001vo.setNrmProcYn(" ");
		} else {
			mbtt02001vo.setNrmProcYn(StringUtil.nvl(request.getParameter("nrmProcYn")));
		}
		if("".equals(request.getParameter("crdScnCnclPssYn")) || null == request.getParameter("crdScnCnclPssYn")){
			mbtt02001vo.setCrdScnCnclPssYn(" ");
		} else {
			mbtt02001vo.setCrdScnCnclPssYn(StringUtil.nvl(request.getParameter("crdScnCnclPssYn")));
		}
		mbtt02001vo.setRespCn(StringUtil.nvl(mmti0213vo.getZ_resp_cd()));
		mbtt02001vo.setRslCn(scrnNm + "_" + StringUtil.nvl(mmti0213vo.getZ_resp_msg()));
		mbtt02001vo.setFrstIpmnEmpno("82101685");
		mbtt02001vo.setFnalAmdrEmpno("82101685");
		if("".equals(request.getParameter("adc_rtrn_dvn")) || null == request.getParameter("adc_rtrn_dvn")){
			mbtt02001vo.setAdcRtrnDvn(" ");
		} else {
			mbtt02001vo.setAdcRtrnDvn(StringUtil.nvl(request.getParameter("adc_rtrn_dvn")));
		}
		if("".equals(request.getParameter("scrn_proc_cd")) || null == request.getParameter("scrn_proc_cd")){
			mbtt02001vo.setScrnProcCd(" ");
		} else {
			mbtt02001vo.setScrnProcCd(StringUtil.nvl(request.getParameter("scrn_proc_cd")));
		}
		if("".equals(mmti0213vo.getCtc_plno()) || null == mmti0213vo.getCtc_plno()){
			mbtt02001vo.setCtcPlno(" ");
		} else {
			mbtt02001vo.setCtcPlno(StringUtil.nvl(mmti0213vo.getCtc_plno()));
		}
		if("".equals(request.getParameter("trv_dstc_proc_dvcd")) || null == request.getParameter("trv_dstc_proc_dvcd")){
			mbtt02001vo.setTrvDstcProcDvcd(" ");
		} else {
			mbtt02001vo.setTrvDstcProcDvcd(StringUtil.nvl(request.getParameter("trv_dstc_proc_dvcd")));
		}
		if("".equals(request.getParameter("mbl_snd_no")) || null == request.getParameter("mbl_snd_no")){
			mbtt02001vo.setMblSndNo(" ");
		} else {
			mbtt02001vo.setMblSndNo(StringUtil.nvl(request.getParameter("mbl_snd_no")));
		}
		if("".equals(request.getParameter("plan_plno_dvcd")) || null == request.getParameter("plan_plno_dvcd")){
			mbtt02001vo.setPlanPlnoDvcd(" ");
		} else {
			mbtt02001vo.setPlanPlnoDvcd(StringUtil.nvl(request.getParameter("plan_plno_dvcd")));
		}
		if("".equals(request.getParameter("plan_plno")) || null == request.getParameter("plan_plno")){
			mbtt02001vo.setPlanPlno(" ");
		} else {
			mbtt02001vo.setPlanPlno(StringUtil.nvl(request.getParameter("plan_plno")));
		}
		if("".equals(mmti0213vo.getChng_plan_no()) || null == mmti0213vo.getChng_plan_no()){
			mbtt02001vo.setChngPlanNo(" ");
		} else {
			mbtt02001vo.setChngPlanNo(StringUtil.nvl(mmti0213vo.getChng_plan_no()));
		}
		if("".equals(request.getParameter("dst_tty_dvn1")) || null == request.getParameter("dst_tty_dvn1")){
			mbtt02001vo.setDstTtyDvn1(" ");
		} else {
			mbtt02001vo.setDstTtyDvn1(StringUtil.nvl(request.getParameter("dst_tty_dvn1")));
		}
		if("".equals(request.getParameter("dst_tty_dvn2")) || null == request.getParameter("dst_tty_dvn2")){
			mbtt02001vo.setDstTtyDvn2(" ");
		} else {
			mbtt02001vo.setDstTtyDvn2(StringUtil.nvl(request.getParameter("dst_tty_dvn2")));
		}
		if("".equals(request.getParameter("dst_tty_dvn3")) || null == request.getParameter("dst_tty_dvn3")){
			mbtt02001vo.setDstTtyDvn3(" ");
		} else {
			mbtt02001vo.setDstTtyDvn3(StringUtil.nvl(request.getParameter("dst_tty_dvn3")));
		}
		if("".equals(request.getParameter("dst_tty_dvn4")) || null == request.getParameter("dst_tty_dvn4")){
			mbtt02001vo.setDstTtyDvn4(" ");
		} else {
			mbtt02001vo.setDstTtyDvn4(StringUtil.nvl(request.getParameter("dst_tty_dvn4")));
		}
		if("".equals(request.getParameter("dst_tty_dvn5")) || null == request.getParameter("dst_tty_dvn5")){
			mbtt02001vo.setDstTtyDvn5(" ");
		} else {
			mbtt02001vo.setDstTtyDvn5(StringUtil.nvl(request.getParameter("dst_tty_dvn5")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt1")) || null == request.getParameter("phgp_regt_tgt1")){
			mbtt02001vo.setPhgpRegtTgt1(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt1(StringUtil.nvl(request.getParameter("phgp_regt_tgt1")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt2")) || null == request.getParameter("phgp_regt_tgt2")){
			mbtt02001vo.setPhgpRegtTgt2(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt2(StringUtil.nvl(request.getParameter("phgp_regt_tgt2")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt3")) || null == request.getParameter("phgp_regt_tgt3")){
			mbtt02001vo.setPhgpRegtTgt3(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt3(StringUtil.nvl(request.getParameter("phgp_regt_tgt3")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt4")) || null == request.getParameter("phgp_regt_tgt4")){
			mbtt02001vo.setPhgpRegtTgt4(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt4(StringUtil.nvl(request.getParameter("phgp_regt_tgt4")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt5")) || null == request.getParameter("phgp_regt_tgt5")){
			mbtt02001vo.setPhgpRegtTgt5(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt5(StringUtil.nvl(request.getParameter("phgp_regt_tgt5")));
		}
		
		//MMTI0213 insert
		int insertRow = 0;
		
		logger.info("#### chatMlCancelCard MMTI0213 MBTT02001 before ####");
		insertRow = mileageTobeService.insertJungsanTest(mbtt02001vo);
		logger.info("#### chatMlCancelCard MMTI0213 MBTT02001 after ####");
		
		if(insertRow < 1){
			logger.info("#### 사서함번호: " + StringUtil.nvl(mbtt02001vo.getPboxNo()) + "####");
			logger.info("#### insert 결과: Fail ####");
		}else{
			logger.info("#### insert 결과: Success ####");
		}
		
		//MMTI0291전문 정산이력테이블(MBTT02001) 적재
		mbtt02001vo.setPboxNo(StringUtil.nvl(mmti0213vo.getSms_ts_bvan()));
		mbtt02001vo.setTlgIdVal("MMTI0291");
		mbtt02001vo.setEsbTrscId(StringUtil.nvl(mmti0291vo.getZ_trsc_id()));
		if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__plno()) || null == mmti0291vo.getTrv_dstc_exca_mtt__plno()){
			mbtt02001vo.setPlno(" ");
		} else {
			mbtt02001vo.setPlno(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__plno()));
		}
		if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__plan_no()) || null == mmti0291vo.getTrv_dstc_exca_mtt__plan_no()){
			mbtt02001vo.setPlanNo(" ");
		} else {
			mbtt02001vo.setPlanNo(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__plan_no()));
		}
		if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__rnw_plno()) || null == mmti0291vo.getTrv_dstc_exca_mtt__rnw_plno()){
			mbtt02001vo.setRnwPlno(" ");
		} else {
			mbtt02001vo.setRnwPlno(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__rnw_plno()));
		}
		mbtt02001vo.setTlgProcRslCdVal(StringUtil.nvl(mmti0291vo.getZ_tlg_sp_cd()));
		mbtt02001vo.setTlgErrCdVal(StringUtil.nvl(mmti0291vo.getZ_trns_org_dvcd())+StringUtil.nvl(mmti0291vo.getZ_trns_org_cd()));
		if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__hdlr_empno()) || null == mmti0291vo.getTrv_dstc_exca_mtt__hdlr_empno()){
			mbtt02001vo.setHdlrEmpno(" ");
		} else {
			mbtt02001vo.setHdlrEmpno(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__hdlr_empno()));
		}
		if("".equals(mmti0213vo.getPbox_no_dvcd()) || null == mmti0213vo.getPbox_no_dvcd()){
			mbtt02001vo.setPboxNoDvcd(" ");
		} else {
			mbtt02001vo.setPboxNoDvcd(StringUtil.nvl(mmti0213vo.getPbox_no_dvcd()));
		}
		if("".equals(mmti0213vo.getProc_dvn()) || null == mmti0213vo.getProc_dvn()){
			mbtt02001vo.setProcDvn(" ");
		} else {
			mbtt02001vo.setProcDvn(StringUtil.nvl(mmti0213vo.getProc_dvn()));
		}
		if("".equals(mmti0213vo.getTrv_dstc_exp_exca_dvcd()) || null == mmti0213vo.getTrv_dstc_exp_exca_dvcd()){
			mbtt02001vo.setTrvDstcExpExcaDvcd(" ");
		} else {
			mbtt02001vo.setTrvDstcExpExcaDvcd(StringUtil.nvl(mmti0213vo.getTrv_dstc_exp_exca_dvcd()));
		}
		if("".equals(mmti0213vo.getTrv_dstc_chng_aply_dvn()) || null == mmti0213vo.getTrv_dstc_chng_aply_dvn()){
			mbtt02001vo.setTrvDstcChngAplyDvn(" ");
		} else {
			mbtt02001vo.setTrvDstcChngAplyDvn(StringUtil.nvl(mmti0213vo.getTrv_dstc_chng_aply_dvn()));
		}
		mbtt02001vo.setHdlrFireYn(StringUtil.nvl(mmti0213vo.getHdlr_fire_yn()));
		if("".equals(mmti0213vo.getMtcc_yn()) || null == mmti0213vo.getMtcc_yn()){
			mbtt02001vo.setMtccYn(" ");
		} else {
			mbtt02001vo.setMtccYn(StringUtil.nvl(mmti0213vo.getMtcc_yn()));
		}
		if("".equals(request.getParameter("aut_cgnt_trv_dstc")) || null == request.getParameter("aut_cgnt_trv_dstc")){
			mbtt02001vo.setAutCgntTrvDstc(0);
		} else {
			mbtt02001vo.setAutCgntTrvDstc(Double.parseDouble(request.getParameter("aut_cgnt_trv_dstc")));
		}
		if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__aut_cgnt_trv_dstc_rsl_cd()) || null == mmti0291vo.getTrv_dstc_exca_mtt__aut_cgnt_trv_dstc_rsl_cd()){
			mbtt02001vo.setAutCgntTrvDstcRslCd(" ");
		} else {
			mbtt02001vo.setAutCgntTrvDstcRslCd(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__aut_cgnt_trv_dstc_rsl_cd()));
		}
		if("".equals(request.getParameter("inptTrvDstc")) || null == request.getParameter("inptTrvDstc")){
			mbtt02001vo.setInptTrvDstc(0);
		} else {
			mbtt02001vo.setInptTrvDstc(Double.parseDouble(request.getParameter("inptTrvDstc")));
		}
		if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__cnv_trv_dstc()) || null == mmti0291vo.getTrv_dstc_exca_mtt__cnv_trv_dstc()){
			mbtt02001vo.setCnvTrvDstc(0);
		} else {
			mbtt02001vo.setCnvTrvDstc(Double.parseDouble(mmti0291vo.getTrv_dstc_exca_mtt__cnv_trv_dstc()));
		}
		if("".equals(request.getParameter("exp_exca_plan_rsl_cd")) || null == request.getParameter("exp_exca_plan_rsl_cd")){
			mbtt02001vo.setExpExcaPlanRslCd(" ");
		} else {
			mbtt02001vo.setExpExcaPlanRslCd(StringUtil.nvl(request.getParameter("exp_exca_plan_rsl_cd")));
		}
		if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__exca_bz_proc_dvn()) || null == mmti0291vo.getTrv_dstc_exca_mtt__exca_bz_proc_dvn()){
			mbtt02001vo.setExcaBzProcDvn(" ");
		} else {
			mbtt02001vo.setExcaBzProcDvn(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__exca_bz_proc_dvn()));
		}
		if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__exca_rtrn_dvn()) || null == mmti0291vo.getTrv_dstc_exca_mtt__exca_rtrn_dvn()){
			mbtt02001vo.setExcaRtrnDvn(" ");
		} else {
			mbtt02001vo.setExcaRtrnDvn(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__exca_rtrn_dvn()));
		}
		if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__pdc_sr_dvn()) || null == mmti0291vo.getTrv_dstc_exca_mtt__pdc_sr_dvn()){
			mbtt02001vo.setPdcSrDvn(" ");
		} else {
			mbtt02001vo.setPdcSrDvn(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__pdc_sr_dvn()));
		}
		if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__adc_rtrn_prm()) || null == mmti0291vo.getTrv_dstc_exca_mtt__adc_rtrn_prm()){
			mbtt02001vo.setAdcRtrnPrm(0);
		} else {
			mbtt02001vo.setAdcRtrnPrm(Double.parseDouble(mmti0291vo.getTrv_dstc_exca_mtt__adc_rtrn_prm()));
		}
		if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn()) || null == mmti0291vo.getTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn()){
			mbtt02001vo.setTrvDstcSplcExcaYn(" ");
		} else {
			mbtt02001vo.setTrvDstcSplcExcaYn(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn()));
		}
		if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__imag_dup_yn()) || null == mmti0291vo.getTrv_dstc_exca_mtt__imag_dup_yn()){
			mbtt02001vo.setImagDupYn(" ");
		} else {
			mbtt02001vo.setImagDupYn(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__imag_dup_yn()));
		}
		if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__nrm_proc_yn()) || null == mmti0291vo.getTrv_dstc_exca_mtt__nrm_proc_yn()){
			mbtt02001vo.setNrmProcYn(" ");
		} else {
			mbtt02001vo.setNrmProcYn(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__nrm_proc_yn()));
		}
		if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__crd_scn_cncl_pss_yn()) || null == mmti0291vo.getTrv_dstc_exca_mtt__crd_scn_cncl_pss_yn()){
			mbtt02001vo.setCrdScnCnclPssYn(" ");
		} else {
			mbtt02001vo.setCrdScnCnclPssYn(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__crd_scn_cncl_pss_yn()));
		}
		mbtt02001vo.setRespCn(StringUtil.nvl(mmti0291vo.getZ_resp_cd()));
		mbtt02001vo.setRslCn(scrnNm + "_" + StringUtil.nvl(mmti0291vo.getZ_resp_msg()));
		mbtt02001vo.setFrstIpmnEmpno("82101685");
		mbtt02001vo.setFnalAmdrEmpno("82101685");
		if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__adc_rtrn_dvn()) || null == mmti0291vo.getTrv_dstc_exca_mtt__adc_rtrn_dvn()){
			mbtt02001vo.setAdcRtrnDvn(" ");
		} else {
			mbtt02001vo.setAdcRtrnDvn(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__adc_rtrn_dvn()));
		}
		if("".equals(mmti0291vo.getTrv_dstc_exca_mtt__scrn_proc_cd()) || null == mmti0291vo.getTrv_dstc_exca_mtt__scrn_proc_cd()){
			mbtt02001vo.setScrnProcCd(" ");
		} else {
			mbtt02001vo.setScrnProcCd(StringUtil.nvl(mmti0291vo.getTrv_dstc_exca_mtt__scrn_proc_cd()));
		}
		if("".equals(request.getParameter("ctc_plno")) || null == request.getParameter("ctc_plno")){
			mbtt02001vo.setCtcPlno(" ");
		} else {
			mbtt02001vo.setCtcPlno(StringUtil.nvl(request.getParameter("ctc_plno")));
		}
		if("".equals(request.getParameter("trv_dstc_proc_dvcd")) || null == request.getParameter("trv_dstc_proc_dvcd")){
			mbtt02001vo.setTrvDstcProcDvcd(" ");
		} else {
			mbtt02001vo.setTrvDstcProcDvcd(StringUtil.nvl(request.getParameter("trv_dstc_proc_dvcd")));
		}
		if("".equals(request.getParameter("mbl_snd_no")) || null == request.getParameter("mbl_snd_no")){
			mbtt02001vo.setMblSndNo(" ");
		} else {
			mbtt02001vo.setMblSndNo(StringUtil.nvl(request.getParameter("mbl_snd_no")));
		}
		if("".equals(request.getParameter("plan_plno_dvcd")) || null == request.getParameter("plan_plno_dvcd")){
			mbtt02001vo.setPlanPlnoDvcd(" ");
		} else {
			mbtt02001vo.setPlanPlnoDvcd(StringUtil.nvl(request.getParameter("plan_plno_dvcd")));
		}
		if("".equals(request.getParameter("plan_plno")) || null == request.getParameter("plan_plno")){
			mbtt02001vo.setPlanPlno(" ");
		} else {
			mbtt02001vo.setPlanPlno(StringUtil.nvl(request.getParameter("plan_plno")));
		}
		if("".equals(request.getParameter("chng_plan_no")) || null == request.getParameter("chng_plan_no")){
			mbtt02001vo.setChngPlanNo(" ");
		} else {
			mbtt02001vo.setChngPlanNo(StringUtil.nvl(request.getParameter("chng_plan_no")));
		}
		if("".equals(request.getParameter("dst_tty_dvn1")) || null == request.getParameter("dst_tty_dvn1")){
			mbtt02001vo.setDstTtyDvn1(" ");
		} else {
			mbtt02001vo.setDstTtyDvn1(StringUtil.nvl(request.getParameter("dst_tty_dvn1")));
		}
		if("".equals(request.getParameter("dst_tty_dvn2")) || null == request.getParameter("dst_tty_dvn2")){
			mbtt02001vo.setDstTtyDvn2(" ");
		} else {
			mbtt02001vo.setDstTtyDvn2(StringUtil.nvl(request.getParameter("dst_tty_dvn2")));
		}
		if("".equals(request.getParameter("dst_tty_dvn3")) || null == request.getParameter("dst_tty_dvn3")){
			mbtt02001vo.setDstTtyDvn3(" ");
		} else {
			mbtt02001vo.setDstTtyDvn3(StringUtil.nvl(request.getParameter("dst_tty_dvn3")));
		}
		if("".equals(request.getParameter("dst_tty_dvn4")) || null == request.getParameter("dst_tty_dvn4")){
			mbtt02001vo.setDstTtyDvn4(" ");
		} else {
			mbtt02001vo.setDstTtyDvn4(StringUtil.nvl(request.getParameter("dst_tty_dvn4")));
		}
		if("".equals(request.getParameter("dst_tty_dvn5")) || null == request.getParameter("dst_tty_dvn5")){
			mbtt02001vo.setDstTtyDvn5(" ");
		} else {
			mbtt02001vo.setDstTtyDvn5(StringUtil.nvl(request.getParameter("dst_tty_dvn5")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt1")) || null == request.getParameter("phgp_regt_tgt1")){
			mbtt02001vo.setPhgpRegtTgt1(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt1(StringUtil.nvl(request.getParameter("phgp_regt_tgt1")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt2")) || null == request.getParameter("phgp_regt_tgt2")){
			mbtt02001vo.setPhgpRegtTgt2(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt2(StringUtil.nvl(request.getParameter("phgp_regt_tgt2")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt3")) || null == request.getParameter("phgp_regt_tgt3")){
			mbtt02001vo.setPhgpRegtTgt3(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt3(StringUtil.nvl(request.getParameter("phgp_regt_tgt3")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt4")) || null == request.getParameter("phgp_regt_tgt4")){
			mbtt02001vo.setPhgpRegtTgt4(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt4(StringUtil.nvl(request.getParameter("phgp_regt_tgt4")));
		}
		if("".equals(request.getParameter("phgp_regt_tgt5")) || null == request.getParameter("phgp_regt_tgt5")){
			mbtt02001vo.setPhgpRegtTgt5(" ");
		} else {
			mbtt02001vo.setPhgpRegtTgt5(StringUtil.nvl(request.getParameter("phgp_regt_tgt5")));
		}
		
		//MMTI0291 insert
		insertRow = 0;
		
		logger.info("#### chatMlCancelCard MMTI0291 MBTT02001 before ####");
		insertRow = mileageTobeService.insertJungsanTest(mbtt02001vo);
		logger.info("#### chatMlCancelCard MMTI0291 MBTT02001 after ####");
		
		if(insertRow < 1){
			logger.info("#### 사서함번호: " + StringUtil.nvl(mbtt02001vo.getPboxNo()) + "####");
			logger.info("#### insert 결과: Fail ####");
		}else{
			logger.info("#### insert 결과: Success ####");
		}
*/		
		request.setAttribute("ch_dvn", ch_dvn);
		return map;	
	}
	
	@RequestMapping(value="/chat_ml_crd_end")
	public String chat_ml_crd_end(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		
		return "/counter/carrider/tobe/chat_ml_crd_end";
	}
	
	@RequestMapping(value="/chatMlFileUpload")
	public @ResponseBody Map<String, String> chatMlFileUpload(MultipartHttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		Map<String, String> map = new HashMap<String, String>();
		String yyyymmdd = DateUtil.getDate("yyyymmdd");
		// String ch_dvn = request.getParameter("ch_dvn");
		
		MMTI0213VO jmvo = new MMTI0213VO();
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("p")));
		jmvo = mileageTobeService.chatMMTI0213VO(jmvo);
		
		String exifDate1 = StringUtil.nvl(request.getParameter("exifDate1"));
		
		// 사진실제촬영일자
		String phgp_rl_ptgr_dt = StringUtil.nvl(request.getParameter("phgp_rl_ptgr_dt"));
		// 사진첨부방식코드
		String phgp_apdx_way_cd = StringUtil.nvl(request.getParameter("phgp_apdx_way_cd"));

		String phgp_ptgr_dt = "";
		
		boolean empty = false;
		if(exifDate1.indexOf(",gallery") > -1) {
			exifDate1 = exifDate1.substring(0, exifDate1.indexOf(",gallery"));
			if(StringUtil.isEmpty(exifDate1)) {
				exifDate1 = DateUtil.getDate();
				empty = true;
			}
			else if(Integer.parseInt(exifDate1) > Integer.parseInt(DateUtil.getDate())) {
				map.put("errorCode", "f");
				return map;
			}
		}

		phgp_ptgr_dt = empty ? "" : exifDate1;
		
		if(exifDate1.indexOf(",gallery") > -1) {
			exifDate1 = exifDate1.substring(0, exifDate1.indexOf(",gallery"));
		}

		if("08".equals(jmvo.getProc_dvn()) || "09".equals(jmvo.getProc_dvn())) {
			ArrayList<File> files = mileageTobeService.uploadToWAS(request, jmvo.getSms_ts_bvan());
			
			String aut_cgnt_trv_dstc_rsl_cd = "";	// 자동인식주행거리결과코드
			String aut_cgnt_vh_no_rsl_cd = "";		// 자동인식차량번호결과코드
			String aut_cgnt_trv_dstc = "";			// 자동인식주행거리
			String aut_cgnt_vh_no = "";				// 자동인식차량번호
			
			String aut_cgnt_trv_dstc_1 = "";		// 자동인식주행거리1
			String aut_cgnt_trv_dstc_2 = "";		// 자동인식주행거리2
			String aut_cgnt_trv_dstc_3 = "";		// 자동인식주행거리3
			
			boolean flag1 = false;
			if(files.size() > 0) {
				FTPUtil ftp = null;
				// [200617]
				FileInputStream in = null;
				FileInputStream fis = null;
				FileOutputStream out = null;
				
				try {
					if("1".equals(jmvo.getAut_cgnt_nn_apcn_yn())) { // OCR서버 문제있으면...
						aut_cgnt_trv_dstc_rsl_cd = "03";
						aut_cgnt_vh_no_rsl_cd = "03";
					}
					else {
						String propsPath = this.getClass().getResource("").getPath();
						propsPath = propsPath.substring(0, propsPath.indexOf("/classes/")) + "/config/ocr_ftp.properties";
						Properties p = new Properties();
						// [200617]
						in = new FileInputStream(propsPath);
						p.load(in);
						in.close();
						// [200617]
						in = null;
						
						String password = p.getProperty("password");
						String decPassword = aes256Decrypt(password);
						if(password.equals(decPassword) || StringUtil.isEmpty(decPassword)) {
							decPassword = password;
							String encPassword = aes256Encrypt(password);
							logger.debug("encPassword: " + encPassword);
							// [200617]
							out = new FileOutputStream(propsPath);
							p.setProperty("password", encPassword);
							p.store(out, "");
							out.close();
							// [200617]
							out = null;
						}
						
						ftp = new FTPUtil(p.getProperty("ip"), p.getProperty("user"), decPassword, Integer.parseInt(p.getProperty("port")));
						
						int working = 0;
						for(int i = 1; i <= 3; i++) {
							String[] ls = ftp.ls("/RECOG_JOB" + i + "/" + yyyymmdd);
							for(int j = 0; j < ls.length; j++) {
								if(".".equals(ls[j]) || "..".equals(ls[j])) continue;
								working++;
							}
						}
		
						if(working <= 6) {
							String filename1 = "";
							
							filename1 = ftp.uploadToOCR("/RECOG/" + yyyymmdd, files.get(0), "--D");

							logger.debug("filename1: " + filename1);

							
							logger.debug("--- 1초 대기 ---");
							Thread.sleep(1000);
							int retryNum = 7;
							for(int retry = 0; retry < retryNum; retry++) {
								String[] ls = ftp.ls("/RECOG_RESULT/" + yyyymmdd);
			
								for(int i = 0; i < ls.length; i++) {
									logger.debug(ls[i]);
									if(!flag1 && ls[i].equals(filename1)) {
										flag1 = true;
									}
									
									if(flag1) break;
								}
			
								if((flag1) || retry == retryNum - 1) {
									break;
								}
								else {
									logger.debug("--- 0.6초 대기 ---");
									Thread.sleep(600);
								}
							}
							
							logger.debug("flag1: " + flag1);
							
							if(flag1) {
								// [210219]
								if(filename1 != null || !"".equals(filename1)){
									filename1 = filename1.replaceAll("/", "");
									filename1 = filename1.replaceAll("\\\\", "");
									filename1 = filename1.replaceAll("./", "");
									filename1 = filename1.replaceAll("../", "");
									filename1 = filename1.replaceAll("&", "");
								}
								
								String path = files.get(0).getParent() + File.separator + filename1;
								ftp.downloadFromOCR("/RECOG_RESULT/" + yyyymmdd, filename1, path);
								logger.debug("path: " + path);
								
								// [210219]
								File f = new File(files.get(0).getParent() + File.separator + filename1);
								// File f = new File(path);
			
								if(f.exists()) {
									Properties props = new Properties();
									// [210219]
									fis = new FileInputStream(files.get(0).getParent() + File.separator + filename1);
									props.load(fis);
									fis.close();
									// [200617]
									fis = null;
									
									if(!StringUtil.isEmpty(props.getProperty("ODO")) && !StringUtil.isEmpty(props.getProperty("RE_CODE"))) {
										aut_cgnt_trv_dstc = props.getProperty("ODO");
										aut_cgnt_trv_dstc_rsl_cd = "1".equals(props.getProperty("RE_CODE")) || "2".equals(props.getProperty("RE_CODE")) ? "01" : "02";
										
										aut_cgnt_trv_dstc_1 = props.getProperty("ODO");
										
										if(!StringUtil.isEmpty(props.getProperty("ODO2"))) {
											aut_cgnt_trv_dstc_2 = props.getProperty("ODO2");
										}
										
										if(!StringUtil.isEmpty(props.getProperty("ODO3"))) {
											aut_cgnt_trv_dstc_3 = props.getProperty("ODO3");
										}
									}
									
					            	if(f.delete()) {
										logger.debug("삭제: " + path);
									}
								}
							}
							else {
								aut_cgnt_trv_dstc_rsl_cd = "02";
							}						
						}
						else {
							aut_cgnt_trv_dstc_rsl_cd = "02";
							if(!"1".equals(jmvo.getCm_yn())) {
								aut_cgnt_vh_no_rsl_cd = "02";
							}
						}
					}
				}
				catch(Exception e) {
					logger.debug(e.getMessage());
					aut_cgnt_trv_dstc_rsl_cd = "02";
					if(!"1".equals(jmvo.getCm_yn())) {
						aut_cgnt_vh_no_rsl_cd = "02";
					}
				}
				finally {
					if(ftp != null) ftp.disconnect();
					
					// [200617]
					try{
			    	  	if(in != null){
			    	  		in.close();
			    	  	}
				      }catch(IOException ee){
				    	  System.err.println("[MileageTobeController.mlFileUpload()] IOException 1");
				      }
					try{
			    	  	if(out != null){
			    	  		out.close();
			    	  	}
				      }catch(IOException ee){
				    	  System.err.println("[MileageTobeController.mlFileUpload()] IOException 2");
				      }
					try{
			    	  	if(fis != null){
			    	  		fis.close();
			    	  	}
				      }catch(IOException ee){
				    	  System.err.println("[MileageTobeController.mlFileUpload()] IOException 3");
				      }
				}
			}
			
			MMTI0259VO jmvo1 = new MMTI0259VO();
			jmvo1.setPbox_use_yn("1");
			jmvo1.setPbox_no(jmvo.getSms_ts_bvan());
			jmvo1.setPhgp_cnfm_dt(DateUtil.getDate());
			jmvo1.setPhgp_ptgr_dt(phgp_ptgr_dt);
			jmvo1.setPhgp_strg_yn("1");
			if("1".equals(jmvo.getAut_cgnt_nn_apcn_yn())) {
				jmvo1.setPbox_chr_nm(request.getParameter("mileage1"));
			}
			
			if("1".equals(jmvo.getPbox_no_dvcd())) {
				if(!"1".equals(jmvo.getCm_yn())) {
					jmvo1.setInpt_trv_dstc(request.getParameter("mileage1"));
					if(!StringUtil.isEmpty(aut_cgnt_vh_no)) {
						jmvo1.setAut_cgnt_vh_no(aut_cgnt_vh_no);
					}
					
					if(!StringUtil.isEmpty(aut_cgnt_vh_no_rsl_cd)) {
						jmvo1.setAut_cgnt_vh_no_rsl_cd(aut_cgnt_vh_no_rsl_cd);
					}
					else {
						jmvo1.setAut_cgnt_vh_no_rsl_cd("02");
					}
				}
					
				if(!StringUtil.isEmpty(aut_cgnt_trv_dstc)) {
					jmvo1.setAut_cgnt_trv_dstc(aut_cgnt_trv_dstc);
				}
				
				if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_rsl_cd)) {
					jmvo1.setAut_cgnt_trv_dstc_rsl_cd(aut_cgnt_trv_dstc_rsl_cd);
				}
				else {
					jmvo1.setAut_cgnt_trv_dstc_rsl_cd("02");
				}
				
				if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_1)) {
					jmvo1.setAut_cgnt_trv_dstc_1(aut_cgnt_trv_dstc_1);
				}
				
				if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_2)) {
					jmvo1.setAut_cgnt_trv_dstc_2(aut_cgnt_trv_dstc_2);
				}
				
				if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_3)) {
					jmvo1.setAut_cgnt_trv_dstc_3(aut_cgnt_trv_dstc_3);
				}
			}
			
			// 200708
			jmvo1.setPhgp_rl_ptgr_dt(phgp_rl_ptgr_dt);
			jmvo1.setPhgp_apdx_way_cd(phgp_apdx_way_cd);
			
			jmvo1 = mileageTobeService.chatMMTI0259VO(jmvo1);
			
			if("0".equals(jmvo1.getErrorCode()) && !"1".equals(jmvo.getCm_yn())) {
				jmvo1.setExp_exca_plan_proc_dvn("1");
				jmvo1.setPlno(jmvo.getPlno());
				
				// 200708
				jmvo1.setPhgp_rl_ptgr_dt(phgp_rl_ptgr_dt);
				jmvo1.setPhgp_apdx_way_cd(phgp_apdx_way_cd);
				
				jmvo1 = mileageTobeService.chatMMTI0259VO(jmvo1);
				
				if("05".equals(jmvo1.getExp_exca_plan_rsl_cd())) {
					mileageTobeService.regInfoToEdmsForMobileWeb(request, jmvo.getSms_ts_bvan());
				}
				else if(!StringUtil.isEmpty(jmvo1.getPlno()) && !StringUtil.isEmpty(jmvo1.getExp_exca_plan_no())) {
					mileageTobeService.regInfoToEdmsForMobileWeb2(request, jmvo.getNtft_srv_rc_ormm_cd(), files, jmvo1.getPlno() + "," + jmvo1.getExp_exca_plan_no());
				}
				else {
					mileageTobeService.regInfoToEdmsForMobileWeb2(request, jmvo.getNtft_srv_rc_ormm_cd(), files, jmvo1.getPlno());
				}
			}
			else {
				if("1".equals(jmvo.getCm_yn())) {
					mileageTobeService.regInfoToEdmsForMobileWeb(request, jmvo.getSms_ts_bvan());
				}
				else {
					mileageTobeService.regInfoToEdmsForMobileWeb2(request, jmvo.getNtft_srv_rc_ormm_cd(), files, jmvo1.getPlno());
				}
			}
	
			for(int i = 0; i < files.size(); i++) {
				File f = files.get(i);
				String fname = f.getName();
				f.delete();
				logger.debug(fname + " 삭제");
			}
			
			map.put("errorCode",				jmvo1.getErrorCode());
			map.put("exp_exca_plan_rsl_cd",		jmvo1.getExp_exca_plan_rsl_cd());
			map.put("adc_rtrn_dvn",				jmvo1.getAdc_rtrn_dvn());
			map.put("adc_rtrn_prm",				jmvo1.getAdc_rtrn_prm());
			map.put("plno",						jmvo1.getPlno());
			map.put("exp_exca_plan_no",			jmvo1.getExp_exca_plan_no());
			map.put("exp_exca_plan_bse_dd",		jmvo1.getExp_exca_plan_bse_dd());
			map.put("aut_cgnt_vh_no",			jmvo1.getAut_cgnt_vh_no());
			map.put("aut_cgnt_vh_no_rsl_cd",	jmvo1.getAut_cgnt_vh_no_rsl_cd());
			map.put("aut_cgnt_trv_dstc",		jmvo1.getAut_cgnt_trv_dstc());
			map.put("aut_cgnt_trv_dstc_rsl_cd",	jmvo1.getAut_cgnt_trv_dstc_rsl_cd());
			map.put("exp_exca_plan_proc_dvn",	jmvo1.getExp_exca_plan_proc_dvn());
			map.put("cnv_trv_dstc",				jmvo1.getCnv_trv_dstc());
			
			// 200708
			map.put("phgp_rl_ptgr_dt",			phgp_rl_ptgr_dt);
			map.put("phgp_apdx_way_cd", 		phgp_apdx_way_cd);
		}
		else {
			mileageTobeService.regInfoToEdmsForMobileWeb(request, jmvo.getSms_ts_bvan());
			
			MMTI0259VO jmvo1 = new MMTI0259VO();
			jmvo1.setPbox_use_yn("1");
			jmvo1.setPbox_no(jmvo.getSms_ts_bvan());
			jmvo1.setPhgp_cnfm_dt(DateUtil.getDate());
			jmvo1.setPhgp_ptgr_dt(phgp_ptgr_dt);
			jmvo1.setPhgp_strg_yn("1");
			
			// 200708
			jmvo1.setPhgp_rl_ptgr_dt(phgp_rl_ptgr_dt);
			jmvo1.setPhgp_apdx_way_cd(phgp_apdx_way_cd);
			
			if("1".equals(jmvo.getPbox_no_dvcd()) && !"1".equals(jmvo.getCm_yn())) {
				if("03".equals(jmvo.getProc_dvn())) {
					jmvo1.setPbox_chr_nm(request.getParameter("mileage1") + "/" + request.getParameter("mileage2"));
				}
				else {
					jmvo1.setPbox_chr_nm(request.getParameter("mileage1"));
				}
			}
			jmvo1 = mileageTobeService.chatMMTI0259VO(jmvo1);
			
			map.put("errorCode", jmvo1.getErrorCode());
		}
			
		return map;
	}
	
	//aiocr용
	@RequestMapping(value="/aiocrChatMlFileUpload")
	public @ResponseBody Map<String, String> aiocrChatMlFileUpload(MultipartHttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		Map<String, String> map = new HashMap<String, String>();
		String yyyymmdd = DateUtil.getDate("yyyymmdd");
		// String ch_dvn = request.getParameter("ch_dvn");
		
		MMTI0213VO jmvo = new MMTI0213VO();
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("p")));
		jmvo = mileageTobeService.chatMMTI0213VO(jmvo);
		
		String exifDate1 = StringUtil.nvl(request.getParameter("exifDate1"));
		
		// 사진실제촬영일자
		String phgp_rl_ptgr_dt = StringUtil.nvl(request.getParameter("phgp_rl_ptgr_dt"));
		// 사진첨부방식코드
		String phgp_apdx_way_cd = StringUtil.nvl(request.getParameter("phgp_apdx_way_cd"));

		String phgp_ptgr_dt = "";
		
		boolean empty = false;
		if(exifDate1.indexOf(",gallery") > -1) {
			exifDate1 = exifDate1.substring(0, exifDate1.indexOf(",gallery"));
			if(StringUtil.isEmpty(exifDate1)) {
				exifDate1 = DateUtil.getDate();
				empty = true;
			}
			else if(Integer.parseInt(exifDate1) > Integer.parseInt(DateUtil.getDate())) {
				map.put("errorCode", "f");
				return map;
			}
		}

		phgp_ptgr_dt = empty ? "" : exifDate1;
		
		if(exifDate1.indexOf(",gallery") > -1) {
			exifDate1 = exifDate1.substring(0, exifDate1.indexOf(",gallery"));
		}

		if("08".equals(jmvo.getProc_dvn()) || "09".equals(jmvo.getProc_dvn())) {
			ArrayList<File> files = mileageTobeService.aiocrUploadToWAS(request, jmvo.getSms_ts_bvan());
			
			String aut_cgnt_trv_dstc_rsl_cd = "";	// 자동인식주행거리결과코드
			String aut_cgnt_vh_no_rsl_cd = "";		// 자동인식차량번호결과코드
			String aut_cgnt_trv_dstc = "";			// 자동인식주행거리
			String aut_cgnt_vh_no = "";				// 자동인식차량번호
			
			String aut_cgnt_trv_dstc_1 = "";		// 자동인식주행거리1
			String aut_cgnt_trv_dstc_2 = "";		// 자동인식주행거리2
			String aut_cgnt_trv_dstc_3 = "";		// 자동인식주행거리3
			
			String a_i_o_c_r_rqst_dsky_val	= "";	// aiocr요청구분키값
			String a_i_o_c_r_resultCode 	= "";	// aiocr요청결과코드값
			String resultValue 				= "";	// 주행거리값1
			String dtcn_cgnt_rt 			= "";	// 검출인식률1
			String cgnt_cgnt_rt 			= "";	// 인식인식률1
			String resultValue2 			= "";	// 주행거리값2
			String dtcn_cgnt_rt2 			= "";	// 검출인식률2
			String cgnt_cgnt_rt2 			= "";	// 인식인식률2
			String resultValue3 			= "";	// 주행거리값3
			String dtcn_cgnt_rt3 			= "";	// 검출인식률3
			String cgnt_cgnt_rt3 			= "";	// 인식인식률3
			String RE_CODE 					= "";
			
			HashMap<String, String> resultMap = null;
			
			boolean flag1 = false;
			if(files.size() > 0) {
				FTPUtil ftp = null;
				// [200617]
				FileInputStream in = null;
				FileInputStream fis = null;
				FileOutputStream out = null;
				
				HttpResponse httpResp = null;
				HttpEntity respEntity = null;
				
				resultMap = new HashMap<String, String>();
				
				try {
					if("1".equals(jmvo.getAut_cgnt_nn_apcn_yn())) { // OCR서버 문제있으면...
						aut_cgnt_trv_dstc_rsl_cd = "03";
						aut_cgnt_vh_no_rsl_cd = "03";
					}
					else {
						String propsPath = this.getClass().getResource("").getPath();
						propsPath = propsPath.substring(0, propsPath.indexOf("/classes/")) + "/config/aiocr_ftp.properties";
						
						String aiocrURL = AIOCR_SERVER_PATH;
						CloseableHttpClient httpClient = HttpClients.createDefault();
						HttpPost httpPost = new HttpPost(aiocrURL);
						
						HttpEntity httpEntity = MultipartEntityBuilder.create()
								.addTextBody("templateName", "car.drivingdistance.workflow")
								.addTextBody("senderName", "SMZ")
								.addBinaryBody("Files", new File(files.get(0).toString()), ContentType.MULTIPART_FORM_DATA, files.get(0).toString()).build();
						
						httpPost.setEntity(httpEntity);
						
						CloseableHttpResponse response1 = httpClient.execute(httpPost);
						
						logger.debug("========== start ==========");
						logger.debug("Status Code : " + response1.getStatusLine().getStatusCode());
						logger.debug("========== end ==========");
						
						// json param setting start
						respEntity = response1.getEntity();
						
						String jsonResp = EntityUtils.toString(respEntity);
						logger.debug("AI OCR uploadAiOCR("+files.get(0).toString()+") 응답 json : " + jsonResp);
						
						JSONParser jsonParser = new JSONParser();
						JSONObject jsonObj = (JSONObject) jsonParser.parse(jsonResp);
						JSONArray jsonArray = (JSONArray) jsonObj.get("results");
						
						a_i_o_c_r_rqst_dsky_val	= (String) jsonObj.get("resultItemKey");	// aiocr요청구분키값
						a_i_o_c_r_resultCode = (String) jsonObj.get("resultCode"); // aiocr요청결과코드값(01:정상, 11~33:오류)
						
						if(response1.getStatusLine().getStatusCode() == 200){
							
							logger.debug("[거울]jsonArray : " + jsonArray.get(0) + "jsonArray size : " + jsonArray.size());
							
							if(jsonResp != null){
//								String ocrResultCode = (String) jsonObj.get("resultCode");
								if(!StringUtil.isEmpty(a_i_o_c_r_resultCode)){
									if("01".equals(a_i_o_c_r_resultCode)){
										if(jsonArray.size() > 0) {
											resultMap.put("RE_CODE", "2");
											aut_cgnt_trv_dstc_rsl_cd = "01";
											for(int s = 0; s < jsonArray.size(); s++){
												if(s == 0) {
													JSONObject jsonObject = (JSONObject) jsonArray.get(0);
													logger.debug("new resultValue = " + (String)jsonObject.get("resultValue"));
													logger.debug("new detectionConfidence = " + (String)jsonObject.get("detectionConfidence"));
													logger.debug("new recognitionConfidence = " + (String)jsonObject.get("recognitionConfidence"));
													
													resultMap.put("resultValue", (String)jsonObject.get("resultValue"));
													resultMap.put("detectionConfidence", (String)jsonObject.get("detectionConfidence"));
													resultMap.put("recognitionConfidence", (String)jsonObject.get("recognitionConfidence"));
												} else if(s == 1) {
													JSONObject jsonObject = (JSONObject) jsonArray.get(1);
													logger.debug("new resultValue2 = " + (String)jsonObject.get("resultValue"));
													logger.debug("new detectionConfidence2 = " + (String)jsonObject.get("detectionConfidence"));
													logger.debug("new recognitionConfidence2 = " + (String)jsonObject.get("recognitionConfidence"));
													
													resultMap.put("resultValue2", (String)jsonObject.get("resultValue"));
													resultMap.put("detectionConfidence2", (String)jsonObject.get("detectionConfidence"));
													resultMap.put("recognitionConfidence2", (String)jsonObject.get("recognitionConfidence"));
												} else {
													JSONObject jsonObject = (JSONObject) jsonArray.get(2);
													logger.debug("new resultValue3 = " + (String)jsonObject.get("resultValue"));
													logger.debug("new detectionConfidence3 = " + (String)jsonObject.get("detectionConfidence"));
													logger.debug("new recognitionConfidence3 = " + (String)jsonObject.get("recognitionConfidence"));
													
													resultMap.put("resultValue3", (String)jsonObject.get("resultValue"));
													resultMap.put("detectionConfidence3", (String)jsonObject.get("detectionConfidence"));
													resultMap.put("recognitionConfidence3", (String)jsonObject.get("recognitionConfidence"));
												}
											
												resultValue				= StringUtil.nvl((String)resultMap.get("resultValue"));			// 주행거리 인식값1
												dtcn_cgnt_rt 			= StringUtil.nvl((String)resultMap.get("detectionConfidence"));	// 검출인식률1
												cgnt_cgnt_rt 			= StringUtil.nvl((String)resultMap.get("recognitionConfidence"));	// 인식인식률1
												resultValue2			= StringUtil.nvl((String)resultMap.get("resultValue2"));			// 주행거리 인식값1
												dtcn_cgnt_rt2 			= StringUtil.nvl((String)resultMap.get("detectionConfidence2"));	// 검출인식률1
												cgnt_cgnt_rt2 			= StringUtil.nvl((String)resultMap.get("recognitionConfidence2"));	// 인식인식률1
												resultValue3			= StringUtil.nvl((String)resultMap.get("resultValue3"));			// 주행거리 인식값1
												dtcn_cgnt_rt3 			= StringUtil.nvl((String)resultMap.get("detectionConfidence3"));	// 검출인식률1
												cgnt_cgnt_rt3 			= StringUtil.nvl((String)resultMap.get("recognitionConfidence3"));	// 인식인식률1
											}
											logger.debug("[거울]resultValue = " + resultValue);
											logger.debug("[거울]dtcn_cgnt_rt = " + dtcn_cgnt_rt);
											logger.debug("[거울]cgnt_cgnt_rt = " + cgnt_cgnt_rt);
											logger.debug("[거울]resultValue2 = " + resultValue2);
											logger.debug("[거울]dtcn_cgnt_rt2 = " + dtcn_cgnt_rt2);
											logger.debug("[거울]cgnt_cgnt_rt2 = " + cgnt_cgnt_rt2);
											logger.debug("[거울]resultValue3 = " + resultValue3);
											logger.debug("[거울]dtcn_cgnt_rt3 = " + dtcn_cgnt_rt3);
											logger.debug("[거울]cgnt_cgnt_rt3 = " + cgnt_cgnt_rt3);
										}
									} else {
										resultMap.put("RE_CODE", "1");
										aut_cgnt_trv_dstc_rsl_cd = a_i_o_c_r_resultCode;
										logger.debug("[거울]aut_cgnt_trv_dstc_rsl_cd = " + aut_cgnt_trv_dstc_rsl_cd);
									}
								} else {
									aut_cgnt_trv_dstc_rsl_cd = "02"; //솔루션에서 보내주는 결과코드값이 없는 경우에 02로 세팅
								}
							}
						} 
						else {
//							aut_cgnt_trv_dstc_rsl_cd = "02";
							aut_cgnt_trv_dstc_rsl_cd = a_i_o_c_r_resultCode;
							logger.debug("[거울]aut_cgnt_trv_dstc_rsl_cd = " + aut_cgnt_trv_dstc_rsl_cd);
							if(!"1".equals(jmvo.getCm_yn())) {
								aut_cgnt_vh_no_rsl_cd = "02";
							}
							logger.error("AI OCR uploadAiOCR("+files.get(0).toString()+","+files.size()+") 시 Error 발생 : " + respEntity);
			                throw new Exception("AI OCR 실패 : " + files.get(0).toString() + "/ responseCode :" + response1.getStatusLine().getStatusCode() + "/ responseMsg :" + EntityUtils.toString(respEntity));
						}
						// json param setting end
						httpClient.close();
						// aiocr 서버 통신 end
					}
				}
				catch(Exception e) {
					logger.debug(e.getMessage());
//					aut_cgnt_trv_dstc_rsl_cd = "02";
					aut_cgnt_trv_dstc_rsl_cd = a_i_o_c_r_resultCode;
					if(!"1".equals(jmvo.getCm_yn())) {
						aut_cgnt_vh_no_rsl_cd = "02";
					}
				}
				finally {
					if(ftp != null) ftp.disconnect();
					
					// [200617]
					try{
			    	  	if(in != null){
			    	  		in.close();
			    	  	}
				      }catch(IOException ee){
				    	  System.err.println("[MileageTobeController.mlFileUpload()] IOException 1");
				      }
					try{
			    	  	if(out != null){
			    	  		out.close();
			    	  	}
				      }catch(IOException ee){
				    	  System.err.println("[MileageTobeController.mlFileUpload()] IOException 2");
				      }
					try{
			    	  	if(fis != null){
			    	  		fis.close();
			    	  	}
				      }catch(IOException ee){
				    	  System.err.println("[MileageTobeController.mlFileUpload()] IOException 3");
				      }
				}
			}
			
			logger.debug("a_i_o_c_r_rqst_dsky_val = " + a_i_o_c_r_rqst_dsky_val);
			logger.debug("dtcn_cgnt_rt = " + dtcn_cgnt_rt);
			logger.debug("cgnt_cgnt_rt = " + cgnt_cgnt_rt);
			
			MMTI0259VO jmvo1 = new MMTI0259VO();
			jmvo1.setPbox_use_yn("1");
			jmvo1.setPbox_no(jmvo.getSms_ts_bvan());
			jmvo1.setPhgp_cnfm_dt(DateUtil.getDate());
			jmvo1.setPhgp_ptgr_dt(phgp_ptgr_dt);
			jmvo1.setPhgp_strg_yn("1");
			if("1".equals(jmvo.getAut_cgnt_nn_apcn_yn())) {
				jmvo1.setPbox_chr_nm(request.getParameter("mileage1"));
			}
			
			if("1".equals(jmvo.getPbox_no_dvcd())) {
				if(!"1".equals(jmvo.getCm_yn())) {
					jmvo1.setInpt_trv_dstc(request.getParameter("mileage1"));
					if(!StringUtil.isEmpty(aut_cgnt_vh_no)) {
						jmvo1.setAut_cgnt_vh_no(aut_cgnt_vh_no);
					}
					
					if(!StringUtil.isEmpty(aut_cgnt_vh_no_rsl_cd)) {
						jmvo1.setAut_cgnt_vh_no_rsl_cd(aut_cgnt_vh_no_rsl_cd);
					}
					else {
						jmvo1.setAut_cgnt_vh_no_rsl_cd("02");
					}
				}
					
				if(!StringUtil.isEmpty(aut_cgnt_trv_dstc)) {
					jmvo1.setAut_cgnt_trv_dstc(aut_cgnt_trv_dstc);
				}
				
				if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_rsl_cd)) {
					jmvo1.setAut_cgnt_trv_dstc_rsl_cd(aut_cgnt_trv_dstc_rsl_cd);
				}
				else {
					jmvo1.setAut_cgnt_trv_dstc_rsl_cd("02");
				}
				
				if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_1)) {
					jmvo1.setAut_cgnt_trv_dstc_1(aut_cgnt_trv_dstc_1);
				}
				
				if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_2)) {
					jmvo1.setAut_cgnt_trv_dstc_2(aut_cgnt_trv_dstc_2);
				}
				
				if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_3)) {
					jmvo1.setAut_cgnt_trv_dstc_3(aut_cgnt_trv_dstc_3);
				}
			}
			
			// 200708
			jmvo1.setPhgp_rl_ptgr_dt(phgp_rl_ptgr_dt);
			jmvo1.setPhgp_apdx_way_cd(phgp_apdx_way_cd);
			jmvo1.setA_i_o_c_r_rqst_dsky_val(a_i_o_c_r_rqst_dsky_val);
			jmvo1.setDtcn_cgnt_rt(dtcn_cgnt_rt);
			jmvo1.setCgnt_cgnt_rt(cgnt_cgnt_rt);
			jmvo1.setAut_cgnt_trv_dstc(resultValue);
			jmvo1.setAut_cgnt_trv_dstc_1(resultValue);
			jmvo1.setAut_cgnt_trv_dstc_2(resultValue2);
			jmvo1.setAut_cgnt_trv_dstc_3(resultValue3);
			
			jmvo1 = mileageTobeService.chatMMTI0259VO(jmvo1);
			
			if("0".equals(jmvo1.getErrorCode()) && !"1".equals(jmvo.getCm_yn())) {
				jmvo1.setExp_exca_plan_proc_dvn("1");
				jmvo1.setPlno(jmvo.getPlno());
				
				// 200708
				jmvo1.setPhgp_rl_ptgr_dt(phgp_rl_ptgr_dt);
				jmvo1.setPhgp_apdx_way_cd(phgp_apdx_way_cd);
				
				jmvo1 = mileageTobeService.chatMMTI0259VO(jmvo1);
				
				if("05".equals(jmvo1.getExp_exca_plan_rsl_cd())) {
					mileageTobeService.aiocrRegInfoToEdmsForMobileWeb(request, jmvo.getSms_ts_bvan());
				}
				else if(!StringUtil.isEmpty(jmvo1.getPlno()) && !StringUtil.isEmpty(jmvo1.getExp_exca_plan_no())) {
					mileageTobeService.regInfoToEdmsForMobileWeb2(request, jmvo.getNtft_srv_rc_ormm_cd(), files, jmvo1.getPlno() + "," + jmvo1.getExp_exca_plan_no());
				}
				else {
					mileageTobeService.regInfoToEdmsForMobileWeb2(request, jmvo.getNtft_srv_rc_ormm_cd(), files, jmvo1.getPlno());
				}
			}
			else {
				if("1".equals(jmvo.getCm_yn())) {
					mileageTobeService.aiocrRegInfoToEdmsForMobileWeb(request, jmvo.getSms_ts_bvan());
				}
				else {
					mileageTobeService.regInfoToEdmsForMobileWeb2(request, jmvo.getNtft_srv_rc_ormm_cd(), files, jmvo1.getPlno());
				}
			}
	
			for(int i = 0; i < files.size(); i++) {
				File f = files.get(i);
				String fname = f.getName();
				f.delete();
				logger.debug(fname + " 삭제");
			}
			
			map.put("errorCode",				jmvo1.getErrorCode());
			map.put("exp_exca_plan_rsl_cd",		jmvo1.getExp_exca_plan_rsl_cd());
			map.put("adc_rtrn_dvn",				jmvo1.getAdc_rtrn_dvn());
			map.put("adc_rtrn_prm",				jmvo1.getAdc_rtrn_prm());
			map.put("plno",						jmvo1.getPlno());
			map.put("exp_exca_plan_no",			jmvo1.getExp_exca_plan_no());
			map.put("exp_exca_plan_bse_dd",		jmvo1.getExp_exca_plan_bse_dd());
			map.put("aut_cgnt_vh_no",			jmvo1.getAut_cgnt_vh_no());
			map.put("aut_cgnt_vh_no_rsl_cd",	jmvo1.getAut_cgnt_vh_no_rsl_cd());
			map.put("aut_cgnt_trv_dstc",		jmvo1.getAut_cgnt_trv_dstc());
			map.put("aut_cgnt_trv_dstc_rsl_cd",	jmvo1.getAut_cgnt_trv_dstc_rsl_cd());
			map.put("exp_exca_plan_proc_dvn",	jmvo1.getExp_exca_plan_proc_dvn());
			map.put("cnv_trv_dstc",				jmvo1.getCnv_trv_dstc());
			
			// 200708
			map.put("phgp_rl_ptgr_dt",			phgp_rl_ptgr_dt);
			map.put("phgp_apdx_way_cd", 		phgp_apdx_way_cd);
			
			map.put("aut_cgnt_trv_dstc_1",			resultValue);
			map.put("aut_cgnt_trv_dstc_2",			resultValue2);
			map.put("aut_cgnt_trv_dstc_3",			resultValue3);
			map.put("a_i_o_c_r_rqst_dsky_val", 		a_i_o_c_r_rqst_dsky_val);
			map.put("resultValue", 					resultValue);
			map.put("dtcn_cgnt_rt", 				dtcn_cgnt_rt);
			map.put("cgnt_cgnt_rt", 				cgnt_cgnt_rt);
			map.put("resultValue2", 				resultValue2);
			map.put("dtcn_cgnt_rt2", 				dtcn_cgnt_rt2);
			map.put("cgnt_cgnt_rt2", 				cgnt_cgnt_rt2);
			map.put("resultValue3", 				resultValue3);
			map.put("dtcn_cgnt_rt3", 				dtcn_cgnt_rt3);
			map.put("cgnt_cgnt_rt3", 				cgnt_cgnt_rt3);
		}
		else {
			mileageTobeService.aiocrRegInfoToEdmsForMobileWeb(request, jmvo.getSms_ts_bvan());
			
			MMTI0259VO jmvo1 = new MMTI0259VO();
			jmvo1.setPbox_use_yn("1");
			jmvo1.setPbox_no(jmvo.getSms_ts_bvan());
			jmvo1.setPhgp_cnfm_dt(DateUtil.getDate());
			jmvo1.setPhgp_ptgr_dt(phgp_ptgr_dt);
			jmvo1.setPhgp_strg_yn("1");
			
			// 200708
			jmvo1.setPhgp_rl_ptgr_dt(phgp_rl_ptgr_dt);
			jmvo1.setPhgp_apdx_way_cd(phgp_apdx_way_cd);
			
			if("1".equals(jmvo.getPbox_no_dvcd()) && !"1".equals(jmvo.getCm_yn())) {
				if("03".equals(jmvo.getProc_dvn())) {
					jmvo1.setPbox_chr_nm(request.getParameter("mileage1") + "/" + request.getParameter("mileage2"));
				}
				else {
					jmvo1.setPbox_chr_nm(request.getParameter("mileage1"));
				}
			}
			jmvo1 = mileageTobeService.chatMMTI0259VO(jmvo1);
			
			map.put("errorCode", jmvo1.getErrorCode());
		}
			
		return map;
	}
	
	@RequestMapping(value="/chatMlFileUploadOCR")
	public @ResponseBody Map<String, String> chatMlFileUploadOCR(MultipartHttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		Map<String, String> map = new HashMap<String, String>();
		String yyyymmdd = DateUtil.getDate("yyyymmdd");
		
		String phgp_rl_ptgr_dt	= StringUtil.nvl(request.getParameter("phgp_rl_ptgr_dt"));	// 사진실제촬영일자
		String phgp_apdx_way_cd	= StringUtil.nvl(request.getParameter("phgp_apdx_way_cd"));	// 사진첨부방식코드
		
		String ch_dvn = StringUtil.nvl(request.getParameter("ch_dvn"));
		
		MMTI0213VO jmvo = new MMTI0213VO();
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("p")));
		jmvo = mileageTobeService.chatMMTI0213VO(jmvo);
		
		String exifDate1 = StringUtil.nvl(request.getParameter("exifDate1"));
		
		if(exifDate1.indexOf(",gallery") > -1) {
			exifDate1 = exifDate1.substring(0, exifDate1.indexOf(",gallery"));
			if(StringUtil.isEmpty(exifDate1)) {
				exifDate1 = DateUtil.getDate();
			}
			else if(Integer.parseInt(exifDate1) > Integer.parseInt(DateUtil.getDate())) {
				map.put("errorCode", "f");
				return map;
			}
		}

		if(exifDate1.indexOf(",gallery") > -1) {
			exifDate1 = exifDate1.substring(0, exifDate1.indexOf(",gallery"));
		}

		ArrayList<File> files = mileageTobeService.uploadToWAS(request, jmvo.getSms_ts_bvan());
		
		String aut_cgnt_trv_dstc_rsl_cd = "";	// 자동인식주행거리결과코드
		String aut_cgnt_vh_no_rsl_cd = "";		// 자동인식차량번호결과코드
		String aut_cgnt_trv_dstc = "";			// 자동인식주행거리
		String aut_cgnt_vh_no = "";				// 자동인식차량번호
		
		String aut_cgnt_trv_dstc_1 = "";		// 자동인식주행거리1
		String aut_cgnt_trv_dstc_2 = "";		// 자동인식주행거리2
		String aut_cgnt_trv_dstc_3 = "";		// 자동인식주행거리3
		
		
		boolean flag1 = false;
		if(files.size() > 0) {
			FTPUtil ftp = null;
			// [200617]
			FileInputStream in = null;
			FileOutputStream out = null;
			FileInputStream fis = null;
			
			try {
				if("1".equals(jmvo.getAut_cgnt_nn_apcn_yn())) { // OCR서버 문제있으면...
					aut_cgnt_trv_dstc_rsl_cd = "03";
					aut_cgnt_vh_no_rsl_cd = "03";
				}
				else {
					String propsPath = this.getClass().getResource("").getPath();
					propsPath = propsPath.substring(0, propsPath.indexOf("/classes/")) + "/config/ocr_ftp.properties";
					Properties p = new Properties();
					// [200617]
					in = new FileInputStream(propsPath);
					p.load(in);
					in.close();
					// [200617]
					in = null;
					String password = p.getProperty("password");
					String decPassword = aes256Decrypt(password);
					if(password.equals(decPassword) || StringUtil.isEmpty(decPassword)) {
						decPassword = password;
						String encPassword = aes256Encrypt(password);
						logger.debug("encPassword: " + encPassword);
						// [200617]
						out = new FileOutputStream(propsPath);
						p.setProperty("password", encPassword);
						p.store(out, "");
						out.close();
						// [200617]
						out = null;
					}
					
					ftp = new FTPUtil(p.getProperty("ip"), p.getProperty("user"), decPassword, Integer.parseInt(p.getProperty("port")));
					
					int working = 0;
					for(int i = 1; i <= 3; i++) {
						String[] ls = ftp.ls("/RECOG_JOB" + i + "/" + yyyymmdd);
						for(int j = 0; j < ls.length; j++) {
							if(".".equals(ls[j]) || "..".equals(ls[j])) continue;
							working++;
						}
					}
	
					if(working <= 6) {
						String filename1 = "";
						
						filename1 = ftp.uploadToOCR("/RECOG/" + yyyymmdd, files.get(0), "--D");
						logger.debug("filename1: " + filename1);
						logger.debug("--- 1초 대기 ---");
						Thread.sleep(1000);
						int retryNum = 7;
						for(int retry = 0; retry < retryNum; retry++) {
							String[] ls = ftp.ls("/RECOG_RESULT/" + yyyymmdd);
		
							for(int i = 0; i < ls.length; i++) {
								if(!flag1 && ls[i].equals(filename1)) {
									flag1 = true;
								}
								
								if(flag1) break;
							}
		
							if((flag1) || retry == retryNum - 1) {
								break;
							}
							else {
								logger.debug("--- 0.6초 대기 ---");
								Thread.sleep(600);
							}
						}
						
						logger.debug("flag1: " + flag1);
						
						if(flag1) {
							// [210219]
							if(filename1 != null || !"".equals(filename1)){
								filename1 = filename1.replaceAll("/", "");
								filename1 = filename1.replaceAll("\\\\", "");
								filename1 = filename1.replaceAll("./", "");
								filename1 = filename1.replaceAll("../", "");
								filename1 = filename1.replaceAll("&", "");
							}
							
							String path = files.get(0).getParent() + File.separator + filename1;
							ftp.downloadFromOCR("/RECOG_RESULT/" + yyyymmdd, filename1, path);
							logger.debug("path: " + path);
							
							// [210219]
							File f = new File(files.get(0).getParent() + File.separator + filename1);
							// File f = new File(path);
		
							if(f.exists()) {
								Properties props = new Properties();
								// [210219]
								fis = new FileInputStream(files.get(0).getParent() + File.separator + filename1);
								props.load(fis);
								fis.close();
								// [200617]
								fis = null;
								
								if(!StringUtil.isEmpty(props.getProperty("ODO")) && !StringUtil.isEmpty(props.getProperty("RE_CODE"))) {
									aut_cgnt_trv_dstc = props.getProperty("ODO");
									aut_cgnt_trv_dstc_rsl_cd = "1".equals(props.getProperty("RE_CODE")) || "2".equals(props.getProperty("RE_CODE")) ? "01" : "02";
									
									aut_cgnt_trv_dstc_1 = props.getProperty("ODO");
									
									if(!StringUtil.isEmpty(props.getProperty("ODO2"))) {
										aut_cgnt_trv_dstc_2 = props.getProperty("ODO2");
									}
									
									if(!StringUtil.isEmpty(props.getProperty("ODO3"))) {
										aut_cgnt_trv_dstc_3 = props.getProperty("ODO3");
									}
								}
								
				            	if(f.delete()) {
									logger.debug("삭제: " + path);
								}
							}
						}
						else {
							aut_cgnt_trv_dstc_rsl_cd = "02";
						}						
					}
					else {
						aut_cgnt_trv_dstc_rsl_cd = "02";
						if(!"1".equals(jmvo.getCm_yn())) {
							aut_cgnt_vh_no_rsl_cd = "02";
						}
					}
				}
			}
			catch(Exception e) {
				logger.debug(e.getMessage());
				aut_cgnt_trv_dstc_rsl_cd = "02";
				if(!"1".equals(jmvo.getCm_yn())) {
					aut_cgnt_vh_no_rsl_cd = "02";
				}
			}
			finally {
				if(ftp != null) ftp.disconnect();
				// [200617]
				try{
		    	  	if(in != null){
		    	  		in.close();
		    	  	}
			      }catch(IOException ee){
			    	  System.err.println("[MileageTobeController.chatMlFileUploadOCR()] IOException 1");
			      }
				try{
		    	  	if(out != null){
		    	  		out.close();
		    	  	}
			      }catch(IOException ee){
			    	  System.err.println("[MileageTobeController.chatMlFileUploadOCR()] IOException 2");
			      }
				try{
		    	  	if(fis != null){
		    	  		fis.close();
		    	  	}
			      }catch(IOException ee){
			    	  System.err.println("[MileageTobeController.chatMlFileUploadOCR()] IOException 3");
			      }
			}
		}
		
		HttpSession session = request.getSession();
		Object[] imgfile = new Object[files.size()];
		// [200617]
		FileInputStream fis = null;
		try {
			for(int i = 0; i < files.size(); i++) {
				File f = files.get(i);
				// [200617]
				fis = new FileInputStream(f);
				byte[] file = new byte[(int) f.length()];
				fis.read(file);
				imgfile[i] = file;
				fis.close();
				// [200617]
				fis = null;
				String fname = f.getName();
				f.delete();
				logger.debug(fname + " 삭제");
			}
		} catch (Exception e) {
			logger.debug(e.getMessage());
		}
		// [200617]
		finally {
			try{
				if(fis!=null){
					fis.close();
				}
			}
			catch(IOException ee){
				System.err.println("[MileageTobeController.chatMlFileUploadOCR()] IOException 4");
		    }
		}
		session.setAttribute("imgfile", imgfile);
		
		map.put("errorCode",					"0");
		map.put("aut_cgnt_trv_dstc_rsl_cd",		aut_cgnt_trv_dstc_rsl_cd);
		map.put("aut_cgnt_vh_no_rsl_cd",		aut_cgnt_vh_no_rsl_cd);
		map.put("aut_cgnt_trv_dstc",			aut_cgnt_trv_dstc);
		map.put("aut_cgnt_vh_no",				aut_cgnt_vh_no);
		
		map.put("aut_cgnt_trv_dstc_1",			aut_cgnt_trv_dstc_1);
		map.put("aut_cgnt_trv_dstc_2",			aut_cgnt_trv_dstc_2);
		map.put("aut_cgnt_trv_dstc_3",			aut_cgnt_trv_dstc_3);
		
		map.put("phgp_rl_ptgr_dt",				phgp_rl_ptgr_dt);
		map.put("phgp_apdx_way_cd",				phgp_apdx_way_cd);
			
		map.put("ch_dvn",						ch_dvn);
		return map;
	}
	
	//aiocr용
	@RequestMapping(value="/aiocrChatMlFileUploadOCR")
	public @ResponseBody Map<String, String> aiocrChatMlFileUploadOCR(MultipartHttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		Map<String, String> map = new HashMap<String, String>();
		String yyyymmdd = DateUtil.getDate("yyyymmdd");
		
		String phgp_rl_ptgr_dt	= StringUtil.nvl(request.getParameter("phgp_rl_ptgr_dt"));	// 사진실제촬영일자
		String phgp_apdx_way_cd	= StringUtil.nvl(request.getParameter("phgp_apdx_way_cd"));	// 사진첨부방식코드
		
		String ch_dvn = StringUtil.nvl(request.getParameter("ch_dvn"));
		
		MMTI0213VO jmvo = new MMTI0213VO();
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("p")));
		jmvo = mileageTobeService.chatMMTI0213VO(jmvo);
		
		String exifDate1 = StringUtil.nvl(request.getParameter("exifDate1"));
		
		if(exifDate1.indexOf(",gallery") > -1) {
			exifDate1 = exifDate1.substring(0, exifDate1.indexOf(",gallery"));
			if(StringUtil.isEmpty(exifDate1)) {
				exifDate1 = DateUtil.getDate();
			}
			else if(Integer.parseInt(exifDate1) > Integer.parseInt(DateUtil.getDate())) {
				map.put("errorCode", "f");
				return map;
			}
		}

		if(exifDate1.indexOf(",gallery") > -1) {
			exifDate1 = exifDate1.substring(0, exifDate1.indexOf(",gallery"));
		}

		ArrayList<File> files = mileageTobeService.aiocrUploadToWAS(request, jmvo.getSms_ts_bvan());
		
		String aut_cgnt_trv_dstc_rsl_cd = "";	// 자동인식주행거리결과코드
		String aut_cgnt_vh_no_rsl_cd = "";		// 자동인식차량번호결과코드
		String aut_cgnt_trv_dstc = "";			// 자동인식주행거리
		String aut_cgnt_vh_no = "";				// 자동인식차량번호
		
		String aut_cgnt_trv_dstc_1 = "";		// 자동인식주행거리1
		String aut_cgnt_trv_dstc_2 = "";		// 자동인식주행거리2
		String aut_cgnt_trv_dstc_3 = "";		// 자동인식주행거리3
		
		String a_i_o_c_r_rqst_dsky_val	= "";	// aiocr요청구분키값
		String a_i_o_c_r_resultCode 	= "";	// aiocr요청결과코드값
		String resultValue 				= "";	// 주행거리값1
		String dtcn_cgnt_rt 			= "";	// 검출인식률1
		String cgnt_cgnt_rt 			= "";	// 인식인식률1
		String resultValue2 			= "";	// 주행거리값2
		String dtcn_cgnt_rt2 			= "";	// 검출인식률2
		String cgnt_cgnt_rt2 			= "";	// 인식인식률2
		String resultValue3 			= "";	// 주행거리값3
		String dtcn_cgnt_rt3 			= "";	// 검출인식률3
		String cgnt_cgnt_rt3 			= "";	// 인식인식률3
		String RE_CODE 					= "";
		
		HashMap<String, String> resultMap = null;
		
		boolean flag1 = false;
		if(files.size() > 0) {
			FTPUtil ftp = null;
			// [200617]
			FileInputStream in = null;
			FileOutputStream out = null;
			FileInputStream fis = null;
			
			HttpResponse httpResp = null;
			HttpEntity respEntity = null;
			
			resultMap = new HashMap<String, String>();
			
			try {
				if("1".equals(jmvo.getAut_cgnt_nn_apcn_yn())) { // OCR서버 문제있으면...
					aut_cgnt_trv_dstc_rsl_cd = "03";
					aut_cgnt_vh_no_rsl_cd = "03";
				}
				else {
					String propsPath = this.getClass().getResource("").getPath();
					propsPath = propsPath.substring(0, propsPath.indexOf("/classes/")) + "/config/aiocr_ftp.properties";
					
					String aiocrURL = AIOCR_SERVER_PATH;
					CloseableHttpClient httpClient = HttpClients.createDefault();
					HttpPost httpPost = new HttpPost(aiocrURL);
					
					HttpEntity httpEntity = MultipartEntityBuilder.create()
							.addTextBody("templateName", "car.drivingdistance.workflow")
							.addTextBody("senderName", "SMZ")
							.addBinaryBody("Files", new File(files.get(0).toString()), ContentType.MULTIPART_FORM_DATA, files.get(0).toString()).build();
					
					httpPost.setEntity(httpEntity);
					
					CloseableHttpResponse response1 = httpClient.execute(httpPost);
					
					logger.debug("========== start ==========");
					logger.debug("Status Code : " + response1.getStatusLine().getStatusCode());
					logger.debug("========== end ==========");
					
					// json param setting start
					respEntity = response1.getEntity();
					
					String jsonResp = EntityUtils.toString(respEntity);
					logger.debug("AI OCR uploadAiOCR("+files.get(0).toString()+") 응답 json : " + jsonResp);
					
					JSONParser jsonParser = new JSONParser();
					JSONObject jsonObj = (JSONObject) jsonParser.parse(jsonResp);
					JSONArray jsonArray = (JSONArray) jsonObj.get("results");
					
					a_i_o_c_r_rqst_dsky_val	= (String) jsonObj.get("resultItemKey");	// aiocr요청구분키값
					a_i_o_c_r_resultCode = (String) jsonObj.get("resultCode"); // aiocr요청결과코드값(01:정상, 11~33:오류)
					
					if(response1.getStatusLine().getStatusCode() == 200){
						
						logger.debug("[거울]jsonArray : " + jsonArray.get(0) + "jsonArray size : " + jsonArray.size());
						
						if(jsonResp != null){
//							String ocrResultCode = (String) jsonObj.get("resultCode");
							if(!StringUtil.isEmpty(a_i_o_c_r_resultCode)){
								if("01".equals(a_i_o_c_r_resultCode)){
									if(jsonArray.size() > 0) {
										resultMap.put("RE_CODE", "2");
										aut_cgnt_trv_dstc_rsl_cd = "01";
										for(int s = 0; s < jsonArray.size(); s++){
											if(s == 0) {
												JSONObject jsonObject = (JSONObject) jsonArray.get(0);
												logger.debug("new resultValue = " + (String)jsonObject.get("resultValue"));
												logger.debug("new detectionConfidence = " + (String)jsonObject.get("detectionConfidence"));
												logger.debug("new recognitionConfidence = " + (String)jsonObject.get("recognitionConfidence"));
												
												resultMap.put("resultValue", (String)jsonObject.get("resultValue"));
												resultMap.put("detectionConfidence", (String)jsonObject.get("detectionConfidence"));
												resultMap.put("recognitionConfidence", (String)jsonObject.get("recognitionConfidence"));
											} else if(s == 1) {
												JSONObject jsonObject = (JSONObject) jsonArray.get(1);
												logger.debug("new resultValue2 = " + (String)jsonObject.get("resultValue"));
												logger.debug("new detectionConfidence2 = " + (String)jsonObject.get("detectionConfidence"));
												logger.debug("new recognitionConfidence2 = " + (String)jsonObject.get("recognitionConfidence"));
												
												resultMap.put("resultValue2", (String)jsonObject.get("resultValue"));
												resultMap.put("detectionConfidence2", (String)jsonObject.get("detectionConfidence"));
												resultMap.put("recognitionConfidence2", (String)jsonObject.get("recognitionConfidence"));
											} else {
												JSONObject jsonObject = (JSONObject) jsonArray.get(2);
												logger.debug("new resultValue3 = " + (String)jsonObject.get("resultValue"));
												logger.debug("new detectionConfidence3 = " + (String)jsonObject.get("detectionConfidence"));
												logger.debug("new recognitionConfidence3 = " + (String)jsonObject.get("recognitionConfidence"));
												
												resultMap.put("resultValue3", (String)jsonObject.get("resultValue"));
												resultMap.put("detectionConfidence3", (String)jsonObject.get("detectionConfidence"));
												resultMap.put("recognitionConfidence3", (String)jsonObject.get("recognitionConfidence"));
											}
										
											resultValue				= StringUtil.nvl((String)resultMap.get("resultValue"));			// 주행거리 인식값1
											dtcn_cgnt_rt 			= StringUtil.nvl((String)resultMap.get("detectionConfidence"));	// 검출인식률1
											cgnt_cgnt_rt 			= StringUtil.nvl((String)resultMap.get("recognitionConfidence"));	// 인식인식률1
											resultValue2			= StringUtil.nvl((String)resultMap.get("resultValue2"));			// 주행거리 인식값1
											dtcn_cgnt_rt2 			= StringUtil.nvl((String)resultMap.get("detectionConfidence2"));	// 검출인식률1
											cgnt_cgnt_rt2 			= StringUtil.nvl((String)resultMap.get("recognitionConfidence2"));	// 인식인식률1
											resultValue3			= StringUtil.nvl((String)resultMap.get("resultValue3"));			// 주행거리 인식값1
											dtcn_cgnt_rt3 			= StringUtil.nvl((String)resultMap.get("detectionConfidence3"));	// 검출인식률1
											cgnt_cgnt_rt3 			= StringUtil.nvl((String)resultMap.get("recognitionConfidence3"));	// 인식인식률1
										}
										logger.debug("[거울]resultValue = " + resultValue);
										logger.debug("[거울]dtcn_cgnt_rt = " + dtcn_cgnt_rt);
										logger.debug("[거울]cgnt_cgnt_rt = " + cgnt_cgnt_rt);
										logger.debug("[거울]resultValue2 = " + resultValue2);
										logger.debug("[거울]dtcn_cgnt_rt2 = " + dtcn_cgnt_rt2);
										logger.debug("[거울]cgnt_cgnt_rt2 = " + cgnt_cgnt_rt2);
										logger.debug("[거울]resultValue3 = " + resultValue3);
										logger.debug("[거울]dtcn_cgnt_rt3 = " + dtcn_cgnt_rt3);
										logger.debug("[거울]cgnt_cgnt_rt3 = " + cgnt_cgnt_rt3);
									}
								} else {
									resultMap.put("RE_CODE", "1");
									aut_cgnt_trv_dstc_rsl_cd = a_i_o_c_r_resultCode;
									logger.debug("[거울]aut_cgnt_trv_dstc_rsl_cd = " + aut_cgnt_trv_dstc_rsl_cd);
								}
							} else {
								aut_cgnt_trv_dstc_rsl_cd = "02";
							}
						}
					}
					else {
//						aut_cgnt_trv_dstc_rsl_cd = "02";
						aut_cgnt_trv_dstc_rsl_cd = a_i_o_c_r_resultCode;
						logger.debug("[거울]aut_cgnt_trv_dstc_rsl_cd = " + aut_cgnt_trv_dstc_rsl_cd);
						
						if(!"1".equals(jmvo.getCm_yn())) {
							aut_cgnt_vh_no_rsl_cd = "02";
						}
						
						logger.error("AI OCR uploadAiOCR("+files.get(0).toString()+","+files.size()+") 시 Error 발생 : " + respEntity);
		                throw new Exception("AI OCR 실패 : " + files.get(0).toString() + "/ responseCode :" + response1.getStatusLine().getStatusCode() + "/ responseMsg :" + EntityUtils.toString(respEntity));
					}
					// json param setting end
					httpClient.close();
					// aiocr 서버 통신 end
				}
			}
			catch(Exception e) {
				logger.debug(e.getMessage());
//				aut_cgnt_trv_dstc_rsl_cd = "02";
				aut_cgnt_trv_dstc_rsl_cd = a_i_o_c_r_resultCode;
				if(!"1".equals(jmvo.getCm_yn())) {
					aut_cgnt_vh_no_rsl_cd = "02";
				}
			}
			finally {
				if(ftp != null) ftp.disconnect();
				// [200617]
				try{
		    	  	if(in != null){
		    	  		in.close();
		    	  	}
			      }catch(IOException ee){
			    	  System.err.println("[MileageTobeController.chatMlFileUploadOCR()] IOException 1");
			      }
				try{
		    	  	if(out != null){
		    	  		out.close();
		    	  	}
			      }catch(IOException ee){
			    	  System.err.println("[MileageTobeController.chatMlFileUploadOCR()] IOException 2");
			      }
				try{
		    	  	if(fis != null){
		    	  		fis.close();
		    	  	}
			      }catch(IOException ee){
			    	  System.err.println("[MileageTobeController.chatMlFileUploadOCR()] IOException 3");
			      }
			}
		}
		
		HttpSession session = request.getSession();
		Object[] imgfile = new Object[files.size()];
		// [200617]
		FileInputStream fis = null;
		try {
			for(int i = 0; i < files.size(); i++) {
				File f = files.get(i);
				// [200617]
				fis = new FileInputStream(f);
				byte[] file = new byte[(int) f.length()];
				fis.read(file);
				imgfile[i] = file;
				fis.close();
				// [200617]
				fis = null;
				String fname = f.getName();
				f.delete();
				logger.debug(fname + " 삭제");
			}
		} catch (Exception e) {
			logger.debug(e.getMessage());
		}
		// [200617]
		finally {
			try{
				if(fis!=null){
					fis.close();
				}
			}
			catch(IOException ee){
				System.err.println("[MileageTobeController.chatMlFileUploadOCR()] IOException 4");
		    }
		}
		session.setAttribute("imgfile", imgfile);
		
		logger.debug("a_i_o_c_r_rqst_dsky_val = " + a_i_o_c_r_rqst_dsky_val);
		logger.debug("dtcn_cgnt_rt = " + dtcn_cgnt_rt);
		logger.debug("cgnt_cgnt_rt = " + cgnt_cgnt_rt);
		
		map.put("errorCode",					"0");
		map.put("aut_cgnt_trv_dstc_rsl_cd",		aut_cgnt_trv_dstc_rsl_cd);
		map.put("aut_cgnt_vh_no_rsl_cd",		aut_cgnt_vh_no_rsl_cd);
		map.put("aut_cgnt_trv_dstc",			resultValue);
		map.put("aut_cgnt_vh_no",				aut_cgnt_vh_no);
		
		map.put("aut_cgnt_trv_dstc_1",			resultValue);
		map.put("aut_cgnt_trv_dstc_2",			resultValue2);
		map.put("aut_cgnt_trv_dstc_3",			resultValue3);
		
		map.put("phgp_rl_ptgr_dt",				phgp_rl_ptgr_dt);
		map.put("phgp_apdx_way_cd",				phgp_apdx_way_cd);
			
		map.put("ch_dvn",						ch_dvn);
		
		map.put("a_i_o_c_r_rqst_dsky_val", 		a_i_o_c_r_rqst_dsky_val);
		map.put("resultValue", 					resultValue);
		map.put("dtcn_cgnt_rt", 				dtcn_cgnt_rt);
		map.put("cgnt_cgnt_rt", 				cgnt_cgnt_rt);
		map.put("resultValue2", 				resultValue2);
		map.put("dtcn_cgnt_rt2", 				dtcn_cgnt_rt2);
		map.put("cgnt_cgnt_rt2", 				cgnt_cgnt_rt2);
		map.put("resultValue3", 				resultValue3);
		map.put("dtcn_cgnt_rt3", 				dtcn_cgnt_rt3);
		map.put("cgnt_cgnt_rt3", 				cgnt_cgnt_rt3);
		
		return map;
	}
	
	@RequestMapping(value="/chatMlFileUploadOCR2")
	public @ResponseBody Map<String, String> chatMlFileUploadOCR2(MultipartHttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		Map<String, String> map = new HashMap<String, String>();

		String aut_cgnt_trv_dstc_rsl_cd	= StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc_rsl_cd"));	// 자동인식주행거리결과코드
		String aut_cgnt_vh_no_rsl_cd	= StringUtil.nvl(request.getParameter("aut_cgnt_vh_no_rsl_cd"));	// 자동인식차량번호결과코드
		String aut_cgnt_trv_dstc		= StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc"));		// 자동인식주행거리
		String aut_cgnt_vh_no			= StringUtil.nvl(request.getParameter("aut_cgnt_vh_no"));			// 자동인식차량번호
		
		String aut_cgnt_trv_dstc_1		= StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc_1"));		// 자동인식주행거리
		String aut_cgnt_trv_dstc_2		= StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc_2"));		// 자동인식주행거리
		String aut_cgnt_trv_dstc_3		= StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc_3"));		// 자동인식주행거리
		
		String phgp_rl_ptgr_dt			= StringUtil.nvl(request.getParameter("phgp_rl_ptgr_dt"));			// 사진실제촬영일자
		String phgp_apdx_way_cd			= StringUtil.nvl(request.getParameter("phgp_apdx_way_cd"));			// 사진첨부방식코드
		
		String ch_dvn = StringUtil.nvl(request.getParameter("ch_dvn"));
		
		MMTI0213VO jmvo = new MMTI0213VO();
		MBTR01001VO mbtr01001vo = new MBTR01001VO();
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("p")));
		jmvo = mileageTobeService.chatMMTI0213VO(jmvo);
		
		String exifDate1 = StringUtil.nvl(request.getParameter("exifDate1"));
		String phgp_ptgr_dt = "";
		
		boolean empty = false;
		if(exifDate1.indexOf(",gallery") > -1) {
			exifDate1 = exifDate1.substring(0, exifDate1.indexOf(",gallery"));
			if(StringUtil.isEmpty(exifDate1)) {
				exifDate1 = DateUtil.getDate();
				empty = true;
			}
			else if(Integer.parseInt(exifDate1) > Integer.parseInt(DateUtil.getDate())) {
				map.put("errorCode", "f");
				return map;
			}
		}

		phgp_ptgr_dt = empty ? "" : exifDate1;
		
		if(exifDate1.indexOf(",gallery") > -1) {
			exifDate1 = exifDate1.substring(0, exifDate1.indexOf(",gallery"));
		}
		
		HttpSession session = request.getSession();
		session.setAttribute("exifDate", exifDate1);

		ArrayList<File> files = mileageTobeService.uploadToWAS(request, jmvo.getSms_ts_bvan());
		
		MMTI0259VO jmvo1 = new MMTI0259VO();
		jmvo1.setPbox_use_yn("1");
		jmvo1.setPbox_no(jmvo.getSms_ts_bvan());
		jmvo1.setPhgp_cnfm_dt(DateUtil.getDate());
		jmvo1.setPhgp_ptgr_dt(phgp_ptgr_dt);
		jmvo1.setPhgp_strg_yn("1");
		if("1".equals(jmvo.getAut_cgnt_nn_apcn_yn())) {
			jmvo1.setPbox_chr_nm(request.getParameter("mileage1"));
		}
		
		if("1".equals(jmvo.getPbox_no_dvcd())) {
			if(!"1".equals(jmvo.getCm_yn())) {
				jmvo1.setInpt_trv_dstc(request.getParameter("mileage1"));
				if(!StringUtil.isEmpty(aut_cgnt_vh_no)) {
					jmvo1.setAut_cgnt_vh_no(aut_cgnt_vh_no);
				}
				
				if(!StringUtil.isEmpty(aut_cgnt_vh_no_rsl_cd)) {
					jmvo1.setAut_cgnt_vh_no_rsl_cd(aut_cgnt_vh_no_rsl_cd);
				}
				else {
					jmvo1.setAut_cgnt_vh_no_rsl_cd("02");
				}
			}
				
			if(!StringUtil.isEmpty(aut_cgnt_trv_dstc)) {
				jmvo1.setAut_cgnt_trv_dstc(aut_cgnt_trv_dstc);
			}
			
			if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_rsl_cd)) {
				jmvo1.setAut_cgnt_trv_dstc_rsl_cd(aut_cgnt_trv_dstc_rsl_cd);
			}
			else {
				jmvo1.setAut_cgnt_trv_dstc_rsl_cd("02");
			}
			
			if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_1)) {
				jmvo1.setAut_cgnt_trv_dstc_1(aut_cgnt_trv_dstc_1);
			}
			
			if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_2)) {
				jmvo1.setAut_cgnt_trv_dstc_2(aut_cgnt_trv_dstc_2);
			}
			
			if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_3)) {
				jmvo1.setAut_cgnt_trv_dstc_3(aut_cgnt_trv_dstc_3);
			}
		}
		
		// 200708
		jmvo1.setPhgp_rl_ptgr_dt(phgp_rl_ptgr_dt);
		jmvo1.setPhgp_apdx_way_cd(phgp_apdx_way_cd);
		
		jmvo1 = mileageTobeService.chatMMTI0259VO(jmvo1);
		
		if("0".equals(jmvo1.getErrorCode()) && !"1".equals(jmvo.getCm_yn())) {
			jmvo1.setExp_exca_plan_proc_dvn("1");
			jmvo1.setPlno(jmvo.getPlno());
			
			// 200708
			jmvo1.setPhgp_rl_ptgr_dt(phgp_rl_ptgr_dt);
			jmvo1.setPhgp_apdx_way_cd(phgp_apdx_way_cd);
			
			jmvo1 = mileageTobeService.chatMMTI0259VO(jmvo1);
			
			if("08".equals(jmvo.getProc_dvn())) {
				mbtr01001vo = mileageTobeService.regInfoToEdmsForMobileWeb2(request, jmvo.getNtft_srv_rc_ormm_cd(), files, jmvo.getPlno() + "," + jmvo.getChng_plan_no(), mbtr01001vo);
			}
			else if(!StringUtil.isEmpty(jmvo1.getPlno()) && !StringUtil.isEmpty(jmvo1.getExp_exca_plan_no())) {
				mbtr01001vo = mileageTobeService.regInfoToEdmsForMobileWeb2(request, jmvo.getNtft_srv_rc_ormm_cd(), files, jmvo1.getPlno() + "," + jmvo1.getExp_exca_plan_no(), mbtr01001vo);
			}
			else if(!StringUtil.isEmpty(jmvo1.getPlno()) && StringUtil.isEmpty(jmvo1.getExp_exca_plan_no())) {
				mbtr01001vo = mileageTobeService.regInfoToEdmsForMobileWeb2(request, jmvo.getNtft_srv_rc_ormm_cd(), files, jmvo1.getPlno(), mbtr01001vo);
			}
		}
		else {
			if("1".equals(jmvo.getCm_yn())) {
				mbtr01001vo = mileageTobeService.regInfoToEdmsForMobileWeb(request, jmvo.getSms_ts_bvan(), mbtr01001vo);
			}
			else {
				mbtr01001vo = mileageTobeService.regInfoToEdmsForMobileWeb2(request, jmvo.getNtft_srv_rc_ormm_cd(), files, jmvo1.getPlno(), mbtr01001vo);
			}
		}
		
		int insertRow = 0;
		
		// VO SET
		mbtr01001vo.setPboxNo(jmvo.getSms_ts_bvan());
		mbtr01001vo.setApdxFlRutNm("");
		mbtr01001vo.setFrstIpmnEmpno("82101685");
		mbtr01001vo.setFnalAmdrEmpno("82101685");
		
		insertRow = mileageTobeService.insertTest(mbtr01001vo);
		if(insertRow < 1){
			logger.info("#### 사서함번호: " + StringUtil.nvl(mbtr01001vo.getPboxNo()) + "####");
			logger.info("#### insert 결과: Fail ####");
		}else{
			logger.info("#### insert 결과: Success ####");
		}

		for(int i = 0; i < files.size(); i++) {
			File f = files.get(i);
			String fname = f.getName();
			f.delete();
			logger.debug(fname + " 삭제");
		}
		
		map.put("errorCode",				jmvo1.getErrorCode());
		map.put("z_resp_msg",				jmvo1.getZ_resp_msg());
		map.put("exp_exca_plan_rsl_cd",		jmvo1.getExp_exca_plan_rsl_cd());
		map.put("adc_rtrn_dvn",				jmvo1.getAdc_rtrn_dvn());
		map.put("adc_rtrn_prm",				jmvo1.getAdc_rtrn_prm());
		map.put("plno",						jmvo1.getPlno());
		map.put("exp_exca_plan_no",			jmvo1.getExp_exca_plan_no());
		map.put("exp_exca_plan_bse_dd",		jmvo1.getExp_exca_plan_bse_dd());
		map.put("aut_cgnt_vh_no",			jmvo1.getAut_cgnt_vh_no());
		map.put("aut_cgnt_vh_no_rsl_cd",	jmvo1.getAut_cgnt_vh_no_rsl_cd());
		map.put("aut_cgnt_trv_dstc",		jmvo1.getAut_cgnt_trv_dstc());
		map.put("aut_cgnt_trv_dstc_rsl_cd",	jmvo1.getAut_cgnt_trv_dstc_rsl_cd());
		map.put("exp_exca_plan_proc_dvn",	jmvo1.getExp_exca_plan_proc_dvn());
		map.put("cnv_trv_dstc",				jmvo1.getCnv_trv_dstc());
		map.put("plhd_cust_nm", 			jmvo1.getPlhd_cust_nm());
		map.put("pdc_sr_dvn", 				jmvo1.getPdc_sr_dvn());
		map.put("ch_dvn",	 				ch_dvn);
		map.put("inpt_trv_dstc", 			jmvo1.getInpt_trv_dstc());
		
		//210714
		session.setAttribute("crd_scn_cncl_pss_yn", StringUtil.nvl(jmvo1.getCrd_scn_cncl_pss_yn()));
		session.setAttribute("stlm_cdcp_nm", StringUtil.nvl(jmvo1.getStlm_cdcp_nm()));
		session.setAttribute("stlm_crd_no", StringUtil.nvl(jmvo1.getStlm_crd_no()));
		
		// 201111 추가
		session.setAttribute("trv_dstc1", request.getParameter("mileage1"));
		// 210708 추가
		session.setAttribute("errorCode", jmvo1.getErrorCode());
		session.setAttribute("exp_exca_plan_rsl_cd", jmvo1.getExp_exca_plan_rsl_cd());
		
		session.setAttribute("cnv_trv_dstc", jmvo1.getCnv_trv_dstc());
		session.setAttribute("adc_rtrn_dvn", jmvo1.getAdc_rtrn_dvn());
		session.setAttribute("adc_rtrn_prm", jmvo1.getAdc_rtrn_prm());
		
		session.setAttribute("plno", jmvo1.getPlno());
		session.setAttribute("exp_exca_plan_no", jmvo1.getExp_exca_plan_no());
		session.setAttribute("exp_exca_plan_bse_dd", jmvo1.getExp_exca_plan_bse_dd());
		session.setAttribute("aut_cgnt_vh_no", jmvo1.getAut_cgnt_vh_no());
		session.setAttribute("aut_cgnt_vh_no_rsl_cd", jmvo1.getAut_cgnt_vh_no_rsl_cd());
		session.setAttribute("aut_cgnt_trv_dstc", jmvo1.getAut_cgnt_trv_dstc());
		session.setAttribute("aut_cgnt_trv_dstc_rsl_cd", jmvo1.getAut_cgnt_trv_dstc_rsl_cd());
		session.setAttribute("exp_exca_plan_proc_dvn", jmvo1.getExp_exca_plan_proc_dvn());
		session.setAttribute("cnv_trv_dstc", jmvo1.getCnv_trv_dstc());
		session.setAttribute("plhd_cust_nm", jmvo1.getPlhd_cust_nm());
		session.setAttribute("pdc_sr_dvn", jmvo1.getPdc_sr_dvn());
		
		
		return map;
	}
	
	//aiocr용
	@RequestMapping(value="/aiocrChatMlFileUploadOCR2")
	public @ResponseBody Map<String, String> aiocrChatMlFileUploadOCR2(MultipartHttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		Map<String, String> map = new HashMap<String, String>();

		String aut_cgnt_trv_dstc_rsl_cd	= StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc_rsl_cd"));	// 자동인식주행거리결과코드
		String aut_cgnt_vh_no_rsl_cd	= StringUtil.nvl(request.getParameter("aut_cgnt_vh_no_rsl_cd"));	// 자동인식차량번호결과코드
		String aut_cgnt_trv_dstc		= StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc"));		// 자동인식주행거리
		String aut_cgnt_vh_no			= StringUtil.nvl(request.getParameter("aut_cgnt_vh_no"));			// 자동인식차량번호
		
		String aut_cgnt_trv_dstc_1		= StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc_1"));		// 자동인식주행거리
		String aut_cgnt_trv_dstc_2		= StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc_2"));		// 자동인식주행거리
		String aut_cgnt_trv_dstc_3		= StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc_3"));		// 자동인식주행거리
		
		String a_i_o_c_r_rqst_dsky_val	= StringUtil.nvl(request.getParameter("a_i_o_c_r_rqst_dsky_val"));	// aiocr요청구분키값
		String resultValue 				= StringUtil.nvl(request.getParameter("resultValue"));				// 주행거리 인식값
		String dtcn_cgnt_rt 			= StringUtil.nvl(request.getParameter("dtcn_cgnt_rt"));				// 검출인식률
		String cgnt_cgnt_rt 			= StringUtil.nvl(request.getParameter("cgnt_cgnt_rt"));				// 인식인식률
		
		String phgp_rl_ptgr_dt			= StringUtil.nvl(request.getParameter("phgp_rl_ptgr_dt"));			// 사진실제촬영일자
		String phgp_apdx_way_cd			= StringUtil.nvl(request.getParameter("phgp_apdx_way_cd"));			// 사진첨부방식코드
		
		String ch_dvn = StringUtil.nvl(request.getParameter("ch_dvn"));
		
		MMTI0213VO jmvo = new MMTI0213VO();
		MBTR01001VO mbtr01001vo = new MBTR01001VO();
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("p")));
		jmvo = mileageTobeService.chatMMTI0213VO(jmvo);
		
		String exifDate1 = StringUtil.nvl(request.getParameter("exifDate1"));
		String phgp_ptgr_dt = "";
		
		boolean empty = false;
		if(exifDate1.indexOf(",gallery") > -1) {
			exifDate1 = exifDate1.substring(0, exifDate1.indexOf(",gallery"));
			if(StringUtil.isEmpty(exifDate1)) {
				exifDate1 = DateUtil.getDate();
				empty = true;
			}
			else if(Integer.parseInt(exifDate1) > Integer.parseInt(DateUtil.getDate())) {
				map.put("errorCode", "f");
				return map;
			}
		}

		phgp_ptgr_dt = empty ? "" : exifDate1;
		
		if(exifDate1.indexOf(",gallery") > -1) {
			exifDate1 = exifDate1.substring(0, exifDate1.indexOf(",gallery"));
		}
		
		HttpSession session = request.getSession();
		session.setAttribute("exifDate", exifDate1);

		ArrayList<File> files = mileageTobeService.aiocrUploadToWAS(request, jmvo.getSms_ts_bvan());
		
		MMTI0259VO jmvo1 = new MMTI0259VO();
		jmvo1.setPbox_use_yn("1");
		jmvo1.setPbox_no(jmvo.getSms_ts_bvan());
		jmvo1.setPhgp_cnfm_dt(DateUtil.getDate());
		jmvo1.setPhgp_ptgr_dt(phgp_ptgr_dt);
		jmvo1.setPhgp_strg_yn("1");
		if("1".equals(jmvo.getAut_cgnt_nn_apcn_yn())) {
			jmvo1.setPbox_chr_nm(request.getParameter("mileage1"));
		}
		
		if("1".equals(jmvo.getPbox_no_dvcd())) {
			if(!"1".equals(jmvo.getCm_yn())) {
				jmvo1.setInpt_trv_dstc(request.getParameter("mileage1"));
				if(!StringUtil.isEmpty(aut_cgnt_vh_no)) {
					jmvo1.setAut_cgnt_vh_no(aut_cgnt_vh_no);
				}
				
				if(!StringUtil.isEmpty(aut_cgnt_vh_no_rsl_cd)) {
					jmvo1.setAut_cgnt_vh_no_rsl_cd(aut_cgnt_vh_no_rsl_cd);
				}
				else {
					jmvo1.setAut_cgnt_vh_no_rsl_cd("02");
				}
			}
				
			if(!StringUtil.isEmpty(aut_cgnt_trv_dstc)) {
				jmvo1.setAut_cgnt_trv_dstc(aut_cgnt_trv_dstc);
			}
			
			if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_rsl_cd)) {
				jmvo1.setAut_cgnt_trv_dstc_rsl_cd(aut_cgnt_trv_dstc_rsl_cd);
			}
			else {
				jmvo1.setAut_cgnt_trv_dstc_rsl_cd("02");
			}
			
			if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_1)) {
				jmvo1.setAut_cgnt_trv_dstc_1(aut_cgnt_trv_dstc_1);
			}
			
			if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_2)) {
				jmvo1.setAut_cgnt_trv_dstc_2(aut_cgnt_trv_dstc_2);
			}
			
			if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_3)) {
				jmvo1.setAut_cgnt_trv_dstc_3(aut_cgnt_trv_dstc_3);
			}
			
			if(!StringUtil.isEmpty(a_i_o_c_r_rqst_dsky_val)) {
				jmvo1.setA_i_o_c_r_rqst_dsky_val(a_i_o_c_r_rqst_dsky_val);
			}
			
			if(!StringUtil.isEmpty(dtcn_cgnt_rt)) {
				jmvo1.setDtcn_cgnt_rt(dtcn_cgnt_rt);
			}
			
			if(!StringUtil.isEmpty(cgnt_cgnt_rt)) {
				jmvo1.setCgnt_cgnt_rt(cgnt_cgnt_rt);
			}
		}
		
		// 200708
		jmvo1.setPhgp_rl_ptgr_dt(phgp_rl_ptgr_dt);
		jmvo1.setPhgp_apdx_way_cd(phgp_apdx_way_cd);
		
		jmvo1 = mileageTobeService.chatMMTI0259VO(jmvo1);
		
		if("0".equals(jmvo1.getErrorCode()) && !"1".equals(jmvo.getCm_yn())) {
			jmvo1.setExp_exca_plan_proc_dvn("1");
			jmvo1.setPlno(jmvo.getPlno());
			
			// 200708
			jmvo1.setPhgp_rl_ptgr_dt(phgp_rl_ptgr_dt);
			jmvo1.setPhgp_apdx_way_cd(phgp_apdx_way_cd);
			
			jmvo1 = mileageTobeService.chatMMTI0259VO(jmvo1);
			
			if("08".equals(jmvo.getProc_dvn())) {
				mbtr01001vo = mileageTobeService.regInfoToEdmsForMobileWeb2(request, jmvo.getNtft_srv_rc_ormm_cd(), files, jmvo.getPlno() + "," + jmvo.getChng_plan_no(), mbtr01001vo);
			}
			else if(!StringUtil.isEmpty(jmvo1.getPlno()) && !StringUtil.isEmpty(jmvo1.getExp_exca_plan_no())) {
				mbtr01001vo = mileageTobeService.regInfoToEdmsForMobileWeb2(request, jmvo.getNtft_srv_rc_ormm_cd(), files, jmvo1.getPlno() + "," + jmvo1.getExp_exca_plan_no(), mbtr01001vo);
			}
			else if(!StringUtil.isEmpty(jmvo1.getPlno()) && StringUtil.isEmpty(jmvo1.getExp_exca_plan_no())) {
				mbtr01001vo = mileageTobeService.regInfoToEdmsForMobileWeb2(request, jmvo.getNtft_srv_rc_ormm_cd(), files, jmvo1.getPlno(), mbtr01001vo);
			}
		}
		else {
			if("1".equals(jmvo.getCm_yn())) {
				mbtr01001vo = mileageTobeService.aiocrRegInfoToEdmsForMobileWeb(request, jmvo.getSms_ts_bvan(), mbtr01001vo);
			}
			else {
				mbtr01001vo = mileageTobeService.regInfoToEdmsForMobileWeb2(request, jmvo.getNtft_srv_rc_ormm_cd(), files, jmvo1.getPlno(), mbtr01001vo);
			}
		}
		
		int insertRow = 0;
		
		// VO SET
		mbtr01001vo.setPboxNo(jmvo.getSms_ts_bvan());
		mbtr01001vo.setApdxFlRutNm("");
		mbtr01001vo.setFrstIpmnEmpno("82101685");
		mbtr01001vo.setFnalAmdrEmpno("82101685");
		
		insertRow = mileageTobeService.insertTest(mbtr01001vo);
		if(insertRow < 1){
			logger.info("#### 사서함번호: " + StringUtil.nvl(mbtr01001vo.getPboxNo()) + "####");
			logger.info("#### insert 결과: Fail ####");
		}else{
			logger.info("#### insert 결과: Success ####");
		}

		for(int i = 0; i < files.size(); i++) {
			File f = files.get(i);
			String fname = f.getName();
			f.delete();
			logger.debug(fname + " 삭제");
		}
		
		map.put("errorCode",				jmvo1.getErrorCode());
		map.put("z_resp_msg",				jmvo1.getZ_resp_msg());
		map.put("exp_exca_plan_rsl_cd",		jmvo1.getExp_exca_plan_rsl_cd());
		map.put("adc_rtrn_dvn",				jmvo1.getAdc_rtrn_dvn());
		map.put("adc_rtrn_prm",				jmvo1.getAdc_rtrn_prm());
		map.put("plno",						jmvo1.getPlno());
		map.put("exp_exca_plan_no",			jmvo1.getExp_exca_plan_no());
		map.put("exp_exca_plan_bse_dd",		jmvo1.getExp_exca_plan_bse_dd());
		map.put("aut_cgnt_vh_no",			jmvo1.getAut_cgnt_vh_no());
		map.put("aut_cgnt_vh_no_rsl_cd",	jmvo1.getAut_cgnt_vh_no_rsl_cd());
		map.put("aut_cgnt_trv_dstc",		jmvo1.getAut_cgnt_trv_dstc());
		map.put("aut_cgnt_trv_dstc_rsl_cd",	jmvo1.getAut_cgnt_trv_dstc_rsl_cd());
		map.put("exp_exca_plan_proc_dvn",	jmvo1.getExp_exca_plan_proc_dvn());
		map.put("cnv_trv_dstc",				jmvo1.getCnv_trv_dstc());
		map.put("plhd_cust_nm", 			jmvo1.getPlhd_cust_nm());
		map.put("pdc_sr_dvn", 				jmvo1.getPdc_sr_dvn());
		map.put("ch_dvn",	 				ch_dvn);
		map.put("inpt_trv_dstc", 			jmvo1.getInpt_trv_dstc());
		
		//210714
		session.setAttribute("crd_scn_cncl_pss_yn", StringUtil.nvl(jmvo1.getCrd_scn_cncl_pss_yn()));
		session.setAttribute("stlm_cdcp_nm", StringUtil.nvl(jmvo1.getStlm_cdcp_nm()));
		session.setAttribute("stlm_crd_no", StringUtil.nvl(jmvo1.getStlm_crd_no()));
		
		// 201111 추가
		session.setAttribute("trv_dstc1", request.getParameter("mileage1"));
		// 210708 추가
		session.setAttribute("errorCode", jmvo1.getErrorCode());
		session.setAttribute("exp_exca_plan_rsl_cd", jmvo1.getExp_exca_plan_rsl_cd());
		
		session.setAttribute("cnv_trv_dstc", jmvo1.getCnv_trv_dstc());
		session.setAttribute("adc_rtrn_dvn", jmvo1.getAdc_rtrn_dvn());
		session.setAttribute("adc_rtrn_prm", jmvo1.getAdc_rtrn_prm());
		
		session.setAttribute("plno", jmvo1.getPlno());
		session.setAttribute("exp_exca_plan_no", jmvo1.getExp_exca_plan_no());
		session.setAttribute("exp_exca_plan_bse_dd", jmvo1.getExp_exca_plan_bse_dd());
		session.setAttribute("aut_cgnt_vh_no", jmvo1.getAut_cgnt_vh_no());
		session.setAttribute("aut_cgnt_vh_no_rsl_cd", jmvo1.getAut_cgnt_vh_no_rsl_cd());
		session.setAttribute("aut_cgnt_trv_dstc", jmvo1.getAut_cgnt_trv_dstc());
		session.setAttribute("aut_cgnt_trv_dstc_rsl_cd", jmvo1.getAut_cgnt_trv_dstc_rsl_cd());
		session.setAttribute("exp_exca_plan_proc_dvn", jmvo1.getExp_exca_plan_proc_dvn());
		session.setAttribute("cnv_trv_dstc", jmvo1.getCnv_trv_dstc());
		session.setAttribute("plhd_cust_nm", jmvo1.getPlhd_cust_nm());
		session.setAttribute("pdc_sr_dvn", jmvo1.getPdc_sr_dvn());
		
		
		return map;
	}
	
	private String getDayTime() throws Exception{
		logger.debug("### getDayTime() 시작 ##########################");
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss", Locale.KOREAN);
		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
			return dateFormat.format(timestamp);
	}
	
/*
	@RequestMapping(value="/test11")
	public String test11(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		HttpSession session = request.getSession();
		int result = mileageTobeService.insertTest();
		session.setAttribute("row", result);
		return "/counter/carrider/tobe/test11";
	}
	
	@RequestMapping(value="/test12")
	public String test12(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		HttpSession session = request.getSession();
		session.setAttribute("stlm_crd_no", "1111********4444");
		session.setAttribute("stlm_cdcp_nm", "삼성");
		return "/counter/carrider/tobe/test12";
	}
*/	
}
