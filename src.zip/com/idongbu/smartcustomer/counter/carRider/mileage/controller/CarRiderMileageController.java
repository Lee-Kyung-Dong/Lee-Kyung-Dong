package com.idongbu.smartcustomer.counter.carRider.mileage.controller;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

// import ch.qos.logback.core.encoder.Encoder;






import com.idongbu.common.SeedUtil;
import com.idongbu.smartcustomer.counter.carRider.common.service.CarRiderFileService;
import com.idongbu.smartcustomer.counter.carRider.mileage.service.CarRiderMileageService;
import com.idongbu.smartzone.vo.MMTI0015VO;
import com.idongbu.smartzone.vo.MMTI0213VO;
import com.idongbu.smartzone.vo.MMTI0218VO;
import com.idongbu.smartzone.vo.MMTI0259VO;
import com.idongbu.smartzone.vo.MMTI0289VO;
import com.idongbu.smartzone.vo.MMTI0291VO;
import com.idongbu.smartzone.vo.MMTI0294VO;
import com.idongbu.smartzone.vo.MMTI0217VO;
import com.idongbu.smartzone.vo.MMTI0305VO;
import com.idongbu.smartzone.vo.XIDB0004VO;
import com.idongbu.smartzone.vo.XTEM0021VO;
import com.idongbu.util.DMEncDecUtil;
import com.idongbu.util.DateUtil;
import com.idongbu.util.FTPUtil;
import com.idongbu.util.StringUtil;
import com.raonsecure.transkey.*;

import org.apache.commons.codec.binary.Base64;

/**
 * @info 보험상품 > 주행거리특약 & 블랙박스특약
 * @author F1F14A61
 */
@Controller
@RequestMapping(value="/idongbu/counter/carrider")
public class CarRiderMileageController {

	//private @Value("${server.mode}") String SERVER_MODE;
	
	@Autowired(required=true)
	private CarRiderMileageService carRiderMileageService;		

	@Autowired(required=true)
	private CarRiderFileService carRiderFileService; 	
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());	
	 
	@RequestMapping(value="/mileageBlackBox01")
	public String mileageBlackBox01(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		MMTI0213VO jmvo = new MMTI0213VO();

		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("num")));
		jmvo = carRiderMileageService.getMMTI0213VO(jmvo);
		String view = "";
		
		if("1".equals(jmvo.getPbox_no_dvcd())) { // 주행거리
			view = "/counter/carrider/mobileweb/mileage01";
		}
		else if("2".equals(jmvo.getPbox_no_dvcd())) { // 블랙박스
			view = "/counter/carrider/mobileweb/blackbox01";
		}

		request.setAttribute("num", request.getParameter("num"));
		request.setAttribute("jmvo", jmvo);
		return view;
	}
	
	@RequestMapping(value="/mileageBlackBox02")
	public String mileageBlackBox02(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		MMTI0213VO jmvo = new MMTI0213VO();
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("num")));
		jmvo = carRiderMileageService.getMMTI0213VO(jmvo);
		String view = "";
		
		if("1".equals(jmvo.getPbox_no_dvcd())) { // 주행거리
			view = "/counter/carrider/mobileweb/mileage02";
		}
		else if("2".equals(jmvo.getPbox_no_dvcd())) { // 블랙박스
			view = "/counter/carrider/mobileweb/blackbox02";
		}

		request.setAttribute("num", request.getParameter("num"));
		request.setAttribute("jmvo", jmvo);
		return view;
	}

	@RequestMapping(value="/mileageBlackBoxFileUpload")
	public @ResponseBody Map<String, String> mileageBlackBoxFileUpload(MultipartHttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		Map<String, String> map = new HashMap<String, String>();
		
		MMTI0213VO jmvo = new MMTI0213VO();
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("num")));
		jmvo = carRiderMileageService.getMMTI0213VO(jmvo);

		carRiderMileageService.regInfoToEdmsForMobileWeb(request, jmvo.getSms_ts_bvan());
		
		MMTI0259VO jmvo1 = new MMTI0259VO();
		jmvo1.setPbox_use_yn("1");
		jmvo1.setPbox_no(jmvo.getSms_ts_bvan());
		jmvo1.setPhgp_cnfm_dt(DateUtil.getDate("yyyymmdd"));
		jmvo1.setPhgp_strg_yn("1");
		
		if("1".equals(jmvo.getPbox_no_dvcd()) && !"1".equals(jmvo.getCm_yn())) {
			if("03".equals(jmvo.getProc_dvn())) {
				jmvo1.setPbox_chr_nm(request.getParameter("mileage1") + "/" + request.getParameter("mileage2"));
			}
			else {
				jmvo1.setPbox_chr_nm(request.getParameter("mileage1"));
			}
		}
		jmvo1 = carRiderMileageService.getMMTI0259VO(jmvo1);
		
		map.put("errorCode", jmvo1.getErrorCode());
			
		return map;
	}

	private String aes256Decrypt(String enc) {
		String dec = "";
		String encKey = carRiderMileageService.getEncKey();
		
		try {
			dec = DMEncDecUtil.decAES256(enc, null, null, encKey);
		}
		catch(Exception e) {
			logger.debug("DMEncDecUtil.decAES256 실패 시 js로 복호화");
			
			String path = this.getClass().getResource("").getPath();
			logger.debug(path);
			
			// [200617] 취약점 수정
			BufferedReader in = null;
			
			try {
				String aesJs = path.substring(0, path.indexOf("/classes/")) + "/aes/gibberish-aes.js";
				if(aesJs.startsWith("/")) aesJs = aesJs.substring(1);
				String cmd = "cscript " + aesJs + " " + encKey  + " " + enc;
				logger.debug("cmd: " + cmd);
				Process p = Runtime.getRuntime().exec(cmd);
				// [200617] 취약점 수정
				in = new BufferedReader(new InputStreamReader(p.getInputStream()));
		
				String line = null;
				boolean flag = false;
				while (true) {
					line = in.readLine();
					if(line == null) break;
					logger.debug(line);
					dec = line;
					if(flag) break;
					if(dec.startsWith("enc: ")) flag = true;
				}
				
				if(dec.startsWith("enc: ")) {
					dec = dec.substring(5);
				}
		
				in.close();
				// [200617] 취약점 수정
				in = null;
			}
			catch(Exception e1) {
				return null;
			}
			// [200617] 취약점 수정
			finally {
				try{
					if(in!=null){
						in.close();
					}
				}
				catch(IOException ee){
					System.err.println("[CarriderMileageController.aes256Decrypt()] IOException 발생");
			    	// ee.getMessage();
			    }
			}
		}
		return dec;
	}
 
	
	private String aes256Encrypt(String plainText) {
		String enc = "";
		String encKey = carRiderMileageService.getEncKey();
		
		try {
			enc = DMEncDecUtil.encAES256(plainText, null, null, encKey);
		}
		catch(Exception e) {
			logger.debug("DMEncDecUtil.encAES256 실패 시 js로 암호화");
			
			String path = this.getClass().getResource("").getPath();
			logger.debug(path);
			// [200617] 취약점 수정
			BufferedReader in = null;
			
			try {
				String aesJs = path.substring(0, path.indexOf("/classes/")) + "/aes/gibberish-aes-2.js";
				if(aesJs.startsWith("/")) aesJs = aesJs.substring(1);
				String cmd = "cscript " + aesJs + " " + encKey  + " " + plainText;
				logger.debug("cmd: " + cmd);
				Process p = Runtime.getRuntime().exec(cmd);
				// [200617] 취약점 수정
				in = new BufferedReader(new InputStreamReader(p.getInputStream()));
		
				String line = null;
				boolean flag = false;
				while (true) {
					line = in.readLine();
					if(line == null) break;
					logger.debug(line);
					enc = line;
					if(flag) break;
					if(enc.startsWith("plain_text: ")) flag = true;
				}
				
				if(enc.startsWith("plain_text: ")) {
					enc = enc.substring(12);
				}
		
				in.close();
				// [200617] 취약점 수정
				in = null;
			}
			catch(Exception e1) {
				logger.info("실패11");
				return null;
			}
			// [200617] 취약점 수정
			finally {
				try{
					if(in!=null){
						in.close();
					}
				}
				catch(IOException ee){
					System.err.println("[CarriderMileageController.aes256Encrypt()] IOException 발생");
			    	// ee.getMessage();
			    }
			}
		}
		return enc;
	}
		
	// 자차보험 
	
	@RequestMapping(value="/mycar01")
	public String mycar01(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		String no = request.getParameter("no");
		
		MMTI0289VO jmvo = new MMTI0289VO();
		jmvo.setMbl_snd_no(aes256Decrypt(no));
		jmvo = carRiderMileageService.getMMTI0289VO(jmvo);

		request.setAttribute("no", no);
		request.setAttribute("jmvo", jmvo);
		return "/counter/carrider/mobileweb/mycar01";
	}

	@RequestMapping(value="/mycar02")
	public String mycar02(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		String no = request.getParameter("no");
		
		MMTI0289VO jmvo = new MMTI0289VO();
		jmvo.setMbl_snd_no(aes256Decrypt(no));
		jmvo = carRiderMileageService.getMMTI0289VO(jmvo);

		request.setAttribute("no", no);
		request.setAttribute("jmvo", jmvo);
		return "/counter/carrider/mobileweb/mycar02";
	}

	@RequestMapping(value="/mycarFileUpload")
	public @ResponseBody Map<String, String> mycarFileUpload(MultipartHttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		Map<String, String> map = new HashMap<String, String>();
		String no = request.getParameter("no");
		
		MMTI0289VO jmvo = new MMTI0289VO();
		jmvo.setMbl_snd_no(aes256Decrypt(no));
		jmvo = carRiderMileageService.getMMTI0289VO(jmvo);

		try {
			carRiderMileageService.regInfoToEdmsForMobileWeb(request, jmvo);
			map.put("errorCode", "0");
		}
		catch(Exception e) {
			logger.debug(StringUtil.getStackTraceString(e));
			map.put("errorCode", "-1");
		}
		
		return map;
	}
	
	@RequestMapping(value="/ml1")
	public String ml1(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		MMTI0213VO jmvo = new MMTI0213VO();
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("p")));
		jmvo = carRiderMileageService.getMMTI0213VO(jmvo);
		request.setAttribute("p", request.getParameter("p"));
		request.setAttribute("jmvo", jmvo);
		return "/counter/carrider/mobileweb/ml1";
	}	
	
	@RequestMapping(value="/ml2")
	public String ml2(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		MMTI0213VO jmvo = new MMTI0213VO();
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("p")));
		jmvo = carRiderMileageService.getMMTI0213VO(jmvo);
		request.setAttribute("p", request.getParameter("p"));
		request.setAttribute("jmvo", jmvo);
		return "/counter/carrider/mobileweb/ml2";
	}

	@RequestMapping(value="/ml2_1")
	public String ml2_1(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		MMTI0213VO jmvo = new MMTI0213VO();
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("p")));
		jmvo = carRiderMileageService.getMMTI0213VO(jmvo);
		
		HttpSession session = request.getSession();
		Object[] imgfile = (Object[]) session.getAttribute("imgfile");
		if(imgfile != null) {
			byte[] file = (byte[]) imgfile[0];
			logger.debug("file.length: " + file.length);
			request.setAttribute("imgsrc", "data:image/jpeg;base64," + new String(Base64.encodeBase64(file)));
		}
		
		request.setAttribute("p", request.getParameter("p"));
		request.setAttribute("jmvo", jmvo);
		return "/counter/carrider/mobileweb/ml2_1";
	}

	@RequestMapping(value="/ml3")
	public String ml3(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		MMTI0213VO jmvo = new MMTI0213VO();
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("p")));
		jmvo = carRiderMileageService.getMMTI0213VO(jmvo);
		
		String exp_exca_plan_rsl_cd = request.getParameter("exp_exca_plan_rsl_cd");
		
		// 간편정산 -> 설계보관/추징 등 아니면 다 확정요청
		if("1".equals(jmvo.getTrv_dstc_splc_exca_yn())) {
			if(exp_exca_plan_rsl_cd.equals("11") || exp_exca_plan_rsl_cd.equals("13") || exp_exca_plan_rsl_cd.equals("14")) {
				MMTI0291VO jmvo1 = new MMTI0291VO();
				jmvo1.setTrv_dstc_exca_mtt__exca_bz_proc_dvn("2");
				jmvo1.setTrv_dstc_exca_mtt__plno(StringUtil.nvl(request.getParameter("plno")));
				jmvo1.setTrv_dstc_exca_mtt__plan_no(StringUtil.nvl(request.getParameter("exp_exca_plan_no")));
				jmvo1.setTrv_dstc_exca_mtt__exca_rtrn_dvn("");
				jmvo1.setTrv_dstc_exca_mtt__pdc_sr_dvn(StringUtil.nvl(request.getParameter("pdc_sr_dvn")));
				jmvo1.setTrv_dstc_exca_mtt__adc_rtrn_dvn(StringUtil.nvl(request.getParameter("adc_rtrn_dvn")));
				jmvo1.setTrv_dstc_exca_mtt__adc_rtrn_prm(StringUtil.nvl(request.getParameter("adc_rtrn_prm")));
				jmvo1.setTrv_dstc_exca_mtt__scrn_proc_cd(StringUtil.nvl(request.getParameter("exp_exca_plan_rsl_cd")));
				jmvo1.setTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn(jmvo.getTrv_dstc_splc_exca_yn());
				jmvo1.setTrv_dstc_exca_mtt__pbox_no(jmvo.getSms_ts_bvan());
				jmvo1 = carRiderMileageService.getMMTI0291VO(jmvo1);
				
				request.setAttribute("z_resp_cd", jmvo1.getZ_resp_cd());
				request.setAttribute("z_resp_msg", jmvo1.getZ_resp_msg());
				
				// 이미지 중복이면 확정신청페이지
				if("1".equals(jmvo1.getTrv_dstc_exca_mtt__imag_dup_yn())){
					exp_exca_plan_rsl_cd = "14";
				}
					
				/*request.setAttribute("imag_dup_yn", jmvo1.getTrv_dstc_exca_mtt__imag_dup_yn());	// 중복여부
				request.setAttribute("imag_rsl_cd", jmvo1.getTrv_dstc_exca_mtt__rsl_cd());			// 결과코드
				request.setAttribute("imag_rsl_msg", jmvo1.getTrv_dstc_exca_mtt__rsl_msg());*/		// 결과메시지
				
				// CM 상품이고, 화면처리코드 IN(02, 14) or 이미지 중복
				
				if("CM".equals(jmvo1.getTrv_dstc_exca_mtt__pdc_sr_dvn()) && 
						("02".equals(jmvo1.getTrv_dstc_exca_mtt__scrn_proc_cd())
						|| "14".equals(jmvo1.getTrv_dstc_exca_mtt__scrn_proc_cd()))){
					
					MMTI0015VO mmti0015vo = new MMTI0015VO();
					mmti0015vo.setFunt_key("00");
					mmti0015vo.setPlan_no(jmvo1.trv_dstc_exca_mtt__plan_no);
					mmti0015vo = carRiderMileageService.getMMTI0015VO(mmti0015vo);
					
					logger.debug("##### MMTI0015 시작 ##########################");
					logger.debug("##### 고객식별번호: " + mmti0015vo.getPlhd__cust_dcmt_no() + " ##########################");
					logger.debug("##### 고객번호: " + mmti0015vo.getPlhd__cust_no() + " ##########################");
					logger.debug("##### 고객명: " + mmti0015vo.getPlhd__cust_nm() + " ##########################");
					logger.debug("##### 이메일: " + mmti0015vo.getPlhd__eml() + " ##########################");
					logger.debug("##### 지역번호: " + mmti0015vo.getPlhd_cntp_if__tlp_arno() + " ##########################");
					logger.debug("##### 국번호: " + mmti0015vo.getPlhd_cntp_if__tlp_ofno() + " ##########################");
					logger.debug("##### 개별번호: " + mmti0015vo.getPlhd_cntp_if__tlp_idvno() + " ##########################");
					
					XTEM0021VO xtem0021vo = new XTEM0021VO();
					xtem0021vo.setCnsl_rpt_no("");						// 상담접수번호				
					xtem0021vo.setCm_bz_dvcd("05");
					xtem0021vo.setCnsl_typ_dvcd("07");
					xtem0021vo.setCm_plan_no(jmvo1.getTrv_dstc_exca_mtt__plan_no());
					xtem0021vo.setCnsl_rpy_dvcd("1");
					xtem0021vo.setCnsl_rpt_dttm(getDayTime());			// 현재년월일시분초 14자리
					xtem0021vo.setCust_nm(mmti0015vo.getPlhd__cust_nm());
					xtem0021vo.setCust_no(mmti0015vo.getPlhd__cust_no());
					
					String cust_dcmt_no = SeedUtil.decrypt(mmti0015vo.getPlhd__cust_dcmt_no());
					
					if("1".equals(cust_dcmt_no.substring(6, 7)) || "2".equals(cust_dcmt_no.substring(6, 7))
						|| "5".equals(cust_dcmt_no.substring(6, 7)) || "6".equals(cust_dcmt_no.substring(6, 7))){
						xtem0021vo.setBrth("19" + cust_dcmt_no.substring(0, 6));
					} else{
						xtem0021vo.setBrth("20" + cust_dcmt_no.substring(0, 6));
					}
					// xtem0021vo.setBrth("");  							// 생년월일
					xtem0021vo.setSx_cd(cust_dcmt_no.substring(6, 7));
					xtem0021vo.setEml_adr(mmti0015vo.getPlhd__eml());
					xtem0021vo.setClp_tlcno(mmti0015vo.getPlhd_cntp_if__tlp_arno());
					xtem0021vo.setClp_ofno(mmti0015vo.getPlhd_cntp_if__tlp_ofno());
					xtem0021vo.setClp_idvno(mmti0015vo.getPlhd_cntp_if__tlp_idvno());
					xtem0021vo.setCnsl_rsvt_dt("99990101");
					xtem0021vo.setCnsl_rsvt_time_cd("1");
					xtem0021vo.setCnsl_cn("최종주행거리사진등록/만기정산");
					xtem0021vo.setCnsl_aply_csn_yn("1");
					xtem0021vo.setUrl_adr("");
					xtem0021vo.setCm_ctrmf_tpcd("32");
					xtem0021vo.setFrst_ipmn_empno("80000028");
					xtem0021vo.setFrst_ipnpt_dttm(getDayTime());		// 현재년월일시분초 14자리	
					
					xtem0021vo = carRiderMileageService.getXTEM0021VO(xtem0021vo);
					logger.debug("##### XTEM0021 시작 ##########################");
					logger.debug("##### 처리결과: [ " + xtem0021vo.getProc_rtn() + " ] ##########################");
				}
				
				
			}
		}
		
		request.setAttribute("p",							request.getParameter("p"));
		request.setAttribute("jmvo",						jmvo);
		request.setAttribute("exp_exca_plan_rsl_cd",		exp_exca_plan_rsl_cd);
		request.setAttribute("adc_rtrn_dvn",				request.getParameter("adc_rtrn_dvn"));
		request.setAttribute("adc_rtrn_prm",				request.getParameter("adc_rtrn_prm"));
		request.setAttribute("plno",						request.getParameter("plno"));
		request.setAttribute("exp_exca_plan_no",			request.getParameter("exp_exca_plan_no"));
		request.setAttribute("exp_exca_plan_bse_dd",		request.getParameter("exp_exca_plan_bse_dd"));
		request.setAttribute("aut_cgnt_vh_no",				request.getParameter("aut_cgnt_vh_no"));
		request.setAttribute("aut_cgnt_vh_no_rsl_cd",		request.getParameter("aut_cgnt_vh_no_rsl_cd"));
		request.setAttribute("aut_cgnt_trv_dstc",			request.getParameter("aut_cgnt_trv_dstc"));
		request.setAttribute("aut_cgnt_trv_dstc_rsl_cd",	request.getParameter("aut_cgnt_trv_dstc_rsl_cd"));
		request.setAttribute("exp_exca_plan_proc_dvn",		request.getParameter("exp_exca_plan_proc_dvn"));
		request.setAttribute("cnv_trv_dstc",				request.getParameter("cnv_trv_dstc"));
		request.setAttribute("plhd_cust_nm",				request.getParameter("plhd_cust_nm"));
		request.setAttribute("pdc_sr_dvn",					request.getParameter("pdc_sr_dvn"));
		request.setAttribute("errorCode",					request.getParameter("errorCode"));
		
		return "/counter/carrider/mobileweb/ml3";
	}
	
	@RequestMapping(value="/ml3_1")
	public @ResponseBody Map<String, String> ml3_1(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		Map<String, String> map = new HashMap<String, String>();
		MMTI0291VO jmvo = new MMTI0291VO();
		jmvo.setTrv_dstc_exca_mtt__exca_bz_proc_dvn("2");
		jmvo.setTrv_dstc_exca_mtt__plno(StringUtil.nvl(request.getParameter("plno")));
		jmvo.setTrv_dstc_exca_mtt__plan_no(StringUtil.nvl(request.getParameter("exp_exca_plan_no")));
		jmvo.setTrv_dstc_exca_mtt__exca_rtrn_dvn("");
		jmvo.setTrv_dstc_exca_mtt__pdc_sr_dvn(StringUtil.nvl(request.getParameter("pdc_sr_dvn")));
		jmvo.setTrv_dstc_exca_mtt__adc_rtrn_dvn(StringUtil.nvl(request.getParameter("adc_rtrn_dvn")));
		jmvo.setTrv_dstc_exca_mtt__adc_rtrn_prm(StringUtil.nvl(request.getParameter("adc_rtrn_prm")));
		jmvo.setTrv_dstc_exca_mtt__scrn_proc_cd(StringUtil.nvl(request.getParameter("exp_exca_plan_rsl_cd")));
		jmvo.setTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn(StringUtil.nvl(request.getParameter("trv_dstc_splc_exca_yn")));
		jmvo.setTrv_dstc_exca_mtt__pbox_no(StringUtil.nvl(request.getParameter("pbox_no")));
		jmvo = carRiderMileageService.getMMTI0291VO(jmvo);

		map.put("trv_dstc_exca_mtt__exca_bz_proc_dvn",			jmvo.getTrv_dstc_exca_mtt__exca_bz_proc_dvn());
		map.put("trv_dstc_exca_mtt__plno", 						jmvo.getTrv_dstc_exca_mtt__plno());
		map.put("trv_dstc_exca_mtt__plan_no", 					jmvo.getTrv_dstc_exca_mtt__plan_no());
		map.put("trv_dstc_exca_mtt__plan_dt", 					jmvo.getTrv_dstc_exca_mtt__plan_dt());
		map.put("trv_dstc_exca_mtt__exca_rtrn_dvn", 			jmvo.getTrv_dstc_exca_mtt__exca_rtrn_dvn());
		map.put("trv_dstc_exca_mtt__bank_cd", 					jmvo.getTrv_dstc_exca_mtt__bank_cd());
		map.put("trv_dstc_exca_mtt__acc_no", 					jmvo.getTrv_dstc_exca_mtt__acc_no());
		map.put("trv_dstc_exca_mtt__adc_rtrn_dvn", 				jmvo.getTrv_dstc_exca_mtt__adc_rtrn_dvn());
		map.put("trv_dstc_exca_mtt__adc_rtrn_prm", 				jmvo.getTrv_dstc_exca_mtt__adc_rtrn_prm());
		map.put("trv_dstc_exca_mtt__cnv_trv_dstc", 				jmvo.getTrv_dstc_exca_mtt__cnv_trv_dstc());
		map.put("trv_dstc_exca_mtt__nrm_proc_yn", 				jmvo.getTrv_dstc_exca_mtt__nrm_proc_yn());
		map.put("trv_dstc_exca_mtt__aut_cgnt_vh_no_eqal_yn", 	jmvo.getTrv_dstc_exca_mtt__aut_cgnt_vh_no_eqal_yn());
		map.put("trv_dstc_exca_mtt__aut_cgnt_trv_dstc_eqal_yn",	jmvo.getTrv_dstc_exca_mtt__aut_cgnt_trv_dstc_eqal_yn());
		map.put("trv_dstc_exca_mtt__rnw_plno", 					jmvo.getTrv_dstc_exca_mtt__rnw_plno());
		map.put("trv_dstc_exca_mtt__hdlr_empno", 				jmvo.getTrv_dstc_exca_mtt__hdlr_empno());
		map.put("trv_dstc_exca_mtt__aut_cgnt_trv_dstc_rsl_cd", 	jmvo.getTrv_dstc_exca_mtt__aut_cgnt_trv_dstc_rsl_cd());
		map.put("trv_dstc_exca_mtt__plhd_cust_nm", 				jmvo.getTrv_dstc_exca_mtt__plhd_cust_nm());
		map.put("trv_dstc_exca_mtt__pdc_sr_dvn", 				jmvo.getTrv_dstc_exca_mtt__pdc_sr_dvn());
		map.put("trv_dstc_exca_mtt__scrn_proc_cd", 				jmvo.getTrv_dstc_exca_mtt__scrn_proc_cd());
		map.put("trv_dstc_exca_mtt__arc_trm_str_dt", 			jmvo.getTrv_dstc_exca_mtt__arc_trm_str_dt());
		map.put("z_resp_cd",									jmvo.getZ_resp_cd());
		
		return map;
	}

	@RequestMapping(value="/ml4")
	public String ml4(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		MMTI0213VO jmvo = new MMTI0213VO();
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("p")));
		jmvo = carRiderMileageService.getMMTI0213VO(jmvo);

		String gubun = request.getParameter("gubun");
		request.setAttribute("p",							request.getParameter("p"));
		request.setAttribute("jmvo",						jmvo);
		request.setAttribute("exp_exca_plan_rsl_cd",		request.getParameter("exp_exca_plan_rsl_cd"));
		request.setAttribute("adc_rtrn_dvn",				request.getParameter("adc_rtrn_dvn"));
		request.setAttribute("adc_rtrn_prm",				request.getParameter("adc_rtrn_prm"));
		request.setAttribute("plno",						request.getParameter("plno"));
		request.setAttribute("exp_exca_plan_no",			request.getParameter("exp_exca_plan_no"));
		request.setAttribute("exp_exca_plan_bse_dd",		request.getParameter("exp_exca_plan_bse_dd"));
		request.setAttribute("aut_cgnt_vh_no",				request.getParameter("aut_cgnt_vh_no"));
		request.setAttribute("aut_cgnt_vh_no_rsl_cd",		request.getParameter("aut_cgnt_vh_no_rsl_cd"));
		request.setAttribute("aut_cgnt_trv_dstc",			request.getParameter("aut_cgnt_trv_dstc"));
		request.setAttribute("aut_cgnt_trv_dstc_rsl_cd",	request.getParameter("aut_cgnt_trv_dstc_rsl_cd"));
		request.setAttribute("cnv_trv_dstc",				request.getParameter("cnv_trv_dstc"));
		request.setAttribute("plhd_cust_nm",				request.getParameter("plhd_cust_nm"));
		request.setAttribute("pdc_sr_dvn",					request.getParameter("pdc_sr_dvn"));
		request.setAttribute("gubun",						gubun);
		
		if("2".equals(gubun) || "3".equals(gubun)) {
			MMTI0291VO jmvo1 = new MMTI0291VO();
			
			if("1".equals(request.getParameter("skip"))) {
				jmvo1.setTrv_dstc_exca_mtt__exca_bz_proc_dvn(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__exca_bz_proc_dvn")));
				jmvo1.setTrv_dstc_exca_mtt__plno(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__plno")));
				jmvo1.setTrv_dstc_exca_mtt__plan_no(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__plan_no")));
				jmvo1.setTrv_dstc_exca_mtt__plan_dt(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__plan_dt")));
				jmvo1.setTrv_dstc_exca_mtt__exca_rtrn_dvn(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__exca_rtrn_dvn")));
				jmvo1.setTrv_dstc_exca_mtt__bank_cd(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__bank_cd")));
				jmvo1.setTrv_dstc_exca_mtt__acc_no(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__acc_no")));
				jmvo1.setTrv_dstc_exca_mtt__adc_rtrn_dvn(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__adc_rtrn_dvn")));
				jmvo1.setTrv_dstc_exca_mtt__adc_rtrn_prm(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__adc_rtrn_prm")));
				jmvo1.setTrv_dstc_exca_mtt__cnv_trv_dstc(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__cnv_trv_dstc")));
				jmvo1.setTrv_dstc_exca_mtt__nrm_proc_yn(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__nrm_proc_yn")));
				jmvo1.setTrv_dstc_exca_mtt__aut_cgnt_vh_no_eqal_yn(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__aut_cgnt_vh_no_eqal_yn")));
				jmvo1.setTrv_dstc_exca_mtt__aut_cgnt_trv_dstc_eqal_yn(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__aut_cgnt_trv_dstc_eqal_yn")));
				jmvo1.setTrv_dstc_exca_mtt__rnw_plno(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__rnw_plno")));
				jmvo1.setTrv_dstc_exca_mtt__hdlr_empno(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__hdlr_empno")));
				jmvo1.setTrv_dstc_exca_mtt__aut_cgnt_trv_dstc_rsl_cd(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__aut_cgnt_trv_dstc_rsl_cd")));
				jmvo1.setTrv_dstc_exca_mtt__plhd_cust_nm(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__plhd_cust_nm")));
				jmvo1.setTrv_dstc_exca_mtt__pdc_sr_dvn(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__pdc_sr_dvn")));
				jmvo1.setTrv_dstc_exca_mtt__scrn_proc_cd(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__scrn_proc_cd")));
				jmvo1.setTrv_dstc_exca_mtt__arc_trm_str_dt(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__arc_trm_str_dt")));
				jmvo1.setZ_resp_cd(StringUtil.nvl(request.getParameter("z_resp_cd")));
			}
			else {
				jmvo1.setTrv_dstc_exca_mtt__exca_bz_proc_dvn("2");
				jmvo1.setTrv_dstc_exca_mtt__plno(request.getParameter("plno"));
				jmvo1.setTrv_dstc_exca_mtt__plan_no(request.getParameter("exp_exca_plan_no"));
				jmvo1.setTrv_dstc_exca_mtt__exca_rtrn_dvn("3".equals(gubun) ? "1" : "2");
				jmvo1.setTrv_dstc_exca_mtt__pdc_sr_dvn(request.getParameter("pdc_sr_dvn"));
				jmvo1.setTrv_dstc_exca_mtt__scrn_proc_cd(request.getParameter("exp_exca_plan_rsl_cd"));
				
				if("3".equals(gubun)) {
					String account = "";
					try {
						account = TransKey.decode("account", request);
					}
					catch(Exception e) {
						logger.debug(e.getMessage());
						account = request.getParameter("account");
					}
					logger.debug("account: " + account);
					jmvo1.setTrv_dstc_exca_mtt__bank_cd(request.getParameter("bank"));
					jmvo1.setTrv_dstc_exca_mtt__acc_no(account);
				}
				jmvo1.setTrv_dstc_exca_mtt__adc_rtrn_dvn(request.getParameter("adc_rtrn_dvn"));
				jmvo1.setTrv_dstc_exca_mtt__adc_rtrn_prm(request.getParameter("adc_rtrn_prm"));
				jmvo1.setTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn(jmvo.getTrv_dstc_splc_exca_yn());
				jmvo1.setTrv_dstc_exca_mtt__pbox_no(jmvo.getSms_ts_bvan());
				jmvo1 = carRiderMileageService.getMMTI0291VO(jmvo1);
			}
			
			// 부적정/중복 이미지인 경우 화면처리코드 02 
			if("1".equals(jmvo1.getTrv_dstc_exca_mtt__imag_dup_yn())){
				jmvo1.setTrv_dstc_exca_mtt__scrn_proc_cd("02");
			}
			request.setAttribute("jmvo1", jmvo1);
			
			// CM 상품이고, 화면처리코드 IN(02, 14) or 이미지 중복
			
			if("CM".equals(jmvo1.getTrv_dstc_exca_mtt__pdc_sr_dvn()) &&
					("02".equals(jmvo1.getTrv_dstc_exca_mtt__scrn_proc_cd())
					|| "14".equals(jmvo1.getTrv_dstc_exca_mtt__scrn_proc_cd()))){
				
				MMTI0015VO mmti0015vo = new MMTI0015VO();
				mmti0015vo.setFunt_key("00");
				mmti0015vo.setPlan_no(jmvo1.trv_dstc_exca_mtt__plan_no);
				mmti0015vo = carRiderMileageService.getMMTI0015VO(mmti0015vo);
				
				logger.debug("##### MMTI0015 시작 ##########################");
				logger.debug("##### 고객식별번호: " + mmti0015vo.getPlhd__cust_dcmt_no() + " ##########################");
				logger.debug("##### 고객번호: " + mmti0015vo.getPlhd__cust_no() + " ##########################");
				logger.debug("##### 고객명: " + mmti0015vo.getPlhd__cust_nm() + " ##########################");
				logger.debug("##### 이메일: " + mmti0015vo.getPlhd__eml() + " ##########################");
				logger.debug("##### 지역번호: " + mmti0015vo.getPlhd_cntp_if__tlp_arno() + " ##########################");
				logger.debug("##### 국번호: " + mmti0015vo.getPlhd_cntp_if__tlp_ofno() + " ##########################");
				logger.debug("##### 개별번호: " + mmti0015vo.getPlhd_cntp_if__tlp_idvno() + " ##########################");
				
				XTEM0021VO xtem0021vo = new XTEM0021VO();
				xtem0021vo.setCnsl_rpt_no("");						// 상담접수번호				
				xtem0021vo.setCm_bz_dvcd("05");
				xtem0021vo.setCnsl_typ_dvcd("07");
				xtem0021vo.setCm_plan_no(jmvo1.getTrv_dstc_exca_mtt__plan_no());
				xtem0021vo.setCnsl_rpy_dvcd("1");
				xtem0021vo.setCnsl_rpt_dttm(getDayTime());			// 현재년월일시분초 14자리
				xtem0021vo.setCust_nm(mmti0015vo.getPlhd__cust_nm());
				xtem0021vo.setCust_no(mmti0015vo.getPlhd__cust_no());
				
				String cust_dcmt_no = SeedUtil.decrypt(mmti0015vo.getPlhd__cust_dcmt_no());
				
				if("1".equals(cust_dcmt_no.substring(6, 7)) || "2".equals(cust_dcmt_no.substring(6, 7))
					|| "5".equals(cust_dcmt_no.substring(6, 7)) || "6".equals(cust_dcmt_no.substring(6, 7))){
					xtem0021vo.setBrth("19" + cust_dcmt_no.substring(0, 6));
				} else{
					xtem0021vo.setBrth("20" + cust_dcmt_no.substring(0, 6));
				}
				// xtem0021vo.setBrth("");  							// 생년월일
				xtem0021vo.setSx_cd(cust_dcmt_no.substring(6, 7));
				xtem0021vo.setEml_adr(mmti0015vo.getPlhd__eml());
				xtem0021vo.setClp_tlcno(mmti0015vo.getPlhd_cntp_if__tlp_arno());
				xtem0021vo.setClp_ofno(mmti0015vo.getPlhd_cntp_if__tlp_ofno());
				xtem0021vo.setClp_idvno(mmti0015vo.getPlhd_cntp_if__tlp_idvno());
				xtem0021vo.setCnsl_rsvt_dt("99990101");
				xtem0021vo.setCnsl_rsvt_time_cd("1");
				xtem0021vo.setCnsl_cn("최종주행거리사진등록/만기정산");
				xtem0021vo.setCnsl_aply_csn_yn("1");
				xtem0021vo.setUrl_adr("");
				xtem0021vo.setCm_ctrmf_tpcd("32");
				xtem0021vo.setFrst_ipmn_empno("80000028");
				xtem0021vo.setFrst_ipnpt_dttm(getDayTime());		// 현재년월일시분초 14자리	
				
				xtem0021vo = carRiderMileageService.getXTEM0021VO(xtem0021vo);
				logger.debug("##### XTEM0021 시작 ##########################");
				logger.debug("##### 처리결과: [ " + xtem0021vo.getProc_rtn() + " ] ##########################");
			}
			
			
		}
		
		return "/counter/carrider/mobileweb/ml4";
	}

	@RequestMapping(value="/ml5")
	public String ml5(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		HttpSession session = request.getSession();
		String empno = StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__hdlr_empno"));
		
		MMTI0294VO jmvo = new MMTI0294VO();
		jmvo.setTrv_dstc_exca_mtt__plno(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__plno")));
		jmvo.setTrv_dstc_exca_mtt__plan_no(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__plan_no")));
		jmvo.setTrv_dstc_exca_mtt__plan_dt(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__plan_dt")));
		jmvo.setTrv_dstc_exca_mtt__rnw_plno(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__rnw_plno")));
		jmvo.setTrv_dstc_exca_mtt__hdlr_empno(empno);
		
		jmvo = carRiderMileageService.getMMTI0294VO(jmvo);
		
		if("ZH001".equals(jmvo.getZ_resp_cd()) && session.getAttribute("imgfile") != null && session.getAttribute("exifDate") != null && !StringUtil.isEmpty(empno)) {
			Object[] imgfile = (Object[]) session.getAttribute("imgfile");
			String exifDate = (String) session.getAttribute("exifDate");

			carRiderMileageService.regInfoToEdmsForMobileWeb3(empno, imgfile[0], exifDate, jmvo.getTrv_dstc_exca_mtt__rnw_plno() + "," + jmvo.getTrv_dstc_exca_mtt__rnw_plan_no());
		}
		
		request.setAttribute("jmvo", jmvo);
		return "/counter/carrider/mobileweb/ml5";
	}
	
	@RequestMapping(value="/mlFileUpload")
	public @ResponseBody Map<String, String> mlFileUpload(MultipartHttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		Map<String, String> map = new HashMap<String, String>();
		String yyyymmdd = DateUtil.getDate("yyyymmdd");
		
		MMTI0213VO jmvo = new MMTI0213VO();
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("p")));
		jmvo = carRiderMileageService.getMMTI0213VO(jmvo);
		
		String exifDate1 = StringUtil.nvl(request.getParameter("exifDate1"));
		
		// 사진실제촬영일자
		String phgp_rl_ptgr_dt = StringUtil.nvl(request.getParameter("phgp_rl_ptgr_dt"));
		// 사진첨부방식코드
		String phgp_apdx_way_cd = StringUtil.nvl(request.getParameter("phgp_apdx_way_cd"));
		
		String phgp_ptgr_dt = "";
		
		boolean empty = false;
		if(exifDate1.indexOf(",gallery") > -1) {
			exifDate1 = exifDate1.substring(0, exifDate1.indexOf(",gallery"));
			if(StringUtil.isEmpty(exifDate1)) {
				exifDate1 = DateUtil.getDate();
				empty = true;
			}
			else if(Integer.parseInt(exifDate1) > Integer.parseInt(DateUtil.getDate())) {
				map.put("errorCode", "f");
				return map;
			}
		}

		phgp_ptgr_dt = empty ? "" : exifDate1;
		
		if(exifDate1.indexOf(",gallery") > -1) {
			exifDate1 = exifDate1.substring(0, exifDate1.indexOf(",gallery"));
		}

		if("08".equals(jmvo.getProc_dvn()) || "09".equals(jmvo.getProc_dvn())) {
			ArrayList<File> files = carRiderMileageService.uploadToWAS(request, jmvo.getSms_ts_bvan());
			
			String aut_cgnt_trv_dstc_rsl_cd = "";	// 자동인식주행거리결과코드
			String aut_cgnt_vh_no_rsl_cd = "";		// 자동인식차량번호결과코드
			String aut_cgnt_trv_dstc = "";			// 자동인식주행거리
			String aut_cgnt_vh_no = "";				// 자동인식차량번호
			
			String aut_cgnt_trv_dstc_1 = "";		// 자동인식주행거리1
			String aut_cgnt_trv_dstc_2 = "";		// 자동인식주행거리2
			String aut_cgnt_trv_dstc_3 = "";		// 자동인식주행거리3
			
			boolean flag1 = false;
			if(files.size() > 0) {
				FTPUtil ftp = null;
				// [200617] 취약점 수정
				FileInputStream in = null;
				FileOutputStream out = null;
				FileInputStream fis = null;
				try {
					if("1".equals(jmvo.getAut_cgnt_nn_apcn_yn())) { // OCR서버 문제있으면...
						aut_cgnt_trv_dstc_rsl_cd = "03";
						aut_cgnt_vh_no_rsl_cd = "03";
					}
					else {
						String propsPath = this.getClass().getResource("").getPath();
						propsPath = propsPath.substring(0, propsPath.indexOf("/classes/")) + "/config/ocr_ftp.properties";
						Properties p = new Properties();
						// [200617] 취약점 수정
						in = new FileInputStream(propsPath);
						p.load(in);
						in.close();
						// [200617] 취약점 수정
						in = null;
						
						String password = p.getProperty("password");
						String decPassword = aes256Decrypt(password);
						if(password.equals(decPassword) || StringUtil.isEmpty(decPassword)) {
							decPassword = password;
							String encPassword = aes256Encrypt(password);
							logger.debug("encPassword: " + encPassword);
							// [200617] 취약점 수정
							out = new FileOutputStream(propsPath);
							p.setProperty("password", encPassword);
							p.store(out, "");
							out.close();
							// [200617] 취약점 수정
							out = null;
						}
						
						ftp = new FTPUtil(p.getProperty("ip"), p.getProperty("user"), decPassword, Integer.parseInt(p.getProperty("port")));
						
						int working = 0;
						for(int i = 1; i <= 3; i++) {
							String[] ls = ftp.ls("/RECOG_JOB" + i + "/" + yyyymmdd);
							for(int j = 0; j < ls.length; j++) {
								if(".".equals(ls[j]) || "..".equals(ls[j])) continue;
								working++;
							}
						}
		
						if(working <= 6) {
							String filename1 = "";
							
							filename1 = ftp.uploadToOCR("/RECOG/" + yyyymmdd, files.get(0), "--D");

							logger.debug("filename1: " + filename1);

							
							logger.debug("--- 1초 대기 ---");
							Thread.sleep(1000);
							int retryNum = 7;
							for(int retry = 0; retry < retryNum; retry++) {
								String[] ls = ftp.ls("/RECOG_RESULT/" + yyyymmdd);
			
								for(int i = 0; i < ls.length; i++) {
									logger.debug(ls[i]);
									if(!flag1 && ls[i].equals(filename1)) {
										flag1 = true;
									}
									
									if(flag1) break;
								}
			
								if((flag1) || retry == retryNum - 1) {
									break;
								}
								else {
									logger.debug("--- 0.6초 대기 ---");
									Thread.sleep(600);
								}
							}
							
							logger.debug("flag1: " + flag1);
							
							if(flag1) {
								// [200617] 취약점 수정
								// filename1 = filename1.replaceAll("/", "");
								// filename1 = filename1.replaceAll("&", "");
								// filename1 = filename1.replaceAll("\\", "");
								
								String path = files.get(0).getParent() + File.separator + filename1;
								ftp.downloadFromOCR("/RECOG_RESULT/" + yyyymmdd, filename1, path);
								logger.debug(path);
								File f = new File(path);
								logger.info("7777 filename1:" + filename1);
								logger.info("7777 path:" + path);
								
			
								if(f.exists()) {
									Properties props = new Properties(); 
									// [200617] 취약점 수정
									fis = new FileInputStream(path);
									props.load(fis);
									fis.close();
									// [200617] 취약점 수정
									fis = null;
									
									if(!StringUtil.isEmpty(props.getProperty("ODO")) && !StringUtil.isEmpty(props.getProperty("RE_CODE"))) {
										aut_cgnt_trv_dstc = props.getProperty("ODO");
										aut_cgnt_trv_dstc_rsl_cd = "1".equals(props.getProperty("RE_CODE")) || "2".equals(props.getProperty("RE_CODE")) ? "01" : "02";
										
										aut_cgnt_trv_dstc_1 = props.getProperty("ODO");
										
										if(!StringUtil.isEmpty(props.getProperty("ODO2"))) {
											aut_cgnt_trv_dstc_2 = props.getProperty("ODO2");
										}
										
										if(!StringUtil.isEmpty(props.getProperty("ODO3"))) {
											aut_cgnt_trv_dstc_3 = props.getProperty("ODO3");
										}
									}
									
					            	if(f.delete()) {
										logger.debug("삭제: " + path);
									}
								}
							}
							else {
								aut_cgnt_trv_dstc_rsl_cd = "02";
							}						
						}
						else {
							aut_cgnt_trv_dstc_rsl_cd = "02";
							if(!"1".equals(jmvo.getCm_yn())) {
								aut_cgnt_vh_no_rsl_cd = "02";
							}
						}
					}
				}
				catch(Exception e) {
					logger.debug(e.getMessage());
					aut_cgnt_trv_dstc_rsl_cd = "02";
					if(!"1".equals(jmvo.getCm_yn())) {
						aut_cgnt_vh_no_rsl_cd = "02";
					}
				}
				finally {
					if(ftp != null) ftp.disconnect();
					// [200617] 취약점 수정
					try{
			    	  	if(in != null){
			    	  		in.close();
			    	  	}
				      }catch(IOException ee){
				    	  System.err.println("[CarriderMileageController.mlFileUpload()] IOException 1 발생");
				      }
					try{
			    	  	if(out != null){
			    	  		out.close();
			    	  	}
				      }catch(IOException ee){
				    	  System.err.println("[CarriderMileageController.mlFileUpload()] IOException 2 발생");
				      }
					try{
			    	  	if(fis != null){
			    	  		fis.close();
			    	  	}
				      }catch(IOException ee){
				    	  System.err.println("[CarriderMileageController.mlFileUpload()] IOException 3 발생");
				      }
				}
			}
			
			MMTI0259VO jmvo1 = new MMTI0259VO();
			jmvo1.setPbox_use_yn("1");
			jmvo1.setPbox_no(jmvo.getSms_ts_bvan());
			jmvo1.setPhgp_cnfm_dt(DateUtil.getDate());
			jmvo1.setPhgp_ptgr_dt(phgp_ptgr_dt);
			jmvo1.setPhgp_strg_yn("1");
			if("1".equals(jmvo.getAut_cgnt_nn_apcn_yn())) {
				jmvo1.setPbox_chr_nm(request.getParameter("mileage1"));
			}
			
			if("1".equals(jmvo.getPbox_no_dvcd())) {
				if(!"1".equals(jmvo.getCm_yn())) {
					jmvo1.setInpt_trv_dstc(request.getParameter("mileage1"));
					if(!StringUtil.isEmpty(aut_cgnt_vh_no)) {
						jmvo1.setAut_cgnt_vh_no(aut_cgnt_vh_no);
					}
					
					if(!StringUtil.isEmpty(aut_cgnt_vh_no_rsl_cd)) {
						jmvo1.setAut_cgnt_vh_no_rsl_cd(aut_cgnt_vh_no_rsl_cd);
					}
					else {
						jmvo1.setAut_cgnt_vh_no_rsl_cd("02");
					}
				}
					
				if(!StringUtil.isEmpty(aut_cgnt_trv_dstc)) {
					jmvo1.setAut_cgnt_trv_dstc(aut_cgnt_trv_dstc);
				}
				
				if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_rsl_cd)) {
					jmvo1.setAut_cgnt_trv_dstc_rsl_cd(aut_cgnt_trv_dstc_rsl_cd);
				}
				else {
					jmvo1.setAut_cgnt_trv_dstc_rsl_cd("02");
				}
				
				if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_1)) {
					jmvo1.setAut_cgnt_trv_dstc_1(aut_cgnt_trv_dstc_1);
				}
				
				if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_2)) {
					jmvo1.setAut_cgnt_trv_dstc_2(aut_cgnt_trv_dstc_2);
				}
				
				if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_3)) {
					jmvo1.setAut_cgnt_trv_dstc_3(aut_cgnt_trv_dstc_3);
				}
			}
			
			// 200708
			jmvo1.setPhgp_rl_ptgr_dt(phgp_rl_ptgr_dt);
			jmvo1.setPhgp_apdx_way_cd(phgp_apdx_way_cd);
			
			jmvo1 = carRiderMileageService.getMMTI0259VO(jmvo1);
			
			if("0".equals(jmvo1.getErrorCode()) && !"1".equals(jmvo.getCm_yn())) {
				jmvo1.setExp_exca_plan_proc_dvn("1");
				jmvo1.setPlno(jmvo.getPlno());
				
				// 200708
				jmvo1.setPhgp_rl_ptgr_dt(phgp_rl_ptgr_dt);
				jmvo1.setPhgp_apdx_way_cd(phgp_apdx_way_cd);
				
				jmvo1 = carRiderMileageService.getMMTI0259VO(jmvo1);
				
				if("05".equals(jmvo1.getExp_exca_plan_rsl_cd())) {
					carRiderMileageService.regInfoToEdmsForMobileWeb(request, jmvo.getSms_ts_bvan());
				}
				else if(!StringUtil.isEmpty(jmvo1.getPlno()) && !StringUtil.isEmpty(jmvo1.getExp_exca_plan_no())) {
					carRiderMileageService.regInfoToEdmsForMobileWeb2(request, jmvo.getNtft_srv_rc_ormm_cd(), files, jmvo1.getPlno() + "," + jmvo1.getExp_exca_plan_no());
				}
				else {
					carRiderMileageService.regInfoToEdmsForMobileWeb2(request, jmvo.getNtft_srv_rc_ormm_cd(), files, jmvo1.getPlno());
				}
			}
			else {
				if("1".equals(jmvo.getCm_yn())) {
					carRiderMileageService.regInfoToEdmsForMobileWeb(request, jmvo.getSms_ts_bvan());
				}
				else {
					carRiderMileageService.regInfoToEdmsForMobileWeb2(request, jmvo.getNtft_srv_rc_ormm_cd(), files, jmvo1.getPlno());
				}
			}
	
			for(int i = 0; i < files.size(); i++) {
				File f = files.get(i);
				String fname = f.getName();
				f.delete();
				logger.debug(fname + " 삭제");
			}
			
			map.put("errorCode",				jmvo1.getErrorCode());
			map.put("exp_exca_plan_rsl_cd",		jmvo1.getExp_exca_plan_rsl_cd());
			map.put("adc_rtrn_dvn",				jmvo1.getAdc_rtrn_dvn());
			map.put("adc_rtrn_prm",				jmvo1.getAdc_rtrn_prm());
			map.put("plno",						jmvo1.getPlno());
			map.put("exp_exca_plan_no",			jmvo1.getExp_exca_plan_no());
			map.put("exp_exca_plan_bse_dd",		jmvo1.getExp_exca_plan_bse_dd());
			map.put("aut_cgnt_vh_no",			jmvo1.getAut_cgnt_vh_no());
			map.put("aut_cgnt_vh_no_rsl_cd",	jmvo1.getAut_cgnt_vh_no_rsl_cd());
			map.put("aut_cgnt_trv_dstc",		jmvo1.getAut_cgnt_trv_dstc());
			map.put("aut_cgnt_trv_dstc_rsl_cd",	jmvo1.getAut_cgnt_trv_dstc_rsl_cd());
			map.put("exp_exca_plan_proc_dvn",	jmvo1.getExp_exca_plan_proc_dvn());
			map.put("cnv_trv_dstc",				jmvo1.getCnv_trv_dstc());
			
			// 200708
			map.put("phgp_rl_ptgr_dt",			phgp_rl_ptgr_dt);
			map.put("phgp_apdx_way_cd", 		phgp_apdx_way_cd);
		}
		else {
			carRiderMileageService.regInfoToEdmsForMobileWeb(request, jmvo.getSms_ts_bvan());
			
			MMTI0259VO jmvo1 = new MMTI0259VO();
			jmvo1.setPbox_use_yn("1");
			jmvo1.setPbox_no(jmvo.getSms_ts_bvan());
			jmvo1.setPhgp_cnfm_dt(DateUtil.getDate());
			jmvo1.setPhgp_ptgr_dt(phgp_ptgr_dt);
			jmvo1.setPhgp_strg_yn("1");
			
			// 200708
			jmvo1.setPhgp_rl_ptgr_dt(phgp_rl_ptgr_dt);
			jmvo1.setPhgp_apdx_way_cd(phgp_apdx_way_cd);
			
			if("1".equals(jmvo.getPbox_no_dvcd()) && !"1".equals(jmvo.getCm_yn())) {
				if("03".equals(jmvo.getProc_dvn())) {
					jmvo1.setPbox_chr_nm(request.getParameter("mileage1") + "/" + request.getParameter("mileage2"));
				}
				else {
					jmvo1.setPbox_chr_nm(request.getParameter("mileage1"));
				}
			}
			jmvo1 = carRiderMileageService.getMMTI0259VO(jmvo1);
			
			map.put("errorCode", jmvo1.getErrorCode());
		}
			
		return map;
	}

	@RequestMapping(value="/mlFileUploadOCR")
	public @ResponseBody Map<String, String> mlFileUploadOCR(MultipartHttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		Map<String, String> map = new HashMap<String, String>();
		String yyyymmdd = DateUtil.getDate("yyyymmdd");
		
		String phgp_rl_ptgr_dt			= StringUtil.nvl(request.getParameter("phgp_rl_ptgr_dt"));			// 사진실제촬영일자
		String phgp_apdx_way_cd			= StringUtil.nvl(request.getParameter("phgp_apdx_way_cd"));			// 사진첨부방식코드
		
		MMTI0213VO jmvo = new MMTI0213VO();
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("p")));
		jmvo = carRiderMileageService.getMMTI0213VO(jmvo);
		
		String exifDate1 = StringUtil.nvl(request.getParameter("exifDate1"));
		
		if(exifDate1.indexOf(",gallery") > -1) {
			exifDate1 = exifDate1.substring(0, exifDate1.indexOf(",gallery"));
			if(StringUtil.isEmpty(exifDate1)) {
				exifDate1 = DateUtil.getDate();
			}
			else if(Integer.parseInt(exifDate1) > Integer.parseInt(DateUtil.getDate())) {
				map.put("errorCode", "f");
				return map;
			}
		}

		if(exifDate1.indexOf(",gallery") > -1) {
			exifDate1 = exifDate1.substring(0, exifDate1.indexOf(",gallery"));
		}

		ArrayList<File> files = carRiderMileageService.uploadToWAS(request, jmvo.getSms_ts_bvan());
		
		String aut_cgnt_trv_dstc_rsl_cd = "";	// 자동인식주행거리결과코드
		String aut_cgnt_vh_no_rsl_cd = "";		// 자동인식차량번호결과코드
		String aut_cgnt_trv_dstc = "";			// 자동인식주행거리
		String aut_cgnt_vh_no = "";				// 자동인식차량번호
		
		String aut_cgnt_trv_dstc_1 = "";		// 자동인식주행거리1
		String aut_cgnt_trv_dstc_2 = "";		// 자동인식주행거리2
		String aut_cgnt_trv_dstc_3 = "";		// 자동인식주행거리3
		
		
		boolean flag1 = false;
		if(files.size() > 0) {
			FTPUtil ftp = null;
			// [200617] 취약점 수정
			FileInputStream in = null;
			FileOutputStream out = null;
			FileInputStream fis = null;
			try {
				if("1".equals(jmvo.getAut_cgnt_nn_apcn_yn())) { // OCR서버 문제있으면...
					aut_cgnt_trv_dstc_rsl_cd = "03";
					aut_cgnt_vh_no_rsl_cd = "03";
				}
				else {
					String propsPath = this.getClass().getResource("").getPath();
					propsPath = propsPath.substring(0, propsPath.indexOf("/classes/")) + "/config/ocr_ftp.properties";
					Properties p = new Properties();
					// [200617] 취약점 수정
					in = new FileInputStream(propsPath);
					p.load(in);
					in.close();
					// [200617] 취약점 수정
					in = null;
					
					String password = p.getProperty("password");
					String decPassword = aes256Decrypt(password);
					if(password.equals(decPassword) || StringUtil.isEmpty(decPassword)) {
						decPassword = password;
						String encPassword = aes256Encrypt(password);
						logger.debug("encPassword: " + encPassword);
						// [200617] 취약점 수정
						out = new FileOutputStream(propsPath);
						p.setProperty("password", encPassword);
						p.store(out, "");
						out.close();
						// [200617] 취약점 수정
						out = null;
					}
					
					ftp = new FTPUtil(p.getProperty("ip"), p.getProperty("user"), decPassword, Integer.parseInt(p.getProperty("port")));
					
					int working = 0;
					for(int i = 1; i <= 3; i++) {
						String[] ls = ftp.ls("/RECOG_JOB" + i + "/" + yyyymmdd);
						for(int j = 0; j < ls.length; j++) {
							if(".".equals(ls[j]) || "..".equals(ls[j])) continue;
							working++;
						}
					}
	
					if(working <= 6) {
						String filename1 = "";
						
						filename1 = ftp.uploadToOCR("/RECOG/" + yyyymmdd, files.get(0), "--D");

						logger.debug("filename1: " + filename1);

						
						logger.debug("--- 1초 대기 ---");
						Thread.sleep(1000);
						int retryNum = 7;
						for(int retry = 0; retry < retryNum; retry++) {
							String[] ls = ftp.ls("/RECOG_RESULT/" + yyyymmdd);
		
							for(int i = 0; i < ls.length; i++) {
								logger.debug(i+"번째");
								logger.debug(ls[i]);
								if(!flag1 && ls[i].equals(filename1)) {
									flag1 = true;
								}
								
								if(flag1) break;
							}
		
							if((flag1) || retry == retryNum - 1) {
								break;
							}
							else {
								logger.debug("--- 0.6초 대기 ---");
								logger.debug("--- retry: " + retry + " ---");
								Thread.sleep(600);
							}
						}
						
						logger.debug("flag1: " + flag1);
						
						if(flag1) { 
							// [200617] 취약점 수정
							// filename1 = filename1.replaceAll("/", ""); 
							// filename1 = filename1.replaceAll("&", "");
							// filename1 = filename1.replaceAll("\\", "");
							String path = files.get(0).getParent() + File.separator + filename1;
							ftp.downloadFromOCR("/RECOG_RESULT/" + yyyymmdd, filename1, path);
							logger.debug(path);
							File f = new File(path);
							logger.info("7777 filename1:" + filename1);
							logger.info("7777 path:" + path);
		
							if(f.exists()) {
								Properties props = new Properties();
								// [200617] 취약점 수정
								fis = new FileInputStream(path);
								props.load(fis);
								fis.close();
								// [200617] 취약점 수정
								fis = null;
								
								if(!StringUtil.isEmpty(props.getProperty("ODO")) && !StringUtil.isEmpty(props.getProperty("RE_CODE"))) {
									aut_cgnt_trv_dstc = props.getProperty("ODO");
									aut_cgnt_trv_dstc_rsl_cd = "1".equals(props.getProperty("RE_CODE")) || "2".equals(props.getProperty("RE_CODE")) ? "01" : "02";
									
									aut_cgnt_trv_dstc_1 = props.getProperty("ODO");
									
									if(!StringUtil.isEmpty(props.getProperty("ODO2"))) {
										aut_cgnt_trv_dstc_2 = props.getProperty("ODO2");
									}
									
									if(!StringUtil.isEmpty(props.getProperty("ODO3"))) {
										aut_cgnt_trv_dstc_3 = props.getProperty("ODO3");
									}
								}
								
				            	if(f.delete()) {
									logger.debug("삭제: " + path);
								}
							}
						}
						else {
							aut_cgnt_trv_dstc_rsl_cd = "02";
						}						
					}
					else {
						aut_cgnt_trv_dstc_rsl_cd = "02";
						if(!"1".equals(jmvo.getCm_yn())) {
							aut_cgnt_vh_no_rsl_cd = "02";
						}
					}
				}
			}
			catch(Exception e) {
				System.err.println("[CarriderMileageController.mlFileUploadOCR()] Exception 발생");
				logger.debug(e.getMessage());
				aut_cgnt_trv_dstc_rsl_cd = "02";
				if(!"1".equals(jmvo.getCm_yn())) {
					aut_cgnt_vh_no_rsl_cd = "02";
				}
			}
			finally {
				if(ftp != null) ftp.disconnect();
				// [200617] 취약점 수정
				try{
		    	  	if(in != null){
		    	  		in.close();
		    	  	}
			      }catch(IOException ee){
			    	  System.err.println("[CarriderMileageController.mlFileUploadOCR()] IOException 1 발생");
			      }
				try{
		    	  	if(out != null){
		    	  		out.close();
		    	  	}
			      }catch(IOException ee){
			    	  System.err.println("[CarriderMileageController.mlFileUploadOCR()] IOException 2 발생");
			      }
				try{
		    	  	if(fis != null){
		    	  		fis.close();
		    	  	}
			      }catch(IOException ee){
			    	  System.err.println("[CarriderMileageController.mlFileUploadOCR()] IOException 3 발생");
			      }
			}
		}
		
		HttpSession session = request.getSession();

		Object[] imgfile = new Object[files.size()];
		// [200617] 취약점 수정
		FileInputStream fis = null;
		try {
			for(int i = 0; i < files.size(); i++) {
				File f = files.get(i);
				// [200617] 취약점 수정
				fis = new FileInputStream(f);
				byte[] file = new byte[(int) f.length()];
				fis.read(file);
				imgfile[i] = file;
				fis.close();
				// [200617] 취약점 수정
				fis = null;
				String fname = f.getName();
				f.delete();
				logger.debug(fname + " 삭제");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			System.err.println("[CarriderMileageController.mlFileUploadOCR()] Exception 발생");
		} 
		// [200617] 취약점 수정
		finally {
			try{
				if(fis!=null){
					fis.close();
				}
			}
			catch(IOException ee){
				System.err.println("[CarriderMileageController.mlFileUploadOCR()] IOException 4 발생");
		    	// ee.getMessage();
		    }
		}
		// [200617] 취약점 수정
		// logger.info("이미지파일" + imgfile.toString());
		
		session.setAttribute("imgfile", imgfile);
		
		map.put("errorCode",					"0");
		map.put("aut_cgnt_trv_dstc_rsl_cd",		aut_cgnt_trv_dstc_rsl_cd);
		map.put("aut_cgnt_vh_no_rsl_cd",		aut_cgnt_vh_no_rsl_cd);
		map.put("aut_cgnt_trv_dstc",			aut_cgnt_trv_dstc);
		map.put("aut_cgnt_vh_no",				aut_cgnt_vh_no);
		
		map.put("aut_cgnt_trv_dstc_1",			aut_cgnt_trv_dstc_1);
		map.put("aut_cgnt_trv_dstc_2",			aut_cgnt_trv_dstc_2);
		map.put("aut_cgnt_trv_dstc_3",			aut_cgnt_trv_dstc_3);
		
		map.put("phgp_rl_ptgr_dt",				phgp_rl_ptgr_dt);
		map.put("phgp_apdx_way_cd",				phgp_apdx_way_cd);
			
		return map;
	}

	@RequestMapping(value="/mlFileUploadOCR2")
	public @ResponseBody Map<String, String> mlFileUploadOCR2(MultipartHttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		Map<String, String> map = new HashMap<String, String>();

		String aut_cgnt_trv_dstc_rsl_cd	= StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc_rsl_cd"));	// 자동인식주행거리결과코드
		String aut_cgnt_vh_no_rsl_cd	= StringUtil.nvl(request.getParameter("aut_cgnt_vh_no_rsl_cd"));	// 자동인식차량번호결과코드
		String aut_cgnt_trv_dstc		= StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc"));		// 자동인식주행거리
		String aut_cgnt_vh_no			= StringUtil.nvl(request.getParameter("aut_cgnt_vh_no"));			// 자동인식차량번호
		
		String aut_cgnt_trv_dstc_1		= StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc_1"));		// 자동인식주행거리
		String aut_cgnt_trv_dstc_2		= StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc_2"));		// 자동인식주행거리
		String aut_cgnt_trv_dstc_3		= StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc_3"));		// 자동인식주행거리
		
		// 020708
		String phgp_rl_ptgr_dt			= StringUtil.nvl(request.getParameter("phgp_rl_ptgr_dt"));			// 사진실제촬영일자
		String phgp_apdx_way_cd			= StringUtil.nvl(request.getParameter("phgp_apdx_way_cd"));			// 사진첨부방식코드
		
		MMTI0213VO jmvo = new MMTI0213VO();
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("p")));
		jmvo = carRiderMileageService.getMMTI0213VO(jmvo);
		
		String exifDate1 = StringUtil.nvl(request.getParameter("exifDate1"));
		String phgp_ptgr_dt = "";
		
		boolean empty = false;
		if(exifDate1.indexOf(",gallery") > -1) {
			exifDate1 = exifDate1.substring(0, exifDate1.indexOf(",gallery"));
			if(StringUtil.isEmpty(exifDate1)) {
				exifDate1 = DateUtil.getDate();
				empty = true;
			}
			else if(Integer.parseInt(exifDate1) > Integer.parseInt(DateUtil.getDate())) {
				map.put("errorCode", "f");
				return map;
			}
		}

		phgp_ptgr_dt = empty ? "" : exifDate1;
		
		if(exifDate1.indexOf(",gallery") > -1) {
			exifDate1 = exifDate1.substring(0, exifDate1.indexOf(",gallery"));
		}
		
		HttpSession session = request.getSession();
		session.setAttribute("exifDate", exifDate1);

		ArrayList<File> files = carRiderMileageService.uploadToWAS(request, jmvo.getSms_ts_bvan());
		
		MMTI0259VO jmvo1 = new MMTI0259VO();
		jmvo1.setPbox_use_yn("1");
		jmvo1.setPbox_no(jmvo.getSms_ts_bvan());
		jmvo1.setPhgp_cnfm_dt(DateUtil.getDate());
		jmvo1.setPhgp_ptgr_dt(phgp_ptgr_dt);
		jmvo1.setPhgp_strg_yn("1");
		if("1".equals(jmvo.getAut_cgnt_nn_apcn_yn())) {
			jmvo1.setPbox_chr_nm(request.getParameter("mileage1"));
		}
		
		if("1".equals(jmvo.getPbox_no_dvcd())) {
			if(!"1".equals(jmvo.getCm_yn())) {
				jmvo1.setInpt_trv_dstc(request.getParameter("mileage1"));
				if(!StringUtil.isEmpty(aut_cgnt_vh_no)) {
					jmvo1.setAut_cgnt_vh_no(aut_cgnt_vh_no);
				}
				
				if(!StringUtil.isEmpty(aut_cgnt_vh_no_rsl_cd)) {
					jmvo1.setAut_cgnt_vh_no_rsl_cd(aut_cgnt_vh_no_rsl_cd);
				}
				else {
					jmvo1.setAut_cgnt_vh_no_rsl_cd("02");
				}
			}
				
			if(!StringUtil.isEmpty(aut_cgnt_trv_dstc)) {
				jmvo1.setAut_cgnt_trv_dstc(aut_cgnt_trv_dstc);
			}
			
			if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_rsl_cd)) {
				jmvo1.setAut_cgnt_trv_dstc_rsl_cd(aut_cgnt_trv_dstc_rsl_cd);
			}
			else {
				jmvo1.setAut_cgnt_trv_dstc_rsl_cd("02");
			}
			
			if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_1)) {
				jmvo1.setAut_cgnt_trv_dstc_1(aut_cgnt_trv_dstc_1);
			}
			
			if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_2)) {
				jmvo1.setAut_cgnt_trv_dstc_2(aut_cgnt_trv_dstc_2);
			}
			
			if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_3)) {
				jmvo1.setAut_cgnt_trv_dstc_3(aut_cgnt_trv_dstc_3);
			}
		}
		
		// 200708
		jmvo1.setPhgp_rl_ptgr_dt(phgp_rl_ptgr_dt);
		jmvo1.setPhgp_apdx_way_cd(phgp_apdx_way_cd);
		
		jmvo1 = carRiderMileageService.getMMTI0259VO(jmvo1);
		
		if("0".equals(jmvo1.getErrorCode()) && !"1".equals(jmvo.getCm_yn())) {
			jmvo1.setExp_exca_plan_proc_dvn("1");
			jmvo1.setPlno(jmvo.getPlno());
			
			// 200708
			jmvo1.setPhgp_rl_ptgr_dt(phgp_rl_ptgr_dt);
			jmvo1.setPhgp_apdx_way_cd(phgp_apdx_way_cd);
			
			jmvo1 = carRiderMileageService.getMMTI0259VO(jmvo1);
			
			if("08".equals(jmvo.getProc_dvn())) {
				carRiderMileageService.regInfoToEdmsForMobileWeb2(request, jmvo.getNtft_srv_rc_ormm_cd(), files, jmvo.getPlno() + "," + jmvo.getChng_plan_no());
			}
			else if(!StringUtil.isEmpty(jmvo1.getPlno()) && !StringUtil.isEmpty(jmvo1.getExp_exca_plan_no())) {
				carRiderMileageService.regInfoToEdmsForMobileWeb2(request, jmvo.getNtft_srv_rc_ormm_cd(), files, jmvo1.getPlno() + "," + jmvo1.getExp_exca_plan_no());
			}
			else if(!StringUtil.isEmpty(jmvo1.getPlno()) && StringUtil.isEmpty(jmvo1.getExp_exca_plan_no())) {
				carRiderMileageService.regInfoToEdmsForMobileWeb2(request, jmvo.getNtft_srv_rc_ormm_cd(), files, jmvo1.getPlno());
			}
		}
		else {
			if("1".equals(jmvo.getCm_yn())) {
				carRiderMileageService.regInfoToEdmsForMobileWeb(request, jmvo.getSms_ts_bvan());
			}
			else {
				carRiderMileageService.regInfoToEdmsForMobileWeb2(request, jmvo.getNtft_srv_rc_ormm_cd(), files, jmvo1.getPlno());
			}
		}

		for(int i = 0; i < files.size(); i++) {
			File f = files.get(i);
			String fname = f.getName();
			/*String fsize = Long.toString(f.length());*/
			long fsz = f.length();
			String logg = String.valueOf(fsz);
			/*logger.debug("##파일사이즈: " + logg);*/
			logger.info("##파일사이즈: " + logg);
			// logger.debug("##파일사이즈: " + fsize);
			f.delete();
			logger.debug(fname + " 삭제");
		}
		
		map.put("errorCode",				jmvo1.getErrorCode());
		map.put("z_resp_msg",				jmvo1.getZ_resp_msg());
		map.put("exp_exca_plan_rsl_cd",		jmvo1.getExp_exca_plan_rsl_cd());
		map.put("adc_rtrn_dvn",				jmvo1.getAdc_rtrn_dvn());
		map.put("adc_rtrn_prm",				jmvo1.getAdc_rtrn_prm());
		map.put("plno",						jmvo1.getPlno());
		map.put("exp_exca_plan_no",			jmvo1.getExp_exca_plan_no());
		map.put("exp_exca_plan_bse_dd",		jmvo1.getExp_exca_plan_bse_dd());
		map.put("aut_cgnt_vh_no",			jmvo1.getAut_cgnt_vh_no());
		map.put("aut_cgnt_vh_no_rsl_cd",	jmvo1.getAut_cgnt_vh_no_rsl_cd());
		map.put("aut_cgnt_trv_dstc",		jmvo1.getAut_cgnt_trv_dstc());
		map.put("aut_cgnt_trv_dstc_rsl_cd",	jmvo1.getAut_cgnt_trv_dstc_rsl_cd());
		map.put("exp_exca_plan_proc_dvn",	jmvo1.getExp_exca_plan_proc_dvn());
		map.put("cnv_trv_dstc",				jmvo1.getCnv_trv_dstc());
		map.put("plhd_cust_nm", 			jmvo1.getPlhd_cust_nm());
		map.put("pdc_sr_dvn", 				jmvo1.getPdc_sr_dvn());
			
		return map;
	}
	
	@RequestMapping(value="/up1")
	public String up1(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		HttpSession session = request.getSession();
		MMTI0217VO jmvo = new MMTI0217VO();

		jmvo.setMbl_snd_no(aes256Decrypt(StringUtil.nvl(request.getParameter("p"))));
		jmvo = carRiderMileageService.getMMTI0217VO(jmvo);

		session.setAttribute("p", jmvo.getMbl_snd_no());
		request.setAttribute("p", StringUtil.nvl(request.getParameter("p")));
		request.setAttribute("jmvo", jmvo);
		
		return "/counter/carrider/mobileweb/up1";
	}

	@RequestMapping(value="/up2")
	public String up2(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		HttpSession session = request.getSession();
		MMTI0217VO jmvo = new MMTI0217VO();

		if(session.getAttribute("p") != null) {
			jmvo.setMbl_snd_no((String) session.getAttribute("p"));
		}
		else {
			jmvo.setMbl_snd_no(aes256Decrypt(StringUtil.nvl(request.getParameter("p"))));
		}
		jmvo = carRiderMileageService.getMMTI0217VO(jmvo);

		request.setAttribute("p", StringUtil.nvl(request.getParameter("p")));
		request.setAttribute("jmvo", jmvo);
		return "/counter/carrider/mobileweb/up2";
	}

	@RequestMapping(value="/upStatus")
	public @ResponseBody Map<String, String> up_status(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		HttpSession session = request.getSession();
		Map<String, String> map = new HashMap<String, String>();
		MMTI0217VO jmvo = new MMTI0217VO();
		MMTI0218VO jmvo1 = new MMTI0218VO();

		if(session.getAttribute("p") != null) {
			jmvo.setMbl_snd_no((String) session.getAttribute("p"));
		}
		else {
			jmvo.setMbl_snd_no(aes256Decrypt(StringUtil.nvl(request.getParameter("p"))));
		}
		jmvo = carRiderMileageService.getMMTI0217VO(jmvo);

		jmvo1.setMbl_snd_no(jmvo.getMbl_snd_no());
		jmvo1.setPlan_plno_dvcd(jmvo.getPlan_plno_dvcd());
		jmvo1.setPlan_plno(jmvo.getPlan_plno());
		jmvo1.setChng_plan_no(jmvo.getChng_plan_no());
		
		jmvo1 = carRiderMileageService.getMMTI0218VO(jmvo1);
		for(int i = 0; i < jmvo1.getPhgp_regt_tgt__dst_tty_dvn().length; i++) {
			map.put("ok" + jmvo1.getPhgp_regt_tgt__dst_tty_dvn()[i], jmvo1.getPhgp_regt_tgt__phgp_regt_cplt_yn()[i]);
		}
		
		return map;
	}

	@RequestMapping(value="/upFileUpload")
	public @ResponseBody Map<String, String> upFileUpload(MultipartHttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		HttpSession session = request.getSession();
		Map<String, String> map = new HashMap<String, String>();
		String p = "";
		if(session.getAttribute("p") != null) {
			p = (String) session.getAttribute("p");
		}
		else {
			p = aes256Decrypt(StringUtil.nvl(request.getParameter("p")));
		}
		String dvn = StringUtil.nvl(request.getParameter("dvn"));
		String pbox_no = "";
		
		MMTI0217VO jmvo = new MMTI0217VO();
		jmvo.setMbl_snd_no(p);
		jmvo = carRiderMileageService.getMMTI0217VO(jmvo);
		
		if("01".equals(dvn) || "02".equals(dvn)) {
			try {
				for(int i = 0; i < jmvo.getIner_mbl_snd_mtt__dst_tty_dvn().length; i++) {
					if(dvn.equals(jmvo.getIner_mbl_snd_mtt__dst_tty_dvn()[i])) {
						pbox_no = jmvo.getIner_mbl_snd_mtt__pbox_no()[i];
						break;
					}
				}
				
				carRiderMileageService.regInfoToEdmsForMobileWeb(request, pbox_no);
				
				MMTI0259VO jmvo1 = new MMTI0259VO();
				jmvo1.setPbox_use_yn("1");
				jmvo1.setPbox_no(pbox_no);
				jmvo1.setPhgp_cnfm_dt(DateUtil.getDate("yyyymmdd"));
				jmvo1.setPhgp_strg_yn("1");
				
				if(!"1".equals(jmvo.getCm_yn())) {
					jmvo1.setPbox_chr_nm(StringUtil.nvl(request.getParameter("mileage1")));
				}
				jmvo1 = carRiderMileageService.getMMTI0259VO(jmvo1);
				
				map.put("errorCode", jmvo1.getErrorCode());
			}
			catch(Exception e) {
				logger.debug(e.getMessage());
				map.put("errorCode", "-1");
			}
		}
		else if("03".equals(dvn) || "04".equals(dvn) || "05".equals(dvn)) {
			MMTI0289VO jmvo1 = new MMTI0289VO();
			
			jmvo1.setMbl_snd_no(p);
			jmvo1.setMbl_ts_dtl_dvcd("01");
			jmvo1.setPlan_plno(jmvo.getPlan_plno());
			
			if("03".equals(dvn)) jmvo1.setMbl_bz_dvcd("35");
			if("04".equals(dvn)) jmvo1.setMbl_bz_dvcd("43");
			if("05".equals(dvn)) jmvo1.setMbl_bz_dvcd("55");
			
			try {
				carRiderMileageService.regInfoToEdmsForMobileWeb(request, jmvo1);
				map.put("errorCode", "0");
			}
			catch(Exception e) {
				logger.debug(e.getMessage());
				map.put("errorCode", "-1");
			}
		}
		
		if("0".equals(map.get("errorCode"))) {
			MMTI0218VO jmvo1 = new MMTI0218VO();
	
			jmvo1.setMbl_snd_no(jmvo.getMbl_snd_no());
			jmvo1.setPlan_plno_dvcd(jmvo.getPlan_plno_dvcd());
			jmvo1.setPlan_plno(jmvo.getPlan_plno());
			jmvo1.setChng_plan_no(jmvo.getChng_plan_no());
			
			jmvo1 = carRiderMileageService.getMMTI0218VO(jmvo1);
			int count = 0;
			for(int i = 0; i < jmvo1.getPhgp_regt_tgt__dst_tty_dvn().length; i++) {
				if("Y".equals(jmvo1.getPhgp_regt_tgt__phgp_regt_cplt_yn()[i]) || "1".equals(jmvo1.getPhgp_regt_tgt__phgp_regt_cplt_yn()[i])) count++;
			}
			
			if(count > 0 && count == jmvo1.getPhgp_regt_tgt__dst_tty_dvn().length) map.put("errorCode", "1");
		}

		return map;
	}
	
	@RequestMapping(value="/updatejungsan")
	public @ResponseBody Map<String, String> updatejungsan(HttpServletRequest request, Model model) throws Exception{
		Map<String, String> map = new HashMap<String, String>();
		try {
			map = new HashMap<String, String>();
			XIDB0004VO vo = new XIDB0004VO();
			String seq = StringUtil.nvl(request.getParameter("seq"));
			String stat = StringUtil.nvl(request.getParameter("stat"));
			String msg = StringUtil.nvl(request.getParameter("msg"));
			logger.info("updatejungsan seq: " + seq);
			logger.info("updatejungsan stat: " + stat);
			logger.info("updatejungsan msg: " + msg);
			
			vo.setSeq(seq);
			vo.setStat(stat);
			vo.setMsg(msg);
			carRiderMileageService.getXIDB0004VO(vo);
			map.put("result", "y");
		} catch (Exception e) {
			map.put("result", "n");
			logger.info("updatejungsan : " + e.getMessage());
		}
		return map;
	}
	
	@RequestMapping(value="/chatMileage01")
	public String chatMileage01(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception{
		
		MMTI0213VO jmvo = new MMTI0213VO();
		MMTI0305VO jmvo1 = new MMTI0305VO();
		
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("num")));
		String ch_dvn = request.getParameter("ch_dvn");
		
		jmvo = carRiderMileageService.chatMMTI0213VO(jmvo);
		
		jmvo1.setSrch_cnd__vh_no(SeedUtil.encrypt(jmvo.getVh_no()));
		jmvo1.setSrch_cnd__plno(jmvo.getPlno());
		jmvo1.setSrch_cnd__proc_dvn("01");
		jmvo1.setSrch_cnd__hdlr_empno("80000176");
		jmvo1.setSrch_cnd__trv_dstc_proc_dvcd(jmvo.getProc_dvn());
		jmvo1 = carRiderMileageService.chatMMTI0305VO(jmvo1);
		
		String tty_eny_yn = jmvo1.getSrch_rsl__tty_eny_yn() == null ? "" : jmvo1.getSrch_rsl__tty_eny_yn();
		logger.info("tty_eny_yn: " + tty_eny_yn);
	
		request.setAttribute("num", request.getParameter("num"));
		request.setAttribute("jmvo", jmvo);
		request.setAttribute("tty_eny_yn", tty_eny_yn);
		request.setAttribute("ch_dvn", ch_dvn);
		return "/counter/carrider/mobileweb/chat_mileage01";
	}
	
	@RequestMapping(value="/chatMileage02")
	public String chatMileage02(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		MMTI0213VO jmvo = new MMTI0213VO();
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("num")));
		jmvo = carRiderMileageService.chatMMTI0213VO(jmvo);
		request.setAttribute("num", request.getParameter("num"));
		request.setAttribute("jmvo", jmvo);
		request.setAttribute("ch_dvn", request.getParameter("ch_dvn"));
		return "/counter/carrider/mobileweb/chat_mileage02";
	}
	
	@RequestMapping(value="/chatMileageFileUpload")
	public @ResponseBody Map<String, String> chatMileageFileUpload(MultipartHttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		
		logger.info(StringUtil.nvl(request.getParameter("ch_dvn")));
		logger.info(aes256Decrypt(request.getParameter("num")));
		
		Map<String, String> map = new HashMap<String, String>();
		
		String ch_dvn = StringUtil.nvl(request.getParameter("ch_dvn"));
		
		MMTI0213VO jmvo = new MMTI0213VO();
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("num")));
		jmvo = carRiderMileageService.chatMMTI0213VO(jmvo);

		carRiderMileageService.regInfoToEdmsForMobileWeb(request, jmvo.getSms_ts_bvan());
		
		MMTI0259VO jmvo1 = new MMTI0259VO();
		jmvo1.setPbox_use_yn("1");
		jmvo1.setPbox_no(jmvo.getSms_ts_bvan());
		jmvo1.setPhgp_cnfm_dt(DateUtil.getDate("yyyymmdd"));
		jmvo1.setPhgp_strg_yn("1");
		
		if("1".equals(jmvo.getPbox_no_dvcd())) { // cm_yn!=1 제거
			if("03".equals(jmvo.getProc_dvn())) {
				jmvo1.setPbox_chr_nm(request.getParameter("mileage1") + "/" + request.getParameter("mileage2"));
			}
			else {
				jmvo1.setPbox_chr_nm(request.getParameter("mileage1"));
			}
		}
		
		/*if("1".equals(jmvo.pbox_no_dvcd) && !"1".equals(jmvo.cm_yn)) {
			if("03".equals(jmvo.proc_dvn)) {
				jmvo1.pbox_chr_nm = request.getParameter("mileage1") + "/" + request.getParameter("mileage2");
			}
			else {
				jmvo1.pbox_chr_nm = request.getParameter("mileage1");
			}
		}*/
		
		jmvo1 = carRiderMileageService.chatMMTI0259VO(jmvo1);
		
		map.put("errorCode", jmvo1.getErrorCode());
		logger.info("errorCode: " + jmvo1.getErrorCode());
		
		ch_dvn="01";
		
		if("0".equals(jmvo1.getErrorCode()) && "01".equals(ch_dvn)){
			MMTI0305VO jmvo2 = new MMTI0305VO();
			jmvo2.setSrch_cnd__proc_dvn("03");
			jmvo2.setSrch_cnd__plno(jmvo.getPlno());
			jmvo2.setSrch_cnd__plan_no(jmvo.getPlan_no());
			jmvo2.setSrch_cnd__hdlr_empno("80000176");
			jmvo2 = carRiderMileageService.chatMMTI0305VO(jmvo2);
			logger.info("rtun_cd: " + jmvo2.getSrch_rsl__rtun_cd() + ", rtun_msg: " + jmvo2.getSrch_rsl__rtun_msg());
			map.put("rtun_cd", jmvo2.getSrch_rsl__rtun_cd());
			map.put("rtun_msg", jmvo2.getSrch_rsl__rtun_msg());
		}
			
		return map;
	}
	
	@RequestMapping(value="/chat_ml1")
	public String chat_ml1(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		MMTI0213VO jmvo = new MMTI0213VO();
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("p")));
		jmvo = carRiderMileageService.chatMMTI0213VO(jmvo);
		String ch_dvn = StringUtil.nvl(request.getParameter("ch_dvn"));

		request.setAttribute("p", request.getParameter("p"));
		request.setAttribute("ch_dvn", ch_dvn);
		request.setAttribute("jmvo", jmvo);
		return "/counter/carrider/mobileweb/chat_ml1";
	}	

	@RequestMapping(value="/chat_ml2")
	public String chat_ml2(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		MMTI0213VO jmvo = new MMTI0213VO();
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("p")));
		jmvo = carRiderMileageService.chatMMTI0213VO(jmvo);
		String ch_dvn = StringUtil.nvl(request.getParameter("ch_dvn"));
		
		request.setAttribute("p", request.getParameter("p"));
		request.setAttribute("ch_dvn", ch_dvn);
		request.setAttribute("jmvo", jmvo);
		return "/counter/carrider/mobileweb/chat_ml2";
	}
	
	@RequestMapping(value="/chat_ml2_1")
	public String chat_ml2_1(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		MMTI0213VO jmvo = new MMTI0213VO();
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("p")));
		String ch_dvn = StringUtil.nvl(request.getParameter("ch_dvn"));
		jmvo = carRiderMileageService.chatMMTI0213VO(jmvo);
		
		HttpSession session = request.getSession();
		Object[] imgfile = (Object[]) session.getAttribute("imgfile");
		if(imgfile != null) {
			byte[] file = (byte[]) imgfile[0];
			logger.debug("file.length: " + file.length);
			request.setAttribute("imgsrc", "data:image/jpeg;base64," + new String(Base64.encodeBase64(file)));
		}
		
		request.setAttribute("p", request.getParameter("p"));
		// request.setAttribute("ch_dvn", request.getParameter("ch_dvn"));
		request.setAttribute("ch_dvn", ch_dvn);
		request.setAttribute("jmvo", jmvo);
		return "/counter/carrider/mobileweb/chat_ml2_1";
	}
	@RequestMapping(value="/chat_ml3")
	public String chat_ml3(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		MMTI0213VO jmvo = new MMTI0213VO();
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("p")));
		jmvo = carRiderMileageService.chatMMTI0213VO(jmvo);
		
		String ch_dvn = StringUtil.nvl(request.getParameter("ch_dvn"));
		
		String exp_exca_plan_rsl_cd = request.getParameter("exp_exca_plan_rsl_cd");
		if("1".equals(jmvo.getTrv_dstc_splc_exca_yn())) {
			if(exp_exca_plan_rsl_cd.equals("11") || exp_exca_plan_rsl_cd.equals("13") || exp_exca_plan_rsl_cd.equals("14")) {
				// [200617] 취약점 수정
				// Map<String, String> map = new HashMap<String, String>();
				MMTI0291VO jmvo1 = new MMTI0291VO();
				jmvo1.setTrv_dstc_exca_mtt__exca_bz_proc_dvn("2");
				jmvo1.setTrv_dstc_exca_mtt__plno(StringUtil.nvl(request.getParameter("plno")));
				jmvo1.setTrv_dstc_exca_mtt__plan_no(StringUtil.nvl(request.getParameter("exp_exca_plan_no")));
				jmvo1.setTrv_dstc_exca_mtt__exca_rtrn_dvn("");
				jmvo1.setTrv_dstc_exca_mtt__pdc_sr_dvn(StringUtil.nvl(request.getParameter("pdc_sr_dvn")));
				jmvo1.setTrv_dstc_exca_mtt__adc_rtrn_dvn(StringUtil.nvl(request.getParameter("adc_rtrn_dvn")));
				jmvo1.setTrv_dstc_exca_mtt__adc_rtrn_prm(StringUtil.nvl(request.getParameter("adc_rtrn_prm")));
				jmvo1.setTrv_dstc_exca_mtt__scrn_proc_cd(StringUtil.nvl(request.getParameter("exp_exca_plan_rsl_cd")));
				jmvo1.setTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn(jmvo.getTrv_dstc_splc_exca_yn());
				jmvo1.setTrv_dstc_exca_mtt__pbox_no(jmvo.getSms_ts_bvan());
				jmvo1.setTrv_dstc_exca_mtt__hdlr_empno("80000176");
				jmvo1 = carRiderMileageService.chatMMTI0291VO(jmvo1);
				
				request.setAttribute("z_resp_cd", jmvo1.getZ_resp_cd());
				request.setAttribute("z_resp_msg", jmvo1.getZ_resp_msg());
				
				// 이미지 중복이면 확정신청페이지
				if("1".equals(jmvo1.getTrv_dstc_exca_mtt__imag_dup_yn())){
					exp_exca_plan_rsl_cd = "14";
				}
				
				// CM 상품이고, 화면처리코드 IN(02, 14) or 이미지 중복
				
				if("CM".equals(jmvo1.getTrv_dstc_exca_mtt__pdc_sr_dvn()) && 
						("02".equals(jmvo1.getTrv_dstc_exca_mtt__scrn_proc_cd())
						|| "14".equals(jmvo1.getTrv_dstc_exca_mtt__scrn_proc_cd()))){
					
					MMTI0015VO mmti0015vo = new MMTI0015VO();
					mmti0015vo.setFunt_key("00");
					mmti0015vo.setPlan_no(jmvo1.trv_dstc_exca_mtt__plan_no);
					mmti0015vo = carRiderMileageService.getMMTI0015VO(mmti0015vo);
					
					logger.debug("##### MMTI0015 시작 ##########################");
					logger.debug("##### 고객식별번호: " + mmti0015vo.getPlhd__cust_dcmt_no() + " ##########################");
					logger.debug("##### 고객번호: " + mmti0015vo.getPlhd__cust_no() + " ##########################");
					logger.debug("##### 고객명: " + mmti0015vo.getPlhd__cust_nm() + " ##########################");
					logger.debug("##### 이메일: " + mmti0015vo.getPlhd__eml() + " ##########################");
					logger.debug("##### 지역번호: " + mmti0015vo.getPlhd_cntp_if__tlp_arno() + " ##########################");
					logger.debug("##### 국번호: " + mmti0015vo.getPlhd_cntp_if__tlp_ofno() + " ##########################");
					logger.debug("##### 개별번호: " + mmti0015vo.getPlhd_cntp_if__tlp_idvno() + " ##########################");
					
					XTEM0021VO xtem0021vo = new XTEM0021VO();
					xtem0021vo.setCnsl_rpt_no("");						// 상담접수번호				
					xtem0021vo.setCm_bz_dvcd("05");
					xtem0021vo.setCnsl_typ_dvcd("07");
					xtem0021vo.setCm_plan_no(jmvo1.getTrv_dstc_exca_mtt__plan_no());
					xtem0021vo.setCnsl_rpy_dvcd("1");
					xtem0021vo.setCnsl_rpt_dttm(getDayTime());			// 현재년월일시분초 14자리
					xtem0021vo.setCust_nm(mmti0015vo.getPlhd__cust_nm());
					xtem0021vo.setCust_no(mmti0015vo.getPlhd__cust_no());
					
					String cust_dcmt_no = SeedUtil.decrypt(mmti0015vo.getPlhd__cust_dcmt_no());
					
					if("1".equals(cust_dcmt_no.substring(6, 7)) || "2".equals(cust_dcmt_no.substring(6, 7))
						|| "5".equals(cust_dcmt_no.substring(6, 7)) || "6".equals(cust_dcmt_no.substring(6, 7))){
						xtem0021vo.setBrth("19" + cust_dcmt_no.substring(0, 6));
					} else{
						xtem0021vo.setBrth("20" + cust_dcmt_no.substring(0, 6));
					}
					// xtem0021vo.setBrth("");  							// 생년월일
					xtem0021vo.setSx_cd(cust_dcmt_no.substring(6, 7));
					xtem0021vo.setEml_adr(mmti0015vo.getPlhd__eml());
					xtem0021vo.setClp_tlcno(mmti0015vo.getPlhd_cntp_if__tlp_arno());
					xtem0021vo.setClp_ofno(mmti0015vo.getPlhd_cntp_if__tlp_ofno());
					xtem0021vo.setClp_idvno(mmti0015vo.getPlhd_cntp_if__tlp_idvno());
					xtem0021vo.setCnsl_rsvt_dt("99990101");
					xtem0021vo.setCnsl_rsvt_time_cd("1");
					xtem0021vo.setCnsl_cn("최종주행거리사진등록/만기정산");
					xtem0021vo.setCnsl_aply_csn_yn("1");
					xtem0021vo.setUrl_adr("");
					xtem0021vo.setCm_ctrmf_tpcd("32");
					xtem0021vo.setFrst_ipmn_empno("80000028");
					xtem0021vo.setFrst_ipnpt_dttm(getDayTime());		// 현재년월일시분초 14자리	
					
					xtem0021vo = carRiderMileageService.getXTEM0021VO(xtem0021vo);
					logger.debug("##### XTEM0021 시작 ##########################");
					logger.debug("##### 처리결과: [ " + xtem0021vo.getProc_rtn() + " ] ##########################");
				}
			}
		}
		
		request.setAttribute("p",							request.getParameter("p"));
		request.setAttribute("jmvo",						jmvo);
		request.setAttribute("exp_exca_plan_rsl_cd",		exp_exca_plan_rsl_cd);
		request.setAttribute("adc_rtrn_dvn",				request.getParameter("adc_rtrn_dvn"));
		request.setAttribute("adc_rtrn_prm",				request.getParameter("adc_rtrn_prm"));
		request.setAttribute("plno",						request.getParameter("plno"));
		request.setAttribute("exp_exca_plan_no",			request.getParameter("exp_exca_plan_no"));
		request.setAttribute("exp_exca_plan_bse_dd",		request.getParameter("exp_exca_plan_bse_dd"));
		request.setAttribute("aut_cgnt_vh_no",				request.getParameter("aut_cgnt_vh_no"));
		request.setAttribute("aut_cgnt_vh_no_rsl_cd",		request.getParameter("aut_cgnt_vh_no_rsl_cd"));
		request.setAttribute("aut_cgnt_trv_dstc",			request.getParameter("aut_cgnt_trv_dstc"));
		request.setAttribute("aut_cgnt_trv_dstc_rsl_cd",	request.getParameter("aut_cgnt_trv_dstc_rsl_cd"));
		request.setAttribute("exp_exca_plan_proc_dvn",		request.getParameter("exp_exca_plan_proc_dvn"));
		request.setAttribute("cnv_trv_dstc",				request.getParameter("cnv_trv_dstc"));
		request.setAttribute("plhd_cust_nm",				request.getParameter("plhd_cust_nm"));
		request.setAttribute("pdc_sr_dvn",					request.getParameter("pdc_sr_dvn"));
		request.setAttribute("errorCode",					request.getParameter("errorCode"));
		request.setAttribute("ch_dvn",						ch_dvn);
		
		return "/counter/carrider/mobileweb/chat_ml3";
	}
	
	@RequestMapping(value="/chat_ml3_1")
	public @ResponseBody Map<String, String> chat_ml3_1(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		Map<String, String> map = new HashMap<String, String>();
		MMTI0291VO jmvo = new MMTI0291VO();
		jmvo.setTrv_dstc_exca_mtt__exca_bz_proc_dvn("2");
		jmvo.setTrv_dstc_exca_mtt__plno(StringUtil.nvl(request.getParameter("plno")));
		jmvo.setTrv_dstc_exca_mtt__plan_no(StringUtil.nvl(request.getParameter("exp_exca_plan_no")));
		jmvo.setTrv_dstc_exca_mtt__exca_rtrn_dvn("");
		jmvo.setTrv_dstc_exca_mtt__pdc_sr_dvn(StringUtil.nvl(request.getParameter("pdc_sr_dvn")));
		jmvo.setTrv_dstc_exca_mtt__adc_rtrn_dvn(StringUtil.nvl(request.getParameter("adc_rtrn_dvn")));
		jmvo.setTrv_dstc_exca_mtt__adc_rtrn_prm(StringUtil.nvl(request.getParameter("adc_rtrn_prm")));
		jmvo.setTrv_dstc_exca_mtt__scrn_proc_cd(StringUtil.nvl(request.getParameter("exp_exca_plan_rsl_cd")));
		jmvo.setTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn(StringUtil.nvl(request.getParameter("trv_dstc_splc_exca_yn")));
		jmvo.setTrv_dstc_exca_mtt__pbox_no(StringUtil.nvl(request.getParameter("pbox_no")));
		jmvo = carRiderMileageService.chatMMTI0291VO(jmvo);

		map.put("trv_dstc_exca_mtt__exca_bz_proc_dvn",			jmvo.getTrv_dstc_exca_mtt__exca_bz_proc_dvn());
		map.put("trv_dstc_exca_mtt__plno", 						jmvo.getTrv_dstc_exca_mtt__plno());
		map.put("trv_dstc_exca_mtt__plan_no", 					jmvo.getTrv_dstc_exca_mtt__plan_no());
		map.put("trv_dstc_exca_mtt__plan_dt", 					jmvo.getTrv_dstc_exca_mtt__plan_dt());
		map.put("trv_dstc_exca_mtt__exca_rtrn_dvn", 			jmvo.getTrv_dstc_exca_mtt__exca_rtrn_dvn());
		map.put("trv_dstc_exca_mtt__bank_cd", 					jmvo.getTrv_dstc_exca_mtt__bank_cd());
		map.put("trv_dstc_exca_mtt__acc_no", 					jmvo.getTrv_dstc_exca_mtt__acc_no());
		map.put("trv_dstc_exca_mtt__adc_rtrn_dvn", 				jmvo.getTrv_dstc_exca_mtt__adc_rtrn_dvn());
		map.put("trv_dstc_exca_mtt__adc_rtrn_prm", 				jmvo.getTrv_dstc_exca_mtt__adc_rtrn_prm());
		map.put("trv_dstc_exca_mtt__cnv_trv_dstc", 				jmvo.getTrv_dstc_exca_mtt__cnv_trv_dstc());
		map.put("trv_dstc_exca_mtt__nrm_proc_yn", 				jmvo.getTrv_dstc_exca_mtt__nrm_proc_yn());
		map.put("trv_dstc_exca_mtt__aut_cgnt_vh_no_eqal_yn", 	jmvo.getTrv_dstc_exca_mtt__aut_cgnt_vh_no_eqal_yn());
		map.put("trv_dstc_exca_mtt__aut_cgnt_trv_dstc_eqal_yn",	jmvo.getTrv_dstc_exca_mtt__aut_cgnt_trv_dstc_eqal_yn());
		map.put("trv_dstc_exca_mtt__rnw_plno", 					jmvo.getTrv_dstc_exca_mtt__rnw_plno());
		map.put("trv_dstc_exca_mtt__hdlr_empno", 				jmvo.getTrv_dstc_exca_mtt__hdlr_empno());
		map.put("trv_dstc_exca_mtt__aut_cgnt_trv_dstc_rsl_cd", 	jmvo.getTrv_dstc_exca_mtt__aut_cgnt_trv_dstc_rsl_cd());
		map.put("trv_dstc_exca_mtt__plhd_cust_nm", 				jmvo.getTrv_dstc_exca_mtt__plhd_cust_nm());
		map.put("trv_dstc_exca_mtt__pdc_sr_dvn", 				jmvo.getTrv_dstc_exca_mtt__pdc_sr_dvn());
		map.put("trv_dstc_exca_mtt__scrn_proc_cd", 				jmvo.getTrv_dstc_exca_mtt__scrn_proc_cd());
		map.put("trv_dstc_exca_mtt__arc_trm_str_dt", 			jmvo.getTrv_dstc_exca_mtt__arc_trm_str_dt());
		map.put("z_resp_cd",									jmvo.getZ_resp_cd());
		
		return map;
	}
	
	@RequestMapping(value="/chat_ml4")
	public String chat_ml4(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		MMTI0213VO jmvo = new MMTI0213VO();
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("p")));
		jmvo = carRiderMileageService.chatMMTI0213VO(jmvo);

		String gubun = request.getParameter("gubun");
		String ch_dvn = StringUtil.nvl(request.getParameter("ch_dvn"));
		request.setAttribute("p",							request.getParameter("p"));
		request.setAttribute("jmvo",						jmvo);
		request.setAttribute("exp_exca_plan_rsl_cd",		request.getParameter("exp_exca_plan_rsl_cd"));
		request.setAttribute("adc_rtrn_dvn",				request.getParameter("adc_rtrn_dvn"));
		request.setAttribute("adc_rtrn_prm",				request.getParameter("adc_rtrn_prm"));
		request.setAttribute("plno",						request.getParameter("plno"));
		request.setAttribute("exp_exca_plan_no",			request.getParameter("exp_exca_plan_no"));
		request.setAttribute("exp_exca_plan_bse_dd",		request.getParameter("exp_exca_plan_bse_dd"));
		request.setAttribute("aut_cgnt_vh_no",				request.getParameter("aut_cgnt_vh_no"));
		request.setAttribute("aut_cgnt_vh_no_rsl_cd",		request.getParameter("aut_cgnt_vh_no_rsl_cd"));
		request.setAttribute("aut_cgnt_trv_dstc",			request.getParameter("aut_cgnt_trv_dstc"));
		request.setAttribute("aut_cgnt_trv_dstc_rsl_cd",	request.getParameter("aut_cgnt_trv_dstc_rsl_cd"));
		request.setAttribute("cnv_trv_dstc",				request.getParameter("cnv_trv_dstc"));
		request.setAttribute("plhd_cust_nm",				request.getParameter("plhd_cust_nm"));
		request.setAttribute("pdc_sr_dvn",					request.getParameter("pdc_sr_dvn"));
		request.setAttribute("gubun",						gubun);
		request.setAttribute("ch_dvn", 						ch_dvn);
		
		if("2".equals(gubun) || "3".equals(gubun)) {
			MMTI0291VO jmvo1 = new MMTI0291VO();
			
			if("1".equals(request.getParameter("skip"))) {
				jmvo1.setTrv_dstc_exca_mtt__exca_bz_proc_dvn(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__exca_bz_proc_dvn")));
				jmvo1.setTrv_dstc_exca_mtt__plno(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__plno")));
				jmvo1.setTrv_dstc_exca_mtt__plan_no(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__plan_no")));
				jmvo1.setTrv_dstc_exca_mtt__plan_dt(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__plan_dt")));
				jmvo1.setTrv_dstc_exca_mtt__exca_rtrn_dvn(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__exca_rtrn_dvn")));
				jmvo1.setTrv_dstc_exca_mtt__bank_cd(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__bank_cd")));
				jmvo1.setTrv_dstc_exca_mtt__acc_no(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__acc_no")));
				jmvo1.setTrv_dstc_exca_mtt__adc_rtrn_dvn(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__adc_rtrn_dvn")));
				jmvo1.setTrv_dstc_exca_mtt__adc_rtrn_prm(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__adc_rtrn_prm")));
				jmvo1.setTrv_dstc_exca_mtt__cnv_trv_dstc(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__cnv_trv_dstc")));
				jmvo1.setTrv_dstc_exca_mtt__nrm_proc_yn(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__nrm_proc_yn")));
				jmvo1.setTrv_dstc_exca_mtt__aut_cgnt_vh_no_eqal_yn(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__aut_cgnt_vh_no_eqal_yn")));
				jmvo1.setTrv_dstc_exca_mtt__aut_cgnt_trv_dstc_eqal_yn(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__aut_cgnt_trv_dstc_eqal_yn")));
				jmvo1.setTrv_dstc_exca_mtt__rnw_plno(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__rnw_plno")));
				jmvo1.setTrv_dstc_exca_mtt__hdlr_empno("80000176");
				jmvo1.setTrv_dstc_exca_mtt__aut_cgnt_trv_dstc_rsl_cd(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__aut_cgnt_trv_dstc_rsl_cd")));
				jmvo1.setTrv_dstc_exca_mtt__plhd_cust_nm(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__plhd_cust_nm")));
				jmvo1.setTrv_dstc_exca_mtt__pdc_sr_dvn(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__pdc_sr_dvn")));
				jmvo1.setTrv_dstc_exca_mtt__scrn_proc_cd(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__scrn_proc_cd")));
				jmvo1.setTrv_dstc_exca_mtt__arc_trm_str_dt(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__arc_trm_str_dt")));
				jmvo1.setZ_resp_cd(StringUtil.nvl(request.getParameter("z_resp_cd")));
			}
			else {
				jmvo1.setTrv_dstc_exca_mtt__exca_bz_proc_dvn("2");
				jmvo1.setTrv_dstc_exca_mtt__plno(request.getParameter("plno"));
				jmvo1.setTrv_dstc_exca_mtt__plan_no(request.getParameter("exp_exca_plan_no"));
				jmvo1.setTrv_dstc_exca_mtt__exca_rtrn_dvn("3".equals(gubun) ? "1" : "2");
				jmvo1.setTrv_dstc_exca_mtt__pdc_sr_dvn(request.getParameter("pdc_sr_dvn"));
				jmvo1.setTrv_dstc_exca_mtt__scrn_proc_cd(request.getParameter("exp_exca_plan_rsl_cd"));
				
				if("3".equals(gubun)) {
					String account = "";
					try {
						account = TransKey.decode("account", request);
					}
					catch(Exception e) {
						logger.debug(e.getMessage());
						account = request.getParameter("account");
					}
					logger.debug("account: " + account);
					jmvo1.setTrv_dstc_exca_mtt__bank_cd(request.getParameter("bank"));
					jmvo1.setTrv_dstc_exca_mtt__acc_no(account);
				}
				jmvo1.setTrv_dstc_exca_mtt__adc_rtrn_dvn(request.getParameter("adc_rtrn_dvn"));
				jmvo1.setTrv_dstc_exca_mtt__adc_rtrn_prm(request.getParameter("adc_rtrn_prm"));
				jmvo1.setTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn(jmvo.getTrv_dstc_splc_exca_yn());
				jmvo1.setTrv_dstc_exca_mtt__pbox_no(jmvo.getSms_ts_bvan());
				jmvo1.setTrv_dstc_exca_mtt__hdlr_empno("80000176");
				jmvo1 = carRiderMileageService.chatMMTI0291VO(jmvo1);
			}
			
			// 부적정/중복 이미지인 경우 화면처리코드 02 
			if("1".equals(jmvo1.getTrv_dstc_exca_mtt__imag_dup_yn())){
				jmvo1.setTrv_dstc_exca_mtt__scrn_proc_cd("02");
			}
			
			// CM 상품이고, 화면처리코드 IN(02, 14) or 이미지 중복
			
			if("CM".equals(jmvo1.getTrv_dstc_exca_mtt__pdc_sr_dvn()) && 
					("02".equals(jmvo1.getTrv_dstc_exca_mtt__scrn_proc_cd())
					|| "14".equals(jmvo1.getTrv_dstc_exca_mtt__scrn_proc_cd()))){
				
				MMTI0015VO mmti0015vo = new MMTI0015VO();
				mmti0015vo.setFunt_key("00");
				mmti0015vo.setPlan_no(jmvo1.trv_dstc_exca_mtt__plan_no);
				mmti0015vo = carRiderMileageService.getMMTI0015VO(mmti0015vo);
				
				logger.debug("##### MMTI0015 시작 ##########################");
				logger.debug("##### 고객식별번호: " + mmti0015vo.getPlhd__cust_dcmt_no() + " ##########################");
				logger.debug("##### 고객번호: " + mmti0015vo.getPlhd__cust_no() + " ##########################");
				logger.debug("##### 고객명: " + mmti0015vo.getPlhd__cust_nm() + " ##########################");
				logger.debug("##### 이메일: " + mmti0015vo.getPlhd__eml() + " ##########################");
				logger.debug("##### 지역번호: " + mmti0015vo.getPlhd_cntp_if__tlp_arno() + " ##########################");
				logger.debug("##### 국번호: " + mmti0015vo.getPlhd_cntp_if__tlp_ofno() + " ##########################");
				logger.debug("##### 개별번호: " + mmti0015vo.getPlhd_cntp_if__tlp_idvno() + " ##########################");
				
				XTEM0021VO xtem0021vo = new XTEM0021VO();
				xtem0021vo.setCnsl_rpt_no("");						// 상담접수번호				
				xtem0021vo.setCm_bz_dvcd("05");
				xtem0021vo.setCnsl_typ_dvcd("07");
				xtem0021vo.setCm_plan_no(jmvo1.getTrv_dstc_exca_mtt__plan_no());
				xtem0021vo.setCnsl_rpy_dvcd("1");
				xtem0021vo.setCnsl_rpt_dttm(getDayTime());			// 현재년월일시분초 14자리
				xtem0021vo.setCust_nm(mmti0015vo.getPlhd__cust_nm());
				xtem0021vo.setCust_no(mmti0015vo.getPlhd__cust_no());
				
				String cust_dcmt_no = SeedUtil.decrypt(mmti0015vo.getPlhd__cust_dcmt_no());
				
				if("1".equals(cust_dcmt_no.substring(6, 7)) || "2".equals(cust_dcmt_no.substring(6, 7))
					|| "5".equals(cust_dcmt_no.substring(6, 7)) || "6".equals(cust_dcmt_no.substring(6, 7))){
					xtem0021vo.setBrth("19" + cust_dcmt_no.substring(0, 6));
				} else{
					xtem0021vo.setBrth("20" + cust_dcmt_no.substring(0, 6));
				}
				// xtem0021vo.setBrth("");  							// 생년월일
				xtem0021vo.setSx_cd(cust_dcmt_no.substring(6, 7));
				xtem0021vo.setEml_adr(mmti0015vo.getPlhd__eml());
				xtem0021vo.setClp_tlcno(mmti0015vo.getPlhd_cntp_if__tlp_arno());
				xtem0021vo.setClp_ofno(mmti0015vo.getPlhd_cntp_if__tlp_ofno());
				xtem0021vo.setClp_idvno(mmti0015vo.getPlhd_cntp_if__tlp_idvno());
				xtem0021vo.setCnsl_rsvt_dt("99990101");
				xtem0021vo.setCnsl_rsvt_time_cd("1");
				xtem0021vo.setCnsl_cn("최종주행거리사진등록/만기정산");
				xtem0021vo.setCnsl_aply_csn_yn("1");
				xtem0021vo.setUrl_adr("");
				xtem0021vo.setCm_ctrmf_tpcd("32");
				xtem0021vo.setFrst_ipmn_empno("80000028");
				xtem0021vo.setFrst_ipnpt_dttm(getDayTime());		// 현재년월일시분초 14자리	
				
				xtem0021vo = carRiderMileageService.getXTEM0021VO(xtem0021vo);
				logger.debug("##### XTEM0021 시작 ##########################");
				logger.debug("##### 처리결과: [ " + xtem0021vo.getProc_rtn() + " ] ##########################");
			}
			request.setAttribute("jmvo1", jmvo1);
		}
		
		return "/counter/carrider/mobileweb/chat_ml4";
	}

	@RequestMapping(value="/chat_ml5")
	public String chat_ml5(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		HttpSession session = request.getSession();
		
		String ch_dvn = StringUtil.nvl(request.getParameter("ch_dvn"));
		
		String empno = StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__hdlr_empno"));
		empno = "80000176";
		
		MMTI0294VO jmvo = new MMTI0294VO();
		jmvo.setTrv_dstc_exca_mtt__plno(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__plno")));
		jmvo.setTrv_dstc_exca_mtt__plan_no(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__plan_no")));
		jmvo.setTrv_dstc_exca_mtt__plan_dt(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__plan_dt")));
		jmvo.setTrv_dstc_exca_mtt__rnw_plno(StringUtil.nvl(request.getParameter("trv_dstc_exca_mtt__rnw_plno")));
		jmvo.setTrv_dstc_exca_mtt__hdlr_empno(empno);
		// jmvo.trv_dstc_exca_mtt__hdlr_empno = "80000176";
		
		jmvo = carRiderMileageService.chatMMTI0294VO(jmvo);
		
		if("ZH001".equals(jmvo.getZ_resp_cd()) && session.getAttribute("imgfile") != null && session.getAttribute("exifDate") != null && !StringUtil.isEmpty(empno)) {
			Object[] imgfile = (Object[]) session.getAttribute("imgfile");
			String exifDate = (String) session.getAttribute("exifDate");

			carRiderMileageService.regInfoToEdmsForMobileWeb3(empno, imgfile[0], exifDate, jmvo.getTrv_dstc_exca_mtt__rnw_plno() + "," + jmvo.getTrv_dstc_exca_mtt__rnw_plan_no());
		}
		
		request.setAttribute("jmvo", jmvo);
		request.setAttribute("ch_dvn", ch_dvn);
		
		return "/counter/carrider/mobileweb/chat_ml5";
	}
	
	@RequestMapping(value="/chatMlFileUpload")
	public @ResponseBody Map<String, String> chatMlFileUpload(MultipartHttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		Map<String, String> map = new HashMap<String, String>();
		String yyyymmdd = DateUtil.getDate("yyyymmdd");
		// String ch_dvn = request.getParameter("ch_dvn");
		
		MMTI0213VO jmvo = new MMTI0213VO();
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("p")));
		jmvo = carRiderMileageService.chatMMTI0213VO(jmvo);
		
		String exifDate1 = StringUtil.nvl(request.getParameter("exifDate1"));
		
		// 사진실제촬영일자
		String phgp_rl_ptgr_dt = StringUtil.nvl(request.getParameter("phgp_rl_ptgr_dt"));
		// 사진첨부방식코드
		String phgp_apdx_way_cd = StringUtil.nvl(request.getParameter("phgp_apdx_way_cd"));
		
		String phgp_ptgr_dt = "";
		
		boolean empty = false;
		if(exifDate1.indexOf(",gallery") > -1) {
			exifDate1 = exifDate1.substring(0, exifDate1.indexOf(",gallery"));
			if(StringUtil.isEmpty(exifDate1)) {
				exifDate1 = DateUtil.getDate();
				empty = true;
			}
			else if(Integer.parseInt(exifDate1) > Integer.parseInt(DateUtil.getDate())) {
				map.put("errorCode", "f");
				return map;
			}
		}

		phgp_ptgr_dt = empty ? "" : exifDate1;
		
		if(exifDate1.indexOf(",gallery") > -1) {
			exifDate1 = exifDate1.substring(0, exifDate1.indexOf(",gallery"));
		}

		if("08".equals(jmvo.getProc_dvn()) || "09".equals(jmvo.getProc_dvn())) {
			ArrayList<File> files = carRiderMileageService.uploadToWAS(request, jmvo.getSms_ts_bvan());
			
			String aut_cgnt_trv_dstc_rsl_cd = "";	// 자동인식주행거리결과코드
			String aut_cgnt_vh_no_rsl_cd = "";		// 자동인식차량번호결과코드
			String aut_cgnt_trv_dstc = "";			// 자동인식주행거리
			String aut_cgnt_vh_no = "";				// 자동인식차량번호
			
			String aut_cgnt_trv_dstc_1 = "";		// 자동인식주행거리1
			String aut_cgnt_trv_dstc_2 = "";		// 자동인식주행거리2
			String aut_cgnt_trv_dstc_3 = "";		// 자동인식주행거리3
			
			boolean flag1 = false;
			if(files.size() > 0) {
				FTPUtil ftp = null;
				// [200617] 취약점 수정
				FileInputStream in = null;
				FileOutputStream out = null;
				FileInputStream fis = null;
				try {
					if("1".equals(jmvo.getAut_cgnt_nn_apcn_yn())) { // OCR서버 문제있으면...
						aut_cgnt_trv_dstc_rsl_cd = "03";
						aut_cgnt_vh_no_rsl_cd = "03";
					}
					else {
						String propsPath = this.getClass().getResource("").getPath();
						propsPath = propsPath.substring(0, propsPath.indexOf("/classes/")) + "/config/ocr_ftp.properties";
						Properties p = new Properties();
						// [200617] 취약점 수정
						in = new FileInputStream(propsPath);
						p.load(in);
						in.close();
						// [200617] 취약점 수정
						in = null;
						
						String password = p.getProperty("password");
						String decPassword = aes256Decrypt(password);
						if(password.equals(decPassword) || StringUtil.isEmpty(decPassword)) {
							decPassword = password;
							String encPassword = aes256Encrypt(password);
							logger.debug("encPassword: " + encPassword);
							// [200617] 취약점 수정
							out = new FileOutputStream(propsPath);
							p.setProperty("password", encPassword);
							p.store(out, "");
							out.close();
							// [200617] 취약점 수정
							out = null;
						}
						
						ftp = new FTPUtil(p.getProperty("ip"), p.getProperty("user"), decPassword, Integer.parseInt(p.getProperty("port")));
						
						int working = 0;
						for(int i = 1; i <= 3; i++) {
							String[] ls = ftp.ls("/RECOG_JOB" + i + "/" + yyyymmdd);
							for(int j = 0; j < ls.length; j++) {
								if(".".equals(ls[j]) || "..".equals(ls[j])) continue;
								working++;
							}
						}
		
						if(working <= 6) {
							String filename1 = "";
							
							filename1 = ftp.uploadToOCR("/RECOG/" + yyyymmdd, files.get(0), "--D");

							logger.debug("filename1: " + filename1);

							
							logger.debug("--- 1초 대기 ---");
							Thread.sleep(1000);
							int retryNum = 7;
							for(int retry = 0; retry < retryNum; retry++) {
								String[] ls = ftp.ls("/RECOG_RESULT/" + yyyymmdd);
			
								for(int i = 0; i < ls.length; i++) {
									logger.debug(ls[i]);
									if(!flag1 && ls[i].equals(filename1)) {
										flag1 = true;
									}
									
									if(flag1) break;
								}
			
								if((flag1) || retry == retryNum - 1) {
									break;
								}
								else {
									logger.debug("--- 0.6초 대기 ---");
									Thread.sleep(600);
								}
							}
							
							logger.debug("flag1: " + flag1);
							
							if(flag1) {
								// [200617] 취약점 수정
								// filename1 = filename1.replaceAll("/", "");
								// filename1 = filename1.replaceAll("&", "");
								// filename1 = filename1.replaceAll("\\", "");
								
								String path = files.get(0).getParent() + File.separator + filename1;
								ftp.downloadFromOCR("/RECOG_RESULT/" + yyyymmdd, filename1, path);
								logger.debug(path);
								File f = new File(path);
								// logger.info("7777 filename1:" + filename1);
								// logger.info("7777 path:" + path);
								
								if(f.exists()) {
									Properties props = new Properties(); 
									// [200617] 취약점 수정
									fis = new FileInputStream(path);
									props.load(fis);
									fis.close();
									// [200617] 취약점 수정
									fis = null;
									
									if(!StringUtil.isEmpty(props.getProperty("ODO")) && !StringUtil.isEmpty(props.getProperty("RE_CODE"))) {
										aut_cgnt_trv_dstc = props.getProperty("ODO");
										aut_cgnt_trv_dstc_rsl_cd = "1".equals(props.getProperty("RE_CODE")) || "2".equals(props.getProperty("RE_CODE")) ? "01" : "02";
										
										aut_cgnt_trv_dstc_1 = props.getProperty("ODO");
										
										if(!StringUtil.isEmpty(props.getProperty("ODO2"))) {
											aut_cgnt_trv_dstc_2 = props.getProperty("ODO2");
										}
										
										if(!StringUtil.isEmpty(props.getProperty("ODO3"))) {
											aut_cgnt_trv_dstc_3 = props.getProperty("ODO3");
										}
									}
									
					            	if(f.delete()) {
										logger.debug("삭제: " + path);
									}
								}
							}
							else {
								aut_cgnt_trv_dstc_rsl_cd = "02";
							}						
						}
						else {
							aut_cgnt_trv_dstc_rsl_cd = "02";
							if(!"1".equals(jmvo.getCm_yn())) {
								aut_cgnt_vh_no_rsl_cd = "02";
							}
						}
					}
				}
				catch(Exception e) {
					System.err.println("[CarriderMileageController.mlFileUpload()] Exception");
					logger.debug(e.getMessage());
					aut_cgnt_trv_dstc_rsl_cd = "02";
					if(!"1".equals(jmvo.getCm_yn())) {
						aut_cgnt_vh_no_rsl_cd = "02";
					}
				}
				finally {
					if(ftp != null) ftp.disconnect();
					// [200617] 취약점 수정
					try{
			    	  	if(in != null){
			    	  		in.close();
			    	  	}
				      }catch(IOException ee){
				    	  System.err.println("[CarriderMileageController.mlFileUpload()] IOException 1 발생");
				      }
					try{
			    	  	if(out != null){
			    	  		out.close();
			    	  	}
				      }catch(IOException ee){
				    	  System.err.println("[CarriderMileageController.mlFileUpload()] IOException 2 발생");
				      }
					try{
			    	  	if(fis != null){
			    	  		fis.close();
			    	  	}
				      }catch(IOException ee){
				    	  System.err.println("[CarriderMileageController.mlFileUpload()] IOException 3 발생");
				      }
				}
			}
			
			MMTI0259VO jmvo1 = new MMTI0259VO();
			jmvo1.setPbox_use_yn("1");
			jmvo1.setPbox_no(jmvo.getSms_ts_bvan());
			jmvo1.setPhgp_cnfm_dt(DateUtil.getDate());
			jmvo1.setPhgp_ptgr_dt(phgp_ptgr_dt);
			jmvo1.setPhgp_strg_yn("1");
			if("1".equals(jmvo.getAut_cgnt_nn_apcn_yn())) {
				jmvo1.setPbox_chr_nm(request.getParameter("mileage1"));
			}
			
			if("1".equals(jmvo.getPbox_no_dvcd())) {
				if(!"1".equals(jmvo.getCm_yn())) {
					jmvo1.setInpt_trv_dstc(request.getParameter("mileage1"));
					if(!StringUtil.isEmpty(aut_cgnt_vh_no)) {
						jmvo1.setAut_cgnt_vh_no(aut_cgnt_vh_no);
					}
					
					if(!StringUtil.isEmpty(aut_cgnt_vh_no_rsl_cd)) {
						jmvo1.setAut_cgnt_vh_no_rsl_cd(aut_cgnt_vh_no_rsl_cd);
					}
					else {
						jmvo1.setAut_cgnt_vh_no_rsl_cd("02");
					}
				}
					
				if(!StringUtil.isEmpty(aut_cgnt_trv_dstc)) {
					jmvo1.setAut_cgnt_trv_dstc(aut_cgnt_trv_dstc);
				}
				
				if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_rsl_cd)) {
					jmvo1.setAut_cgnt_trv_dstc_rsl_cd(aut_cgnt_trv_dstc_rsl_cd);
				}
				else {
					jmvo1.setAut_cgnt_trv_dstc_rsl_cd("02");
				}
				
				if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_1)) {
					jmvo1.setAut_cgnt_trv_dstc_1(aut_cgnt_trv_dstc_1);
				}
				
				if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_2)) {
					jmvo1.setAut_cgnt_trv_dstc_2(aut_cgnt_trv_dstc_2);
				}
				
				if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_3)) {
					jmvo1.setAut_cgnt_trv_dstc_3(aut_cgnt_trv_dstc_3);
				}
			}
			
			// 200708
			jmvo1.setPhgp_rl_ptgr_dt(phgp_rl_ptgr_dt);
			jmvo1.setPhgp_apdx_way_cd(phgp_apdx_way_cd);
			
			jmvo1 = carRiderMileageService.chatMMTI0259VO(jmvo1);
			
			if("0".equals(jmvo1.getErrorCode()) && !"1".equals(jmvo.getCm_yn())) {
				jmvo1.setExp_exca_plan_proc_dvn("1");
				jmvo1.setPlno(jmvo.getPlno());
				
				// 200708
				jmvo1.setPhgp_rl_ptgr_dt(phgp_rl_ptgr_dt);
				jmvo1.setPhgp_apdx_way_cd(phgp_apdx_way_cd);
				
				jmvo1 = carRiderMileageService.chatMMTI0259VO(jmvo1);
				
				if("05".equals(jmvo1.getExp_exca_plan_rsl_cd())) {
					carRiderMileageService.regInfoToEdmsForMobileWeb(request, jmvo.getSms_ts_bvan());
				}
				else if(!StringUtil.isEmpty(jmvo1.getPlno()) && !StringUtil.isEmpty(jmvo1.getExp_exca_plan_no())) {
					carRiderMileageService.regInfoToEdmsForMobileWeb2(request, jmvo.getNtft_srv_rc_ormm_cd(), files, jmvo1.getPlno() + "," + jmvo1.getExp_exca_plan_no());
				}
				else {
					carRiderMileageService.regInfoToEdmsForMobileWeb2(request, jmvo.getNtft_srv_rc_ormm_cd(), files, jmvo1.getPlno());
				}
			}
			else {
				if("1".equals(jmvo.getCm_yn())) {
					carRiderMileageService.regInfoToEdmsForMobileWeb(request, jmvo.getSms_ts_bvan());
				}
				else {
					carRiderMileageService.regInfoToEdmsForMobileWeb2(request, jmvo.getNtft_srv_rc_ormm_cd(), files, jmvo1.getPlno());
				}
			}
	
			for(int i = 0; i < files.size(); i++) {
				File f = files.get(i);
				String fname = f.getName();
				f.delete();
				logger.debug(fname + " 삭제");
			}
			
			map.put("errorCode",				jmvo1.getErrorCode());
			map.put("exp_exca_plan_rsl_cd",		jmvo1.getExp_exca_plan_rsl_cd());
			map.put("adc_rtrn_dvn",				jmvo1.getAdc_rtrn_dvn());
			map.put("adc_rtrn_prm",				jmvo1.getAdc_rtrn_prm());
			map.put("plno",						jmvo1.getPlno());
			map.put("exp_exca_plan_no",			jmvo1.getExp_exca_plan_no());
			map.put("exp_exca_plan_bse_dd",		jmvo1.getExp_exca_plan_bse_dd());
			map.put("aut_cgnt_vh_no",			jmvo1.getAut_cgnt_vh_no());
			map.put("aut_cgnt_vh_no_rsl_cd",	jmvo1.getAut_cgnt_vh_no_rsl_cd());
			map.put("aut_cgnt_trv_dstc",		jmvo1.getAut_cgnt_trv_dstc());
			map.put("aut_cgnt_trv_dstc_rsl_cd",	jmvo1.getAut_cgnt_trv_dstc_rsl_cd());
			map.put("exp_exca_plan_proc_dvn",	jmvo1.getExp_exca_plan_proc_dvn());
			map.put("cnv_trv_dstc",				jmvo1.getCnv_trv_dstc());
			
			// 200708
			map.put("phgp_rl_ptgr_dt",			phgp_rl_ptgr_dt);
			map.put("phgp_apdx_way_cd", 		phgp_apdx_way_cd);
			
		}
		else {
			carRiderMileageService.regInfoToEdmsForMobileWeb(request, jmvo.getSms_ts_bvan());
			
			MMTI0259VO jmvo1 = new MMTI0259VO();
			jmvo1.setPbox_use_yn("1");
			jmvo1.setPbox_no(jmvo.getSms_ts_bvan());
			jmvo1.setPhgp_cnfm_dt(DateUtil.getDate());
			jmvo1.setPhgp_ptgr_dt(phgp_ptgr_dt);
			jmvo1.setPhgp_strg_yn("1");
			
			// 200708
			jmvo1.setPhgp_rl_ptgr_dt(phgp_rl_ptgr_dt);
			jmvo1.setPhgp_apdx_way_cd(phgp_apdx_way_cd);
			
			if("1".equals(jmvo.getPbox_no_dvcd()) && !"1".equals(jmvo.getCm_yn())) {
				if("03".equals(jmvo.getProc_dvn())) {
					jmvo1.setPbox_chr_nm(request.getParameter("mileage1") + "/" + request.getParameter("mileage2"));
				}
				else {
					jmvo1.setPbox_chr_nm(request.getParameter("mileage1"));
				}
			}
			jmvo1 = carRiderMileageService.chatMMTI0259VO(jmvo1);
			
			map.put("errorCode", jmvo1.getErrorCode());
		}
			
		return map;
	}
	
	@RequestMapping(value="/chatMlFileUploadOCR")
	public @ResponseBody Map<String, String> chatMlFileUploadOCR(MultipartHttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		Map<String, String> map = new HashMap<String, String>();
		String yyyymmdd = DateUtil.getDate("yyyymmdd");
		
		String phgp_rl_ptgr_dt	= StringUtil.nvl(request.getParameter("phgp_rl_ptgr_dt"));	// 사진실제촬영일자
		String phgp_apdx_way_cd	= StringUtil.nvl(request.getParameter("phgp_apdx_way_cd"));	// 사진첨부방식코드
		
		String ch_dvn = StringUtil.nvl(request.getParameter("ch_dvn"));
		
		MMTI0213VO jmvo = new MMTI0213VO();
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("p")));
		jmvo = carRiderMileageService.chatMMTI0213VO(jmvo);
		
		String exifDate1 = StringUtil.nvl(request.getParameter("exifDate1"));
		
		if(exifDate1.indexOf(",gallery") > -1) {
			exifDate1 = exifDate1.substring(0, exifDate1.indexOf(",gallery"));
			if(StringUtil.isEmpty(exifDate1)) {
				exifDate1 = DateUtil.getDate();
			}
			else if(Integer.parseInt(exifDate1) > Integer.parseInt(DateUtil.getDate())) {
				map.put("errorCode", "f");
				return map;
			}
		}

		if(exifDate1.indexOf(",gallery") > -1) {
			exifDate1 = exifDate1.substring(0, exifDate1.indexOf(",gallery"));
		}

		ArrayList<File> files = carRiderMileageService.uploadToWAS(request, jmvo.getSms_ts_bvan());
		
		String aut_cgnt_trv_dstc_rsl_cd = "";	// 자동인식주행거리결과코드
		String aut_cgnt_vh_no_rsl_cd = "";		// 자동인식차량번호결과코드
		String aut_cgnt_trv_dstc = "";			// 자동인식주행거리
		String aut_cgnt_vh_no = "";				// 자동인식차량번호
		
		String aut_cgnt_trv_dstc_1 = "";		// 자동인식주행거리1
		String aut_cgnt_trv_dstc_2 = "";		// 자동인식주행거리2
		String aut_cgnt_trv_dstc_3 = "";		// 자동인식주행거리3
		
		
		boolean flag1 = false;
		if(files.size() > 0) {
			FTPUtil ftp = null;
			// [200617] 취약점 수정
			FileInputStream in = null;
			FileOutputStream out = null;
			FileInputStream fis = null;
			
			try {
				if("1".equals(jmvo.getAut_cgnt_nn_apcn_yn())) { // OCR서버 문제있으면...
					aut_cgnt_trv_dstc_rsl_cd = "03";
					aut_cgnt_vh_no_rsl_cd = "03";
				}
				else {
					String propsPath = this.getClass().getResource("").getPath();
					propsPath = propsPath.substring(0, propsPath.indexOf("/classes/")) + "/config/ocr_ftp.properties";
					Properties p = new Properties();
					// [200617] 취약점 수정
					in = new FileInputStream(propsPath);
					p.load(in);
					in.close();
					// [200617] 취약점 수정
					in = null;
					String password = p.getProperty("password");
					String decPassword = aes256Decrypt(password);
					if(password.equals(decPassword) || StringUtil.isEmpty(decPassword)) {
						decPassword = password;
						String encPassword = aes256Encrypt(password);
						logger.debug("encPassword: " + encPassword);
						// [200617] 취약점 수정
						out = new FileOutputStream(propsPath);
						p.setProperty("password", encPassword);
						p.store(out, "");
						out.close();
						// [200617] 취약점 수정
						out = null;
					}
					
					ftp = new FTPUtil(p.getProperty("ip"), p.getProperty("user"), decPassword, Integer.parseInt(p.getProperty("port")));
					
					int working = 0;
					for(int i = 1; i <= 3; i++) {
						String[] ls = ftp.ls("/RECOG_JOB" + i + "/" + yyyymmdd);
						for(int j = 0; j < ls.length; j++) {
							if(".".equals(ls[j]) || "..".equals(ls[j])) continue;
							working++;
						}
					}
	
					if(working <= 6) {
						String filename1 = "";
						
						filename1 = ftp.uploadToOCR("/RECOG/" + yyyymmdd, files.get(0), "--D");

						logger.debug("filename1: " + filename1);

						
						logger.debug("--- 1초 대기 ---");
						Thread.sleep(1000);
						int retryNum = 7;
						for(int retry = 0; retry < retryNum; retry++) {
							String[] ls = ftp.ls("/RECOG_RESULT/" + yyyymmdd);
		
							for(int i = 0; i < ls.length; i++) {
								logger.debug(i+"번째");
								logger.debug(ls[i]);
								if(!flag1 && ls[i].equals(filename1)) {
									flag1 = true;
								}
								
								if(flag1) break;
							}
		
							if((flag1) || retry == retryNum - 1) {
								break;
							}
							else {
								logger.debug("--- 0.6초 대기 ---");
								Thread.sleep(600);
							}
						}
						
						logger.debug("flag1: " + flag1);
						
						if(flag1) {
							// [200617] 취약점 수정
							// filename1 = filename1.replaceAll("/", "");
							// filename1 = filename1.replaceAll("&", "");
							// filename1 = filename1.replaceAll("\\", "");
							String path = files.get(0).getParent() + File.separator + filename1;
							ftp.downloadFromOCR("/RECOG_RESULT/" + yyyymmdd, filename1, path);
							logger.debug(path);
							File f = new File(path);
							logger.info("7777 filename1:" + filename1);
							logger.info("7777 path:" + path);
		
							if(f.exists()) {
								Properties props = new Properties();
								// [200617] 취약점 수정
								fis = new FileInputStream(path);
								props.load(fis);
								fis.close();
								// [200617] 취약점 수정
								fis = null;
								
								if(!StringUtil.isEmpty(props.getProperty("ODO")) && !StringUtil.isEmpty(props.getProperty("RE_CODE"))) {
									aut_cgnt_trv_dstc = props.getProperty("ODO");
									aut_cgnt_trv_dstc_rsl_cd = "1".equals(props.getProperty("RE_CODE")) || "2".equals(props.getProperty("RE_CODE")) ? "01" : "02";
									
									aut_cgnt_trv_dstc_1 = props.getProperty("ODO");
									
									if(!StringUtil.isEmpty(props.getProperty("ODO2"))) {
										aut_cgnt_trv_dstc_2 = props.getProperty("ODO2");
									}
									
									if(!StringUtil.isEmpty(props.getProperty("ODO3"))) {
										aut_cgnt_trv_dstc_3 = props.getProperty("ODO3");
									}
								}
								
				            	if(f.delete()) {
									logger.debug("삭제: " + path);
								}
							}
						}
						else {
							aut_cgnt_trv_dstc_rsl_cd = "02";
						}						
					}
					else {
						aut_cgnt_trv_dstc_rsl_cd = "02";
						if(!"1".equals(jmvo.getCm_yn())) {
							aut_cgnt_vh_no_rsl_cd = "02";
						}
					}
				}
			}
			catch(Exception e) {
				logger.debug(e.getMessage());
				aut_cgnt_trv_dstc_rsl_cd = "02";
				if(!"1".equals(jmvo.getCm_yn())) {
					aut_cgnt_vh_no_rsl_cd = "02";
				}
			}
			finally {
				if(ftp != null) ftp.disconnect();
				// [200617] 취약점 수정
				try{
		    	  	if(in != null){
		    	  		in.close();
		    	  	}
			      }catch(IOException ee){
			    	  System.err.println("[CarriderMileageController.chatMlFileUploadOCR()] IOException 1 발생");
			      }
				try{
		    	  	if(out != null){
		    	  		out.close();
		    	  	}
			      }catch(IOException ee){
			    	  System.err.println("[CarriderMileageController.chatMlFileUploadOCR()] IOException 2 발생");
			      }
				try{
		    	  	if(fis != null){
		    	  		fis.close();
		    	  	}
			      }catch(IOException ee){
			    	  System.err.println("[CarriderMileageController.chatMlFileUploadOCR()] IOException 3 발생");
			      }
			}
		}
		
		HttpSession session = request.getSession();
		Object[] imgfile = new Object[files.size()];
		// [200617] 취약점 수정
		FileInputStream fis = null;
		try {
			for(int i = 0; i < files.size(); i++) {
				File f = files.get(i);
				// [200617] 취약점 수정
				fis = new FileInputStream(f);
				byte[] file = new byte[(int) f.length()];
				fis.read(file);
				imgfile[i] = file;
				fis.close();
				// [200617] 취약점 수정
				fis = null;
				String fname = f.getName();
				f.delete();
				logger.debug(fname + " 삭제");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();
			System.err.println("[CarriderMileageController.chatMlFileUploadOCR()] Exception 발생");
		}
		// [200617] 취약점 수정
		finally {
			try{
				if(fis!=null){
					fis.close();
				}
			}
			catch(IOException ee){
				System.err.println("[CarriderMileageController.chatMlFileUploadOCR()] IOException 4 발생");
		    	// ee.getMessage();
		    }
		}
		session.setAttribute("imgfile", imgfile);
		
		map.put("errorCode",					"0");
		map.put("aut_cgnt_trv_dstc_rsl_cd",		aut_cgnt_trv_dstc_rsl_cd);
		map.put("aut_cgnt_vh_no_rsl_cd",		aut_cgnt_vh_no_rsl_cd);
		map.put("aut_cgnt_trv_dstc",			aut_cgnt_trv_dstc);
		map.put("aut_cgnt_vh_no",				aut_cgnt_vh_no);
		
		map.put("aut_cgnt_trv_dstc_1",			aut_cgnt_trv_dstc_1);
		map.put("aut_cgnt_trv_dstc_2",			aut_cgnt_trv_dstc_2);
		map.put("aut_cgnt_trv_dstc_3",			aut_cgnt_trv_dstc_3);
		
		map.put("phgp_rl_ptgr_dt",				phgp_rl_ptgr_dt);
		map.put("phgp_apdx_way_cd",				phgp_apdx_way_cd);
		
		map.put("ch_dvn",						ch_dvn);
			
		return map;
	}
	
	

	
	@RequestMapping(value="/chatMlFileUploadOCR2")
	public @ResponseBody Map<String, String> chatMlFileUploadOCR2(MultipartHttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		Map<String, String> map = new HashMap<String, String>();

		String aut_cgnt_trv_dstc_rsl_cd	= StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc_rsl_cd"));	// 자동인식주행거리결과코드
		String aut_cgnt_vh_no_rsl_cd	= StringUtil.nvl(request.getParameter("aut_cgnt_vh_no_rsl_cd"));	// 자동인식차량번호결과코드
		String aut_cgnt_trv_dstc		= StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc"));		// 자동인식주행거리
		String aut_cgnt_vh_no			= StringUtil.nvl(request.getParameter("aut_cgnt_vh_no"));			// 자동인식차량번호
		
		String aut_cgnt_trv_dstc_1		= StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc_1"));		// 자동인식주행거리
		String aut_cgnt_trv_dstc_2		= StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc_2"));		// 자동인식주행거리
		String aut_cgnt_trv_dstc_3		= StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc_3"));		// 자동인식주행거리
		
		String phgp_rl_ptgr_dt			= StringUtil.nvl(request.getParameter("phgp_rl_ptgr_dt"));			// 사진실제촬영일자
		String phgp_apdx_way_cd			= StringUtil.nvl(request.getParameter("phgp_apdx_way_cd"));			// 사진첨부방식코드
		
		String ch_dvn = StringUtil.nvl(request.getParameter("ch_dvn"));
		
		MMTI0213VO jmvo = new MMTI0213VO();
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("p")));
		jmvo = carRiderMileageService.chatMMTI0213VO(jmvo);
		
		String exifDate1 = StringUtil.nvl(request.getParameter("exifDate1"));
		String phgp_ptgr_dt = "";
		
		boolean empty = false;
		if(exifDate1.indexOf(",gallery") > -1) {
			exifDate1 = exifDate1.substring(0, exifDate1.indexOf(",gallery"));
			if(StringUtil.isEmpty(exifDate1)) {
				exifDate1 = DateUtil.getDate();
				empty = true;
			}
			else if(Integer.parseInt(exifDate1) > Integer.parseInt(DateUtil.getDate())) {
				map.put("errorCode", "f");
				return map;
			}
		}

		phgp_ptgr_dt = empty ? "" : exifDate1;
		
		if(exifDate1.indexOf(",gallery") > -1) {
			exifDate1 = exifDate1.substring(0, exifDate1.indexOf(",gallery"));
		}
		
		HttpSession session = request.getSession();
		session.setAttribute("exifDate", exifDate1);

		ArrayList<File> files = carRiderMileageService.uploadToWAS(request, jmvo.getSms_ts_bvan());
		
		MMTI0259VO jmvo1 = new MMTI0259VO();
		jmvo1.setPbox_use_yn("1");
		jmvo1.setPbox_no(jmvo.getSms_ts_bvan());
		jmvo1.setPhgp_cnfm_dt(DateUtil.getDate());
		jmvo1.setPhgp_ptgr_dt(phgp_ptgr_dt);
		jmvo1.setPhgp_strg_yn("1");
		if("1".equals(jmvo.getAut_cgnt_nn_apcn_yn())) {
			jmvo1.setPbox_chr_nm(request.getParameter("mileage1"));
		}
		
		if("1".equals(jmvo.getPbox_no_dvcd())) {
			if(!"1".equals(jmvo.getCm_yn())) {
				jmvo1.setInpt_trv_dstc(request.getParameter("mileage1"));
				if(!StringUtil.isEmpty(aut_cgnt_vh_no)) {
					jmvo1.setAut_cgnt_vh_no(aut_cgnt_vh_no);
				}
				
				if(!StringUtil.isEmpty(aut_cgnt_vh_no_rsl_cd)) {
					jmvo1.setAut_cgnt_vh_no_rsl_cd(aut_cgnt_vh_no_rsl_cd);
				}
				else {
					jmvo1.setAut_cgnt_vh_no_rsl_cd("02");
				}
			}
				
			if(!StringUtil.isEmpty(aut_cgnt_trv_dstc)) {
				jmvo1.setAut_cgnt_trv_dstc(aut_cgnt_trv_dstc);
			}
			
			if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_rsl_cd)) {
				jmvo1.setAut_cgnt_trv_dstc_rsl_cd(aut_cgnt_trv_dstc_rsl_cd);
			}
			else {
				jmvo1.setAut_cgnt_trv_dstc_rsl_cd("02");
			}
			
			if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_1)) {
				jmvo1.setAut_cgnt_trv_dstc_1(aut_cgnt_trv_dstc_1);
			}
			
			if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_2)) {
				jmvo1.setAut_cgnt_trv_dstc_2(aut_cgnt_trv_dstc_2);
			}
			
			if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_3)) {
				jmvo1.setAut_cgnt_trv_dstc_3(aut_cgnt_trv_dstc_3);
			}
		}
		
		// 200708
		jmvo1.setPhgp_rl_ptgr_dt(phgp_rl_ptgr_dt);
		jmvo1.setPhgp_apdx_way_cd(phgp_apdx_way_cd);
		
		jmvo1 = carRiderMileageService.chatMMTI0259VO(jmvo1);
		
		if("0".equals(jmvo1.getErrorCode()) && !"1".equals(jmvo.getCm_yn())) {
			jmvo1.setExp_exca_plan_proc_dvn("1");
			jmvo1.setPlno(jmvo.getPlno());
			
			// 200708
			jmvo1.setPhgp_rl_ptgr_dt(phgp_rl_ptgr_dt);
			jmvo1.setPhgp_apdx_way_cd(phgp_apdx_way_cd);
			
			jmvo1 = carRiderMileageService.chatMMTI0259VO(jmvo1);
			
			if("08".equals(jmvo.getProc_dvn())) {
				carRiderMileageService.regInfoToEdmsForMobileWeb2(request, jmvo.getNtft_srv_rc_ormm_cd(), files, jmvo.getPlno() + "," + jmvo.getChng_plan_no());
			}
			else if(!StringUtil.isEmpty(jmvo1.getPlno()) && !StringUtil.isEmpty(jmvo1.getExp_exca_plan_no())) {
				carRiderMileageService.regInfoToEdmsForMobileWeb2(request, jmvo.getNtft_srv_rc_ormm_cd(), files, jmvo1.getPlno() + "," + jmvo1.getExp_exca_plan_no());
			}
			else if(!StringUtil.isEmpty(jmvo1.getPlno()) && StringUtil.isEmpty(jmvo1.getExp_exca_plan_no())) {
				carRiderMileageService.regInfoToEdmsForMobileWeb2(request, jmvo.getNtft_srv_rc_ormm_cd(), files, jmvo1.getPlno());
			}
		}
		else {
			if("1".equals(jmvo.getCm_yn())) {
				carRiderMileageService.regInfoToEdmsForMobileWeb(request, jmvo.getSms_ts_bvan());
			}
			else {
				carRiderMileageService.regInfoToEdmsForMobileWeb2(request, jmvo.getNtft_srv_rc_ormm_cd(), files, jmvo1.getPlno());
			}
		}

		for(int i = 0; i < files.size(); i++) {
			File f = files.get(i);
			String fname = f.getName();
			f.delete();
			logger.debug(fname + " 삭제");
		}
		
		map.put("errorCode",				jmvo1.getErrorCode());
		map.put("z_resp_msg",				jmvo1.getZ_resp_msg());
		map.put("exp_exca_plan_rsl_cd",		jmvo1.getExp_exca_plan_rsl_cd());
		map.put("adc_rtrn_dvn",				jmvo1.getAdc_rtrn_dvn());
		map.put("adc_rtrn_prm",				jmvo1.getAdc_rtrn_prm());
		map.put("plno",						jmvo1.getPlno());
		map.put("exp_exca_plan_no",			jmvo1.getExp_exca_plan_no());
		map.put("exp_exca_plan_bse_dd",		jmvo1.getExp_exca_plan_bse_dd());
		map.put("aut_cgnt_vh_no",			jmvo1.getAut_cgnt_vh_no());
		map.put("aut_cgnt_vh_no_rsl_cd",	jmvo1.getAut_cgnt_vh_no_rsl_cd());
		map.put("aut_cgnt_trv_dstc",		jmvo1.getAut_cgnt_trv_dstc());
		map.put("aut_cgnt_trv_dstc_rsl_cd",	jmvo1.getAut_cgnt_trv_dstc_rsl_cd());
		map.put("exp_exca_plan_proc_dvn",	jmvo1.getExp_exca_plan_proc_dvn());
		map.put("cnv_trv_dstc",				jmvo1.getCnv_trv_dstc());
		map.put("plhd_cust_nm", 			jmvo1.getPlhd_cust_nm());
		map.put("pdc_sr_dvn", 				jmvo1.getPdc_sr_dvn());
		map.put("ch_dvn",	 				ch_dvn);
			
		return map;
	}
	
	private String getDayTime() throws Exception{
		logger.debug("### getDayTime() 시작 ##########################");
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss", Locale.KOREAN);
		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
			return dateFormat.format(timestamp);
	}
}
