package com.idongbu.smartcustomer.counter.carRider.mileage.service;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.idongbu.common.ESBBizHeader;
import com.idongbu.common.ESBChannelHeader;
import com.idongbu.common.ESBManager;
import com.idongbu.common.XmlUtil;
import com.idongbu.smartcustomer.counter.carRider.common.service.CarRiderFileService;
//import com.idongbu.smartcustomer.counter.carRider.common.service.CarRiderJMService;
import com.idongbu.smartcustomer.vo.FileMeta;
import com.idongbu.smartzone.vo.MMTI0015VO;
import com.idongbu.smartzone.vo.MMTI0213VO;
import com.idongbu.smartzone.vo.MMTI0259VO;
import com.idongbu.smartzone.vo.MMTI0289VO;
import com.idongbu.smartzone.vo.MMTI0291VO;
import com.idongbu.smartzone.vo.MMTI0294VO;
import com.idongbu.smartzone.vo.MMTI0217VO;
import com.idongbu.smartzone.vo.MMTI0218VO;
import com.idongbu.smartzone.vo.MMTI0305VO;
import com.idongbu.smartzone.vo.XIDB0004VO;
import com.idongbu.smartzone.vo.XTEM0021VO;
import com.idongbu.util.StringUtil;

@Service
public class CarRiderMileageService {

	//private final Logger logger = LoggerFactory.getLogger(this.getClass());

	private @Value("${legacy.homepage_jojikwon_cd}") String HOMEPAGE_JOJIKWON_CD;
//	private @Value("${legacy.homepage_jijum_cd}") String HOMEPAGE_JIJUM_CD;
//	private @Value("${legacy.homepage_jibu_cd}") String HOMEPAGE_JIBU_CD;
	private @Value("${carrider.upload.temp.path}") String CARRIDER_UPLOAD_TEMP_PATH;
	private @Value("${esb.Realip}") String ESBURL;
	private @Value("${dm.aes.key}") String dmAesKey;
	private static final String CHAT_EMPNO = "80000176";

	// 전문 서비스 ( 주행거리/블랙박스 )
	//@Autowired(required=true)
	//private CarRiderJMService carRiderJMService;		
 
	@Autowired(required=true)
	private CarRiderFileService carRiderFileService; 	

	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@SuppressWarnings("static-access")
	public MMTI0213VO getMMTI0213VO(MMTI0213VO jmvo) throws Exception {
		String UserId = HOMEPAGE_JOJIKWON_CD;                                                                                                                                                                                           
		String formId = "MMTI0213";                                                                                                                                                                                           
		String telegram = "MMTI"; // esb                                                                                                                                                                                      
		                                                                                                                                                                                                                      
		ESBManager em = new ESBManager();                                                                                                                                                                                     
		ESBChannelHeader channelHead = new ESBChannelHeader();                                                                                                                                                                
		ESBBizHeader bizHead = new ESBBizHeader();     
		
		bizHead = em.makeDefaultBizHeader(UserId);                                                                                                                                                                            
		channelHead = em.makeDefaultChannelHeader(formId, UserId);  
		String Url = ESBURL;
		logger.debug("Url: " + Url);
		String rtnXmlString = (String)XmlUtil.callESBToString(channelHead, bizHead, jmvo, Url, telegram);                                                                                                                   
		                                                                                                                                                                                                                      
		logger.debug("##############################");                                                                                                                                                                       
		logger.debug(rtnXmlString);                                                                                                                                                                                           
		logger.debug("##############################");                                                                                                                                                                       
		                                                                                                                                                                                                                      
		jmvo = (MMTI0213VO) ESBManager.xmlToVOnew(rtnXmlString, (MMTI0213VO)jmvo);                                                                                                                      
		                                                                                                                                                                                                                      
		return jmvo;
	}
	
	@SuppressWarnings("static-access")
	public MMTI0259VO getMMTI0259VO(MMTI0259VO jmvo) throws Exception {
		String UserId = HOMEPAGE_JOJIKWON_CD;                                                                                                                                                                                           
		String formId = "MMTI0259";                                                                                                                                                                                           
		String telegram = "MMTI"; // esb                                                                                                                                                                                      
		                                                                                                                                                                                                                      
		ESBManager em = new ESBManager();                                                                                                                                                                                     
		ESBChannelHeader channelHead = new ESBChannelHeader();                                                                                                                                                                
		ESBBizHeader bizHead = new ESBBizHeader();     
		
		bizHead = em.makeDefaultBizHeader(UserId);                                                                                                                                                                            
		channelHead = em.makeDefaultChannelHeader(formId, UserId);  
		String Url = ESBURL;
		logger.debug("Url: " + Url);
		String rtnXmlString = (String)XmlUtil.callESBToString(channelHead, bizHead, jmvo, Url, telegram);                                                                                                                   
		                                                                                                                                                                                                                      
		logger.debug("##############################");                                                                                                                                                                       
		logger.debug(rtnXmlString);                                                                                                                                                                                           
		logger.debug("##############################");                                                                                                                                                                       
		                                                                                                                                                                                                                      
		jmvo = (MMTI0259VO) ESBManager.xmlToVOnew(rtnXmlString, (MMTI0259VO)jmvo);                                                                                                                      
		                                                                                                                                                                                                                      
		return jmvo;
	}
	
	public void regInfoToEdmsForMobileWeb(MultipartHttpServletRequest request, String sms_ts_bvan) throws Exception {
		boolean result = false;

		// 등록관련정보조회 서블릿을 호출해서 User ID 조회
		Map<String, String> edmsPreRegInfo = carRiderFileService.getEdmsIdForMobileWeb(sms_ts_bvan);
		if(!"1".equals(edmsPreRegInfo.get("RtnCd"))) {
			throw new Exception(edmsPreRegInfo.get("Message"));
		}		

		// 이미지 업로드
		LinkedList<FileMeta> linkedList = carRiderFileService.upload(request, CARRIDER_UPLOAD_TEMP_PATH, sms_ts_bvan);		

		if(linkedList == null || linkedList.size() == 0) {
			throw new Exception("파일 업로드 실패 [ 업로드할 파일이 없거나 이미지파일이 아닙니다. ]");
		}

		for(int i = 0; i < linkedList.size(); i++) {
			FileMeta fileMeta = linkedList.get(i);

			File file = new File(CARRIDER_UPLOAD_TEMP_PATH + fileMeta.getFileName());

			// EDMS로 파일 전송후 해당 파일 삭제						
			result = carRiderFileService.fileSendToEdms(file, edmsPreRegInfo.get("UsrId"), null);
			if(result) {
				logger.debug(CARRIDER_UPLOAD_TEMP_PATH + fileMeta.getFileName() + " 삭제");
			}
			logger.debug("result: " + result);

			if(result) {
				// EDMS에 문서 등록
				String exifDate = "";
				if(i == 0) exifDate = StringUtil.nvl(request.getParameter("exifDate1"));
				else if(i == 1) exifDate = StringUtil.nvl(request.getParameter("exifDate2"));
				if(exifDate.indexOf(",gallery") > -1) {
					exifDate = exifDate.substring(0, exifDate.indexOf(",gallery"));
				}
				logger.debug("exifDate: " + exifDate);
				
				result = carRiderFileService.docRegToEdms2(edmsPreRegInfo, file.getName(), null, exifDate);
				logger.debug("result: " + result);
			} 
			else {
				throw new Exception("EDMS에 파일전송 실패");
			}
		}
	}
	
	@SuppressWarnings("static-access")
	public MMTI0289VO getMMTI0289VO(MMTI0289VO jmvo) throws Exception {
		String UserId = HOMEPAGE_JOJIKWON_CD;                                                                                                                                                                                           
		String formId = "MMTI0289";                                                                                                                                                                                           
		String telegram = "MMTI"; // esb                                                                                                                                                                                      
		                                                                                                                                                                                                                      
		ESBManager em = new ESBManager();                                                                                                                                                                                     
		ESBChannelHeader channelHead = new ESBChannelHeader();                                                                                                                                                                
		ESBBizHeader bizHead = new ESBBizHeader();     
		
		bizHead = em.makeDefaultBizHeader(UserId);                                                                                                                                                                            
		channelHead = em.makeDefaultChannelHeader(formId, UserId);  
		String Url = ESBURL;
		logger.debug("Url: " + Url);
		String rtnXmlString = (String)XmlUtil.callESBToString(channelHead, bizHead, jmvo, Url, telegram);                                                                                                                   
		                                                                                                                                                                                                                      
		logger.debug("##############################");                                                                                                                                                                       
		logger.debug(rtnXmlString);                                                                                                                                                                                           
		logger.debug("##############################");                                                                                                                                                                       
		                                                                                                                                                                                                                      
		jmvo = (MMTI0289VO) ESBManager.xmlToVOnew(rtnXmlString, (MMTI0289VO)jmvo);                                                                                                                      
		                                                                                                                                                                                                                      
		return jmvo;
	}	
	
	public String getEncKey() {
		return dmAesKey;
	}

	// EDMS (자차사진등록)
	public void regInfoToEdmsForMobileWeb(MultipartHttpServletRequest request, MMTI0289VO jmvo) throws Exception {
		boolean result = false;

		// 등록관련정보조회 서블릿을 호출해서 User ID 조회
		Map<String, String> edmsPreRegInfo = new HashMap<String, String>();
		edmsPreRegInfo.put("UsrId"		, carRiderFileService.getEdmsId());
		edmsPreRegInfo.put("SysCode"	, "MTD");
		edmsPreRegInfo.put("Index09"	, "01".equals(jmvo.getMbl_ts_dtl_dvcd()) ? "CKA" : "CKB");
		edmsPreRegInfo.put("DocNo1"		, "01".equals(jmvo.getMbl_ts_dtl_dvcd()) ? jmvo.getPlan_plno() : jmvo.getPlno());
		edmsPreRegInfo.put("DocNo2"		, "01".equals(jmvo.getMbl_ts_dtl_dvcd()) ? "" : jmvo.getPlan_plno());
		if("43".equals(jmvo.getMbl_bz_dvcd())) { // 차선이탈경고장치가입
			edmsPreRegInfo.put("DocType", "01".equals(jmvo.getMbl_ts_dtl_dvcd()) ? "CKA025" : "CKB017");
		}
		else if("01".equals(jmvo.getMbl_bz_dvcd())) { // 자차추가
			edmsPreRegInfo.put("DocType", "01".equals(jmvo.getMbl_ts_dtl_dvcd()) ? "CKA026" : "CKB018");
		}
		else if("35".equals(jmvo.getMbl_bz_dvcd())) { // 베이비인카가입서류
			edmsPreRegInfo.put("DocType", "01".equals(jmvo.getMbl_ts_dtl_dvcd()) ? "CKA027" : "CKB019");
		}
		else if("55".equals(jmvo.getMbl_bz_dvcd())) { // 전방충돌경고장치
			edmsPreRegInfo.put("DocType", "01".equals(jmvo.getMbl_ts_dtl_dvcd()) ? "CKA029" : "CKB020");
		}
		else if("69".equals(jmvo.getMbl_bz_dvcd()) || "71".equals(jmvo.getMbl_bz_dvcd()) 
				|| "72".equals(jmvo.getMbl_bz_dvcd()) || "73".equals(jmvo.getMbl_bz_dvcd())) { // 해지/취소, 자동차사항(차량대체), 요율사항, 가입경력지정자
			edmsPreRegInfo.put("DocType", "CKB003");
		}
		else {
			edmsPreRegInfo.put("DocType", "01".equals(jmvo.getMbl_ts_dtl_dvcd()) ? "CKA003" : "CKB003");
		}

		// 이미지 업로드
		LinkedList<FileMeta> linkedList = carRiderFileService.upload(request, CARRIDER_UPLOAD_TEMP_PATH, jmvo.getMbl_snd_no());
		
		LinkedList<String> exifDateQueue = new LinkedList<String>();
		if(request.getParameter("exifDate1") != null) exifDateQueue.add(request.getParameter("exifDate1"));
		if(request.getParameter("exifDate2") != null) exifDateQueue.add(request.getParameter("exifDate2"));
		if(request.getParameter("exifDate3") != null) exifDateQueue.add(request.getParameter("exifDate3"));
		if(request.getParameter("exifDate4") != null) exifDateQueue.add(request.getParameter("exifDate4"));

		if(linkedList == null || linkedList.size() == 0) {
			throw new Exception("파일 업로드 실패 [ 업로드할 파일이 없거나 이미지파일이 아닙니다. ]");
		}

		for(int i = 0; i < linkedList.size(); i++) {
			FileMeta fileMeta = linkedList.get(i);

			File file = new File(CARRIDER_UPLOAD_TEMP_PATH + fileMeta.getFileName());

			// EDMS로 파일 전송후 해당 파일 삭제						
			result = carRiderFileService.fileSendToEdms(file, edmsPreRegInfo.get("UsrId"), null);
			if(result) {
				logger.debug(CARRIDER_UPLOAD_TEMP_PATH + fileMeta.getFileName() + " 삭제");
			}
			logger.debug("result: " + result);

			if(result) {
				// EDMS에 문서 등록
				String exifDate = exifDateQueue.removeFirst();
				logger.debug("exifDate: " + exifDate);
				
				result = carRiderFileService.docRegToEdms2(edmsPreRegInfo, file.getName(), null, exifDate);
				logger.debug("result: " + result);
				
				if(!result) throw new Exception("EDMS 등록 실패");
			} 
			else {
				throw new Exception("EDMS에 파일전송 실패");
			}
		}
	}
	
	public void regInfoToEdmsForMobileWeb2(MultipartHttpServletRequest request, String id, ArrayList<File> files, String plnoAndPlanNo) throws Exception { // OCR 용
		boolean result = false;

		// 등록관련정보조회 서블릿을 호출해서 User ID 조회
		String edmsId = carRiderFileService.getEdmsId(id);
		if(edmsId.startsWith("-")) {
			throw new Exception("오류");
		}		

		for(int i = 0; i < files.size(); i++) {
			File file = files.get(i);

			// EDMS로 파일 전송후 해당 파일 삭제 X					
			result = carRiderFileService.fileSendToEdms2(file, edmsId, null);
			logger.debug("result: " + result);
			if(result) {
				// EDMS에 문서 등록
				String exifDate = "";
				if(i == 0) exifDate = StringUtil.nvl(request.getParameter("exifDate1"));
				else if(i == 1) exifDate = StringUtil.nvl(request.getParameter("exifDate2"));
				
				if(exifDate.indexOf(",gallery") > -1) {
					exifDate = exifDate.substring(0, exifDate.indexOf(",gallery"));
				}
				
				logger.debug("exifDate: " + exifDate);
				
				result = carRiderFileService.docRegToEdms3(edmsId, file.getName(), null, exifDate, plnoAndPlanNo);
				logger.debug("result: " + result);
			} 
			else {
				throw new Exception("EDMS에 파일전송 실패");
			}
		}
	}
	
	public void regInfoToEdmsForMobileWeb3(String id, Object fileObject, String exifDate, String plnoAndPlanNo) throws Exception { // OCR 용
		boolean result = false;

		// 등록관련정보조회 서블릿을 호출해서 User ID 조회
		String edmsId = carRiderFileService.getEdmsId(id);
		if(edmsId.startsWith("-")) {
			throw new Exception("오류");
		}		

		File file = new File(CARRIDER_UPLOAD_TEMP_PATH + "TEMP_" + System.currentTimeMillis() + ".jpg");
		// [200617] 취약점 수정
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(file);
			fos.write((byte[]) fileObject);
			fos.close();
			fos = null;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();
			System.err.println("[CarriderMileageService.regInfoToEdmsForMobileWeb3()] Exception 발생");
		} finally {
			try {
				if(fos != null){
					fos.close();
				}
			} catch (IOException e2) {
				System.err.println("[CarriderMileageService.regInfoToEdmsForMobileWeb3()] IOException 발생");
			}
		}

		// EDMS로 파일 전송후 해당 파일 삭제 X					
		result = carRiderFileService.fileSendToEdms2(file, edmsId, null);
		logger.debug("result: " + result);
		if(result) {
			// EDMS에 문서 등록
			logger.debug("exifDate: " + exifDate);
			result = carRiderFileService.docRegToEdms4(edmsId, file.getName(), null, exifDate, plnoAndPlanNo);
			logger.debug("result: " + result);
			
			if(file.exists()) { 
				if(file.delete())logger.debug("파일삭제!!!");
			}
		} 
		else {
			throw new Exception("EDMS에 파일전송 실패");
		}
	}	
	
	public ArrayList<File> uploadToWAS(MultipartHttpServletRequest request, String sms_ts_bvan) throws Exception { // OCR 용
		ArrayList<File> files = new ArrayList<File>();

		// 이미지 업로드
		LinkedList<FileMeta> linkedList = carRiderFileService.upload(request, CARRIDER_UPLOAD_TEMP_PATH, sms_ts_bvan);		

		if(linkedList == null || linkedList.size() == 0) {
			throw new Exception("파일 업로드 실패 [ 업로드할 파일이 없거나 이미지파일이 아닙니다. ]");
		}

		for(int i = 0; i < linkedList.size(); i++) {
			FileMeta fileMeta = linkedList.get(i);
			File file = new File(CARRIDER_UPLOAD_TEMP_PATH + fileMeta.getFileName());
			files.add(file);
		}
		
		return files;
	}	

	@SuppressWarnings("static-access")
	public MMTI0291VO getMMTI0291VO(MMTI0291VO jmvo) throws Exception {
		String UserId = HOMEPAGE_JOJIKWON_CD;                                                                                                                                                                                           
		String formId = "MMTI0291";                                                                                                                                                                                           
		String telegram = "MMTI"; // esb                                                                                                                                                                                      
		                                                                                                                                                                                                                      
		ESBManager em = new ESBManager();                                                                                                                                                                                     
		ESBChannelHeader channelHead = new ESBChannelHeader();                                                                                                                                                                
		ESBBizHeader bizHead = new ESBBizHeader();     
		
		bizHead = em.makeDefaultBizHeader(UserId);                                                                                                                                                                            
		channelHead = em.makeDefaultChannelHeader(formId, UserId);  
		String Url = ESBURL;
		logger.debug("Url: " + Url);
		String rtnXmlString = (String)XmlUtil.callESBToString(channelHead, bizHead, jmvo, Url, telegram);                                                                                                                   
		                                                                                                                                                                                                                      
		logger.debug("##############################");                                                                                                                                                                       
		logger.debug(rtnXmlString);                                                                                                                                                                                           
		logger.debug("##############################");                                                                                                                                                                       
		                                                                                                                                                                                                                      
		jmvo = (MMTI0291VO) ESBManager.xmlToVOnew(rtnXmlString, (MMTI0291VO)jmvo);                                                                                                                      
		                                                                                                                                                                                                                      
		return jmvo;
	}

	@SuppressWarnings("static-access")
	public MMTI0294VO getMMTI0294VO(MMTI0294VO jmvo) throws Exception {
		String UserId = HOMEPAGE_JOJIKWON_CD;                                                                                                                                                                                           
		String formId = "MMTI0294";                                                                                                                                                                                           
		String telegram = "MMTI"; // esb                                                                                                                                                                                      
		                                                                                                                                                                                                                      
		ESBManager em = new ESBManager();                                                                                                                                                                                     
		ESBChannelHeader channelHead = new ESBChannelHeader();                                                                                                                                                                
		ESBBizHeader bizHead = new ESBBizHeader();     
		
		bizHead = em.makeDefaultBizHeader(UserId);                                                                                                                                                                            
		channelHead = em.makeDefaultChannelHeader(formId, UserId);  
		String Url = ESBURL;
		logger.debug("Url: " + Url);
		String rtnXmlString = (String)XmlUtil.callESBToString(channelHead, bizHead, jmvo, Url, telegram);                                                                                                                   
		                                                                                                                                                                                                                      
		logger.debug("##############################");                                                                                                                                                                       
		logger.debug(rtnXmlString);                                                                                                                                                                                           
		logger.debug("##############################");                                                                                                                                                                       
		                                                                                                                                                                                                                      
		jmvo = (MMTI0294VO) ESBManager.xmlToVOnew(rtnXmlString, (MMTI0294VO)jmvo);                                                                                                                      
		                                                                                                                                                                                                                      
		return jmvo;
	}

	@SuppressWarnings("static-access")
	public MMTI0217VO getMMTI0217VO(MMTI0217VO jmvo) throws Exception {
		String UserId = HOMEPAGE_JOJIKWON_CD;                                                                                                                                                                                           
		String formId = "MMTI0217";                                                                                                                                                                                           
		String telegram = "MMTI"; // esb                                                                                                                                                                                      
		                                                                                                                                                                                                                      
		ESBManager em = new ESBManager();                                                                                                                                                                                     
		ESBChannelHeader channelHead = new ESBChannelHeader();                                                                                                                                                                
		ESBBizHeader bizHead = new ESBBizHeader();     
		
		bizHead = em.makeDefaultBizHeader(UserId);                                                                                                                                                                            
		channelHead = em.makeDefaultChannelHeader(formId, UserId);  
		String Url = ESBURL;
		logger.debug("Url: " + Url);
		String rtnXmlString = (String)XmlUtil.callESBToString(channelHead, bizHead, jmvo, Url, telegram);                                                                                                                   
		                                                                                                                                                                                                                      
		logger.debug("##############################");                                                                                                                                                                       
		logger.debug(rtnXmlString);                                                                                                                                                                                           
		logger.debug("##############################");                                                                                                                                                                       
		                                                                                                                                                                                                                      
		jmvo = (MMTI0217VO) ESBManager.xmlToVOnew(rtnXmlString, (MMTI0217VO)jmvo);                                                                                                                      
		                                                                                                                                                                                                                      
		return jmvo;
	}

	@SuppressWarnings("static-access")
	public MMTI0218VO getMMTI0218VO(MMTI0218VO jmvo) throws Exception {
		String UserId = HOMEPAGE_JOJIKWON_CD;                                                                                                                                                                                           
		String formId = "MMTI0218";                                                                                                                                                                                           
		String telegram = "MMTI"; // esb                                                                                                                                                                                      
		                                                                                                                                                                                                                      
		ESBManager em = new ESBManager();                                                                                                                                                                                     
		ESBChannelHeader channelHead = new ESBChannelHeader();                                                                                                                                                                
		ESBBizHeader bizHead = new ESBBizHeader();     
		
		bizHead = em.makeDefaultBizHeader(UserId);                                                                                                                                                                            
		channelHead = em.makeDefaultChannelHeader(formId, UserId);  
		String Url = ESBURL;
		logger.debug("Url: " + Url);
		String rtnXmlString = (String)XmlUtil.callESBToString(channelHead, bizHead, jmvo, Url, telegram);                                                                                                                   
		                                                                                                                                                                                                                      
		logger.debug("##############################");                                                                                                                                                                       
		logger.debug(rtnXmlString);                                                                                                                                                                                           
		logger.debug("##############################");                                                                                                                                                                       
		                                                                                                                                                                                                                      
		jmvo = (MMTI0218VO) ESBManager.xmlToVOnew(rtnXmlString, (MMTI0218VO)jmvo);                                                                                                                      
		                                                                                                                                                                                                                      
		return jmvo;
	}

	@SuppressWarnings("static-access")
	public XIDB0004VO getXIDB0004VO(XIDB0004VO jmvo) throws Exception{
		String UserId = HOMEPAGE_JOJIKWON_CD;                                                                                                                                                                                           
		String formId = "XIDB0004";                                                                                                                                                                                           
		String telegram = "XIDB"; // esb                                                                                                                                                                                      
		                                                                                                                                                                                                                      
		ESBManager em = new ESBManager();                                                                                                                                                                                     
		ESBChannelHeader channelHead = new ESBChannelHeader();                                                                                                                                                                
		ESBBizHeader bizHead = new ESBBizHeader();     
		
		bizHead = em.makeDefaultBizHeader(UserId);                                                                                                                                                                            
		channelHead = em.makeDefaultChannelHeader(formId, UserId);  
		String Url = ESBURL;
		logger.debug("Url: " + Url);
		String rtnXmlString = (String)XmlUtil.callESBToString(channelHead, bizHead, jmvo, Url, telegram);                                                                                                                   
		                                                                                                                                                                                                                      
		logger.debug("##############################");                                                                                                                                                                       
		logger.debug(rtnXmlString);                                                                                                                                                                                           
		logger.debug("##############################");                                                                                                                                                                       
		                                                                                                                                                                                                                      
		jmvo = (XIDB0004VO) ESBManager.xmlToVOnew(rtnXmlString, (XIDB0004VO)jmvo);                                                                                                                      
		      
		return jmvo;
		
	}
	
	@SuppressWarnings("static-access")
	public MMTI0305VO chatMMTI0305VO(MMTI0305VO jmvo) throws Exception{
		String UserId = CHAT_EMPNO;
		String formId = "MMTI0305";                                                                                                                                                                                           
		String telegram = "MMTI"; // esb                                                                                                                                                                                      
		                                                                                                                                                                                                                      
		ESBManager em = new ESBManager();                                                                                                                                                                                     
		ESBChannelHeader channelHead = new ESBChannelHeader();                                                                                                                                                                
		ESBBizHeader bizHead = new ESBBizHeader();     
		
		bizHead = em.makeDefaultBizHeader(UserId);                                                                                                                                                                            
		channelHead = em.makeDefaultChannelHeader(formId, UserId);  
		String Url = ESBURL;
		logger.debug("Url: " + Url);
		String rtnXmlString = (String)XmlUtil.callESBToString(channelHead, bizHead, jmvo, Url, telegram);                                                                                                                   
		                                                                                                                                                                                                                      
		logger.debug("##############################");                                                                                                                                                                       
		logger.debug(rtnXmlString);                                                                                                                                                                                           
		logger.debug("##############################");                                                                                                                                                                       
		                                                                                                                                                                                                                      
		jmvo = (MMTI0305VO) ESBManager.xmlToVOnew(rtnXmlString, (MMTI0305VO)jmvo);                                                                                                                      
		                                                                                                                                                                                                                      
		return jmvo;
	}
	
	
	@SuppressWarnings("static-access")
	public MMTI0213VO chatMMTI0213VO(MMTI0213VO jmvo) throws Exception {
		String UserId = CHAT_EMPNO;                                                                                                                                                                                           
		String formId = "MMTI0213";                                                                                                                                                                                           
		String telegram = "MMTI"; // esb                                                                                                                                                                                      
		                                                                                                                                                                                                                      
		ESBManager em = new ESBManager();                                                                                                                                                                                     
		ESBChannelHeader channelHead = new ESBChannelHeader();                                                                                                                                                                
		ESBBizHeader bizHead = new ESBBizHeader();     
		
		bizHead = em.makeDefaultBizHeader(UserId);                                                                                                                                                                            
		channelHead = em.makeDefaultChannelHeader(formId, UserId);  
		String Url = ESBURL;
		logger.debug("Url: " + Url);
		String rtnXmlString = (String)XmlUtil.callESBToString(channelHead, bizHead, jmvo, Url, telegram);                                                                                                                   
		                                                                                                                                                                                                                      
		logger.debug("##############################");                                                                                                                                                                       
		logger.debug(rtnXmlString);                                                                                                                                                                                           
		logger.debug("##############################");                                                                                                                                                                       
		                                                                                                                                                                                                                      
		jmvo = (MMTI0213VO) ESBManager.xmlToVOnew(rtnXmlString, (MMTI0213VO)jmvo);                                                                                                                      
		                                                                                                                                                                                                                      
		return jmvo;
	}
	
	
	@SuppressWarnings("static-access")
	public MMTI0259VO chatMMTI0259VO(MMTI0259VO jmvo) throws Exception {
		String UserId = CHAT_EMPNO;                                                                                                                                                                                           
		String formId = "MMTI0259";                                                                                                                                                                                           
		String telegram = "MMTI"; // esb                                                                                                                                                                                      
		                                                                                                                                                                                                                      
		ESBManager em = new ESBManager();                                                                                                                                                                                     
		ESBChannelHeader channelHead = new ESBChannelHeader();                                                                                                                                                                
		ESBBizHeader bizHead = new ESBBizHeader();     
		
		bizHead = em.makeDefaultBizHeader(UserId);                                                                                                                                                                            
		channelHead = em.makeDefaultChannelHeader(formId, UserId);  
		String Url = ESBURL;
		logger.debug("Url: " + Url);
		String rtnXmlString = (String)XmlUtil.callESBToString(channelHead, bizHead, jmvo, Url, telegram);                                                                                                                   
		                                                                                                                                                                                                                      
		logger.debug("##############################");                                                                                                                                                                       
		logger.debug(rtnXmlString);                                                                                                                                                                                           
		logger.debug("##############################");                                                                                                                                                                       
		                                                                                                                                                                                                                      
		jmvo = (MMTI0259VO) ESBManager.xmlToVOnew(rtnXmlString, (MMTI0259VO)jmvo);                                                                                                                      
		                                                                                                                                                                                                                      
		return jmvo;
	}
	
	
	@SuppressWarnings("static-access")
	public MMTI0291VO chatMMTI0291VO(MMTI0291VO jmvo) throws Exception {
		String UserId = CHAT_EMPNO;                                                                                                                                                                                           
		String formId = "MMTI0291";                                                                                                                                                                                           
		String telegram = "MMTI"; // esb                                                                                                                                                                                      
		                                                                                                                                                                                                                      
		ESBManager em = new ESBManager();                                                                                                                                                                                     
		ESBChannelHeader channelHead = new ESBChannelHeader();                                                                                                                                                                
		ESBBizHeader bizHead = new ESBBizHeader();     
		
		bizHead = em.makeDefaultBizHeader(UserId);                                                                                                                                                                            
		channelHead = em.makeDefaultChannelHeader(formId, UserId);  
		String Url = ESBURL;
		logger.debug("Url: " + Url);
		String rtnXmlString = (String)XmlUtil.callESBToString(channelHead, bizHead, jmvo, Url, telegram);                                                                                                                   
		                                                                                                                                                                                                                      
		logger.debug("##############################");                                                                                                                                                                       
		logger.debug(rtnXmlString);                                                                                                                                                                                           
		logger.debug("##############################");                                                                                                                                                                       
		                                                                                                                                                                                                                      
		jmvo = (MMTI0291VO) ESBManager.xmlToVOnew(rtnXmlString, (MMTI0291VO)jmvo);                                                                                                                      
		                                                                                                                                                                                                                      
		return jmvo;
	}
	
	@SuppressWarnings("static-access")
	public MMTI0294VO chatMMTI0294VO(MMTI0294VO jmvo) throws Exception {
		String UserId = CHAT_EMPNO;                                                                                                                                                                                           
		String formId = "MMTI0294";                                                                                                                                                                                           
		String telegram = "MMTI"; // esb                                                                                                                                                                                      
		                                                                                                                                                                                                                      
		ESBManager em = new ESBManager();                                                                                                                                                                                     
		ESBChannelHeader channelHead = new ESBChannelHeader();                                                                                                                                                                
		ESBBizHeader bizHead = new ESBBizHeader();     
		
		bizHead = em.makeDefaultBizHeader(UserId);                                                                                                                                                                            
		channelHead = em.makeDefaultChannelHeader(formId, UserId);  
		String Url = ESBURL;
		logger.debug("Url: " + Url);
		String rtnXmlString = (String)XmlUtil.callESBToString(channelHead, bizHead, jmvo, Url, telegram);                                                                                                                   
		                                                                                                                                                                                                                      
		logger.debug("##############################");                                                                                                                                                                       
		logger.debug(rtnXmlString);                                                                                                                                                                                           
		logger.debug("##############################");                                                                                                                                                                       
		                                                                                                                                                                                                                      
		jmvo = (MMTI0294VO) ESBManager.xmlToVOnew(rtnXmlString, (MMTI0294VO)jmvo);                                                                                                                      
		                                                                                                                                                                                                                      
		return jmvo;
	}
	
	@SuppressWarnings("static-access")
	public MMTI0015VO getMMTI0015VO(MMTI0015VO jmvo) throws Exception {
		String UserId = HOMEPAGE_JOJIKWON_CD;                                                                                                                                                                                           
		String formId = "MMTI0015";                                                                                                                                                                                           
		String telegram = "MMTI"; // esb                                                                                                                                                                                      
		                                                                                                                                                                                                                      
		ESBManager em = new ESBManager();                                                                                                                                                                                     
		ESBChannelHeader channelHead = new ESBChannelHeader();                                                                                                                                                                
		ESBBizHeader bizHead = new ESBBizHeader();     
		
		bizHead = em.makeDefaultBizHeader(UserId);                                                                                                                                                                            
		channelHead = em.makeDefaultChannelHeader(formId, UserId);  
		String Url = ESBURL;
		logger.debug("Url: " + Url);
		String rtnXmlString = (String)XmlUtil.callESBToString(channelHead, bizHead, jmvo, Url, telegram);                                                                                                                   
		                                                                                                                                                                                                                      
		logger.debug("##############################");                                                                                                                                                                       
		logger.debug(rtnXmlString);                                                                                                                                                                                           
		logger.debug("##############################");                                                                                                                                                                       
		                                                                                                                                                                                                                      
		jmvo = (MMTI0015VO) ESBManager.xmlToVOnew(rtnXmlString, (MMTI0015VO)jmvo);                                                                                                                      
		                                                                                                                                                                                                                      
		return jmvo;
	}
	
	@SuppressWarnings("static-access")
	public XTEM0021VO getXTEM0021VO(XTEM0021VO jmvo) throws Exception {
		String UserId = HOMEPAGE_JOJIKWON_CD;                                                                                                                                                                                           
		String formId = "XTEM0021";                                                                                                                                                                                           
		String telegram = "XTEM"; // esb                                                                                                                                                                                      
		                                                                                                                                                                                                                      
		ESBManager em = new ESBManager();                                                                                                                                                                                     
		ESBChannelHeader channelHead = new ESBChannelHeader();                                                                                                                                                                
		ESBBizHeader bizHead = new ESBBizHeader();     
		
		bizHead = em.makeDefaultBizHeader(UserId);                                                                                                                                                                            
		channelHead = em.makeDefaultChannelHeader(formId, UserId);  
		String Url = ESBURL;
		logger.debug("Url: " + Url);
		String rtnXmlString = (String)XmlUtil.callESBToString(channelHead, bizHead, jmvo, Url, telegram);                                                                                                                   
		                                                                                                                                                                                                                      
		logger.debug("##############################");                                                                                                                                                                       
		logger.debug(rtnXmlString);                                                                                                                                                                                           
		logger.debug("##############################");                                                                                                                                                                       
		                                                                                                                                                                                                                      
		jmvo = (XTEM0021VO) ESBManager.xmlToVOnew(rtnXmlString, (XTEM0021VO)jmvo);                                                                                                                      
		                                                                                                                                                                                                                      
		return jmvo;
	}
	
	
}
