package com.idongbu.smartcustomer.counter.carRider.common.service;

import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.idongbu.common.ESBBizHeader;
import com.idongbu.common.ESBChannelHeader;
import com.idongbu.common.ESBManager;
import com.idongbu.common.XmlUtil;
import com.idongbu.smartcustomer.vo.CmmFQD0659RVO;
import com.idongbu.smartcustomer.vo.CmmFQD0706RVO;
import com.idongbu.smartcustomer.vo.CmmFQD0708RVO;
import com.idongbu.smartcustomer.vo.CmmFQZ9079RVO;
import com.idongbu.smartzone.vo.MMTI0143VO;
import com.idongbu.smartzone.vo.MMTI0214VO;
import com.idongbu.smartzone.vo.MMTI0261VO;
import com.idongbu.smartzone.vo.MMTI0272VO;
import com.idongbu.util.DateUtil;

@Service
public class CarRiderJMService {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	private @Value("${legacy.homepage_jojikwon_cd}") String HOMEPAGE_JOJIKWON_CD;
	private @Value("${esb.Realip}") String ESBURL; 
	
	/***************************************************************************
	 * 고객용 앱 신규대상 가입유무(주행거리, 블랙박스) ( 전문프로그램 ID : FQD0659R )
	 * @param CmmFQD0659RVO
	 * @return CmmFQD0659RVO
	 * @throws Exception
	 **************************************************************************/
	public CmmFQD0659RVO getCmmFQD0659RVO(CmmFQD0659RVO in_vo) throws Exception {

		MMTI0272VO dataVo = new MMTI0272VO();

		String UserId = HOMEPAGE_JOJIKWON_CD;
		String formId = "MMTI0272";
		String telegram = "MMTI"; // esb 전문 구분

		Class recvTobeClass = Class.forName(dataVo.getClass().getName());
		Constructor constructor = recvTobeClass.getConstructor(new Class[]{});
		MMTI0272VO recvTobeVoClass = (MMTI0272VO) constructor.newInstance(new Object[]{});

		ESBManager em = new ESBManager();
		ESBChannelHeader channelHead = new ESBChannelHeader();
		ESBBizHeader bizHead = new ESBBizHeader();

		//헤더셋---------------------------------------------------------------------------------------------------
		channelHead = em.makeDefaultChannelHeader(formId, UserId);
		bizHead = em.makeDefaultBizHeader(UserId);
		//bizHead.setZ_page_if_key("hpg_ctc_srch_ctc_lit");

		//입력VO셋-------------------------------------------------------------------------------------------------
		dataVo.setCust_dcmt_no(in_vo.getSCR_GOGEK_NO());	//고객식별번호(AS-IS고객생년월일)
		dataVo.setVh_no(in_vo.getH_SCR_CAR_NO());			//차량번호(AS-IS차량번호)
		dataVo.setBz_dvn(in_vo.getSCR_GUBUN());				//업무구분(AS-IS구분) [1]:주행거리 2:블랙박스
		dataVo.setProc_dvn(in_vo.getSCR_PROCESS_GB());		//처리구분(AS-IS처리구분) [1]:신규(주행거리,블랙박스) 2:추가가입(블랙박스)
		dataVo.setAuth_yn(in_vo.getSCR_AUTHORITY_GB());		//권한여부(AS-IS권한유무)
		dataVo.setOrmm_cd(in_vo.getSCR_JOJIKWON_CD());		//조직원코드(AS-IS조직원코드)

		//Url------------------------------------------------------------------------------------------------------
		String Url = ESBURL;
		
		//ESB호출--------------------------------------------------------------------------------------------------
		String rtnXmlString = (String)XmlUtil.callESBToString(channelHead, bizHead, dataVo, Url, telegram);

		
		recvTobeVoClass = (MMTI0272VO) ESBManager.xmlToVOnew(rtnXmlString, (MMTI0272VO)recvTobeVoClass);
		
		dataVo = recvTobeVoClass;

		CmmFQD0659RVO cmmFQD0659RVO = new CmmFQD0659RVO();

		cmmFQD0659RVO.setSCR_GOGEK_NO(dataVo.cust_dcmt_no);         //고객식별번호
		cmmFQD0659RVO.setH_SCR_CAR_NO(dataVo.vh_no);                //차량번호    
		cmmFQD0659RVO.setSCR_GUBUN(dataVo.bz_dvn);                  //업무구분    
		cmmFQD0659RVO.setSCR_PROCESS_GB(dataVo.proc_dvn);           //처리구분    
		cmmFQD0659RVO.setSCR_AUTHORITY_GB(dataVo.auth_yn);          //권한여부    
		cmmFQD0659RVO.setSCR_JOJIKWON_CD(dataVo.ormm_cd);           //조직원코드  
		cmmFQD0659RVO.setSCR_SULGYE_CNT(dataVo.proc_auth_yn);		//처리권한여부(AS-IS는 건수0이상이면 대상 TO-BE는 1이 대상)

		List<Map<String, String>> loopData = new ArrayList<Map<String, String>>();	//vo에 들어갈 loop data
		for(int i = 0; i < dataVo.getScr_sulgye_occ__plno_test().length; i++){

			Map<String,String> map = new HashMap<String,String>();			
			map.put("SCR_SULGYE_NO", dataVo.scr_sulgye_occ__plno_test[i]);		//블랙박스기가입여부

			loopData.add(map);
		}

		logger.debug("@@@@@@@"+loopData.size());
		cmmFQD0659RVO.setLOOP_DATA(loopData);
		logger.debug("==============\n" + loopData);

		return cmmFQD0659RVO;
		
/*AS-IS
		CmmFQD0659RVO cmmFQD0659RVO = new CmmFQD0659RVO();
		List<Map<String, String>> loopData = new ArrayList<Map<String, String>>();	//vo에 들어갈 loop data
		
		String makedXml = SoapUtil.makeXml(in_vo);
		logger.debug("makedXml : " + makedXml);
		
		byte[] rtnByte = HttpClientUtil.callPost(JUNGGE_URL, makedXml);
		String rtnXmlString = new String(rtnByte,"UTF-8");
		logger.debug("rtnXmlString : " + rtnXmlString);
		
		Document doc = SoapUtil.stringToDocument(rtnXmlString);			
		
		cmmFQD0659RVO.setCOMM_CHANNEL(((Element)XPath.selectSingleNode(doc, "//COMM_CHANNEL")).getTextTrim());
		cmmFQD0659RVO.setCOMM_UNIQUE(((Element)XPath.selectSingleNode(doc, "//COMM_UNIQUE")).getTextTrim());
		cmmFQD0659RVO.setCOMM_PGMID(((Element)XPath.selectSingleNode(doc, "//COMM_PGMID")).getTextTrim());
		cmmFQD0659RVO.setCOMM_PROC_GB(((Element)XPath.selectSingleNode(doc, "//COMM_PROC_GB")).getTextTrim());
		cmmFQD0659RVO.setCOMM_FUN_KEY(((Element)XPath.selectSingleNode(doc, "//COMM_FUN_KEY")).getTextTrim());
		cmmFQD0659RVO.setCOMM_USER_GB(((Element)XPath.selectSingleNode(doc, "//COMM_USER_GB")).getTextTrim());     
		cmmFQD0659RVO.setCOMM_USER_CD(((Element)XPath.selectSingleNode(doc, "//COMM_USER_CD")).getTextTrim());
		cmmFQD0659RVO.setCOMM_JIJUM_CD(((Element)XPath.selectSingleNode(doc, "//COMM_JIJUM_CD")).getTextTrim());     
		cmmFQD0659RVO.setCOMM_JIBU_CD(((Element)XPath.selectSingleNode(doc, "//COMM_JIBU_CD")).getTextTrim());
		cmmFQD0659RVO.setCOMM_PROTOCOL(((Element)XPath.selectSingleNode(doc, "//COMM_PROTOCOL")).getTextTrim());		
		cmmFQD0659RVO.setCOMM_COND_CD(((Element)XPath.selectSingleNode(doc, "//COMM_COND_CD")).getTextTrim());
		cmmFQD0659RVO.setCOMM_LAST_FLAG(((Element)XPath.selectSingleNode(doc, "//COMM_LAST_FLAG")).getTextTrim());		
		cmmFQD0659RVO.setCOMM_CURSOR_MAP(((Element)XPath.selectSingleNode(doc, "//COMM_CURSOR_MAP")).getTextTrim());         
		cmmFQD0659RVO.setCOMM_CURSOR_IDX(((Element)XPath.selectSingleNode(doc, "//COMM_CURSOR_IDX")).getTextTrim());		
		cmmFQD0659RVO.setCOMM_MESSAGE_CD(((Element)XPath.selectSingleNode(doc, "//COMM_MESSAGE_CD")).getTextTrim());				
		cmmFQD0659RVO.setH_COMM_MESSAGE_NM(((Element)XPath.selectSingleNode(doc, "//H_COMM_MESSAGE_NM")).getTextTrim());      
		cmmFQD0659RVO.setCOMM_SYS_ERR(((Element)XPath.selectSingleNode(doc, "//COMM_SYS_ERR")).getTextTrim());
		cmmFQD0659RVO.setCOMM_FILLER(((Element)XPath.selectSingleNode(doc, "//COMM_FILLER")).getTextTrim());				
		cmmFQD0659RVO.setSCR_GOGEK_NO(((Element)XPath.selectSingleNode(doc, "//SCR_GOGEK_NO")).getTextTrim());
		cmmFQD0659RVO.setH_SCR_CAR_NO(((Element)XPath.selectSingleNode(doc, "//H_SCR_CAR_NO")).getTextTrim());
		cmmFQD0659RVO.setSCR_GUBUN(((Element)XPath.selectSingleNode(doc, "//SCR_GUBUN")).getTextTrim());
		cmmFQD0659RVO.setSCR_PROCESS_GB(((Element)XPath.selectSingleNode(doc, "//SCR_PROCESS_GB")).getTextTrim());
		cmmFQD0659RVO.setSCR_AUTHORITY_GB(((Element)XPath.selectSingleNode(doc, "//SCR_AUTHORITY_GB")).getTextTrim());
		cmmFQD0659RVO.setSCR_JOJIKWON_CD(((Element)XPath.selectSingleNode(doc, "//SCR_JOJIKWON_CD")).getTextTrim());		
		cmmFQD0659RVO.setSCR_IN_FIL(((Element)XPath.selectSingleNode(doc, "//SCR_IN_FIL")).getTextTrim());		
		cmmFQD0659RVO.setSCR_SULGYE_CNT(((Element)XPath.selectSingleNode(doc, "//SCR_SULGYE_CNT")).getTextTrim());
		cmmFQD0659RVO.setSCR_OUT_FIL(((Element)XPath.selectSingleNode(doc, "//SCR_OUT_FIL")).getTextTrim());

		List<Element> loop_parts = XPath.selectNodes(doc, "//SCR_OUTPUT/SCR_SULGYE_OCC");	//xml의 loop data
		
		for (Element element : loop_parts) { //xml상 loop data만큼 loop
			
			String key_value = element.getChild("SCR_SULGYE_NO").getTextTrim(); // 설계번호
			if(key_value == null || "".equals(key_value)) continue;	            // key 없는 빈 loop일 경우 continue 
			
			Map<String, String> map = new HashMap<String, String>();
			map.put("SCR_SULGYE_NO", element.getChild("SCR_SULGYE_NO").getTextTrim());
			map.put("SCR_GAIP_SULGYE_YMD", element.getChild("SCR_GAIP_SULGYE_YMD").getTextTrim());
			map.put("SCR_BOHUM_SYMD", element.getChild("SCR_BOHUM_SYMD").getTextTrim());
			map.put("SCR_BOHUM_EYMD", element.getChild("SCR_BOHUM_EYMD").getTextTrim());
			
			loopData.add(map);
		}
		cmmFQD0659RVO.setLOOP_DATA(loopData);
		
		return cmmFQD0659RVO; 		
*/
	}
	
	/***************************************************************************
	 * [ 자보특약 ] 자동차 계약 - 계약관리 - 차량번호조회 ( 전문프로그램 ID : FQZ9079R )
	 * @param in_vo
	 * @return
	 * @throws Exception
	 **************************************************************************/
	public CmmFQZ9079RVO getCmmFQZ9079RVO(CmmFQZ9079RVO in_vo) throws Exception {

		MMTI0143VO dataVo = new MMTI0143VO();
		
		String UserId = HOMEPAGE_JOJIKWON_CD;
		String formId = "MMTI0143";
		String telegram = "MMTI"; // esb 전문 구분
		
		Class recvTobeClass = Class.forName(dataVo.getClass().getName());
		Constructor constructor = recvTobeClass.getConstructor(new Class[]{});
		MMTI0143VO recvTobeVoClass = (MMTI0143VO) constructor.newInstance(new Object[]{});
		
		ESBManager em = new ESBManager();
		ESBChannelHeader channelHead = new ESBChannelHeader();
		ESBBizHeader bizHead = new ESBBizHeader();
	
		bizHead = em.makeDefaultBizHeader(UserId);
		channelHead = em.makeDefaultChannelHeader(formId, UserId);
		//bizHead.setZ_page_if_key("hpg_ctc_srch_ctc_lit");

		//입력값셋------------------------------------
		dataVo.setVh_no(in_vo.getH_SCR_CAR_NO());	//차량번호
		dataVo.setProc_dvn(in_vo.getSCR_GUBUN());	//처리구분
		//--------------------------------------------

		String Url = ESBURL;
		String rtnXmlString = (String)XmlUtil.callESBToString(channelHead, bizHead, dataVo, Url, telegram);
	
		recvTobeVoClass = (MMTI0143VO) ESBManager.xmlToVOnew(rtnXmlString, (MMTI0143VO)recvTobeVoClass);

		in_vo.setH_SCR_CAR_NO(recvTobeVoClass.getVh_no());				//차량번호
		in_vo.setSCR_GUBUN(recvTobeVoClass.getProc_dvn());				//처리구분
		in_vo.setSCR_BRIGHT_MAP(recvTobeVoClass.getErr_scrn_id());		//에러화면ID
		in_vo.setH_SCR_CAR_NO_B(recvTobeVoClass.getVh_no_scrn_proc());	//차량번호화면처리
		
		List<Map<String,String>> listData = new ArrayList<Map<String,String>>();
		for(int i = 0; i < recvTobeVoClass.getSme_vh_ctc_det_srch_mngt_cust__plno().length; i++){

			Map<String,String> map = new HashMap<String,String>();
			
			map.put("H_SCR_GOGEK_NM", recvTobeVoClass.sme_vh_ctc_det_srch_mngt_cust__ins_nm[i]);	//피보험자명
			map.put("SCR_POLI_NO", recvTobeVoClass.sme_vh_ctc_det_srch_mngt_cust__plno[i]);			//증권번호
			//map.put("", recvTobeVoClass.sme_vh_ctc_det_srch_mngt_cust_arc_tp_cd[i]);				//보험종목코드
			map.put("SCR_SYMD", recvTobeVoClass.sme_vh_ctc_det_srch_mngt_cust__arc_pd[i]);			//보험시기
			map.put("SCR_EYMD", recvTobeVoClass.sme_vh_ctc_det_srch_mngt_cust__arc_et[i]);			//보험종기
			map.put("SCR_GOGEK_CONTROL_NO", recvTobeVoClass.sme_vh_ctc_det_srch_mngt_cust__cust_no[i]);		//고객번호
			map.put("SCR_DRIVE_JUNGSAN_DS_YN", recvTobeVoClass.sme_vh_ctc_det_srch_mngt_cust__trv_dstc_tty_exp_exca_tgt_yn[i]);	//주행거리특약만기정산대상여부
			map.put("SCR_DRIVE_JUNGSAN_YN", recvTobeVoClass.sme_vh_ctc_det_srch_mngt_cust__trv_dstc_tty_exp_exca_yn[i]);			//주행거리특약만기정산여부
			map.put("SCR_DRIVE_UPMU_CD", recvTobeVoClass.sme_vh_ctc_det_srch_mngt_cust__trv_dstc_chn_dvn[i]);					//주행거리채널구분
			map.put("SCR_DRIVE_JARYO_YMD", recvTobeVoClass.sme_vh_ctc_det_srch_mngt_cust__trv_dstc_dat_fnal_inpt_dt[i]);			//주행거리자료최종입력일자
			map.put("SCR_CAR_NAME", recvTobeVoClass.sme_vh_ctc_det_srch_mngt_cust__crnm[i]);			//차량명
			map.put("SCR_BLACKBOX_YN", recvTobeVoClass.sme_vh_ctc_det_srch_mngt_cust__blbo_yn[i]);		//블랙박스기가입여부

			listData.add(map);
		}
		
		logger.debug("@@@@@@@"+listData.size());
		in_vo.setLOOP_DATA(listData);
		logger.debug("==============\n" + listData);
		
		return in_vo;
		
/*AS-IS		
		CmmFQZ9079RVO cmmFQZ9079RVO = new CmmFQZ9079RVO();
		List<Map<String, String>> loopData = new ArrayList<Map<String, String>>();	//vo에 들어갈 loop data
		
		String makedXml = SoapUtil.makeXml(in_vo);
		logger.debug("makedXml : " + makedXml);
		
		byte[] rtnByte = HttpClientUtil.callPost(JUNGGE_URL, makedXml);
		String rtnXmlString = new String(rtnByte,"UTF-8");
		logger.debug("rtnXmlString : " + rtnXmlString);
		
		Document doc = SoapUtil.stringToDocument(rtnXmlString);			
	
		cmmFQZ9079RVO.setCOMM_CHANNEL(((Element)XPath.selectSingleNode(doc, "//COMM_CHANNEL")).getTextTrim());
		cmmFQZ9079RVO.setCOMM_UNIQUE(((Element)XPath.selectSingleNode(doc, "//COMM_UNIQUE")).getTextTrim());
		cmmFQZ9079RVO.setCOMM_PGMID(((Element)XPath.selectSingleNode(doc, "//COMM_PGMID")).getTextTrim());
		cmmFQZ9079RVO.setCOMM_PROC_GB(((Element)XPath.selectSingleNode(doc, "//COMM_PROC_GB")).getTextTrim());
		cmmFQZ9079RVO.setCOMM_FUN_KEY(((Element)XPath.selectSingleNode(doc, "//COMM_FUN_KEY")).getTextTrim());
		cmmFQZ9079RVO.setCOMM_USER_GB(((Element)XPath.selectSingleNode(doc, "//COMM_USER_GB")).getTextTrim());     
		cmmFQZ9079RVO.setCOMM_USER_CD(((Element)XPath.selectSingleNode(doc, "//COMM_USER_CD")).getTextTrim());
		cmmFQZ9079RVO.setCOMM_JIJUM_CD(((Element)XPath.selectSingleNode(doc, "//COMM_JIJUM_CD")).getTextTrim());     
		cmmFQZ9079RVO.setCOMM_JIBU_CD(((Element)XPath.selectSingleNode(doc, "//COMM_JIBU_CD")).getTextTrim());
		cmmFQZ9079RVO.setCOMM_PROTOCOL(((Element)XPath.selectSingleNode(doc, "//COMM_PROTOCOL")).getTextTrim());		
		cmmFQZ9079RVO.setCOMM_COND_CD(((Element)XPath.selectSingleNode(doc, "//COMM_COND_CD")).getTextTrim());
		cmmFQZ9079RVO.setCOMM_LAST_FLAG(((Element)XPath.selectSingleNode(doc, "//COMM_LAST_FLAG")).getTextTrim());		
		cmmFQZ9079RVO.setCOMM_CURSOR_MAP(((Element)XPath.selectSingleNode(doc, "//COMM_CURSOR_MAP")).getTextTrim());         
		cmmFQZ9079RVO.setCOMM_CURSOR_IDX(((Element)XPath.selectSingleNode(doc, "//COMM_CURSOR_IDX")).getTextTrim());		
		cmmFQZ9079RVO.setCOMM_MESSAGE_CD(((Element)XPath.selectSingleNode(doc, "//COMM_MESSAGE_CD")).getTextTrim());				
		cmmFQZ9079RVO.setH_COMM_MESSAGE_NM(((Element)XPath.selectSingleNode(doc, "//H_COMM_MESSAGE_NM")).getTextTrim());      
		cmmFQZ9079RVO.setCOMM_SYS_ERR(((Element)XPath.selectSingleNode(doc, "//COMM_SYS_ERR")).getTextTrim());
		cmmFQZ9079RVO.setCOMM_FILLER(((Element)XPath.selectSingleNode(doc, "//COMM_FILLER")).getTextTrim());
		
		cmmFQZ9079RVO.setH_SCR_CAR_NO(((Element)XPath.selectSingleNode(doc, "//H_SCR_CAR_NO")).getTextTrim());
		cmmFQZ9079RVO.setSCR_GUBUN(((Element)XPath.selectSingleNode(doc, "//SCR_GUBUN")).getTextTrim());
		cmmFQZ9079RVO.setPAGE_Q_POLI_NO(((Element)XPath.selectSingleNode(doc, "//PAGE_Q_POLI_NO")).getTextTrim());
		cmmFQZ9079RVO.setPAGE_Q_BOHUM_SYMD(((Element)XPath.selectSingleNode(doc, "//PAGE_Q_BOHUM_SYMD")).getTextTrim());
		cmmFQZ9079RVO.setPAGE_F_POLI_NO(((Element)XPath.selectSingleNode(doc, "//PAGE_F_POLI_NO")).getTextTrim());
		cmmFQZ9079RVO.setPAGE_F_BOHUM_SYMD(((Element)XPath.selectSingleNode(doc, "//PAGE_F_BOHUM_SYMD")).getTextTrim());
		cmmFQZ9079RVO.setPAGE_L_POLI_NO(((Element)XPath.selectSingleNode(doc, "//PAGE_L_POLI_NO")).getTextTrim());
		cmmFQZ9079RVO.setPAGE_L_BOHUM_SYMD(((Element)XPath.selectSingleNode(doc, "//PAGE_L_BOHUM_SYMD")).getTextTrim());
		cmmFQZ9079RVO.setSCR_BRIGHT_MAP(((Element)XPath.selectSingleNode(doc, "//SCR_BRIGHT_MAP")).getTextTrim());
		cmmFQZ9079RVO.setH_SCR_CAR_NO_B(((Element)XPath.selectSingleNode(doc, "//H_SCR_CAR_NO_B")).getTextTrim());

		List<Element> loop_parts = XPath.selectNodes(doc, "//SCR_AREA/SCR_OUT_DATA");	//xml의 loop data
		
		for (Element element : loop_parts) { //xml상 loop data만큼 loop
			
			String key_value = element.getChild("SCR_POLI_NO").getTextTrim();   // 
			if(key_value == null || "".equals(key_value)) continue;	            // key 없는 빈 loop일 경우 continue 
			
			Map<String, String> map = new HashMap<String, String>();
			map.put("SCR_POLI_NO", element.getChild("SCR_POLI_NO").getTextTrim());
			map.put("H_SCR_GOGEK_NM", element.getChild("H_SCR_GOGEK_NM").getTextTrim());
			map.put("SCR_SYMD", element.getChild("SCR_SYMD").getTextTrim());
			map.put("SCR_EYMD", element.getChild("SCR_EYMD").getTextTrim());
			map.put("SCR_GOGEK_CONTROL_NO", element.getChild("SCR_GOGEK_CONTROL_NO").getTextTrim());
			map.put("SCR_DRIVE_JUNGSAN_DS_YN", element.getChild("SCR_DRIVE_JUNGSAN_DS_YN").getTextTrim());
			map.put("SCR_DRIVE_JUNGSAN_YN", element.getChild("SCR_DRIVE_JUNGSAN_YN").getTextTrim());
			map.put("SCR_DRIVE_UPMU_CD", element.getChild("SCR_DRIVE_UPMU_CD").getTextTrim());
			map.put("SCR_DRIVE_JARYO_YMD", element.getChild("SCR_DRIVE_JARYO_YMD").getTextTrim());
			map.put("H_SCR_CAR_NAME", element.getChild("H_SCR_CAR_NAME").getTextTrim());
			map.put("SCR_BLACKBOX_YN", element.getChild("SCR_BLACKBOX_YN").getTextTrim());			
			
			loopData.add(map);
		}
		cmmFQZ9079RVO.setLOOP_DATA(loopData);		

		return cmmFQZ9079RVO;
*/
	}
	
	/***************************************************************************
	 * [ 자보특약 ] 주행거리 특약 신규 - 채번 ( 전문프로그램 ID : FQD0708R )
	 * @param in_vo
	 * @return
	 * @throws Exception
	 **************************************************************************/
	public CmmFQD0708RVO getCmmFQD0708RVO(CmmFQD0708RVO in_vo) throws Exception {

		MMTI0261VO dataVo = new MMTI0261VO();

		String UserId = HOMEPAGE_JOJIKWON_CD;
		String formId = "MMTI0261";
		String telegram = "MMTI"; // esb 전문 구분

		Class recvTobeClass = Class.forName(dataVo.getClass().getName());
		Constructor constructor = recvTobeClass.getConstructor(new Class[]{});
		MMTI0261VO recvTobeVoClass = (MMTI0261VO) constructor.newInstance(new Object[]{});

		ESBManager em = new ESBManager();
		ESBChannelHeader channelHead = new ESBChannelHeader();
		ESBBizHeader bizHead = new ESBBizHeader();

		//헤더셋---------------------------------------------------------------------------------------------------
		channelHead = em.makeDefaultChannelHeader(formId, UserId);
		bizHead = em.makeDefaultBizHeader(UserId);
		//bizHead.setZ_page_if_key("hpg_ctc_srch_ctc_lit");

		//입력VO셋-------------------------------------------------------------------------------------------------
		dataVo.setBz_dvn("13");								//업무구분(13:고객용앱) <- 차세대 신규추가
		dataVo.setProc_dvn(in_vo.getSCR_PROCESS_GB());		//처리구분(03:변경(차량대체)/06:프로미정산)
		dataVo.setPlan_no(in_vo.getSCR_SULGYE_NO());		//설계번호
		//dataVo.set(in_vo.getSCR_BESU_SULGYE_NO());		//(AS-IS배서설계번호)[삭제]
		dataVo.setIns_cd(in_vo.getSCR_GOGEK_NO());			//피보험자코드
		dataVo.setPlno(in_vo.getSCR_POLI_NO());				//증권번호(필수아님-사용안됨)

		//Url------------------------------------------------------------------------------------------------------
		String Url = ESBURL;
		
		//ESB호출--------------------------------------------------------------------------------------------------
		String rtnXmlString = (String)XmlUtil.callESBToString(channelHead, bizHead, dataVo, Url, telegram);

		
		recvTobeVoClass = (MMTI0261VO) ESBManager.xmlToVOnew(rtnXmlString, (MMTI0261VO)recvTobeVoClass);
		
		dataVo = recvTobeVoClass;

		CmmFQD0708RVO cmmFQD0708RVO = new CmmFQD0708RVO();

		//cmmFQD0708RVO.set(dataVo.getBz_dvn());				//업무구분
		cmmFQD0708RVO.setSCR_PROCESS_GB(dataVo.getProc_dvn());	//처리구분
		cmmFQD0708RVO.setSCR_SULGYE_NO(dataVo.getPlan_no());	//설계번호
		//cmmFQD0708RVO.setSCR_BESU_SULGYE_NO("");				//배서설계번호[삭제]
		cmmFQD0708RVO.setSCR_GOGEK_NO(dataVo.getIns_cd());		//피보험자코드
		cmmFQD0708RVO.setSCR_POLI_NO(dataVo.getPlno());			//증권번호
		cmmFQD0708RVO.setSCR_CHABUN_NO(dataVo.getPbox_no());	//사서함번호(AS-IS채번번호)
		cmmFQD0708RVO.setCOMM_COND_CD(dataVo.errorCode);
		cmmFQD0708RVO.setH_COMM_MESSAGE_NM(!"".equals(dataVo.z_msg_cd) ? dataVo.returnMessage : dataVo.z_resp_msg);
		
		return cmmFQD0708RVO;
		
/*AS-IS
		CmmFQD0708RVO cmmFQD0708RVO = new CmmFQD0708RVO();
		
		String makedXml = SoapUtil.makeXml(in_vo);
		logger.debug("makedXml : " + makedXml);
		
		byte[] rtnByte = HttpClientUtil.callPost(JUNGGE_URL, makedXml);
		String rtnXmlString = new String(rtnByte,"UTF-8");
		logger.debug("rtnXmlString : " + rtnXmlString);
		
		Document doc = SoapUtil.stringToDocument(rtnXmlString);			
	
		cmmFQD0708RVO.setCOMM_CHANNEL(((Element)XPath.selectSingleNode(doc, "//COMM_CHANNEL")).getTextTrim());
		cmmFQD0708RVO.setCOMM_UNIQUE(((Element)XPath.selectSingleNode(doc, "//COMM_UNIQUE")).getTextTrim());
		cmmFQD0708RVO.setCOMM_PGMID(((Element)XPath.selectSingleNode(doc, "//COMM_PGMID")).getTextTrim());
		cmmFQD0708RVO.setCOMM_PROC_GB(((Element)XPath.selectSingleNode(doc, "//COMM_PROC_GB")).getTextTrim());
		cmmFQD0708RVO.setCOMM_FUN_KEY(((Element)XPath.selectSingleNode(doc, "//COMM_FUN_KEY")).getTextTrim());
		cmmFQD0708RVO.setCOMM_USER_GB(((Element)XPath.selectSingleNode(doc, "//COMM_USER_GB")).getTextTrim());     
		cmmFQD0708RVO.setCOMM_USER_CD(((Element)XPath.selectSingleNode(doc, "//COMM_USER_CD")).getTextTrim());
		cmmFQD0708RVO.setCOMM_JIJUM_CD(((Element)XPath.selectSingleNode(doc, "//COMM_JIJUM_CD")).getTextTrim());     
		cmmFQD0708RVO.setCOMM_JIBU_CD(((Element)XPath.selectSingleNode(doc, "//COMM_JIBU_CD")).getTextTrim());
		cmmFQD0708RVO.setCOMM_PROTOCOL(((Element)XPath.selectSingleNode(doc, "//COMM_PROTOCOL")).getTextTrim());		
		cmmFQD0708RVO.setCOMM_COND_CD(((Element)XPath.selectSingleNode(doc, "//COMM_COND_CD")).getTextTrim());
		cmmFQD0708RVO.setCOMM_LAST_FLAG(((Element)XPath.selectSingleNode(doc, "//COMM_LAST_FLAG")).getTextTrim());		
		cmmFQD0708RVO.setCOMM_CURSOR_MAP(((Element)XPath.selectSingleNode(doc, "//COMM_CURSOR_MAP")).getTextTrim());         
		cmmFQD0708RVO.setCOMM_CURSOR_IDX(((Element)XPath.selectSingleNode(doc, "//COMM_CURSOR_IDX")).getTextTrim());		
		cmmFQD0708RVO.setCOMM_MESSAGE_CD(((Element)XPath.selectSingleNode(doc, "//COMM_MESSAGE_CD")).getTextTrim());				
		cmmFQD0708RVO.setH_COMM_MESSAGE_NM(((Element)XPath.selectSingleNode(doc, "//H_COMM_MESSAGE_NM")).getTextTrim());      
		cmmFQD0708RVO.setCOMM_SYS_ERR(((Element)XPath.selectSingleNode(doc, "//COMM_SYS_ERR")).getTextTrim());
		cmmFQD0708RVO.setCOMM_FILLER(((Element)XPath.selectSingleNode(doc, "//COMM_FILLER")).getTextTrim());				
		cmmFQD0708RVO.setSCR_PROCESS_GB(((Element)XPath.selectSingleNode(doc, "//SCR_PROCESS_GB")).getTextTrim());		
		cmmFQD0708RVO.setSCR_SULGYE_NO(((Element)XPath.selectSingleNode(doc, "//SCR_SULGYE_NO")).getTextTrim());
		cmmFQD0708RVO.setSCR_BESU_SULGYE_NO(((Element)XPath.selectSingleNode(doc, "//SCR_BESU_SULGYE_NO")).getTextTrim());
		cmmFQD0708RVO.setSCR_GOGEK_NO(((Element)XPath.selectSingleNode(doc, "//SCR_GOGEK_NO")).getTextTrim());
		cmmFQD0708RVO.setSCR_POLI_NO(((Element)XPath.selectSingleNode(doc, "//SCR_POLI_NO")).getTextTrim());
		cmmFQD0708RVO.setSCR_CHABUN_NO(((Element)XPath.selectSingleNode(doc, "//SCR_CHABUN_NO")).getTextTrim());

		return cmmFQD0708RVO;		
*/
	}
	
	/***************************************************************************
	 * [ 자보특약 ] 자동차보험 주행거리 입력 - 대체 ( 전문프로그램 ID : FQD0706R )
	 * @param in_vo
	 * @return
	 * @throws Exception
	 **************************************************************************/
	public CmmFQD0706RVO getCmmFQD0706RVO(CmmFQD0706RVO in_vo) throws Exception {
		
		MMTI0214VO dataVo = new MMTI0214VO();

		String UserId = HOMEPAGE_JOJIKWON_CD;
		String formId = "MMTI0214";
		String telegram = "MMTI"; // esb 전문 구분

		Class recvTobeClass = Class.forName(dataVo.getClass().getName());
		Constructor constructor = recvTobeClass.getConstructor(new Class[]{});
		MMTI0214VO recvTobeVoClass = (MMTI0214VO) constructor.newInstance(new Object[]{});

		ESBManager em = new ESBManager();
		ESBChannelHeader channelHead = new ESBChannelHeader();
		ESBBizHeader bizHead = new ESBBizHeader();

		//헤더셋---------------------------------------------------------------------------------------------------
		channelHead = em.makeDefaultChannelHeader(formId, UserId);
		bizHead = em.makeDefaultBizHeader(UserId);
		
		String setJuhangKm = in_vo.getSCR_DRIVE_TEXT();
		
		//입력VO셋-------------------------------------------------------------------------------------------------
		dataVo.setPhgp_cnfm_dt(in_vo.getSCR_DRIVE_SAJIN_YMD());		//사진확인일자
		dataVo.setPhgp_strg_yn(in_vo.getSCR_DRIVE_SAJIN_GB());		//사진저장여부
		dataVo.setBz_dvn(in_vo.getSCR_UPMU_GB());					//업무구분
		dataVo.setProc_dvn(in_vo.getSCR_PROCESS_GB());				//처리구분
		dataVo.setPlan_ply_dvn("03".equals(in_vo.getSCR_PROCESS_GB()) ? "1" : "2");								//설계증권구분(1:설계번호 2:증권번호)
		dataVo.setPlan_plno("03".equals(in_vo.getSCR_PROCESS_GB()) ? in_vo.getSCR_SULGYE_NO() : in_vo.getSCR_POLI_NO());				//설계증권번호
		dataVo.setTrv_dstc_cnfm_dt(DateUtil.getDate());		//주행거리확인일자
		dataVo.setTrv_dstc(setJuhangKm);				//주행거리
		//dataVo.setCnfr_blg_nm(in_vo.getH_SCR_W_SOSOK());			//확인자소속명
		//dataVo.setCnfr_nm(in_vo.getH_SCR_W_NAME());				//확인자명
		//dataVo.setCnfr_no(in_vo.getSCR_W_SABUN());				//확인자번호
		//dataVo.setCnfr_ofc_tlno("");								//확인자사무실전화번호
		//dataVo.setCnfr_clpno("");									//확인자휴대폰번호
		//dataVo.setCnfr_fx_no("");									//확인자팩스번호
		//dataVo.setRpt_no(in_vo.getSCR_JUPSU_NO());				//접수번호
		dataVo.setPbox_no(in_vo.getSCR_CHABUN_NO());				//사서함번호
		//dataVo.setApcn_str_dt(in_vo.getSCR_DRIVE_YMD());			//적용시작일자(보험시작일 - 쓰이지 않는 주행거리확인일자에 담아서 넣어줌)
		//dataVo.setApcn_str_dt(DateUtil.getDate("yyyymmdd"));		//적용시작일자(보험시작일?)
		

		//Url------------------------------------------------------------------------------------------------------
		String Url = ESBURL;
		
		//ESB호출--------------------------------------------------------------------------------------------------
		String rtnXmlString = (String)XmlUtil.callESBToString(channelHead, bizHead, dataVo, Url, telegram);
		
		recvTobeVoClass = (MMTI0214VO) ESBManager.xmlToVOnew(rtnXmlString, (MMTI0214VO)recvTobeVoClass);
		
		dataVo = recvTobeVoClass;

		//OUT VO셋-------------------------------------------------------------------------------------------------
		CmmFQD0706RVO cmmFQD0706RVO = new CmmFQD0706RVO();
		
		String juhangKM = dataVo.getTrv_dstc();
		
		cmmFQD0706RVO.setSCR_DRIVE_SAJIN_YMD(dataVo.getPhgp_cnfm_dt());    	//사진확인일자           
		cmmFQD0706RVO.setSCR_DRIVE_SAJIN_GB(dataVo.getPhgp_strg_yn());     	//사진저장여부           
		cmmFQD0706RVO.setSCR_UPMU_GB(dataVo.getBz_dvn());                  	//업무구분               
		cmmFQD0706RVO.setSCR_PROCESS_GB(dataVo.getProc_dvn());             	//처리구분               
		//cmmFQD0706RVO.set(dataVo.getPlan_ply_dvn());                      //설계증권구분           
		//cmmFQD0706RVO.set(dataVo.getPlan_plno());                         //설계증권번호           
		cmmFQD0706RVO.setSCR_DRIVE_YMD(dataVo.getTrv_dstc_cnfm_dt());      	//주행거리확인일자       
		cmmFQD0706RVO.setSCR_DRIVE_KM(juhangKM);               	//주행거리               
		cmmFQD0706RVO.setH_SCR_W_SOSOK(dataVo.getCnfr_blg_nm());           	//확인자소속명           
		cmmFQD0706RVO.setH_SCR_W_NAME(dataVo.getCnfr_nm());                	//확인자명               
		cmmFQD0706RVO.setSCR_W_SABUN(dataVo.getCnfr_no());                 	//확인자번호             
		//cmmFQD0706RVO.set(dataVo.getCnfr_ofc_tlno());                     //확인자사무실전화번호   
		//cmmFQD0706RVO.set(dataVo.getCnfr_clpno());                        //확인자휴대폰번호       
		//cmmFQD0706RVO.set(dataVo.getCnfr_fx_no());                        //확인자팩스번호         
		cmmFQD0706RVO.setSCR_JUPSU_NO(dataVo.getRpt_no());                 	//접수번호               
		cmmFQD0706RVO.setSCR_CHABUN_NO(dataVo.getPbox_no());               	//사서함번호             
		//cmmFQD0706RVO.set(dataVo.getApcn_str_dt());                       //적용시작일자           

		cmmFQD0706RVO.setCOMM_COND_CD(dataVo.errorCode);
		
		return cmmFQD0706RVO;
		 
/*AS-IS
		CmmFQD0706RVO cmmFQD0706RVO = new CmmFQD0706RVO();
		
		String makedXml = SoapUtil.makeXml(in_vo);
		logger.debug("makedXml : " + makedXml);
		
		byte[] rtnByte = HttpClientUtil.callPost(JUNGGE_URL, makedXml);
		String rtnXmlString = new String(rtnByte,"UTF-8");
		logger.debug("rtnXmlString : " + rtnXmlString);
		
		Document doc = SoapUtil.stringToDocument(rtnXmlString);			
	
		cmmFQD0706RVO.setCOMM_CHANNEL(((Element)XPath.selectSingleNode(doc, "//COMM_CHANNEL")).getTextTrim());
		cmmFQD0706RVO.setCOMM_UNIQUE(((Element)XPath.selectSingleNode(doc, "//COMM_UNIQUE")).getTextTrim());
		cmmFQD0706RVO.setCOMM_PGMID(((Element)XPath.selectSingleNode(doc, "//COMM_PGMID")).getTextTrim());
		cmmFQD0706RVO.setCOMM_PROC_GB(((Element)XPath.selectSingleNode(doc, "//COMM_PROC_GB")).getTextTrim());
		cmmFQD0706RVO.setCOMM_FUN_KEY(((Element)XPath.selectSingleNode(doc, "//COMM_FUN_KEY")).getTextTrim());
		cmmFQD0706RVO.setCOMM_USER_GB(((Element)XPath.selectSingleNode(doc, "//COMM_USER_GB")).getTextTrim());     
		cmmFQD0706RVO.setCOMM_USER_CD(((Element)XPath.selectSingleNode(doc, "//COMM_USER_CD")).getTextTrim());
		cmmFQD0706RVO.setCOMM_JIJUM_CD(((Element)XPath.selectSingleNode(doc, "//COMM_JIJUM_CD")).getTextTrim());     
		cmmFQD0706RVO.setCOMM_JIBU_CD(((Element)XPath.selectSingleNode(doc, "//COMM_JIBU_CD")).getTextTrim());
		cmmFQD0706RVO.setCOMM_PROTOCOL(((Element)XPath.selectSingleNode(doc, "//COMM_PROTOCOL")).getTextTrim());		
		cmmFQD0706RVO.setCOMM_COND_CD(((Element)XPath.selectSingleNode(doc, "//COMM_COND_CD")).getTextTrim());
		cmmFQD0706RVO.setCOMM_LAST_FLAG(((Element)XPath.selectSingleNode(doc, "//COMM_LAST_FLAG")).getTextTrim());		
		cmmFQD0706RVO.setCOMM_CURSOR_MAP(((Element)XPath.selectSingleNode(doc, "//COMM_CURSOR_MAP")).getTextTrim());         
		cmmFQD0706RVO.setCOMM_CURSOR_IDX(((Element)XPath.selectSingleNode(doc, "//COMM_CURSOR_IDX")).getTextTrim());		
		cmmFQD0706RVO.setCOMM_MESSAGE_CD(((Element)XPath.selectSingleNode(doc, "//COMM_MESSAGE_CD")).getTextTrim());				
		cmmFQD0706RVO.setH_COMM_MESSAGE_NM(((Element)XPath.selectSingleNode(doc, "//H_COMM_MESSAGE_NM")).getTextTrim());      
		cmmFQD0706RVO.setCOMM_SYS_ERR(((Element)XPath.selectSingleNode(doc, "//COMM_SYS_ERR")).getTextTrim());
		cmmFQD0706RVO.setCOMM_FILLER(((Element)XPath.selectSingleNode(doc, "//COMM_FILLER")).getTextTrim());		
		cmmFQD0706RVO.setSCR_SASEOHAM_INFO(((Element)XPath.selectSingleNode(doc, "//SCR_SASEOHAM_INFO")).getTextTrim());		
		cmmFQD0706RVO.setSCR_SASEOHAM_GB(((Element)XPath.selectSingleNode(doc, "//SCR_SASEOHAM_GB")).getTextTrim());
		cmmFQD0706RVO.setSCR_CHABUN_NO(((Element)XPath.selectSingleNode(doc, "//SCR_CHABUN_NO")).getTextTrim());
		cmmFQD0706RVO.setSCR_DRIVE_SAJIN_YMD(((Element)XPath.selectSingleNode(doc, "//SCR_DRIVE_SAJIN_YMD")).getTextTrim());
		cmmFQD0706RVO.setSCR_DRIVE_SAJIN_GB(((Element)XPath.selectSingleNode(doc, "//SCR_DRIVE_SAJIN_GB")).getTextTrim());
		cmmFQD0706RVO.setSCR_DRIVE_HP(((Element)XPath.selectSingleNode(doc, "//SCR_DRIVE_HP")).getTextTrim());
		cmmFQD0706RVO.setSCR_DRIVE_TEXT(((Element)XPath.selectSingleNode(doc, "//SCR_DRIVE_TEXT")).getTextTrim());
		cmmFQD0706RVO.setSCR_UPMU_GB(((Element)XPath.selectSingleNode(doc, "//SCR_UPMU_GB")).getTextTrim());
		cmmFQD0706RVO.setSCR_PROCESS_GB(((Element)XPath.selectSingleNode(doc, "//SCR_PROCESS_GB")).getTextTrim());
		cmmFQD0706RVO.setSCR_SULGYE_NO(((Element)XPath.selectSingleNode(doc, "//SCR_SULGYE_NO")).getTextTrim());
		cmmFQD0706RVO.setSCR_POLI_NO(((Element)XPath.selectSingleNode(doc, "//SCR_POLI_NO")).getTextTrim());
		cmmFQD0706RVO.setSCR_BESU_SULGYE_NO(((Element)XPath.selectSingleNode(doc, "//SCR_BESU_SULGYE_NO")).getTextTrim());
		cmmFQD0706RVO.setSCR_DRIVE_YMD(((Element)XPath.selectSingleNode(doc, "//SCR_DRIVE_YMD")).getTextTrim());
		cmmFQD0706RVO.setSCR_DRIVE_KM(((Element)XPath.selectSingleNode(doc, "//SCR_DRIVE_KM")).getTextTrim());
		cmmFQD0706RVO.setSCR_HWAKINJA_INFO(((Element)XPath.selectSingleNode(doc, "//SCR_HWAKINJA_INFO")).getTextTrim());
		cmmFQD0706RVO.setH_SCR_W_SOSOK(((Element)XPath.selectSingleNode(doc, "//H_SCR_W_SOSOK")).getTextTrim());
		cmmFQD0706RVO.setH_SCR_W_NAME(((Element)XPath.selectSingleNode(doc, "//H_SCR_W_NAME")).getTextTrim());
		cmmFQD0706RVO.setSCR_W_SABUN(((Element)XPath.selectSingleNode(doc, "//SCR_W_SABUN")).getTextTrim());
		cmmFQD0706RVO.setH_SCR_W_JIKCHEK(((Element)XPath.selectSingleNode(doc, "//H_SCR_W_JIKCHEK")).getTextTrim());
		cmmFQD0706RVO.setSCR_W_OFFICE_TEL(((Element)XPath.selectSingleNode(doc, "//SCR_W_OFFICE_TEL")).getTextTrim());
		cmmFQD0706RVO.setSCR_W_HP_TEL(((Element)XPath.selectSingleNode(doc, "//SCR_W_HP_TEL")).getTextTrim());
		cmmFQD0706RVO.setSCR_W_FAX(((Element)XPath.selectSingleNode(doc, "//SCR_W_FAX")).getTextTrim());
		cmmFQD0706RVO.setSCR_JUPSU_NO(((Element)XPath.selectSingleNode(doc, "//SCR_JUPSU_NO")).getTextTrim());
		cmmFQD0706RVO.setSCR_SAJIN_AGREE_GB(((Element)XPath.selectSingleNode(doc, "//SCR_SAJIN_AGREE_GB")).getTextTrim());

		return cmmFQD0706RVO;
*/		
	}	
}
