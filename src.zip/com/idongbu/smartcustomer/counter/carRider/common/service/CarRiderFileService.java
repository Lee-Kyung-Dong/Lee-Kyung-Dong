package com.idongbu.smartcustomer.counter.carRider.common.service;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.PostMethod;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.xpath.XPath;
import org.mybatis.spring.SqlSessionTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.idongbu.smartcustomer.vo.FileMeta;
import com.idongbu.util.DateUtil;
import com.idongbu.util.HttpClientUtil;
import com.idongbu.util.SoapUtil;
import com.idongbu.util.StringUtil;

@Service
public class CarRiderFileService {
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	//모바일 DB사용하는 sqlsession
	@Autowired(required=true)
	@Qualifier("sqlSession")
	protected SqlSessionTemplate sqlSession;	
	
	private @Value("${legacy.homepage_jojikwon_cd}") String HOMEPAGE_JOJIKWON_CD;
	private @Value("${legacy.edms_step1_url}") String EDMS_STEP1_URL;
	private @Value("${legacy.edms_step3_url}") String EDMS_STEP3_URL;
	private @Value("${legacy.edms_fileserver_ip}") String EDMS_FILESERVER_IP; // 주행거리신규, 블랙박스
	private @Value("${legacy.edms_fileserver_port}") String EDMS_FILESERVER_PORT; // 주행거리신규, 블랙박스
	private @Value("${legacy.edms_fileserver_path}") String EDMS_FILESERVER_PATH; // 주행거리신규, 블랙박스
	private @Value("${carrider.upload.temp.path}") String CARRIDER_UPLOAD_TEMP_PATH;
	private @Value("${legacy.edms_PreRegServlet}") String EDMS_PRE_REG_SERVLET_URL;
	
	/***************************************************************************
	 * 파일 업로드
	 * @param request
	 * @param path
	 * @param rename_keyval
	 * @return
	 **************************************************************************/
	public LinkedList<FileMeta> upload(MultipartHttpServletRequest request, String path) {
		return upload(request, path, "");
	}
	
	public LinkedList<FileMeta> upload(MultipartHttpServletRequest request, String path, String rename_keyval) {
		LinkedList<FileMeta> files = new LinkedList<FileMeta>();		
		Iterator<String> iterator = request.getFileNames();
		MultipartFile multipartFile = null;		
		File file = null;
		
		if(path != null) {
			file = new File(path);
			if(!file.exists()) {
				file.mkdirs();
			}
		}	

		int i = 1;
		while(iterator.hasNext()) {
			multipartFile = request.getFile(iterator.next());
			logger.debug("업로드 파일명: " + multipartFile.getOriginalFilename() + ", i: " + i + ", size: " + multipartFile.getSize());

			if("".equals(StringUtil.nvl(multipartFile.getOriginalFilename())) || 0 == multipartFile.getSize() || 
			   ( multipartFile.getOriginalFilename().toUpperCase().indexOf("JPG") < 0 && 
				 multipartFile.getOriginalFilename().toUpperCase().indexOf("JPEG") < 0 &&
				 multipartFile.getOriginalFilename().toUpperCase().indexOf("PNG") < 0 &&
			     multipartFile.getOriginalFilename().toUpperCase().indexOf("GIF") < 0 && 
			     multipartFile.getOriginalFilename().toUpperCase().indexOf("TIF") < 0 && 
			     multipartFile.getOriginalFilename().toUpperCase().indexOf("BMP") < 0 ) ) {
				continue;
			}
			
			try {
				FileCopyUtils.copy(multipartFile.getBytes(), new FileOutputStream(path + multipartFile.getOriginalFilename()));
				
				if("".equals(rename_keyval)) {
					file = renameFile(new File(CARRIDER_UPLOAD_TEMP_PATH + multipartFile.getOriginalFilename()), request.getParameter("SCR_GOGEK_NO"), Integer.toString(i));
				}
				else {
					file = renameFile(new File(CARRIDER_UPLOAD_TEMP_PATH + multipartFile.getOriginalFilename()), rename_keyval, Integer.toString(i));
				}
			}
			catch(IOException e) {
				for(int j = 0; j <= files.size(); j++) {
					File tmp_file = new File(CARRIDER_UPLOAD_TEMP_PATH + files.get(j).getFileName());
					if(tmp_file.delete()) logger.debug("temp file deleted");
				}				
				return null;
			}
			
			FileMeta fileMeta = new FileMeta();
			fileMeta.setFileName(file.getName());
			fileMeta.setFileSize(multipartFile.getSize() / 1024 + " Kb");
			fileMeta.setFileType(multipartFile.getContentType());			
			/*logger.info("주행가입/블박 멀티파트 파일명: " + multipartFile.getOriginalFilename());
			logger.info("주행가입/블박 rename 파일명: " + file.getName());
			logger.info("주행가입/블박 WAS업로드파일 사이즈: " + multipartFile.getSize()/1024 + "KB");*/
			files.add(fileMeta);
			i++;
		}
		return files;
	}
		
	/***************************************************************************
	 * [ 파일업로드 ] 파일명 변경
	 * @param File
	 * @param chebun or gogek_no 등
	 * @param num
	 * @return
	 **************************************************************************/
	public File renameFile(File file, String keyval, String num) {
		if(file == null) {
			return null;
		}
		else {
			java.util.Date currentdate = new java.util.Date();
			java.text.SimpleDateFormat format = new java.text.SimpleDateFormat("yyyyMMddHHmmss");	
			String tmpStr = keyval + "_" + num + "_" + format.format(currentdate) + file.getName().substring(file.getName().lastIndexOf("."), file.getName().length());
			File newFile = new File(file.getParent() + "\\" + tmpStr);
			file.renameTo(newFile);
			return newFile;			
		}
	}
	
	public File renameFile(File file, String num) {
		if(file == null) {
			return null;
		}
		else {
			java.util.Date currentdate = new java.util.Date();
			java.text.SimpleDateFormat format = new java.text.SimpleDateFormat("yyyyMMddHHmmss");	
			String tmpStr = num + "_" + format.format(currentdate) + file.getName().substring(file.getName().lastIndexOf("."), file.getName().length());
			File newFile = new File(file.getParent() + "\\" + tmpStr);
			file.renameTo(newFile);		
			return newFile;
		}
	}	

	/***************************************************************************
	 * EDMS 아이디 조회
	 * @return
	 * @throws Exception
	 **************************************************************************/
	public String getEdmsId() throws Exception {
		String result = "";		
		
		HttpClient client = new HttpClient();
        PostMethod httppost = new PostMethod(EDMS_STEP1_URL); 
        httppost.setRequestHeader("Content-Type", "application/x-www-form-urlencoded; charset=utf-8"); 
        httppost.addParameter("SysCode", "MAP");
        httppost.addParameter("Id", HOMEPAGE_JOJIKWON_CD); 
        
	    client.executeMethod(httppost);
	    
	    if(httppost.getStatusCode() != 200) {
	        throw new Exception(httppost.getStatusLine().toString());
	    }
	    
	    String[] tmpArr = ( httppost.getResponseBodyAsString() ).split("\\|");
	    result = tmpArr[0];
	
	    httppost.releaseConnection();

        return result;
	}
	
	/***************************************************************************
	 * 등록관련정보조회 서블릿을 호출해서 User ID 조회 (주행거리특약 - 대체 / 만기정산)
	 * @param SCR_CHABUN_NO
	 * @return
	 * @throws Exception
	 **************************************************************************/
	public Map<String, String> getEdmsId2(String SCR_CHABUN_NO) throws Exception {
		String url = EDMS_PRE_REG_SERVLET_URL + "?SysCode=MTD&KeyNo=" + SCR_CHABUN_NO;
		
		byte[] rtnByte = HttpClientUtil.callUrlPost(url);

		String rtnXmlString = new String(rtnByte,"EUC-KR");
		logger.debug("rtnXmlString : " + rtnXmlString);
		
		Document doc = SoapUtil.stringToDocument(rtnXmlString);
		
		Map<String, String> map = new HashMap<String, String>();
		map.put("UsrId", ((Element)XPath.selectSingleNode(doc, "//UsrId")).getTextTrim());
		map.put("RtnCd", ((Element)XPath.selectSingleNode(doc, "//RtnCd")).getTextTrim());
		map.put("DocNo2", ((Element)XPath.selectSingleNode(doc, "//DocNo2")).getTextTrim());
		map.put("DocNo1", ((Element)XPath.selectSingleNode(doc, "//DocNo1")).getTextTrim());
		map.put("Message", ((Element)XPath.selectSingleNode(doc, "//Message")).getTextTrim());
		map.put("DocType", ((Element)XPath.selectSingleNode(doc, "//DocType")).getTextTrim());
		map.put("Index09", ((Element)XPath.selectSingleNode(doc, "//Index09")).getTextTrim());
		
		return map;
	}	
	
	/***************************************************************************
	 * EDMS 로 파일 전송 - 주행거리신규 / 블랙박스
	 * @param file
	 * @return
	 * @throws Exception
	 **************************************************************************/
	public boolean fileSendToEdms(File file, String edms_id, Map<String, String> map) throws Exception {
		if(!file.isFile()) {
			return false;
		}
		
		String edmsFilePath = "";

		edmsFilePath = EDMS_FILESERVER_PATH
			         + "/CK" 
			         + "/" + DateUtil.getYear()
			         + "/" + DateUtil.getMonth()
			         + "/dDIMSTmp"
			         + "/" + edms_id + "/"; 

		try {
			int returnCode = sendFile(edmsFilePath + file.getName(), file.getAbsolutePath(), EDMS_FILESERVER_IP, EDMS_FILESERVER_PORT);
						
			if(returnCode != 0) {
				if(map != null) map.put("MSG", String.valueOf(returnCode));				
				return false;
			}
		}
		catch(Exception e) {			
			return false;
		}
		finally {
			if(file.delete())logger.debug("temp file deleted");
		}
		return true;
	}

	/***************************************************************************
	 * EDMS에 문서 등록 (주행거리특약 신규 / 블랙박스 신규, 추가)
	 * @param SysCode
	 * @param Index09
	 * @param UsrId
	 * @param FileName
	 * @param DocNo1
	 * @param DocNo2
	 * @param DocType
	 * @return
	 * @throws Exception
	 **************************************************************************/
	public boolean docRegToEdms(String UsrId, String FileName, String DocNo1, String DocNo2, String reg_type, Map<String, String> map) throws Exception {
		HttpClient client = new HttpClient();
				
		PostMethod httppost = new PostMethod(EDMS_STEP3_URL);
        httppost.setRequestHeader("Content-Type", "application/x-www-form-urlencoded; charset=euc-kr");
        httppost.addParameter("SysCode", "MTD"); // 주행거리 & 블랙박스 특약 고정값	자동차
        httppost.addParameter("Index09", "CKJ"); // 주행거리 & 블랙박스 특약 고정값
        httppost.addParameter("UsrId", UsrId); // 직원의 edms_id
        httppost.addParameter("FileName", FileName); // 파일명
        
		byte[] b_carno = StringUtil.nvl(DocNo1).getBytes("EUC-KR");
		        
        httppost.addParameter("DocNo1", new String(b_carno, "EUC-KR")); // 차량번호
        httppost.addParameter("DocNo2", StringUtil.nvl(DocNo2)); // 생년월일
        
		if("10".equals(reg_type) || "11".equals(reg_type) || "12".equals(reg_type)) {
			httppost.addParameter("DocType", "CKJ002"); // CKJ002: 주행거리
		}
		else if("20".equals(reg_type) || "21".equals(reg_type)) {
			httppost.addParameter("DocType", "CKJ001"); // CKJ001: 블랙박스
		}        
                       
        String resultText = "";
        
        try {
            client.executeMethod(httppost);
            if(httppost.getStatusCode() != 200) {
                throw new Exception(httppost.getStatusLine().toString());
            } 
            
            resultText = httppost.getResponseBodyAsString();

            String[] tmpArr = resultText.split("\\|");
            
            if(!tmpArr[0].equals("Y")) {
            	map.put("MSG", resultText);
            	return false;
            }
        }
        catch(Exception e) {
            return false;
        }
        finally {
            httppost.releaseConnection();
        }
        return true;
	}
	
	/***************************************************************************
	 * 주행거리특약 대체(11), 만기(12)
	 * @param map
	 * @param fileName
	 * @param reg_type
	 * @return
	 * @throws Exception
	 **************************************************************************/
	public boolean docRegToEdms2(Map<String, String> edmsPreRegInfo, String fileName, Map<String, String> map, String exifDate) throws Exception {
		HttpClient client = new HttpClient();
				
		PostMethod httppost = new PostMethod(EDMS_STEP3_URL);
        httppost.setRequestHeader("Content-Type", "application/x-www-form-urlencoded; charset=euc-kr");
        httppost.addParameter("SysCode", "MTD");
        httppost.addParameter("Index09", edmsPreRegInfo.get("Index09"));
        httppost.addParameter("UsrId", edmsPreRegInfo.get("UsrId"));
        httppost.addParameter("DocNo1", edmsPreRegInfo.get("DocNo1"));
        httppost.addParameter("DocNo2", edmsPreRegInfo.get("DocNo2"));        
        httppost.addParameter("FileName", fileName);
        httppost.addParameter("DocType", edmsPreRegInfo.get("DocType"));
    	httppost.addParameter("Date", exifDate);
                       
        String resultText = "";
        
        try {
            client.executeMethod(httppost);
            if(httppost.getStatusCode() != 200) {
                throw new Exception(httppost.getStatusLine().toString());
            } 
            
            resultText = httppost.getResponseBodyAsString();
            logger.debug("resultText: " + resultText);

            String[] tmpArr = resultText.split("\\|");
            
            if(!tmpArr[0].equals("Y")) {
            	if(map != null) map.put("MSG", resultText);
            	return false;
            }
        }
        catch(Exception e) {
            return false;
        }
        finally {
            httppost.releaseConnection();
        }
        return true;
	}	
	
	/***************************************************************************
	 * 파일 전송
	 * @param DstFileName
	 * @param SrcFileName
	 * @return
	 **************************************************************************/
	public int sendFile(String DstFileName, String SrcFileName, String ip, String port) {
		int BUF_SIZE = 1024;
		//int port = Integer.parseInt(EDMS_FILESERVER_PORT);
		StringBuffer aBuf1;
		String sBuf1;
		byte send_byte[];
		int n, iNameLen;
		long lFileSize;
		byte[] data = new byte[BUF_SIZE];
		byte[] data3 = new byte[3];

		Socket socket 		 = null;
		OutputStream os		 = null;
		InputStream is 		 = null;
		DataOutputStream dos = null;
		DataInputStream dis  = null;
		FileInputStream fis  = null;		
		
		try {
			socket = new Socket(ip, Integer.parseInt(port));
			os = socket.getOutputStream();
			is = socket.getInputStream();
			dos = new DataOutputStream(os);
			dis = new DataInputStream(is);
			
			sBuf1 = "SND";
			send_byte = sBuf1.getBytes();
			dos.write(send_byte, 0, 3);

			byte[] head = new byte[512];
			head = DstFileName.getBytes();
			ByteArrayInputStream inByte = new ByteArrayInputStream(head);
			iNameLen = inByte.available();
			inByte.close();

			aBuf1 = new StringBuffer(Integer.toString(iNameLen));
			aBuf1.setLength(10);
			sBuf1 = aBuf1.toString() + DstFileName; 
			send_byte = sBuf1.getBytes();
			dos.write(send_byte, 0, iNameLen + 10);

			File f = new File(SrcFileName);
			if(!f.isFile()) {
				return -92;
			}
			fis = new FileInputStream(f);

			lFileSize = f.length();

			aBuf1 = new StringBuffer(Long.toString(lFileSize));
			aBuf1.setLength(10);
			sBuf1 = aBuf1.toString();
			send_byte = sBuf1.getBytes();
			dos.write(send_byte, 0, sBuf1.length());
			
			n = fis.read(data, 0, BUF_SIZE);
					
			while( n != -1)
			{
				dos.write(data, 0, n);
				n = fis.read(data, 0, BUF_SIZE);
			}

			n = dis.read(data3, 0, 3);

			String sAck = new String(data3);
			sAck = sAck.trim();

			if(sAck.equals("ACK")){
				return 0;
			}
			else{
				return -91;
			}
		} 
		catch(Exception e) {
			return -99;
		}
		finally {
			try { if(is != null) { is.close(); } } catch (IOException e) {is=null;}
			try { if(os != null) { os.close(); } } catch (IOException e) {os=null;}
			try { if(dis != null) { dis.close(); } } catch (IOException e) {dis=null;}
			try { if(dos != null) { dos.close(); } } catch (IOException e) {dos=null;}
			try { if(fis != null) { fis.close(); } } catch (IOException e) {fis=null;}
			try { if(socket != null) { socket.close(); } } catch (IOException e) {socket=null;}
		}
	}

	/***************************************************************************
	 * 등록관련정보조회 서블릿을 호출해서 User ID 조회 (주행거리/블랙박스 모바일웹)
	 * @param sms_ts_bvan
	 * @return
	 * @throws Exception
	 **************************************************************************/
	public Map<String, String> getEdmsIdForMobileWeb(String sms_ts_bvan) throws Exception {
		String url = EDMS_PRE_REG_SERVLET_URL + "?SysCode=MTD&KeyNo=" + sms_ts_bvan;
		
		byte[] rtnByte = HttpClientUtil.callUrlPost(url);

		String rtnXmlString = new String(rtnByte,"EUC-KR");
		logger.debug("rtnXmlString : " + rtnXmlString);
		
		Document doc = SoapUtil.stringToDocument(rtnXmlString);
		
		Map<String, String> map = new HashMap<String, String>();
		map.put("UsrId", ((Element)XPath.selectSingleNode(doc, "//UsrId")).getTextTrim());
		map.put("RtnCd", ((Element)XPath.selectSingleNode(doc, "//RtnCd")).getTextTrim());
		map.put("DocNo2", ((Element)XPath.selectSingleNode(doc, "//DocNo2")).getTextTrim());
		map.put("DocNo1", ((Element)XPath.selectSingleNode(doc, "//DocNo1")).getTextTrim());
		map.put("Message", ((Element)XPath.selectSingleNode(doc, "//Message")).getTextTrim());
		map.put("DocType", ((Element)XPath.selectSingleNode(doc, "//DocType")).getTextTrim());
		map.put("Index09", ((Element)XPath.selectSingleNode(doc, "//Index09")).getTextTrim());
		
		return map;
	}
	
	/***************************************************************************
	 * EDMS 로 파일 전송 - 주행거리
	 * @param file
	 * @return
	 * @throws Exception
	 **************************************************************************/
	public boolean fileSendToEdms2(File file, String edms_id, Map<String, String> map) throws Exception {
		if(!file.isFile()) {
			return false;
		}
		
		String edmsFilePath = "";

		edmsFilePath = EDMS_FILESERVER_PATH
			         + "/CK" 
			         + "/" + DateUtil.getYear()
			         + "/" + DateUtil.getMonth()
			         + "/dDIMSTmp"
			         + "/" + edms_id + "/"; 

		try {
			int returnCode = sendFile(edmsFilePath + file.getName(), file.getAbsolutePath(), EDMS_FILESERVER_IP, EDMS_FILESERVER_PORT);
						
			if(returnCode != 0) {
				if(map != null) map.put("MSG", String.valueOf(returnCode));				
				return false;
			}
		}
		catch(Exception e) {			
			return false;
		}

		return true;
	}
	
	public boolean docRegToEdms3(String edmsId, String fileName, Map<String, String> map, String exifDate, String plnoAndPlanNo) throws Exception {
		HttpClient client = new HttpClient();
				
		PostMethod httppost = new PostMethod(EDMS_STEP3_URL);
        httppost.setRequestHeader("Content-Type", "application/x-www-form-urlencoded; charset=euc-kr");
        httppost.addParameter("SysCode", "MTD");
        httppost.addParameter("UsrId", edmsId);

        if(plnoAndPlanNo.indexOf(",") > -1) {
        	String[] p = plnoAndPlanNo.split(",");
            httppost.addParameter("Index09", "CKB");
	        httppost.addParameter("DocNo1", p[0]);
	        httppost.addParameter("DocNo2", p[1]);
	        httppost.addParameter("DocType", "CKB008");
        }
        else {
            httppost.addParameter("Index09", "CKI");
	        httppost.addParameter("DocNo1", plnoAndPlanNo);
	        httppost.addParameter("DocNo2", "");
	        httppost.addParameter("DocType", "CKI002");
        }
        
        httppost.addParameter("FileName", fileName);
    	httppost.addParameter("Date", exifDate);
                       
        String resultText = "";
        
        try {
            client.executeMethod(httppost);
            if(httppost.getStatusCode() != 200) {
                throw new Exception(httppost.getStatusLine().toString());
            } 
            
            resultText = httppost.getResponseBodyAsString();
            logger.debug("resultText: " + resultText);

            String[] tmpArr = resultText.split("\\|");
            
            if(!tmpArr[0].equals("Y")) {
            	if(map != null) map.put("MSG", resultText);
            	return false;
            }
        }
        catch(Exception e) {
            return false;
        }
        finally {
            httppost.releaseConnection();
        }
        return true;
	}
	
	public boolean docRegToEdms4(String edmsId, String fileName, Map<String, String> map, String exifDate, String plnoAndPlanNo) throws Exception {
		HttpClient client = new HttpClient();
				
		PostMethod httppost = new PostMethod(EDMS_STEP3_URL);
        httppost.setRequestHeader("Content-Type", "application/x-www-form-urlencoded; charset=euc-kr");
        httppost.addParameter("SysCode", "MTD");
        httppost.addParameter("UsrId", edmsId);

        if(plnoAndPlanNo.indexOf(",") > -1) {
        	String[] p = plnoAndPlanNo.split(",");
            httppost.addParameter("Index09", "CKB");
	        httppost.addParameter("DocNo1", p[0]);
	        httppost.addParameter("DocNo2", p[1]);
	        httppost.addParameter("DocType", "CKB007");
        }
        else {
            httppost.addParameter("Index09", "CKI");
	        httppost.addParameter("DocNo1", plnoAndPlanNo);
	        httppost.addParameter("DocNo2", "");
	        httppost.addParameter("DocType", "CKI002");
        }
        
        httppost.addParameter("FileName", fileName);
    	httppost.addParameter("Date", exifDate);
                       
        String resultText = "";
        
        try {
            client.executeMethod(httppost);
            if(httppost.getStatusCode() != 200) {
                throw new Exception(httppost.getStatusLine().toString());
            } 
            
            resultText = httppost.getResponseBodyAsString();
            logger.debug("resultText: " + resultText);

            String[] tmpArr = resultText.split("\\|");
            
            if(!tmpArr[0].equals("Y")) {
            	if(map != null) map.put("MSG", resultText);
            	return false;
            }
        }
        catch(Exception e) {
            return false;
        }
        finally {
            httppost.releaseConnection();
        }
        return true;
	}	
	
	/***************************************************************************
	 * EDMS 아이디 조회 (OCR 만기정산)
	 * @return
	 * @throws Exception
	 **************************************************************************/
	public String getEdmsId(String id) throws Exception {
		String result = "";		
		
		HttpClient client = new HttpClient();
        PostMethod httppost = new PostMethod(EDMS_STEP1_URL); 
        httppost.setRequestHeader("Content-Type", "application/x-www-form-urlencoded; charset=utf-8"); 
        httppost.addParameter("Id", id); 
        
	    client.executeMethod(httppost);
	    
	    if(httppost.getStatusCode() != 200) {
	        throw new Exception(httppost.getStatusLine().toString());
	    }
	    
	    String[] tmpArr = ( httppost.getResponseBodyAsString() ).split("\\|");
	    result = tmpArr[0];
	
	    httppost.releaseConnection();

        return result;
	}	

}
