package com.idongbu.smartcustomer.counter.carRider.shortterm.vo;

public class PhoneVO {
	private String RECV_HP;
	private String SENDER_CD;
	private String SENDER_NA;
	private String SENDER_HP;
	private String BONBU_CD;
	private String JIJUM_CD;
	private String JUMPO_CD;
	private String SEND_NO;
	private String SEND_NM;
	private String AGC_CD;
	private int CF_CD;	
	private String AUTH_RES_CD;	
	private String AUTH_NUMBER;
	private String FIN_CD;
	
	public String getRECV_HP() {
		return RECV_HP;
	}
	public void setRECV_HP(String rECV_HP) {
		RECV_HP = rECV_HP;
	}
	public String getSENDER_CD() {
		return SENDER_CD;
	}
	public void setSENDER_CD(String sENDER_CD) {
		SENDER_CD = sENDER_CD;
	}
	public String getSENDER_NA() {
		return SENDER_NA;
	}
	public void setSENDER_NA(String sENDER_NA) {
		SENDER_NA = sENDER_NA;
	}
	public String getSENDER_HP() {
		return SENDER_HP;
	}
	public void setSENDER_HP(String sENDER_HP) {
		SENDER_HP = sENDER_HP;
	}
	public String getBONBU_CD() {
		return BONBU_CD;
	}
	public void setBONBU_CD(String bONBU_CD) {
		BONBU_CD = bONBU_CD;
	}
	public String getJIJUM_CD() {
		return JIJUM_CD;
	}
	public void setJIJUM_CD(String jIJUM_CD) {
		JIJUM_CD = jIJUM_CD;
	}
	public String getJUMPO_CD() {
		return JUMPO_CD;
	}
	public void setJUMPO_CD(String jUMPO_CD) {
		JUMPO_CD = jUMPO_CD;
	}
	public String getSEND_NO() {
		return SEND_NO;
	}
	public void setSEND_NO(String sEND_NO) {
		SEND_NO = sEND_NO;
	}
	public String getSEND_NM() {
		return SEND_NM;
	}
	public void setSEND_NM(String sEND_NM) {
		SEND_NM = sEND_NM;
	}
	public String getAGC_CD() {
		return AGC_CD;
	}
	public void setAGC_CD(String aGC_CD) {
		AGC_CD = aGC_CD;
	}
	public int getCF_CD() {
		return CF_CD;
	}
	public void setCF_CD(int cF_CD) {
		CF_CD = cF_CD;
	}
	public String getAUTH_RES_CD() {
		return AUTH_RES_CD;
	}
	public void setAUTH_RES_CD(String aUTH_RES_CD) {
		AUTH_RES_CD = aUTH_RES_CD;
	}
	public String getAUTH_NUMBER() {
		return AUTH_NUMBER;
	}
	public void setAUTH_NUMBER(String aUTH_NUMBER) {
		AUTH_NUMBER = aUTH_NUMBER;
	}
	public String getFIN_CD() {
		return FIN_CD;
	}
	public void setFIN_CD(String fIN_CD) {
		FIN_CD = fIN_CD;
	}
	
	
}
