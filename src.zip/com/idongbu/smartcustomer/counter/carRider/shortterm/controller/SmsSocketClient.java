package com.idongbu.smartcustomer.counter.carRider.shortterm.controller;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.idongbu.smartcustomer.counter.carRider.shortterm.vo.PhoneVO;

public class SmsSocketClient 
{
	protected final Log infoLogger 	= LogFactory.getLog("kakaodriver.info.log");
	
	String socketSeverIp = "";
	String socketSeverPort = "";
	
	String jobCd = "";
	String subJobCd = "";
	
	public SmsSocketClient(String socketSeverIp, String socketSeverPort,String jobCd,String subJobCd)
	{
		this.socketSeverIp   = socketSeverIp;
		this.socketSeverPort = socketSeverPort;
		this.jobCd           = jobCd;
		this.subJobCd        = subJobCd;	
	}
	
	public Map<String, String> authReq(PhoneVO phone)
	{
		boolean bRet = false;
		String sErrMsg = "";
		
		String uniqueCd = "";
		Map<String, String> result = new HashMap<String, String>();
		SimpleDateFormat format = new SimpleDateFormat("yyyyMMddHHmmss", Locale.KOREA);

		Socket socket = null;
		BufferedOutputStream bos = null;
		BufferedReader br = null;
		InputStreamReader isr = null;
		
		int CF_CD = 2;
		
		try 
		{
			infoLogger.info("socketClient ip : " + socketSeverIp +  ",port : " + this.socketSeverPort);
			
			socket = new Socket(this.socketSeverIp, Integer.parseInt(this.socketSeverPort));

			String RECV_HP = phone.getRECV_HP();

			String SENDER_CD = phone.getSENDER_CD();
			String SENDER_NA = phone.getSENDER_NA();
			String SENDER_HP = phone.getSENDER_HP();
			String BONBU_CD = phone.getBONBU_CD();
			String JIJUM_CD = phone.getJIJUM_CD();
			String JUMPO_CD = phone.getJUMPO_CD();
			String SEND_TIME = format.format(new Date());
			String SMS_KEY = SENDER_CD + RECV_HP + SEND_TIME;

			String FIN_CD  = phone.getFIN_CD();
			String SEND_NO = phone.getSEND_NO();
			String SEND_NM = phone.getSEND_NM();
			String AGC_CD = phone.getAGC_CD();
			String MSG_SMS = "[DB손해보험] 본인인증을 위해 필요한 인증번호(000000)를 입력해주세요";
			String AUTH_RES_CD = phone.getAUTH_RES_CD();
			String AUTH_NUMBER = phone.getAUTH_NUMBER();
			
			if (phone.getCF_CD() > 0) 
			{
				CF_CD = phone.getCF_CD();
			}
			
			String data = "REQ_TYPE:N1:1||SCHEDULE_TYPE:N1:0||SEND_TYPE:N1:0||PORDER:N3:999||RECV_HP:S12:"
					+ RECV_HP
					+ "||SEND_TIME:S14:" + SEND_TIME	//
					+ "||PA_HP:S12:" + SENDER_HP		//						
					+ "||SERVICE_CD:S6:" + jobCd					
					+ "||SUBSERVICE_CD:S6:" + subJobCd
					+ "||TIMESTAMP_KEY:S26:" + SEND_TIME//
					+ "||SENDER_CD:S8:" + SENDER_CD		//취급자 코드 없음
					+ "||SENDER_NA:S12:" + SENDER_NA	//취급자 이름 없음
					+ "||BONBU_CD:S4:" + BONBU_CD		//본부코드 없음
					+ "||JIJUM_CD:S4:" + JIJUM_CD		//지점코드 없음
					+ "||JUMPO_CD:S4:" + JUMPO_CD		//점포코드 없음
					+ "||SMS_KEY:S50:" + SMS_KEY		//SMS키
					+ "||CF_CD:N1:" + CF_CD				//본인인증 방식 수정으로 변경 CF_CD 2인증번호 발송 요청, 4 인증번호 검증
					+ "||GK_GB:N1:1"
					+ "||SEND_NO:S13:" + SEND_NO		//주민번호 13자리 
					+ "||SEND_NM:S12:" + SEND_NM		//
					+ "||MSG_SMS:S200:" + MSG_SMS		//					
					+ "||LICENSE:S10:" + subJobCd
					+ "||AGC_CD:S4:" + AGC_CD			//통신사
					+ "||FIN_CD:N1:" + FIN_CD;
			
			if (CF_CD == 4) 
			{
				data = data 
					+ "||AUTH_RES_CD:S24:" + AUTH_RES_CD
					+ "||AUTH_NUMBER:S6:" + AUTH_NUMBER;
			}
			
			data += "\n";

			infoLogger.info("socketClient requestData : " + data);		
			
			bos = new BufferedOutputStream(socket.getOutputStream());
			
			bos.write(data.getBytes("euc-kr"));
			bos.flush();
			
			isr = new InputStreamReader(socket.getInputStream());
			br = new BufferedReader(isr);

			StringBuffer sb = new StringBuffer();

			String tcpBuf = "";
			while ((tcpBuf = br.readLine()) != null) {
				sb.append(tcpBuf);
				if (tcpBuf.indexOf("}") > -1) {
					break;
				}
			}
			String resultMsg = sb.toString();
			
			infoLogger.info("socketClient resultMsg : " + resultMsg);
			
			resultMsg = resultMsg.substring(resultMsg.indexOf("{") + 1, resultMsg.indexOf("}"));
			String[] resultMsgs = resultMsg.split(",");
			
			String resCd = "";
			for (int k = 0; k < resultMsgs.length; k++) {
				String[] resultMsgSubs = resultMsgs[k].split("=");
				
				if(resultMsgSubs[0].trim().equals("resCd") || resultMsgSubs[0].trim().equals("retCd")) {
					resCd = resultMsgSubs[1].trim();
				}
				
				if (CF_CD == 2) {
					if(resultMsgSubs[0].trim().equals("uniqueCd"))
					{
						if(resultMsgSubs.length == 2)
							uniqueCd = resultMsgSubs[1].trim();
					}
				}
			}
			sErrMsg = getErrMsg(CF_CD,resCd);
			result.put("resCd", resCd);
			
			if(sErrMsg.length() == 0)
				bRet = true;
		} 
		catch (SocketTimeoutException e) 
		{
			System.out.println("SocketTimeoutException");
			sErrMsg = e.getMessage();
		} 
		catch (NumberFormatException e) 
		{
			System.out.println("NumberFormatException");			
			sErrMsg = e.getMessage();	
		}
		catch (UnknownHostException e) 
		{
			System.out.println("UnknownHostException");		
			sErrMsg = e.getMessage();
		}
		catch (IOException e) 
		{
			System.out.println("IOException");
			sErrMsg = e.getMessage();	
		}
		catch (Exception e) 
		{
			System.out.println("Exception");
			sErrMsg = e.getMessage();	
		}
		finally 
		{
			try 
			{
				if(bos != null)
					bos.close();
				if (br != null)
					br.close();
				if (isr != null)
					isr.close();
				if (socket != null)
					socket.close();
			}
			catch (Exception e) 
			{;}
			
			if(bRet)
			{
				result.put("resultYn", "Y");
				
				if(CF_CD == 2)
					result.put("uniqueCd", uniqueCd);
			}
			else
			{
				result.put("resultYn", "N");
				result.put("errMsg", sErrMsg);
			}
		}

		return result;
	}
	
	private String getErrMsg(int CF_CD,String resCd)
	{
		String sErrMsg = "";
		System.out.println("CF_CD : " + CF_CD + ", resCd : " + resCd);
		// 인증 키 발송 요청이면
		if(CF_CD == 2)
		{
			sErrMsg = "인증 키 발송 오류 : ";
			
			if(resCd.equals("0"))
			{ 
				sErrMsg = "";
			}
			else if(resCd.equals("1003"))
			{
				sErrMsg += "인증실패(PPS-선불통화서비스 가입자)";
			}
			else if(resCd.equals("1005"))
			{
				sErrMsg += "인증실패(법인 가입자)";
			}
			else if(resCd.equals("1006"))
			{
				sErrMsg += "인증실패(생년월일 불일치)";
			}
			else if(resCd.equals("1007"))
			{
				sErrMsg += "인증실패(성명 불일치)";
			}
			else if(resCd.equals("1014"))
			{
				sErrMsg += "인증실패(일시 정지 상태)";
			}
			else if(resCd.equals("1990"))
			{
				sErrMsg += "인증실패(SKT고객 아님)";
			}
			else if(resCd.equals("2021"))
			{
				sErrMsg += "인증실패(일시 정지 상태)";
			}
			else if(resCd.equals("2022"))
			{
				sErrMsg += "인증실패(법인 가입자)";
			}
			else if(resCd.equals("2023"))
			{
				sErrMsg += "인증실패(선불고객)";
			}
			else if(resCd.equals("2025"))
			{
				sErrMsg += "인증실패(KT고객 아님)";
			}
			else if(resCd.equals("2026"))
			{
				sErrMsg += "인증실패(생년월일 불일치)";
			}
			else if(resCd.equals("2027"))
			{
				sErrMsg += "인증실패(성명 불일치)";
			}
			else if(resCd.equals("3001"))
			{
				sErrMsg += "인증실패(생년월일 불일치)";
			}
			else if(resCd.equals("3003"))
			{
				sErrMsg += "인증실패(선불고객)";
			}
			else if(resCd.equals("3004"))
			{
				sErrMsg += "인증실패(법인 가입자)";
			}
			else if(resCd.equals("3005"))
			{
				sErrMsg += "인증실패(일시정지)";
			}
			else if(resCd.equals("3006"))
			{
				sErrMsg += "인증실패(LGT 고객 아님)";
			}
			else if(resCd.equals("3007"))
			{
				sErrMsg += "인증실패(성명 불일치)";
			}
			else
			{
				sErrMsg += "정의되지않은 에러";
			}
		}
		else
		{
			sErrMsg = "인증 키 체크 오류 : ";
			
			if(resCd.equals("0"))
			{
				sErrMsg = "";
			}
			else if(resCd.equals("0001"))
			{
				sErrMsg += "인증실패(인증정보 불일치)";
			}
			else if(resCd.equals("0031"))
			{
				sErrMsg += "인증실패(인증번호 확인불가-인증번호 만료)";
			}
			else if(resCd.equals("0032"))
			{
				sErrMsg += "인증실패(주민번호, CI 불일치)";
			}
			else if(resCd.equals("0033"))
			{
				sErrMsg += "인증실패(인증고유번호 불일치)";
			}
			else if(resCd.equals("0034"))
			{
				sErrMsg += "인증실패(기 인증 완료 건)";
			}
			else
			{
				sErrMsg += "정의되지않은 에러";
			}
		}
		return sErrMsg;
	}
}
