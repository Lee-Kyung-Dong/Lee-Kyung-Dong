package com.idongbu.smartcustomer.counter.carRider.shortterm.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.idongbu.common.SeedUtil;
import com.idongbu.smartcustomer.counter.carRider.shortterm.service.ShortService;
import com.idongbu.smartcustomer.counter.carRider.shortterm.vo.PhoneVO;
import com.idongbu.smartzone.vo.AACT0015VO;
import com.idongbu.smartzone.vo.AACT0019VO;
import com.idongbu.smartzone.vo.AACT0065VO;
import com.idongbu.smartzone.vo.MMTI0044VO;
import com.idongbu.smartzone.vo.MMTI0101VO;
import com.idongbu.smartzone.vo.MMTI0285VO;
import com.idongbu.smartzone.vo.MMTI0289VO;
import com.idongbu.util.DMEncDecUtil;
import com.idongbu.util.DateUtil;
import com.idongbu.util.StringUtil;
import com.raonsecure.transkey.TransKey;

@Controller
@RequestMapping("/mdbins/carrider/shortterm")
public class ShortController {
	
	@Autowired(required=true)
	private ShortService shortService;
	
	private @Value("${dm.aes.key}") String dmAesKey;
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());	

	/** 
	 * 계약정보 조회
	 * */
	@RequestMapping(value="/step1")
	public String step1(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		logger.info("### STEP 1 시작 ##########################");
		HttpSession session = request.getSession();
		MMTI0101VO mmti0101vo = new MMTI0101VO();
		Map<String, String> map = new HashMap<String, String>();

		String url_yn = "Y";
		logger.info("### 알림번호 복호화 전: " + request.getParameter("no"));
		String mbl_snd_no = aes256Decrypt(request.getParameter("no"));
		logger.info("### 알림번호 복호화 후: " + mbl_snd_no);
		if(mbl_snd_no.length() != 16 || mbl_snd_no == null){
			url_yn = "N";
		}
		else{
			MMTI0289VO mmti0289vo = new MMTI0289VO();
			mmti0289vo.setMbl_snd_no(mbl_snd_no);
			mmti0289vo = shortService.getMMTI0289VO(mmti0289vo);
			String plno = mmti0289vo.getPlan_plno();

			session.setAttribute("plno", plno);
			mmti0101vo.setPlno(plno);
			mmti0101vo.setBlco_bz_proc_dvn("11");
			mmti0101vo = shortService.getMMTI0101VO(mmti0101vo);
			logger.info("### 계약조회 MMTI0101 시작 ##########################");
			String z_resp_cd = mmti0101vo.getZ_resp_cd();
			String z_resp_msg = mmti0101vo.getZ_resp_msg();
			logger.info("##### z_resp_cd: " + z_resp_cd + " ##########################");
			logger.info("##### z_resp_msg: " + z_resp_msg + " ##########################");
			if("ZH799".equals(mmti0101vo.getZ_resp_cd())){
				map.put("z_resp_cd", z_resp_cd);
				map.put("z_resp_msg", z_resp_msg);
			}else{
				String dsgn_cd = mmti0101vo.getDsgn_cd();
				session.setAttribute("dsgn_cd", dsgn_cd);
				
				String end_dt = mmti0101vo.getArc_et();
				String dat_dt = getDayAfterTomorrow();
				String end_yn = "N";
				
				logger.debug("### 보험종기: " + end_dt + " ##########################");
				logger.debug("### 모레: " + dat_dt + " ##########################");
				
				int end = Integer.parseInt(end_dt);
				int dat = Integer.parseInt(dat_dt);
				
				// 보험종기 전전일까지만 가입 가능함
				if(end < dat){
					end_yn = "Y";
				}
				map.put("end_yn", end_yn);
				
				String arc_pd = mmti0101vo.getArc_pd().substring(0, 4)
						+ "." + mmti0101vo.getArc_pd().substring(4, 6)
						+ "." + mmti0101vo.getArc_pd().substring(6, 8);
				String arc_et = mmti0101vo.getArc_et().substring(0, 4)
						+ "." + mmti0101vo.getArc_et().substring(4, 6)
						+ "." + mmti0101vo.getArc_et().substring(6, 8);
				
				// 보종명
				map.put("inpd_nm", mmti0101vo.getInpd_nm());
				// 한글차량번호 -> 뒷두자리 마스킹
				map.put("hngl_vh_no", maskCarno(mmti0101vo.getHngl_vh_no()));
				// 보험기간시작일자
				map.put("arc_pd", arc_pd);
				// 보험기간종료일자
				map.put("arc_et", arc_et);
				// 계약상태명 
				map.put("ctc_stat_nm", mmti0101vo.getCtc_stat_nm());
				// 피보험자명 -> 가운데글자 마스킹
				map.put("ins_nm", maskNm(mmti0101vo.getIns_nm()));
				// 계약자명 -> 가운데글자 마스킹
				map.put("plhd_cust_nm", maskNm(mmti0101vo.getPlhd_cust_nm()));
				// 증번
				map.put("plno", plno);
			}
		}
		
		// 배서설계 불가능한 경우 제어
		// 1. 다른 계약변경 신청 진행중인 설계번호 있는 경우 -> MMTI0101전문 ZH799 떨어지는 경우 첫화면에서 제어 
		// 2. 취급자 해촉된 경우 -> 모바일앱과 동일한 고정취급자사번 사용함. 해촉되는 경우 없음
		map.put("url_yn", url_yn);
		model.addAttribute("vo", map);
		String view = "";
		view = "/counter/carrider/shortterm/st1";
		logger.info("### STEP 1 종료 ##########################");
		return view;
	}
	
	/** 
	 * 가입내역 조회
	 */
	@RequestMapping(value="/inquiry")
	public String inquiry(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		logger.info("### 가입내역 조회 시작 ##########################");
		// MMTI0285 운전자 한정 & 연령 특약 정보를 통해 이전 단기운전자특약 가입내역 조회
		// 계약기간 내 단기운전자확대 가입 횟수 제한 50회 라고함.. 

		HttpSession session = request.getSession();
		MMTI0101VO mmti0101vo = new MMTI0101VO();
		MMTI0285VO mmti0285vo = new MMTI0285VO();
		Map<String, String[]> map = new HashMap<String, String[]>();
		

		String plno = (String)session.getAttribute("plno");
		mmti0101vo.setPlno(plno);
		mmti0101vo.setBlco_bz_proc_dvn("11");
		mmti0101vo = shortService.getMMTI0101VO(mmti0101vo);
		
		String bse_dd = mmti0101vo.getArc_pd();
		// 보험기간시작일자(MMTI0285 IN 기준일 세팅용)
		String arc_trm_str_dt = mmti0101vo.getArc_pd();
		// 보험기간종료일자(MMTI0285 IN 기준일 세팅용)
		String arc_trm_fin_dt = mmti0101vo.getArc_et();

		// 가입내역조회 정보 담을 리스트들 생성
		// 한글차량번호, 상품명, 계약자, 피보험자, 시기, 종기, 증번 리스트 생성
		List<String> car_no_list = new ArrayList<String>();
        List<String> bj_nm_list = new ArrayList<String>();
        List<String> plhd_nm_list = new ArrayList<String>();
        List<String> ins_nm_list = new ArrayList<String>();
        List<String> str_dt_list = new ArrayList<String>();
        List<String> fin_dt_list = new ArrayList<String>();
        List<String> shtm_plno_list = new ArrayList<String>();
		
        for(int i=0; i<1; i++){
	        
			// MMTI0285 IN (기능키(조회:01), 증번, 기준일, 시작일자, 종료일자)
			mmti0285vo.setFunt_key("01");
			mmti0285vo.setPlno(plno);
			mmti0285vo.setBse_dd(bse_dd);
			mmti0285vo.setArc_trm_str_dt(arc_trm_str_dt);
			mmti0285vo.setArc_trm_fin_dt(arc_trm_fin_dt);
			
			// MMTI0285 가져옴, 필드 사용 시 운전자/연령 구분 주의
			mmti0285vo = shortService.getMMTI0285VO(mmti0285vo);
	
			// 운전자한정 & 연령특약 기간 각각 찾아서 겹치는 기간(=단기운전자 기간) 확인
			
			// 운전자한정 확인용 준비 (시작일자, 종료일자, 운전자한정특약코드, 리스트(누구나))
			String s_drvr_date = mmti0285vo.getArc_trm_str_dt();
			String e_drvr_date = mmti0285vo.getArc_trm_fin_dt();
			String drvr_code = mmti0285vo.getPlan_tty_mtt__drvr_rstc_tty_cd()[0]; 
			
			ArrayList<String> list_290001 = new ArrayList<String>();
			boolean isFirst = true;
			
			// 누구나운전 날짜를 290001리스트에 넣기
			int drvr_idx = 0;
			do{
				// 운전자한정특약 없는 경우
				if(mmti0285vo.getPlan_ftr_tty_drvr_mtt__apcn_bgn_dt().length == 0){
					// 가입 당시 운전자한정 누구나인 경우
					list_290001.add(s_drvr_date + e_drvr_date);
				} 
				// 운전자한정특약 있는 경우
				else{
					// 가입을 누구나/연령제한없음으로 하고, 추후 변경해 소급적용한 경우
					if(isFirst){
						e_drvr_date = mmti0285vo.getPlan_ftr_tty_drvr_mtt__apcn_bgn_dt()[drvr_idx];
						e_drvr_date = DateUtil.addDate(e_drvr_date, 2, +1);
						isFirst = false;
					} else{
						s_drvr_date = mmti0285vo.getPlan_ftr_tty_drvr_mtt__apcn_bgn_dt()[drvr_idx];
						s_drvr_date = DateUtil.addDate(s_drvr_date, 2, +1);
						e_drvr_date = mmti0285vo.getPlan_ftr_tty_drvr_mtt__apcn_fin_dt()[drvr_idx];
						drvr_code = mmti0285vo.getPlan_ftr_tty_drvr_mtt__drvr_rstc_tty_cd()[drvr_idx];
						drvr_idx++;
					}
					// 운전자한정특약 코드가 누구나인 경우
					if("290001".equals(drvr_code)){
						list_290001.add(s_drvr_date + e_drvr_date);
					}
				}
			} while(drvr_idx < mmti0285vo.getPlan_ftr_tty_drvr_mtt__apcn_bgn_dt().length);
	
			// 연령확인용 준비(시작일자, 종료일자, 연령한정특약코드, 리스트(전체연령))
			String s_ag_date = mmti0285vo.getArc_trm_str_dt();
			String e_ag_date = mmti0285vo.getArc_trm_fin_dt();
			String ag_code = mmti0285vo.getPlan_tty_mtt__ag_rstc_tty_cd()[0];
			ArrayList<String> list_290011 = new ArrayList<String>();
			isFirst = true;
			
			// 전연령 날짜를 290011리스트에 넣기
			int ag_idx = 0;
			do{
				// 연령한정특약 없는 경우
				if(mmti0285vo.getPlan_ftr_tty_ag_mtt__apcn_bgn_dt().length == 0){
					// 가입당시 전체 연령 운전인 경우
					if("290011".equals(ag_code)){
						list_290011.add(s_ag_date + e_ag_date);
					}
				}
				// 연령한정특약 있는 경우
				else{
					if(isFirst){
						e_ag_date = mmti0285vo.getPlan_ftr_tty_ag_mtt__apcn_bgn_dt()[ag_idx];
						e_ag_date = DateUtil.addDate(e_ag_date, 2, +1);
						isFirst = false;
					} else{
						s_ag_date = mmti0285vo.getPlan_ftr_tty_ag_mtt__apcn_bgn_dt()[ag_idx];
						s_ag_date = DateUtil.addDate(s_ag_date, 2, +1);
						e_ag_date = mmti0285vo.getPlan_ftr_tty_ag_mtt__apcn_fin_dt()[ag_idx];
						ag_code = mmti0285vo.getPlan_ftr_tty_ag_mtt__ag_rstc_tty_cd()[ag_idx];
						ag_idx++;
					}
					// 연령한정특약 코드가 전체연령인 경우
					if("290011".equals(ag_code)){
						list_290011.add(s_ag_date + e_ag_date);
					}
				}
			}
			
			// WHILE -> ag_idx가 적용개시일자(연령).length보다 작으면 계속 반복
			while(ag_idx < mmti0285vo.getPlan_ftr_tty_ag_mtt__apcn_bgn_dt().length);
			// 누구나(290001리스트) || 전연령(290011리스트)) 체크해서 가입이력 없으면 없으면 계속
			
			if(list_290001.size() == 0 || list_290011.size() == 0) continue;
			
			// 누구나 / 전연령 가입 건 수 체크
			// 각 특약의 겹치는 날짜(단기운전자 적용 기간)를 구하기
			// 연령 / 운전자 날짜가 다른 경우 확인하는 이유는
			// 최초가입 시 전연령/ 누구나 둘중 하나 기본에 추가 특약 가입한 경우 구하기 위함
			
			// max size: 전연령/누구나 리스트 중 큰 사이즈로 세팅
			int max_size = list_290001.size() > list_290011.size() ? list_290001.size() : list_290011.size();
			// idx 두개 세팅
			int idx_290001 = 0;
			int idx_290011 = 0;
			// WHILE(전연령<MAX && 누구나<MAX)
			while(idx_290001 < max_size && idx_290011 < max_size){
				// KCUS0006 에서 한글차량번호, 상품명, 계약자명, 피보험자명, 증권번호 가져옴
				// 마스킹 필요함
				car_no_list.add(maskCarno(mmti0101vo.getHngl_vh_no()));
				bj_nm_list.add(mmti0101vo.getInpd_nm());
				plhd_nm_list.add(maskNm(mmti0101vo.getPlhd_cust_nm()));
				ins_nm_list.add(maskNm(mmti0101vo.getIns_nm()));
				shtm_plno_list.add(mmti0101vo.getPlno());
				
				String date1 = (String)list_290001.get(idx_290001);
				String date11 = (String)list_290011.get(idx_290011);
				// IF(두 특약의 적용일자 같은 경우)
				if(date1.equals(date11)){
					// 시작일/종료일 리스트에 정보 담아주고 (일자 같아서 아무거나로 하면됨)
					String arc_pd = mmti0101vo.getArc_pd().substring(0, 4)
							+ "." + mmti0101vo.getArc_pd().substring(4, 6)
							+ "." + mmti0101vo.getArc_pd().substring(6, 8);
					String arc_et = mmti0101vo.getArc_et().substring(0, 4)
							+ "." + mmti0101vo.getArc_et().substring(4, 6)
							+ "." + mmti0101vo.getArc_et().substring(6, 8);
					
					str_dt_list.add(((String)list_290001.get(idx_290001)).substring(0, 4)
							+ "." + ((String)list_290001.get(idx_290001)).substring(4, 6)
							+ "." + ((String)list_290001.get(idx_290001)).substring(6, 8));
					fin_dt_list.add(((String)list_290001.get(idx_290001)).substring(8, 12)
							+ "." + ((String)list_290001.get(idx_290001)).substring(12, 14)
							+ "." + ((String)list_290001.get(idx_290001)).substring(14, 16));
					
					// 각 특약 idx++
					idx_290001++;
					idx_290011++;
				}
				// ELSE
				else{
					// 두 특약의 시기/종기 각각 담아두고 (총 4가지)
					int s_date1 = Integer.parseInt(date1.substring(0, 8));
					int e_date1 = Integer.parseInt(date1.substring(8, 16));
					int s_date11 = Integer.parseInt(date11.substring(0, 8));
					int e_date11 = Integer.parseInt(date11.substring(8, 16));
					
					// IF (누구나 종기 < 전연령 시기)
					if(e_date1 < s_date11){
						// 누구나 idx++
						idx_290001++;
						continue;
					}
					// ELSE IF (전연령 종기 < 누구나 시기)
					else if(e_date11 < s_date1){
						// -> 전연령 IDX++
						idx_290011++;
						continue;
					}
				
					// IF(누구나 시기 <= 전연령 시기) -> 시작일 리스트에 전연령 시기 담아줌
					// ELSE -> 시작일 리스트에 누구나 시기 담아줌
					str_dt_list.add((s_date1 <= s_date11 ? 
							date11.substring(0, 4) + "." + date11.substring(4, 6) + "." + date11.substring(6, 8) 
							: date1.substring(0, 4) + "." + date1.substring(4, 6) + "." + date1.substring(6, 8)));
					// IF(누구나 종기 <= 전연령 종기) -> 종료일 리스트에 누구나 종기 담아줌
					// ELSE -> 종료일 리스트에 전연령 종기 담아줌
					fin_dt_list.add((e_date1 <= e_date11 ? 
							date1.substring(8, 12) + "." + date1.substring(12, 14) + "." + date1.substring(14, 16)
							: date11.substring(8, 12) + "." + date11.substring(12, 14) + "." + date11.substring(14, 16)));
					
					// IF(누구나 종기 > 전연령 종기) -> 전연령 IDX++
					if(e_date1 > e_date11){
						idx_290011++;
					}
					// ELSE IF(누구나 종기 < 전연령 종기) -> 누구나 IDX++
					else if (e_date1 < e_date11) {
						idx_290001++;
					}
					// ELSE -> 누구나/전연령 둘다 IDX++
					else{
						idx_290001++;
						idx_290011++;
					}
				}
			} // WHILE END
        }
		int aSize = bj_nm_list.size();
		// 차량번호, 보종명, 계약자명, 피보험자명, 증번, 시작일, 종료일
		map.put("car_no", car_no_list.toArray(new String[aSize]));
		map.put("bj_nm", bj_nm_list.toArray(new String[aSize]));
		map.put("plhd_nm", plhd_nm_list.toArray(new String[aSize]));
		map.put("ins_nm", ins_nm_list.toArray(new String[aSize]));
		map.put("str_dt", str_dt_list.toArray(new String[aSize]));
		map.put("fin_dt", fin_dt_list.toArray(new String[aSize]));
		map.put("shtm_plno", shtm_plno_list.toArray(new String[aSize]));
		/*
		for (int i = 0; i < aSize; i++) {
			logger.debug(map.get("car_no")[i]);
			logger.debug(map.get("bj_nm")[i]);
			logger.debug(map.get("plhd_nm")[i]);
			logger.debug(map.get("ins_nm")[i]);
			logger.debug(map.get("str_dt")[i]);
			logger.debug(map.get("fin_dt")[i]);
			logger.debug(map.get("shtm_plno")[i]);
		}
		*/
		logger.debug("### aSize: " + aSize + " ##########################");
		model.addAttribute("shtmMap", map);
		model.addAttribute("aSize", aSize);
		
		String view = "";
		view = "/counter/carrider/shortterm/inquiry";
		logger.info("### 가입내역 조회 종료 ##########################");
		return view;
	}
	
	/** 
	 * 현재 가입사항 확인 및 변경사항 입력
	 * */
	@RequestMapping(value="/step2")
	public String step2(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		logger.info("### STEP 2 시작 ##########################");
		Map<String, String> map = new HashMap<String, String>();
		MMTI0101VO mmti0101vo = new MMTI0101VO();

		// 증번, 경계업무처리구분, 계약변경사유구분정정변경, 계약변경기준일

		HttpSession session = request.getSession();
		String plno = (String)session.getAttribute("plno");
		mmti0101vo.setPlno(plno);
		mmti0101vo.setBlco_bz_proc_dvn("11");
		mmti0101vo = shortService.getMMTI0101VO(mmti0101vo);
		
		String arc_pd = mmti0101vo.getArc_pd().substring(0, 4)
				+ "." + mmti0101vo.getArc_pd().substring(4, 6)
				+ "." + mmti0101vo.getArc_pd().substring(6, 8);
		String arc_et = mmti0101vo.getArc_et().substring(0, 4)
				+ "." + mmti0101vo.getArc_et().substring(4, 6)
				+ "." + mmti0101vo.getArc_et().substring(6, 8);
		
		// 한글차번, 보험기간, 운전자범위, 운전자 연령 
		String drvr_rstc_tty_nm = null;
		String ag_tty_nm = null;
		
		if("290012".equals(mmti0101vo.getAg_tty_cd())){
			ag_tty_nm = "만21세이상";
		}else if("290013".equals(mmti0101vo.getAg_tty_cd())){
			ag_tty_nm = "만22세이상";
		}else if("290014".equals(mmti0101vo.getAg_tty_cd())){
			ag_tty_nm = "만24세이상";
		}else if("290015".equals(mmti0101vo.getAg_tty_cd())){
			ag_tty_nm = "만26세이상";
		}else if("290098".equals(mmti0101vo.getAg_tty_cd())){
			ag_tty_nm = "만28세이상";
		}else if("290016".equals(mmti0101vo.getAg_tty_cd())){
			ag_tty_nm = "만30세이상";
		}else if("290017".equals(mmti0101vo.getAg_tty_cd())){
			ag_tty_nm = "만35세이상";
		}else if("290018".equals(mmti0101vo.getAg_tty_cd())){
			ag_tty_nm = "만43세이상";
		}else if("290019".equals(mmti0101vo.getAg_tty_cd())){
			ag_tty_nm = "만48세이상";
		}else if("290011".equals(mmti0101vo.getAg_tty_cd())){
			ag_tty_nm = "연령제한없이 운전";
		}
		else{
			ag_tty_nm = mmti0101vo.getAg_tty_cd();
		}
		
		if("290004".equals(mmti0101vo.getDrvr_rstc_tty_cd())){
			drvr_rstc_tty_nm = "가족한정외1인운전자추가";
		}else if("290002".equals(mmti0101vo.getDrvr_rstc_tty_cd())){
			drvr_rstc_tty_nm = "가족운전자한정운전";
		}else if("290003".equals(mmti0101vo.getDrvr_rstc_tty_cd())){
			drvr_rstc_tty_nm = "부부운전자한정운전";
		}else if("290009".equals(mmti0101vo.getDrvr_rstc_tty_cd())){
			drvr_rstc_tty_nm = "기명운전자1인한정운전";
		}else if("290006".equals(mmti0101vo.getDrvr_rstc_tty_cd())){
			drvr_rstc_tty_nm = "기명피보험자1인한정운전";
		}else if("290007".equals(mmti0101vo.getDrvr_rstc_tty_cd())){
			drvr_rstc_tty_nm = "지정운전자1인한정운전";
		}else if("290005".equals(mmti0101vo.getDrvr_rstc_tty_cd())){
			drvr_rstc_tty_nm = "가족및형제자매운전자한정운전";
		}else if("290001".equals(mmti0101vo.getDrvr_rstc_tty_cd())){
			drvr_rstc_tty_nm = "누구나운전";
		}else if("290008".equals(mmti0101vo.getDrvr_rstc_tty_cd())){
			drvr_rstc_tty_nm = "기명피보험자및기명1인운전자한정운전";
		}else if("290010".equals(mmti0101vo.getDrvr_rstc_tty_cd())){
			drvr_rstc_tty_nm = "기명운전자1인한정운전(영업용)";
		}else if("290085".equals(mmti0101vo.getDrvr_rstc_tty_cd())){
			drvr_rstc_tty_nm = "부부외1인한정";
		}else{
			drvr_rstc_tty_nm = mmti0101vo.getDrvr_rstc_tty_cd();
		}
		
		// 한글차량번호 -> 뒷두자리 마스킹
		map.put("hngl_vh_no", maskCarno(mmti0101vo.getHngl_vh_no()));
		// 보험기간시작일자
		map.put("arc_pd", arc_pd);
		// 보험기간종료일자
		map.put("arc_et", arc_et);
		// 운전자한정특약명
		map.put("drvr_rstc_tty_nm", drvr_rstc_tty_nm);
		// 연령특약명
		map.put("ag_tty_nm", ag_tty_nm);
		// 증번
		map.put("plno", plno);
		
		model.addAttribute("vo", map);
		String view = "";
		view = "/counter/carrider/shortterm/st2";
		logger.info("### STEP 2 종료 ##########################");
		return view;
	}
	/** 
	 * 보험료 산출 페이지 이동
	 * */
	@RequestMapping(value="/step3")
	public String step3(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		logger.info("### STEP 3 시작 ##########################");
		Map<String, String> map = new HashMap<String, String>();
		String sday = StringUtil.nvl(request.getParameter("sday"));
		String eday = StringUtil.nvl(request.getParameter("eday"));
		String tday = StringUtil.nvl(request.getParameter("tday"));
		// String plno = StringUtil.nvl(request.getParameter("plno"));
		HttpSession session = request.getSession();
		String plno = (String)session.getAttribute("plno");
		String drvr_nm = request.getParameter("drvr_rstc_tty_nm1");
		String ag_nm = request.getParameter("ag_tty_nm1");
		logger.info("### 선택한 시작일: " + sday + " ##########################");
		logger.info("### 선택한 종료일: " + eday + " ##########################");
		map.put("sday", sday);
		map.put("eday", eday);
		map.put("tday", tday);
		map.put("plno", plno);
		map.put("drvr_nm", drvr_nm);
		map.put("ag_nm", ag_nm);
		session.setAttribute("sday", sday);
		session.setAttribute("eday", eday);
		model.addAttribute("vo", map);
		String view = "";
		view = "/counter/carrider/shortterm/st3";
		logger.info("### STEP 3 종료 ##########################");
		return view;
	}
	
	/** 
	 * 보험료 산출
	 * */
	@RequestMapping(value="/step3_1")
	public @ResponseBody Map<String, String> step3_1(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		logger.info("### 보험료 산출 시작 ##########################");
		HttpSession session = request.getSession();
		Map<String, String> vo = new HashMap<String, String>();
		String sday = StringUtil.nvl(request.getParameter("sday"));
		String eday = StringUtil.nvl(request.getParameter("eday"));
		String tday = StringUtil.nvl(request.getParameter("tday"));
		// String plno = StringUtil.nvl(request.getParameter("plno"));
		String plno = (String)session.getAttribute("plno");
		String drvr_nm = request.getParameter("drvr_nm");
		String ag_nm = request.getParameter("ag_nm");
		
		// 보험료 산출 기준일은 선택한 특약 시작일의 전날로 넣어줘야됨
		SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
		Date date = format.parse(sday);
		Calendar cal = new GregorianCalendar(Locale.KOREA);
		cal.setTime(date);
		cal.add(Calendar.DATE, -1);
		String y_date = format.format(cal.getTime());
		logger.debug("### 시작일 전일 : " + y_date + " ##########################");
		session.setAttribute("y_date", y_date);
		
		MMTI0101VO mmti0101vo = new MMTI0101VO();
		mmti0101vo.setPlno(plno);
		mmti0101vo.setBlco_bz_proc_dvn("12");
		mmti0101vo.setCtrmf_rs_dvn_rsvn_chng("2");
		mmti0101vo.setCtrmf_bse_dd(y_date);
		mmti0101vo.setBsec_chng_fin_dt(eday);
		mmti0101vo.setAg_tty_cd("290011");
		mmti0101vo.setDrvr_rstc_tty_cd("290001");
		logger.debug("### 보험료산출전문(MMTI0101) 시작 ##########################");
		mmti0101vo = shortService.getMMTI0101VO(mmti0101vo);
		logger.debug("### 보험료산출전문(MMTI0101) 결과 errorCode: [ " + mmti0101vo.getErrorCode() + " ] ##########################");

		if(!("0".equals(mmti0101vo.getErrorCode()))){
			if("Z0009".equals(mmti0101vo.getZ_msg_cd())){
				vo.put("resultCode", "99");
			}
			else{
				vo.put("resultCode", mmti0101vo.getErrorCode());
			}
			vo.put("resultMessage", mmti0101vo.getZ_resp_msg());
		} else{
			vo.put("resultCode", mmti0101vo.getErrorCode());
			//vo.put("resultMessage", "납부하실 보험료를 안내해드리겠습니다.\n확인버튼을 누른 후 잠시만 기다려 주시기 바랍니다.");
		}
		
		if("변경된 사항이 없습니다.".equals(vo.get("resultMessage"))){
			vo.put("resultMessage", "해당기간에 이미 단기운전자 확대내역이 존재하여 선택하실 수 없습니다.\n자세한 내용은 계약담당자 또는 고객상담센터로 문의주시기 바랍니다.");
		}
		
		vo.put("plno", plno);
		vo.put("adc_prm", mmti0101vo.getAdc_prm());
		vo.put("adc_rtrn_dvn", mmti0101vo.getAdc_rtrn_dvn());
		
		sday = sday.substring(0, 4) + "." + sday.substring(4, 6) + "." + sday.substring(6, 8);
		eday = eday.substring(0, 4) + "." + eday.substring(4, 6) + "." + eday.substring(6, 8);
		
		session.setAttribute("sday", sday);
		session.setAttribute("eday", eday);
		session.setAttribute("adc_prm", mmti0101vo.getAdc_prm());
		vo.put("sday", sday);
		vo.put("eday", eday);
		vo.put("drvr_nm", drvr_nm);
		vo.put("ag_nm", ag_nm);
		logger.info("### 보험료 산출 종료 ##########################");
		return vo;
	}
	
	/** 
	 * 배서 설계 보관
	 * */
	@RequestMapping(value="/savePlan")
	public @ResponseBody Map<String, String> savePlan(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		logger.info("### 배서 설계 보관 시작 ##########################");
		Map<String, String> map = new HashMap<String, String>();
		HttpSession session = request.getSession();
		MMTI0101VO mmti0101vo = new MMTI0101VO();
		
		// String plno = StringUtil.nvl(request.getParameter("plno"));
		String plno = (String)session.getAttribute("plno");
		String sday = StringUtil.nvl(request.getParameter("sday"));
		String eday = StringUtil.nvl(request.getParameter("eday"));
		mmti0101vo.setPlno(plno);					// 증번
		mmti0101vo.setBlco_bz_proc_dvn("17");		// 경계업무처리구분 17: 배서설계보관
		mmti0101vo.setCtrmf_rs_dvn_rsvn_chng("2");  // 계약변경사유구분정정변경(1: 정정, 2: 변경)
		
		String y_date = (String)session.getAttribute("y_date");
		
		mmti0101vo.setCtrmf_bse_dd(y_date);			// 계약변경기준일(선택한 시작일 -1일)
		mmti0101vo.setBsec_chng_fin_dt(eday);		// 구간변경종료일자
		mmti0101vo.setAg_tty_cd("290011");			// 연령특약코드
		mmti0101vo.setDrvr_rstc_tty_cd("290001");	// 운전자한정특약코드
		
		// 12.16 취급자사번 수정
		// mmti0101vo.setDsgn_cd("80000040");
		mmti0101vo.setDsgn_cd((String)session.getAttribute("dsgn_cd"));
		
		mmti0101vo = shortService.getMMTI0101VO(mmti0101vo);
		if("0".equals(mmti0101vo.getErrorCode())){
			session.setAttribute("ctrmf_plan_no", mmti0101vo.getCtrmf_plan_no());
		}
		map.put("errCd", mmti0101vo.getErrorCode());
		map.put("returnMsg", mmti0101vo.getReturnMesssage());
		// logger.debug("### 배서설계번호: " + mmti0101vo.getCtrmf_plan_no() + " ##########################");
		logger.info("### 배서 설계 보관 종료 ##########################");
		return map;
	}
	
	
	/** 
	 * 결제정보 입력
	 * */
	@RequestMapping(value="/step4")
	public String step4(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		logger.info("### STEP 4 시작 ##########################");
		HttpSession session = request.getSession();
		String plno = (String)session.getAttribute("plno");
		String adc_prm  = StringUtil.nvl(request.getParameter("adc_prm11"));
		
		model.addAttribute("plno", plno);
		model.addAttribute("adc_prm", adc_prm);
		String view = "/counter/carrider/shortterm/st4";
		logger.info("### STEP 4 종료 ##########################");
		return view;
	}
	
	@RequestMapping(value="/step5")
	public String step5(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		logger.info("### STEP 5 시작 ##########################");
		Map<String, String> map = new HashMap<String, String>();
		HttpSession session = request.getSession();
		String plno = (String)session.getAttribute("plno");
		MMTI0044VO mmti0044vo = new MMTI0044VO();
		mmti0044vo.setPlno(plno);
		mmti0044vo = shortService.getMMTI0044VO(mmti0044vo);

		String plhd_tlno_2 = "";				// 계약자전화번호2
		String plhd_cd = "";					// 계약자주민번호(암호)
		
		plhd_cd = mmti0044vo.getPlhd_tlno_2();
		plhd_tlno_2 = mmti0044vo.getPlhd_tlno_2();
		
		map.put("plhd_tlno_2", plhd_tlno_2);
		map.put("plno", plno);
		model.addAttribute("vo", map);
		session.setAttribute("plhd_cd", plhd_cd);
		
		String view = "";
		view = "/counter/carrider/shortterm/st5";
		logger.info("### STEP 5 종료 ##########################");
		return view;
	}
	
	/** 
	 * 휴대폰 인증 - 인증번호 발송
	 * */
	@RequestMapping(value="/sendAuthSms")
	public @ResponseBody Map<String, String> sendAuthSms(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		logger.info("### 휴대폰 인증번호 발송 시작 ##########################");
		Map<String, String> map = new HashMap<String, String>();
		try {
			HttpSession session = request.getSession();
			String plno = (String)session.getAttribute("plno");
			MMTI0044VO mmti0044vo = new MMTI0044VO();
			mmti0044vo.setPlno(plno);
			mmti0044vo = shortService.getMMTI0044VO(mmti0044vo);

			String plhd_nme = "";					// 계약자성명
			String plhd_tlno_2 = "";				// 계약자전화번호2
			String plhd_cd = "";					// 계약자주민번호(암호)
			
			plhd_cd = mmti0044vo.getPlhd_cd();
			plhd_tlno_2 = mmti0044vo.getPlhd_tlno_2();
			plhd_nme = mmti0044vo.getPlhd_nme();
			
			// 본인인증에 담는 풀주민번호는 평문으로 담아야됨
			plhd_cd = SeedUtil.decrypt(plhd_cd);

			String mobileCarrier= StringUtil.nvl(request.getParameter("mobileCarrier"));
			String cust_clpno = StringUtil.nvl(request.getParameter("cust_clpno"));
			/*String move_tlcp_dvcd = StringUtil.nvl(request.getParameter("move_tlcp_dvcd"));*/
			logger.info("### 계약자번호: " + plhd_tlno_2 + " ##########################");
			logger.info("### 입력한번호: " + cust_clpno + " ##########################");
			
			/** 이행시 빼야됨 */
//			 plhd_tlno_2 = "01089219551";
			/** 이행시 빼야됨 */
			
			if(!plhd_tlno_2.equals(cust_clpno)){
				map.put("RESULT_CODE", "100");
				map.put("RESULT_MSG", "계약자 명의의 휴대폰을 통한 본인인증만 가능합니다.");	
			}else{
				PhoneVO phoneVO = new PhoneVO();
				
				phoneVO.setSENDER_CD("단기운전자특약");
				phoneVO.setSENDER_NA("DB손해보험");
				phoneVO.setSENDER_HP("1588-0100");
				phoneVO.setBONBU_CD("");
				phoneVO.setJIJUM_CD("");
				phoneVO.setJUMPO_CD("");
				phoneVO.setCF_CD(2);
				phoneVO.setFIN_CD("1"); 					// 0:생년월일 1:주민번호
				phoneVO.setAGC_CD(mobileCarrier);			// 통신사
				phoneVO.setRECV_HP(cust_clpno); 			// 수신자번호						
				
				/** 운영 시 */
				
				 phoneVO.setSEND_NO(plhd_cd); 				// 주민번호
				 phoneVO.setSEND_NM(plhd_nme); 				// 고객명
				// String smsIp = "10.10.150.122";
				// String smsPort = "2001";
				
				/** 운영 시 */
				
				/** 테스트 시 */
				
//				phoneVO.setSEND_NO("주민번호"); 		// 주민번호
//				phoneVO.setSEND_NM("박나눔"); 			// 고객명
				String smsIp = "10.10.86.88";
				String smsPort = "2001";
				
				/** 테스트 시 */				
				

				String jobCd = "MTI";
				String subJobCd = "MTI087";
				
				Map<String, String> result = null;
				boolean smsResult = false;
				
				SmsSocketClient smsSocketClient = new SmsSocketClient(smsIp, smsPort, jobCd, subJobCd);
				result = smsSocketClient.authReq(phoneVO);
				
				System.out.println("Result : " + result);
				
				String resultCode = result.get("resCd").toString();
				smsResult = result.get("resCd").equals("0");	//인증 문자 발송 성공 여부
				logger.info("### 인증문자발송 성공여부: " + smsResult);
				
				String smsResultMsg = "";
				
				if(smsResult){			
					smsResultMsg = "인증 번호 발송 성공";
					System.out.println("MultiPush Complieted0.11");			
					
					map.put("RESULT_CODE", "02");
					map.put("RESULT_MSG", "인증 번호 발송 성공");							
					map.put("uniqueCd", result.get("uniqueCd").toString());
	
				} else {
					smsResultMsg = result.get("errMsg").toString();
					
					if(resultCode.equals("1006") || resultCode.equals("2026") || resultCode.equals("3001"))
						smsResultMsg = "인증 키 발송 오류 : 인증실패(통신사 확인필요)";
					
					map.put("RESULT_CODE", "96");
					map.put("RESULT_CODE", resultCode);
					map.put("RESULT_MSG", smsResultMsg);	
				}
			}

		} catch (Exception e) {
			map.put("RESULT_CODE", "96");
			map.put("RESULT_MSG", " 인증 번호 발송 실패");	
		}
		logger.info("### 휴대폰 인증번호 발송 종료 ##########################");
		return map;
	}
	
	/** 
	 * 휴대폰 인증 - 인증번호 체크
	 * */
	@RequestMapping(value="/checkAuthSms")
	public @ResponseBody Map<String, String> checkAuthSms(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		logger.info("### 인증번호 체크 시작 ##########################");
		Map<String, String> map = new HashMap<String, String>();
		HttpSession session = request.getSession();
		String plno = (String)session.getAttribute("plno");

		MMTI0044VO mmti0044vo = new MMTI0044VO();
		mmti0044vo.setPlno(plno);
		mmti0044vo = shortService.getMMTI0044VO(mmti0044vo);
		
		String plhd_nme = mmti0044vo.getPlhd_nme();			// 계약자성명
		String plhd_tlno_2 = mmti0044vo.getPlhd_tlno_2();	// 계약자전화번호2
		String plhd_cd = mmti0044vo.getPlhd_cd();			// 계약자주민번호(암호)
		
		// 본인인증에 담는 풀주민번호는 평문으로 담아야됨
		plhd_cd = SeedUtil.decrypt(plhd_cd);
		
		// 순서대로 휴대폰번호, 통신사, 인증번호, 인증키
		String cust_clpno = StringUtil.nvl(request.getParameter("cust_clpno"));
		// String mobileCarrier = StringUtil.nvl(request.getParameter("mobileCarrier"));
		String verificationCode = StringUtil.nvl(request.getParameter("verificationCode"));
		String unique_cd = StringUtil.nvl(request.getParameter("unique_cd"));
		
		PhoneVO phoneVO = new PhoneVO();
		
		phoneVO.setSENDER_CD("단기운전자특약");
		phoneVO.setSENDER_NA("DB손해보험");
		phoneVO.setSENDER_HP("1588-0100");
		phoneVO.setBONBU_CD("");
		phoneVO.setJIJUM_CD("");
		phoneVO.setJUMPO_CD("");
		phoneVO.setCF_CD(4);						// 인증번호 검증
		phoneVO.setAUTH_NUMBER(verificationCode);	// 인증번호
		phoneVO.setAUTH_RES_CD(unique_cd);			// 인증고유번호 임시번호
		phoneVO.setFIN_CD("1");						// 인증방식(주민번호)
		phoneVO.setRECV_HP(cust_clpno); 			// 수신자번호
		
		/** 운영 시 */
		
		 phoneVO.setSEND_NO(plhd_cd);				// 주민번호
		 phoneVO.setSEND_NM(plhd_nme);				// 고객명
		// String smsIp = "10.10.150.122";
		// String smsPort = "2001";
		
		/** 운영 시 */
		
		
		/** 테스트 시 */
		
//		phoneVO.setSEND_NO("주민번호");		
//		phoneVO.setSEND_NM("박나눔");		
		String smsIp = "10.10.86.88";		
		String smsPort = "2001";
		
		/** 테스트 시 */
		
		
		String jobCd = "MTI";
		String subJobCd = "MTI087";
		
		Map<String, String> result = null;
		boolean smsResult = false;
		
		SmsSocketClient smsSocketClient = new SmsSocketClient(smsIp, smsPort, jobCd, subJobCd);
		result = smsSocketClient.authReq(phoneVO);
					
		smsResult = result.get("resCd").equals("0");
		
		if(smsResult){
			map.put("RESULT_MSG", "정상적으로 처리 되었습니다.");
			map.put("RESULT_CODE", "01");
		} else{
			// 인증실패
			map.put("RESULT_CODE", "90");
			map.put("RESULT_MSG", result.get("errMsg").toString());		
		}
		logger.info("### 인증번호 체크 종료 ##########################");
		return map;
	}
	
	
	/** 
	 * 결제정보입력 시 계약자명의 카드 맞는지 확인
	 * */
	@RequestMapping(value="/chkCrd")
	public @ResponseBody Map<String, String> chkCrd(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		logger.info("### 본인명의 카드정보 확인 시작 ##########################");
		Map<String, String> map = new HashMap<String, String>();
		HttpSession session = request.getSession();
		String plno = (String)session.getAttribute("plno");

		String crd_no1 = StringUtil.nvl(request.getParameter("crd_no1"));
		String crd_no2 = StringUtil.nvl(request.getParameter("crd_no2"));
		String crd_no3 = "";
		
		String name = request.getParameter("name");
		String hidden = request.getParameter("hidden");
		String hmac = request.getParameter("hmac");
		
		logger.info("### name: " + name + " ##########################");
		logger.info("### hidden: " + hidden + " ##########################");
		logger.info("### hmac: " + hmac + " ##########################");
		
		try {
			logger.info("### 보안키패드 try 시작 ##########################");
			crd_no3 = TransKey.decode(name, hidden, hmac, request);
			logger.info("### crd_no3: " + crd_no3 + " ##########################");
			logger.info("### 보안키패드 try 끝 ##########################");
		} catch (Exception e) {
			logger.info("### 보안키패드 catch ##########################");
			logger.debug(e.getMessage());
			crd_no3 = request.getParameter("crd_no3");
			logger.info("### crd_no3: " + crd_no3 + " ##########################");
		}
		
		String crd_no4 = StringUtil.nvl(request.getParameter("crd_no4"));
		String crd_no = crd_no1 + "" + crd_no2 + "" + crd_no3 + "" + crd_no4;
		String vlid_trm = StringUtil.nvl(request.getParameter("vlid_trm"));
		logger.info("#@#카번: " + crd_no);
		logger.info("#@#기간: " + vlid_trm);
		
		// 계약자 주민번호(생년월일) 가져오기
		MMTI0044VO mmti0044vo = new MMTI0044VO();
		mmti0044vo.setPlno(plno);
		mmti0044vo = shortService.getMMTI0044VO(mmti0044vo);
		String plhd_cd = SeedUtil.decrypt(mmti0044vo.getPlhd_cd());
		plhd_cd = plhd_cd.substring(0, 6);
		
		AACT0019VO aact0019vo = new AACT0019VO();
		aact0019vo.setCrd_no(crd_no);							// 카드번호
		aact0019vo.setVlid_trm(vlid_trm);						// 유효기간
		
		/** 운영 시 */
		aact0019vo.setRrno(plhd_cd);							// 생년월일
		/** 운영 시 */
		
		/** 테스트용(이행 시 제거) */
		// aact0019vo.setRrno("890815");			// 나눔 생년월일  
		// aact0019vo.setRrno("831115"); 			// 다이너스
		// aact0019vo.setRrno("730517");			// 아맥스
		/** 테스트용(이행 시 제거) */
		
		logger.debug("### AACT0019(결제정보입력-계약자명의확인) 시작 ##########################");
		aact0019vo = shortService.getAACT0019VO(aact0019vo);
		
		String msg_cd = aact0019vo.getMsg_cd();					// 메시지코드
		String msg_cn = aact0019vo.getMsg_cn();					// 메시지내용
		logger.info("### AACT0019 메시지코드: [ " + msg_cd + " ] ##########################");
		logger.info("### AACT0019 메시지내용: [ " + msg_cn + " ] ##########################");
		
		if(!msg_cd.equals("0000")){
			msg_cn = "계약자 본인 신용카드로만 결제 가능합니다.";
		}
		
		session.setAttribute("crd_no1", crd_no1);
		session.setAttribute("crd_no2", crd_no2);
		session.setAttribute("crd_no3", crd_no3);
		session.setAttribute("crd_no4", crd_no4);
		session.setAttribute("crd_no", crd_no);
		session.setAttribute("vlid_trm", vlid_trm);
		
		map.put("msg_cd", msg_cd);
		map.put("msg_cn", msg_cn);
		logger.info("### 본인명의 카드정보 확인 종료 ##########################");
		return map;
	}

	/** 
	 * 카드 인증
	 * */
	@RequestMapping(value="/checkAuthCrd")
	public @ResponseBody Map<String, String> checkAuthCrd(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		logger.info("### 카드 인증 시작 ##########################");
		Map<String, String> map = new HashMap<String, String>();
		HttpSession session = request.getSession();
		String plno = (String)session.getAttribute("plno");
	
		String crd_no1 = StringUtil.nvl(request.getParameter("crd_no1"));
		String crd_no2 = StringUtil.nvl(request.getParameter("crd_no2"));
		String crd_no3 = "";
		
		String name = request.getParameter("name");
		String hidden = request.getParameter("hidden");
		String hmac = request.getParameter("hmac");
		
		logger.info("### name: " + name + " ##########################");
		logger.info("### hidden: " + hidden + " ##########################");
		logger.info("### hmac: " + hmac + " ##########################");
		
		try {
			logger.info("### 보안키패드 try 시작 ##########################");
			crd_no3 = TransKey.decode(name, hidden, hmac, request);
			logger.info("### crd_no3: " + crd_no3 + " ##########################");
			logger.info("### 보안키패드 try 끝 ##########################");
		} catch (Exception e) {
			logger.info("### 보안키패드 catch ##########################");
			logger.debug(e.getMessage());
			crd_no3 = request.getParameter("crd_no3");
			logger.info("### crd_no3: " + crd_no3 + " ##########################");
		}
		
		String crd_no4 = StringUtil.nvl(request.getParameter("crd_no4"));
		String crd_no = crd_no1 + "" + crd_no2 + "" + crd_no3 + "" + crd_no4;
		String vlid_trm = StringUtil.nvl(request.getParameter("vlid_trm"));
		logger.debug("### 인증 카번: " + crd_no);
		logger.debug("### 인증 기간: " + vlid_trm);
		
		// 주민번호(생년월일) 가져오기
		MMTI0044VO mmti0044vo = new MMTI0044VO();
		mmti0044vo.setPlno(plno);
		mmti0044vo = shortService.getMMTI0044VO(mmti0044vo);
		String plhd_cd = SeedUtil.decrypt(mmti0044vo.getPlhd_cd());
		plhd_cd = plhd_cd.substring(0, 6);				
		
		AACT0019VO aact0019vo = new AACT0019VO();
		aact0019vo.setCrd_no(crd_no);			// 카드번호
		aact0019vo.setVlid_trm(vlid_trm);		// 유효기간
		
		/** 운영 시 */
		aact0019vo.setRrno(plhd_cd);			// 생년월일
		/** 운영 시 */
		
		/** 테스트용(이행 시 제거) */
		// aact0019vo.setRrno("890815");		// 나눔 생년월일  
		// aact0019vo.setRrno("831115");		// 다이너스
		// aact0019vo.setRrno("730517");		// 아맥스
		/** 테스트용(이행 시 제거) */
		
		logger.debug("### AACT0019(카드 본인인증) 시작 ##########################");
		aact0019vo = shortService.getAACT0019VO(aact0019vo);
		String msg_cd = aact0019vo.getMsg_cd();		// 메시지코드
		String msg_cn = aact0019vo.getMsg_cn();		// 메시지내용
		logger.info("### AACT0019 메시지코드: [ " + msg_cd + " ] ##########################");
		logger.info("### AACT0019 메시지내용: [ " + msg_cn + " ] ##########################");
		
		map.put("msg_cd", msg_cd);
		map.put("msg_cn", msg_cn);
		logger.info("### 카드 인증 종료 ##########################");
		return map;
	}
	
	@RequestMapping(value="/reqCrdPayment")
	public @ResponseBody Map<String, String> reqCrdPayment(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		logger.info("### 카드 결제 시작 ##########################");
		HttpSession session = request.getSession();
		Map<String, String> map = new HashMap<String, String>();
		String plno = (String)session.getAttribute("plno");
		logger.info("### plno:" + plno + " ##########################");
		
		AACT0015VO aact0015vo = new AACT0015VO();
		AACT0065VO aact0065vo = new AACT0065VO();
		
		// 주민번호 가져오기
		MMTI0044VO mmti0044vo = new MMTI0044VO();
		mmti0044vo.setPlno(plno);
		mmti0044vo = shortService.getMMTI0044VO(mmti0044vo);
		
		String crd_no = (String)session.getAttribute("crd_no1") + (String)session.getAttribute("crd_no2") + (String)session.getAttribute("crd_no3") + (String)session.getAttribute("crd_no4"); 
		
		logger.debug("### 카드번호(crd_no): " + crd_no + " ##########################");
		crd_no = SeedUtil.encrypt(crd_no);
		logger.debug("### (암호화)카드번호(crd_no): " + crd_no + " ##########################");
		
		String ins_cd = mmti0044vo.getIns_cd();
		logger.debug("### (암호화)피보험자 주민번호(ins_cd): " + ins_cd + " ##########################");
		
		String plhd_cd = mmti0044vo.getPlhd_cd();
		logger.debug("### (암호화)계약자주민번호(plhd_cd): " + plhd_cd + " ##########################");
		
		String adc_prm = (String)session.getAttribute("adc_prm");
		logger.debug("### 보험료(adc_prm): " + adc_prm + " ##########################");
		
		String vlid_trm = (String)session.getAttribute("vlid_trm");
		logger.debug("### 유효기간(vlid_trm): " + vlid_trm + " ##########################");
		
		String chn_crd_ap_key = createCardApKey(SeedUtil.decrypt(plhd_cd).substring(0, 6));
		logger.info("### 채널카드승인키(chn_crd_ap_key): " + chn_crd_ap_key + " ##########################");
		
		String rrno = SeedUtil.decrypt(plhd_cd).substring(0, 6);
		rrno = SeedUtil.encrypt(rrno);
		
		
		/** 테스트용(이행 시 제거) */
		/*
		ins_cd = SeedUtil.encrypt("8908151406316");
		plhd_cd = SeedUtil.encrypt("8908151406316");
		rrno = SeedUtil.encrypt("890815");
		chn_crd_ap_key = createCardApKey("890815");
		*/
		/*
		// 다이너스 14자리
		ins_cd = SeedUtil.encrypt("8311151030613");
		plhd_cd = SeedUtil.encrypt("8311151030613");
		rrno = SeedUtil.encrypt("831115");
		chn_crd_ap_key = createCardApKey("831115");
		*/
		/*
		// 아맥스 15자리
		ins_cd = SeedUtil.encrypt("7305172533611");
		plhd_cd = SeedUtil.encrypt("7305172533611");
		rrno = SeedUtil.encrypt("730517");
		chn_crd_ap_key = createCardApKey("730517");
		*/
		/** 테스트용(이행 시 제거) */
		
		aact0015vo.setAct_ocr_dvcd("01");					// 구분(01:자동차) -> 필수는 아님
		aact0015vo.setDgs_amt(adc_prm);						// 결제금액
		
		// 12.16 취급자사번 수정
		// aact0015vo.setOrmm_no("80000040");				// 조직원번호(설계자코드)
		aact0015vo.setOrmm_no((String)session.getAttribute("dsgn_cd"));
		
		aact0015vo.setVlid_trm(vlid_trm);					// 유효기간
		aact0015vo.setAllt_trm("00");						// 할부기간
		aact0015vo.setBz_slc("1");							// 1:승인 2:취소
		aact0015vo.setBz_dvn("3");							// 업무구분(배서)
		// aact0015vo.setPlhd_no_yn("");					// 계약자번호존재유무(Y=1, N=0)
		aact0015vo.setCrd_no(crd_no);						// 카드번호(암호)
		aact0015vo.setIns_dcmt_no(ins_cd);					// 피보험자주민(암호)
		aact0015vo.setPlhd_dcmt_no(plhd_cd);				// 계약자주민(암호)	
		aact0015vo.setRrno(rrno);							// 주민(평문)
		aact0015vo.setChn_crd_ap_key(chn_crd_ap_key);		// 채널카드승인키(평문)	
		
		
		logger.debug("### 카드승인 AACT0015 시작 ##########################");
		aact0015vo = shortService.getAACT0015VO(aact0015vo);
		
		String resultCode = "";
		String resultMessage = "";
		String msg_cn = "";
		String crdt_crd_ap_yn = "";
		String nrm_proc_yn = "";
		String ap_dttm = "";
		
		if("0".equals(aact0015vo.getErrorCode())){
			logger.info("### 카드승인 errorCode = 0 ##########################");
			if("ZH799".equals(aact0015vo.getZ_resp_cd()) || !"0000".equals(aact0015vo.getMsg_cd())){
				// 카드승인 실패 - 에러코드 ZH799 또는 msg_cd가 0000 아닌 경우
				resultCode = "99";
				// resultMessage = aact0015vo.getMsg_cn();
				resultMessage = "해당계약은 단기운전자 확대가입 불가합니다. 자세한 사항은 계약담당자 또는 고객담당센터로 문의주시기 바랍니다.";
				logger.info("### 카드승인 z_resp_cd = ZH799 OR msg_cd != 0000 의 msg_cn: [ " + msg_cn + " ] ##########################");
			} else if("ZH605".equals(aact0015vo.getMsg_cd())){
				// 카드승인 실패 - ZH605
				logger.info("### 카드승인 msg_cd = ZH605 ##########################");
				resultCode = "99";
				// resultMessage = "죄송합니다. 카드승인이 실패하였습니다. 처음부터 다시 시도하여 주십시요.";
				resultMessage = "해당계약은 단기운전자 확대가입 불가합니다. 자세한 사항은 계약담당자 또는 고객담당센터로 문의주시기 바랍니다.";
				msg_cn = "시스템 오류(서버오류)에 따른 카드승인 실패";
			} else{
				// 카드승인 정상
				resultCode = "0";
				resultMessage = "정상 처리되었습니다.";
				String act_dd = getDayTime("1");
				String cltd_dd = getDayTime("1");
				String cltd_hmns = getDayTime("2");
				session.setAttribute("act_dd", act_dd);
				session.setAttribute("cltd_dd", cltd_dd);
				session.setAttribute("cltd_hmns", cltd_hmns);
				msg_cn = aact0015vo.getReturnMessage();
				crdt_crd_ap_yn = "1";
				nrm_proc_yn = "1";
				ap_dttm = ""; // DateUtil.getDatetime().replaceAll(":", "")
				// 승인관리번호 세션에 넣어줌
				session.setAttribute("crd_ap_mngt_no", aact0015vo.getAp_mngt_no());
				logger.info("### 카드승인 정상 ### 승인관리번호: [ " + aact0015vo.getAp_mngt_no() + " ] ##########################");
			} 
		} else{
			// 카드승인 실패 - 에러코드 0 아닐때
			logger.info("### 카드승인 errorCode != 0 ##########################");
			resultCode = "99";
			// resultMessage = "죄송합니다. 카드승인이 실패하였습니다. 처음부터 다시 시도하여 주십시요.";
			resultMessage = "해당계약은 단기운전자 확대가입 불가합니다. 자세한 사항은 계약담당자 또는 고객담당센터로 문의주시기 바랍니다.";
			msg_cn = aact0015vo.getMsg_cn();
		}
		
		String isu_cdcp_cd = aact0015vo.getCrd_isu_cmy_cd();
		String isu_cdcp_nm = aact0015vo.getCrd_isu_cmy_nm();
		String ap_mngt_no = aact0015vo.getAp_no();
		//String plan_no = (String)session.getAttribute("ctrmf_plan_no");
		String ctrmf_plan_no = (String)session.getAttribute("ctrmf_plan_no");
		String dcp_empno = (String)session.getAttribute("dsgn_cd");
		String crd_ap_mngt_no = (String)session.getAttribute("crd_ap_mngt_no");
		String act_dd = (String)session.getAttribute("act_dd");
		String cltd_dd = (String)session.getAttribute("cltd_dd");
		String cltd_hmns = (String)session.getAttribute("cltd_hmns");
		
		// 카드승인 정상
		if("0".equals(resultCode)){
			// 배서확정
			// AACT0065
			aact0065vo.setProc_dvn("D");							// 처리구분
			aact0065vo.setCtrmf_plan_no(ctrmf_plan_no);				// 배서설계번호
			aact0065vo.setPlno(plno);								// 증번
			// aact0065vo.setRecp_no("");							// 영수증번호
			aact0065vo.setOrmm_cd("80000040");						// 조직원코드	
			aact0065vo.setAct_dd(act_dd);							// 회계일
			aact0065vo.setCltd_dd(cltd_dd);							// 영수년월일
			aact0065vo.setCltd_hmns(cltd_hmns);						// 영수시분초
			aact0065vo.setCltd_prm(adc_prm);						// 영수보험료
			aact0065vo.setMntp_dvn("2");							// 금종구분(2: 카드)
			aact0065vo.setCrd_ap_mngt_no(crd_ap_mngt_no);			// 승인관리번호
			aact0065vo.setNstl_str_orr("1");						// 카드확정:1
			aact0065vo.setNstl_fin_orr("1");						// 카드확정:1
			aact0065vo.setBz_dvn("3");								// 업무구분 3: 배서
			aact0065vo.setDcp_empno(dcp_empno);						// 설계자사번
			logger.debug("### 카드확정 AACT0065 시작!! ### 변경설계번호: [" + ctrmf_plan_no + "] ##########################");
			aact0065vo = shortService.getAACT0065VO(aact0065vo);
			
			if("0".equals(aact0065vo.getErrorCode())){
				logger.info("### 배서 확정 성공 ### 변경설번: [" + ctrmf_plan_no + "] ##########################");
			} else{
				logger.info("### 배서 확정 실패 ### 변경설번: [" + ctrmf_plan_no + "] ### 에러코드 및 메시지: [" + aact0065vo.getErrorCode() + ", " + aact0065vo.getZ_resp_msg() + "]");
			}
			
			// 카드출금 확정처리 후 배서정보 갱신
			int retVal = -1; // 확정전문 성공 시 0으로 세팅하고, 실패 시 해당값으로 카드취소 요청
			if("ZH001".equals(aact0065vo.getZ_resp_cd())){
				logger.info("### 카드확정전문 z_resp_cd == ZH001 ##########################");

				retVal = 0; // 확정전문 성공이므로 카드취소 수행하지않음
			} else{ // 배서 확정 실패시
				logger.info("### 카드확정전문 z_resp_cd != ZH001 ##########################");
				// 카드배서확정전문실패 및 카드취소프로세스 실행 문자발송 
			}
			if(retVal<0){
				// 카드 취소 수행
				logger.debug("### AACT0015 카드 취소 수행!! ##########################");
				AACT0015VO aact0015vo2 = new AACT0015VO();
				aact0015vo2.setBz_slc("2"); 					// 업무선택(1:승인, 2:취소)
				
				// 12.16 취급자사번 수정
				// aact0015vo.setOrmm_no("80000040");					// 조직원번호(설계자코드)
				aact0015vo2.setOrmm_no((String)session.getAttribute("dsgn_cd"));
		        
		        aact0015vo2.setCrd_no(crd_no); 					// 카드번호
		        aact0015vo2.setRrno(plhd_cd);					// 주민번호(생년월일)
		        aact0015vo2.setVlid_trm(vlid_trm);				// 유효기간
		        aact0015vo2.setAllt_trm("00"); 					// 할부기간 
		        aact0015vo2.setDgs_amt(adc_prm); 				// 거래금액
		        aact0015vo2.setBz_dvn("3"); 					// 업무구분
		        aact0015vo2.setIns_dcmt_no(ins_cd); 			// 주민번호 (ENC)
		        aact0015vo2.setPlhd_dcmt_no(plhd_cd); 			// 주민번호 (ENC)
		        aact0015vo2.setChn_crd_ap_key(chn_crd_ap_key);  // 채널카드승인키
				
		        logger.debug("### 회계결제 신용카드 취소 전문 호출");
				aact0015vo2 = shortService.getAACT0015VO(aact0015vo2);
				logger.debug("### 회계결제 신용카드 취소 전문 호출 결과 : " + aact0015vo2.getZ_resp_cd());
				
				resultCode = "99";
				// resultMessage = "계약 확정 중 오류가 발생하였습니다.";
				resultMessage = "해당계약은 단기운전자 확대가입 불가합니다. 자세한 사항은 계약담당자 또는 고객담당센터로 문의주시기 바랍니다.";
				
				if(!"ZH001".equals(aact0015vo2.getZ_resp_cd()) && !"0000".equals(aact0015vo2.getMsg_cd())){
					logger.debug("### 카드취소 z_resp_cd != ZH001 OR msg_cd != 0000 ###");
					logger.info("### 카드취소 전문 실패 ##### 변경설계번호: [" + ctrmf_plan_no + "] ######");
					// 연락처, 이름, 주민번호 등등 계약자 정보
					// logger.debug("### 카드취소 전문 실패 ##### 변경설계번호: [" + ctrmf_plan_no + "] ######");
					resultCode = "98";
					// resultMessage = "계약 확정 중 오류가 발생하였습니다. 카드결제 취소에 실패하였습니다. 해당 채널카드승인키와 함께 담당자에게 문의바랍니다.<br>[채널카드승인키: " + chn_crd_ap_key + " ]";
					resultMessage = "해당계약은 단기운전자 확대가입 불가합니다. 자세한 사항은 계약담당자 또는 고객담당센터로 문의주시기 바랍니다.";
				}else{
					logger.info("### 카드취소 전문 성공 ##### 변경설계번호: [" + ctrmf_plan_no + "] ######");	
				}
			} else{
				// 변경 확정 정상적으로 된 경우
				logger.info("### 카드승인 및 배서확정 성공 ##### 변경설계번호: [" + ctrmf_plan_no + "] ######");
				resultCode = "0";
				resultMessage = "정상 처리되었습니다.";
			}
		}
		//카드승인 resultCode가 0이 아닌 경우
		else{	
			// 카드결제 실패
			logger.info("### 카드승인전문 resultCode != 0, ##### 변경설계번호: [" + ctrmf_plan_no + "] ######");
			logger.error("계약 확정중 오류가 발생하였습니다.");
			resultCode = "99";
			// resultMessage = "계약 확정 중 오류가 발생하였습니다.";
			resultMessage = "해당계약은 단기운전자 확대가입 불가합니다. 자세한 사항은 계약담당자 또는 고객담당센터로 문의주시기 바랍니다.";
		}
		logger.info("### 단기운전자 확대가입 카드출금 프로세스 종료 ##########################");
		
		// 챗봇쪽은 AACT0015 -> ZH6XX, AACT0065 -> ZH001 아닐때 취소요청함
		

		logger.info("### 카결결코드: [ " + resultCode + " ] ######");
		logger.info("### 카결결메시지: [ " + resultMessage + " ] ######");
		
		map.put("resultCode", resultCode);
		map.put("resultMessage", resultMessage);
		
		logger.info("### 카드 결제 종료 ##########################");
		return map;
	}
	
	
	
	/** 
	 * 완료 페이지
	 * */
	@RequestMapping(value="/step6")
	public String step6(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		logger.info("### STEP 6 시작 ##########################");
		HttpSession session = request.getSession();

		String sday = (String)session.getAttribute("sday");
		String eday = (String)session.getAttribute("eday");

		model.addAttribute("sday", sday);
		model.addAttribute("eday", eday);
		session.invalidate();
		String view = "";
		view = "/counter/carrider/shortterm/st6";
		logger.info("### STEP 6 종료 ##########################");
		return view;
	}
	
	
	private String getDayAfterTomorrow() throws Exception{
		logger.info("### getDayAfterTomorrow() 시작 ##########################");
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		Date curr = new Date();
		Calendar cal = new GregorianCalendar(Locale.KOREA);
		cal.setTime(curr);
		cal.add(Calendar.DATE, +2);
		return dateFormat.format(cal.getTime());
	}
	
	private String createCardApKey(String plhd_cd) throws Exception{
		logger.info("### createCateApKey() 시작 ##########################");
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmssSSS", Locale.KOREAN);
		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		// dateFormat.format(timestamp);
		
		return "XSMZ" + plhd_cd + dateFormat.format(timestamp);
	}
	
	private String getDayTime(String val) throws Exception{
		logger.info("### getDayTime() 시작 ##########################");
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss", Locale.KOREAN);
		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		if("1".equals(val)){
			return dateFormat.format(timestamp).substring(0, 8);
		} else if("2".equals(val)){
			return dateFormat.format(timestamp).substring(8, 14);
		} else{
			return "";
		}
	}
	
	private String maskCarno(String var){
		return var.replaceAll("(.{2}$)", "**");
	}
	
	private String maskNm(String var){
			var = strMiddleMasking(var, 1, 1);
			return var;
	}
	
	public static String strMiddleMasking(String str, int sPos, int len) {
		int ePos = sPos + len;
		if (str.length() >= ePos ) {
			str = str.trim();
			String aster = "";
			for (int i = 0; i < len; i++)
				aster += "*";
			str = str.substring(0, sPos) + aster + str.substring(ePos, str.length());
		}
		return str;
	}
	
	private String aes256Decrypt(String enc) {
		logger.debug("### AES256 복호화 시작 ##########################");
		String dec = "";
		String encKey = dmAesKey;
		
		try {
			dec = DMEncDecUtil.decAES256(enc, null, null, encKey);
		}
		catch(Exception e) {
			logger.debug("DMEncDecUtil.decAES256 실패 시 js로 복호화");
			
			String path = this.getClass().getResource("").getPath();
			logger.debug(path);
			
			BufferedReader in = null;
			
			try {
				String aesJs = path.substring(0, path.indexOf("/classes/")) + "/aes/gibberish-aes.js";
				if(aesJs.startsWith("/")) aesJs = aesJs.substring(1);
				String cmd = "cscript " + aesJs + " " + encKey  + " " + enc;
				logger.debug("cmd: " + cmd);
				Process p = Runtime.getRuntime().exec(cmd);
				in = new BufferedReader(new InputStreamReader(p.getInputStream()));
		
				String line = null;
				boolean flag = false;
				while (true) {
					line = in.readLine();
					if(line == null) break;
					logger.debug(line);
					dec = line;
					if(flag) break;
					if(dec.startsWith("enc: ")) flag = true;
				}
				
				if(dec.startsWith("enc: ")) {
					dec = dec.substring(5);
				}
		
				in.close();
				in = null;
			}
			catch(Exception e1) {
				return null;
			}
			finally {
				try{
					if(in!=null){
						in.close();
					}
				}
				catch(IOException ee){
					System.err.println("[ShortController.aes256Decrypt()] IOException 발생");
			    }
			}
		}
		return dec;
	}
}
