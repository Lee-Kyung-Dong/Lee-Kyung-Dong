package com.idongbu.smartcustomer.counter.carRider.shortterm.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.idongbu.common.ESBBizHeader;
import com.idongbu.common.ESBChannelHeader;
import com.idongbu.common.ESBManager;
import com.idongbu.common.XmlUtil;
import com.idongbu.smartzone.vo.AACT0015VO;
import com.idongbu.smartzone.vo.AACT0019VO;
import com.idongbu.smartzone.vo.AACT0065VO;
import com.idongbu.smartzone.vo.KCUS0006VO;
import com.idongbu.smartzone.vo.MMTI0044VO;
import com.idongbu.smartzone.vo.MMTI0101VO;
import com.idongbu.smartzone.vo.MMTI0285VO;
import com.idongbu.smartzone.vo.MMTI0289VO;

@Service
public class ShortService {
	
	private @Value("${legacy.homepage_jojikwon_cd}") String HOMEPAGE_JOJIKWON_CD;
	private @Value("${esb.Realip}") String ESBURL;
	private @Value("${dm.aes.key}") String dmAesKey;
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@SuppressWarnings("static-access")
	public KCUS0006VO getKCUS0006VO(KCUS0006VO kcus0006vo) throws Exception {
		String UserId = HOMEPAGE_JOJIKWON_CD;                                                                                                                                                                                           
		String formId = "KCUS0006";                                                                                                                                                                                           
		String telegram = "KCUS"; // esb                                                                                                                                                                                      
		                                                                                                                                                                                                                      
		ESBManager em = new ESBManager();                                                                                                                                                                                     
		ESBChannelHeader channelHead = new ESBChannelHeader();                                                                                                                                                                
		ESBBizHeader bizHead = new ESBBizHeader();     
		
		bizHead = em.makeDefaultBizHeader(UserId);                                                                                                                                                                            
		channelHead = em.makeDefaultChannelHeader(formId, UserId);  
		String Url = ESBURL;
		logger.debug("Url: " + Url);
		String rtnXmlString = (String)XmlUtil.callESBToString(channelHead, bizHead, kcus0006vo, Url, telegram);                                                                                                                   
		                                                                                                                                                                                                                      
		logger.debug("##############################");                                                                                                                                                                       
		logger.debug(rtnXmlString);                                                                                                                                                                                           
		logger.debug("##############################");                                                                                                                                                                       
		                                                                                                                                                                                                                      
		kcus0006vo = (KCUS0006VO) ESBManager.xmlToVOnew(rtnXmlString, (KCUS0006VO)kcus0006vo);                                                                                                                      
		                                                                                                                                                                                                                      
		return kcus0006vo;
	}
	
	@SuppressWarnings("static-access")
	public MMTI0285VO getMMTI0285VO(MMTI0285VO mmti0285vo) throws Exception {
		String UserId = HOMEPAGE_JOJIKWON_CD;                                                                                                                                                                                           
		String formId = "MMTI0285";                                                                                                                                                                                           
		String telegram = "MMTI"; // esb                                                                                                                                                                                      
		                                                                                                                                                                                                                      
		ESBManager em = new ESBManager();                                                                                                                                                                                     
		ESBChannelHeader channelHead = new ESBChannelHeader();                                                                                                                                                                
		ESBBizHeader bizHead = new ESBBizHeader();     
		
		bizHead = em.makeDefaultBizHeader(UserId);                                                                                                                                                                            
		channelHead = em.makeDefaultChannelHeader(formId, UserId);  
		String Url = ESBURL;
		logger.debug("Url: " + Url);
		String rtnXmlString = (String)XmlUtil.callESBToString(channelHead, bizHead, mmti0285vo, Url, telegram);                                                                                                                   
		                                                                                                                                                                                                                      
		logger.debug("##############################");                                                                                                                                                                       
		logger.debug(rtnXmlString);                                                                                                                                                                                           
		logger.debug("##############################");                                                                                                                                                                       
		                                                                                                                                                                                                                      
		mmti0285vo = (MMTI0285VO) ESBManager.xmlToVOnew(rtnXmlString, (MMTI0285VO)mmti0285vo);                                                                                                                      
		                                                                                                                                                                                                                      
		return mmti0285vo;
	}
	
	@SuppressWarnings("static-access")
	public MMTI0101VO getMMTI0101VO(MMTI0101VO mmti0101vo) throws Exception {
		String UserId = HOMEPAGE_JOJIKWON_CD;                                                                                                                                                                                           
		String formId = "MMTI0101";                                                                                                                                                                                           
		String telegram = "MMTI"; // esb                                                                                                                                                                                      
		                                                                                                                                                                                                                      
		ESBManager em = new ESBManager();                                                                                                                                                                                     
		ESBChannelHeader channelHead = new ESBChannelHeader();                                                                                                                                                                
		ESBBizHeader bizHead = new ESBBizHeader();     
		
		bizHead = em.makeDefaultBizHeader(UserId);                                                                                                                                                                            
		channelHead = em.makeDefaultChannelHeader(formId, UserId);  
		String Url = ESBURL;
		logger.debug("Url: " + Url);
		String rtnXmlString = (String)XmlUtil.callESBToString(channelHead, bizHead, mmti0101vo, Url, telegram);                                                                                                                   
		                                                                                                                                                                                                                      
		logger.debug("##############################");                                                                                                                                                                       
		logger.debug(rtnXmlString);                                                                                                                                                                                           
		logger.debug("##############################");                                                                                                                                                                       
		                                                                                                                                                                                                                      
		mmti0101vo = (MMTI0101VO) ESBManager.xmlToVOnew(rtnXmlString, (MMTI0101VO)mmti0101vo);                                                                                                                      
		                                                                                                                                                                                                                      
		return mmti0101vo;
	}
	
	@SuppressWarnings("static-access")
	public MMTI0044VO getMMTI0044VO(MMTI0044VO mmti0044vo) throws Exception {
		String UserId = HOMEPAGE_JOJIKWON_CD;                                                                                                                                                                                           
		String formId = "MMTI0044";                                                                                                                                                                                           
		String telegram = "MMTI"; // esb                                                                                                                                                                                      
		                                                                                                                                                                                                                      
		ESBManager em = new ESBManager();                                                                                                                                                                                     
		ESBChannelHeader channelHead = new ESBChannelHeader();                                                                                                                                                                
		ESBBizHeader bizHead = new ESBBizHeader();     
		
		bizHead = em.makeDefaultBizHeader(UserId);                                                                                                                                                                            
		channelHead = em.makeDefaultChannelHeader(formId, UserId);  
		String Url = ESBURL;
		logger.debug("Url: " + Url);
		String rtnXmlString = (String)XmlUtil.callESBToString(channelHead, bizHead, mmti0044vo, Url, telegram);                                                                                                                   
		                                                                                                                                                                                                                      
		logger.debug("##############################");                                                                                                                                                                       
		logger.debug(rtnXmlString);                                                                                                                                                                                           
		logger.debug("##############################");                                                                                                                                                                       
		                                                                                                                                                                                                                      
		mmti0044vo = (MMTI0044VO) ESBManager.xmlToVOnew(rtnXmlString, (MMTI0044VO)mmti0044vo);                                                                                                                      
		                                                                                                                                                                                                                      
		return mmti0044vo;
	}
	
	@SuppressWarnings("static-access")
	public AACT0019VO getAACT0019VO(AACT0019VO aact0019vo) throws Exception {
		String UserId = HOMEPAGE_JOJIKWON_CD;                                                                                                                                                                                           
		String formId = "AACT0019";                                                                                                                                                                                           
		String telegram = "AACT"; // esb                                                                                                                                                                                      
		                                                                                                                                                                                                                      
		ESBManager em = new ESBManager();                                                                                                                                                                                     
		ESBChannelHeader channelHead = new ESBChannelHeader();                                                                                                                                                                
		ESBBizHeader bizHead = new ESBBizHeader();     
		
		bizHead = em.makeDefaultBizHeader(UserId);                                                                                                                                                                            
		channelHead = em.makeDefaultChannelHeader(formId, UserId);  
		String Url = ESBURL;
		logger.debug("Url: " + Url);
		String rtnXmlString = (String)XmlUtil.callESBToString(channelHead, bizHead, aact0019vo, Url, telegram);                                                                                                                   
		                                                                                                                                                                                                                      
		logger.debug("##############################");                                                                                                                                                                       
		logger.debug(rtnXmlString);                                                                                                                                                                                           
		logger.debug("##############################");                                                                                                                                                                       
		                                                                                                                                                                                                                      
		aact0019vo = (AACT0019VO) ESBManager.xmlToVOnew(rtnXmlString, (AACT0019VO)aact0019vo);                                                                                                                      
		                                                                                                                                                                                                                      
		return aact0019vo;
	}
	
	@SuppressWarnings("static-access")
	public MMTI0289VO getMMTI0289VO(MMTI0289VO mmti0289vo) throws Exception {
		String UserId = HOMEPAGE_JOJIKWON_CD;                                                                                                                                                                                           
		String formId = "MMTI0289";                                                                                                                                                                                           
		String telegram = "MMTI"; // esb                                                                                                                                                                                      
		                                                                                                                                                                                                                      
		ESBManager em = new ESBManager();                                                                                                                                                                                     
		ESBChannelHeader channelHead = new ESBChannelHeader();                                                                                                                                                                
		ESBBizHeader bizHead = new ESBBizHeader();     
		
		bizHead = em.makeDefaultBizHeader(UserId);                                                                                                                                                                            
		channelHead = em.makeDefaultChannelHeader(formId, UserId);  
		String Url = ESBURL;
		logger.debug("Url: " + Url);
		String rtnXmlString = (String)XmlUtil.callESBToString(channelHead, bizHead, mmti0289vo, Url, telegram);                                                                                                                   
		                                                                                                                                                                                                                      
		logger.debug("##############################");                                                                                                                                                                       
		logger.debug(rtnXmlString);                                                                                                                                                                                           
		logger.debug("##############################");                                                                                                                                                                       
		                                                                                                                                                                                                                      
		mmti0289vo = (MMTI0289VO) ESBManager.xmlToVOnew(rtnXmlString, (MMTI0289VO)mmti0289vo);                                                                                                                      
		                                                                                                                                                                                                                      
		return mmti0289vo;
	}
	
	@SuppressWarnings("static-access")
	public AACT0015VO getAACT0015VO(AACT0015VO aact0015vo) throws Exception {
		String UserId = HOMEPAGE_JOJIKWON_CD;                                                                                                                                                                                           
		String formId = "AACT0015";                                                                                                                                                                                           
		String telegram = "AACT"; // esb                                                                                                                                                                                      
		                                                                                                                                                                                                                      
		ESBManager em = new ESBManager();                                                                                                                                                                                     
		ESBChannelHeader channelHead = new ESBChannelHeader();                                                                                                                                                                
		ESBBizHeader bizHead = new ESBBizHeader();     
		
		bizHead = em.makeDefaultBizHeader(UserId);                                                                                                                                                                            
		channelHead = em.makeDefaultChannelHeader(formId, UserId);  
		String Url = ESBURL;
		logger.debug("Url: " + Url);
		String rtnXmlString = (String)XmlUtil.callESBToString(channelHead, bizHead, aact0015vo, Url, telegram);                                                                                                                   
		                                                                                                                                                                                                                      
		logger.debug("##############################");                                                                                                                                                                       
		logger.debug(rtnXmlString);                                                                                                                                                                                           
		logger.debug("##############################");                                                                                                                                                                       
		                                                                                                                                                                                                                      
		aact0015vo = (AACT0015VO) ESBManager.xmlToVOnew(rtnXmlString, (AACT0015VO)aact0015vo);                                                                                                                      
		                                                                                                                                                                                                                      
		return aact0015vo;
	}
	
	@SuppressWarnings("static-access")
	public AACT0065VO getAACT0065VO(AACT0065VO aact0065vo) throws Exception {
		String UserId = HOMEPAGE_JOJIKWON_CD;                                                                                                                                                                                           
		String formId = "AACT0065";                                                                                                                                                                                           
		String telegram = "AACT"; // esb                                                                                                                                                                                      
		                                                                                                                                                                                                                      
		ESBManager em = new ESBManager();                                                                                                                                                                                     
		ESBChannelHeader channelHead = new ESBChannelHeader();                                                                                                                                                                
		ESBBizHeader bizHead = new ESBBizHeader();     
		
		bizHead = em.makeDefaultBizHeader(UserId);                                                                                                                                                                            
		channelHead = em.makeDefaultChannelHeader(formId, UserId);  
		String Url = ESBURL;
		logger.debug("Url: " + Url);
		String rtnXmlString = (String)XmlUtil.callESBToString(channelHead, bizHead, aact0065vo, Url, telegram);                                                                                                                   
		                                                                                                                                                                                                                      
		logger.debug("##############################");                                                                                                                                                                       
		logger.debug(rtnXmlString);                                                                                                                                                                                           
		logger.debug("##############################");                                                                                                                                                                       
		                                                                                                                                                                                                                      
		aact0065vo = (AACT0065VO) ESBManager.xmlToVOnew(rtnXmlString, (AACT0065VO)aact0065vo);                                                                                                                      
		                                                                                                                                                                                                                      
		return aact0065vo;
	}
	
	
}
