package com.idongbu.smartcustomer.counter.carRider.demo;

import java.io.File;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.idongbu.common.ESBBizHeader;
import com.idongbu.common.ESBChannelHeader;
import com.idongbu.common.ESBManager;
import com.idongbu.common.XmlUtil;
import com.idongbu.smartcustomer.vo.FileMeta;
import com.idongbu.smartzone.vo.MMTI0015VO;
import com.idongbu.smartzone.vo.MMTI0213VO;
import com.idongbu.smartzone.vo.MMTI0259VO;
import com.idongbu.smartzone.vo.MMTI0291VO;
import com.idongbu.smartzone.vo.XIDB0004VO;
import com.idongbu.smartzone.vo.XTEM0021VO;
import com.idongbu.util.StringUtil;

@Service
public class DBTestService {

	private @Value("${legacy.homepage_jojikwon_cd}") String HOMEPAGE_JOJIKWON_CD;
	private @Value("${carrider.upload.temp.path}") String CARRIDER_UPLOAD_TEMP_PATH;
	private @Value("${esb.Realip}") String ESBURL;
	private @Value("${dm.aes.key}") String dmAesKey;
	private static final String CHAT_EMPNO = "80000176";

	@Autowired(required=true)
	private DBTestFileService dbTestFileService; 	

	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired(required=true)
	@Qualifier("sqlSession")
	protected SqlSessionTemplate sqlSession;
	
	@SuppressWarnings("static-access")
	public MMTI0213VO getMMTI0213VO(MMTI0213VO jmvo) throws Exception {
		String UserId = HOMEPAGE_JOJIKWON_CD;                                                                                                                                                                                           
		String formId = "MMTI0213";                                                                                                                                                                                           
		String telegram = "MMTI"; // esb                                                                                                                                                                                      
		                                                                                                                                                                                                                      
		ESBManager em = new ESBManager();                                                                                                                                                                                     
		ESBChannelHeader channelHead = new ESBChannelHeader();                                                                                                                                                                
		ESBBizHeader bizHead = new ESBBizHeader();     
		
		bizHead = em.makeDefaultBizHeader(UserId);                                                                                                                                                                            
		channelHead = em.makeDefaultChannelHeader(formId, UserId);  
		String Url = ESBURL;
		logger.debug("Url: " + Url);
		String rtnXmlString = (String)XmlUtil.callESBToString(channelHead, bizHead, jmvo, Url, telegram);                                                                                                                   
		                                                                                                                                                                                                                      
		logger.debug("##############################");                                                                                                                                                                       
		logger.debug(rtnXmlString);                                                                                                                                                                                           
		logger.debug("##############################");                                                                                                                                                                       
		                                                                                                                                                                                                                      
		jmvo = (MMTI0213VO) ESBManager.xmlToVOnew(rtnXmlString, (MMTI0213VO)jmvo);                                                                                                                      
		                                                                                                                                                                                                                      
		return jmvo;
	}
	
	
	@SuppressWarnings("static-access")
	public MMTI0259VO getMMTI0259VO(MMTI0259VO jmvo) throws Exception {
		String UserId = HOMEPAGE_JOJIKWON_CD;                                                                                                                                                                                           
		String formId = "MMTI0259";                                                                                                                                                                                           
		String telegram = "MMTI"; // esb                                                                                                                                                                                      
		                                                                                                                                                                                                                      
		ESBManager em = new ESBManager();                                                                                                                                                                                     
		ESBChannelHeader channelHead = new ESBChannelHeader();                                                                                                                                                                
		ESBBizHeader bizHead = new ESBBizHeader();     
		
		bizHead = em.makeDefaultBizHeader(UserId);                                                                                                                                                                            
		channelHead = em.makeDefaultChannelHeader(formId, UserId);  
		String Url = ESBURL;
		logger.debug("Url: " + Url);
		String rtnXmlString = (String)XmlUtil.callESBToString(channelHead, bizHead, jmvo, Url, telegram);                                                                                                                   
		                                                                                                                                                                                                                      
		logger.debug("##############################");                                                                                                                                                                       
		logger.debug(rtnXmlString);                                                                                                                                                                                           
		logger.debug("##############################");                                                                                                                                                                       
		                                                                                                                                                                                                                      
		jmvo = (MMTI0259VO) ESBManager.xmlToVOnew(rtnXmlString, (MMTI0259VO)jmvo);                                                                                                                      
		                                                                                                                                                                                                                      
		return jmvo;
	}
	
	@SuppressWarnings("static-access")
	public MMTI0291VO getMMTI0291VO(MMTI0291VO jmvo) throws Exception {
		String UserId = HOMEPAGE_JOJIKWON_CD;                                                                                                                                                                                           
		String formId = "MMTI0291";                                                                                                                                                                                           
		String telegram = "MMTI"; // esb                                                                                                                                                                                      
		                                                                                                                                                                                                                      
		ESBManager em = new ESBManager();                                                                                                                                                                                     
		ESBChannelHeader channelHead = new ESBChannelHeader();                                                                                                                                                                
		ESBBizHeader bizHead = new ESBBizHeader();     
		
		bizHead = em.makeDefaultBizHeader(UserId);                                                                                                                                                                            
		channelHead = em.makeDefaultChannelHeader(formId, UserId);  
		String Url = ESBURL;
		logger.debug("Url: " + Url);
		String rtnXmlString = (String)XmlUtil.callESBToString(channelHead, bizHead, jmvo, Url, telegram);                                                                                                                   
		                                                                                                                                                                                                                      
		logger.debug("##############################");                                                                                                                                                                       
		logger.debug(rtnXmlString);                                                                                                                                                                                           
		logger.debug("##############################");                                                                                                                                                                       
		                                                                                                                                                                                                                      
		jmvo = (MMTI0291VO) ESBManager.xmlToVOnew(rtnXmlString, (MMTI0291VO)jmvo);                                                                                                                      
		                                                                                                                                                                                                                      
		return jmvo;
	}
	
	@SuppressWarnings("static-access")
	public MMTI0015VO getMMTI0015VO(MMTI0015VO jmvo) throws Exception {
		String UserId = HOMEPAGE_JOJIKWON_CD;                                                                                                                                                                                           
		String formId = "MMTI0015";                                                                                                                                                                                           
		String telegram = "MMTI"; // esb                                                                                                                                                                                      
		                                                                                                                                                                                                                      
		ESBManager em = new ESBManager();                                                                                                                                                                                     
		ESBChannelHeader channelHead = new ESBChannelHeader();                                                                                                                                                                
		ESBBizHeader bizHead = new ESBBizHeader();     
		
		bizHead = em.makeDefaultBizHeader(UserId);                                                                                                                                                                            
		channelHead = em.makeDefaultChannelHeader(formId, UserId);  
		String Url = ESBURL;
		logger.debug("Url: " + Url);
		String rtnXmlString = (String)XmlUtil.callESBToString(channelHead, bizHead, jmvo, Url, telegram);                                                                                                                   
		                                                                                                                                                                                                                      
		logger.debug("##############################");                                                                                                                                                                       
		logger.debug(rtnXmlString);                                                                                                                                                                                           
		logger.debug("##############################");                                                                                                                                                                       
		                                                                                                                                                                                                                      
		jmvo = (MMTI0015VO) ESBManager.xmlToVOnew(rtnXmlString, (MMTI0015VO)jmvo);                                                                                                                      
		                                                                                                                                                                                                                      
		return jmvo;
	}
	
	@SuppressWarnings("static-access")
	public XTEM0021VO getXTEM0021VO(XTEM0021VO jmvo) throws Exception {
		String UserId = HOMEPAGE_JOJIKWON_CD;                                                                                                                                                                                           
		String formId = "XTEM0021";                                                                                                                                                                                           
		String telegram = "XTEM"; // esb                                                                                                                                                                                      
		                                                                                                                                                                                                                      
		ESBManager em = new ESBManager();                                                                                                                                                                                     
		ESBChannelHeader channelHead = new ESBChannelHeader();                                                                                                                                                                
		ESBBizHeader bizHead = new ESBBizHeader();     
		
		bizHead = em.makeDefaultBizHeader(UserId);                                                                                                                                                                            
		channelHead = em.makeDefaultChannelHeader(formId, UserId);  
		String Url = ESBURL;
		logger.debug("Url: " + Url);
		String rtnXmlString = (String)XmlUtil.callESBToString(channelHead, bizHead, jmvo, Url, telegram);                                                                                                                   
		                                                                                                                                                                                                                      
		logger.debug("##############################");                                                                                                                                                                       
		logger.debug(rtnXmlString);                                                                                                                                                                                           
		logger.debug("##############################");                                                                                                                                                                       
		                                                                                                                                                                                                                      
		jmvo = (XTEM0021VO) ESBManager.xmlToVOnew(rtnXmlString, (XTEM0021VO)jmvo);                                                                                                                      
		                                                                                                                                                                                                                      
		return jmvo;
	}
	
	@SuppressWarnings("static-access")
	public XIDB0004VO getXIDB0004VO(XIDB0004VO jmvo) throws Exception{
		String UserId = HOMEPAGE_JOJIKWON_CD;                                                                                                                                                                                           
		String formId = "XIDB0004";                                                                                                                                                                                           
		String telegram = "XIDB"; // esb                                                                                                                                                                                      
		                                                                                                                                                                                                                      
		ESBManager em = new ESBManager();                                                                                                                                                                                     
		ESBChannelHeader channelHead = new ESBChannelHeader();                                                                                                                                                                
		ESBBizHeader bizHead = new ESBBizHeader();     
		
		bizHead = em.makeDefaultBizHeader(UserId);                                                                                                                                                                            
		channelHead = em.makeDefaultChannelHeader(formId, UserId);  
		String Url = ESBURL;
		logger.debug("Url: " + Url);
		String rtnXmlString = (String)XmlUtil.callESBToString(channelHead, bizHead, jmvo, Url, telegram);                                                                                                                   
		                                                                                                                                                                                                                      
		logger.debug("##############################");                                                                                                                                                                       
		logger.debug(rtnXmlString);                                                                                                                                                                                           
		logger.debug("##############################");                                                                                                                                                                       
		                                                                                                                                                                                                                      
		jmvo = (XIDB0004VO) ESBManager.xmlToVOnew(rtnXmlString, (XIDB0004VO)jmvo);                                                                                                                      
		      
		return jmvo;
		
	}
	
	public String getEncKey() {
		return dmAesKey;
	}
	
	public ArrayList<File> uploadToWAS(MultipartHttpServletRequest request, String sms_ts_bvan) throws Exception { // OCR 용
		ArrayList<File> files = new ArrayList<File>();

		// 이미지 업로드
		LinkedList<FileMeta> linkedList = dbTestFileService.upload(request, CARRIDER_UPLOAD_TEMP_PATH, sms_ts_bvan);		

		if(linkedList == null || linkedList.size() == 0) {
			throw new Exception("파일 업로드 실패 [ 업로드할 파일이 없거나 이미지파일이 아닙니다. ]");
		}

		for(int i = 0; i < linkedList.size(); i++) {
			FileMeta fileMeta = linkedList.get(i);
			File file = new File(CARRIDER_UPLOAD_TEMP_PATH + fileMeta.getFileName());
			files.add(file);
		}
		
		return files;
	}
	
	public MBTR01001VO regInfoToEdmsForMobileWeb(MultipartHttpServletRequest request, String sms_ts_bvan, MBTR01001VO mbtr01001vo) throws Exception {
		boolean result = false;

		// 등록관련정보조회 서블릿을 호출해서 User ID 조회
		Map<String, String> edmsPreRegInfo = dbTestFileService.getEdmsIdForMobileWeb(sms_ts_bvan);
		if(!"1".equals(edmsPreRegInfo.get("RtnCd"))) {
			throw new Exception(edmsPreRegInfo.get("Message"));
		}		

		// 이미지 업로드
		LinkedList<FileMeta> linkedList = dbTestFileService.upload(request, CARRIDER_UPLOAD_TEMP_PATH, sms_ts_bvan);		

		if(linkedList == null || linkedList.size() == 0) {
			throw new Exception("파일 업로드 실패 [ 업로드할 파일이 없거나 이미지파일이 아닙니다. ]");
		}

		for(int i = 0; i < linkedList.size(); i++) {
			FileMeta fileMeta = linkedList.get(i);

			File file = new File(CARRIDER_UPLOAD_TEMP_PATH + fileMeta.getFileName());

			String exifDate = "";
			if(i == 0) exifDate = StringUtil.nvl(request.getParameter("exifDate1"));
			else if(i == 1) exifDate = StringUtil.nvl(request.getParameter("exifDate2"));
			if(exifDate.indexOf(",gallery") > -1) {
				exifDate = exifDate.substring(0, exifDate.indexOf(",gallery"));
			}
			
			mbtr01001vo = dbTestFileService.docRegToEdms2(edmsPreRegInfo, file, null, exifDate, mbtr01001vo);
			
			if("N".equals(mbtr01001vo.getNrmYn()))
				throw new Exception("EDMS에 파일전송 실패");
		}
		
		return mbtr01001vo;
	}
	
	public MBTR01001VO regInfoToEdmsForMobileWeb2(MultipartHttpServletRequest request, String id, ArrayList<File> files, String plnoAndPlanNo, MBTR01001VO mbtr01001vo) throws Exception { // OCR 용
		boolean result = false;

		for(int i = 0; i < files.size(); i++) {
			File file = files.get(i);

			// EDMS에 문서 등록
			String exifDate = "";
			if(i == 0) exifDate = StringUtil.nvl(request.getParameter("exifDate1"));
			else if(i == 1) exifDate = StringUtil.nvl(request.getParameter("exifDate2"));
			
			if(exifDate.indexOf(",gallery") > -1) {
				exifDate = exifDate.substring(0, exifDate.indexOf(",gallery"));
			}
			
			mbtr01001vo = dbTestFileService.docRegToEdms3(id, file, null, exifDate, plnoAndPlanNo, mbtr01001vo);
			if("N".equals(mbtr01001vo.getNrmYn()))
				throw new Exception("EDMS에 파일전송 실패");
		}
		return mbtr01001vo;
	}
	
	public int insertTest(MBTR01001VO mbtr01001vo) throws Exception{
		
		DBTestDao mapper = sqlSession.getMapper(DBTestDao.class);
		int result = mapper.insertEdmsHist(mbtr01001vo);
		
		return result;
	}
	
	public int insertJungsanTest(MBTT02001VO mbtt02001vo) throws Exception{
		
		DBTestDao mapper = sqlSession.getMapper(DBTestDao.class);
		int result = mapper.insertMlHist(mbtt02001vo);
		
		return result;
	}
}
