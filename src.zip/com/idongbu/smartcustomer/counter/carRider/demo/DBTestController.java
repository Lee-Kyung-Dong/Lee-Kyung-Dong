package com.idongbu.smartcustomer.counter.carRider.demo;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.idongbu.common.SeedUtil;
import com.idongbu.smartzone.vo.MMTI0015VO;
import com.idongbu.smartzone.vo.MMTI0213VO;
import com.idongbu.smartzone.vo.MMTI0259VO;
import com.idongbu.smartzone.vo.MMTI0291VO;
import com.idongbu.smartzone.vo.XIDB0004VO;
import com.idongbu.smartzone.vo.XTEM0021VO;
import com.idongbu.util.DMEncDecUtil;
import com.idongbu.util.DateUtil;
import com.idongbu.util.FTPUtil;
import com.idongbu.util.StringUtil;

@Controller
@RequestMapping("/dbtest")
public class DBTestController {
	
	@Autowired(required=true)
	private DBTestService dbTestService;

	@Autowired(required=true)
	private DBTestFileService dbTestFileService;
	
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	
	@RequestMapping(value="/ml_test1")
	public String ml_test1(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		MBTR01001VO mbtr01001vo = new MBTR01001VO();
		mbtr01001vo.setPboxNo("M8526673");
		mbtr01001vo.setPlno("220202820888001");
		mbtr01001vo.setPlanNo("2202107C2800002");
		mbtr01001vo.setCtrmfPlanNo("2202107C5800001");
		mbtr01001vo.setEdmsBzLgcgCd("CKB");
		mbtr01001vo.setDocTypSmcgCd("CKB008");
		mbtr01001vo.setNrmYn("Y");
		mbtr01001vo.setProcRslMsgCn("테스트");
		mbtr01001vo.setApdxFlRutNm("");
		mbtr01001vo.setEdmsFlSizeVal(123333);
		mbtr01001vo.setFrstIpmnEmpno("81900372");
		mbtr01001vo.setFnalAmdrEmpno("81900372");
		int a = dbTestService.insertTest(mbtr01001vo);
		if(a<1){
			logger.info("### fail");
		}else{
			logger.info("### success");
		}
		return "/counter/carrider/test/ml_test1";
	}	
	
	@RequestMapping(value="/ml1")
	public String ml1(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		logger.info("###### 1 ##");
		HttpSession session = request.getSession();
		MMTI0213VO jmvo = new MMTI0213VO();
		logger.info("###### 2 ##");
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("p")));
		logger.info("###### 3 ##");
		jmvo = dbTestService.getMMTI0213VO(jmvo);
		logger.info("###### 4 ##");
		request.setAttribute("p", request.getParameter("p"));
		request.setAttribute("jmvo", jmvo);
		
		if(!StringUtil.isEmpty(request.getParameter("appSeq"))){
			session.setAttribute("appSeq", StringUtil.nvl(request.getParameter("appSeq")));
		}
		logger.info("###### 5 ##");
		return "/counter/carrider/test/ml1";
	}	
	
	@RequestMapping(value="/ml2")
	public String ml2(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		MMTI0213VO jmvo = new MMTI0213VO();
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("p")));
		jmvo = dbTestService.getMMTI0213VO(jmvo);
		
		request.setAttribute("p", request.getParameter("p"));
		request.setAttribute("jmvo", jmvo);
		return "/counter/carrider/test/ml2";
	}
	
	
	@RequestMapping(value="/ml2_1")
	public String ml2_1(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		MMTI0213VO jmvo = new MMTI0213VO();
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("p")));
		jmvo = dbTestService.getMMTI0213VO(jmvo);
		
		HttpSession session = request.getSession();
		Object[] imgfile = (Object[]) session.getAttribute("imgfile");
		if(imgfile != null) {
			byte[] file = (byte[]) imgfile[0];
			logger.debug("file.length: " + file.length);
			request.setAttribute("imgsrc", "data:image/jpeg;base64," + new String(Base64.encodeBase64(file)));
		}
		
		request.setAttribute("p", request.getParameter("p"));
		session.setAttribute("p", request.getParameter("p"));
		request.setAttribute("jmvo", jmvo);
		return "/counter/carrider/test/ml2_1";
	}
	
	@RequestMapping(value="/ml3")
	public String ml3(HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		HttpSession session = request.getSession();
		MMTI0213VO jmvo = new MMTI0213VO();
		//jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("p")));
		jmvo.setSms_ts_bvan(aes256Decrypt((String)session.getAttribute("p")));
		
		jmvo = dbTestService.getMMTI0213VO(jmvo);
		
		session.setAttribute("pbox_no", jmvo.getSms_ts_bvan());
		
		logger.info("###### ml3 테스트1 ######");
		logger.info("###### request ######");
		logger.info("###### plno: " + StringUtil.nvl(request.getParameter("plno")));
		logger.info("###### plan_no: " + StringUtil.nvl(request.getParameter("exp_exca_plan_no")));
		logger.info("###### pdc_sr_dvn: " + StringUtil.nvl(request.getParameter("pdc_sr_dvn")));
		logger.info("###### adc_rtrn_dvn: " + StringUtil.nvl(request.getParameter("adc_rtrn_dvn")));
		logger.info("###### adc_rtrn_prm: " + StringUtil.nvl(request.getParameter("adc_rtrn_prm")));
		logger.info("###### scrn_proc_cd: " + StringUtil.nvl(request.getParameter("exp_exca_plan_rsl_cd")));
		
		logger.info("###### ml3 테스트2 ######");
		logger.info("###### session ######");
		logger.info("###### plno: " + StringUtil.nvl((String)session.getAttribute("plno")));
		logger.info("###### plan_no: " + StringUtil.nvl((String)session.getAttribute("exp_exca_plan_no")));
		logger.info("###### pdc_sr_dvn: " + StringUtil.nvl((String)session.getAttribute("pdc_sr_dvn")));
		logger.info("###### adc_rtrn_dvn: " + StringUtil.nvl((String)session.getAttribute("adc_rtrn_dvn")));
		logger.info("###### adc_rtrn_prm: " + StringUtil.nvl((String)session.getAttribute("adc_rtrn_prm")));
		logger.info("###### scrn_proc_cd: " + StringUtil.nvl((String)session.getAttribute("exp_exca_plan_rsl_cd")));
		
		
//		String exp_exca_plan_rsl_cd = request.getParameter("exp_exca_plan_rsl_cd");
		String exp_exca_plan_rsl_cd = (String)session.getAttribute("exp_exca_plan_rsl_cd");
		
		// 간편정산 -> 설계보관/추징 등 아니면 다 확정요청
		if("1".equals(jmvo.getTrv_dstc_splc_exca_yn())) {
			if(exp_exca_plan_rsl_cd.equals("11") || exp_exca_plan_rsl_cd.equals("13") || exp_exca_plan_rsl_cd.equals("14")) {
				// [200617]
				MMTI0291VO jmvo1 = new MMTI0291VO();
				jmvo1.setTrv_dstc_exca_mtt__exca_bz_proc_dvn("2");
				jmvo1.setTrv_dstc_exca_mtt__plno(StringUtil.nvl(request.getParameter("plno")));
				jmvo1.setTrv_dstc_exca_mtt__plan_no(StringUtil.nvl(request.getParameter("exp_exca_plan_no")));
				jmvo1.setTrv_dstc_exca_mtt__exca_rtrn_dvn("");
				jmvo1.setTrv_dstc_exca_mtt__pdc_sr_dvn(StringUtil.nvl(request.getParameter("pdc_sr_dvn")));
				jmvo1.setTrv_dstc_exca_mtt__adc_rtrn_dvn(StringUtil.nvl(request.getParameter("adc_rtrn_dvn")));
				jmvo1.setTrv_dstc_exca_mtt__adc_rtrn_prm(StringUtil.nvl(request.getParameter("adc_rtrn_prm")));
				jmvo1.setTrv_dstc_exca_mtt__scrn_proc_cd(StringUtil.nvl(request.getParameter("exp_exca_plan_rsl_cd")));
				jmvo1.setTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn(jmvo.getTrv_dstc_splc_exca_yn());
				jmvo1.setTrv_dstc_exca_mtt__pbox_no(jmvo.getSms_ts_bvan());
				jmvo1 = dbTestService.getMMTI0291VO(jmvo1);
				
				request.setAttribute("z_resp_cd", jmvo1.getZ_resp_cd());
				request.setAttribute("z_resp_msg", jmvo1.getZ_resp_msg());
				session.setAttribute("z_resp_cd", jmvo1.getZ_resp_cd());
				session.setAttribute("z_resp_msg", jmvo1.getZ_resp_msg());
				
				// 이미지 중복이면 확정신청페이지
				if("1".equals(jmvo1.getTrv_dstc_exca_mtt__imag_dup_yn())){
					exp_exca_plan_rsl_cd = "14";
				}
					
				/*request.setAttribute("imag_dup_yn", jmvo1.getTrv_dstc_exca_mtt__imag_dup_yn());	// 중복여부
				request.setAttribute("imag_rsl_cd", jmvo1.getTrv_dstc_exca_mtt__rsl_cd());			// 결과코드
				request.setAttribute("imag_rsl_msg", jmvo1.getTrv_dstc_exca_mtt__rsl_msg());*/		// 결과메시지
				
				// CM 상품이고, 화면처리코드 IN(02, 14) or 이미지 중복
				
				if("CM".equals(jmvo1.getTrv_dstc_exca_mtt__pdc_sr_dvn()) && 
						("02".equals(jmvo1.getTrv_dstc_exca_mtt__scrn_proc_cd())
						|| "14".equals(jmvo1.getTrv_dstc_exca_mtt__scrn_proc_cd()))){
					
					MMTI0015VO mmti0015vo = new MMTI0015VO();
					mmti0015vo.setFunt_key("00");
					mmti0015vo.setPlan_no(jmvo1.getTrv_dstc_exca_mtt__plan_no());
					mmti0015vo = dbTestService.getMMTI0015VO(mmti0015vo);
					
					logger.debug("##### MMTI0015 시작 ##########################");
					logger.debug("##### 고객식별번호: " + mmti0015vo.getPlhd__cust_dcmt_no() + " ##########################");
					logger.debug("##### 고객번호: " + mmti0015vo.getPlhd__cust_no() + " ##########################");
					logger.debug("##### 고객명: " + mmti0015vo.getPlhd__cust_nm() + " ##########################");
					logger.debug("##### 이메일: " + mmti0015vo.getPlhd__eml() + " ##########################");
					logger.debug("##### 지역번호: " + mmti0015vo.getPlhd_cntp_if__tlp_arno() + " ##########################");
					logger.debug("##### 국번호: " + mmti0015vo.getPlhd_cntp_if__tlp_ofno() + " ##########################");
					logger.debug("##### 개별번호: " + mmti0015vo.getPlhd_cntp_if__tlp_idvno() + " ##########################");
					
					XTEM0021VO xtem0021vo = new XTEM0021VO();
					xtem0021vo.setCnsl_rpt_no("");						// 상담접수번호				
					xtem0021vo.setCm_bz_dvcd("05");
					xtem0021vo.setCnsl_typ_dvcd("07");
					xtem0021vo.setCm_plan_no(jmvo1.getTrv_dstc_exca_mtt__plan_no());
					xtem0021vo.setCnsl_rpy_dvcd("1");
					xtem0021vo.setCnsl_rpt_dttm(getDayTime());			// 현재년월일시분초 14자리
					xtem0021vo.setCust_nm(mmti0015vo.getPlhd__cust_nm());
					xtem0021vo.setCust_no(mmti0015vo.getPlhd__cust_no());
					
					String cust_dcmt_no = SeedUtil.decrypt(mmti0015vo.getPlhd__cust_dcmt_no());
					
					if("1".equals(cust_dcmt_no.substring(6, 7)) || "2".equals(cust_dcmt_no.substring(6, 7))
						|| "5".equals(cust_dcmt_no.substring(6, 7)) || "6".equals(cust_dcmt_no.substring(6, 7))){
						xtem0021vo.setBrth("19" + cust_dcmt_no.substring(0, 6));
					} else{
						xtem0021vo.setBrth("20" + cust_dcmt_no.substring(0, 6));
					}
					// xtem0021vo.setBrth("");  							// 생년월일
					xtem0021vo.setSx_cd(cust_dcmt_no.substring(6, 7));
					xtem0021vo.setEml_adr(mmti0015vo.getPlhd__eml());
					xtem0021vo.setClp_tlcno(mmti0015vo.getPlhd_cntp_if__tlp_arno());
					xtem0021vo.setClp_ofno(mmti0015vo.getPlhd_cntp_if__tlp_ofno());
					xtem0021vo.setClp_idvno(mmti0015vo.getPlhd_cntp_if__tlp_idvno());
					xtem0021vo.setCnsl_rsvt_dt("99990101");
					xtem0021vo.setCnsl_rsvt_time_cd("1");
					xtem0021vo.setCnsl_cn("최종주행거리사진등록/만기정산");
					xtem0021vo.setCnsl_aply_csn_yn("1");
					xtem0021vo.setUrl_adr("");
					xtem0021vo.setCm_ctrmf_tpcd("32");
					xtem0021vo.setFrst_ipmn_empno("80000028");
					xtem0021vo.setFrst_ipnpt_dttm(getDayTime());		// 현재년월일시분초 14자리	
					
					xtem0021vo = dbTestService.getXTEM0021VO(xtem0021vo);
					logger.debug("##### XTEM0021 시작 ##########################");
					logger.debug("##### 처리결과: [ " + xtem0021vo.getProc_rtn() + " ] ##########################");
				}
			}
		}
		
		request.setAttribute("p",							request.getParameter("p"));
		request.setAttribute("jmvo",						jmvo);
		request.setAttribute("exp_exca_plan_rsl_cd",		exp_exca_plan_rsl_cd);
		request.setAttribute("adc_rtrn_dvn",				request.getParameter("adc_rtrn_dvn"));
		request.setAttribute("adc_rtrn_prm",				request.getParameter("adc_rtrn_prm"));
		request.setAttribute("plno",						request.getParameter("plno"));
		request.setAttribute("exp_exca_plan_no",			request.getParameter("exp_exca_plan_no"));
		request.setAttribute("exp_exca_plan_bse_dd",		request.getParameter("exp_exca_plan_bse_dd"));
		request.setAttribute("aut_cgnt_vh_no",				request.getParameter("aut_cgnt_vh_no"));
		request.setAttribute("aut_cgnt_vh_no_rsl_cd",		request.getParameter("aut_cgnt_vh_no_rsl_cd"));
		request.setAttribute("aut_cgnt_trv_dstc",			request.getParameter("aut_cgnt_trv_dstc"));
		request.setAttribute("aut_cgnt_trv_dstc_rsl_cd",	request.getParameter("aut_cgnt_trv_dstc_rsl_cd"));
		request.setAttribute("exp_exca_plan_proc_dvn",		request.getParameter("exp_exca_plan_proc_dvn"));
		request.setAttribute("cnv_trv_dstc",				request.getParameter("cnv_trv_dstc"));
		request.setAttribute("plhd_cust_nm",				request.getParameter("plhd_cust_nm"));
		request.setAttribute("pdc_sr_dvn",					request.getParameter("pdc_sr_dvn"));
		request.setAttribute("errorCode",					request.getParameter("errorCode"));
		
		
		
		session.setAttribute("p",							session.getAttribute("p"));
		session.setAttribute("jmvo",						jmvo);
		session.setAttribute("exp_exca_plan_rsl_cd",		exp_exca_plan_rsl_cd);
		session.setAttribute("adc_rtrn_dvn",				session.getAttribute("adc_rtrn_dvn"));
		session.setAttribute("adc_rtrn_prm",				session.getAttribute("adc_rtrn_prm"));
		session.setAttribute("plno",						session.getAttribute("plno"));
		session.setAttribute("exp_exca_plan_no",			session.getAttribute("exp_exca_plan_no"));
		session.setAttribute("exp_exca_plan_bse_dd",		session.getAttribute("exp_exca_plan_bse_dd"));
		session.setAttribute("aut_cgnt_vh_no",				session.getAttribute("aut_cgnt_vh_no"));
		session.setAttribute("aut_cgnt_vh_no_rsl_cd",		session.getAttribute("aut_cgnt_vh_no_rsl_cd"));
		session.setAttribute("aut_cgnt_trv_dstc",			session.getAttribute("aut_cgnt_trv_dstc"));
		session.setAttribute("aut_cgnt_trv_dstc_rsl_cd",	session.getAttribute("aut_cgnt_trv_dstc_rsl_cd"));
		session.setAttribute("exp_exca_plan_proc_dvn",		session.getAttribute("exp_exca_plan_proc_dvn"));
		session.setAttribute("cnv_trv_dstc",				session.getAttribute("cnv_trv_dstc"));
		session.setAttribute("plhd_cust_nm",				session.getAttribute("plhd_cust_nm"));
		session.setAttribute("pdc_sr_dvn",					session.getAttribute("pdc_sr_dvn"));
		session.setAttribute("errorCode",					session.getAttribute("errorCode"));
		
		
		return "/counter/carrider/test/ml3";
	}
	
	@RequestMapping(value="/mlFileUpload")
	public @ResponseBody Map<String, String> mlFileUpload(MultipartHttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		Map<String, String> map = new HashMap<String, String>();
		String yyyymmdd = DateUtil.getDate("yyyymmdd");
		
		MMTI0213VO jmvo = new MMTI0213VO();
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("p")));
		jmvo = dbTestService.getMMTI0213VO(jmvo);
		
		String exifDate1 = StringUtil.nvl(request.getParameter("exifDate1"));
		// 사진실제촬영일자
		String phgp_rl_ptgr_dt = StringUtil.nvl(request.getParameter("phgp_rl_ptgr_dt"));
		// 사진첨부방식코드
		String phgp_apdx_way_cd = StringUtil.nvl(request.getParameter("phgp_apdx_way_cd"));
		
		String phgp_ptgr_dt = "";
	
		boolean empty = false;
		if(exifDate1.indexOf(",gallery") > -1) {
			exifDate1 = exifDate1.substring(0, exifDate1.indexOf(",gallery"));
			if(StringUtil.isEmpty(exifDate1)) {
				exifDate1 = DateUtil.getDate();
				empty = true;
			}
			else if(Integer.parseInt(exifDate1) > Integer.parseInt(DateUtil.getDate())) {
				map.put("errorCode", "f");
				return map;
			}
		}

		phgp_ptgr_dt = empty ? "" : exifDate1;
		
		if(exifDate1.indexOf(",gallery") > -1) {
			exifDate1 = exifDate1.substring(0, exifDate1.indexOf(",gallery"));
		}

		if("08".equals(jmvo.getProc_dvn()) || "09".equals(jmvo.getProc_dvn())) {
			ArrayList<File> files = dbTestService.uploadToWAS(request, jmvo.getSms_ts_bvan());
			
			String aut_cgnt_trv_dstc_rsl_cd = "";	// 자동인식주행거리결과코드
			String aut_cgnt_vh_no_rsl_cd = "";		// 자동인식차량번호결과코드
			String aut_cgnt_trv_dstc = "";			// 자동인식주행거리
			String aut_cgnt_vh_no = "";				// 자동인식차량번호
			
			String aut_cgnt_trv_dstc_1 = "";		// 자동인식주행거리1
			String aut_cgnt_trv_dstc_2 = "";		// 자동인식주행거리2
			String aut_cgnt_trv_dstc_3 = "";		// 자동인식주행거리3
			
			boolean flag1 = false;
			if(files.size() > 0) {
				FTPUtil ftp = null;
				// [200617]
				FileInputStream in = null;
				FileInputStream fis = null;
				FileOutputStream out = null;
				
				try {
					if("1".equals(jmvo.getAut_cgnt_nn_apcn_yn())) { // OCR서버 문제있으면...
						aut_cgnt_trv_dstc_rsl_cd = "03";
						aut_cgnt_vh_no_rsl_cd = "03";
					}
					else {
						String propsPath = this.getClass().getResource("").getPath();
						propsPath = propsPath.substring(0, propsPath.indexOf("/classes/")) + "/config/ocr_ftp.properties";
						Properties p = new Properties();
						// [200617]
						in = new FileInputStream(propsPath);
						p.load(in);
						in.close();
						// [200617]
						in = null;
						
						String password = p.getProperty("password");
						String decPassword = aes256Decrypt(password);
						if(password.equals(decPassword) || StringUtil.isEmpty(decPassword)) {
							decPassword = password;
							String encPassword = aes256Encrypt(password);
							logger.debug("encPassword: " + encPassword);
							// [200617]
							out = new FileOutputStream(propsPath);
							p.setProperty("password", encPassword);
							p.store(out, "");
							out.close();
							// [200617]
							out = null;
						}
						
						ftp = new FTPUtil(p.getProperty("ip"), p.getProperty("user"), decPassword, Integer.parseInt(p.getProperty("port")));
						
						int working = 0;
						for(int i = 1; i <= 3; i++) {
							String[] ls = ftp.ls("/RECOG_JOB" + i + "/" + yyyymmdd);
							for(int j = 0; j < ls.length; j++) {
								if(".".equals(ls[j]) || "..".equals(ls[j])) continue;
								working++;
							}
						}
		
						if(working <= 6) {
							String filename1 = "";
							
							filename1 = ftp.uploadToOCR("/RECOG/" + yyyymmdd, files.get(0), "--D");

							logger.debug("filename1: " + filename1);

							
							logger.debug("--- 1초 대기 ---");
							Thread.sleep(1000);
							int retryNum = 7;
							for(int retry = 0; retry < retryNum; retry++) {
								String[] ls = ftp.ls("/RECOG_RESULT/" + yyyymmdd);
			
								for(int i = 0; i < ls.length; i++) {
									logger.debug(ls[i]);
									if(!flag1 && ls[i].equals(filename1)) {
										flag1 = true;
									}
									
									if(flag1) break;
								}
			
								if((flag1) || retry == retryNum - 1) {
									break;
								}
								else {
									logger.debug("--- 0.6초 대기 ---");
									Thread.sleep(600);
								}
							}
							
							logger.debug("flag1: " + flag1);
							
							if(flag1) {
								// [210219]
								if(filename1 != null || !"".equals(filename1)){
									filename1 = filename1.replaceAll("/", "");
									filename1 = filename1.replaceAll("\\\\", "");
									filename1 = filename1.replaceAll("./", "");
									filename1 = filename1.replaceAll("../", "");
									filename1 = filename1.replaceAll("&", "");
								}
								
								String path = files.get(0).getParent() + File.separator + filename1;
								ftp.downloadFromOCR("/RECOG_RESULT/" + yyyymmdd, filename1, path);
								logger.debug("path: " + path);
								
								// [210219]
								File f = new File(files.get(0).getParent() + File.separator + filename1);
								// File f = new File(path);
			
								if(f.exists()) {
									Properties props = new Properties();
									// [210219]
									fis = new FileInputStream(files.get(0).getParent() + File.separator + filename1);
									props.load(fis);
									fis.close();
									// [200617]
									fis = null;
									
									if(!StringUtil.isEmpty(props.getProperty("ODO")) && !StringUtil.isEmpty(props.getProperty("RE_CODE"))) {
										aut_cgnt_trv_dstc = props.getProperty("ODO");
										aut_cgnt_trv_dstc_rsl_cd = "1".equals(props.getProperty("RE_CODE")) || "2".equals(props.getProperty("RE_CODE")) ? "01" : "02";
										
										aut_cgnt_trv_dstc_1 = props.getProperty("ODO");
										
										if(!StringUtil.isEmpty(props.getProperty("ODO2"))) {
											aut_cgnt_trv_dstc_2 = props.getProperty("ODO2");
										}
										
										if(!StringUtil.isEmpty(props.getProperty("ODO3"))) {
											aut_cgnt_trv_dstc_3 = props.getProperty("ODO3");
										}
									}
									
					            	if(f.delete()) {
										logger.debug("삭제: " + path);
									}
								}
							}
							else {
								aut_cgnt_trv_dstc_rsl_cd = "02";
							}						
						}
						else {
							aut_cgnt_trv_dstc_rsl_cd = "02";
							if(!"1".equals(jmvo.getCm_yn())) {
								aut_cgnt_vh_no_rsl_cd = "02";
							}
						}
					}
				}
				catch(Exception e) {
					logger.debug(e.getMessage());
					aut_cgnt_trv_dstc_rsl_cd = "02";
					if(!"1".equals(jmvo.getCm_yn())) {
						aut_cgnt_vh_no_rsl_cd = "02";
					}
				}
				finally {
					if(ftp != null) ftp.disconnect();
					
					// [200617]
					try{
			    	  	if(in != null){
			    	  		in.close();
			    	  	}
				      }catch(IOException ee){
				    	  System.err.println("[MileageTobeController.mlFileUpload()] IOException 1");
				      }
					try{
			    	  	if(out != null){
			    	  		out.close();
			    	  	}
				      }catch(IOException ee){
				    	  System.err.println("[MileageTobeController.mlFileUpload()] IOException 2");
				      }
					try{
			    	  	if(fis != null){
			    	  		fis.close();
			    	  	}
				      }catch(IOException ee){
				    	  System.err.println("[MileageTobeController.mlFileUpload()] IOException 3");
				      }
				}
			}
			
			MMTI0259VO jmvo1 = new MMTI0259VO();
			jmvo1.setPbox_use_yn("1");
			jmvo1.setPbox_no(jmvo.getSms_ts_bvan());
			jmvo1.setPhgp_cnfm_dt(DateUtil.getDate());
			jmvo1.setPhgp_ptgr_dt(phgp_ptgr_dt);
			jmvo1.setPhgp_strg_yn("1");
			if("1".equals(jmvo.getAut_cgnt_nn_apcn_yn())) {
				jmvo1.setPbox_chr_nm(request.getParameter("mileage1"));
			}
			
			if("1".equals(jmvo.getPbox_no_dvcd())) {
				if(!"1".equals(jmvo.getCm_yn())) {
					jmvo1.setInpt_trv_dstc(request.getParameter("mileage1"));
					if(!StringUtil.isEmpty(aut_cgnt_vh_no)) {
						jmvo1.setAut_cgnt_vh_no(aut_cgnt_vh_no);
					}
					
					if(!StringUtil.isEmpty(aut_cgnt_vh_no_rsl_cd)) {
						jmvo1.setAut_cgnt_vh_no_rsl_cd(aut_cgnt_vh_no_rsl_cd);
					}
					else {
						jmvo1.setAut_cgnt_vh_no_rsl_cd("02");
					}
				}
					
				if(!StringUtil.isEmpty(aut_cgnt_trv_dstc)) {
					jmvo1.setAut_cgnt_trv_dstc(aut_cgnt_trv_dstc);
				}
				
				if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_rsl_cd)) {
					jmvo1.setAut_cgnt_trv_dstc_rsl_cd(aut_cgnt_trv_dstc_rsl_cd);
				}
				else {
					jmvo1.setAut_cgnt_trv_dstc_rsl_cd("02");
				}
				
				if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_1)) {
					jmvo1.setAut_cgnt_trv_dstc_1(aut_cgnt_trv_dstc_1);
				}
				
				if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_2)) {
					jmvo1.setAut_cgnt_trv_dstc_2(aut_cgnt_trv_dstc_2);
				}
				
				if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_3)) {
					jmvo1.setAut_cgnt_trv_dstc_3(aut_cgnt_trv_dstc_3);
				}
			}
			
			// 200708
			jmvo1.setPhgp_rl_ptgr_dt(phgp_rl_ptgr_dt);
			jmvo1.setPhgp_apdx_way_cd(phgp_apdx_way_cd);
			
			jmvo1 = dbTestService.getMMTI0259VO(jmvo1);
			MBTR01001VO mbtr01001vo = new MBTR01001VO();
			
			if("0".equals(jmvo1.getErrorCode()) && !"1".equals(jmvo.getCm_yn())) {
				jmvo1.setExp_exca_plan_proc_dvn("1");
				jmvo1.setPlno(jmvo.getPlno());
			
				// 200708
				jmvo1.setPhgp_rl_ptgr_dt(phgp_rl_ptgr_dt);
				jmvo1.setPhgp_apdx_way_cd(phgp_apdx_way_cd);
				
				jmvo1 = dbTestService.getMMTI0259VO(jmvo1);
				
				if("05".equals(jmvo1.getExp_exca_plan_rsl_cd())) {
					mbtr01001vo = dbTestService.regInfoToEdmsForMobileWeb(request, jmvo.getSms_ts_bvan(), mbtr01001vo);
				}
				else if(!StringUtil.isEmpty(jmvo1.getPlno()) && !StringUtil.isEmpty(jmvo1.getExp_exca_plan_no())) {
					mbtr01001vo = dbTestService.regInfoToEdmsForMobileWeb2(request, jmvo.getNtft_srv_rc_ormm_cd(), files, jmvo1.getPlno() + "," + jmvo1.getExp_exca_plan_no(), mbtr01001vo);
				}
				else {
					mbtr01001vo = dbTestService.regInfoToEdmsForMobileWeb2(request, jmvo.getNtft_srv_rc_ormm_cd(), files, jmvo1.getPlno(), mbtr01001vo);
				}
			}
			else {
				if("1".equals(jmvo.getCm_yn())) {
					mbtr01001vo = dbTestService.regInfoToEdmsForMobileWeb(request, jmvo.getSms_ts_bvan(), mbtr01001vo);
				}
				else {
					mbtr01001vo = dbTestService.regInfoToEdmsForMobileWeb2(request, jmvo.getNtft_srv_rc_ormm_cd(), files, jmvo1.getPlno(), mbtr01001vo);
				}
			}
			
			int insertRow = 0;
			
			// VO SET
			mbtr01001vo.setPboxNo(jmvo.getSms_ts_bvan());
			mbtr01001vo.setApdxFlRutNm("");
			mbtr01001vo.setFrstIpmnEmpno("81900372");
			mbtr01001vo.setFnalAmdrEmpno("81900372");
			
			insertRow = dbTestService.insertTest(mbtr01001vo);
			if(insertRow < 1){
				logger.info("#### 사서함번호: " + StringUtil.nvl(mbtr01001vo.getPboxNo()) + "####");
				logger.info("#### insert 결과: Fail ####");
			}else{
				logger.info("#### insert 결과: Success ####");
			}
	
			for(int i = 0; i < files.size(); i++) {
				File f = files.get(i);
				String fname = f.getName();
				f.delete();
				logger.debug(fname + " 삭제");
			}
			
			map.put("errorCode",				jmvo1.getErrorCode());
			map.put("exp_exca_plan_rsl_cd",		jmvo1.getExp_exca_plan_rsl_cd());
			map.put("adc_rtrn_dvn",				jmvo1.getAdc_rtrn_dvn());
			map.put("adc_rtrn_prm",				jmvo1.getAdc_rtrn_prm());
			map.put("plno",						jmvo1.getPlno());
			map.put("exp_exca_plan_no",			jmvo1.getExp_exca_plan_no());
			map.put("exp_exca_plan_bse_dd",		jmvo1.getExp_exca_plan_bse_dd());
			map.put("aut_cgnt_vh_no",			jmvo1.getAut_cgnt_vh_no());
			map.put("aut_cgnt_vh_no_rsl_cd",	jmvo1.getAut_cgnt_vh_no_rsl_cd());
			map.put("aut_cgnt_trv_dstc",		jmvo1.getAut_cgnt_trv_dstc());
			map.put("aut_cgnt_trv_dstc_rsl_cd",	jmvo1.getAut_cgnt_trv_dstc_rsl_cd());
			map.put("exp_exca_plan_proc_dvn",	jmvo1.getExp_exca_plan_proc_dvn());
			map.put("cnv_trv_dstc",				jmvo1.getCnv_trv_dstc());
			
			// 200708
			map.put("phgp_rl_ptgr_dt",			phgp_rl_ptgr_dt);
			map.put("phgp_apdx_way_cd", 		phgp_apdx_way_cd);
			
		}
		else {
			MBTR01001VO mbtr01001vo = new MBTR01001VO();
			mbtr01001vo = dbTestService.regInfoToEdmsForMobileWeb(request, jmvo.getSms_ts_bvan(), mbtr01001vo);
			
			int insertRow = 0;
			
			// VO SET
			mbtr01001vo.setPboxNo(jmvo.getSms_ts_bvan());
			mbtr01001vo.setApdxFlRutNm("");
			mbtr01001vo.setFrstIpmnEmpno("81900372");
			mbtr01001vo.setFnalAmdrEmpno("81900372");
			
			insertRow = dbTestService.insertTest(mbtr01001vo);
			if(insertRow < 1){
				logger.info("#### 사서함번호: " + StringUtil.nvl(mbtr01001vo.getPboxNo()) + "####");
				logger.info("#### insert 결과: Fail ####");
			}else{
				logger.info("#### insert 결과: Success ####");
			}
			
			MMTI0259VO jmvo1 = new MMTI0259VO();
			jmvo1.setPbox_use_yn("1");
			jmvo1.setPbox_no(jmvo.getSms_ts_bvan());
			jmvo1.setPhgp_cnfm_dt(DateUtil.getDate());
			jmvo1.setPhgp_ptgr_dt(phgp_ptgr_dt);
			jmvo1.setPhgp_strg_yn("1");
			
			// 200708
			jmvo1.setPhgp_rl_ptgr_dt(phgp_rl_ptgr_dt);
			jmvo1.setPhgp_apdx_way_cd(phgp_apdx_way_cd);
			
			if("1".equals(jmvo.getPbox_no_dvcd()) && !"1".equals(jmvo.getCm_yn())) {
				if("03".equals(jmvo.getProc_dvn())) {
					jmvo1.setPbox_chr_nm(request.getParameter("mileage1") + "/" + request.getParameter("mileage2"));
				}
				else {
					jmvo1.setPbox_chr_nm(request.getParameter("mileage1"));
				}
			}
			jmvo1 = dbTestService.getMMTI0259VO(jmvo1);
			
			map.put("errorCode", jmvo1.getErrorCode());
		}
			
		return map;
	}
	
	@RequestMapping(value="/mlFileUploadOCR")
	public @ResponseBody Map<String, String> mlFileUploadOCR(MultipartHttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		Map<String, String> map = new HashMap<String, String>();
		String yyyymmdd = DateUtil.getDate("yyyymmdd");
		
		String phgp_rl_ptgr_dt			= StringUtil.nvl(request.getParameter("phgp_rl_ptgr_dt"));			// 사진실제촬영일자
		String phgp_apdx_way_cd			= StringUtil.nvl(request.getParameter("phgp_apdx_way_cd"));			// 사진첨부방식코드
		
		MMTI0213VO jmvo = new MMTI0213VO();
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("p")));
		jmvo = dbTestService.getMMTI0213VO(jmvo);
		
		String exifDate1 = StringUtil.nvl(request.getParameter("exifDate1"));
		
		if(exifDate1.indexOf(",gallery") > -1) {
			exifDate1 = exifDate1.substring(0, exifDate1.indexOf(",gallery"));
			if(StringUtil.isEmpty(exifDate1)) {
				exifDate1 = DateUtil.getDate();
			}
			else if(Integer.parseInt(exifDate1) > Integer.parseInt(DateUtil.getDate())) {
				map.put("errorCode", "f");
				return map;
			}
		}

		if(exifDate1.indexOf(",gallery") > -1) {
			exifDate1 = exifDate1.substring(0, exifDate1.indexOf(",gallery"));
		}

		ArrayList<File> files = dbTestService.uploadToWAS(request, jmvo.getSms_ts_bvan());
		
		String aut_cgnt_trv_dstc_rsl_cd = "";	// 자동인식주행거리결과코드
		String aut_cgnt_vh_no_rsl_cd = "";		// 자동인식차량번호결과코드
		String aut_cgnt_trv_dstc = "";			// 자동인식주행거리
		String aut_cgnt_vh_no = "";				// 자동인식차량번호
		
		String aut_cgnt_trv_dstc_1 = "";		// 자동인식주행거리1
		String aut_cgnt_trv_dstc_2 = "";		// 자동인식주행거리2
		String aut_cgnt_trv_dstc_3 = "";		// 자동인식주행거리3
		
		
		boolean flag1 = false;
		if(files.size() > 0) {
			FTPUtil ftp = null;
			// [200617]
			FileInputStream in = null;
			FileInputStream fis = null;
			FileOutputStream out = null;
			
			try {
				if("1".equals(jmvo.getAut_cgnt_nn_apcn_yn())) { // OCR서버 문제있으면...
					aut_cgnt_trv_dstc_rsl_cd = "03";
					aut_cgnt_vh_no_rsl_cd = "03";
				}
				else {
					String propsPath = this.getClass().getResource("").getPath();
					propsPath = propsPath.substring(0, propsPath.indexOf("/classes/")) + "/config/ocr_ftp.properties";
					Properties p = new Properties();
					// [200617]
					in = new FileInputStream(propsPath);
					p.load(in);
					in.close();
					// [200617]
					in = null;
					
					String password = p.getProperty("password");
					String decPassword = aes256Decrypt(password);
					if(password.equals(decPassword) || StringUtil.isEmpty(decPassword)) {
						decPassword = password;
						String encPassword = aes256Encrypt(password);
						logger.debug("encPassword: " + encPassword);
						// [200617]
						out = new FileOutputStream(propsPath);
						p.setProperty("password", encPassword);
						p.store(out, "");
						out.close();
						// [200617]
						out = null;
					}
					
					ftp = new FTPUtil(p.getProperty("ip"), p.getProperty("user"), decPassword, Integer.parseInt(p.getProperty("port")));
					
					int working = 0;
					for(int i = 1; i <= 3; i++) {
						String[] ls = ftp.ls("/RECOG_JOB" + i + "/" + yyyymmdd);
						for(int j = 0; j < ls.length; j++) {
							if(".".equals(ls[j]) || "..".equals(ls[j])) continue;
							working++;
						}
					}
	
					if(working <= 6) {
						String filename1 = "";
						
						filename1 = ftp.uploadToOCR("/RECOG/" + yyyymmdd, files.get(0), "--D");

						logger.debug("filename1: " + filename1);

						
						logger.debug("--- 1초 대기 ---");
						Thread.sleep(1000);
						int retryNum = 7;
						for(int retry = 0; retry < retryNum; retry++) {
							String[] ls = ftp.ls("/RECOG_RESULT/" + yyyymmdd);
		
							for(int i = 0; i < ls.length; i++) {
								// logger.debug(ls[i]);
								if(!flag1 && ls[i].equals(filename1)) {
									flag1 = true;
								}
								
								if(flag1) break;
							}
		
							if((flag1) || retry == retryNum - 1) {
								break;
							}
							else {
								logger.debug("--- 0.6초 대기 ---");
								Thread.sleep(600);
							}
						}
						
						logger.debug("flag1: " + flag1);
						
						if(flag1) {
							// [210219]
							if(filename1 != null || !"".equals(filename1)){
								filename1 = filename1.replaceAll("/", "");
								filename1 = filename1.replaceAll("\\\\", "");
								filename1 = filename1.replaceAll("./", "");
								filename1 = filename1.replaceAll("../", "");
								filename1 = filename1.replaceAll("&", "");
							}
							
							String path = files.get(0).getParent() + File.separator + filename1;
							ftp.downloadFromOCR("/RECOG_RESULT/" + yyyymmdd, filename1, path);
							logger.debug("path: " + path);
							
							// [210219]
							File f = new File(files.get(0).getParent() + File.separator + filename1);
							// File f = new File(path);
		
							if(f.exists()) {
								Properties props = new Properties();
								// [210219]
								fis = new FileInputStream(files.get(0).getParent() + File.separator + filename1);
								props.load(fis);
								fis.close();
								// [200617]
								fis = null;
								
								if(!StringUtil.isEmpty(props.getProperty("ODO")) && !StringUtil.isEmpty(props.getProperty("RE_CODE"))) {
									aut_cgnt_trv_dstc = props.getProperty("ODO");
									aut_cgnt_trv_dstc_rsl_cd = "1".equals(props.getProperty("RE_CODE")) || "2".equals(props.getProperty("RE_CODE")) ? "01" : "02";
									
									aut_cgnt_trv_dstc_1 = props.getProperty("ODO");
									
									if(!StringUtil.isEmpty(props.getProperty("ODO2"))) {
										aut_cgnt_trv_dstc_2 = props.getProperty("ODO2");
									}
									
									if(!StringUtil.isEmpty(props.getProperty("ODO3"))) {
										aut_cgnt_trv_dstc_3 = props.getProperty("ODO3");
									}
								}
								
				            	if(f.delete()) {
									logger.debug("삭제: " + path);
								}
							}
						}
						else {
							aut_cgnt_trv_dstc_rsl_cd = "02";
						}						
					}
					else {
						aut_cgnt_trv_dstc_rsl_cd = "02";
						if(!"1".equals(jmvo.getCm_yn())) {
							aut_cgnt_vh_no_rsl_cd = "02";
						}
					}
				}
			}
			catch(Exception e) {
				logger.debug(e.getMessage());
				aut_cgnt_trv_dstc_rsl_cd = "02";
				if(!"1".equals(jmvo.getCm_yn())) {
					aut_cgnt_vh_no_rsl_cd = "02";
				}
			}
			finally {
				if(ftp != null) ftp.disconnect();
				// [200617]
				try{
		    	  	if(in != null){
		    	  		in.close();
		    	  	}
			      }catch(IOException ee){
			    	  System.err.println("[MileageTobeController.mlFileUploadOCR()] IOException 1");
			      }
				try{
		    	  	if(out != null){
		    	  		out.close();
		    	  	}
			      }catch(IOException ee){
			    	  System.err.println("[MileageTobeController.mlFileUploadOCR()] IOException 2");
			      }
				try{
		    	  	if(fis != null){
		    	  		fis.close();
		    	  	}
			      }catch(IOException ee){
			    	  System.err.println("[MileageTobeController.mlFileUploadOCR()] IOException 3");
			      }
			}
		}
		
		HttpSession session = request.getSession();
		Object[] imgfile = new Object[files.size()];
		// [200617]
		FileInputStream fis = null;
		try {
			for(int i = 0; i < files.size(); i++) {
				File f = files.get(i);
				fis = new FileInputStream(f);
				byte[] file = new byte[(int) f.length()];
				fis.read(file);
				imgfile[i] = file;
				fis.close();
				fis = null;
				String fname = f.getName();
				f.delete();
				logger.debug(fname + " 삭제");
			}
		} catch (Exception e) {
			System.err.println("[MileageTobeController.mlFileUploadOCR()] Exception");
		}
		finally {
			try{
				if(fis!=null){
					fis.close();
				}
			}
			catch(IOException ee){
				System.err.println("[MileageTobeController.mlFileUploadOCR()] IOException 4");
		    }
		}
		session.setAttribute("imgfile", imgfile);
		
		map.put("errorCode",					"0");
		map.put("aut_cgnt_trv_dstc_rsl_cd",		aut_cgnt_trv_dstc_rsl_cd);
		map.put("aut_cgnt_vh_no_rsl_cd",		aut_cgnt_vh_no_rsl_cd);
		map.put("aut_cgnt_trv_dstc",			aut_cgnt_trv_dstc);
		map.put("aut_cgnt_vh_no",				aut_cgnt_vh_no);
		
		map.put("aut_cgnt_trv_dstc_1",			aut_cgnt_trv_dstc_1);
		map.put("aut_cgnt_trv_dstc_2",			aut_cgnt_trv_dstc_2);
		map.put("aut_cgnt_trv_dstc_3",			aut_cgnt_trv_dstc_3);
		
		
		map.put("phgp_rl_ptgr_dt",			phgp_rl_ptgr_dt);
		map.put("phgp_apdx_way_cd",			phgp_apdx_way_cd);
			
		return map;
	}
	
	@RequestMapping(value="/mlFileUploadOCR2")
	public @ResponseBody Map<String, String> mlFileUploadOCR2(MultipartHttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		Map<String, String> map = new HashMap<String, String>();

		String aut_cgnt_trv_dstc_rsl_cd	= StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc_rsl_cd"));	// 자동인식주행거리결과코드
		String aut_cgnt_vh_no_rsl_cd	= StringUtil.nvl(request.getParameter("aut_cgnt_vh_no_rsl_cd"));	// 자동인식차량번호결과코드
		String aut_cgnt_trv_dstc		= StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc"));		// 자동인식주행거리
		String aut_cgnt_vh_no			= StringUtil.nvl(request.getParameter("aut_cgnt_vh_no"));			// 자동인식차량번호
		
		String aut_cgnt_trv_dstc_1		= StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc_1"));		// 자동인식주행거리
		String aut_cgnt_trv_dstc_2		= StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc_2"));		// 자동인식주행거리
		String aut_cgnt_trv_dstc_3		= StringUtil.nvl(request.getParameter("aut_cgnt_trv_dstc_3"));		// 자동인식주행거리
		
		// 020708
		String phgp_rl_ptgr_dt			= StringUtil.nvl(request.getParameter("phgp_rl_ptgr_dt"));			// 사진실제촬영일자
		String phgp_apdx_way_cd			= StringUtil.nvl(request.getParameter("phgp_apdx_way_cd"));			// 사진첨부방식코드
		
		MMTI0213VO jmvo = new MMTI0213VO();
		jmvo.setSms_ts_bvan(aes256Decrypt(request.getParameter("p")));
		jmvo = dbTestService.getMMTI0213VO(jmvo);
		
		String exifDate1 = StringUtil.nvl(request.getParameter("exifDate1"));
		String phgp_ptgr_dt = "";
		
		boolean empty = false;
		if(exifDate1.indexOf(",gallery") > -1) {
			exifDate1 = exifDate1.substring(0, exifDate1.indexOf(",gallery"));
			if(StringUtil.isEmpty(exifDate1)) {
				exifDate1 = DateUtil.getDate();
				empty = true;
			}
			else if(Integer.parseInt(exifDate1) > Integer.parseInt(DateUtil.getDate())) {
				map.put("errorCode", "f");
				return map;
			}
		}

		phgp_ptgr_dt = empty ? "" : exifDate1;
		
		if(exifDate1.indexOf(",gallery") > -1) {
			exifDate1 = exifDate1.substring(0, exifDate1.indexOf(",gallery"));
		}
		
		HttpSession session = request.getSession();
		session.setAttribute("exifDate", exifDate1);

		ArrayList<File> files = dbTestService.uploadToWAS(request, jmvo.getSms_ts_bvan());
		
		MMTI0259VO jmvo1 = new MMTI0259VO();
		jmvo1.setPbox_use_yn("1");
		jmvo1.setPbox_no(jmvo.getSms_ts_bvan());
		jmvo1.setPhgp_cnfm_dt(DateUtil.getDate());
		jmvo1.setPhgp_ptgr_dt(phgp_ptgr_dt);
		jmvo1.setPhgp_strg_yn("1");
		if("1".equals(jmvo.getAut_cgnt_nn_apcn_yn())) {
			jmvo1.setPbox_chr_nm(request.getParameter("mileage1"));
		}
		
		if("1".equals(jmvo.getPbox_no_dvcd())) {
			if(!"1".equals(jmvo.getCm_yn())) {
				jmvo1.setInpt_trv_dstc(request.getParameter("mileage1"));
				if(!StringUtil.isEmpty(aut_cgnt_vh_no)) {
					jmvo1.setAut_cgnt_vh_no(aut_cgnt_vh_no);
				}
				
				if(!StringUtil.isEmpty(aut_cgnt_vh_no_rsl_cd)) {
					jmvo1.setAut_cgnt_vh_no_rsl_cd(aut_cgnt_vh_no_rsl_cd);
				}
				else {
					jmvo1.setAut_cgnt_vh_no_rsl_cd("02");
				}
			}
				
			if(!StringUtil.isEmpty(aut_cgnt_trv_dstc)) {
				jmvo1.setAut_cgnt_trv_dstc(aut_cgnt_trv_dstc);
			}
			
			if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_rsl_cd)) {
				jmvo1.setAut_cgnt_trv_dstc_rsl_cd(aut_cgnt_trv_dstc_rsl_cd);
			}
			else {
				jmvo1.setAut_cgnt_trv_dstc_rsl_cd("02");
			}
			
			if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_1)) {
				jmvo1.setAut_cgnt_trv_dstc_1(aut_cgnt_trv_dstc_1);
			}
			
			if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_2)) {
				jmvo1.setAut_cgnt_trv_dstc_2(aut_cgnt_trv_dstc_2);
			}
			
			if(!StringUtil.isEmpty(aut_cgnt_trv_dstc_3)) {
				jmvo1.setAut_cgnt_trv_dstc_3(aut_cgnt_trv_dstc_3);
			}
		}
		
		// 200708
		jmvo1.setPhgp_rl_ptgr_dt(phgp_rl_ptgr_dt);
		jmvo1.setPhgp_apdx_way_cd(phgp_apdx_way_cd);
		
		jmvo1 = dbTestService.getMMTI0259VO(jmvo1);
		
		MBTR01001VO mbtr01001vo = new MBTR01001VO();
		MBTT02001VO mbtt02001vo = new MBTT02001VO(); //20220607추가(주행거리정산이력적재)
		
		if("0".equals(jmvo1.getErrorCode()) && !"1".equals(jmvo.getCm_yn())) {
			jmvo1.setExp_exca_plan_proc_dvn("1");
			jmvo1.setPlno(jmvo.getPlno());
			
			// 200708
			jmvo1.setPhgp_rl_ptgr_dt(phgp_rl_ptgr_dt);
			jmvo1.setPhgp_apdx_way_cd(phgp_apdx_way_cd);
			
			jmvo1 = dbTestService.getMMTI0259VO(jmvo1);
			//mbtr01001vo = dbTestService.regInfoToEdmsForMobileWeb2(request, jmvo.getNtft_srv_rc_ormm_cd(), files, jmvo.getPlno() + "," + jmvo.getChng_plan_no(), mbtr01001vo);
			if("08".equals(jmvo.getProc_dvn())) {
				mbtr01001vo = dbTestService.regInfoToEdmsForMobileWeb2(request, jmvo.getNtft_srv_rc_ormm_cd(), files, jmvo.getPlno() + "," + jmvo.getChng_plan_no(), mbtr01001vo);
//				dbTestService.insertJungsanTest(mbtt02001vo);
			}
			else if(!StringUtil.isEmpty(jmvo1.getPlno()) && !StringUtil.isEmpty(jmvo1.getExp_exca_plan_no())) {
				mbtr01001vo = dbTestService.regInfoToEdmsForMobileWeb2(request, jmvo.getNtft_srv_rc_ormm_cd(), files, jmvo1.getPlno() + "," + jmvo1.getExp_exca_plan_no(), mbtr01001vo);
			}
			else if(!StringUtil.isEmpty(jmvo1.getPlno()) && StringUtil.isEmpty(jmvo1.getExp_exca_plan_no())) {
				mbtr01001vo = dbTestService.regInfoToEdmsForMobileWeb2(request, jmvo.getNtft_srv_rc_ormm_cd(), files, jmvo1.getPlno(), mbtr01001vo);
			}
		}
		else {
			if("1".equals(jmvo.getCm_yn())) {
				mbtr01001vo = dbTestService.regInfoToEdmsForMobileWeb(request, jmvo.getSms_ts_bvan(), mbtr01001vo);
			}
			else {
				mbtr01001vo = dbTestService.regInfoToEdmsForMobileWeb2(request, jmvo.getNtft_srv_rc_ormm_cd(), files, jmvo1.getPlno(), mbtr01001vo);
			}
		}
		
		int insertRow = 0;
		
		// VO SET
		mbtr01001vo.setPboxNo(jmvo.getSms_ts_bvan());
		mbtr01001vo.setApdxFlRutNm("");
		mbtr01001vo.setFrstIpmnEmpno("81900372");
		mbtr01001vo.setFnalAmdrEmpno("81900372");
		
		try {
			insertRow = dbTestService.insertTest(mbtr01001vo);
			if(insertRow < 1){
				logger.info("#### 사서함번호: " + StringUtil.nvl(mbtr01001vo.getPboxNo()) + "####");
				logger.info("#### insert 결과: Fail ####");
			}else{
				logger.info("#### insert 결과: Success ####");
			}
		} catch (Exception e) {
			e.getMessage();
		}
			

		for(int i = 0; i < files.size(); i++) {
			File f = files.get(i);
			String fname = f.getName();
			/*String fsize = Long.toString(f.length());*/
			long fsz = f.length();
			String logg = String.valueOf(fsz);
			/*logger.debug("##파일사이즈: " + logg);*/
			logger.info("##파일사이즈: " + logg);
			// logger.debug("##파일사이즈: " + fsize);
			f.delete();
			logger.debug(fname + " 삭제");
		}
		
		map.put("errorCode",				jmvo1.getErrorCode());
		map.put("z_resp_msg",				jmvo1.getZ_resp_msg());
		map.put("exp_exca_plan_rsl_cd",		jmvo1.getExp_exca_plan_rsl_cd());
		map.put("adc_rtrn_dvn",				jmvo1.getAdc_rtrn_dvn());
		map.put("adc_rtrn_prm",				jmvo1.getAdc_rtrn_prm());
		map.put("plno",						jmvo1.getPlno());
		map.put("exp_exca_plan_no",			jmvo1.getExp_exca_plan_no());
		map.put("exp_exca_plan_bse_dd",		jmvo1.getExp_exca_plan_bse_dd());
		map.put("aut_cgnt_vh_no",			jmvo1.getAut_cgnt_vh_no());
		map.put("aut_cgnt_vh_no_rsl_cd",	jmvo1.getAut_cgnt_vh_no_rsl_cd());
		map.put("aut_cgnt_trv_dstc",		jmvo1.getAut_cgnt_trv_dstc());
		map.put("aut_cgnt_trv_dstc_rsl_cd",	jmvo1.getAut_cgnt_trv_dstc_rsl_cd());
		map.put("exp_exca_plan_proc_dvn",	jmvo1.getExp_exca_plan_proc_dvn());
		map.put("cnv_trv_dstc",				jmvo1.getCnv_trv_dstc());
		map.put("plhd_cust_nm", 			jmvo1.getPlhd_cust_nm());
		map.put("pdc_sr_dvn", 				jmvo1.getPdc_sr_dvn());
		
		//210714
		session.setAttribute("crd_scn_cncl_pss_yn", StringUtil.nvl(jmvo1.getCrd_scn_cncl_pss_yn()));
		session.setAttribute("stlm_cdcp_nm", StringUtil.nvl(jmvo1.getStlm_cdcp_nm()));
		session.setAttribute("stlm_crd_no", StringUtil.nvl(jmvo1.getStlm_crd_no()));
			
		// 201111 추가
		session.setAttribute("trv_dstc1", request.getParameter("mileage1"));
		// 210708 추가
		session.setAttribute("errorCode", jmvo1.getErrorCode());
		session.setAttribute("exp_exca_plan_rsl_cd", jmvo1.getExp_exca_plan_rsl_cd());
		
		session.setAttribute("cnv_trv_dstc", jmvo1.getCnv_trv_dstc());
		session.setAttribute("adc_rtrn_dvn", jmvo1.getAdc_rtrn_dvn());
		session.setAttribute("adc_rtrn_prm", jmvo1.getAdc_rtrn_prm());
		
		session.setAttribute("plno", jmvo1.getPlno());
		session.setAttribute("exp_exca_plan_no", jmvo1.getExp_exca_plan_no());
		session.setAttribute("exp_exca_plan_bse_dd", jmvo1.getExp_exca_plan_bse_dd());
		session.setAttribute("aut_cgnt_vh_no", jmvo1.getAut_cgnt_vh_no());
		session.setAttribute("aut_cgnt_vh_no_rsl_cd", jmvo1.getAut_cgnt_vh_no_rsl_cd());
		session.setAttribute("aut_cgnt_trv_dstc", jmvo1.getAut_cgnt_trv_dstc());
		session.setAttribute("aut_cgnt_trv_dstc_rsl_cd", jmvo1.getAut_cgnt_trv_dstc_rsl_cd());
		session.setAttribute("exp_exca_plan_proc_dvn", jmvo1.getExp_exca_plan_proc_dvn());
		session.setAttribute("cnv_trv_dstc", jmvo1.getCnv_trv_dstc());
		session.setAttribute("plhd_cust_nm", jmvo1.getPlhd_cust_nm());
		session.setAttribute("pdc_sr_dvn", jmvo1.getPdc_sr_dvn());
		
		return map;
	}
	
	@RequestMapping(value="/updatejungsan")
	public @ResponseBody Map<String, String> updatejungsan(HttpServletRequest request, Model model) throws Exception{
		Map<String, String> map = new HashMap<String, String>();
		try {
			map = new HashMap<String, String>();
			XIDB0004VO vo = new XIDB0004VO();
			String seq = StringUtil.nvl(request.getParameter("seq"));
			String stat = StringUtil.nvl(request.getParameter("stat"));
			String msg = StringUtil.nvl(request.getParameter("msg"));
			String eta_dtl_cn = StringUtil.nvl(request.getParameter("eta_dtl_cn"));
			logger.debug("#### XIDB004 ####");
			logger.debug("updatejungsan seq: " + seq);
			logger.debug("updatejungsan stat: " + stat);
			logger.debug("updatejungsan msg: " + msg);
			logger.debug("updatejungsan eta_dtl_cn: " + msg);
			
			vo.setSeq(seq);
			vo.setStat(stat);
			vo.setMsg(msg);
			vo.setEta_dtl_cn(eta_dtl_cn);
			dbTestService.getXIDB0004VO(vo);
			map.put("result", "y");
		} catch (Exception e) {
			map.put("result", "n");
			logger.debug("updatejungsan : " + e.getMessage());
		}
		return map;
	}
	
	private String aes256Decrypt(String enc) {
		String dec = "";
		String encKey = dbTestService.getEncKey();
		
		try {
			dec = DMEncDecUtil.decAES256(enc, null, null, encKey);
		}
		catch(Exception e) {
			logger.debug("DMEncDecUtil.decAES256 실패 시 js로 복호화");
			
			String path = this.getClass().getResource("").getPath();
			logger.debug(path);
			
			// [200617]
			BufferedReader in = null;
			
			try {
				String aesJs = path.substring(0, path.indexOf("/classes/")) + "/aes/gibberish-aes.js";
				if(aesJs.startsWith("/")) aesJs = aesJs.substring(1);
				String cmd = "cscript " + aesJs + " " + encKey  + " " + enc;
				logger.debug("cmd: " + cmd);
				Process p = Runtime.getRuntime().exec(cmd);
				// [200617]
				in = new BufferedReader(new InputStreamReader(p.getInputStream()));
		
				String line = null;  
				boolean flag = false;
				while (true) {
					line = in.readLine();
					if(line == null) break;
					logger.debug(line);
					dec = line;
					if(flag) break;
					if(dec.startsWith("enc: ")) flag = true;
				}
				
				if(dec.startsWith("enc: ")) {
					dec = dec.substring(5);
				}
		
				in.close();
				// [200617]
				in = null;
			}
			catch(Exception e1) {
				return null;
			}
			// [200617]
			finally{
				try{
					if(in!=null){
						in.close();
					}
				}catch(IOException ee){
					System.err.println("[MileageTobeController.aes256Decrypt()] IOException");
				}
			}
		}
		return dec;
	}
	
	private String aes256Encrypt(String plainText) {
		String enc = "";
		String encKey = dbTestService.getEncKey();
		
		try {
			enc = DMEncDecUtil.encAES256(plainText, null, null, encKey);
		}
		catch(Exception e) {
			logger.debug("DMEncDecUtil.encAES256 실패 시 js로 암호화");
			
			String path = this.getClass().getResource("").getPath();
			logger.debug(path);
			// [200617]
			BufferedReader in = null;
			
			try {
				String aesJs = path.substring(0, path.indexOf("/classes/")) + "/aes/gibberish-aes-2.js";
				if(aesJs.startsWith("/")) aesJs = aesJs.substring(1);
				String cmd = "cscript " + aesJs + " " + encKey  + " " + plainText;
				logger.debug("cmd: " + cmd);
				Process p = Runtime.getRuntime().exec(cmd);
				// [200617]
				in = new BufferedReader(new InputStreamReader(p.getInputStream()));
		
				String line = null;
				boolean flag = false;
				while (true) {
					line = in.readLine();
					if(line == null) break;
					logger.debug(line);
					enc = line;
					if(flag) break;
					if(enc.startsWith("plain_text: ")) flag = true;
				}
				
				if(enc.startsWith("plain_text: ")) {
					enc = enc.substring(12);
				}
		
				in.close();
				// [200617]
				in = null;
			}
			catch(Exception e1) {
				return null;
			}
			// [200617]
			finally{
				try{
					if(in!=null){
						in.close();
					}
				}catch(IOException ee){
					System.err.println("[MileageTobeController.aes256Encrypt()] IOException");
				}
			}
		}
		return enc;
	}
	
	private String getDayTime() throws Exception{
		logger.debug("### getDayTime() 시작 ##########################");
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss", Locale.KOREAN);
		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
			return dateFormat.format(timestamp);
	}
	
}
