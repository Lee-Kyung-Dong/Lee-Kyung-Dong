package com.idongbu.smartcustomer.counter.carRider.demo;

import com.idongbu.smartcustomer.counter.carRider.demo.MBTR01001VO;
import com.idongbu.smartcustomer.counter.carRider.demo.MBTT02001VO;

public interface DBTestDao  {
	// Integer insertCntrCarPhoto(Map<String, String> map) throws Exception;
	
	// EDMS 전송이력
	public int insertEdmsHist(MBTR01001VO mbtr01001vo) throws Exception;
	
	// 정산이력 
	public int insertMlHist(MBTT02001VO mbtt02001vo) throws Exception;
	
}