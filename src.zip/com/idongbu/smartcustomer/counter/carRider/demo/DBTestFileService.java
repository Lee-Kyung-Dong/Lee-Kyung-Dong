package com.idongbu.smartcustomer.counter.carRider.demo;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.xpath.XPath;
import org.mybatis.spring.SqlSessionTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.idongbu.smartcustomer.vo.FileMeta;
import com.idongbu.util.HttpClientUtil;
import com.idongbu.util.SoapUtil;
import com.idongbu.util.StringUtil;

import edm.jar.Edms;
import edm.jar.vo.EdmResponseVO;

@Service
public class DBTestFileService {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	//모바일 DB사용하는 sqlsession
	@Autowired(required=true)
	@Qualifier("sqlSession")
	protected SqlSessionTemplate sqlSession;	
	
	private @Value("${legacy.homepage_jojikwon_cd}") String HOMEPAGE_JOJIKWON_CD;
	private @Value("${legacy.edms_step1_url}") String EDMS_STEP1_URL;
	private @Value("${legacy.edms_step3_url}") String EDMS_STEP3_URL;
	private @Value("${legacy.edms_fileserver_ip}") String EDMS_FILESERVER_IP; // 주행거리신규, 블랙박스
	private @Value("${legacy.edms_fileserver_port}") String EDMS_FILESERVER_PORT; // 주행거리신규, 블랙박스
	private @Value("${legacy.edms_fileserver_path}") String EDMS_FILESERVER_PATH; // 주행거리신규, 블랙박스
	private @Value("${carrider.upload.temp.path}") String CARRIDER_UPLOAD_TEMP_PATH;
	private @Value("${legacy.edms_tobe_PreRegServlet}") String EDMS_PRE_REG_SERVLET_URL;
	private @Value("${legacy.edms_edm_url}") String EDMS_EDM_URL;
	
	public LinkedList<FileMeta> upload(MultipartHttpServletRequest request, String path, String rename_keyval) {
		LinkedList<FileMeta> files = new LinkedList<FileMeta>();		
		Iterator<String> iterator = request.getFileNames();
		MultipartFile multipartFile = null;		
		File file = null;
		
		if(path != null) {
			file = new File(path);
			if(!file.exists()) {
				file.mkdirs();
			}
		}	

		int i = 1;
		while(iterator.hasNext()) {
			multipartFile = request.getFile(iterator.next());
			logger.debug("업로드 파일명: " + multipartFile.getOriginalFilename() + ", i: " + i + ", size: " + multipartFile.getSize());

			if("".equals(StringUtil.nvl(multipartFile.getOriginalFilename())) || 0 == multipartFile.getSize() || 
			   ( multipartFile.getOriginalFilename().toUpperCase().indexOf("JPG") < 0 && 
				 multipartFile.getOriginalFilename().toUpperCase().indexOf("JPEG") < 0 &&
				 multipartFile.getOriginalFilename().toUpperCase().indexOf("PNG") < 0 &&
			     multipartFile.getOriginalFilename().toUpperCase().indexOf("GIF") < 0 && 
			     multipartFile.getOriginalFilename().toUpperCase().indexOf("TIF") < 0 && 
			     multipartFile.getOriginalFilename().toUpperCase().indexOf("BMP") < 0 ) ) {
				continue;
			}
			
			try {
				FileCopyUtils.copy(multipartFile.getBytes(), new FileOutputStream(path + multipartFile.getOriginalFilename()));
				
				if("".equals(rename_keyval)) {
					file = renameFile(new File(CARRIDER_UPLOAD_TEMP_PATH + multipartFile.getOriginalFilename()), request.getParameter("SCR_GOGEK_NO"), Integer.toString(i));
				}
				else {
					file = renameFile(new File(CARRIDER_UPLOAD_TEMP_PATH + multipartFile.getOriginalFilename()), rename_keyval, Integer.toString(i));
				}
			}
			catch(IOException e) {
				for(int j = 0; j <= files.size(); j++) {
					File tmp_file = new File(CARRIDER_UPLOAD_TEMP_PATH + files.get(j).getFileName());
					if(tmp_file.delete()) logger.debug("temp file deleted");
				}				
				return null;
			}
			
			FileMeta fileMeta = new FileMeta();
			fileMeta.setFileName(file.getName());
			fileMeta.setFileSize(multipartFile.getSize() / 1024 + " Kb");
			fileMeta.setFileType(multipartFile.getContentType());			
			/*logger.info("주행가입/블박 멀티파트 파일명: " + multipartFile.getOriginalFilename());
			logger.info("주행가입/블박 rename 파일명: " + file.getName());
			logger.info("주행가입/블박 WAS업로드파일 사이즈: " + multipartFile.getSize()/1024 + "KB");*/
			files.add(fileMeta);
			i++;
		}
		return files;
	}
	
	public Map<String, String> getEdmsIdForMobileWeb(String sms_ts_bvan) throws Exception {
		String url = EDMS_PRE_REG_SERVLET_URL + "?SysCode=MTD&KeyNo=" + sms_ts_bvan;
		
		byte[] rtnByte = HttpClientUtil.callUrlPost(url);

		String rtnXmlString = new String(rtnByte,"EUC-KR");
		logger.debug("rtnXmlString : " + rtnXmlString);
		
		Document doc = SoapUtil.stringToDocument(rtnXmlString);
		
		Map<String, String> map = new HashMap<String, String>();
		map.put("UsrId", ((Element)XPath.selectSingleNode(doc, "//UsrId")).getTextTrim());
		map.put("RtnCd", ((Element)XPath.selectSingleNode(doc, "//RtnCd")).getTextTrim());
		map.put("DocNo2", ((Element)XPath.selectSingleNode(doc, "//DocNo2")).getTextTrim());
		map.put("DocNo1", ((Element)XPath.selectSingleNode(doc, "//DocNo1")).getTextTrim());
		map.put("Message", ((Element)XPath.selectSingleNode(doc, "//Message")).getTextTrim());
		map.put("DocType", ((Element)XPath.selectSingleNode(doc, "//DocType")).getTextTrim());
		map.put("Index09", ((Element)XPath.selectSingleNode(doc, "//Index09")).getTextTrim());
		
		return map;
	}
	
	public MBTR01001VO docRegToEdms2(Map<String, String> edmsPreRegInfo, File file, Map<String, String> map, String exifDate, MBTR01001VO mbtr01001vo) throws Exception {
		
		try {
            // BIZ정보 Map
            HashMap<String, String> params = new HashMap<String, String>();
            
            params.put("sysCd", "MTD");
            params.put("userId", edmsPreRegInfo.get("UsrId"));
            params.put("edmsBzDvcd", "CK");
            
            params.put("edmsBzLgcgCd", edmsPreRegInfo.get("Index09"));
            params.put("docTypSmcgCd", edmsPreRegInfo.get("DocType"));
            
            
            if("CKA".equals(edmsPreRegInfo.get("Index09"))) {
            	params.put("planNo", edmsPreRegInfo.get("DocNo1"));
            	params.put("plno", edmsPreRegInfo.get("DocNo2"));
            } else if("CKB".equals(edmsPreRegInfo.get("Index09"))) {
            	params.put("plno", edmsPreRegInfo.get("DocNo1"));
            	params.put("ctrmfPlanNo", edmsPreRegInfo.get("DocNo2"));
            }
            
            params.put("trvDstcPtgrDt", exifDate); //주행거리촬영일자
            
            Edms edms = new Edms();
            EdmResponseVO respVO = edms.uploadFile(EDMS_EDM_URL, file, params);
            
            logger.info("###### docRegToEdms2 리턴값 ######");
            logger.info("planNo: " + params.get("planNo"));
            logger.info("plno: " + params.get("plno"));
            logger.info("rslYn: " + respVO.getRslYn());
            logger.info("rslErrCd: " + respVO.getRslErrCd());
            logger.info("rslMsg: " + respVO.getRslMsg());
            logger.info("trGuid: " + respVO.getTrGuid());
            logger.info("sysCd: " + params.get("sysCd"));
            logger.info("userId: " + params.get("userId"));
            logger.info("edmsBzDvcd: " + params.get("edmsBzDvcd"));
            logger.info("edmsBzLgcgCd: " + params.get("edmsBzLgcgCd"));
            logger.info("ctrmfPlanNo: " + StringUtil.nvl(params.get("ctrmfPlanNo")));
            logger.info("docTypSmcgCd: " + params.get("docTypSmcgCd"));
            logger.info("trvDstcPtgrDt: " + params.get("trvDstcPtgrDt"));
            logger.info("EDMS_EDM_URL: " + EDMS_EDM_URL);
            logger.info("file: " + file);
            logger.info("file size: " + file.length());
            
            mbtr01001vo.setPlno(params.get("plno"));
            mbtr01001vo.setPlanNo(StringUtil.nvl(params.get("planNo")));
            mbtr01001vo.setCtrmfPlanNo(StringUtil.nvl(params.get("ctrmfPlanNo")));
            mbtr01001vo.setEdmsBzLgcgCd(params.get("edmsBzLgcgCd"));
            mbtr01001vo.setDocTypSmcgCd(params.get("docTypSmcgCd"));
            mbtr01001vo.setNrmYn(respVO.getRslYn());
            mbtr01001vo.setProcRslMsgCn(StringUtil.nvl(respVO.getRslMsg()));
            mbtr01001vo.setEdmsFlSizeVal(file.length());
            
            if ("N".equals(respVO.getRslYn())) {
            	if(map != null) map.put("MSG", respVO.getRslMsg());
            }        
        } catch(Exception e) {
        	// return false;
        }
		
		return mbtr01001vo;
	}
	
	public MBTR01001VO docRegToEdms3(String edmsId, File file, Map<String, String> map, String exifDate, String plnoAndPlanNo, MBTR01001VO mbtr01001vo) throws Exception {
		
		try {
            // BIZ정보 Map
            HashMap<String, String> params = new HashMap<String, String>();
            
            params.put("sysCd", "MTD");
            params.put("userId", edmsId);
            params.put("edmsBzDvcd", "CK");

            if(plnoAndPlanNo.indexOf(",") > -1) {
            	String[] p = plnoAndPlanNo.split(",");
            	params.put("edmsBzLgcgCd", "CKB");
            	params.put("plno", p[0]);
            	params.put("ctrmfPlanNo", p[1]);
            	params.put("docTypSmcgCd", "CKB008");
            }
            else {
            	params.put("edmsBzLgcgCd", "CKI");
            	params.put("plno", plnoAndPlanNo);
            	params.put("docTypSmcgCd", "CKI002");
            }
            
            params.put("trvDstcPtgrDt", exifDate); //주행거리촬영일자

            Edms edms = new Edms();
            EdmResponseVO respVO = edms.uploadFile(EDMS_EDM_URL, file, params);
            
            logger.info("###### docRegToEdms3 리턴값 ######");
            logger.info("plno: " + params.get("plno"));
            logger.info("ctrmfPlanNo: " + StringUtil.nvl(params.get("ctrmfPlanNo")));
            logger.info("rslYn: " + respVO.getRslYn());
            logger.info("rslErrCd: " + respVO.getRslErrCd());
            logger.info("rslMsg: " + respVO.getRslMsg());
            logger.info("trGuid: " + respVO.getTrGuid());
            logger.info("sysCd: " + params.get("sysCd"));
            logger.info("userId: " + params.get("userId"));
            logger.info("edmsBzDvcd: " + params.get("edmsBzDvcd"));
            logger.info("edmsBzLgcgCd: " + params.get("edmsBzLgcgCd"));
            logger.info("docTypSmcgCd: " + params.get("docTypSmcgCd"));
            logger.info("trvDstcPtgrDt: " + params.get("trvDstcPtgrDt"));
            logger.info("EDMS_EDM_URL: " + EDMS_EDM_URL);
            logger.info("file: " + file);
            logger.info("file size: " + file.length());            
            
            mbtr01001vo.setPlno(params.get("plno"));
            mbtr01001vo.setPlanNo(StringUtil.nvl(params.get("plan_no")));
            mbtr01001vo.setCtrmfPlanNo(StringUtil.nvl(params.get("ctrmfPlanNo")));
            mbtr01001vo.setEdmsBzLgcgCd(params.get("edmsBzLgcgCd"));
            mbtr01001vo.setDocTypSmcgCd(params.get("docTypSmcgCd"));
            mbtr01001vo.setNrmYn(respVO.getRslYn());
            mbtr01001vo.setProcRslMsgCn(StringUtil.nvl(respVO.getRslMsg()));
            mbtr01001vo.setEdmsFlSizeVal(file.length());
            
            if ("N".equals(respVO.getRslYn())) {
            	if(map != null) map.put("MSG", respVO.getRslMsg());
            }        
        } catch(Exception e) {
        	// return false;
        }
		
		return mbtr01001vo;

	}
	
	
	public File renameFile(File file, String keyval, String num) {
		if(file == null) {
			return null;
		}
		else {
			java.util.Date currentdate = new java.util.Date();
			java.text.SimpleDateFormat format = new java.text.SimpleDateFormat("yyyyMMddHHmmss");	
			String tmpStr = keyval + "_" + num + "_" + format.format(currentdate) + file.getName().substring(file.getName().lastIndexOf("."), file.getName().length());
			File newFile = new File(file.getParent() + "\\" + tmpStr);
			file.renameTo(newFile);
			return newFile;			
		}
	}
	
	
}
