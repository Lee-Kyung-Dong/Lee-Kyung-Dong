package com.idongbu.smartcustomer.counter.carRider.demo;

// EDMS 전송이력 VO
public class MBTR01001VO {

	private int sqno;					// 일련번호
	private String pboxNo;				// 사서함번호
	private String plno;				// 증권번호
	private String planNo;				// 설계번호
	private String ctrmfPlanNo;		// 변경설계번호
	private String edmsBzLgcgCd;		// EDMS업무대분류코드
	private String docTypSmcgCd;		// 문서유형소분류코드
	private String flTsDttm;			// 파일전송일시
	private String nrmYn;				// 정상여부
	private String procRslMsgCn;		// 처리결과메시지내용
	private String apdxFlRutNm;		// 첨부파일경로명
	private long edmsFlSizeVal;		// EDMS파일크기값
	private String frstIpmnEmpno;		// 최초입력자사원번호
	private String frstInptDttm;		// 최초입력일시
	private String fnalAmdrEmpno;		// 최종수정자사원번호
	private String fnalUpdtDttm;
	public int getSqno() {
		return sqno;
	}
	public void setSqno(int sqno) {
		this.sqno = sqno;
	}
	public String getPboxNo() {
		return pboxNo;
	}
	public void setPboxNo(String pboxNo) {
		this.pboxNo = pboxNo;
	}
	public String getPlno() {
		return plno;
	}
	public void setPlno(String plno) {
		this.plno = plno;
	}
	public String getPlanNo() {
		return planNo;
	}
	public void setPlanNo(String planNo) {
		this.planNo = planNo;
	}
	public String getCtrmfPlanNo() {
		return ctrmfPlanNo;
	}
	public void setCtrmfPlanNo(String ctrmfPlanNo) {
		this.ctrmfPlanNo = ctrmfPlanNo;
	}
	public String getEdmsBzLgcgCd() {
		return edmsBzLgcgCd;
	}
	public void setEdmsBzLgcgCd(String edmsBzLgcgCd) {
		this.edmsBzLgcgCd = edmsBzLgcgCd;
	}
	public String getDocTypSmcgCd() {
		return docTypSmcgCd;
	}
	public void setDocTypSmcgCd(String docTypSmcgCd) {
		this.docTypSmcgCd = docTypSmcgCd;
	}
	public String getFlTsDttm() {
		return flTsDttm;
	}
	public void setFlTsDttm(String flTsDttm) {
		this.flTsDttm = flTsDttm;
	}
	public String getNrmYn() {
		return nrmYn;
	}
	public void setNrmYn(String nrmYn) {
		this.nrmYn = nrmYn;
	}
	public String getProcRslMsgCn() {
		return procRslMsgCn;
	}
	public void setProcRslMsgCn(String procRslMsgCn) {
		this.procRslMsgCn = procRslMsgCn;
	}
	public String getApdxFlRutNm() {
		return apdxFlRutNm;
	}
	public void setApdxFlRutNm(String apdxFlRutNm) {
		this.apdxFlRutNm = apdxFlRutNm;
	}
	public long getEdmsFlSizeVal() {
		return edmsFlSizeVal;
	}
	public void setEdmsFlSizeVal(long edmsFlSizeVal) {
		this.edmsFlSizeVal = edmsFlSizeVal;
	}
	public String getFrstIpmnEmpno() {
		return frstIpmnEmpno;
	}
	public void setFrstIpmnEmpno(String frstIpmnEmpno) {
		this.frstIpmnEmpno = frstIpmnEmpno;
	}
	public String getFrstInptDttm() {
		return frstInptDttm;
	}
	public void setFrstInptDttm(String frstInptDttm) {
		this.frstInptDttm = frstInptDttm;
	}
	public String getFnalAmdrEmpno() {
		return fnalAmdrEmpno;
	}
	public void setFnalAmdrEmpno(String fnalAmdrEmpno) {
		this.fnalAmdrEmpno = fnalAmdrEmpno;
	}
	public String getFnalUpdtDttm() {
		return fnalUpdtDttm;
	}
	public void setFnalUpdtDttm(String fnalUpdtDttm) {
		this.fnalUpdtDttm = fnalUpdtDttm;
	}		
	
}
	