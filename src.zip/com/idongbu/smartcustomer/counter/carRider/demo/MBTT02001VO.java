package com.idongbu.smartcustomer.counter.carRider.demo;

// 정산이력 VO
public class MBTT02001VO {

	private int sqno;					// 일련번호
	private String pboxNo;				// 사서함번호
	private String tlgIdVal;			// 전문ID값
	private String esbTrscId;			// ESB트랜잭션ID
	private String plno;				// 증권번호
	private String planNo;				// 설계번호
	private String rnwPlno;				// 갱신증권번호
	private String regtDttm;			// 등록일시
	private String tlgProcRslCdVal;		// 전문처리결과코드값
	private String tlgErrCdVal;			// 전문에러코드값
	private String hdlrEmpno;			// 취급자사원번호
	private String respCn;				// 응답내용
	private String rslCn;				// 결과내용
	private String frstIpmnEmpno;		// 최초입력자사원번호
	private String frstInptDttm;		// 최초입력일시
	private String fnalAmdrEmpno;		// 최종수정자사원번호
	private String fnalUpdtDttm;		// 최종수정일시
	
	// 20220524 추가
	private String pboxNoDvcd;			// 사서함번호구분코드
	private String procDvn;				// 처리구분
	private String trvDstcExpExcaDvcd;	// 주행거리만기정산구분코드
	private String trvDstcChngAplyDvn;	// 주행거리변경신청구분
	private String hdlrFireYn;			// 취급자해촉여부
	private String mtccYn;				// 이륜차여부
	private double autCgntTrvDstc;		// 자동인식주행거리
	private String autCgntTrvDstcRslCd;	// 자동인식주행거리결과코드
	private double inptTrvDstc;			// 입력주행거리
	private double cnvTrvDstc;			// 환산주행거리
	private String expExcaPlanRslCd;	// 만기정산설계결과코드
	private String excaBzProcDvn;		// 정산업무처리구분
	private String excaRtrnDvn;			// 정산환급구분
	private String pdcSrDvn;			// 상품출처구분
	private double adcRtrnPrm;			// 추징환급보험료
	private String trvDstcSplcExcaYn;	// 주행거리간편정산여부
	private String imagDupYn;			// 이미지중복여부
	private String nrmProcYn;			// 정산처리여부
	private String crdScnCnclPssYn;		// 카드부분취소가능여부
	
	//20220630 추가
	private String adcRtrnDvn;			//추징환급구분
	private String scrnProcCd;			//화면처리코드
	private String ctcPlno;				//계약증권번호
	private String trvDstcProcDvcd;		//주행거리처리구분코드
	private String mblSndNo;			//모바일발송번호
	private String planPlnoDvcd;		//설계증권번호구분코드
	private String planPlno; 			//설계증권번호
	private String chngPlanNo;			//변경설계번호
	private String dstTtyDvn1;			//할인특약구분1(01:주행거리)
	private String dstTtyDvn2;			//할인특약구분2(02:블랙박스)
	private String dstTtyDvn3;			//할인특약구분3(03:베이비인카)
	private String dstTtyDvn4;			//할인특약구분4(04:차선이탈)
	private String dstTtyDvn5;			//할인특약구분5(05:전방충돌)
	private String phgpRegtTgt1;		//사진등록대상1
	private String phgpRegtTgt2;		//사진등록대상2
	private String phgpRegtTgt3;		//사진등록대상3
	private String phgpRegtTgt4;		//사진등록대상4
	private String phgpRegtTgt5;		//사진등록대상5
	
	public int getSqno() {
		return sqno;
	}
	public void setSqno(int sqno) {
		this.sqno = sqno;
	}
	public String getPboxNo() {
		return pboxNo;
	}
	public void setPboxNo(String pboxNo) {
		this.pboxNo = pboxNo;
	}
	public String getTlgIdVal() {
		return tlgIdVal;
	}
	public void setTlgIdVal(String tlgIdVal) {
		this.tlgIdVal = tlgIdVal;
	}
	public String getEsbTrscId() {
		return esbTrscId;
	}
	public void setEsbTrscId(String esbTrscId) {
		this.esbTrscId = esbTrscId;
	}
	public String getPlno() {
		return plno;
	}
	public void setPlno(String plno) {
		this.plno = plno;
	}
	public String getPlanNo() {
		return planNo;
	}
	public void setPlanNo(String planNo) {
		this.planNo = planNo;
	}
	public String getRnwPlno() {
		return rnwPlno;
	}
	public void setRnwPlno(String rnwPlno) {
		this.rnwPlno = rnwPlno;
	}
	public String getRegtDttm() {
		return regtDttm;
	}
	public void setRegtDttm(String regtDttm) {
		this.regtDttm = regtDttm;
	}
	public String getTlgProcRslCdVal() {
		return tlgProcRslCdVal;
	}
	public void setTlgProcRslCdVal(String tlgProcRslCdVal) {
		this.tlgProcRslCdVal = tlgProcRslCdVal;
	}
	public String getTlgErrCdVal() {
		return tlgErrCdVal;
	}
	public void setTlgErrCdVal(String tlgErrCdVal) {
		this.tlgErrCdVal = tlgErrCdVal;
	}
	public String getHdlrEmpno() {
		return hdlrEmpno;
	}
	public void setHdlrEmpno(String hdlrEmpno) {
		this.hdlrEmpno = hdlrEmpno;
	}
	public String getRespCn() {
		return respCn;
	}
	public void setRespCn(String respCn) {
		this.respCn = respCn;
	}
	public String getRslCn() {
		return rslCn;
	}
	public void setRslCn(String rslCn) {
		this.rslCn = rslCn;
	}
	public String getFrstIpmnEmpno() {
		return frstIpmnEmpno;
	}
	public void setFrstIpmnEmpno(String frstIpmnEmpno) {
		this.frstIpmnEmpno = frstIpmnEmpno;
	}
	public String getFrstInptDttm() {
		return frstInptDttm;
	}
	public void setFrstInptDttm(String frstInptDttm) {
		this.frstInptDttm = frstInptDttm;
	}
	public String getFnalAmdrEmpno() {
		return fnalAmdrEmpno;
	}
	public void setFnalAmdrEmpno(String fnalAmdrEmpno) {
		this.fnalAmdrEmpno = fnalAmdrEmpno;
	}
	public String getFnalUpdtDttm() {
		return fnalUpdtDttm;
	}
	public void setFnalUpdtDttm(String fnalUpdtDttm) {
		this.fnalUpdtDttm = fnalUpdtDttm;
	}
	public String getPboxNoDvcd() {
		return pboxNoDvcd;
	}
	public void setPboxNoDvcd(String pboxNoDvcd) {
		this.pboxNoDvcd = pboxNoDvcd;
	}
	public String getProcDvn() {
		return procDvn;
	}
	public void setProcDvn(String procDvn) {
		this.procDvn = procDvn;
	}
	public String getTrvDstcExpExcaDvcd() {
		return trvDstcExpExcaDvcd;
	}
	public void setTrvDstcExpExcaDvcd(String trvDstcExpExcaDvcd) {
		this.trvDstcExpExcaDvcd = trvDstcExpExcaDvcd;
	}
	public String getTrvDstcChngAplyDvn() {
		return trvDstcChngAplyDvn;
	}
	public void setTrvDstcChngAplyDvn(String trvDstcChngAplyDvn) {
		this.trvDstcChngAplyDvn = trvDstcChngAplyDvn;
	}
	public String getHdlrFireYn() {
		return hdlrFireYn;
	}
	public void setHdlrFireYn(String hdlrFireYn) {
		this.hdlrFireYn = hdlrFireYn;
	}
	public String getMtccYn() {
		return mtccYn;
	}
	public void setMtccYn(String mtccYn) {
		this.mtccYn = mtccYn;
	}
	public void setCnvTrvDstc(int cnvTrvDstc) {
		this.cnvTrvDstc = cnvTrvDstc;
	}
	public String getAutCgntTrvDstcRslCd() {
		return autCgntTrvDstcRslCd;
	}
	public void setAutCgntTrvDstcRslCd(String autCgntTrvDstcRslCd) {
		this.autCgntTrvDstcRslCd = autCgntTrvDstcRslCd;
	}
	public double getInptTrvDstc() {
		return inptTrvDstc;
	}
	public void setInptTrvDstc(double inptTrvDstc) {
		this.inptTrvDstc = inptTrvDstc;
	}
	public double getCnvTrvDstc() {
		return cnvTrvDstc;
	}
	public void setCnvTrvDstc(double cnvTrvDstc) {
		this.cnvTrvDstc = cnvTrvDstc;
	}
	public String getExpExcaPlanRslCd() {
		return expExcaPlanRslCd;
	}
	public void setExpExcaPlanRslCd(String expExcaPlanRslCd) {
		this.expExcaPlanRslCd = expExcaPlanRslCd;
	}
	public String getExcaBzProcDvn() {
		return excaBzProcDvn;
	}
	public void setExcaBzProcDvn(String excaBzProcDvn) {
		this.excaBzProcDvn = excaBzProcDvn;
	}
	public String getExcaRtrnDvn() {
		return excaRtrnDvn;
	}
	public void setExcaRtrnDvn(String excaRtrnDvn) {
		this.excaRtrnDvn = excaRtrnDvn;
	}
	public String getPdcSrDvn() {
		return pdcSrDvn;
	}
	public void setPdcSrDvn(String pdcSrDvn) {
		this.pdcSrDvn = pdcSrDvn;
	}
	public double getAdcRtrnPrm() {
		return adcRtrnPrm;
	}
	public void setAdcRtrnPrm(double adcRtrnPrm) {
		this.adcRtrnPrm = adcRtrnPrm;
	}
	public String getTrvDstcSplcExcaYn() {
		return trvDstcSplcExcaYn;
	}
	public void setTrvDstcSplcExcaYn(String trvDstcSplcExcaYn) {
		this.trvDstcSplcExcaYn = trvDstcSplcExcaYn;
	}
	public String getImagDupYn() {
		return imagDupYn;
	}
	public void setImagDupYn(String imagDupYn) {
		this.imagDupYn = imagDupYn;
	}
	public String getNrmProcYn() {
		return nrmProcYn;
	}
	public void setNrmProcYn(String nrmProcYn) {
		this.nrmProcYn = nrmProcYn;
	}
	public String getCrdScnCnclPssYn() {
		return crdScnCnclPssYn;
	}
	public void setCrdScnCnclPssYn(String crdScnCnclPssYn) {
		this.crdScnCnclPssYn = crdScnCnclPssYn;
	}
	public double getAutCgntTrvDstc() {
		return autCgntTrvDstc;
	}
	public void setAutCgntTrvDstc(double autCgntTrvDstc) {
		this.autCgntTrvDstc = autCgntTrvDstc;
	}
	public String getAdcRtrnDvn() {
		return adcRtrnDvn;
	}
	public void setAdcRtrnDvn(String adcRtrnDvn) {
		this.adcRtrnDvn = adcRtrnDvn;
	}
	public String getScrnProcCd() {
		return scrnProcCd;
	}
	public void setScrnProcCd(String scrnProcCd) {
		this.scrnProcCd = scrnProcCd;
	}
	public String getCtcPlno() {
		return ctcPlno;
	}
	public void setCtcPlno(String ctcPlno) {
		this.ctcPlno = ctcPlno;
	}
	public String getTrvDstcProcDvcd() {
		return trvDstcProcDvcd;
	}
	public void setTrvDstcProcDvcd(String trvDstcProcDvcd) {
		this.trvDstcProcDvcd = trvDstcProcDvcd;
	}
	public String getMblSndNo() {
		return mblSndNo;
	}
	public void setMblSndNo(String mblSndNo) {
		this.mblSndNo = mblSndNo;
	}
	public String getPlanPlnoDvcd() {
		return planPlnoDvcd;
	}
	public void setPlanPlnoDvcd(String planPlnoDvcd) {
		this.planPlnoDvcd = planPlnoDvcd;
	}
	public String getPlanPlno() {
		return planPlno;
	}
	public void setPlanPlno(String planPlno) {
		this.planPlno = planPlno;
	}
	public String getChngPlanNo() {
		return chngPlanNo;
	}
	public void setChngPlanNo(String chngPlanNo) {
		this.chngPlanNo = chngPlanNo;
	}
	public String getDstTtyDvn1() {
		return dstTtyDvn1;
	}
	public void setDstTtyDvn1(String dstTtyDvn1) {
		this.dstTtyDvn1 = dstTtyDvn1;
	}
	public String getDstTtyDvn2() {
		return dstTtyDvn2;
	}
	public void setDstTtyDvn2(String dstTtyDvn2) {
		this.dstTtyDvn2 = dstTtyDvn2;
	}
	public String getDstTtyDvn3() {
		return dstTtyDvn3;
	}
	public void setDstTtyDvn3(String dstTtyDvn3) {
		this.dstTtyDvn3 = dstTtyDvn3;
	}
	public String getDstTtyDvn4() {
		return dstTtyDvn4;
	}
	public void setDstTtyDvn4(String dstTtyDvn4) {
		this.dstTtyDvn4 = dstTtyDvn4;
	}
	public String getDstTtyDvn5() {
		return dstTtyDvn5;
	}
	public void setDstTtyDvn5(String dstTtyDvn5) {
		this.dstTtyDvn5 = dstTtyDvn5;
	}
	public String getPhgpRegtTgt1() {
		return phgpRegtTgt1;
	}
	public void setPhgpRegtTgt1(String phgpRegtTgt1) {
		this.phgpRegtTgt1 = phgpRegtTgt1;
	}
	public String getPhgpRegtTgt2() {
		return phgpRegtTgt2;
	}
	public void setPhgpRegtTgt2(String phgpRegtTgt2) {
		this.phgpRegtTgt2 = phgpRegtTgt2;
	}
	public String getPhgpRegtTgt3() {
		return phgpRegtTgt3;
	}
	public void setPhgpRegtTgt3(String phgpRegtTgt3) {
		this.phgpRegtTgt3 = phgpRegtTgt3;
	}
	public String getPhgpRegtTgt4() {
		return phgpRegtTgt4;
	}
	public void setPhgpRegtTgt4(String phgpRegtTgt4) {
		this.phgpRegtTgt4 = phgpRegtTgt4;
	}
	public String getPhgpRegtTgt5() {
		return phgpRegtTgt5;
	}
	public void setPhgpRegtTgt5(String phgpRegtTgt5) {
		this.phgpRegtTgt5 = phgpRegtTgt5;
	}
	
}
