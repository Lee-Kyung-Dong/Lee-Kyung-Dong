package com.idongbu.smartcustomer.customer.mapper;

import com.idongbu.smartcustomer.vo.EmsMailVO;

public interface CustomerDao {
	
	public int insertHaaMailForm(EmsMailVO vo);
	
	public String selectContent(long mail_seq);
}
