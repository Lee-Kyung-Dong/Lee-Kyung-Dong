package com.idongbu.smartcustomer.contract.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.idongbu.smartcustomer.vo.AutoIcheTableVO;
import com.idongbu.smartcustomer.vo.ComnInfoVO;


/**
 * @info myBatis 연동위한 interface 
 */
public interface ContractDao {

	String getCodeSelet(@Param("cl_cd") String cl_cd , @Param("dstin_cd") String dstin_cd);
	
	String selectPlaceName(String zip_no);
	
	//홈페이지 COMN_INFO조회
	List<ComnInfoVO> selectComCdList(ComnInfoVO vo);
	
	/* 2016.01.28 박형규 안쓰는 소스로 파악하여 주석처리(2017.1.28일에도 문제 없으면 완전 삭제할것)
	//자동이체인서트 maxseq
	int getMaxSeq();
	
	//자동이체 로그저장
	int autoIcheInsert(AutoIcheTableVO vo);
	
	//자동이체변경 업데이트
	int autoIcheUpdate(AutoIcheTableVO vo);
	
	//이체일변경시 업데이트 
	//void autoInsertIcheDd(AutoIcheTableVO vo);
	 */
}
