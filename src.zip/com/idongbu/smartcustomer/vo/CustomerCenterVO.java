package com.idongbu.smartcustomer.vo;

public class CustomerCenterVO {
	
	public String ERR	= null;

	public static final String  RELAYGB             = "116U"; //대신에 sysid 를 전달해야 하기 때문에 사용함

	// 동부 기업보험 파트 구자은 과장의 요청사항 : 2011.03.03
	public String GOGAEK_NO      = ""; // 고객번호 (-) 제외
	public String SANGDAMIL_DATE = ""; // 상담일자 (yyyymmddhh24miss)
	public String BALSHINJA_NO   = ""; // 발신자 번호 (-) 제외
	public String STATUS         = ""; // 접수, 완료
	public String UPMU_DESC1     = ""; // 상담업무 대분류 : 메뉴 레벨1
	public String UPMU_DESC2     = ""; // 상담업무 대분류 : 메뉴 레벨2
	public String UPMU_DESC3     = ""; // 상담업무 대분류 : 메뉴 레벨3
	public String POLI_NO        = ""; // 증권번호
    public String JUBSU_NO       = ""; // 접수번호
    public String SULGYE_NO      = ""; // 설계번호
    public String NOTE           = ""; // 비고	
	public String getERR() {
		return ERR;
	}
	public void setERR(String eRR) {
		ERR = eRR;
	}
	public String getGOGAEK_NO() {
		return GOGAEK_NO;
	}
	public void setGOGAEK_NO(String gOGAEK_NO) {
		GOGAEK_NO = gOGAEK_NO;
	}
	public String getSANGDAMIL_DATE() {
		return SANGDAMIL_DATE;
	}
	public void setSANGDAMIL_DATE(String sANGDAMIL_DATE) {
		SANGDAMIL_DATE = sANGDAMIL_DATE;
	}
	public String getBALSHINJA_NO() {
		return BALSHINJA_NO;
	}
	public void setBALSHINJA_NO(String bALSHINJA_NO) {
		BALSHINJA_NO = bALSHINJA_NO;
	}
	public String getSTATUS() {
		return STATUS;
	}
	public void setSTATUS(String sTATUS) {
		STATUS = sTATUS;
	}
	public String getUPMU_DESC1() {
		return UPMU_DESC1;
	}
	public void setUPMU_DESC1(String uPMU_DESC1) {
		UPMU_DESC1 = uPMU_DESC1;
	}
	public String getUPMU_DESC2() {
		return UPMU_DESC2;
	}
	public void setUPMU_DESC2(String uPMU_DESC2) {
		UPMU_DESC2 = uPMU_DESC2;
	}
	public String getUPMU_DESC3() {
		return UPMU_DESC3;
	}
	public void setUPMU_DESC3(String uPMU_DESC3) {
		UPMU_DESC3 = uPMU_DESC3;
	}
	public String getPOLI_NO() {
		return POLI_NO;
	}
	public void setPOLI_NO(String pOLI_NO) {
		POLI_NO = pOLI_NO;
	}
	public String getJUBSU_NO() {
		return JUBSU_NO;
	}
	public void setJUBSU_NO(String jUBSU_NO) {
		JUBSU_NO = jUBSU_NO;
	}
	public String getSULGYE_NO() {
		return SULGYE_NO;
	}
	public void setSULGYE_NO(String sULGYE_NO) {
		SULGYE_NO = sULGYE_NO;
	}
	public String getNOTE() {
		return NOTE;
	}
	public void setNOTE(String nOTE) {
		NOTE = nOTE;
	}
	public static String getRelaygb() {
		return RELAYGB;
	}
}
