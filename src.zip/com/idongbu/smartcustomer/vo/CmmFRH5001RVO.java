package com.idongbu.smartcustomer.vo;

import com.idongbu.common.vo.CMMVO;

public class CmmFRH5001RVO extends CMMVO {
	
	public CmmFRH5001RVO() {
		super.setPGMID(this.proid);
		super.setTRID(this.trid);
	}

	private static final String proid  = "FRH5001R";
	private static final String trid   = "RHK0";
	private String rURL				   = "";
                                       
	private String CC_CHANNEL		   = "";
	private String CC_UKEY		       = "";
	private String CC_PGMID		       = "";
	private String CC_PROC_GB		   = "";
	private String CC_FUN_KEY		   = "";
	private String CC_USER_GB		   = "";
	private String CC_USER_CD		   = "";
	private String CC_JIJUM_CD		   = "";
	private String CC_JIBU_CD		   = "";
	private String CC_PROTOCOL		   = "";
	private String CC_COND_CD		   = "";
	private String CC_LAST_FLAG		   = "";
	private String CC_CURSOR_MAP	   = "";
	private String CC_CURSOR_IDX	   = "";
	private String CC_MESSAGE_CD	   = "";
	private String HC_MESSAGE_NM	   = "";
	private String CC_SYS_ERR		   = "";
	private String CC_FILLER		   = "";
	private String SS_JOGUN		       = "";
	private String SS_JOGUN_NO		   = "";
	private String SS_SAGO_YMD		   = "";
	private String SS_SAGO_HM		   = "";
	private String SS_SINGU_GB		   = "";
	private String SS_ILJANGJA_GB      = "";
	private String SS_SAGO_JUBSU_NO    = "";
	private String SS_SAGO_JUBSU_SEQ   = "";
	private String SS_IPRYUK_YMD	   = "";
	private String SS_IPRYUK_HM		   = "";
	private String SS_GOGEK_GB		   = "";
	private String SS_GOGEK_GEINBUPIN  = "";
	private String SS_GOGEK_NO		   = "";
	private String HS_GOGEK_NM		   = "";
	private String SS_GOGEK_AGE		   = "";
	private String SS_GOGEK_JOB_CD	   = "";
	private String HS_GOGEK_JOB_NM	   = "";
	private String SS_GOGEK_TEL		   = "";
	private String SS_JUBSU_UPMU1      = "";
	private String SS_JUBSU_UPMU2      = "";
	private String SS_JUBSU_UPMU3      = "";
	private String HS_TONGBOJA_NM      = "";
	private String SS_TONGBOJA_GWANGYE = "";
	private String SS_TONGBOJA_TEL     = "";
	private String SS_JUBSU_CHANNEL    = "";
	private String SS_INMUL		       = "";
	private String HS_INMUL		       = "";
	private String HS_ANNE_CD2		   = "";
	private String SS_TYPE_CD		   = "";
	private String SS_WONIN_CD		   = "";
	private String SS_UNHENG_CD1	   = "";
	private String SS_UNHENG_CD2	   = "";
	private String SS_SAGO_JANGSO_GB   = "";
	private String SS_SAGO_ZIP		   = "";
	private String HS_SAGO_ZIP		   = "";
	private String HS_SAGO_JANGSO	   = "";
	private String HS_SAGO_NEYONG	   = "";
	private String HS_TUKGI_SAHANG	   = "";
	private String SS_CHURI_CD		   = "";
	private String SS_CHURI_OFFICE	   = "";
	private String SS_SINGO_CD		   = "";
	private String HS_SINGO_NM		   = "";
	private String SS_SERYU_CD		   = "";
	private String SS_SERYU_GB		   = "";
	private String SS_SERYU_YMD		   = "";
	private String SS_PIBO_EMAIL	   = "";
	private String SS_WALRYO_YN		   = "";
	private String SS_SANGDAM_CNT	   = "";
	private String SS_JUBSU_CENTER	   = "";
	private String SS_JUBSU_TEAM	   = "";
	private String SS_JUBSU_JIJUM	   = "";
	private String SS_JUBSUJA		   = "";
	private String HS_JUBSUJA_NM	   = "";
	private String SS_JUBSU_YMD		   = "";
	private String SS_JUBSU_HM		   = "";
	private String SS_GUANSIM_CD	   = "";
	private String SS_EMERGENCY_GB	   = "";
	private String SS_MIWHAKIN_CD	   = "";
	private String SS_POLI_NO		   = "";
	private String HS_GYEYAK_JIJUM	   = "";
	private String HS_YUNGUP_JIJUM	   = "";
	private String SS_MI_HPNO		   = "";
	private String SS_NAPIP_YMD		   = "";
	private String SS_B_MEMO		   = "";
	private String SS_B_IMAGE		   = "";
	private String SS_B_NOTES		   = "";
	private String SS_B_EMAIL		   = "";
	private String SS_B_RECORD		   = "";
	private String SS_C_MIWHAKIN	   = "";
	private String SS_C_TONGHAP		   = "";
	private String BB_ST_PATH		   = "";
	private String BB_TERM_ID		   = "";
	private String BB_MAP_ID		   = "";
	private String BB_JOGUN		       = "";
	private String BB_JOGUN_NO		   = "";
	private String BB_SAGO_YMDHM	   = "";
	private String BB_SAGO_JUBSU_NO	   = "";
	private String BB_SAGO_JUBSU_SEQ   = "";
	private String BB_LAST_JUBSU_SEQ   = "";
	private String BB_IN_CNT		   = "";
	private String BB_JAEMUL_CNT	   = "";
	private String BB_DEIN_CNT		   = "";
	private String BB_DAEMUL_CNT	   = "";
	private String BB_CHURI_GB		   = "";
	private String BB_MOKJUK_YN		   = "";
	private String BB_GYEYAK_YN		   = "";
	private String BB_TONGHAP_YN	   = "";
	private String BB_PROTECT_YN	   = "";
	private String BB_YOUNGUP_YN	   = "";
	private String BB_5002_YN		   = "";
	private String BB_5003_YN		   = "";
	private String BB_GF_GB		       = "";
	private String BB_DAMDANGJA		   = "";
	private String BB_TASA_GB		   = "";
	private String BB_SANGDAM_NO	   = "";
	private String BB_SANGDAM_GB	   = "";

	private String SS_NCSI_ZIP         = "";
	private String SS_SUN_JUBSU        = "";
	private String SS_TONGBOJA_SMS_YN  = "";
	private String SS_PA_SMS_YN        = "";
	private String SS_GUSANG_CD        = "";
	private String SS_JOGI_SAGO        = "";
	private String SS_KYOCHA_GB        = "";
	private String SS_YUNGUP_CHONG     = "";
	private String SS_SAJUN_SIM        = "";
	private String SS_WIJANG_YN        = "";
	private String SS_GYEYAK_YN        = "";
	private String SS_MORAL_YN         = "";
	private String SS_SAGO_CNT         = "";
	private String SS_TASA_CNT         = "";
	private String HS_JOGI_YN          = "";
	private String HS_SAJUN_YN         = "";
	private String SS_HWASANG_YN       = "";
	private String SS_GOLJUL_YN        = "";
	private String SS_SOAK_YN          = "";
	private String SS_GIJIGP_BANK_CD   = "";
	private String SS_GIJIGP_GYEJWA_NO = "";
	private String SS_JADONG_BANK_CD   = "";
	private String SS_JADONG_GYEJWA_NO = "";
	private String SS_SOAK_FAST        = "";	
	
	// 특정장소 추가 , sjh 20110811    
	private String SS_SAGO_JANGSO_SP   = "";
	private String SS_SAGO_JUNGBO      = "";
                                       
	/* 새주소 관련 추가 2011.09.16 */  
	private String SS_SAGO_ZIP_GB      = "";
	private String SS_N_SAGO_ZIP	   = "";
	private String HS_N_SAGO_ZIP	   = "";
	private String HS_N_SAGO_JANGSO    = "";
	                                   
	private String SS_GYEJWA_YN	       = "";
	private String SS_BANK_CD	       = "";
	private String SS_GYEJWA_NO	       = "";
	
	private String pdc_nm			   = "";
	private String plhd_nm			   = "";
	private String askg_typ			   = "";
	private String accd_oj_dvcd		   = "";
	private String accd_oj_rnk		   = "";
	
	public String getrURL() {
		return rURL;
	}
	public void setrURL(String rURL) {
		this.rURL = rURL;
	}
	public String getCC_CHANNEL() {
		return CC_CHANNEL;
	}
	public void setCC_CHANNEL(String cC_CHANNEL) {
		CC_CHANNEL = cC_CHANNEL;
	}
	public String getCC_UKEY() {
		return CC_UKEY;
	}
	public void setCC_UKEY(String cC_UKEY) {
		CC_UKEY = cC_UKEY;
	}
	public String getCC_PGMID() {
		return CC_PGMID;
	}
	public void setCC_PGMID(String cC_PGMID) {
		CC_PGMID = cC_PGMID;
	}
	public String getCC_PROC_GB() {
		return CC_PROC_GB;
	}
	public void setCC_PROC_GB(String cC_PROC_GB) {
		CC_PROC_GB = cC_PROC_GB;
	}
	public String getCC_FUN_KEY() {
		return CC_FUN_KEY;
	}
	public void setCC_FUN_KEY(String cC_FUN_KEY) {
		CC_FUN_KEY = cC_FUN_KEY;
	}
	public String getCC_USER_GB() {
		return CC_USER_GB;
	}
	public void setCC_USER_GB(String cC_USER_GB) {
		CC_USER_GB = cC_USER_GB;
	}
	public String getCC_USER_CD() {
		return CC_USER_CD;
	}
	public void setCC_USER_CD(String cC_USER_CD) {
		CC_USER_CD = cC_USER_CD;
	}
	public String getCC_JIJUM_CD() {
		return CC_JIJUM_CD;
	}
	public void setCC_JIJUM_CD(String cC_JIJUM_CD) {
		CC_JIJUM_CD = cC_JIJUM_CD;
	}
	public String getCC_JIBU_CD() {
		return CC_JIBU_CD;
	}
	public void setCC_JIBU_CD(String cC_JIBU_CD) {
		CC_JIBU_CD = cC_JIBU_CD;
	}
	public String getCC_PROTOCOL() {
		return CC_PROTOCOL;
	}
	public void setCC_PROTOCOL(String cC_PROTOCOL) {
		CC_PROTOCOL = cC_PROTOCOL;
	}
	public String getCC_COND_CD() {
		return CC_COND_CD;
	}
	public void setCC_COND_CD(String cC_COND_CD) {
		CC_COND_CD = cC_COND_CD;
	}
	public String getCC_LAST_FLAG() {
		return CC_LAST_FLAG;
	}
	public void setCC_LAST_FLAG(String cC_LAST_FLAG) {
		CC_LAST_FLAG = cC_LAST_FLAG;
	}
	public String getCC_CURSOR_MAP() {
		return CC_CURSOR_MAP;
	}
	public void setCC_CURSOR_MAP(String cC_CURSOR_MAP) {
		CC_CURSOR_MAP = cC_CURSOR_MAP;
	}
	public String getCC_CURSOR_IDX() {
		return CC_CURSOR_IDX;
	}
	public void setCC_CURSOR_IDX(String cC_CURSOR_IDX) {
		CC_CURSOR_IDX = cC_CURSOR_IDX;
	}
	public String getCC_MESSAGE_CD() {
		return CC_MESSAGE_CD;
	}
	public void setCC_MESSAGE_CD(String cC_MESSAGE_CD) {
		CC_MESSAGE_CD = cC_MESSAGE_CD;
	}
	public String getHC_MESSAGE_NM() {
		return HC_MESSAGE_NM;
	}
	public void setHC_MESSAGE_NM(String hC_MESSAGE_NM) {
		HC_MESSAGE_NM = hC_MESSAGE_NM;
	}
	public String getCC_SYS_ERR() {
		return CC_SYS_ERR;
	}
	public void setCC_SYS_ERR(String cC_SYS_ERR) {
		CC_SYS_ERR = cC_SYS_ERR;
	}
	public String getCC_FILLER() {
		return CC_FILLER;
	}
	public void setCC_FILLER(String cC_FILLER) {
		CC_FILLER = cC_FILLER;
	}
	public String getSS_JOGUN() {
		return SS_JOGUN;
	}
	public void setSS_JOGUN(String sS_JOGUN) {
		SS_JOGUN = sS_JOGUN;
	}
	public String getSS_JOGUN_NO() {
		return SS_JOGUN_NO;
	}
	public void setSS_JOGUN_NO(String sS_JOGUN_NO) {
		SS_JOGUN_NO = sS_JOGUN_NO;
	}
	public String getSS_SAGO_YMD() {
		return SS_SAGO_YMD;
	}
	public void setSS_SAGO_YMD(String sS_SAGO_YMD) {
		SS_SAGO_YMD = sS_SAGO_YMD;
	}
	public String getSS_SAGO_HM() {
		return SS_SAGO_HM;
	}
	public void setSS_SAGO_HM(String sS_SAGO_HM) {
		SS_SAGO_HM = sS_SAGO_HM;
	}
	public String getSS_SINGU_GB() {
		return SS_SINGU_GB;
	}
	public void setSS_SINGU_GB(String sS_SINGU_GB) {
		SS_SINGU_GB = sS_SINGU_GB;
	}
	public String getSS_ILJANGJA_GB() {
		return SS_ILJANGJA_GB;
	}
	public void setSS_ILJANGJA_GB(String sS_ILJANGJA_GB) {
		SS_ILJANGJA_GB = sS_ILJANGJA_GB;
	}
	public String getSS_SAGO_JUBSU_NO() {
		return SS_SAGO_JUBSU_NO;
	}
	public void setSS_SAGO_JUBSU_NO(String sS_SAGO_JUBSU_NO) {
		SS_SAGO_JUBSU_NO = sS_SAGO_JUBSU_NO;
	}
	public String getSS_SAGO_JUBSU_SEQ() {
		return SS_SAGO_JUBSU_SEQ;
	}
	public void setSS_SAGO_JUBSU_SEQ(String sS_SAGO_JUBSU_SEQ) {
		SS_SAGO_JUBSU_SEQ = sS_SAGO_JUBSU_SEQ;
	}
	public String getSS_IPRYUK_YMD() {
		return SS_IPRYUK_YMD;
	}
	public void setSS_IPRYUK_YMD(String sS_IPRYUK_YMD) {
		SS_IPRYUK_YMD = sS_IPRYUK_YMD;
	}
	public String getSS_IPRYUK_HM() {
		return SS_IPRYUK_HM;
	}
	public void setSS_IPRYUK_HM(String sS_IPRYUK_HM) {
		SS_IPRYUK_HM = sS_IPRYUK_HM;
	}
	public String getSS_GOGEK_GB() {
		return SS_GOGEK_GB;
	}
	public void setSS_GOGEK_GB(String sS_GOGEK_GB) {
		SS_GOGEK_GB = sS_GOGEK_GB;
	}
	public String getSS_GOGEK_GEINBUPIN() {
		return SS_GOGEK_GEINBUPIN;
	}
	public void setSS_GOGEK_GEINBUPIN(String sS_GOGEK_GEINBUPIN) {
		SS_GOGEK_GEINBUPIN = sS_GOGEK_GEINBUPIN;
	}
	public String getSS_GOGEK_NO() {
		return SS_GOGEK_NO;
	}
	public void setSS_GOGEK_NO(String sS_GOGEK_NO) {
		SS_GOGEK_NO = sS_GOGEK_NO;
	}
	public String getHS_GOGEK_NM() {
		return HS_GOGEK_NM;
	}
	public void setHS_GOGEK_NM(String hS_GOGEK_NM) {
		HS_GOGEK_NM = hS_GOGEK_NM;
	}
	public String getSS_GOGEK_AGE() {
		return SS_GOGEK_AGE;
	}
	public void setSS_GOGEK_AGE(String sS_GOGEK_AGE) {
		SS_GOGEK_AGE = sS_GOGEK_AGE;
	}
	public String getSS_GOGEK_JOB_CD() {
		return SS_GOGEK_JOB_CD;
	}
	public void setSS_GOGEK_JOB_CD(String sS_GOGEK_JOB_CD) {
		SS_GOGEK_JOB_CD = sS_GOGEK_JOB_CD;
	}
	public String getHS_GOGEK_JOB_NM() {
		return HS_GOGEK_JOB_NM;
	}
	public void setHS_GOGEK_JOB_NM(String hS_GOGEK_JOB_NM) {
		HS_GOGEK_JOB_NM = hS_GOGEK_JOB_NM;
	}
	public String getSS_GOGEK_TEL() {
		return SS_GOGEK_TEL;
	}
	public void setSS_GOGEK_TEL(String sS_GOGEK_TEL) {
		SS_GOGEK_TEL = sS_GOGEK_TEL;
	}
	public String getSS_JUBSU_UPMU1() {
		return SS_JUBSU_UPMU1;
	}
	public void setSS_JUBSU_UPMU1(String sS_JUBSU_UPMU1) {
		SS_JUBSU_UPMU1 = sS_JUBSU_UPMU1;
	}
	public String getSS_JUBSU_UPMU2() {
		return SS_JUBSU_UPMU2;
	}
	public void setSS_JUBSU_UPMU2(String sS_JUBSU_UPMU2) {
		SS_JUBSU_UPMU2 = sS_JUBSU_UPMU2;
	}
	public String getSS_JUBSU_UPMU3() {
		return SS_JUBSU_UPMU3;
	}
	public void setSS_JUBSU_UPMU3(String sS_JUBSU_UPMU3) {
		SS_JUBSU_UPMU3 = sS_JUBSU_UPMU3;
	}
	public String getHS_TONGBOJA_NM() {
		return HS_TONGBOJA_NM;
	}
	public void setHS_TONGBOJA_NM(String hS_TONGBOJA_NM) {
		HS_TONGBOJA_NM = hS_TONGBOJA_NM;
	}
	public String getSS_TONGBOJA_GWANGYE() {
		return SS_TONGBOJA_GWANGYE;
	}
	public void setSS_TONGBOJA_GWANGYE(String sS_TONGBOJA_GWANGYE) {
		SS_TONGBOJA_GWANGYE = sS_TONGBOJA_GWANGYE;
	}
	public String getSS_TONGBOJA_TEL() {
		return SS_TONGBOJA_TEL;
	}
	public void setSS_TONGBOJA_TEL(String sS_TONGBOJA_TEL) {
		SS_TONGBOJA_TEL = sS_TONGBOJA_TEL;
	}
	public String getSS_JUBSU_CHANNEL() {
		return SS_JUBSU_CHANNEL;
	}
	public void setSS_JUBSU_CHANNEL(String sS_JUBSU_CHANNEL) {
		SS_JUBSU_CHANNEL = sS_JUBSU_CHANNEL;
	}
	public String getSS_INMUL() {
		return SS_INMUL;
	}
	public void setSS_INMUL(String sS_INMUL) {
		SS_INMUL = sS_INMUL;
	}
	public String getHS_INMUL() {
		return HS_INMUL;
	}
	public void setHS_INMUL(String hS_INMUL) {
		HS_INMUL = hS_INMUL;
	}
	public String getHS_ANNE_CD2() {
		return HS_ANNE_CD2;
	}
	public void setHS_ANNE_CD2(String hS_ANNE_CD2) {
		HS_ANNE_CD2 = hS_ANNE_CD2;
	}
	public String getSS_TYPE_CD() {
		return SS_TYPE_CD;
	}
	public void setSS_TYPE_CD(String sS_TYPE_CD) {
		SS_TYPE_CD = sS_TYPE_CD;
	}
	public String getSS_WONIN_CD() {
		return SS_WONIN_CD;
	}
	public void setSS_WONIN_CD(String sS_WONIN_CD) {
		SS_WONIN_CD = sS_WONIN_CD;
	}
	public String getSS_UNHENG_CD1() {
		return SS_UNHENG_CD1;
	}
	public void setSS_UNHENG_CD1(String sS_UNHENG_CD1) {
		SS_UNHENG_CD1 = sS_UNHENG_CD1;
	}
	public String getSS_UNHENG_CD2() {
		return SS_UNHENG_CD2;
	}
	public void setSS_UNHENG_CD2(String sS_UNHENG_CD2) {
		SS_UNHENG_CD2 = sS_UNHENG_CD2;
	}
	public String getSS_SAGO_JANGSO_GB() {
		return SS_SAGO_JANGSO_GB;
	}
	public void setSS_SAGO_JANGSO_GB(String sS_SAGO_JANGSO_GB) {
		SS_SAGO_JANGSO_GB = sS_SAGO_JANGSO_GB;
	}
	public String getSS_SAGO_ZIP() {
		return SS_SAGO_ZIP;
	}
	public void setSS_SAGO_ZIP(String sS_SAGO_ZIP) {
		SS_SAGO_ZIP = sS_SAGO_ZIP;
	}
	public String getHS_SAGO_ZIP() {
		return HS_SAGO_ZIP;
	}
	public void setHS_SAGO_ZIP(String hS_SAGO_ZIP) {
		HS_SAGO_ZIP = hS_SAGO_ZIP;
	}
	public String getHS_SAGO_JANGSO() {
		return HS_SAGO_JANGSO;
	}
	public void setHS_SAGO_JANGSO(String hS_SAGO_JANGSO) {
		HS_SAGO_JANGSO = hS_SAGO_JANGSO;
	}
	public String getHS_SAGO_NEYONG() {
		return HS_SAGO_NEYONG;
	}
	public void setHS_SAGO_NEYONG(String hS_SAGO_NEYONG) {
		HS_SAGO_NEYONG = hS_SAGO_NEYONG;
	}
	public String getHS_TUKGI_SAHANG() {
		return HS_TUKGI_SAHANG;
	}
	public void setHS_TUKGI_SAHANG(String hS_TUKGI_SAHANG) {
		HS_TUKGI_SAHANG = hS_TUKGI_SAHANG;
	}
	public String getSS_CHURI_CD() {
		return SS_CHURI_CD;
	}
	public void setSS_CHURI_CD(String sS_CHURI_CD) {
		SS_CHURI_CD = sS_CHURI_CD;
	}
	public String getSS_CHURI_OFFICE() {
		return SS_CHURI_OFFICE;
	}
	public void setSS_CHURI_OFFICE(String sS_CHURI_OFFICE) {
		SS_CHURI_OFFICE = sS_CHURI_OFFICE;
	}
	public String getSS_SINGO_CD() {
		return SS_SINGO_CD;
	}
	public void setSS_SINGO_CD(String sS_SINGO_CD) {
		SS_SINGO_CD = sS_SINGO_CD;
	}
	public String getHS_SINGO_NM() {
		return HS_SINGO_NM;
	}
	public void setHS_SINGO_NM(String hS_SINGO_NM) {
		HS_SINGO_NM = hS_SINGO_NM;
	}
	public String getSS_SERYU_CD() {
		return SS_SERYU_CD;
	}
	public void setSS_SERYU_CD(String sS_SERYU_CD) {
		SS_SERYU_CD = sS_SERYU_CD;
	}
	public String getSS_SERYU_GB() {
		return SS_SERYU_GB;
	}
	public void setSS_SERYU_GB(String sS_SERYU_GB) {
		SS_SERYU_GB = sS_SERYU_GB;
	}
	public String getSS_SERYU_YMD() {
		return SS_SERYU_YMD;
	}
	public void setSS_SERYU_YMD(String sS_SERYU_YMD) {
		SS_SERYU_YMD = sS_SERYU_YMD;
	}
	public String getSS_PIBO_EMAIL() {
		return SS_PIBO_EMAIL;
	}
	public void setSS_PIBO_EMAIL(String sS_PIBO_EMAIL) {
		SS_PIBO_EMAIL = sS_PIBO_EMAIL;
	}
	public String getSS_WALRYO_YN() {
		return SS_WALRYO_YN;
	}
	public void setSS_WALRYO_YN(String sS_WALRYO_YN) {
		SS_WALRYO_YN = sS_WALRYO_YN;
	}
	public String getSS_SANGDAM_CNT() {
		return SS_SANGDAM_CNT;
	}
	public void setSS_SANGDAM_CNT(String sS_SANGDAM_CNT) {
		SS_SANGDAM_CNT = sS_SANGDAM_CNT;
	}
	public String getSS_JUBSU_CENTER() {
		return SS_JUBSU_CENTER;
	}
	public void setSS_JUBSU_CENTER(String sS_JUBSU_CENTER) {
		SS_JUBSU_CENTER = sS_JUBSU_CENTER;
	}
	public String getSS_JUBSU_TEAM() {
		return SS_JUBSU_TEAM;
	}
	public void setSS_JUBSU_TEAM(String sS_JUBSU_TEAM) {
		SS_JUBSU_TEAM = sS_JUBSU_TEAM;
	}
	public String getSS_JUBSU_JIJUM() {
		return SS_JUBSU_JIJUM;
	}
	public void setSS_JUBSU_JIJUM(String sS_JUBSU_JIJUM) {
		SS_JUBSU_JIJUM = sS_JUBSU_JIJUM;
	}
	public String getSS_JUBSUJA() {
		return SS_JUBSUJA;
	}
	public void setSS_JUBSUJA(String sS_JUBSUJA) {
		SS_JUBSUJA = sS_JUBSUJA;
	}
	public String getHS_JUBSUJA_NM() {
		return HS_JUBSUJA_NM;
	}
	public void setHS_JUBSUJA_NM(String hS_JUBSUJA_NM) {
		HS_JUBSUJA_NM = hS_JUBSUJA_NM;
	}
	public String getSS_JUBSU_YMD() {
		return SS_JUBSU_YMD;
	}
	public void setSS_JUBSU_YMD(String sS_JUBSU_YMD) {
		SS_JUBSU_YMD = sS_JUBSU_YMD;
	}
	public String getSS_JUBSU_HM() {
		return SS_JUBSU_HM;
	}
	public void setSS_JUBSU_HM(String sS_JUBSU_HM) {
		SS_JUBSU_HM = sS_JUBSU_HM;
	}
	public String getSS_GUANSIM_CD() {
		return SS_GUANSIM_CD;
	}
	public void setSS_GUANSIM_CD(String sS_GUANSIM_CD) {
		SS_GUANSIM_CD = sS_GUANSIM_CD;
	}
	public String getSS_EMERGENCY_GB() {
		return SS_EMERGENCY_GB;
	}
	public void setSS_EMERGENCY_GB(String sS_EMERGENCY_GB) {
		SS_EMERGENCY_GB = sS_EMERGENCY_GB;
	}
	public String getSS_MIWHAKIN_CD() {
		return SS_MIWHAKIN_CD;
	}
	public void setSS_MIWHAKIN_CD(String sS_MIWHAKIN_CD) {
		SS_MIWHAKIN_CD = sS_MIWHAKIN_CD;
	}
	public String getSS_POLI_NO() {
		return SS_POLI_NO;
	}
	public void setSS_POLI_NO(String sS_POLI_NO) {
		SS_POLI_NO = sS_POLI_NO;
	}
	public String getHS_GYEYAK_JIJUM() {
		return HS_GYEYAK_JIJUM;
	}
	public void setHS_GYEYAK_JIJUM(String hS_GYEYAK_JIJUM) {
		HS_GYEYAK_JIJUM = hS_GYEYAK_JIJUM;
	}
	public String getHS_YUNGUP_JIJUM() {
		return HS_YUNGUP_JIJUM;
	}
	public void setHS_YUNGUP_JIJUM(String hS_YUNGUP_JIJUM) {
		HS_YUNGUP_JIJUM = hS_YUNGUP_JIJUM;
	}
	public String getSS_MI_HPNO() {
		return SS_MI_HPNO;
	}
	public void setSS_MI_HPNO(String sS_MI_HPNO) {
		SS_MI_HPNO = sS_MI_HPNO;
	}
	public String getSS_NAPIP_YMD() {
		return SS_NAPIP_YMD;
	}
	public void setSS_NAPIP_YMD(String sS_NAPIP_YMD) {
		SS_NAPIP_YMD = sS_NAPIP_YMD;
	}
	public String getSS_B_MEMO() {
		return SS_B_MEMO;
	}
	public void setSS_B_MEMO(String sS_B_MEMO) {
		SS_B_MEMO = sS_B_MEMO;
	}
	public String getSS_B_IMAGE() {
		return SS_B_IMAGE;
	}
	public void setSS_B_IMAGE(String sS_B_IMAGE) {
		SS_B_IMAGE = sS_B_IMAGE;
	}
	public String getSS_B_NOTES() {
		return SS_B_NOTES;
	}
	public void setSS_B_NOTES(String sS_B_NOTES) {
		SS_B_NOTES = sS_B_NOTES;
	}
	public String getSS_B_EMAIL() {
		return SS_B_EMAIL;
	}
	public void setSS_B_EMAIL(String sS_B_EMAIL) {
		SS_B_EMAIL = sS_B_EMAIL;
	}
	public String getSS_B_RECORD() {
		return SS_B_RECORD;
	}
	public void setSS_B_RECORD(String sS_B_RECORD) {
		SS_B_RECORD = sS_B_RECORD;
	}
	public String getSS_C_MIWHAKIN() {
		return SS_C_MIWHAKIN;
	}
	public void setSS_C_MIWHAKIN(String sS_C_MIWHAKIN) {
		SS_C_MIWHAKIN = sS_C_MIWHAKIN;
	}
	public String getSS_C_TONGHAP() {
		return SS_C_TONGHAP;
	}
	public void setSS_C_TONGHAP(String sS_C_TONGHAP) {
		SS_C_TONGHAP = sS_C_TONGHAP;
	}
	public String getBB_ST_PATH() {
		return BB_ST_PATH;
	}
	public void setBB_ST_PATH(String bB_ST_PATH) {
		BB_ST_PATH = bB_ST_PATH;
	}
	public String getBB_TERM_ID() {
		return BB_TERM_ID;
	}
	public void setBB_TERM_ID(String bB_TERM_ID) {
		BB_TERM_ID = bB_TERM_ID;
	}
	public String getBB_MAP_ID() {
		return BB_MAP_ID;
	}
	public void setBB_MAP_ID(String bB_MAP_ID) {
		BB_MAP_ID = bB_MAP_ID;
	}
	public String getBB_JOGUN() {
		return BB_JOGUN;
	}
	public void setBB_JOGUN(String bB_JOGUN) {
		BB_JOGUN = bB_JOGUN;
	}
	public String getBB_JOGUN_NO() {
		return BB_JOGUN_NO;
	}
	public void setBB_JOGUN_NO(String bB_JOGUN_NO) {
		BB_JOGUN_NO = bB_JOGUN_NO;
	}
	public String getBB_SAGO_YMDHM() {
		return BB_SAGO_YMDHM;
	}
	public void setBB_SAGO_YMDHM(String bB_SAGO_YMDHM) {
		BB_SAGO_YMDHM = bB_SAGO_YMDHM;
	}
	public String getBB_SAGO_JUBSU_NO() {
		return BB_SAGO_JUBSU_NO;
	}
	public void setBB_SAGO_JUBSU_NO(String bB_SAGO_JUBSU_NO) {
		BB_SAGO_JUBSU_NO = bB_SAGO_JUBSU_NO;
	}
	public String getBB_SAGO_JUBSU_SEQ() {
		return BB_SAGO_JUBSU_SEQ;
	}
	public void setBB_SAGO_JUBSU_SEQ(String bB_SAGO_JUBSU_SEQ) {
		BB_SAGO_JUBSU_SEQ = bB_SAGO_JUBSU_SEQ;
	}
	public String getBB_LAST_JUBSU_SEQ() {
		return BB_LAST_JUBSU_SEQ;
	}
	public void setBB_LAST_JUBSU_SEQ(String bB_LAST_JUBSU_SEQ) {
		BB_LAST_JUBSU_SEQ = bB_LAST_JUBSU_SEQ;
	}
	public String getBB_IN_CNT() {
		return BB_IN_CNT;
	}
	public void setBB_IN_CNT(String bB_IN_CNT) {
		BB_IN_CNT = bB_IN_CNT;
	}
	public String getBB_JAEMUL_CNT() {
		return BB_JAEMUL_CNT;
	}
	public void setBB_JAEMUL_CNT(String bB_JAEMUL_CNT) {
		BB_JAEMUL_CNT = bB_JAEMUL_CNT;
	}
	public String getBB_DEIN_CNT() {
		return BB_DEIN_CNT;
	}
	public void setBB_DEIN_CNT(String bB_DEIN_CNT) {
		BB_DEIN_CNT = bB_DEIN_CNT;
	}
	public String getBB_DAEMUL_CNT() {
		return BB_DAEMUL_CNT;
	}
	public void setBB_DAEMUL_CNT(String bB_DAEMUL_CNT) {
		BB_DAEMUL_CNT = bB_DAEMUL_CNT;
	}
	public String getBB_CHURI_GB() {
		return BB_CHURI_GB;
	}
	public void setBB_CHURI_GB(String bB_CHURI_GB) {
		BB_CHURI_GB = bB_CHURI_GB;
	}
	public String getBB_MOKJUK_YN() {
		return BB_MOKJUK_YN;
	}
	public void setBB_MOKJUK_YN(String bB_MOKJUK_YN) {
		BB_MOKJUK_YN = bB_MOKJUK_YN;
	}
	public String getBB_GYEYAK_YN() {
		return BB_GYEYAK_YN;
	}
	public void setBB_GYEYAK_YN(String bB_GYEYAK_YN) {
		BB_GYEYAK_YN = bB_GYEYAK_YN;
	}
	public String getBB_TONGHAP_YN() {
		return BB_TONGHAP_YN;
	}
	public void setBB_TONGHAP_YN(String bB_TONGHAP_YN) {
		BB_TONGHAP_YN = bB_TONGHAP_YN;
	}
	public String getBB_PROTECT_YN() {
		return BB_PROTECT_YN;
	}
	public void setBB_PROTECT_YN(String bB_PROTECT_YN) {
		BB_PROTECT_YN = bB_PROTECT_YN;
	}
	public String getBB_YOUNGUP_YN() {
		return BB_YOUNGUP_YN;
	}
	public void setBB_YOUNGUP_YN(String bB_YOUNGUP_YN) {
		BB_YOUNGUP_YN = bB_YOUNGUP_YN;
	}
	public String getBB_5002_YN() {
		return BB_5002_YN;
	}
	public void setBB_5002_YN(String bB_5002_YN) {
		BB_5002_YN = bB_5002_YN;
	}
	public String getBB_5003_YN() {
		return BB_5003_YN;
	}
	public void setBB_5003_YN(String bB_5003_YN) {
		BB_5003_YN = bB_5003_YN;
	}
	public String getBB_GF_GB() {
		return BB_GF_GB;
	}
	public void setBB_GF_GB(String bB_GF_GB) {
		BB_GF_GB = bB_GF_GB;
	}
	public String getBB_DAMDANGJA() {
		return BB_DAMDANGJA;
	}
	public void setBB_DAMDANGJA(String bB_DAMDANGJA) {
		BB_DAMDANGJA = bB_DAMDANGJA;
	}
	public String getBB_TASA_GB() {
		return BB_TASA_GB;
	}
	public void setBB_TASA_GB(String bB_TASA_GB) {
		BB_TASA_GB = bB_TASA_GB;
	}
	public String getBB_SANGDAM_NO() {
		return BB_SANGDAM_NO;
	}
	public void setBB_SANGDAM_NO(String bB_SANGDAM_NO) {
		BB_SANGDAM_NO = bB_SANGDAM_NO;
	}
	public String getBB_SANGDAM_GB() {
		return BB_SANGDAM_GB;
	}
	public void setBB_SANGDAM_GB(String bB_SANGDAM_GB) {
		BB_SANGDAM_GB = bB_SANGDAM_GB;
	}
	public String getSS_NCSI_ZIP() {
		return SS_NCSI_ZIP;
	}
	public void setSS_NCSI_ZIP(String sS_NCSI_ZIP) {
		SS_NCSI_ZIP = sS_NCSI_ZIP;
	}
	public String getSS_SUN_JUBSU() {
		return SS_SUN_JUBSU;
	}
	public void setSS_SUN_JUBSU(String sS_SUN_JUBSU) {
		SS_SUN_JUBSU = sS_SUN_JUBSU;
	}
	public String getSS_TONGBOJA_SMS_YN() {
		return SS_TONGBOJA_SMS_YN;
	}
	public void setSS_TONGBOJA_SMS_YN(String sS_TONGBOJA_SMS_YN) {
		SS_TONGBOJA_SMS_YN = sS_TONGBOJA_SMS_YN;
	}
	public String getSS_PA_SMS_YN() {
		return SS_PA_SMS_YN;
	}
	public void setSS_PA_SMS_YN(String sS_PA_SMS_YN) {
		SS_PA_SMS_YN = sS_PA_SMS_YN;
	}
	public String getSS_GUSANG_CD() {
		return SS_GUSANG_CD;
	}
	public void setSS_GUSANG_CD(String sS_GUSANG_CD) {
		SS_GUSANG_CD = sS_GUSANG_CD;
	}
	public String getSS_JOGI_SAGO() {
		return SS_JOGI_SAGO;
	}
	public void setSS_JOGI_SAGO(String sS_JOGI_SAGO) {
		SS_JOGI_SAGO = sS_JOGI_SAGO;
	}
	public String getSS_KYOCHA_GB() {
		return SS_KYOCHA_GB;
	}
	public void setSS_KYOCHA_GB(String sS_KYOCHA_GB) {
		SS_KYOCHA_GB = sS_KYOCHA_GB;
	}
	public String getSS_YUNGUP_CHONG() {
		return SS_YUNGUP_CHONG;
	}
	public void setSS_YUNGUP_CHONG(String sS_YUNGUP_CHONG) {
		SS_YUNGUP_CHONG = sS_YUNGUP_CHONG;
	}
	public String getSS_SAJUN_SIM() {
		return SS_SAJUN_SIM;
	}
	public void setSS_SAJUN_SIM(String sS_SAJUN_SIM) {
		SS_SAJUN_SIM = sS_SAJUN_SIM;
	}
	public String getSS_WIJANG_YN() {
		return SS_WIJANG_YN;
	}
	public void setSS_WIJANG_YN(String sS_WIJANG_YN) {
		SS_WIJANG_YN = sS_WIJANG_YN;
	}
	public String getSS_GYEYAK_YN() {
		return SS_GYEYAK_YN;
	}
	public void setSS_GYEYAK_YN(String sS_GYEYAK_YN) {
		SS_GYEYAK_YN = sS_GYEYAK_YN;
	}
	public String getSS_MORAL_YN() {
		return SS_MORAL_YN;
	}
	public void setSS_MORAL_YN(String sS_MORAL_YN) {
		SS_MORAL_YN = sS_MORAL_YN;
	}
	public String getSS_SAGO_CNT() {
		return SS_SAGO_CNT;
	}
	public void setSS_SAGO_CNT(String sS_SAGO_CNT) {
		SS_SAGO_CNT = sS_SAGO_CNT;
	}
	public String getSS_TASA_CNT() {
		return SS_TASA_CNT;
	}
	public void setSS_TASA_CNT(String sS_TASA_CNT) {
		SS_TASA_CNT = sS_TASA_CNT;
	}
	public String getHS_JOGI_YN() {
		return HS_JOGI_YN;
	}
	public void setHS_JOGI_YN(String hS_JOGI_YN) {
		HS_JOGI_YN = hS_JOGI_YN;
	}
	public String getHS_SAJUN_YN() {
		return HS_SAJUN_YN;
	}
	public void setHS_SAJUN_YN(String hS_SAJUN_YN) {
		HS_SAJUN_YN = hS_SAJUN_YN;
	}
	public String getSS_HWASANG_YN() {
		return SS_HWASANG_YN;
	}
	public void setSS_HWASANG_YN(String sS_HWASANG_YN) {
		SS_HWASANG_YN = sS_HWASANG_YN;
	}
	public String getSS_GOLJUL_YN() {
		return SS_GOLJUL_YN;
	}
	public void setSS_GOLJUL_YN(String sS_GOLJUL_YN) {
		SS_GOLJUL_YN = sS_GOLJUL_YN;
	}
	public String getSS_SOAK_YN() {
		return SS_SOAK_YN;
	}
	public void setSS_SOAK_YN(String sS_SOAK_YN) {
		SS_SOAK_YN = sS_SOAK_YN;
	}
	public String getSS_GIJIGP_BANK_CD() {
		return SS_GIJIGP_BANK_CD;
	}
	public void setSS_GIJIGP_BANK_CD(String sS_GIJIGP_BANK_CD) {
		SS_GIJIGP_BANK_CD = sS_GIJIGP_BANK_CD;
	}
	public String getSS_GIJIGP_GYEJWA_NO() {
		return SS_GIJIGP_GYEJWA_NO;
	}
	public void setSS_GIJIGP_GYEJWA_NO(String sS_GIJIGP_GYEJWA_NO) {
		SS_GIJIGP_GYEJWA_NO = sS_GIJIGP_GYEJWA_NO;
	}
	public String getSS_JADONG_BANK_CD() {
		return SS_JADONG_BANK_CD;
	}
	public void setSS_JADONG_BANK_CD(String sS_JADONG_BANK_CD) {
		SS_JADONG_BANK_CD = sS_JADONG_BANK_CD;
	}
	public String getSS_JADONG_GYEJWA_NO() {
		return SS_JADONG_GYEJWA_NO;
	}
	public void setSS_JADONG_GYEJWA_NO(String sS_JADONG_GYEJWA_NO) {
		SS_JADONG_GYEJWA_NO = sS_JADONG_GYEJWA_NO;
	}
	public String getSS_SOAK_FAST() {
		return SS_SOAK_FAST;
	}
	public void setSS_SOAK_FAST(String sS_SOAK_FAST) {
		SS_SOAK_FAST = sS_SOAK_FAST;
	}
	public String getSS_SAGO_JANGSO_SP() {
		return SS_SAGO_JANGSO_SP;
	}
	public void setSS_SAGO_JANGSO_SP(String sS_SAGO_JANGSO_SP) {
		SS_SAGO_JANGSO_SP = sS_SAGO_JANGSO_SP;
	}
	public String getSS_SAGO_JUNGBO() {
		return SS_SAGO_JUNGBO;
	}
	public void setSS_SAGO_JUNGBO(String sS_SAGO_JUNGBO) {
		SS_SAGO_JUNGBO = sS_SAGO_JUNGBO;
	}
	public String getSS_SAGO_ZIP_GB() {
		return SS_SAGO_ZIP_GB;
	}
	public void setSS_SAGO_ZIP_GB(String sS_SAGO_ZIP_GB) {
		SS_SAGO_ZIP_GB = sS_SAGO_ZIP_GB;
	}
	public String getSS_N_SAGO_ZIP() {
		return SS_N_SAGO_ZIP;
	}
	public void setSS_N_SAGO_ZIP(String sS_N_SAGO_ZIP) {
		SS_N_SAGO_ZIP = sS_N_SAGO_ZIP;
	}
	public String getHS_N_SAGO_ZIP() {
		return HS_N_SAGO_ZIP;
	}
	public void setHS_N_SAGO_ZIP(String hS_N_SAGO_ZIP) {
		HS_N_SAGO_ZIP = hS_N_SAGO_ZIP;
	}
	public String getHS_N_SAGO_JANGSO() {
		return HS_N_SAGO_JANGSO;
	}
	public void setHS_N_SAGO_JANGSO(String hS_N_SAGO_JANGSO) {
		HS_N_SAGO_JANGSO = hS_N_SAGO_JANGSO;
	}
	public String getSS_GYEJWA_YN() {
		return SS_GYEJWA_YN;
	}
	public void setSS_GYEJWA_YN(String sS_GYEJWA_YN) {
		SS_GYEJWA_YN = sS_GYEJWA_YN;
	}
	public String getSS_BANK_CD() {
		return SS_BANK_CD;
	}
	public void setSS_BANK_CD(String sS_BANK_CD) {
		SS_BANK_CD = sS_BANK_CD;
	}
	public String getSS_GYEJWA_NO() {
		return SS_GYEJWA_NO;
	}
	public void setSS_GYEJWA_NO(String sS_GYEJWA_NO) {
		SS_GYEJWA_NO = sS_GYEJWA_NO;
	}
	public static String getProid() {
		return proid;
	}
	public static String getTrid() {
		return trid;
	}
	
	private String contact1               = "";
	private String contact2               = "";
	private String contact3               = "";
	public String getContact1() {
		return contact1;
	}

	public void setContact1(String contact1) {
		this.contact1 = contact1;
	}

	public String getContact2() {
		return contact2;
	}

	public void setContact2(String contact2) {
		this.contact2 = contact2;
	}

	public String getContact3() {
		return contact3;
	}

	public void setContact3(String contact3) {
		this.contact3 = contact3;
	}
	/**
	 * @return the pdc_nm
	 */
	public String getPdc_nm() {
		return pdc_nm;
	}
	/**
	 * @param pdc_nm the pdc_nm to set
	 */
	public void setPdc_nm(String pdc_nm) {
		this.pdc_nm = pdc_nm;
	}
	/**
	 * @return the plhd_nm
	 */
	public String getPlhd_nm() {
		return plhd_nm;
	}
	/**
	 * @param plhd_nm the plhd_nm to set
	 */
	public void setPlhd_nm(String plhd_nm) {
		this.plhd_nm = plhd_nm;
	}
	/**
	 * @return the askg_typ
	 */
	public String getAskg_typ() {
		return askg_typ;
	}
	/**
	 * @param askg_typ the askg_typ to set
	 */
	public void setAskg_typ(String askg_typ) {
		this.askg_typ = askg_typ;
	}

	/**
	 * @return the accd_oj_dvcd
	 */
	public String getAccd_oj_dvcd() {
		return accd_oj_dvcd;
	}
	/**
	 * @param accd_oj_dvcd the accd_oj_dvcd to set
	 */
	public void setAccd_oj_dvcd(String accd_oj_dvcd) {
		this.accd_oj_dvcd = accd_oj_dvcd;
	}
	/**
	 * @return the accd_oj_rnk
	 */
	public String getAccd_oj_rnk() {
		return accd_oj_rnk;
	}
	/**
	 * @param accd_oj_rnk the accd_oj_rnk to set
	 */
	public void setAccd_oj_rnk(String accd_oj_rnk) {
		this.accd_oj_rnk = accd_oj_rnk;
	}	
	
}
