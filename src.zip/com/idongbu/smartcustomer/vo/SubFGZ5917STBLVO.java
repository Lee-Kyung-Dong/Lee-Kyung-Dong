package com.idongbu.smartcustomer.vo;

public class SubFGZ5917STBLVO {
	public String LK_BUNNAP_NM   = null;
	public String LK_ICHE_DD     = null;
	public String LK_BANK_NM     = null;
	public String LK_GYEJWA_NO   = null;
	public String LK_YEGMJU_NM   = null;
	public String LK_SUGUM_FIL   = null;

	public String getLK_BUNNAP_NM() {
		return LK_BUNNAP_NM;
	}
	public void setLK_BUNNAP_NM(String lK_BUNNAP_NM) {
		LK_BUNNAP_NM = lK_BUNNAP_NM;
	}
	public String getLK_ICHE_DD() {
		return LK_ICHE_DD;
	}
	public void setLK_ICHE_DD(String lK_ICHE_DD) {
		LK_ICHE_DD = lK_ICHE_DD;
	}
	public String getLK_BANK_NM() {
		return LK_BANK_NM;
	}
	public void setLK_BANK_NM(String lK_BANK_NM) {
		LK_BANK_NM = lK_BANK_NM;
	}
	public String getLK_GYEJWA_NO() {
		return LK_GYEJWA_NO;
	}
	public void setLK_GYEJWA_NO(String lK_GYEJWA_NO) {
		LK_GYEJWA_NO = lK_GYEJWA_NO;
	}
	public String getLK_YEGMJU_NM() {
		return LK_YEGMJU_NM;
	}
	public void setLK_YEGMJU_NM(String lK_YEGMJU_NM) {
		LK_YEGMJU_NM = lK_YEGMJU_NM;
	}
	public String getLK_SUGUM_FIL() {
		return LK_SUGUM_FIL;
	}
	public void setLK_SUGUM_FIL(String lK_SUGUM_FIL) {
		LK_SUGUM_FIL = lK_SUGUM_FIL;
	}

}
