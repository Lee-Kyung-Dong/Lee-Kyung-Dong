package com.idongbu.smartcustomer.vo;

public class ExceMemberVO
{
	private String seq			= "";// 시퀀스
	private String req_no     	= "";// 정보처리번호               
	private String code      	= "";// 예외대상고객주민등록번호 시퀀스     
	private String fd_mb_jumin	= "";// 예외대상업무코드             
	private String reg_date   	= "";// 요청일                  
	private String cre_date   	= "";// 등록일                  
	private String upd_date   	= "";// 수정일                  
	private String reg_by     	= "";// 요청자                  
	private String cre_by     	= "";// 생성자                  
	private String upd_by     	= "";// 수정자                  
	private String is_apply   	= "";// 적용여부(Y:적용,N:미적용)     
	private String channel    	= "";// 채널(T:모두,H:홈페이지,M:모바일)
	
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getReq_no() {
		return req_no;
	}
	public void setReq_no(String req_no) {
		this.req_no = req_no;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getFd_mb_jumin() {
		return fd_mb_jumin;
	}
	public void setFd_mb_jumin(String fd_mb_jumin) {
		this.fd_mb_jumin = fd_mb_jumin;
	}
	public String getReg_date() {
		return reg_date;
	}
	public void setReg_date(String reg_date) {
		this.reg_date = reg_date;
	}
	public String getCre_date() {
		return cre_date;
	}
	public void setCre_date(String cre_date) {
		this.cre_date = cre_date;
	}
	public String getUpd_date() {
		return upd_date;
	}
	public void setUpd_date(String upd_date) {
		this.upd_date = upd_date;
	}
	public String getReg_by() {
		return reg_by;
	}
	public void setReg_by(String reg_by) {
		this.reg_by = reg_by;
	}
	public String getCre_by() {
		return cre_by;
	}
	public void setCre_by(String cre_by) {
		this.cre_by = cre_by;
	}
	public String getUpd_by() {
		return upd_by;
	}
	public void setUpd_by(String upd_by) {
		this.upd_by = upd_by;
	}
	public String getIs_apply() {
		return is_apply;
	}
	public void setIs_apply(String is_apply) {
		this.is_apply = is_apply;
	}
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
}

