package com.idongbu.smartcustomer.vo;

import java.util.List;

import com.idongbu.common.vo.CMMVO;

// 수금방법일괄변경신청(계좌변경)
public class CmmFUB2032RVO extends CMMVO {
	
	public CmmFUB2032RVO() {
		super.setPGMID(this.proid);
		super.setTRID(this.trid);
	}	
	
	public static final String proid		= "FUB2032R";
	public static final String trid			= "UB2W";
	public String rURL						= "";
		
	public String CC_JIJUM_CD			  = null;
	public String CC_JIBU_CD			  = null;
	public String CC_CHANNEL			  = null;
	public String CC_PROC_GB			  = null;
	public String CC_FUN_KEY			  = null;
	public String CC_USER_GB			  = null;
	public String CC_USER_CD			  = null;
	public String CC_COND_CD			  = null;
	public String CC_SYS_ERR			  = null;
	public String CC_MESSAGE_CD			  = null;
	public String HC_MESSAGE_NM			  = null;
	public String JJ_GOGEK_NO			  = null;				//고객번호
	public String HJ_GOGEK_NAME           = null;				//고객명
	public String JJ_IPRYUKJA             = null;				//입력자
	public String JJ_PASSWORD             = null;				//비밀번호
	public String []JJ_NO				  = new String[0];	//10     번호
	public String []JJ_POLI_NO            = new String[0];	//10     증권번호 
	public String []HJ_IPCHULGM           = new String[0];	//10     입출금
	public String []JJ_BANK_CODE          = new String[0];	//10     은행코드
	public String []HJ_BANK_NM            = new String[0];	//10     은행명
	public String []JJ_GYEJWA_NO1         = new String[0];	//10     계좌번호
	public String []HJ_YEGMJU             = new String[0];	//10     예금주
	public String []JJ_ICHE_DD            = new String[0];	//10     이체일
	public String []JJ_LAST_YM            = new String[0];	//10     변경전적용년월
	public String []HJ_SANGTE_NM          = new String[0];	//10     상태명
	public String []HJ_DECHUL_NM          = new String[0];	//10      대출명
	public String []HJ_BOJONG_NM		  = new String[0];	//10     보종명
	public String []JJ_BOHUM_GIGAN_SYMD	  = new String[0];	//10     보험기간시작일	
	public String []JJ_BOHUM_GIGAN_EYMD	  = new String[0];	//10     보헙기간종료일	
	public String JJ_SUKUM_BANGCD		  = null;				//수금방법코드
	public String HJ_SUKUM_BANGNM         = null;				//수금방법명
	public String JJ_BANK_CD              = null;				//은행코드
	public String HJ_BANK_NAME            = null;				//은행명
	public String JJ_GYEJWA_NO            = null;				//계좌번호
	public String JJ_ICHE_D               = null;				//이체일
	public String JJ_GWANGYE_CD           = null;				//관계코드
	public String HJ_GWANGYE_NM           = null;				//관계명
	public String HJ_YEGMJU_NM            = null;				//예금주명
	public String JJ_YEGMJU_NO            = null;				//예금주번호
	public String JJ_YEGMJU_TEL           = null;				//예금주전화번호
	public String JJ_JUK_YY               = null;				//
	public String JJ_JUK_MM               = null;				//
	public String HJ_REMARK               = null;				//
	public String UU_UDA_JUMIN_NO         = null;
	public String UU_UDA_POLI_NO          = null;
	public String UU_CURR_POLI_NO         = null;
	public String UU_FIRST_POLI_NO        = null;
	public String UU_LAST_POLI_NO         = null;
	public List<SubFUB2032RVO> LIST_DATA = null;
	public String CC_UKEY = null; // UNIQUE-KEY(UA6G)
	
	public String getrURL() {
		return rURL;
	}
	public void setrURL(String rURL) {
		this.rURL = rURL;
	}
	public String getCC_JIJUM_CD() {
		return CC_JIJUM_CD;
	}
	public void setCC_JIJUM_CD(String cC_JIJUM_CD) {
		CC_JIJUM_CD = cC_JIJUM_CD;
	}
	public String getCC_JIBU_CD() {
		return CC_JIBU_CD;
	}
	public void setCC_JIBU_CD(String cC_JIBU_CD) {
		CC_JIBU_CD = cC_JIBU_CD;
	}
	public String getCC_CHANNEL() {
		return CC_CHANNEL;
	}
	public void setCC_CHANNEL(String cC_CHANNEL) {
		CC_CHANNEL = cC_CHANNEL;
	}
	public String getCC_PROC_GB() {
		return CC_PROC_GB;
	}
	public void setCC_PROC_GB(String cC_PROC_GB) {
		CC_PROC_GB = cC_PROC_GB;
	}
	public String getCC_FUN_KEY() {
		return CC_FUN_KEY;
	}
	public void setCC_FUN_KEY(String cC_FUN_KEY) {
		CC_FUN_KEY = cC_FUN_KEY;
	}
	public String getCC_USER_GB() {
		return CC_USER_GB;
	}
	public void setCC_USER_GB(String cC_USER_GB) {
		CC_USER_GB = cC_USER_GB;
	}
	public String getCC_USER_CD() {
		return CC_USER_CD;
	}
	public void setCC_USER_CD(String cC_USER_CD) {
		CC_USER_CD = cC_USER_CD;
	}
	public String getCC_COND_CD() {
		return CC_COND_CD;
	}
	public void setCC_COND_CD(String cC_COND_CD) {
		CC_COND_CD = cC_COND_CD;
	}
	public String getJJ_GOGEK_NO() {
		return JJ_GOGEK_NO;
	}
	public void setJJ_GOGEK_NO(String jJ_GOGEK_NO) {
		JJ_GOGEK_NO = jJ_GOGEK_NO;
	}
	public String getHJ_GOGEK_NAME() {
		return HJ_GOGEK_NAME;
	}
	public void setHJ_GOGEK_NAME(String hJ_GOGEK_NAME) {
		HJ_GOGEK_NAME = hJ_GOGEK_NAME;
	}
	public String getJJ_IPRYUKJA() {
		return JJ_IPRYUKJA;
	}
	public void setJJ_IPRYUKJA(String jJ_IPRYUKJA) {
		JJ_IPRYUKJA = jJ_IPRYUKJA;
	}
	public String getJJ_PASSWORD() {
		return JJ_PASSWORD;
	}
	public void setJJ_PASSWORD(String jJ_PASSWORD) {
		JJ_PASSWORD = jJ_PASSWORD;
	}
	public String[] getJJ_NO() {
		return JJ_NO;
	}
	public void setJJ_NO(String[] jJ_NO) {
		JJ_NO = jJ_NO;
	}
	public String[] getJJ_POLI_NO() {
		return JJ_POLI_NO;
	}
	public void setJJ_POLI_NO(String[] jJ_POLI_NO) {
		JJ_POLI_NO = jJ_POLI_NO;
	}
	public String[] getHJ_IPCHULGM() {
		return HJ_IPCHULGM;
	}
	public void setHJ_IPCHULGM(String[] hJ_IPCHULGM) {
		HJ_IPCHULGM = hJ_IPCHULGM;
	}
	public String[] getJJ_BANK_CODE() {
		return JJ_BANK_CODE;
	}
	public void setJJ_BANK_CODE(String[] jJ_BANK_CODE) {
		JJ_BANK_CODE = jJ_BANK_CODE;
	}
	public String[] getHJ_BANK_NM() {
		return HJ_BANK_NM;
	}
	public void setHJ_BANK_NM(String[] hJ_BANK_NM) {
		HJ_BANK_NM = hJ_BANK_NM;
	}
	public String[] getJJ_GYEJWA_NO1() {
		return JJ_GYEJWA_NO1;
	}
	public void setJJ_GYEJWA_NO1(String[] jJ_GYEJWA_NO1) {
		JJ_GYEJWA_NO1 = jJ_GYEJWA_NO1;
	}
	public String[] getHJ_YEGMJU() {
		return HJ_YEGMJU;
	}
	public void setHJ_YEGMJU(String[] hJ_YEGMJU) {
		HJ_YEGMJU = hJ_YEGMJU;
	}
	public String[] getJJ_ICHE_DD() {
		return JJ_ICHE_DD;
	}
	public void setJJ_ICHE_DD(String[] jJ_ICHE_DD) {
		JJ_ICHE_DD = jJ_ICHE_DD;
	}
	public String[] getJJ_LAST_YM() {
		return JJ_LAST_YM;
	}
	public void setJJ_LAST_YM(String[] jJ_LAST_YM) {
		JJ_LAST_YM = jJ_LAST_YM;
	}
	public String[] getHJ_SANGTE_NM() {
		return HJ_SANGTE_NM;
	}
	public void setHJ_SANGTE_NM(String[] hJ_SANGTE_NM) {
		HJ_SANGTE_NM = hJ_SANGTE_NM;
	}
	public String[] getHJ_DECHUL_NM() {
		return HJ_DECHUL_NM;
	}
	public void setHJ_DECHUL_NM(String[] hJ_DECHUL_NM) {
		HJ_DECHUL_NM = hJ_DECHUL_NM;
	}
	public String[] getHJ_BOJONG_NM() {
		return HJ_BOJONG_NM;
	}
	public void setHJ_BOJONG_NM(String[] hJ_BOJONG_NM) {
		HJ_BOJONG_NM = hJ_BOJONG_NM;
	}
	public String[] getJJ_BOHUM_GIGAN_SYMD() {
		return JJ_BOHUM_GIGAN_SYMD;
	}
	public void setJJ_BOHUM_GIGAN_SYMD(String[] jJ_BOHUM_GIGAN_SYMD) {
		JJ_BOHUM_GIGAN_SYMD = jJ_BOHUM_GIGAN_SYMD;
	}
	public String[] getJJ_BOHUM_GIGAN_EYMD() {
		return JJ_BOHUM_GIGAN_EYMD;
	}
	public void setJJ_BOHUM_GIGAN_EYMD(String[] jJ_BOHUM_GIGAN_EYMD) {
		JJ_BOHUM_GIGAN_EYMD = jJ_BOHUM_GIGAN_EYMD;
	}
	public String getJJ_SUKUM_BANGCD() {
		return JJ_SUKUM_BANGCD;
	}
	public void setJJ_SUKUM_BANGCD(String jJ_SUKUM_BANGCD) {
		JJ_SUKUM_BANGCD = jJ_SUKUM_BANGCD;
	}
	public String getHJ_SUKUM_BANGNM() {
		return HJ_SUKUM_BANGNM;
	}
	public void setHJ_SUKUM_BANGNM(String hJ_SUKUM_BANGNM) {
		HJ_SUKUM_BANGNM = hJ_SUKUM_BANGNM;
	}
	public String getJJ_BANK_CD() {
		return JJ_BANK_CD;
	}
	public void setJJ_BANK_CD(String jJ_BANK_CD) {
		JJ_BANK_CD = jJ_BANK_CD;
	}
	public String getHJ_BANK_NAME() {
		return HJ_BANK_NAME;
	}
	public void setHJ_BANK_NAME(String hJ_BANK_NAME) {
		HJ_BANK_NAME = hJ_BANK_NAME;
	}
	public String getJJ_GYEJWA_NO() {
		return JJ_GYEJWA_NO;
	}
	public void setJJ_GYEJWA_NO(String jJ_GYEJWA_NO) {
		JJ_GYEJWA_NO = jJ_GYEJWA_NO;
	}
	public String getJJ_ICHE_D() {
		return JJ_ICHE_D;
	}
	public void setJJ_ICHE_D(String jJ_ICHE_D) {
		JJ_ICHE_D = jJ_ICHE_D;
	}
	public String getJJ_GWANGYE_CD() {
		return JJ_GWANGYE_CD;
	}
	public void setJJ_GWANGYE_CD(String jJ_GWANGYE_CD) {
		JJ_GWANGYE_CD = jJ_GWANGYE_CD;
	}
	public String getHJ_GWANGYE_NM() {
		return HJ_GWANGYE_NM;
	}
	public void setHJ_GWANGYE_NM(String hJ_GWANGYE_NM) {
		HJ_GWANGYE_NM = hJ_GWANGYE_NM;
	}
	public String getHJ_YEGMJU_NM() {
		return HJ_YEGMJU_NM;
	}
	public void setHJ_YEGMJU_NM(String hJ_YEGMJU_NM) {
		HJ_YEGMJU_NM = hJ_YEGMJU_NM;
	}
	public String getJJ_YEGMJU_NO() {
		return JJ_YEGMJU_NO;
	}
	public void setJJ_YEGMJU_NO(String jJ_YEGMJU_NO) {
		JJ_YEGMJU_NO = jJ_YEGMJU_NO;
	}
	public String getJJ_YEGMJU_TEL() {
		return JJ_YEGMJU_TEL;
	}
	public void setJJ_YEGMJU_TEL(String jJ_YEGMJU_TEL) {
		JJ_YEGMJU_TEL = jJ_YEGMJU_TEL;
	}
	public String getJJ_JUK_YY() {
		return JJ_JUK_YY;
	}
	public void setJJ_JUK_YY(String jJ_JUK_YY) {
		JJ_JUK_YY = jJ_JUK_YY;
	}
	public String getJJ_JUK_MM() {
		return JJ_JUK_MM;
	}
	public void setJJ_JUK_MM(String jJ_JUK_MM) {
		JJ_JUK_MM = jJ_JUK_MM;
	}
	public String getHJ_REMARK() {
		return HJ_REMARK;
	}
	public void setHJ_REMARK(String hJ_REMARK) {
		HJ_REMARK = hJ_REMARK;
	}
	public String getUU_UDA_JUMIN_NO() {
		return UU_UDA_JUMIN_NO;
	}
	public void setUU_UDA_JUMIN_NO(String uU_UDA_JUMIN_NO) {
		UU_UDA_JUMIN_NO = uU_UDA_JUMIN_NO;
	}
	public String getUU_UDA_POLI_NO() {
		return UU_UDA_POLI_NO;
	}
	public void setUU_UDA_POLI_NO(String uU_UDA_POLI_NO) {
		UU_UDA_POLI_NO = uU_UDA_POLI_NO;
	}
	public String getUU_CURR_POLI_NO() {
		return UU_CURR_POLI_NO;
	}
	public void setUU_CURR_POLI_NO(String uU_CURR_POLI_NO) {
		UU_CURR_POLI_NO = uU_CURR_POLI_NO;
	}
	public String getUU_FIRST_POLI_NO() {
		return UU_FIRST_POLI_NO;
	}
	public void setUU_FIRST_POLI_NO(String uU_FIRST_POLI_NO) {
		UU_FIRST_POLI_NO = uU_FIRST_POLI_NO;
	}
	public String getUU_LAST_POLI_NO() {
		return UU_LAST_POLI_NO;
	}
	public void setUU_LAST_POLI_NO(String uU_LAST_POLI_NO) {
		UU_LAST_POLI_NO = uU_LAST_POLI_NO;
	}
	public static String getProid() {
		return proid;
	}
	public static String getTrid() {
		return trid;
	}
	public List<SubFUB2032RVO> getLIST_DATA() {
		return LIST_DATA;
	}
	public void setLIST_DATA(List<SubFUB2032RVO> lIST_DATA) {
		LIST_DATA = lIST_DATA;
	}
	public String getCC_MESSAGE_CD() {
		return CC_MESSAGE_CD;
	}
	public void setCC_MESSAGE_CD(String cC_MESSAGE_CD) {
		CC_MESSAGE_CD = cC_MESSAGE_CD;
	}
	public String getHC_MESSAGE_NM() {
		return HC_MESSAGE_NM;
	}
	public void setHC_MESSAGE_NM(String hC_MESSAGE_NM) {
		HC_MESSAGE_NM = hC_MESSAGE_NM;
	}
	public String getCC_SYS_ERR() {
		return CC_SYS_ERR;
	}
	public void setCC_SYS_ERR(String cC_SYS_ERR) {
		CC_SYS_ERR = cC_SYS_ERR;
	}
	public String getCC_UKEY() {
		return CC_UKEY;
	}
	public void setCC_UKEY(String cC_UKEY) {
		CC_UKEY = cC_UKEY;
	}
}