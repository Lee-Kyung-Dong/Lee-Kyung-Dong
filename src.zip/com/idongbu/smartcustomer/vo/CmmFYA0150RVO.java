package com.idongbu.smartcustomer.vo;

import com.idongbu.common.vo.CMMVO;

public class CmmFYA0150RVO extends CMMVO {

	public CmmFYA0150RVO() {
		super.setPGMID(proid);
		super.setTRID(trid);
	}	
	
	private final static String proid     = "FYA0150R";
	private final static String trid	  = "YAF0";
	private String rURL				      = "";
                                         
	// 입력	                             
	private String TERM_ID                = ""; // UNIQUE_KEY
	private String PATH                   = ""; // 처리구분
	private String RE_BANK_CD             = ""; // 은행코드(필수)
	private String RE_GYEJWA_NO           = ""; // 계좌번호(필수)
	private String RE_GOGEK_NO            = ""; // 예금주주민번호(필수)
                                         
	// 출력                              
	private String CHANNEL                = "";
	private String COND_CODE              = "";
	private String CUR_POS_INDEX          = "";
	private String CUR_POS_MAP_ID         = "";
	private String FUNCTION_KEY           = "";
	private String H_MESSAGE_NM           = "";
	private String H_RE_BANK_NM           = ""; // 은행한글명
	private String H_RE_CHECK_NM          = ""; // 위의 체크코드 명 동일,상이,미확인
	private String H_RE_YEGMJU_NM         = ""; // 예금주명(은행으로 보내는)
	private String H_SE_U_D_YEGMJU_NM     = ""; // 예금주명(은행에서 받는)
	private String JIBU_CODE              = "";
	private String JIJUM_CODE             = "";
	private String LOG_SOCKET_NO          = "";
	private Short NODE_NAME1             ;
	private Short NODE_NAME2             ;
	private Short NODE_NAME3             ;
	private Short NODE_NAME4             ;
	private String PGM_ID                 = "";
	private String PROTOCOL               = "";
	private String RE_CHECK_CD            = ""; // 예금주 계좌와 주민번호 일치여부 체크코드 1:동일 2:상이 3:미확인
	private String SE_DERR_FBRT_PGM       = "";
	private String SE_DERR_FLD            = "";
	private String SE_LAST_FLAG           = "";
	private String SE_MSG_ID              = "";
	private String SE_SM_CONTENTS         = "";
	private String SE_SM_ID               = "";
	private String SE_SM_LEVEL            = "";
	private String SE_SM_PRC              = "";
	private String SE_SM_RC               = "";
	private String SE_SYS_MSG_ID          = "";
	private String SOCKET_DATA            = "";
	private String SSO_COMMON_DATA        = "";
	private String TR_SOCKET_NO           = "";
	private String USER_ID                = "";
	private String USER_ID_F              = "";
	private String Length                 = "";
	private String RecordName             = "";
	private String RecordShortDescription = "";
	private String Version                = "";
	
	public String getrURL() {
		return rURL;
	}
	public void setrURL(String rURL) {
		this.rURL = rURL;
	}
	public String getTERM_ID() {
		return TERM_ID;
	}
	public void setTERM_ID(String tERM_ID) {
		TERM_ID = tERM_ID;
	}
	public String getPATH() {
		return PATH;
	}
	public void setPATH(String pATH) {
		PATH = pATH;
	}
	public String getRE_BANK_CD() {
		return RE_BANK_CD;
	}
	public void setRE_BANK_CD(String rE_BANK_CD) {
		RE_BANK_CD = rE_BANK_CD;
	}
	public String getRE_GYEJWA_NO() {
		return RE_GYEJWA_NO;
	}
	public void setRE_GYEJWA_NO(String rE_GYEJWA_NO) {
		RE_GYEJWA_NO = rE_GYEJWA_NO;
	}
	public String getRE_GOGEK_NO() {
		return RE_GOGEK_NO;
	}
	public void setRE_GOGEK_NO(String rE_GOGEK_NO) {
		RE_GOGEK_NO = rE_GOGEK_NO;
	}
	public String getCHANNEL() {
		return CHANNEL;
	}
	public void setCHANNEL(String cHANNEL) {
		CHANNEL = cHANNEL;
	}
	public String getCOND_CODE() {
		return COND_CODE;
	}
	public void setCOND_CODE(String cOND_CODE) {
		COND_CODE = cOND_CODE;
	}
	public String getCUR_POS_INDEX() {
		return CUR_POS_INDEX;
	}
	public void setCUR_POS_INDEX(String cUR_POS_INDEX) {
		CUR_POS_INDEX = cUR_POS_INDEX;
	}
	public String getCUR_POS_MAP_ID() {
		return CUR_POS_MAP_ID;
	}
	public void setCUR_POS_MAP_ID(String cUR_POS_MAP_ID) {
		CUR_POS_MAP_ID = cUR_POS_MAP_ID;
	}
	public String getFUNCTION_KEY() {
		return FUNCTION_KEY;
	}
	public void setFUNCTION_KEY(String fUNCTION_KEY) {
		FUNCTION_KEY = fUNCTION_KEY;
	}
	public String getH_MESSAGE_NM() {
		return H_MESSAGE_NM;
	}
	public void setH_MESSAGE_NM(String h_MESSAGE_NM) {
		H_MESSAGE_NM = h_MESSAGE_NM;
	}
	public String getH_RE_BANK_NM() {
		return H_RE_BANK_NM;
	}
	public void setH_RE_BANK_NM(String h_RE_BANK_NM) {
		H_RE_BANK_NM = h_RE_BANK_NM;
	}
	public String getH_RE_CHECK_NM() {
		return H_RE_CHECK_NM;
	}
	public void setH_RE_CHECK_NM(String h_RE_CHECK_NM) {
		H_RE_CHECK_NM = h_RE_CHECK_NM;
	}
	public String getH_RE_YEGMJU_NM() {
		return H_RE_YEGMJU_NM;
	}
	public void setH_RE_YEGMJU_NM(String h_RE_YEGMJU_NM) {
		H_RE_YEGMJU_NM = h_RE_YEGMJU_NM;
	}
	public String getH_SE_U_D_YEGMJU_NM() {
		return H_SE_U_D_YEGMJU_NM;
	}
	public void setH_SE_U_D_YEGMJU_NM(String h_SE_U_D_YEGMJU_NM) {
		H_SE_U_D_YEGMJU_NM = h_SE_U_D_YEGMJU_NM;
	}
	public String getJIBU_CODE() {
		return JIBU_CODE;
	}
	public void setJIBU_CODE(String jIBU_CODE) {
		JIBU_CODE = jIBU_CODE;
	}
	public String getJIJUM_CODE() {
		return JIJUM_CODE;
	}
	public void setJIJUM_CODE(String jIJUM_CODE) {
		JIJUM_CODE = jIJUM_CODE;
	}
	public String getLOG_SOCKET_NO() {
		return LOG_SOCKET_NO;
	}
	public void setLOG_SOCKET_NO(String lOG_SOCKET_NO) {
		LOG_SOCKET_NO = lOG_SOCKET_NO;
	}
	public String getPGM_ID() {
		return PGM_ID;
	}
	public void setPGM_ID(String pGM_ID) {
		PGM_ID = pGM_ID;
	}
	public String getPROTOCOL() {
		return PROTOCOL;
	}
	public void setPROTOCOL(String pROTOCOL) {
		PROTOCOL = pROTOCOL;
	}
	public String getRE_CHECK_CD() {
		return RE_CHECK_CD;
	}
	public void setRE_CHECK_CD(String rE_CHECK_CD) {
		RE_CHECK_CD = rE_CHECK_CD;
	}
	public String getSE_DERR_FBRT_PGM() {
		return SE_DERR_FBRT_PGM;
	}
	public void setSE_DERR_FBRT_PGM(String sE_DERR_FBRT_PGM) {
		SE_DERR_FBRT_PGM = sE_DERR_FBRT_PGM;
	}
	public String getSE_DERR_FLD() {
		return SE_DERR_FLD;
	}
	public void setSE_DERR_FLD(String sE_DERR_FLD) {
		SE_DERR_FLD = sE_DERR_FLD;
	}
	public String getSE_LAST_FLAG() {
		return SE_LAST_FLAG;
	}
	public void setSE_LAST_FLAG(String sE_LAST_FLAG) {
		SE_LAST_FLAG = sE_LAST_FLAG;
	}
	public String getSE_MSG_ID() {
		return SE_MSG_ID;
	}
	public void setSE_MSG_ID(String sE_MSG_ID) {
		SE_MSG_ID = sE_MSG_ID;
	}
	public String getSE_SM_CONTENTS() {
		return SE_SM_CONTENTS;
	}
	public void setSE_SM_CONTENTS(String sE_SM_CONTENTS) {
		SE_SM_CONTENTS = sE_SM_CONTENTS;
	}
	public String getSE_SM_ID() {
		return SE_SM_ID;
	}
	public void setSE_SM_ID(String sE_SM_ID) {
		SE_SM_ID = sE_SM_ID;
	}
	public String getSE_SM_LEVEL() {
		return SE_SM_LEVEL;
	}
	public void setSE_SM_LEVEL(String sE_SM_LEVEL) {
		SE_SM_LEVEL = sE_SM_LEVEL;
	}
	public String getSE_SM_PRC() {
		return SE_SM_PRC;
	}
	public void setSE_SM_PRC(String sE_SM_PRC) {
		SE_SM_PRC = sE_SM_PRC;
	}
	public String getSE_SM_RC() {
		return SE_SM_RC;
	}
	public void setSE_SM_RC(String sE_SM_RC) {
		SE_SM_RC = sE_SM_RC;
	}
	public String getSE_SYS_MSG_ID() {
		return SE_SYS_MSG_ID;
	}
	public void setSE_SYS_MSG_ID(String sE_SYS_MSG_ID) {
		SE_SYS_MSG_ID = sE_SYS_MSG_ID;
	}
	public String getSOCKET_DATA() {
		return SOCKET_DATA;
	}
	public void setSOCKET_DATA(String sOCKET_DATA) {
		SOCKET_DATA = sOCKET_DATA;
	}
	public String getSSO_COMMON_DATA() {
		return SSO_COMMON_DATA;
	}
	public void setSSO_COMMON_DATA(String sSO_COMMON_DATA) {
		SSO_COMMON_DATA = sSO_COMMON_DATA;
	}
	public String getTR_SOCKET_NO() {
		return TR_SOCKET_NO;
	}
	public void setTR_SOCKET_NO(String tR_SOCKET_NO) {
		TR_SOCKET_NO = tR_SOCKET_NO;
	}
	public String getUSER_ID() {
		return USER_ID;
	}
	public void setUSER_ID(String uSER_ID) {
		USER_ID = uSER_ID;
	}
	public String getUSER_ID_F() {
		return USER_ID_F;
	}
	public void setUSER_ID_F(String uSER_ID_F) {
		USER_ID_F = uSER_ID_F;
	}
	public String getLength() {
		return Length;
	}
	public void setLength(String length) {
		Length = length;
	}
	public String getRecordName() {
		return RecordName;
	}
	public void setRecordName(String recordName) {
		RecordName = recordName;
	}
	public String getRecordShortDescription() {
		return RecordShortDescription;
	}
	public void setRecordShortDescription(String recordShortDescription) {
		RecordShortDescription = recordShortDescription;
	}
	public String getVersion() {
		return Version;
	}
	public void setVersion(String version) {
		Version = version;
	}
	public Short getNODE_NAME1() {
		return NODE_NAME1;
	}
	public void setNODE_NAME1(Short nODE_NAME1) {
		NODE_NAME1 = nODE_NAME1;
	}
	public Short getNODE_NAME2() {
		return NODE_NAME2;
	}
	public void setNODE_NAME2(Short nODE_NAME2) {
		NODE_NAME2 = nODE_NAME2;
	}
	public Short getNODE_NAME3() {
		return NODE_NAME3;
	}
	public void setNODE_NAME3(Short nODE_NAME3) {
		NODE_NAME3 = nODE_NAME3;
	}
	public Short getNODE_NAME4() {
		return NODE_NAME4;
	}
	public void setNODE_NAME4(Short nODE_NAME4) {
		NODE_NAME4 = nODE_NAME4;
	}
}
