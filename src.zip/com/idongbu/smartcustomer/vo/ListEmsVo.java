package com.idongbu.smartcustomer.vo;

public class ListEmsVo {
	
	public String workday	= "";
	public String seqno	= "";
	public String member_id	= "";
	public String to_name	= "";
	public String to_mail	= "";
	public String mapping	= "";
	public int member_id_seq = 0;
	public String list_table = "";
	
	public String getMember_id() {
		return member_id;
	}
	public void setMember_id(String member_id) {
		this.member_id = member_id;
	}
	public String getTo_name() {
		return to_name;
	}
	public void setTo_name(String to_name) {
		this.to_name = to_name;
	}
	public String getTo_mail() {
		return to_mail;
	}
	public void setTo_mail(String to_mail) {
		this.to_mail = to_mail;
	}
	public String getMapping() {
		return mapping;
	}
	public void setMapping(String mapping) {
		this.mapping = mapping;
	}
	public int getMember_id_seq() {
		return member_id_seq;
	}
	public void setMember_id_seq(int member_id_seq) {
		this.member_id_seq = member_id_seq;
	}
	public String getWorkday() {
		return workday;
	}
	public void setWorkday(String workday) {
		this.workday = workday;
	}
	public String getSeqno() {
		return seqno;
	}
	public void setSeqno(String seqno) {
		this.seqno = seqno;
	}
	public String getList_table() {
		return list_table;
	}
	public void setList_table(String list_table) {
		this.list_table = list_table;
	}
}
