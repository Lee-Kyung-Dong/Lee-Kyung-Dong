package com.idongbu.smartcustomer.vo;

import java.util.List;

public class SubFGZ5917SVO {
	public String LK_BJ_NM  	        		= null;
	public List<SubFGZ5917STBLVO> LK_GZ5917_TBL = null;
	public String LK_FIL				    	= null;
	
	public String getLK_BJ_NM() {
		return LK_BJ_NM;
	}
	public void setLK_BJ_NM(String lK_BJ_NM) {
		LK_BJ_NM = lK_BJ_NM;
	}
	public List<SubFGZ5917STBLVO> getLK_GZ5917_TBL() {
		return LK_GZ5917_TBL;
	}
	public void setLK_GZ5917_TBL(List<SubFGZ5917STBLVO> lK_GZ5917_TBL) {
		LK_GZ5917_TBL = lK_GZ5917_TBL;
	}
	public String getLK_FIL() {
		return LK_FIL;
	}
	public void setLK_FIL(String lK_FIL) {
		LK_FIL = lK_FIL;
	}

}
