package com.idongbu.smartcustomer.vo;

import java.util.ArrayList;

import com.idongbu.common.vo.CMMVO;


public class CyCerPriFRI1037RVO extends CMMVO {
	
	public CyCerPriFRI1037RVO() {
		super.setPGMID(this.proid);
		super.setTRID(this.trid);
	}
	
	public static final String proid		  = "FRI1037R";
	public static final String trid			  = "RI84";
	public String rURL						  = "";
	
	// 공통
	public String USER_GB		= "";
	public String USER_CD		= "";
	public String JIJUM_CD		= "";
	public String JIBU_CD		= "";
	
	//COMM_HEAD_AREA.	
//	public String TRID         	  = "";
	public String CHANNEL         = "";
	public String UNIQUE          = "";
//	public String PGMID           = "";
	public String PROC_GB         = "";
	public String FUN_KEY         = "";
	public String PROTOCOL        = "";
	public String LAST_FLAG       = "";
	public String MESSAGE_CD      = "";
	public String MESSAGE_NM      = "";
	public String FORM_ID         = "";
	public String TS_ITEM         = "";
	public String RETURN_FORM_ID  = "";
	
	// 호스트 조회
	public String JUBSU_NO            	 = "";
	public String MOKJUK_GB           	 = "";
	public String PRT_DATA 		 		 = "";
	public String MOKJUK_SEQ           	 = "";
	
	// 실제사용
	public String CC_UKEY           	 = "";
	public String CC_PROC_GB           	 = "";
	public String CC_FUN_KEY           	 = "";
	public String CC_USER_GB		= "";
	public String CC_USER_CD		= "";
	public String CC_JIJUM_CD		= "";
	public String CC_JIBU_CD		= "";
	public String CC_FORM_ID         = "";
	public String SS_SAGO_JUBSU_NO           	 = "";
	public String SS_SAGO_MOKJUK_GB           	 = "";
	public String SS_SAGO_MOKJUK_SEQ           	 = "";
	
	// 주민번호
	public String JUMIN_NO		= "";
		
	// 에러
	public String ERROR_CD		= "";

	public String getrURL() {
		return rURL;
	}

	public void setrURL(String rURL) {
		this.rURL = rURL;
	}

	public String getUSER_GB() {
		return USER_GB;
	}

	public void setUSER_GB(String uSER_GB) {
		USER_GB = uSER_GB;
	}

	public String getUSER_CD() {
		return USER_CD;
	}

	public void setUSER_CD(String uSER_CD) {
		USER_CD = uSER_CD;
	}

	public String getJIJUM_CD() {
		return JIJUM_CD;
	}

	public void setJIJUM_CD(String jIJUM_CD) {
		JIJUM_CD = jIJUM_CD;
	}

	public String getJIBU_CD() {
		return JIBU_CD;
	}

	public void setJIBU_CD(String jIBU_CD) {
		JIBU_CD = jIBU_CD;
	}

	public String getCHANNEL() {
		return CHANNEL;
	}

	public void setCHANNEL(String cHANNEL) {
		CHANNEL = cHANNEL;
	}

	public String getUNIQUE() {
		return UNIQUE;
	}

	public void setUNIQUE(String uNIQUE) {
		UNIQUE = uNIQUE;
	}

	public String getPROC_GB() {
		return PROC_GB;
	}

	public void setPROC_GB(String pROC_GB) {
		PROC_GB = pROC_GB;
	}

	public String getFUN_KEY() {
		return FUN_KEY;
	}

	public void setFUN_KEY(String fUN_KEY) {
		FUN_KEY = fUN_KEY;
	}

	public String getPROTOCOL() {
		return PROTOCOL;
	}

	public void setPROTOCOL(String pROTOCOL) {
		PROTOCOL = pROTOCOL;
	}

	public String getLAST_FLAG() {
		return LAST_FLAG;
	}

	public void setLAST_FLAG(String lAST_FLAG) {
		LAST_FLAG = lAST_FLAG;
	}

	public String getMESSAGE_CD() {
		return MESSAGE_CD;
	}

	public void setMESSAGE_CD(String mESSAGE_CD) {
		MESSAGE_CD = mESSAGE_CD;
	}

	public String getMESSAGE_NM() {
		return MESSAGE_NM;
	}

	public void setMESSAGE_NM(String mESSAGE_NM) {
		MESSAGE_NM = mESSAGE_NM;
	}

	public String getFORM_ID() {
		return FORM_ID;
	}

	public void setFORM_ID(String fORM_ID) {
		FORM_ID = fORM_ID;
	}

	public String getTS_ITEM() {
		return TS_ITEM;
	}

	public void setTS_ITEM(String tS_ITEM) {
		TS_ITEM = tS_ITEM;
	}

	public String getRETURN_FORM_ID() {
		return RETURN_FORM_ID;
	}

	public void setRETURN_FORM_ID(String rETURN_FORM_ID) {
		RETURN_FORM_ID = rETURN_FORM_ID;
	}

	public String getJUBSU_NO() {
		return JUBSU_NO;
	}

	public void setJUBSU_NO(String jUBSU_NO) {
		JUBSU_NO = jUBSU_NO;
	}

	public String getMOKJUK_GB() {
		return MOKJUK_GB;
	}

	public void setMOKJUK_GB(String mOKJUK_GB) {
		MOKJUK_GB = mOKJUK_GB;
	}

	public String getPRT_DATA() {
		return PRT_DATA;
	}

	public void setPRT_DATA(String pRT_DATA) {
		PRT_DATA = pRT_DATA;
	}

	public String getMOKJUK_SEQ() {
		return MOKJUK_SEQ;
	}

	public void setMOKJUK_SEQ(String mOKJUK_SEQ) {
		MOKJUK_SEQ = mOKJUK_SEQ;
	}

	public String getJUMIN_NO() {
		return JUMIN_NO;
	}

	public void setJUMIN_NO(String jUMIN_NO) {
		JUMIN_NO = jUMIN_NO;
	}

	public String getERROR_CD() {
		return ERROR_CD;
	}

	public void setERROR_CD(String eRROR_CD) {
		ERROR_CD = eRROR_CD;
	}

	public static String getProid() {
		return proid;
	}

	public static String getTrid() {
		return trid;
	}

	public String getSS_SAGO_JUBSU_NO() {
		return SS_SAGO_JUBSU_NO;
	}

	public void setSS_SAGO_JUBSU_NO(String sS_SAGO_JUBSU_NO) {
		SS_SAGO_JUBSU_NO = sS_SAGO_JUBSU_NO;
	}

	public String getSS_SAGO_MOKJUK_GB() {
		return SS_SAGO_MOKJUK_GB;
	}

	public void setSS_SAGO_MOKJUK_GB(String sS_SAGO_MOKJUK_GB) {
		SS_SAGO_MOKJUK_GB = sS_SAGO_MOKJUK_GB;
	}

	public String getSS_SAGO_MOKJUK_SEQ() {
		return SS_SAGO_MOKJUK_SEQ;
	}

	public void setSS_SAGO_MOKJUK_SEQ(String sS_SAGO_MOKJUK_SEQ) {
		SS_SAGO_MOKJUK_SEQ = sS_SAGO_MOKJUK_SEQ;
	}

	public String getCC_UKEY() {
		return CC_UKEY;
	}

	public void setCC_UKEY(String cC_UKEY) {
		CC_UKEY = cC_UKEY;
	}

	public String getCC_PROC_GB() {
		return CC_PROC_GB;
	}

	public void setCC_PROC_GB(String cC_PROC_GB) {
		CC_PROC_GB = cC_PROC_GB;
	}

	public String getCC_FUN_KEY() {
		return CC_FUN_KEY;
	}

	public void setCC_FUN_KEY(String cC_FUN_KEY) {
		CC_FUN_KEY = cC_FUN_KEY;
	}

	public String getCC_USER_GB() {
		return CC_USER_GB;
	}

	public void setCC_USER_GB(String cC_USER_GB) {
		CC_USER_GB = cC_USER_GB;
	}

	public String getCC_USER_CD() {
		return CC_USER_CD;
	}

	public void setCC_USER_CD(String cC_USER_CD) {
		CC_USER_CD = cC_USER_CD;
	}

	public String getCC_JIJUM_CD() {
		return CC_JIJUM_CD;
	}

	public void setCC_JIJUM_CD(String cC_JIJUM_CD) {
		CC_JIJUM_CD = cC_JIJUM_CD;
	}

	public String getCC_JIBU_CD() {
		return CC_JIBU_CD;
	}

	public void setCC_JIBU_CD(String cC_JIBU_CD) {
		CC_JIBU_CD = cC_JIBU_CD;
	}

	public String getCC_FORM_ID() {
		return CC_FORM_ID;
	}

	public void setCC_FORM_ID(String cC_FORM_ID) {
		CC_FORM_ID = cC_FORM_ID;
	}
	
}
