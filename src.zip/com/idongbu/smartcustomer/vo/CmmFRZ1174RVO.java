package com.idongbu.smartcustomer.vo;

import com.idongbu.common.vo.CMMVO;

// 사고사실 내역조회
public class CmmFRZ1174RVO extends CMMVO {
	
	public CmmFRZ1174RVO() {
		super.setPGMID(this.proid);
		super.setTRID(this.trid);
	}	

	public static final String proid		= "FRZ1174R";
	public static final String trid		= "RZ03";
	public String rURL						= "";

	// 입력
	public String LK_I_JUMIN_NO = "";

	// 출력
	public String LK_TRID = "";
	public String LK_FLAG = "";
	public String LK_NT_CD = "";
	public String LK_RSP_TIME = "";
	public String LK_COMP_GB = "";
	public String LK_COMP_CD = "";
	public String LK_FILLER = "";
	public String LK_USER_ID = "";
	public String LK_PART_GB1 = "";
	public String LK_PART_GB2 = "";
	public String LK_UPMU_CD1 = "";
	public String LK_UPMU_CD2 = "";
	public String LK_UPMU_CD3 = "";
	public String LK_GULK_GB = "";
	public String LK_CM_FILLER = "";
	public String LK_RETURN_CD = "";
	public String LK_MSG_CD1 = "";
	public String LK_MSG_CD2 = "";
	public String H_LK_MESSAGE1 = "";
	public String H_LK_MESSAGE2 = "";
//	public String LK_I_JUMIN_NO = "";
	public String LK_SAGO_JUBSU_NO1 = "";
	public String LK_SAGO_MOKJUK_GB1 = "";
	public String LK_SAGO_MOKJUK_SEQ1 = "";
	public String LK_BJ_NM1 = "";
	public String LK_PROD_NM1 = "";
	public String LK_PIHEJA_NAME1 = "";
	public String LK_SAGO_YMDSB1 = "";
	public String LK_SAGO_JUBSU_NO2 = "";
	public String LK_SAGO_MOKJUK_GB2 = "";
	public String LK_SAGO_MOKJUK_SEQ2 = "";
	public String LK_BJ_NM2 = "";
	public String LK_PROD_NM2 = "";
	public String LK_PIHEJA_NAME2 = "";
	public String LK_SAGO_YMDSB2 = "";
	public String LK_SAGO_JUBSU_NO3 = "";
	public String LK_SAGO_MOKJUK_GB3 = "";
	public String LK_SAGO_MOKJUK_SEQ3 = "";
	public String LK_BJ_NM3 = "";
	public String LK_PROD_NM3 = "";
	public String LK_PIHEJA_NAME3 = "";
	public String LK_SAGO_YMDSB3 = "";
	public String LK_SAGO_JUBSU_NO4 = "";
	public String LK_SAGO_MOKJUK_GB4 = "";
	public String LK_SAGO_MOKJUK_SEQ4 = "";
	public String LK_BJ_NM4 = "";
	public String LK_PROD_NM4 = "";
	public String LK_PIHEJA_NAME4 = "";
	public String LK_SAGO_YMDSB4 = "";
	public String LK_SAGO_JUBSU_NO5 = "";
	public String LK_SAGO_MOKJUK_GB5 = "";
	public String LK_SAGO_MOKJUK_SEQ5 = "";
	public String LK_BJ_NM5 = "";
	public String LK_PROD_NM5 = "";
	public String LK_PIHEJA_NAME5 = "";
	public String LK_SAGO_YMDSB5 = "";
	public String LK_SAGO_JUBSU_NO6 = "";
	public String LK_SAGO_MOKJUK_GB6 = "";
	public String LK_SAGO_MOKJUK_SEQ6 = "";
	public String LK_BJ_NM6 = "";
	public String LK_PROD_NM6 = "";
	public String LK_PIHEJA_NAME6 = "";
	public String LK_SAGO_YMDSB6 = "";
	public String LK_SAGO_JUBSU_NO7 = "";
	public String LK_SAGO_MOKJUK_GB7 = "";
	public String LK_SAGO_MOKJUK_SEQ7 = "";
	public String LK_BJ_NM7 = "";
	public String LK_PROD_NM7 = "";
	public String LK_PIHEJA_NAME7 = "";
	public String LK_SAGO_YMDSB7 = "";
	public String LK_SAGO_JUBSU_NO8 = "";
	public String LK_SAGO_MOKJUK_GB8 = "";
	public String LK_SAGO_MOKJUK_SEQ8 = "";
	public String LK_BJ_NM8 = "";
	public String LK_PROD_NM8 = "";
	public String LK_PIHEJA_NAME8 = "";
	public String LK_SAGO_YMDSB8 = "";
	public String LK_SAGO_JUBSU_NO9 = "";
	public String LK_SAGO_MOKJUK_GB9 = "";
	public String LK_SAGO_MOKJUK_SEQ9 = "";
	public String LK_BJ_NM9 = "";
	public String LK_PROD_NM9 = "";
	public String LK_PIHEJA_NAME9 = "";
	public String LK_SAGO_YMDSB9 = "";
	public String LK_SAGO_JUBSU_NO10 = "";
	public String LK_SAGO_MOKJUK_GB10 = "";
	public String LK_SAGO_MOKJUK_SEQ10 = "";
	public String LK_BJ_NM10 = "";
	public String LK_PROD_NM10 = "";
	public String LK_PIHEJA_NAME10 = "";
	public String LK_SAGO_YMDSB10 = "";
	public String LK_SAGO_JUBSU_NO11 = "";
	public String LK_SAGO_MOKJUK_GB11 = "";
	public String LK_SAGO_MOKJUK_SEQ11 = "";
	public String LK_BJ_NM11 = "";
	public String LK_PROD_NM11 = "";
	public String LK_PIHEJA_NAME11 = "";
	public String LK_SAGO_YMDSB11 = "";
	public String LK_SAGO_JUBSU_NO12 = "";
	public String LK_SAGO_MOKJUK_GB12 = "";
	public String LK_SAGO_MOKJUK_SEQ12 = "";
	public String LK_BJ_NM12 = "";
	public String LK_PROD_NM12 = "";
	public String LK_PIHEJA_NAME12 = "";
	public String LK_SAGO_YMDSB12 = "";
	public String LK_SAGO_JUBSU_NO13 = "";
	public String LK_SAGO_MOKJUK_GB13 = "";
	public String LK_SAGO_MOKJUK_SEQ13 = "";
	public String LK_BJ_NM13 = "";
	public String LK_PROD_NM13 = "";
	public String LK_PIHEJA_NAME13 = "";
	public String LK_SAGO_YMDSB13 = "";
	public String LK_SAGO_JUBSU_NO14 = "";
	public String LK_SAGO_MOKJUK_GB14 = "";
	public String LK_SAGO_MOKJUK_SEQ14 = "";
	public String LK_BJ_NM14 = "";
	public String LK_PROD_NM14 = "";
	public String LK_PIHEJA_NAME14 = "";
	public String LK_SAGO_YMDSB14 = "";
	public String LK_SAGO_JUBSU_NO15 = "";
	public String LK_SAGO_MOKJUK_GB15 = "";
	public String LK_SAGO_MOKJUK_SEQ15 = "";
	public String LK_BJ_NM15 = "";
	public String LK_PROD_NM15 = "";
	public String LK_PIHEJA_NAME15 = "";
	public String LK_SAGO_YMDSB15 = "";
	public String LK_SAGO_JUBSU_NO16 = "";
	public String LK_SAGO_MOKJUK_GB16 = "";
	public String LK_SAGO_MOKJUK_SEQ16 = "";
	public String LK_BJ_NM16 = "";
	public String LK_PROD_NM16 = "";
	public String LK_PIHEJA_NAME16 = "";
	public String LK_SAGO_YMDSB16 = "";
	public String LK_SAGO_JUBSU_NO17 = "";
	public String LK_SAGO_MOKJUK_GB17 = "";
	public String LK_SAGO_MOKJUK_SEQ17 = "";
	public String LK_BJ_NM17 = "";
	public String LK_PROD_NM17 = "";
	public String LK_PIHEJA_NAME17 = "";
	public String LK_SAGO_YMDSB17 = "";
	public String LK_SAGO_JUBSU_NO18 = "";
	public String LK_SAGO_MOKJUK_GB18 = "";
	public String LK_SAGO_MOKJUK_SEQ18 = "";
	public String LK_BJ_NM18 = "";
	public String LK_PROD_NM18 = "";
	public String LK_PIHEJA_NAME18 = "";
	public String LK_SAGO_YMDSB18 = "";
	public String LK_SAGO_JUBSU_NO19 = "";
	public String LK_SAGO_MOKJUK_GB19 = "";
	public String LK_SAGO_MOKJUK_SEQ19 = "";
	public String LK_BJ_NM19 = "";
	public String LK_PROD_NM19 = "";
	public String LK_PIHEJA_NAME19 = "";
	public String LK_SAGO_YMDSB19 = "";
	public String LK_SAGO_JUBSU_NO20 = "";
	public String LK_SAGO_MOKJUK_GB20 = "";
	public String LK_SAGO_MOKJUK_SEQ20 = "";
	public String LK_BJ_NM20 = "";
	public String LK_PROD_NM20 = "";
	public String LK_PIHEJA_NAME20 = "";
	public String LK_SAGO_YMDSB20 = "";
	public String LK_SAGO_JUBSU_NO21 = "";
	public String LK_SAGO_MOKJUK_GB21 = "";
	public String LK_SAGO_MOKJUK_SEQ21 = "";
	public String LK_BJ_NM21 = "";
	public String LK_PROD_NM21 = "";
	public String LK_PIHEJA_NAME21 = "";
	public String LK_SAGO_YMDSB21 = "";
	public String LK_SAGO_JUBSU_NO22 = "";
	public String LK_SAGO_MOKJUK_GB22 = "";
	public String LK_SAGO_MOKJUK_SEQ22 = "";
	public String LK_BJ_NM22 = "";
	public String LK_PROD_NM22 = "";
	public String LK_PIHEJA_NAME22 = "";
	public String LK_SAGO_YMDSB22 = "";
	public String LK_SAGO_JUBSU_NO23 = "";
	public String LK_SAGO_MOKJUK_GB23 = "";
	public String LK_SAGO_MOKJUK_SEQ23 = "";
	public String LK_BJ_NM23 = "";
	public String LK_PROD_NM23 = "";
	public String LK_PIHEJA_NAME23 = "";
	public String LK_SAGO_YMDSB23 = "";
	public String LK_SAGO_JUBSU_NO24 = "";
	public String LK_SAGO_MOKJUK_GB24 = "";
	public String LK_SAGO_MOKJUK_SEQ24 = "";
	public String LK_BJ_NM24 = "";
	public String LK_PROD_NM24 = "";
	public String LK_PIHEJA_NAME24 = "";
	public String LK_SAGO_YMDSB24 = "";
	public String LK_SAGO_JUBSU_NO25 = "";
	public String LK_SAGO_MOKJUK_GB25 = "";
	public String LK_SAGO_MOKJUK_SEQ25 = "";
	public String LK_BJ_NM25 = "";
	public String LK_PROD_NM25 = "";
	public String LK_PIHEJA_NAME25 = "";
	public String LK_SAGO_YMDSB25 = "";
	public String LK_SAGO_JUBSU_NO26 = "";
	public String LK_SAGO_MOKJUK_GB26 = "";
	public String LK_SAGO_MOKJUK_SEQ26 = "";
	public String LK_BJ_NM26 = "";
	public String LK_PROD_NM26 = "";
	public String LK_PIHEJA_NAME26 = "";
	public String LK_SAGO_YMDSB26 = "";
	public String LK_SAGO_JUBSU_NO27 = "";
	public String LK_SAGO_MOKJUK_GB27 = "";
	public String LK_SAGO_MOKJUK_SEQ27 = "";
	public String LK_BJ_NM27 = "";
	public String LK_PROD_NM27 = "";
	public String LK_PIHEJA_NAME27 = "";
	public String LK_SAGO_YMDSB27 = "";
	public String LK_SAGO_JUBSU_NO28 = "";
	public String LK_SAGO_MOKJUK_GB28 = "";
	public String LK_SAGO_MOKJUK_SEQ28 = "";
	public String LK_BJ_NM28 = "";
	public String LK_PROD_NM28 = "";
	public String LK_PIHEJA_NAME28 = "";
	public String LK_SAGO_YMDSB28 = "";
	public String LK_SAGO_JUBSU_NO29 = "";
	public String LK_SAGO_MOKJUK_GB29 = "";
	public String LK_SAGO_MOKJUK_SEQ29 = "";
	public String LK_BJ_NM29 = "";
	public String LK_PROD_NM29 = "";
	public String LK_PIHEJA_NAME29 = "";
	public String LK_SAGO_YMDSB29 = "";
	public String LK_SAGO_JUBSU_NO30 = "";
	public String LK_SAGO_MOKJUK_GB30 = "";
	public String LK_SAGO_MOKJUK_SEQ30 = "";
	public String LK_BJ_NM30 = "";
	public String LK_PROD_NM30 = "";
	public String LK_PIHEJA_NAME30 = "";
	public String LK_SAGO_YMDSB30 = "";
	public String FILLER = "";
	
	public String getrURL() {
		return rURL;
	}
	public void setrURL(String rURL) {
		this.rURL = rURL;
	}
	public String getLK_I_JUMIN_NO() {
		return LK_I_JUMIN_NO;
	}
	public void setLK_I_JUMIN_NO(String lK_I_JUMIN_NO) {
		LK_I_JUMIN_NO = lK_I_JUMIN_NO;
	}
	public String getLK_TRID() {
		return LK_TRID;
	}
	public void setLK_TRID(String lK_TRID) {
		LK_TRID = lK_TRID;
	}
	public String getLK_FLAG() {
		return LK_FLAG;
	}
	public void setLK_FLAG(String lK_FLAG) {
		LK_FLAG = lK_FLAG;
	}
	public String getLK_NT_CD() {
		return LK_NT_CD;
	}
	public void setLK_NT_CD(String lK_NT_CD) {
		LK_NT_CD = lK_NT_CD;
	}
	public String getLK_RSP_TIME() {
		return LK_RSP_TIME;
	}
	public void setLK_RSP_TIME(String lK_RSP_TIME) {
		LK_RSP_TIME = lK_RSP_TIME;
	}
	public String getLK_COMP_GB() {
		return LK_COMP_GB;
	}
	public void setLK_COMP_GB(String lK_COMP_GB) {
		LK_COMP_GB = lK_COMP_GB;
	}
	public String getLK_COMP_CD() {
		return LK_COMP_CD;
	}
	public void setLK_COMP_CD(String lK_COMP_CD) {
		LK_COMP_CD = lK_COMP_CD;
	}
	public String getLK_FILLER() {
		return LK_FILLER;
	}
	public void setLK_FILLER(String lK_FILLER) {
		LK_FILLER = lK_FILLER;
	}
	public String getLK_USER_ID() {
		return LK_USER_ID;
	}
	public void setLK_USER_ID(String lK_USER_ID) {
		LK_USER_ID = lK_USER_ID;
	}
	public String getLK_PART_GB1() {
		return LK_PART_GB1;
	}
	public void setLK_PART_GB1(String lK_PART_GB1) {
		LK_PART_GB1 = lK_PART_GB1;
	}
	public String getLK_PART_GB2() {
		return LK_PART_GB2;
	}
	public void setLK_PART_GB2(String lK_PART_GB2) {
		LK_PART_GB2 = lK_PART_GB2;
	}
	public String getLK_UPMU_CD1() {
		return LK_UPMU_CD1;
	}
	public void setLK_UPMU_CD1(String lK_UPMU_CD1) {
		LK_UPMU_CD1 = lK_UPMU_CD1;
	}
	public String getLK_UPMU_CD2() {
		return LK_UPMU_CD2;
	}
	public void setLK_UPMU_CD2(String lK_UPMU_CD2) {
		LK_UPMU_CD2 = lK_UPMU_CD2;
	}
	public String getLK_UPMU_CD3() {
		return LK_UPMU_CD3;
	}
	public void setLK_UPMU_CD3(String lK_UPMU_CD3) {
		LK_UPMU_CD3 = lK_UPMU_CD3;
	}
	public String getLK_GULK_GB() {
		return LK_GULK_GB;
	}
	public void setLK_GULK_GB(String lK_GULK_GB) {
		LK_GULK_GB = lK_GULK_GB;
	}
	public String getLK_CM_FILLER() {
		return LK_CM_FILLER;
	}
	public void setLK_CM_FILLER(String lK_CM_FILLER) {
		LK_CM_FILLER = lK_CM_FILLER;
	}
	public String getLK_RETURN_CD() {
		return LK_RETURN_CD;
	}
	public void setLK_RETURN_CD(String lK_RETURN_CD) {
		LK_RETURN_CD = lK_RETURN_CD;
	}
	public String getLK_MSG_CD1() {
		return LK_MSG_CD1;
	}
	public void setLK_MSG_CD1(String lK_MSG_CD1) {
		LK_MSG_CD1 = lK_MSG_CD1;
	}
	public String getLK_MSG_CD2() {
		return LK_MSG_CD2;
	}
	public void setLK_MSG_CD2(String lK_MSG_CD2) {
		LK_MSG_CD2 = lK_MSG_CD2;
	}
	public String getH_LK_MESSAGE1() {
		return H_LK_MESSAGE1;
	}
	public void setH_LK_MESSAGE1(String h_LK_MESSAGE1) {
		H_LK_MESSAGE1 = h_LK_MESSAGE1;
	}
	public String getH_LK_MESSAGE2() {
		return H_LK_MESSAGE2;
	}
	public void setH_LK_MESSAGE2(String h_LK_MESSAGE2) {
		H_LK_MESSAGE2 = h_LK_MESSAGE2;
	}
	public String getLK_SAGO_JUBSU_NO1() {
		return LK_SAGO_JUBSU_NO1;
	}
	public void setLK_SAGO_JUBSU_NO1(String lK_SAGO_JUBSU_NO1) {
		LK_SAGO_JUBSU_NO1 = lK_SAGO_JUBSU_NO1;
	}
	public String getLK_SAGO_MOKJUK_GB1() {
		return LK_SAGO_MOKJUK_GB1;
	}
	public void setLK_SAGO_MOKJUK_GB1(String lK_SAGO_MOKJUK_GB1) {
		LK_SAGO_MOKJUK_GB1 = lK_SAGO_MOKJUK_GB1;
	}
	public String getLK_SAGO_MOKJUK_SEQ1() {
		return LK_SAGO_MOKJUK_SEQ1;
	}
	public void setLK_SAGO_MOKJUK_SEQ1(String lK_SAGO_MOKJUK_SEQ1) {
		LK_SAGO_MOKJUK_SEQ1 = lK_SAGO_MOKJUK_SEQ1;
	}
	public String getLK_BJ_NM1() {
		return LK_BJ_NM1;
	}
	public void setLK_BJ_NM1(String lK_BJ_NM1) {
		LK_BJ_NM1 = lK_BJ_NM1;
	}
	public String getLK_PROD_NM1() {
		return LK_PROD_NM1;
	}
	public void setLK_PROD_NM1(String lK_PROD_NM1) {
		LK_PROD_NM1 = lK_PROD_NM1;
	}
	public String getLK_PIHEJA_NAME1() {
		return LK_PIHEJA_NAME1;
	}
	public void setLK_PIHEJA_NAME1(String lK_PIHEJA_NAME1) {
		LK_PIHEJA_NAME1 = lK_PIHEJA_NAME1;
	}
	public String getLK_SAGO_YMDSB1() {
		return LK_SAGO_YMDSB1;
	}
	public void setLK_SAGO_YMDSB1(String lK_SAGO_YMDSB1) {
		LK_SAGO_YMDSB1 = lK_SAGO_YMDSB1;
	}
	public String getLK_SAGO_JUBSU_NO2() {
		return LK_SAGO_JUBSU_NO2;
	}
	public void setLK_SAGO_JUBSU_NO2(String lK_SAGO_JUBSU_NO2) {
		LK_SAGO_JUBSU_NO2 = lK_SAGO_JUBSU_NO2;
	}
	public String getLK_SAGO_MOKJUK_GB2() {
		return LK_SAGO_MOKJUK_GB2;
	}
	public void setLK_SAGO_MOKJUK_GB2(String lK_SAGO_MOKJUK_GB2) {
		LK_SAGO_MOKJUK_GB2 = lK_SAGO_MOKJUK_GB2;
	}
	public String getLK_SAGO_MOKJUK_SEQ2() {
		return LK_SAGO_MOKJUK_SEQ2;
	}
	public void setLK_SAGO_MOKJUK_SEQ2(String lK_SAGO_MOKJUK_SEQ2) {
		LK_SAGO_MOKJUK_SEQ2 = lK_SAGO_MOKJUK_SEQ2;
	}
	public String getLK_BJ_NM2() {
		return LK_BJ_NM2;
	}
	public void setLK_BJ_NM2(String lK_BJ_NM2) {
		LK_BJ_NM2 = lK_BJ_NM2;
	}
	public String getLK_PROD_NM2() {
		return LK_PROD_NM2;
	}
	public void setLK_PROD_NM2(String lK_PROD_NM2) {
		LK_PROD_NM2 = lK_PROD_NM2;
	}
	public String getLK_PIHEJA_NAME2() {
		return LK_PIHEJA_NAME2;
	}
	public void setLK_PIHEJA_NAME2(String lK_PIHEJA_NAME2) {
		LK_PIHEJA_NAME2 = lK_PIHEJA_NAME2;
	}
	public String getLK_SAGO_YMDSB2() {
		return LK_SAGO_YMDSB2;
	}
	public void setLK_SAGO_YMDSB2(String lK_SAGO_YMDSB2) {
		LK_SAGO_YMDSB2 = lK_SAGO_YMDSB2;
	}
	public String getLK_SAGO_JUBSU_NO3() {
		return LK_SAGO_JUBSU_NO3;
	}
	public void setLK_SAGO_JUBSU_NO3(String lK_SAGO_JUBSU_NO3) {
		LK_SAGO_JUBSU_NO3 = lK_SAGO_JUBSU_NO3;
	}
	public String getLK_SAGO_MOKJUK_GB3() {
		return LK_SAGO_MOKJUK_GB3;
	}
	public void setLK_SAGO_MOKJUK_GB3(String lK_SAGO_MOKJUK_GB3) {
		LK_SAGO_MOKJUK_GB3 = lK_SAGO_MOKJUK_GB3;
	}
	public String getLK_SAGO_MOKJUK_SEQ3() {
		return LK_SAGO_MOKJUK_SEQ3;
	}
	public void setLK_SAGO_MOKJUK_SEQ3(String lK_SAGO_MOKJUK_SEQ3) {
		LK_SAGO_MOKJUK_SEQ3 = lK_SAGO_MOKJUK_SEQ3;
	}
	public String getLK_BJ_NM3() {
		return LK_BJ_NM3;
	}
	public void setLK_BJ_NM3(String lK_BJ_NM3) {
		LK_BJ_NM3 = lK_BJ_NM3;
	}
	public String getLK_PROD_NM3() {
		return LK_PROD_NM3;
	}
	public void setLK_PROD_NM3(String lK_PROD_NM3) {
		LK_PROD_NM3 = lK_PROD_NM3;
	}
	public String getLK_PIHEJA_NAME3() {
		return LK_PIHEJA_NAME3;
	}
	public void setLK_PIHEJA_NAME3(String lK_PIHEJA_NAME3) {
		LK_PIHEJA_NAME3 = lK_PIHEJA_NAME3;
	}
	public String getLK_SAGO_YMDSB3() {
		return LK_SAGO_YMDSB3;
	}
	public void setLK_SAGO_YMDSB3(String lK_SAGO_YMDSB3) {
		LK_SAGO_YMDSB3 = lK_SAGO_YMDSB3;
	}
	public String getLK_SAGO_JUBSU_NO4() {
		return LK_SAGO_JUBSU_NO4;
	}
	public void setLK_SAGO_JUBSU_NO4(String lK_SAGO_JUBSU_NO4) {
		LK_SAGO_JUBSU_NO4 = lK_SAGO_JUBSU_NO4;
	}
	public String getLK_SAGO_MOKJUK_GB4() {
		return LK_SAGO_MOKJUK_GB4;
	}
	public void setLK_SAGO_MOKJUK_GB4(String lK_SAGO_MOKJUK_GB4) {
		LK_SAGO_MOKJUK_GB4 = lK_SAGO_MOKJUK_GB4;
	}
	public String getLK_SAGO_MOKJUK_SEQ4() {
		return LK_SAGO_MOKJUK_SEQ4;
	}
	public void setLK_SAGO_MOKJUK_SEQ4(String lK_SAGO_MOKJUK_SEQ4) {
		LK_SAGO_MOKJUK_SEQ4 = lK_SAGO_MOKJUK_SEQ4;
	}
	public String getLK_BJ_NM4() {
		return LK_BJ_NM4;
	}
	public void setLK_BJ_NM4(String lK_BJ_NM4) {
		LK_BJ_NM4 = lK_BJ_NM4;
	}
	public String getLK_PROD_NM4() {
		return LK_PROD_NM4;
	}
	public void setLK_PROD_NM4(String lK_PROD_NM4) {
		LK_PROD_NM4 = lK_PROD_NM4;
	}
	public String getLK_PIHEJA_NAME4() {
		return LK_PIHEJA_NAME4;
	}
	public void setLK_PIHEJA_NAME4(String lK_PIHEJA_NAME4) {
		LK_PIHEJA_NAME4 = lK_PIHEJA_NAME4;
	}
	public String getLK_SAGO_YMDSB4() {
		return LK_SAGO_YMDSB4;
	}
	public void setLK_SAGO_YMDSB4(String lK_SAGO_YMDSB4) {
		LK_SAGO_YMDSB4 = lK_SAGO_YMDSB4;
	}
	public String getLK_SAGO_JUBSU_NO5() {
		return LK_SAGO_JUBSU_NO5;
	}
	public void setLK_SAGO_JUBSU_NO5(String lK_SAGO_JUBSU_NO5) {
		LK_SAGO_JUBSU_NO5 = lK_SAGO_JUBSU_NO5;
	}
	public String getLK_SAGO_MOKJUK_GB5() {
		return LK_SAGO_MOKJUK_GB5;
	}
	public void setLK_SAGO_MOKJUK_GB5(String lK_SAGO_MOKJUK_GB5) {
		LK_SAGO_MOKJUK_GB5 = lK_SAGO_MOKJUK_GB5;
	}
	public String getLK_SAGO_MOKJUK_SEQ5() {
		return LK_SAGO_MOKJUK_SEQ5;
	}
	public void setLK_SAGO_MOKJUK_SEQ5(String lK_SAGO_MOKJUK_SEQ5) {
		LK_SAGO_MOKJUK_SEQ5 = lK_SAGO_MOKJUK_SEQ5;
	}
	public String getLK_BJ_NM5() {
		return LK_BJ_NM5;
	}
	public void setLK_BJ_NM5(String lK_BJ_NM5) {
		LK_BJ_NM5 = lK_BJ_NM5;
	}
	public String getLK_PROD_NM5() {
		return LK_PROD_NM5;
	}
	public void setLK_PROD_NM5(String lK_PROD_NM5) {
		LK_PROD_NM5 = lK_PROD_NM5;
	}
	public String getLK_PIHEJA_NAME5() {
		return LK_PIHEJA_NAME5;
	}
	public void setLK_PIHEJA_NAME5(String lK_PIHEJA_NAME5) {
		LK_PIHEJA_NAME5 = lK_PIHEJA_NAME5;
	}
	public String getLK_SAGO_YMDSB5() {
		return LK_SAGO_YMDSB5;
	}
	public void setLK_SAGO_YMDSB5(String lK_SAGO_YMDSB5) {
		LK_SAGO_YMDSB5 = lK_SAGO_YMDSB5;
	}
	public String getLK_SAGO_JUBSU_NO6() {
		return LK_SAGO_JUBSU_NO6;
	}
	public void setLK_SAGO_JUBSU_NO6(String lK_SAGO_JUBSU_NO6) {
		LK_SAGO_JUBSU_NO6 = lK_SAGO_JUBSU_NO6;
	}
	public String getLK_SAGO_MOKJUK_GB6() {
		return LK_SAGO_MOKJUK_GB6;
	}
	public void setLK_SAGO_MOKJUK_GB6(String lK_SAGO_MOKJUK_GB6) {
		LK_SAGO_MOKJUK_GB6 = lK_SAGO_MOKJUK_GB6;
	}
	public String getLK_SAGO_MOKJUK_SEQ6() {
		return LK_SAGO_MOKJUK_SEQ6;
	}
	public void setLK_SAGO_MOKJUK_SEQ6(String lK_SAGO_MOKJUK_SEQ6) {
		LK_SAGO_MOKJUK_SEQ6 = lK_SAGO_MOKJUK_SEQ6;
	}
	public String getLK_BJ_NM6() {
		return LK_BJ_NM6;
	}
	public void setLK_BJ_NM6(String lK_BJ_NM6) {
		LK_BJ_NM6 = lK_BJ_NM6;
	}
	public String getLK_PROD_NM6() {
		return LK_PROD_NM6;
	}
	public void setLK_PROD_NM6(String lK_PROD_NM6) {
		LK_PROD_NM6 = lK_PROD_NM6;
	}
	public String getLK_PIHEJA_NAME6() {
		return LK_PIHEJA_NAME6;
	}
	public void setLK_PIHEJA_NAME6(String lK_PIHEJA_NAME6) {
		LK_PIHEJA_NAME6 = lK_PIHEJA_NAME6;
	}
	public String getLK_SAGO_YMDSB6() {
		return LK_SAGO_YMDSB6;
	}
	public void setLK_SAGO_YMDSB6(String lK_SAGO_YMDSB6) {
		LK_SAGO_YMDSB6 = lK_SAGO_YMDSB6;
	}
	public String getLK_SAGO_JUBSU_NO7() {
		return LK_SAGO_JUBSU_NO7;
	}
	public void setLK_SAGO_JUBSU_NO7(String lK_SAGO_JUBSU_NO7) {
		LK_SAGO_JUBSU_NO7 = lK_SAGO_JUBSU_NO7;
	}
	public String getLK_SAGO_MOKJUK_GB7() {
		return LK_SAGO_MOKJUK_GB7;
	}
	public void setLK_SAGO_MOKJUK_GB7(String lK_SAGO_MOKJUK_GB7) {
		LK_SAGO_MOKJUK_GB7 = lK_SAGO_MOKJUK_GB7;
	}
	public String getLK_SAGO_MOKJUK_SEQ7() {
		return LK_SAGO_MOKJUK_SEQ7;
	}
	public void setLK_SAGO_MOKJUK_SEQ7(String lK_SAGO_MOKJUK_SEQ7) {
		LK_SAGO_MOKJUK_SEQ7 = lK_SAGO_MOKJUK_SEQ7;
	}
	public String getLK_BJ_NM7() {
		return LK_BJ_NM7;
	}
	public void setLK_BJ_NM7(String lK_BJ_NM7) {
		LK_BJ_NM7 = lK_BJ_NM7;
	}
	public String getLK_PROD_NM7() {
		return LK_PROD_NM7;
	}
	public void setLK_PROD_NM7(String lK_PROD_NM7) {
		LK_PROD_NM7 = lK_PROD_NM7;
	}
	public String getLK_PIHEJA_NAME7() {
		return LK_PIHEJA_NAME7;
	}
	public void setLK_PIHEJA_NAME7(String lK_PIHEJA_NAME7) {
		LK_PIHEJA_NAME7 = lK_PIHEJA_NAME7;
	}
	public String getLK_SAGO_YMDSB7() {
		return LK_SAGO_YMDSB7;
	}
	public void setLK_SAGO_YMDSB7(String lK_SAGO_YMDSB7) {
		LK_SAGO_YMDSB7 = lK_SAGO_YMDSB7;
	}
	public String getLK_SAGO_JUBSU_NO8() {
		return LK_SAGO_JUBSU_NO8;
	}
	public void setLK_SAGO_JUBSU_NO8(String lK_SAGO_JUBSU_NO8) {
		LK_SAGO_JUBSU_NO8 = lK_SAGO_JUBSU_NO8;
	}
	public String getLK_SAGO_MOKJUK_GB8() {
		return LK_SAGO_MOKJUK_GB8;
	}
	public void setLK_SAGO_MOKJUK_GB8(String lK_SAGO_MOKJUK_GB8) {
		LK_SAGO_MOKJUK_GB8 = lK_SAGO_MOKJUK_GB8;
	}
	public String getLK_SAGO_MOKJUK_SEQ8() {
		return LK_SAGO_MOKJUK_SEQ8;
	}
	public void setLK_SAGO_MOKJUK_SEQ8(String lK_SAGO_MOKJUK_SEQ8) {
		LK_SAGO_MOKJUK_SEQ8 = lK_SAGO_MOKJUK_SEQ8;
	}
	public String getLK_BJ_NM8() {
		return LK_BJ_NM8;
	}
	public void setLK_BJ_NM8(String lK_BJ_NM8) {
		LK_BJ_NM8 = lK_BJ_NM8;
	}
	public String getLK_PROD_NM8() {
		return LK_PROD_NM8;
	}
	public void setLK_PROD_NM8(String lK_PROD_NM8) {
		LK_PROD_NM8 = lK_PROD_NM8;
	}
	public String getLK_PIHEJA_NAME8() {
		return LK_PIHEJA_NAME8;
	}
	public void setLK_PIHEJA_NAME8(String lK_PIHEJA_NAME8) {
		LK_PIHEJA_NAME8 = lK_PIHEJA_NAME8;
	}
	public String getLK_SAGO_YMDSB8() {
		return LK_SAGO_YMDSB8;
	}
	public void setLK_SAGO_YMDSB8(String lK_SAGO_YMDSB8) {
		LK_SAGO_YMDSB8 = lK_SAGO_YMDSB8;
	}
	public String getLK_SAGO_JUBSU_NO9() {
		return LK_SAGO_JUBSU_NO9;
	}
	public void setLK_SAGO_JUBSU_NO9(String lK_SAGO_JUBSU_NO9) {
		LK_SAGO_JUBSU_NO9 = lK_SAGO_JUBSU_NO9;
	}
	public String getLK_SAGO_MOKJUK_GB9() {
		return LK_SAGO_MOKJUK_GB9;
	}
	public void setLK_SAGO_MOKJUK_GB9(String lK_SAGO_MOKJUK_GB9) {
		LK_SAGO_MOKJUK_GB9 = lK_SAGO_MOKJUK_GB9;
	}
	public String getLK_SAGO_MOKJUK_SEQ9() {
		return LK_SAGO_MOKJUK_SEQ9;
	}
	public void setLK_SAGO_MOKJUK_SEQ9(String lK_SAGO_MOKJUK_SEQ9) {
		LK_SAGO_MOKJUK_SEQ9 = lK_SAGO_MOKJUK_SEQ9;
	}
	public String getLK_BJ_NM9() {
		return LK_BJ_NM9;
	}
	public void setLK_BJ_NM9(String lK_BJ_NM9) {
		LK_BJ_NM9 = lK_BJ_NM9;
	}
	public String getLK_PROD_NM9() {
		return LK_PROD_NM9;
	}
	public void setLK_PROD_NM9(String lK_PROD_NM9) {
		LK_PROD_NM9 = lK_PROD_NM9;
	}
	public String getLK_PIHEJA_NAME9() {
		return LK_PIHEJA_NAME9;
	}
	public void setLK_PIHEJA_NAME9(String lK_PIHEJA_NAME9) {
		LK_PIHEJA_NAME9 = lK_PIHEJA_NAME9;
	}
	public String getLK_SAGO_YMDSB9() {
		return LK_SAGO_YMDSB9;
	}
	public void setLK_SAGO_YMDSB9(String lK_SAGO_YMDSB9) {
		LK_SAGO_YMDSB9 = lK_SAGO_YMDSB9;
	}
	public String getLK_SAGO_JUBSU_NO10() {
		return LK_SAGO_JUBSU_NO10;
	}
	public void setLK_SAGO_JUBSU_NO10(String lK_SAGO_JUBSU_NO10) {
		LK_SAGO_JUBSU_NO10 = lK_SAGO_JUBSU_NO10;
	}
	public String getLK_SAGO_MOKJUK_GB10() {
		return LK_SAGO_MOKJUK_GB10;
	}
	public void setLK_SAGO_MOKJUK_GB10(String lK_SAGO_MOKJUK_GB10) {
		LK_SAGO_MOKJUK_GB10 = lK_SAGO_MOKJUK_GB10;
	}
	public String getLK_SAGO_MOKJUK_SEQ10() {
		return LK_SAGO_MOKJUK_SEQ10;
	}
	public void setLK_SAGO_MOKJUK_SEQ10(String lK_SAGO_MOKJUK_SEQ10) {
		LK_SAGO_MOKJUK_SEQ10 = lK_SAGO_MOKJUK_SEQ10;
	}
	public String getLK_BJ_NM10() {
		return LK_BJ_NM10;
	}
	public void setLK_BJ_NM10(String lK_BJ_NM10) {
		LK_BJ_NM10 = lK_BJ_NM10;
	}
	public String getLK_PROD_NM10() {
		return LK_PROD_NM10;
	}
	public void setLK_PROD_NM10(String lK_PROD_NM10) {
		LK_PROD_NM10 = lK_PROD_NM10;
	}
	public String getLK_PIHEJA_NAME10() {
		return LK_PIHEJA_NAME10;
	}
	public void setLK_PIHEJA_NAME10(String lK_PIHEJA_NAME10) {
		LK_PIHEJA_NAME10 = lK_PIHEJA_NAME10;
	}
	public String getLK_SAGO_YMDSB10() {
		return LK_SAGO_YMDSB10;
	}
	public void setLK_SAGO_YMDSB10(String lK_SAGO_YMDSB10) {
		LK_SAGO_YMDSB10 = lK_SAGO_YMDSB10;
	}
	public String getLK_SAGO_JUBSU_NO11() {
		return LK_SAGO_JUBSU_NO11;
	}
	public void setLK_SAGO_JUBSU_NO11(String lK_SAGO_JUBSU_NO11) {
		LK_SAGO_JUBSU_NO11 = lK_SAGO_JUBSU_NO11;
	}
	public String getLK_SAGO_MOKJUK_GB11() {
		return LK_SAGO_MOKJUK_GB11;
	}
	public void setLK_SAGO_MOKJUK_GB11(String lK_SAGO_MOKJUK_GB11) {
		LK_SAGO_MOKJUK_GB11 = lK_SAGO_MOKJUK_GB11;
	}
	public String getLK_SAGO_MOKJUK_SEQ11() {
		return LK_SAGO_MOKJUK_SEQ11;
	}
	public void setLK_SAGO_MOKJUK_SEQ11(String lK_SAGO_MOKJUK_SEQ11) {
		LK_SAGO_MOKJUK_SEQ11 = lK_SAGO_MOKJUK_SEQ11;
	}
	public String getLK_BJ_NM11() {
		return LK_BJ_NM11;
	}
	public void setLK_BJ_NM11(String lK_BJ_NM11) {
		LK_BJ_NM11 = lK_BJ_NM11;
	}
	public String getLK_PROD_NM11() {
		return LK_PROD_NM11;
	}
	public void setLK_PROD_NM11(String lK_PROD_NM11) {
		LK_PROD_NM11 = lK_PROD_NM11;
	}
	public String getLK_PIHEJA_NAME11() {
		return LK_PIHEJA_NAME11;
	}
	public void setLK_PIHEJA_NAME11(String lK_PIHEJA_NAME11) {
		LK_PIHEJA_NAME11 = lK_PIHEJA_NAME11;
	}
	public String getLK_SAGO_YMDSB11() {
		return LK_SAGO_YMDSB11;
	}
	public void setLK_SAGO_YMDSB11(String lK_SAGO_YMDSB11) {
		LK_SAGO_YMDSB11 = lK_SAGO_YMDSB11;
	}
	public String getLK_SAGO_JUBSU_NO12() {
		return LK_SAGO_JUBSU_NO12;
	}
	public void setLK_SAGO_JUBSU_NO12(String lK_SAGO_JUBSU_NO12) {
		LK_SAGO_JUBSU_NO12 = lK_SAGO_JUBSU_NO12;
	}
	public String getLK_SAGO_MOKJUK_GB12() {
		return LK_SAGO_MOKJUK_GB12;
	}
	public void setLK_SAGO_MOKJUK_GB12(String lK_SAGO_MOKJUK_GB12) {
		LK_SAGO_MOKJUK_GB12 = lK_SAGO_MOKJUK_GB12;
	}
	public String getLK_SAGO_MOKJUK_SEQ12() {
		return LK_SAGO_MOKJUK_SEQ12;
	}
	public void setLK_SAGO_MOKJUK_SEQ12(String lK_SAGO_MOKJUK_SEQ12) {
		LK_SAGO_MOKJUK_SEQ12 = lK_SAGO_MOKJUK_SEQ12;
	}
	public String getLK_BJ_NM12() {
		return LK_BJ_NM12;
	}
	public void setLK_BJ_NM12(String lK_BJ_NM12) {
		LK_BJ_NM12 = lK_BJ_NM12;
	}
	public String getLK_PROD_NM12() {
		return LK_PROD_NM12;
	}
	public void setLK_PROD_NM12(String lK_PROD_NM12) {
		LK_PROD_NM12 = lK_PROD_NM12;
	}
	public String getLK_PIHEJA_NAME12() {
		return LK_PIHEJA_NAME12;
	}
	public void setLK_PIHEJA_NAME12(String lK_PIHEJA_NAME12) {
		LK_PIHEJA_NAME12 = lK_PIHEJA_NAME12;
	}
	public String getLK_SAGO_YMDSB12() {
		return LK_SAGO_YMDSB12;
	}
	public void setLK_SAGO_YMDSB12(String lK_SAGO_YMDSB12) {
		LK_SAGO_YMDSB12 = lK_SAGO_YMDSB12;
	}
	public String getLK_SAGO_JUBSU_NO13() {
		return LK_SAGO_JUBSU_NO13;
	}
	public void setLK_SAGO_JUBSU_NO13(String lK_SAGO_JUBSU_NO13) {
		LK_SAGO_JUBSU_NO13 = lK_SAGO_JUBSU_NO13;
	}
	public String getLK_SAGO_MOKJUK_GB13() {
		return LK_SAGO_MOKJUK_GB13;
	}
	public void setLK_SAGO_MOKJUK_GB13(String lK_SAGO_MOKJUK_GB13) {
		LK_SAGO_MOKJUK_GB13 = lK_SAGO_MOKJUK_GB13;
	}
	public String getLK_SAGO_MOKJUK_SEQ13() {
		return LK_SAGO_MOKJUK_SEQ13;
	}
	public void setLK_SAGO_MOKJUK_SEQ13(String lK_SAGO_MOKJUK_SEQ13) {
		LK_SAGO_MOKJUK_SEQ13 = lK_SAGO_MOKJUK_SEQ13;
	}
	public String getLK_BJ_NM13() {
		return LK_BJ_NM13;
	}
	public void setLK_BJ_NM13(String lK_BJ_NM13) {
		LK_BJ_NM13 = lK_BJ_NM13;
	}
	public String getLK_PROD_NM13() {
		return LK_PROD_NM13;
	}
	public void setLK_PROD_NM13(String lK_PROD_NM13) {
		LK_PROD_NM13 = lK_PROD_NM13;
	}
	public String getLK_PIHEJA_NAME13() {
		return LK_PIHEJA_NAME13;
	}
	public void setLK_PIHEJA_NAME13(String lK_PIHEJA_NAME13) {
		LK_PIHEJA_NAME13 = lK_PIHEJA_NAME13;
	}
	public String getLK_SAGO_YMDSB13() {
		return LK_SAGO_YMDSB13;
	}
	public void setLK_SAGO_YMDSB13(String lK_SAGO_YMDSB13) {
		LK_SAGO_YMDSB13 = lK_SAGO_YMDSB13;
	}
	public String getLK_SAGO_JUBSU_NO14() {
		return LK_SAGO_JUBSU_NO14;
	}
	public void setLK_SAGO_JUBSU_NO14(String lK_SAGO_JUBSU_NO14) {
		LK_SAGO_JUBSU_NO14 = lK_SAGO_JUBSU_NO14;
	}
	public String getLK_SAGO_MOKJUK_GB14() {
		return LK_SAGO_MOKJUK_GB14;
	}
	public void setLK_SAGO_MOKJUK_GB14(String lK_SAGO_MOKJUK_GB14) {
		LK_SAGO_MOKJUK_GB14 = lK_SAGO_MOKJUK_GB14;
	}
	public String getLK_SAGO_MOKJUK_SEQ14() {
		return LK_SAGO_MOKJUK_SEQ14;
	}
	public void setLK_SAGO_MOKJUK_SEQ14(String lK_SAGO_MOKJUK_SEQ14) {
		LK_SAGO_MOKJUK_SEQ14 = lK_SAGO_MOKJUK_SEQ14;
	}
	public String getLK_BJ_NM14() {
		return LK_BJ_NM14;
	}
	public void setLK_BJ_NM14(String lK_BJ_NM14) {
		LK_BJ_NM14 = lK_BJ_NM14;
	}
	public String getLK_PROD_NM14() {
		return LK_PROD_NM14;
	}
	public void setLK_PROD_NM14(String lK_PROD_NM14) {
		LK_PROD_NM14 = lK_PROD_NM14;
	}
	public String getLK_PIHEJA_NAME14() {
		return LK_PIHEJA_NAME14;
	}
	public void setLK_PIHEJA_NAME14(String lK_PIHEJA_NAME14) {
		LK_PIHEJA_NAME14 = lK_PIHEJA_NAME14;
	}
	public String getLK_SAGO_YMDSB14() {
		return LK_SAGO_YMDSB14;
	}
	public void setLK_SAGO_YMDSB14(String lK_SAGO_YMDSB14) {
		LK_SAGO_YMDSB14 = lK_SAGO_YMDSB14;
	}
	public String getLK_SAGO_JUBSU_NO15() {
		return LK_SAGO_JUBSU_NO15;
	}
	public void setLK_SAGO_JUBSU_NO15(String lK_SAGO_JUBSU_NO15) {
		LK_SAGO_JUBSU_NO15 = lK_SAGO_JUBSU_NO15;
	}
	public String getLK_SAGO_MOKJUK_GB15() {
		return LK_SAGO_MOKJUK_GB15;
	}
	public void setLK_SAGO_MOKJUK_GB15(String lK_SAGO_MOKJUK_GB15) {
		LK_SAGO_MOKJUK_GB15 = lK_SAGO_MOKJUK_GB15;
	}
	public String getLK_SAGO_MOKJUK_SEQ15() {
		return LK_SAGO_MOKJUK_SEQ15;
	}
	public void setLK_SAGO_MOKJUK_SEQ15(String lK_SAGO_MOKJUK_SEQ15) {
		LK_SAGO_MOKJUK_SEQ15 = lK_SAGO_MOKJUK_SEQ15;
	}
	public String getLK_BJ_NM15() {
		return LK_BJ_NM15;
	}
	public void setLK_BJ_NM15(String lK_BJ_NM15) {
		LK_BJ_NM15 = lK_BJ_NM15;
	}
	public String getLK_PROD_NM15() {
		return LK_PROD_NM15;
	}
	public void setLK_PROD_NM15(String lK_PROD_NM15) {
		LK_PROD_NM15 = lK_PROD_NM15;
	}
	public String getLK_PIHEJA_NAME15() {
		return LK_PIHEJA_NAME15;
	}
	public void setLK_PIHEJA_NAME15(String lK_PIHEJA_NAME15) {
		LK_PIHEJA_NAME15 = lK_PIHEJA_NAME15;
	}
	public String getLK_SAGO_YMDSB15() {
		return LK_SAGO_YMDSB15;
	}
	public void setLK_SAGO_YMDSB15(String lK_SAGO_YMDSB15) {
		LK_SAGO_YMDSB15 = lK_SAGO_YMDSB15;
	}
	public String getLK_SAGO_JUBSU_NO16() {
		return LK_SAGO_JUBSU_NO16;
	}
	public void setLK_SAGO_JUBSU_NO16(String lK_SAGO_JUBSU_NO16) {
		LK_SAGO_JUBSU_NO16 = lK_SAGO_JUBSU_NO16;
	}
	public String getLK_SAGO_MOKJUK_GB16() {
		return LK_SAGO_MOKJUK_GB16;
	}
	public void setLK_SAGO_MOKJUK_GB16(String lK_SAGO_MOKJUK_GB16) {
		LK_SAGO_MOKJUK_GB16 = lK_SAGO_MOKJUK_GB16;
	}
	public String getLK_SAGO_MOKJUK_SEQ16() {
		return LK_SAGO_MOKJUK_SEQ16;
	}
	public void setLK_SAGO_MOKJUK_SEQ16(String lK_SAGO_MOKJUK_SEQ16) {
		LK_SAGO_MOKJUK_SEQ16 = lK_SAGO_MOKJUK_SEQ16;
	}
	public String getLK_BJ_NM16() {
		return LK_BJ_NM16;
	}
	public void setLK_BJ_NM16(String lK_BJ_NM16) {
		LK_BJ_NM16 = lK_BJ_NM16;
	}
	public String getLK_PROD_NM16() {
		return LK_PROD_NM16;
	}
	public void setLK_PROD_NM16(String lK_PROD_NM16) {
		LK_PROD_NM16 = lK_PROD_NM16;
	}
	public String getLK_PIHEJA_NAME16() {
		return LK_PIHEJA_NAME16;
	}
	public void setLK_PIHEJA_NAME16(String lK_PIHEJA_NAME16) {
		LK_PIHEJA_NAME16 = lK_PIHEJA_NAME16;
	}
	public String getLK_SAGO_YMDSB16() {
		return LK_SAGO_YMDSB16;
	}
	public void setLK_SAGO_YMDSB16(String lK_SAGO_YMDSB16) {
		LK_SAGO_YMDSB16 = lK_SAGO_YMDSB16;
	}
	public String getLK_SAGO_JUBSU_NO17() {
		return LK_SAGO_JUBSU_NO17;
	}
	public void setLK_SAGO_JUBSU_NO17(String lK_SAGO_JUBSU_NO17) {
		LK_SAGO_JUBSU_NO17 = lK_SAGO_JUBSU_NO17;
	}
	public String getLK_SAGO_MOKJUK_GB17() {
		return LK_SAGO_MOKJUK_GB17;
	}
	public void setLK_SAGO_MOKJUK_GB17(String lK_SAGO_MOKJUK_GB17) {
		LK_SAGO_MOKJUK_GB17 = lK_SAGO_MOKJUK_GB17;
	}
	public String getLK_SAGO_MOKJUK_SEQ17() {
		return LK_SAGO_MOKJUK_SEQ17;
	}
	public void setLK_SAGO_MOKJUK_SEQ17(String lK_SAGO_MOKJUK_SEQ17) {
		LK_SAGO_MOKJUK_SEQ17 = lK_SAGO_MOKJUK_SEQ17;
	}
	public String getLK_BJ_NM17() {
		return LK_BJ_NM17;
	}
	public void setLK_BJ_NM17(String lK_BJ_NM17) {
		LK_BJ_NM17 = lK_BJ_NM17;
	}
	public String getLK_PROD_NM17() {
		return LK_PROD_NM17;
	}
	public void setLK_PROD_NM17(String lK_PROD_NM17) {
		LK_PROD_NM17 = lK_PROD_NM17;
	}
	public String getLK_PIHEJA_NAME17() {
		return LK_PIHEJA_NAME17;
	}
	public void setLK_PIHEJA_NAME17(String lK_PIHEJA_NAME17) {
		LK_PIHEJA_NAME17 = lK_PIHEJA_NAME17;
	}
	public String getLK_SAGO_YMDSB17() {
		return LK_SAGO_YMDSB17;
	}
	public void setLK_SAGO_YMDSB17(String lK_SAGO_YMDSB17) {
		LK_SAGO_YMDSB17 = lK_SAGO_YMDSB17;
	}
	public String getLK_SAGO_JUBSU_NO18() {
		return LK_SAGO_JUBSU_NO18;
	}
	public void setLK_SAGO_JUBSU_NO18(String lK_SAGO_JUBSU_NO18) {
		LK_SAGO_JUBSU_NO18 = lK_SAGO_JUBSU_NO18;
	}
	public String getLK_SAGO_MOKJUK_GB18() {
		return LK_SAGO_MOKJUK_GB18;
	}
	public void setLK_SAGO_MOKJUK_GB18(String lK_SAGO_MOKJUK_GB18) {
		LK_SAGO_MOKJUK_GB18 = lK_SAGO_MOKJUK_GB18;
	}
	public String getLK_SAGO_MOKJUK_SEQ18() {
		return LK_SAGO_MOKJUK_SEQ18;
	}
	public void setLK_SAGO_MOKJUK_SEQ18(String lK_SAGO_MOKJUK_SEQ18) {
		LK_SAGO_MOKJUK_SEQ18 = lK_SAGO_MOKJUK_SEQ18;
	}
	public String getLK_BJ_NM18() {
		return LK_BJ_NM18;
	}
	public void setLK_BJ_NM18(String lK_BJ_NM18) {
		LK_BJ_NM18 = lK_BJ_NM18;
	}
	public String getLK_PROD_NM18() {
		return LK_PROD_NM18;
	}
	public void setLK_PROD_NM18(String lK_PROD_NM18) {
		LK_PROD_NM18 = lK_PROD_NM18;
	}
	public String getLK_PIHEJA_NAME18() {
		return LK_PIHEJA_NAME18;
	}
	public void setLK_PIHEJA_NAME18(String lK_PIHEJA_NAME18) {
		LK_PIHEJA_NAME18 = lK_PIHEJA_NAME18;
	}
	public String getLK_SAGO_YMDSB18() {
		return LK_SAGO_YMDSB18;
	}
	public void setLK_SAGO_YMDSB18(String lK_SAGO_YMDSB18) {
		LK_SAGO_YMDSB18 = lK_SAGO_YMDSB18;
	}
	public String getLK_SAGO_JUBSU_NO19() {
		return LK_SAGO_JUBSU_NO19;
	}
	public void setLK_SAGO_JUBSU_NO19(String lK_SAGO_JUBSU_NO19) {
		LK_SAGO_JUBSU_NO19 = lK_SAGO_JUBSU_NO19;
	}
	public String getLK_SAGO_MOKJUK_GB19() {
		return LK_SAGO_MOKJUK_GB19;
	}
	public void setLK_SAGO_MOKJUK_GB19(String lK_SAGO_MOKJUK_GB19) {
		LK_SAGO_MOKJUK_GB19 = lK_SAGO_MOKJUK_GB19;
	}
	public String getLK_SAGO_MOKJUK_SEQ19() {
		return LK_SAGO_MOKJUK_SEQ19;
	}
	public void setLK_SAGO_MOKJUK_SEQ19(String lK_SAGO_MOKJUK_SEQ19) {
		LK_SAGO_MOKJUK_SEQ19 = lK_SAGO_MOKJUK_SEQ19;
	}
	public String getLK_BJ_NM19() {
		return LK_BJ_NM19;
	}
	public void setLK_BJ_NM19(String lK_BJ_NM19) {
		LK_BJ_NM19 = lK_BJ_NM19;
	}
	public String getLK_PROD_NM19() {
		return LK_PROD_NM19;
	}
	public void setLK_PROD_NM19(String lK_PROD_NM19) {
		LK_PROD_NM19 = lK_PROD_NM19;
	}
	public String getLK_PIHEJA_NAME19() {
		return LK_PIHEJA_NAME19;
	}
	public void setLK_PIHEJA_NAME19(String lK_PIHEJA_NAME19) {
		LK_PIHEJA_NAME19 = lK_PIHEJA_NAME19;
	}
	public String getLK_SAGO_YMDSB19() {
		return LK_SAGO_YMDSB19;
	}
	public void setLK_SAGO_YMDSB19(String lK_SAGO_YMDSB19) {
		LK_SAGO_YMDSB19 = lK_SAGO_YMDSB19;
	}
	public String getLK_SAGO_JUBSU_NO20() {
		return LK_SAGO_JUBSU_NO20;
	}
	public void setLK_SAGO_JUBSU_NO20(String lK_SAGO_JUBSU_NO20) {
		LK_SAGO_JUBSU_NO20 = lK_SAGO_JUBSU_NO20;
	}
	public String getLK_SAGO_MOKJUK_GB20() {
		return LK_SAGO_MOKJUK_GB20;
	}
	public void setLK_SAGO_MOKJUK_GB20(String lK_SAGO_MOKJUK_GB20) {
		LK_SAGO_MOKJUK_GB20 = lK_SAGO_MOKJUK_GB20;
	}
	public String getLK_SAGO_MOKJUK_SEQ20() {
		return LK_SAGO_MOKJUK_SEQ20;
	}
	public void setLK_SAGO_MOKJUK_SEQ20(String lK_SAGO_MOKJUK_SEQ20) {
		LK_SAGO_MOKJUK_SEQ20 = lK_SAGO_MOKJUK_SEQ20;
	}
	public String getLK_BJ_NM20() {
		return LK_BJ_NM20;
	}
	public void setLK_BJ_NM20(String lK_BJ_NM20) {
		LK_BJ_NM20 = lK_BJ_NM20;
	}
	public String getLK_PROD_NM20() {
		return LK_PROD_NM20;
	}
	public void setLK_PROD_NM20(String lK_PROD_NM20) {
		LK_PROD_NM20 = lK_PROD_NM20;
	}
	public String getLK_PIHEJA_NAME20() {
		return LK_PIHEJA_NAME20;
	}
	public void setLK_PIHEJA_NAME20(String lK_PIHEJA_NAME20) {
		LK_PIHEJA_NAME20 = lK_PIHEJA_NAME20;
	}
	public String getLK_SAGO_YMDSB20() {
		return LK_SAGO_YMDSB20;
	}
	public void setLK_SAGO_YMDSB20(String lK_SAGO_YMDSB20) {
		LK_SAGO_YMDSB20 = lK_SAGO_YMDSB20;
	}
	public String getLK_SAGO_JUBSU_NO21() {
		return LK_SAGO_JUBSU_NO21;
	}
	public void setLK_SAGO_JUBSU_NO21(String lK_SAGO_JUBSU_NO21) {
		LK_SAGO_JUBSU_NO21 = lK_SAGO_JUBSU_NO21;
	}
	public String getLK_SAGO_MOKJUK_GB21() {
		return LK_SAGO_MOKJUK_GB21;
	}
	public void setLK_SAGO_MOKJUK_GB21(String lK_SAGO_MOKJUK_GB21) {
		LK_SAGO_MOKJUK_GB21 = lK_SAGO_MOKJUK_GB21;
	}
	public String getLK_SAGO_MOKJUK_SEQ21() {
		return LK_SAGO_MOKJUK_SEQ21;
	}
	public void setLK_SAGO_MOKJUK_SEQ21(String lK_SAGO_MOKJUK_SEQ21) {
		LK_SAGO_MOKJUK_SEQ21 = lK_SAGO_MOKJUK_SEQ21;
	}
	public String getLK_BJ_NM21() {
		return LK_BJ_NM21;
	}
	public void setLK_BJ_NM21(String lK_BJ_NM21) {
		LK_BJ_NM21 = lK_BJ_NM21;
	}
	public String getLK_PROD_NM21() {
		return LK_PROD_NM21;
	}
	public void setLK_PROD_NM21(String lK_PROD_NM21) {
		LK_PROD_NM21 = lK_PROD_NM21;
	}
	public String getLK_PIHEJA_NAME21() {
		return LK_PIHEJA_NAME21;
	}
	public void setLK_PIHEJA_NAME21(String lK_PIHEJA_NAME21) {
		LK_PIHEJA_NAME21 = lK_PIHEJA_NAME21;
	}
	public String getLK_SAGO_YMDSB21() {
		return LK_SAGO_YMDSB21;
	}
	public void setLK_SAGO_YMDSB21(String lK_SAGO_YMDSB21) {
		LK_SAGO_YMDSB21 = lK_SAGO_YMDSB21;
	}
	public String getLK_SAGO_JUBSU_NO22() {
		return LK_SAGO_JUBSU_NO22;
	}
	public void setLK_SAGO_JUBSU_NO22(String lK_SAGO_JUBSU_NO22) {
		LK_SAGO_JUBSU_NO22 = lK_SAGO_JUBSU_NO22;
	}
	public String getLK_SAGO_MOKJUK_GB22() {
		return LK_SAGO_MOKJUK_GB22;
	}
	public void setLK_SAGO_MOKJUK_GB22(String lK_SAGO_MOKJUK_GB22) {
		LK_SAGO_MOKJUK_GB22 = lK_SAGO_MOKJUK_GB22;
	}
	public String getLK_SAGO_MOKJUK_SEQ22() {
		return LK_SAGO_MOKJUK_SEQ22;
	}
	public void setLK_SAGO_MOKJUK_SEQ22(String lK_SAGO_MOKJUK_SEQ22) {
		LK_SAGO_MOKJUK_SEQ22 = lK_SAGO_MOKJUK_SEQ22;
	}
	public String getLK_BJ_NM22() {
		return LK_BJ_NM22;
	}
	public void setLK_BJ_NM22(String lK_BJ_NM22) {
		LK_BJ_NM22 = lK_BJ_NM22;
	}
	public String getLK_PROD_NM22() {
		return LK_PROD_NM22;
	}
	public void setLK_PROD_NM22(String lK_PROD_NM22) {
		LK_PROD_NM22 = lK_PROD_NM22;
	}
	public String getLK_PIHEJA_NAME22() {
		return LK_PIHEJA_NAME22;
	}
	public void setLK_PIHEJA_NAME22(String lK_PIHEJA_NAME22) {
		LK_PIHEJA_NAME22 = lK_PIHEJA_NAME22;
	}
	public String getLK_SAGO_YMDSB22() {
		return LK_SAGO_YMDSB22;
	}
	public void setLK_SAGO_YMDSB22(String lK_SAGO_YMDSB22) {
		LK_SAGO_YMDSB22 = lK_SAGO_YMDSB22;
	}
	public String getLK_SAGO_JUBSU_NO23() {
		return LK_SAGO_JUBSU_NO23;
	}
	public void setLK_SAGO_JUBSU_NO23(String lK_SAGO_JUBSU_NO23) {
		LK_SAGO_JUBSU_NO23 = lK_SAGO_JUBSU_NO23;
	}
	public String getLK_SAGO_MOKJUK_GB23() {
		return LK_SAGO_MOKJUK_GB23;
	}
	public void setLK_SAGO_MOKJUK_GB23(String lK_SAGO_MOKJUK_GB23) {
		LK_SAGO_MOKJUK_GB23 = lK_SAGO_MOKJUK_GB23;
	}
	public String getLK_SAGO_MOKJUK_SEQ23() {
		return LK_SAGO_MOKJUK_SEQ23;
	}
	public void setLK_SAGO_MOKJUK_SEQ23(String lK_SAGO_MOKJUK_SEQ23) {
		LK_SAGO_MOKJUK_SEQ23 = lK_SAGO_MOKJUK_SEQ23;
	}
	public String getLK_BJ_NM23() {
		return LK_BJ_NM23;
	}
	public void setLK_BJ_NM23(String lK_BJ_NM23) {
		LK_BJ_NM23 = lK_BJ_NM23;
	}
	public String getLK_PROD_NM23() {
		return LK_PROD_NM23;
	}
	public void setLK_PROD_NM23(String lK_PROD_NM23) {
		LK_PROD_NM23 = lK_PROD_NM23;
	}
	public String getLK_PIHEJA_NAME23() {
		return LK_PIHEJA_NAME23;
	}
	public void setLK_PIHEJA_NAME23(String lK_PIHEJA_NAME23) {
		LK_PIHEJA_NAME23 = lK_PIHEJA_NAME23;
	}
	public String getLK_SAGO_YMDSB23() {
		return LK_SAGO_YMDSB23;
	}
	public void setLK_SAGO_YMDSB23(String lK_SAGO_YMDSB23) {
		LK_SAGO_YMDSB23 = lK_SAGO_YMDSB23;
	}
	public String getLK_SAGO_JUBSU_NO24() {
		return LK_SAGO_JUBSU_NO24;
	}
	public void setLK_SAGO_JUBSU_NO24(String lK_SAGO_JUBSU_NO24) {
		LK_SAGO_JUBSU_NO24 = lK_SAGO_JUBSU_NO24;
	}
	public String getLK_SAGO_MOKJUK_GB24() {
		return LK_SAGO_MOKJUK_GB24;
	}
	public void setLK_SAGO_MOKJUK_GB24(String lK_SAGO_MOKJUK_GB24) {
		LK_SAGO_MOKJUK_GB24 = lK_SAGO_MOKJUK_GB24;
	}
	public String getLK_SAGO_MOKJUK_SEQ24() {
		return LK_SAGO_MOKJUK_SEQ24;
	}
	public void setLK_SAGO_MOKJUK_SEQ24(String lK_SAGO_MOKJUK_SEQ24) {
		LK_SAGO_MOKJUK_SEQ24 = lK_SAGO_MOKJUK_SEQ24;
	}
	public String getLK_BJ_NM24() {
		return LK_BJ_NM24;
	}
	public void setLK_BJ_NM24(String lK_BJ_NM24) {
		LK_BJ_NM24 = lK_BJ_NM24;
	}
	public String getLK_PROD_NM24() {
		return LK_PROD_NM24;
	}
	public void setLK_PROD_NM24(String lK_PROD_NM24) {
		LK_PROD_NM24 = lK_PROD_NM24;
	}
	public String getLK_PIHEJA_NAME24() {
		return LK_PIHEJA_NAME24;
	}
	public void setLK_PIHEJA_NAME24(String lK_PIHEJA_NAME24) {
		LK_PIHEJA_NAME24 = lK_PIHEJA_NAME24;
	}
	public String getLK_SAGO_YMDSB24() {
		return LK_SAGO_YMDSB24;
	}
	public void setLK_SAGO_YMDSB24(String lK_SAGO_YMDSB24) {
		LK_SAGO_YMDSB24 = lK_SAGO_YMDSB24;
	}
	public String getLK_SAGO_JUBSU_NO25() {
		return LK_SAGO_JUBSU_NO25;
	}
	public void setLK_SAGO_JUBSU_NO25(String lK_SAGO_JUBSU_NO25) {
		LK_SAGO_JUBSU_NO25 = lK_SAGO_JUBSU_NO25;
	}
	public String getLK_SAGO_MOKJUK_GB25() {
		return LK_SAGO_MOKJUK_GB25;
	}
	public void setLK_SAGO_MOKJUK_GB25(String lK_SAGO_MOKJUK_GB25) {
		LK_SAGO_MOKJUK_GB25 = lK_SAGO_MOKJUK_GB25;
	}
	public String getLK_SAGO_MOKJUK_SEQ25() {
		return LK_SAGO_MOKJUK_SEQ25;
	}
	public void setLK_SAGO_MOKJUK_SEQ25(String lK_SAGO_MOKJUK_SEQ25) {
		LK_SAGO_MOKJUK_SEQ25 = lK_SAGO_MOKJUK_SEQ25;
	}
	public String getLK_BJ_NM25() {
		return LK_BJ_NM25;
	}
	public void setLK_BJ_NM25(String lK_BJ_NM25) {
		LK_BJ_NM25 = lK_BJ_NM25;
	}
	public String getLK_PROD_NM25() {
		return LK_PROD_NM25;
	}
	public void setLK_PROD_NM25(String lK_PROD_NM25) {
		LK_PROD_NM25 = lK_PROD_NM25;
	}
	public String getLK_PIHEJA_NAME25() {
		return LK_PIHEJA_NAME25;
	}
	public void setLK_PIHEJA_NAME25(String lK_PIHEJA_NAME25) {
		LK_PIHEJA_NAME25 = lK_PIHEJA_NAME25;
	}
	public String getLK_SAGO_YMDSB25() {
		return LK_SAGO_YMDSB25;
	}
	public void setLK_SAGO_YMDSB25(String lK_SAGO_YMDSB25) {
		LK_SAGO_YMDSB25 = lK_SAGO_YMDSB25;
	}
	public String getLK_SAGO_JUBSU_NO26() {
		return LK_SAGO_JUBSU_NO26;
	}
	public void setLK_SAGO_JUBSU_NO26(String lK_SAGO_JUBSU_NO26) {
		LK_SAGO_JUBSU_NO26 = lK_SAGO_JUBSU_NO26;
	}
	public String getLK_SAGO_MOKJUK_GB26() {
		return LK_SAGO_MOKJUK_GB26;
	}
	public void setLK_SAGO_MOKJUK_GB26(String lK_SAGO_MOKJUK_GB26) {
		LK_SAGO_MOKJUK_GB26 = lK_SAGO_MOKJUK_GB26;
	}
	public String getLK_SAGO_MOKJUK_SEQ26() {
		return LK_SAGO_MOKJUK_SEQ26;
	}
	public void setLK_SAGO_MOKJUK_SEQ26(String lK_SAGO_MOKJUK_SEQ26) {
		LK_SAGO_MOKJUK_SEQ26 = lK_SAGO_MOKJUK_SEQ26;
	}
	public String getLK_BJ_NM26() {
		return LK_BJ_NM26;
	}
	public void setLK_BJ_NM26(String lK_BJ_NM26) {
		LK_BJ_NM26 = lK_BJ_NM26;
	}
	public String getLK_PROD_NM26() {
		return LK_PROD_NM26;
	}
	public void setLK_PROD_NM26(String lK_PROD_NM26) {
		LK_PROD_NM26 = lK_PROD_NM26;
	}
	public String getLK_PIHEJA_NAME26() {
		return LK_PIHEJA_NAME26;
	}
	public void setLK_PIHEJA_NAME26(String lK_PIHEJA_NAME26) {
		LK_PIHEJA_NAME26 = lK_PIHEJA_NAME26;
	}
	public String getLK_SAGO_YMDSB26() {
		return LK_SAGO_YMDSB26;
	}
	public void setLK_SAGO_YMDSB26(String lK_SAGO_YMDSB26) {
		LK_SAGO_YMDSB26 = lK_SAGO_YMDSB26;
	}
	public String getLK_SAGO_JUBSU_NO27() {
		return LK_SAGO_JUBSU_NO27;
	}
	public void setLK_SAGO_JUBSU_NO27(String lK_SAGO_JUBSU_NO27) {
		LK_SAGO_JUBSU_NO27 = lK_SAGO_JUBSU_NO27;
	}
	public String getLK_SAGO_MOKJUK_GB27() {
		return LK_SAGO_MOKJUK_GB27;
	}
	public void setLK_SAGO_MOKJUK_GB27(String lK_SAGO_MOKJUK_GB27) {
		LK_SAGO_MOKJUK_GB27 = lK_SAGO_MOKJUK_GB27;
	}
	public String getLK_SAGO_MOKJUK_SEQ27() {
		return LK_SAGO_MOKJUK_SEQ27;
	}
	public void setLK_SAGO_MOKJUK_SEQ27(String lK_SAGO_MOKJUK_SEQ27) {
		LK_SAGO_MOKJUK_SEQ27 = lK_SAGO_MOKJUK_SEQ27;
	}
	public String getLK_BJ_NM27() {
		return LK_BJ_NM27;
	}
	public void setLK_BJ_NM27(String lK_BJ_NM27) {
		LK_BJ_NM27 = lK_BJ_NM27;
	}
	public String getLK_PROD_NM27() {
		return LK_PROD_NM27;
	}
	public void setLK_PROD_NM27(String lK_PROD_NM27) {
		LK_PROD_NM27 = lK_PROD_NM27;
	}
	public String getLK_PIHEJA_NAME27() {
		return LK_PIHEJA_NAME27;
	}
	public void setLK_PIHEJA_NAME27(String lK_PIHEJA_NAME27) {
		LK_PIHEJA_NAME27 = lK_PIHEJA_NAME27;
	}
	public String getLK_SAGO_YMDSB27() {
		return LK_SAGO_YMDSB27;
	}
	public void setLK_SAGO_YMDSB27(String lK_SAGO_YMDSB27) {
		LK_SAGO_YMDSB27 = lK_SAGO_YMDSB27;
	}
	public String getLK_SAGO_JUBSU_NO28() {
		return LK_SAGO_JUBSU_NO28;
	}
	public void setLK_SAGO_JUBSU_NO28(String lK_SAGO_JUBSU_NO28) {
		LK_SAGO_JUBSU_NO28 = lK_SAGO_JUBSU_NO28;
	}
	public String getLK_SAGO_MOKJUK_GB28() {
		return LK_SAGO_MOKJUK_GB28;
	}
	public void setLK_SAGO_MOKJUK_GB28(String lK_SAGO_MOKJUK_GB28) {
		LK_SAGO_MOKJUK_GB28 = lK_SAGO_MOKJUK_GB28;
	}
	public String getLK_SAGO_MOKJUK_SEQ28() {
		return LK_SAGO_MOKJUK_SEQ28;
	}
	public void setLK_SAGO_MOKJUK_SEQ28(String lK_SAGO_MOKJUK_SEQ28) {
		LK_SAGO_MOKJUK_SEQ28 = lK_SAGO_MOKJUK_SEQ28;
	}
	public String getLK_BJ_NM28() {
		return LK_BJ_NM28;
	}
	public void setLK_BJ_NM28(String lK_BJ_NM28) {
		LK_BJ_NM28 = lK_BJ_NM28;
	}
	public String getLK_PROD_NM28() {
		return LK_PROD_NM28;
	}
	public void setLK_PROD_NM28(String lK_PROD_NM28) {
		LK_PROD_NM28 = lK_PROD_NM28;
	}
	public String getLK_PIHEJA_NAME28() {
		return LK_PIHEJA_NAME28;
	}
	public void setLK_PIHEJA_NAME28(String lK_PIHEJA_NAME28) {
		LK_PIHEJA_NAME28 = lK_PIHEJA_NAME28;
	}
	public String getLK_SAGO_YMDSB28() {
		return LK_SAGO_YMDSB28;
	}
	public void setLK_SAGO_YMDSB28(String lK_SAGO_YMDSB28) {
		LK_SAGO_YMDSB28 = lK_SAGO_YMDSB28;
	}
	public String getLK_SAGO_JUBSU_NO29() {
		return LK_SAGO_JUBSU_NO29;
	}
	public void setLK_SAGO_JUBSU_NO29(String lK_SAGO_JUBSU_NO29) {
		LK_SAGO_JUBSU_NO29 = lK_SAGO_JUBSU_NO29;
	}
	public String getLK_SAGO_MOKJUK_GB29() {
		return LK_SAGO_MOKJUK_GB29;
	}
	public void setLK_SAGO_MOKJUK_GB29(String lK_SAGO_MOKJUK_GB29) {
		LK_SAGO_MOKJUK_GB29 = lK_SAGO_MOKJUK_GB29;
	}
	public String getLK_SAGO_MOKJUK_SEQ29() {
		return LK_SAGO_MOKJUK_SEQ29;
	}
	public void setLK_SAGO_MOKJUK_SEQ29(String lK_SAGO_MOKJUK_SEQ29) {
		LK_SAGO_MOKJUK_SEQ29 = lK_SAGO_MOKJUK_SEQ29;
	}
	public String getLK_BJ_NM29() {
		return LK_BJ_NM29;
	}
	public void setLK_BJ_NM29(String lK_BJ_NM29) {
		LK_BJ_NM29 = lK_BJ_NM29;
	}
	public String getLK_PROD_NM29() {
		return LK_PROD_NM29;
	}
	public void setLK_PROD_NM29(String lK_PROD_NM29) {
		LK_PROD_NM29 = lK_PROD_NM29;
	}
	public String getLK_PIHEJA_NAME29() {
		return LK_PIHEJA_NAME29;
	}
	public void setLK_PIHEJA_NAME29(String lK_PIHEJA_NAME29) {
		LK_PIHEJA_NAME29 = lK_PIHEJA_NAME29;
	}
	public String getLK_SAGO_YMDSB29() {
		return LK_SAGO_YMDSB29;
	}
	public void setLK_SAGO_YMDSB29(String lK_SAGO_YMDSB29) {
		LK_SAGO_YMDSB29 = lK_SAGO_YMDSB29;
	}
	public String getLK_SAGO_JUBSU_NO30() {
		return LK_SAGO_JUBSU_NO30;
	}
	public void setLK_SAGO_JUBSU_NO30(String lK_SAGO_JUBSU_NO30) {
		LK_SAGO_JUBSU_NO30 = lK_SAGO_JUBSU_NO30;
	}
	public String getLK_SAGO_MOKJUK_GB30() {
		return LK_SAGO_MOKJUK_GB30;
	}
	public void setLK_SAGO_MOKJUK_GB30(String lK_SAGO_MOKJUK_GB30) {
		LK_SAGO_MOKJUK_GB30 = lK_SAGO_MOKJUK_GB30;
	}
	public String getLK_SAGO_MOKJUK_SEQ30() {
		return LK_SAGO_MOKJUK_SEQ30;
	}
	public void setLK_SAGO_MOKJUK_SEQ30(String lK_SAGO_MOKJUK_SEQ30) {
		LK_SAGO_MOKJUK_SEQ30 = lK_SAGO_MOKJUK_SEQ30;
	}
	public String getLK_BJ_NM30() {
		return LK_BJ_NM30;
	}
	public void setLK_BJ_NM30(String lK_BJ_NM30) {
		LK_BJ_NM30 = lK_BJ_NM30;
	}
	public String getLK_PROD_NM30() {
		return LK_PROD_NM30;
	}
	public void setLK_PROD_NM30(String lK_PROD_NM30) {
		LK_PROD_NM30 = lK_PROD_NM30;
	}
	public String getLK_PIHEJA_NAME30() {
		return LK_PIHEJA_NAME30;
	}
	public void setLK_PIHEJA_NAME30(String lK_PIHEJA_NAME30) {
		LK_PIHEJA_NAME30 = lK_PIHEJA_NAME30;
	}
	public String getLK_SAGO_YMDSB30() {
		return LK_SAGO_YMDSB30;
	}
	public void setLK_SAGO_YMDSB30(String lK_SAGO_YMDSB30) {
		LK_SAGO_YMDSB30 = lK_SAGO_YMDSB30;
	}
	public String getFILLER() {
		return FILLER;
	}
	public void setFILLER(String fILLER) {
		FILLER = fILLER;
	}
	public static String getProid() {
		return proid;
	}
	public static String getTrid() {
		return trid;
	}

}
