package com.idongbu.smartcustomer.vo;

import java.util.List;
import java.util.Map;

import com.idongbu.common.vo.CMMVO;

public class CmmFRH5002RVO extends CMMVO {

	public CmmFRH5002RVO() {
		super.setPGMID(this.proid);
		super.setTRID(this.trid);
	}		
	
	private static final String proid     = "FRH5002R";
	private static final String trid      = "RHK1";
	private String rURL				      = "";
                                          
	private String CC_CHANNEL		      = "";
	private String CC_UKEY		          = "";
	private String CC_PGMID		          = "";
	private String CC_PROC_GB		      = "";
	private String CC_FUN_KEY		      = "";
	private String CC_USER_GB		      = "";
	private String CC_USER_CD		      = "";
	private String CC_JIJUM_CD		      = "";
	private String CC_JIBU_CD		      = "";
	private String CC_PROTOCOL		      = "";
	private String CC_COND_CD		      = "";
	private String CC_LAST_FLAG		      = "";
	private String CC_CURSOR_MAP          = "";
	private String CC_CURSOR_IDX          = "";
	private String CC_MESSAGE_CD          = "";
	private String HC_MESSAGE_NM          = "";
	private String CC_SYS_ERR		      = "";
	private String CC_FILLER		      = "";
	private String SS_JOGUN		          = "";
	private String SS_JOGUN_NO		      = "";
	private String SS_SAGO_JUBSU_NO       = "";
	private String SS_SAGO_JUBSU_SEQ	  = "";
	private String SS_SAGO_MOKJUK_GB	  = "";
	private String SS_SAGO_MOKJUK_SEQ     = "";
	private String SS_DB_YN		          = "";
	private String SS_GF		          = "";
	private String SS_SAGO_DAMBO	      = "";
	private String SS_PIHE_GWANGE	      = "";
	private String HS_PIHE_GWANGE	      = "";
	private String SS_PIHE_JUMIN	      = "";
	private String HS_PIHE_NM		      = "";
	private String SS_PIHE_TEL		      = "";
	private String SS_BUSANG_BUWI_CD      = "";
	private String SS_SONHE_CD1		      = "";
	private String SS_SONHE_CD2		      = "";
	private String SS_GOLJUL_CD		      = "";
	private String SS_SUSUL_CD		      = "";
	private String SS_SONHEAK_GB	      = "";
	private String SS_IPWON_YMD		      = "";
	private String HS_SOYUJA_NM		      = "";
	private String SS_GURECHU_CD1	      = "";
	private String SS_GURECHU_CD2	      = "";
	private String HS_GURECHU_NM	      = "";
	private String SS_GURECHU_ZIP	      = "";
	private String HS_GURECHU_GITA	      = "";
	private String SS_GURECHU_TEL	      = "";
	private String SS_GURECHU_GBSU	      = "";
	private String SS_CENTER		      = "";
	private String SS_TEAM		          = "";
	private String SS_DAMDANGJA		      = "";
	private String HS_DAMDANGJA		      = "";
	private String SS_DAMDANGJA_TEL	      = "";
	private String SS_J_CENTER		      = "";
	private String SS_J_TEAM		      = "";
	private String SS_J_DAMDANGJA         = "";
	private String HS_J_DAMDANGJA         = "";
	private String SS_J_DAMDANGJA_TE      = "";
	private String SS_CAR_DAM_YN          = "";
	private String SS_SOAK_YN	          = "";
	private String SS_BANK_CD	          = "";
	private String SS_GYEJWA_NO	          = "";
	private String SS_GYEJWA_YN	          = "";
	private String SS_GANG_BAE_YN         = "";
	private String SS_JINRYO_GWAMOK       = "";
	
	private String SS_SERYU_YMD		      = "";
	private String SS_SONSA		          = "";
	private String HS_SONSA		          = "";
	private String SS_H_CNT		          = "";
	private String SS_H_PAGE		      = "";
	private String SS_H_T_PAGE		      = "";
//	private String[] SS_B_DB_YN		      = new String[0]; // 10
//	private String[] SS_B_GF		      = new String[0]; // 10
//	private String[] HS_B_GF		      = new String[0]; // 10
//	private String[] SS_B_MOKJUK_GB	      = new String[0]; // 10
//	private String[] SS_B_MOKJUK_SEQ      = new String[0]; // 10
//	private String[] SS_B_SAGO_DAMBO      = new String[0]; // 10
//	private String[] HS_B_SAGO_DAMBO      = new String[0]; // 10
//	private String[] SS_B_PIHE_GWANGE     = new String[0]; // 10
//	private String[] HS_B_PIHE_GWANGE     = new String[0]; // 10
//	private String[] SS_B_PIHE_JUMIN      = new String[0]; // 10
//	private String[] HS_B_PIHE_NM	      = new String[0]; // 10
//	private String[] SS_B_PIHE_TEL	      = new String[0]; // 10
//	private String[] SS_B_BUSANG_BUWI_CD  = new String[0]; // 10
//	private String[] HS_B_BUSANG_BUWI_NM  = new String[0]; // 10
//	private String[] SS_B_SONHE_CD1		  = new String[0]; // 10
//	private String[] HS_B_SONHE_CD1		  = new String[0]; // 10
//	private String[] SS_B_SONHE_CD2		  = new String[0]; // 10
//	private String[] HS_B_SONHE_CD2		  = new String[0]; // 10
//	private String[] SS_B_GOLJUL_CD		  = new String[0]; // 10
//	private String[] SS_B_SUSUL_CD		  = new String[0]; // 10
//	private String[] SS_B_SONHEAK_GB	  = new String[0]; // 10
//	private String[] SS_B_IPWON_YMD		  = new String[0]; // 10
//	private String[] HS_B_SOYUJA_NM		  = new String[0]; // 10
//	private String[] SS_B_GURECHU_CD1	  = new String[0]; // 10
//	private String[] SS_B_GURECHU_CD2	  = new String[0]; // 10
//	private String[] HS_B_GURECHU_NM	  = new String[0]; // 10
//	private String[] SS_B_GURECHU_ZIP	  = new String[0]; // 10
//	private String[] HS_B_GURECHU_GITA	  = new String[0]; // 10
//	private String[] SS_B_GURECHU_TEL	  = new String[0]; // 10
//	private String[] SS_B_GURECHU_GBSU	  = new String[0]; // 10
//	private String[] SS_B_CENTER		  = new String[0]; // 10
//	private String[] SS_B_TEAM		      = new String[0]; // 10
//	private String[] SS_B_DAMDANGJA		  = new String[0]; // 10
//	private String[] HS_B_DAMDANGJA		  = new String[0]; // 10
//	private String[] SS_B_DAMDANGJA_TEL	  = new String[0]; // 10
//	private String[] SS_B_J_CENTER		  = new String[0]; // 10
//	private String[] SS_B_J_TEAM		  = new String[0]; // 10
//	private String[] SS_B_J_DAMDANGJA	  = new String[0]; // 10
//	private String[] HS_B_J_DAMDANGJA	  = new String[0]; // 10
//	private String[] SS_B_J_DAMDANGJA_TEL = new String[0]; // 10
//	private String[] SS_B_SERYU_SUSIN	  = new String[0]; // 10
//	private String[] SS_B_SERYU_YMD		  = new String[0]; // 10
//	private String[] SS_B_SONSA		      = new String[0]; // 10
//	private String[] HS_B_SONSA		      = new String[0]; // 10
	private List<Map<String, String>> LOOP_DATA = null;
	private String UUC_INQ_MOKJUK_GB	  = "";
	private String UUC_INQ_MOKJUK_SEQ	  = "";
	private String UUC_F_MOKJUK_GB		  = "";
	private String UUC_F_MOKJUK_SEQ		  = "";
	private String UUC_L_MOKJUK_GB		  = "";
	private String UUC_L_MOKJUK_SEQ		  = "";
	private String BB_ST_PATH		      = "";
	private String BB_TERM_ID		      = "";
	private String BB_MAP_ID		      = "";
	private String BB_JOGUN		          = "";
	private String BB_JOGUN_NO		      = "";
	private String BB_SAGO_JUBSU_NO		  = "";
	private String BB_SAGO_JUBSU_SEQ	  = "";
	private String BB_SAGO_MOKJUK_GB	  = "";
	private String BB_SAGO_MOKJUK_SEQ	  = "";
	private String BB_LAST_JUBSU_SEQ	  = "";
	private String BB_LAST_MOKJUK_SEQ	  = "";
	private String BB_INMUL		          = "";
	private String BB_IN_CNT		      = "";
	private String BB_JAEMUL_CNT	      = "";
	private String BB_DEIN_CNT		      = "";
	private String BB_DAEMUL_CNT	      = "";
	private String BB_GOGEK_GB		      = "";
	private String BB_GOGEK_NO		      = "";
	private String HB_GOGEK_NM		      = "";
	private String BB_GOGEK_TEL		      = "";
	private String BB_SAGO_DAMBO		  = "";
	private String BB_JUBSU_UPMU1		  = "";
	private String BB_JUBSU_UPMU2		  = "";
	private String BB_JUBSU_UPMU3		  = "";
	private String BB_SAGO_YMD		      = "";
	private String BB_SAGO_HM		      = "";
	private String BB_TYPE_CD		      = "";
	private String BB_WONIN_CD		      = "";
	private String BB_UNHENG_CD1		  = "";
	private String BB_UNHENG_CD2		  = "";
	private String BB_SAGO_ZIP		      = "";
	private String BB_N_SAGO_ZIP	      = "";
	private String BB_WALRYO_YN		      = "";
	private String BB_JUBSU_CENTER	      = "";
	private String BB_JUBSUJA		      = "";
	private String BB_MIWHAKIN_CD		  = "";
	private String BB_YUNGUP_CHONG		  = "";
	private String BB_SERYU_CD			  = "";
	private String BB_GF_GB		          = "";
	private String BB_DAMDANGJA		      = "";
	private String BB_SAGO_JANGSO_GB      = "";
	private String BB_SUN_JUBSU		      = "";
	                                      
	private String BB_SAGO_YMDHM          = "";
	
	private String SS_J_DAMDANGJA_TEL     = "";
	private String SS_GIJIGP_BANK_CD      = "";
	private String SS_GIJIGP_GYEJWA_NO    = "";
	private String SS_JADONG_BANK_CD      = "";
	private String SS_JADONG_GYEJWA_NO    = "";
	private String BB_SOAK_YN             = "";
	private String BB_BANK_CD             = "";
	private String BB_GYEJWA_NO           = "";
	private String BB_GYEJWA_YN		      = "";

	public String getrURL() {
		return rURL;
	}

	public void setrURL(String rURL) {
		this.rURL = rURL;
	}

	public String getCC_CHANNEL() {
		return CC_CHANNEL;
	}

	public void setCC_CHANNEL(String cC_CHANNEL) {
		CC_CHANNEL = cC_CHANNEL;
	}

	public String getCC_UKEY() {
		return CC_UKEY;
	}

	public void setCC_UKEY(String cC_UKEY) {
		CC_UKEY = cC_UKEY;
	}

	public String getCC_PGMID() {
		return CC_PGMID;
	}

	public void setCC_PGMID(String cC_PGMID) {
		CC_PGMID = cC_PGMID;
	}

	public String getCC_PROC_GB() {
		return CC_PROC_GB;
	}

	public void setCC_PROC_GB(String cC_PROC_GB) {
		CC_PROC_GB = cC_PROC_GB;
	}

	public String getCC_FUN_KEY() {
		return CC_FUN_KEY;
	}

	public void setCC_FUN_KEY(String cC_FUN_KEY) {
		CC_FUN_KEY = cC_FUN_KEY;
	}

	public String getCC_USER_GB() {
		return CC_USER_GB;
	}

	public void setCC_USER_GB(String cC_USER_GB) {
		CC_USER_GB = cC_USER_GB;
	}

	public String getCC_USER_CD() {
		return CC_USER_CD;
	}

	public void setCC_USER_CD(String cC_USER_CD) {
		CC_USER_CD = cC_USER_CD;
	}

	public String getCC_JIJUM_CD() {
		return CC_JIJUM_CD;
	}

	public void setCC_JIJUM_CD(String cC_JIJUM_CD) {
		CC_JIJUM_CD = cC_JIJUM_CD;
	}

	public String getCC_JIBU_CD() {
		return CC_JIBU_CD;
	}

	public void setCC_JIBU_CD(String cC_JIBU_CD) {
		CC_JIBU_CD = cC_JIBU_CD;
	}

	public String getCC_PROTOCOL() {
		return CC_PROTOCOL;
	}

	public void setCC_PROTOCOL(String cC_PROTOCOL) {
		CC_PROTOCOL = cC_PROTOCOL;
	}

	public String getCC_COND_CD() {
		return CC_COND_CD;
	}

	public void setCC_COND_CD(String cC_COND_CD) {
		CC_COND_CD = cC_COND_CD;
	}

	public String getCC_LAST_FLAG() {
		return CC_LAST_FLAG;
	}

	public void setCC_LAST_FLAG(String cC_LAST_FLAG) {
		CC_LAST_FLAG = cC_LAST_FLAG;
	}

	public String getCC_CURSOR_MAP() {
		return CC_CURSOR_MAP;
	}

	public void setCC_CURSOR_MAP(String cC_CURSOR_MAP) {
		CC_CURSOR_MAP = cC_CURSOR_MAP;
	}

	public String getCC_CURSOR_IDX() {
		return CC_CURSOR_IDX;
	}

	public void setCC_CURSOR_IDX(String cC_CURSOR_IDX) {
		CC_CURSOR_IDX = cC_CURSOR_IDX;
	}

	public String getCC_MESSAGE_CD() {
		return CC_MESSAGE_CD;
	}

	public void setCC_MESSAGE_CD(String cC_MESSAGE_CD) {
		CC_MESSAGE_CD = cC_MESSAGE_CD;
	}

	public String getHC_MESSAGE_NM() {
		return HC_MESSAGE_NM;
	}

	public void setHC_MESSAGE_NM(String hC_MESSAGE_NM) {
		HC_MESSAGE_NM = hC_MESSAGE_NM;
	}

	public String getCC_SYS_ERR() {
		return CC_SYS_ERR;
	}

	public void setCC_SYS_ERR(String cC_SYS_ERR) {
		CC_SYS_ERR = cC_SYS_ERR;
	}

	public String getCC_FILLER() {
		return CC_FILLER;
	}

	public void setCC_FILLER(String cC_FILLER) {
		CC_FILLER = cC_FILLER;
	}

	public String getSS_JOGUN() {
		return SS_JOGUN;
	}

	public void setSS_JOGUN(String sS_JOGUN) {
		SS_JOGUN = sS_JOGUN;
	}

	public String getSS_JOGUN_NO() {
		return SS_JOGUN_NO;
	}

	public void setSS_JOGUN_NO(String sS_JOGUN_NO) {
		SS_JOGUN_NO = sS_JOGUN_NO;
	}

	public String getSS_SAGO_JUBSU_NO() {
		return SS_SAGO_JUBSU_NO;
	}

	public void setSS_SAGO_JUBSU_NO(String sS_SAGO_JUBSU_NO) {
		SS_SAGO_JUBSU_NO = sS_SAGO_JUBSU_NO;
	}

	public String getSS_SAGO_JUBSU_SEQ() {
		return SS_SAGO_JUBSU_SEQ;
	}

	public void setSS_SAGO_JUBSU_SEQ(String sS_SAGO_JUBSU_SEQ) {
		SS_SAGO_JUBSU_SEQ = sS_SAGO_JUBSU_SEQ;
	}

	public String getSS_SAGO_MOKJUK_GB() {
		return SS_SAGO_MOKJUK_GB;
	}

	public void setSS_SAGO_MOKJUK_G(String sS_SAGO_MOKJUK_GB) {
		SS_SAGO_MOKJUK_GB = sS_SAGO_MOKJUK_GB;
	}

	public String getSS_SAGO_MOKJUK_SEQ() {
		return SS_SAGO_MOKJUK_SEQ;
	}

	public void setSS_SAGO_MOKJUK_SEQ(String sS_SAGO_MOKJUK_SEQ) {
		SS_SAGO_MOKJUK_SEQ = sS_SAGO_MOKJUK_SEQ;
	}

	public String getSS_DB_YN() {
		return SS_DB_YN;
	}

	public void setSS_DB_YN(String sS_DB_YN) {
		SS_DB_YN = sS_DB_YN;
	}

	public String getSS_GF() {
		return SS_GF;
	}

	public void setSS_GF(String sS_GF) {
		SS_GF = sS_GF;
	}

	public String getSS_SAGO_DAMBO() {
		return SS_SAGO_DAMBO;
	}

	public void setSS_SAGO_DAMBO(String sS_SAGO_DAMBO) {
		SS_SAGO_DAMBO = sS_SAGO_DAMBO;
	}

	public String getSS_PIHE_GWANGE() {
		return SS_PIHE_GWANGE;
	}

	public void setSS_PIHE_GWANGE(String sS_PIHE_GWANGE) {
		SS_PIHE_GWANGE = sS_PIHE_GWANGE;
	}

	public String getHS_PIHE_GWANGE() {
		return HS_PIHE_GWANGE;
	}

	public void setHS_PIHE_GWANGE(String hS_PIHE_GWANGE) {
		HS_PIHE_GWANGE = hS_PIHE_GWANGE;
	}

	public String getSS_PIHE_JUMIN() {
		return SS_PIHE_JUMIN;
	}

	public void setSS_PIHE_JUMIN(String sS_PIHE_JUMIN) {
		SS_PIHE_JUMIN = sS_PIHE_JUMIN;
	}

	public String getHS_PIHE_NM() {
		return HS_PIHE_NM;
	}

	public void setHS_PIHE_NM(String hS_PIHE_NM) {
		HS_PIHE_NM = hS_PIHE_NM;
	}

	public String getSS_PIHE_TEL() {
		return SS_PIHE_TEL;
	}

	public void setSS_PIHE_TEL(String sS_PIHE_TEL) {
		SS_PIHE_TEL = sS_PIHE_TEL;
	}

	public String getSS_BUSANG_BUWI_CD() {
		return SS_BUSANG_BUWI_CD;
	}

	public void setSS_BUSANG_BUWI_CD(String sS_BUSANG_BUWI_CD) {
		SS_BUSANG_BUWI_CD = sS_BUSANG_BUWI_CD;
	}

	public String getSS_SONHE_CD1() {
		return SS_SONHE_CD1;
	}

	public void setSS_SONHE_CD1(String sS_SONHE_CD1) {
		SS_SONHE_CD1 = sS_SONHE_CD1;
	}

	public String getSS_SONHE_CD2() {
		return SS_SONHE_CD2;
	}

	public void setSS_SONHE_CD2(String sS_SONHE_CD2) {
		SS_SONHE_CD2 = sS_SONHE_CD2;
	}

	public String getSS_GOLJUL_CD() {
		return SS_GOLJUL_CD;
	}

	public void setSS_GOLJUL_CD(String sS_GOLJUL_CD) {
		SS_GOLJUL_CD = sS_GOLJUL_CD;
	}

	public String getSS_SUSUL_CD() {
		return SS_SUSUL_CD;
	}

	public void setSS_SUSUL_CD(String sS_SUSUL_CD) {
		SS_SUSUL_CD = sS_SUSUL_CD;
	}

	public String getSS_SONHEAK_GB() {
		return SS_SONHEAK_GB;
	}

	public void setSS_SONHEAK_GB(String sS_SONHEAK_GB) {
		SS_SONHEAK_GB = sS_SONHEAK_GB;
	}

	public String getSS_IPWON_YMD() {
		return SS_IPWON_YMD;
	}

	public void setSS_IPWON_YMD(String sS_IPWON_YMD) {
		SS_IPWON_YMD = sS_IPWON_YMD;
	}

	public String getHS_SOYUJA_NM() {
		return HS_SOYUJA_NM;
	}

	public void setHS_SOYUJA_NM(String hS_SOYUJA_NM) {
		HS_SOYUJA_NM = hS_SOYUJA_NM;
	}

	public String getSS_GURECHU_CD1() {
		return SS_GURECHU_CD1;
	}

	public void setSS_GURECHU_CD1(String sS_GURECHU_CD1) {
		SS_GURECHU_CD1 = sS_GURECHU_CD1;
	}

	public String getSS_GURECHU_CD2() {
		return SS_GURECHU_CD2;
	}

	public void setSS_GURECHU_CD2(String sS_GURECHU_CD2) {
		SS_GURECHU_CD2 = sS_GURECHU_CD2;
	}

	public String getHS_GURECHU_NM() {
		return HS_GURECHU_NM;
	}

	public void setHS_GURECHU_NM(String hS_GURECHU_NM) {
		HS_GURECHU_NM = hS_GURECHU_NM;
	}

	public String getSS_GURECHU_ZIP() {
		return SS_GURECHU_ZIP;
	}

	public void setSS_GURECHU_ZIP(String sS_GURECHU_ZIP) {
		SS_GURECHU_ZIP = sS_GURECHU_ZIP;
	}

	public String getHS_GURECHU_GITA() {
		return HS_GURECHU_GITA;
	}

	public void setHS_GURECHU_GITA(String hS_GURECHU_GITA) {
		HS_GURECHU_GITA = hS_GURECHU_GITA;
	}

	public String getSS_GURECHU_TEL() {
		return SS_GURECHU_TEL;
	}

	public void setSS_GURECHU_TEL(String sS_GURECHU_TEL) {
		SS_GURECHU_TEL = sS_GURECHU_TEL;
	}

	public String getSS_GURECHU_GBSU() {
		return SS_GURECHU_GBSU;
	}

	public void setSS_GURECHU_GBSU(String sS_GURECHU_GBSU) {
		SS_GURECHU_GBSU = sS_GURECHU_GBSU;
	}

	public String getSS_CENTER() {
		return SS_CENTER;
	}

	public void setSS_CENTER(String sS_CENTER) {
		SS_CENTER = sS_CENTER;
	}

	public String getSS_TEAM() {
		return SS_TEAM;
	}

	public void setSS_TEAM(String sS_TEAM) {
		SS_TEAM = sS_TEAM;
	}

	public String getSS_DAMDANGJA() {
		return SS_DAMDANGJA;
	}

	public void setSS_DAMDANGJA(String sS_DAMDANGJA) {
		SS_DAMDANGJA = sS_DAMDANGJA;
	}

	public String getHS_DAMDANGJA() {
		return HS_DAMDANGJA;
	}

	public void setHS_DAMDANGJA(String hS_DAMDANGJA) {
		HS_DAMDANGJA = hS_DAMDANGJA;
	}

	public String getSS_DAMDANGJA_TEL() {
		return SS_DAMDANGJA_TEL;
	}

	public void setSS_DAMDANGJA_TEL(String sS_DAMDANGJA_TEL) {
		SS_DAMDANGJA_TEL = sS_DAMDANGJA_TEL;
	}

	public String getSS_J_CENTER() {
		return SS_J_CENTER;
	}

	public void setSS_J_CENTER(String sS_J_CENTER) {
		SS_J_CENTER = sS_J_CENTER;
	}

	public String getSS_J_TEAM() {
		return SS_J_TEAM;
	}

	public void setSS_J_TEAM(String sS_J_TEAM) {
		SS_J_TEAM = sS_J_TEAM;
	}

	public String getSS_J_DAMDANGJA() {
		return SS_J_DAMDANGJA;
	}

	public void setSS_J_DAMDANGJA(String sS_J_DAMDANGJA) {
		SS_J_DAMDANGJA = sS_J_DAMDANGJA;
	}

	public String getHS_J_DAMDANGJA() {
		return HS_J_DAMDANGJA;
	}

	public void setHS_J_DAMDANGJA(String hS_J_DAMDANGJA) {
		HS_J_DAMDANGJA = hS_J_DAMDANGJA;
	}

	public String getSS_J_DAMDANGJA_TE() {
		return SS_J_DAMDANGJA_TE;
	}

	public void setSS_J_DAMDANGJA_TE(String sS_J_DAMDANGJA_TE) {
		SS_J_DAMDANGJA_TE = sS_J_DAMDANGJA_TE;
	}

	public String getSS_CAR_DAM_YN() {
		return SS_CAR_DAM_YN;
	}

	public void setSS_CAR_DAM_YN(String sS_CAR_DAM_YN) {
		SS_CAR_DAM_YN = sS_CAR_DAM_YN;
	}

	public String getSS_SOAK_YN() {
		return SS_SOAK_YN;
	}

	public void setSS_SOAK_YN(String sS_SOAK_YN) {
		SS_SOAK_YN = sS_SOAK_YN;
	}

	public String getSS_BANK_CD() {
		return SS_BANK_CD;
	}

	public void setSS_BANK_CD(String sS_BANK_CD) {
		SS_BANK_CD = sS_BANK_CD;
	}

	public String getSS_GYEJWA_NO() {
		return SS_GYEJWA_NO;
	}

	public void setSS_GYEJWA_NO(String sS_GYEJWA_NO) {
		SS_GYEJWA_NO = sS_GYEJWA_NO;
	}

	public String getSS_GYEJWA_YN() {
		return SS_GYEJWA_YN;
	}

	public void setSS_GYEJWA_YN(String sS_GYEJWA_YN) {
		SS_GYEJWA_YN = sS_GYEJWA_YN;
	}

	public String getSS_GANG_BAE_YN() {
		return SS_GANG_BAE_YN;
	}

	public void setSS_GANG_BAE_YN(String sS_GANG_BAE_YN) {
		SS_GANG_BAE_YN = sS_GANG_BAE_YN;
	}

	public String getSS_JINRYO_GWAMOK() {
		return SS_JINRYO_GWAMOK;
	}

	public void setSS_JINRYO_GWAMOK(String sS_JINRYO_GWAMOK) {
		SS_JINRYO_GWAMOK = sS_JINRYO_GWAMOK;
	}

	public String getSS_SERYU_YMD() {
		return SS_SERYU_YMD;
	}

	public void setSS_SERYU_YMD(String sS_SERYU_YMD) {
		SS_SERYU_YMD = sS_SERYU_YMD;
	}

	public String getSS_SONSA() {
		return SS_SONSA;
	}

	public void setSS_SONSA(String sS_SONSA) {
		SS_SONSA = sS_SONSA;
	}

	public String getHS_SONSA() {
		return HS_SONSA;
	}

	public void setHS_SONSA(String hS_SONSA) {
		HS_SONSA = hS_SONSA;
	}

	public String getSS_H_CNT() {
		return SS_H_CNT;
	}

	public void setSS_H_CNT(String sS_H_CNT) {
		SS_H_CNT = sS_H_CNT;
	}

	public String getSS_H_PAGE() {
		return SS_H_PAGE;
	}

	public void setSS_H_PAGE(String sS_H_PAGE) {
		SS_H_PAGE = sS_H_PAGE;
	}

	public String getSS_H_T_PAGE() {
		return SS_H_T_PAGE;
	}

	public void setSS_H_T_PAGE(String sS_H_T_PAGE) {
		SS_H_T_PAGE = sS_H_T_PAGE;
	}

	public List<Map<String, String>> getLOOP_DATA() {
		return LOOP_DATA;
	}

	public void setLOOP_DATA(List<Map<String, String>> lOOP_DATA) {
		LOOP_DATA = lOOP_DATA;
	}

	public String getUUC_INQ_MOKJUK_GB() {
		return UUC_INQ_MOKJUK_GB;
	}

	public void setUUC_INQ_MOKJUK_GB(String uUC_INQ_MOKJUK_GB) {
		UUC_INQ_MOKJUK_GB = uUC_INQ_MOKJUK_GB;
	}

	public String getUUC_INQ_MOKJUK_SEQ() {
		return UUC_INQ_MOKJUK_SEQ;
	}

	public void setUUC_INQ_MOKJUK_SEQ(String uUC_INQ_MOKJUK_SEQ) {
		UUC_INQ_MOKJUK_SEQ = uUC_INQ_MOKJUK_SEQ;
	}

	public String getUUC_F_MOKJUK_GB() {
		return UUC_F_MOKJUK_GB;
	}

	public void setUUC_F_MOKJUK_GB(String uUC_F_MOKJUK_GB) {
		UUC_F_MOKJUK_GB = uUC_F_MOKJUK_GB;
	}

	public String getUUC_F_MOKJUK_SEQ() {
		return UUC_F_MOKJUK_SEQ;
	}

	public void setUUC_F_MOKJUK_SEQ(String uUC_F_MOKJUK_SEQ) {
		UUC_F_MOKJUK_SEQ = uUC_F_MOKJUK_SEQ;
	}

	public String getUUC_L_MOKJUK_GB() {
		return UUC_L_MOKJUK_GB;
	}

	public void setUUC_L_MOKJUK_GB(String uUC_L_MOKJUK_GB) {
		UUC_L_MOKJUK_GB = uUC_L_MOKJUK_GB;
	}

	public String getUUC_L_MOKJUK_SEQ() {
		return UUC_L_MOKJUK_SEQ;
	}

	public void setUUC_L_MOKJUK_SEQ(String uUC_L_MOKJUK_SEQ) {
		UUC_L_MOKJUK_SEQ = uUC_L_MOKJUK_SEQ;
	}

	public String getBB_ST_PATH() {
		return BB_ST_PATH;
	}

	public void setBB_ST_PATH(String bB_ST_PATH) {
		BB_ST_PATH = bB_ST_PATH;
	}

	public String getBB_TERM_ID() {
		return BB_TERM_ID;
	}

	public void setBB_TERM_ID(String bB_TERM_ID) {
		BB_TERM_ID = bB_TERM_ID;
	}

	public String getBB_MAP_ID() {
		return BB_MAP_ID;
	}

	public void setBB_MAP_ID(String bB_MAP_ID) {
		BB_MAP_ID = bB_MAP_ID;
	}

	public String getBB_JOGUN() {
		return BB_JOGUN;
	}

	public void setBB_JOGUN(String bB_JOGUN) {
		BB_JOGUN = bB_JOGUN;
	}

	public String getBB_JOGUN_NO() {
		return BB_JOGUN_NO;
	}

	public void setBB_JOGUN_NO(String bB_JOGUN_NO) {
		BB_JOGUN_NO = bB_JOGUN_NO;
	}

	public String getBB_SAGO_JUBSU_NO() {
		return BB_SAGO_JUBSU_NO;
	}

	public void setBB_SAGO_JUBSU_NO(String bB_SAGO_JUBSU_NO) {
		BB_SAGO_JUBSU_NO = bB_SAGO_JUBSU_NO;
	}

	public String getBB_SAGO_JUBSU_SEQ() {
		return BB_SAGO_JUBSU_SEQ;
	}

	public void setBB_SAGO_JUBSU_SEQ(String bB_SAGO_JUBSU_SEQ) {
		BB_SAGO_JUBSU_SEQ = bB_SAGO_JUBSU_SEQ;
	}

	public String getBB_SAGO_MOKJUK_GB() {
		return BB_SAGO_MOKJUK_GB;
	}

	public void setBB_SAGO_MOKJUK_GB(String bB_SAGO_MOKJUK_GB) {
		BB_SAGO_MOKJUK_GB = bB_SAGO_MOKJUK_GB;
	}

	public String getBB_SAGO_MOKJUK_SEQ() {
		return BB_SAGO_MOKJUK_SEQ;
	}

	public void setBB_SAGO_MOKJUK_SEQ(String bB_SAGO_MOKJUK_SEQ) {
		BB_SAGO_MOKJUK_SEQ = bB_SAGO_MOKJUK_SEQ;
	}

	public String getBB_LAST_JUBSU_SEQ() {
		return BB_LAST_JUBSU_SEQ;
	}

	public void setBB_LAST_JUBSU_SEQ(String bB_LAST_JUBSU_SEQ) {
		BB_LAST_JUBSU_SEQ = bB_LAST_JUBSU_SEQ;
	}

	public String getBB_LAST_MOKJUK_SEQ() {
		return BB_LAST_MOKJUK_SEQ;
	}

	public void setBB_LAST_MOKJUK_SEQ(String bB_LAST_MOKJUK_SEQ) {
		BB_LAST_MOKJUK_SEQ = bB_LAST_MOKJUK_SEQ;
	}

	public String getBB_INMUL() {
		return BB_INMUL;
	}

	public void setBB_INMUL(String bB_INMUL) {
		BB_INMUL = bB_INMUL;
	}

	public String getBB_IN_CNT() {
		return BB_IN_CNT;
	}

	public void setBB_IN_CNT(String bB_IN_CNT) {
		BB_IN_CNT = bB_IN_CNT;
	}

	public String getBB_JAEMUL_CNT() {
		return BB_JAEMUL_CNT;
	}

	public void setBB_JAEMUL_CNT(String bB_JAEMUL_CNT) {
		BB_JAEMUL_CNT = bB_JAEMUL_CNT;
	}

	public String getBB_DEIN_CNT() {
		return BB_DEIN_CNT;
	}

	public void setBB_DEIN_CNT(String bB_DEIN_CNT) {
		BB_DEIN_CNT = bB_DEIN_CNT;
	}

	public String getBB_DAEMUL_CNT() {
		return BB_DAEMUL_CNT;
	}

	public void setBB_DAEMUL_CNT(String bB_DAEMUL_CNT) {
		BB_DAEMUL_CNT = bB_DAEMUL_CNT;
	}

	public String getBB_GOGEK_GB() {
		return BB_GOGEK_GB;
	}

	public void setBB_GOGEK_GB(String bB_GOGEK_GB) {
		BB_GOGEK_GB = bB_GOGEK_GB;
	}

	public String getBB_GOGEK_NO() {
		return BB_GOGEK_NO;
	}

	public void setBB_GOGEK_NO(String bB_GOGEK_NO) {
		BB_GOGEK_NO = bB_GOGEK_NO;
	}

	public String getHB_GOGEK_NM() {
		return HB_GOGEK_NM;
	}

	public void setHB_GOGEK_NM(String hB_GOGEK_NM) {
		HB_GOGEK_NM = hB_GOGEK_NM;
	}

	public String getBB_GOGEK_TEL() {
		return BB_GOGEK_TEL;
	}

	public void setBB_GOGEK_TEL(String bB_GOGEK_TEL) {
		BB_GOGEK_TEL = bB_GOGEK_TEL;
	}

	public String getBB_SAGO_DAMBO() {
		return BB_SAGO_DAMBO;
	}

	public void setBB_SAGO_DAMBO(String bB_SAGO_DAMBO) {
		BB_SAGO_DAMBO = bB_SAGO_DAMBO;
	}

	public String getBB_JUBSU_UPMU1() {
		return BB_JUBSU_UPMU1;
	}

	public void setBB_JUBSU_UPMU1(String bB_JUBSU_UPMU1) {
		BB_JUBSU_UPMU1 = bB_JUBSU_UPMU1;
	}

	public String getBB_JUBSU_UPMU2() {
		return BB_JUBSU_UPMU2;
	}

	public void setBB_JUBSU_UPMU2(String bB_JUBSU_UPMU2) {
		BB_JUBSU_UPMU2 = bB_JUBSU_UPMU2;
	}

	public String getBB_JUBSU_UPMU3() {
		return BB_JUBSU_UPMU3;
	}

	public void setBB_JUBSU_UPMU3(String bB_JUBSU_UPMU3) {
		BB_JUBSU_UPMU3 = bB_JUBSU_UPMU3;
	}

	public String getBB_SAGO_YMD() {
		return BB_SAGO_YMD;
	}

	public void setBB_SAGO_YMD(String bB_SAGO_YMD) {
		BB_SAGO_YMD = bB_SAGO_YMD;
	}

	public String getBB_SAGO_HM() {
		return BB_SAGO_HM;
	}

	public void setBB_SAGO_HM(String bB_SAGO_HM) {
		BB_SAGO_HM = bB_SAGO_HM;
	}

	public String getBB_TYPE_CD() {
		return BB_TYPE_CD;
	}

	public void setBB_TYPE_CD(String bB_TYPE_CD) {
		BB_TYPE_CD = bB_TYPE_CD;
	}

	public String getBB_WONIN_CD() {
		return BB_WONIN_CD;
	}

	public void setBB_WONIN_CD(String bB_WONIN_CD) {
		BB_WONIN_CD = bB_WONIN_CD;
	}

	public String getBB_UNHENG_CD1() {
		return BB_UNHENG_CD1;
	}

	public void setBB_UNHENG_CD1(String bB_UNHENG_CD1) {
		BB_UNHENG_CD1 = bB_UNHENG_CD1;
	}

	public String getBB_UNHENG_CD2() {
		return BB_UNHENG_CD2;
	}

	public void setBB_UNHENG_CD2(String bB_UNHENG_CD2) {
		BB_UNHENG_CD2 = bB_UNHENG_CD2;
	}

	public String getBB_SAGO_ZIP() {
		return BB_SAGO_ZIP;
	}

	public void setBB_SAGO_ZIP(String bB_SAGO_ZIP) {
		BB_SAGO_ZIP = bB_SAGO_ZIP;
	}

	public String getBB_N_SAGO_ZIP() {
		return BB_N_SAGO_ZIP;
	}

	public void setBB_N_SAGO_ZIP(String bB_N_SAGO_ZIP) {
		BB_N_SAGO_ZIP = bB_N_SAGO_ZIP;
	}

	public String getBB_WALRYO_YN() {
		return BB_WALRYO_YN;
	}

	public void setBB_WALRYO_YN(String bB_WALRYO_YN) {
		BB_WALRYO_YN = bB_WALRYO_YN;
	}

	public String getBB_JUBSU_CENTER() {
		return BB_JUBSU_CENTER;
	}

	public void setBB_JUBSU_CENTER(String bB_JUBSU_CENTER) {
		BB_JUBSU_CENTER = bB_JUBSU_CENTER;
	}

	public String getBB_JUBSUJA() {
		return BB_JUBSUJA;
	}

	public void setBB_JUBSUJA(String bB_JUBSUJA) {
		BB_JUBSUJA = bB_JUBSUJA;
	}

	public String getBB_MIWHAKIN_CD() {
		return BB_MIWHAKIN_CD;
	}

	public void setBB_MIWHAKIN_CD(String bB_MIWHAKIN_CD) {
		BB_MIWHAKIN_CD = bB_MIWHAKIN_CD;
	}

	public String getBB_YUNGUP_CHONG() {
		return BB_YUNGUP_CHONG;
	}

	public void setBB_YUNGUP_CHONG(String bB_YUNGUP_CHONG) {
		BB_YUNGUP_CHONG = bB_YUNGUP_CHONG;
	}

	public String getBB_SERYU_CD() {
		return BB_SERYU_CD;
	}

	public void setBB_SERYU_CD(String bB_SERYU_CD) {
		BB_SERYU_CD = bB_SERYU_CD;
	}

	public String getBB_GF_GB() {
		return BB_GF_GB;
	}

	public void setBB_GF_GB(String bB_GF_GB) {
		BB_GF_GB = bB_GF_GB;
	}

	public String getBB_DAMDANGJA() {
		return BB_DAMDANGJA;
	}

	public void setBB_DAMDANGJA(String bB_DAMDANGJA) {
		BB_DAMDANGJA = bB_DAMDANGJA;
	}

	public String getBB_SAGO_JANGSO_GB() {
		return BB_SAGO_JANGSO_GB;
	}

	public void setBB_SAGO_JANGSO_GB(String bB_SAGO_JANGSO_GB) {
		BB_SAGO_JANGSO_GB = bB_SAGO_JANGSO_GB;
	}

	public String getBB_SUN_JUBSU() {
		return BB_SUN_JUBSU;
	}

	public void setBB_SUN_JUBSU(String bB_SUN_JUBSU) {
		BB_SUN_JUBSU = bB_SUN_JUBSU;
	}

	public String getBB_SAGO_YMDHM() {
		return BB_SAGO_YMDHM;
	}

	public void setBB_SAGO_YMDHM(String bB_SAGO_YMDHM) {
		BB_SAGO_YMDHM = bB_SAGO_YMDHM;
	}

	public static String getProid() {
		return proid;
	}

	public static String getTrid() {
		return trid;
	}

	public String getSS_J_DAMDANGJA_TEL() {
		return SS_J_DAMDANGJA_TEL;
	}

	public void setSS_J_DAMDANGJA_TEL(String sS_J_DAMDANGJA_TEL) {
		SS_J_DAMDANGJA_TEL = sS_J_DAMDANGJA_TEL;
	}

	public String getSS_GIJIGP_BANK_CD() {
		return SS_GIJIGP_BANK_CD;
	}

	public void setSS_GIJIGP_BANK_CD(String sS_GIJIGP_BANK_CD) {
		SS_GIJIGP_BANK_CD = sS_GIJIGP_BANK_CD;
	}

	public String getSS_GIJIGP_GYEJWA_NO() {
		return SS_GIJIGP_GYEJWA_NO;
	}

	public void setSS_GIJIGP_GYEJWA_NO(String sS_GIJIGP_GYEJWA_NO) {
		SS_GIJIGP_GYEJWA_NO = sS_GIJIGP_GYEJWA_NO;
	}

	public String getSS_JADONG_BANK_CD() {
		return SS_JADONG_BANK_CD;
	}

	public void setSS_JADONG_BANK_CD(String sS_JADONG_BANK_CD) {
		SS_JADONG_BANK_CD = sS_JADONG_BANK_CD;
	}

	public String getSS_JADONG_GYEJWA_NO() {
		return SS_JADONG_GYEJWA_NO;
	}

	public void setSS_JADONG_GYEJWA_NO(String sS_JADONG_GYEJWA_NO) {
		SS_JADONG_GYEJWA_NO = sS_JADONG_GYEJWA_NO;
	}

	public String getBB_SOAK_YN() {
		return BB_SOAK_YN;
	}

	public void setBB_SOAK_YN(String bB_SOAK_YN) {
		BB_SOAK_YN = bB_SOAK_YN;
	}

	public String getBB_BANK_CD() {
		return BB_BANK_CD;
	}

	public void setBB_BANK_CD(String bB_BANK_CD) {
		BB_BANK_CD = bB_BANK_CD;
	}

	public String getBB_GYEJWA_NO() {
		return BB_GYEJWA_NO;
	}

	public void setBB_GYEJWA_NO(String bB_GYEJWA_NO) {
		BB_GYEJWA_NO = bB_GYEJWA_NO;
	}

	public String getBB_GYEJWA_YN() {
		return BB_GYEJWA_YN;
	}

	public void setBB_GYEJWA_YN(String bB_GYEJWA_YN) {
		BB_GYEJWA_YN = bB_GYEJWA_YN;
	}

	public void setSS_SAGO_MOKJUK_GB(String sS_SAGO_MOKJUK_GB) {
		SS_SAGO_MOKJUK_GB = sS_SAGO_MOKJUK_GB;
	}	
	
	private String contact1               = "";
	private String contact2               = "";
	private String contact3               = "";
	public String getContact1() {
		return contact1;
	}

	public void setContact1(String contact1) {
		this.contact1 = contact1;
	}

	public String getContact2() {
		return contact2;
	}

	public void setContact2(String contact2) {
		this.contact2 = contact2;
	}

	public String getContact3() {
		return contact3;
	}

	public void setContact3(String contact3) {
		this.contact3 = contact3;
	}
}
