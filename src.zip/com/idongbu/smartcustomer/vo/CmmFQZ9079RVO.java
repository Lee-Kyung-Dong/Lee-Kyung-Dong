package com.idongbu.smartcustomer.vo;

import java.util.List;
import java.util.Map;

import com.idongbu.common.vo.CMMVO;

public class CmmFQZ9079RVO extends CMMVO {
	
	public CmmFQZ9079RVO() {
		super.setPGMID(this.proid);
		super.setTRID(this.trid);
	}		
	
	private static final String proid = "FQZ9079R";
	private static final String trid  = "QZ79";
	private String rURL				  = "";

	private String COMM_CHANNEL       = "";
	private String COMM_UNIQUE        = "";
	private String COMM_PGMID         = "";
	private String COMM_PROC_GB       = "";
	private String COMM_FUN_KEY       = "";
	private String COMM_USER_GB       = "";
	private String COMM_USER_CD       = "";
	private String COMM_JIJUM_CD      = "";
	private String COMM_JIBU_CD       = "";
	private String COMM_PROTOCOL      = "";
	private String COMM_COND_CD       = "";
	private String COMM_LAST_FLAG     = "";
	private String COMM_CURSOR_MAP    = "";
	private String COMM_CURSOR_IDX    = "";
	private String COMM_MESSAGE_CD    = "";
	private String H_COMM_MESSAGE_NM  = "";
	private String COMM_SYS_ERR       = "";
	private String COMM_FILLER        = "";
	/*
	private String SCR_POLI_NO             = ""; // 증권번호
	private String H_SCR_GOGEK_NM          = ""; // 피보험자
	private String SCR_SYMD                = ""; // 보험시작기간   
	private String SCR_EYMD                = ""; // 보험종료기간   
	private String SCR_GOGEK_CONTROL_NO    = ""; // 고객번호
	private String SCR_DRIVE_JUNGSAN_DS_YN = ""; // 주행거리특약 만기정산대상여부 ( Y / N )
	private String SCR_DRIVE_JUNGSAN_YN    = ""; // 주행거리특약 만기정산여부 ( Y / N )
	private String SCR_DRIVE_UPMU_CD       = ""; // 주행거리채널구분 ( 0 : 영업포탈/8 : 프로미월드(정비업체)/9 : 콜시스템(자동차) )
	private String SCR_DRIVE_JARYO_YMD     = ""; // 주행거리자료최종입력일자
	private String H_SCR_CAR_NAME          = ""; // 차명
	private String SCR_BLACKBOX_YN         = ""; // 블랙박스 가입유무 ( Y / N )
	*/
	private List<Map<String, String>> LOOP_DATA = null;
	private String H_SCR_CAR_NO       = ""; // 차량번호
	private String H_SCR_CAR_NAME     = ""; // 차명
	private String SCR_BLACKBOX_YN    = ""; // 블랙박스 가입유무
	private String SCR_GUBUN          = ""; // 처리구분 ( 주행거리가입건만리턴'D', 그외는 ' ' )
	
	private String PAGE_Q_POLI_NO     = ""; // 조회 증권번호
	private String PAGE_Q_BOHUM_SYMD  = ""; // 조회 보험시작기간
	private String PAGE_F_POLI_NO     = ""; // FIRST KEY 증권번호
	private String PAGE_F_BOHUM_SYMD  = ""; // FIRST KEY 보험시작기간
	private String PAGE_L_POLI_NO     = ""; // LAST KEY 증권번호
	private String PAGE_L_BOHUM_SYMD  = ""; // LAST KEY 보험시작기간
	private String SCR_BRIGHT_MAP     = ""; // 화면브라이트MAP
	private String H_SCR_CAR_NO_B     = ""; // 
	
	public String getrURL() {
		return rURL;
	}
	public void setrURL(String rURL) {
		this.rURL = rURL;
	}
	public String getCOMM_CHANNEL() {
		return COMM_CHANNEL;
	}
	public void setCOMM_CHANNEL(String cOMM_CHANNEL) {
		COMM_CHANNEL = cOMM_CHANNEL;
	}
	public String getCOMM_UNIQUE() {
		return COMM_UNIQUE;
	}
	public void setCOMM_UNIQUE(String cOMM_UNIQUE) {
		COMM_UNIQUE = cOMM_UNIQUE;
	}
	public String getCOMM_PGMID() {
		return COMM_PGMID;
	}
	public void setCOMM_PGMID(String cOMM_PGMID) {
		COMM_PGMID = cOMM_PGMID;
	}
	public String getCOMM_PROC_GB() {
		return COMM_PROC_GB;
	}
	public void setCOMM_PROC_GB(String cOMM_PROC_GB) {
		COMM_PROC_GB = cOMM_PROC_GB;
	}
	public String getCOMM_FUN_KEY() {
		return COMM_FUN_KEY;
	}
	public void setCOMM_FUN_KEY(String cOMM_FUN_KEY) {
		COMM_FUN_KEY = cOMM_FUN_KEY;
	}
	public String getCOMM_USER_GB() {
		return COMM_USER_GB;
	}
	public void setCOMM_USER_GB(String cOMM_USER_GB) {
		COMM_USER_GB = cOMM_USER_GB;
	}
	public String getCOMM_USER_CD() {
		return COMM_USER_CD;
	}
	public void setCOMM_USER_CD(String cOMM_USER_CD) {
		COMM_USER_CD = cOMM_USER_CD;
	}
	public String getCOMM_JIJUM_CD() {
		return COMM_JIJUM_CD;
	}
	public void setCOMM_JIJUM_CD(String cOMM_JIJUM_CD) {
		COMM_JIJUM_CD = cOMM_JIJUM_CD;
	}
	public String getCOMM_JIBU_CD() {
		return COMM_JIBU_CD;
	}
	public void setCOMM_JIBU_CD(String cOMM_JIBU_CD) {
		COMM_JIBU_CD = cOMM_JIBU_CD;
	}
	public String getCOMM_PROTOCOL() {
		return COMM_PROTOCOL;
	}
	public void setCOMM_PROTOCOL(String cOMM_PROTOCOL) {
		COMM_PROTOCOL = cOMM_PROTOCOL;
	}
	public String getCOMM_COND_CD() {
		return COMM_COND_CD;
	}
	public void setCOMM_COND_CD(String cOMM_COND_CD) {
		COMM_COND_CD = cOMM_COND_CD;
	}
	public String getCOMM_LAST_FLAG() {
		return COMM_LAST_FLAG;
	}
	public void setCOMM_LAST_FLAG(String cOMM_LAST_FLAG) {
		COMM_LAST_FLAG = cOMM_LAST_FLAG;
	}
	public String getCOMM_CURSOR_MAP() {
		return COMM_CURSOR_MAP;
	}
	public void setCOMM_CURSOR_MAP(String cOMM_CURSOR_MAP) {
		COMM_CURSOR_MAP = cOMM_CURSOR_MAP;
	}
	public String getCOMM_CURSOR_IDX() {
		return COMM_CURSOR_IDX;
	}
	public void setCOMM_CURSOR_IDX(String cOMM_CURSOR_IDX) {
		COMM_CURSOR_IDX = cOMM_CURSOR_IDX;
	}
	public String getCOMM_MESSAGE_CD() {
		return COMM_MESSAGE_CD;
	}
	public void setCOMM_MESSAGE_CD(String cOMM_MESSAGE_CD) {
		COMM_MESSAGE_CD = cOMM_MESSAGE_CD;
	}
	public String getH_COMM_MESSAGE_NM() {
		return H_COMM_MESSAGE_NM;
	}
	public void setH_COMM_MESSAGE_NM(String h_COMM_MESSAGE_NM) {
		H_COMM_MESSAGE_NM = h_COMM_MESSAGE_NM;
	}
	public String getCOMM_SYS_ERR() {
		return COMM_SYS_ERR;
	}
	public void setCOMM_SYS_ERR(String cOMM_SYS_ERR) {
		COMM_SYS_ERR = cOMM_SYS_ERR;
	}
	public String getCOMM_FILLER() {
		return COMM_FILLER;
	}
	public void setCOMM_FILLER(String cOMM_FILLER) {
		COMM_FILLER = cOMM_FILLER;
	}
	public List<Map<String, String>> getLOOP_DATA() {
		return LOOP_DATA;
	}
	public void setLOOP_DATA(List<Map<String, String>> lOOP_DATA) {
		LOOP_DATA = lOOP_DATA;
	}
	public String getH_SCR_CAR_NO() {
		return H_SCR_CAR_NO;
	}
	public void setH_SCR_CAR_NO(String h_SCR_CAR_NO) {
		H_SCR_CAR_NO = h_SCR_CAR_NO;
	}
	public String getH_SCR_CAR_NAME() {
		return H_SCR_CAR_NAME;
	}
	public void setH_SCR_CAR_NAME(String h_SCR_CAR_NAME) {
		H_SCR_CAR_NAME = h_SCR_CAR_NAME;
	}
	public String getSCR_BLACKBOX_YN() {
		return SCR_BLACKBOX_YN;
	}
	public void setSCR_BLACKBOX_YN(String sCR_BLACKBOX_YN) {
		SCR_BLACKBOX_YN = sCR_BLACKBOX_YN;
	}
	public String getSCR_GUBUN() {
		return SCR_GUBUN;
	}
	public void setSCR_GUBUN(String sCR_GUBUN) {
		SCR_GUBUN = sCR_GUBUN;
	}
	public String getPAGE_Q_POLI_NO() {
		return PAGE_Q_POLI_NO;
	}
	public void setPAGE_Q_POLI_NO(String pAGE_Q_POLI_NO) {
		PAGE_Q_POLI_NO = pAGE_Q_POLI_NO;
	}
	public String getPAGE_Q_BOHUM_SYMD() {
		return PAGE_Q_BOHUM_SYMD;
	}
	public void setPAGE_Q_BOHUM_SYMD(String pAGE_Q_BOHUM_SYMD) {
		PAGE_Q_BOHUM_SYMD = pAGE_Q_BOHUM_SYMD;
	}
	public String getPAGE_F_POLI_NO() {
		return PAGE_F_POLI_NO;
	}
	public void setPAGE_F_POLI_NO(String pAGE_F_POLI_NO) {
		PAGE_F_POLI_NO = pAGE_F_POLI_NO;
	}
	public String getPAGE_F_BOHUM_SYMD() {
		return PAGE_F_BOHUM_SYMD;
	}
	public void setPAGE_F_BOHUM_SYMD(String pAGE_F_BOHUM_SYMD) {
		PAGE_F_BOHUM_SYMD = pAGE_F_BOHUM_SYMD;
	}
	public String getPAGE_L_POLI_NO() {
		return PAGE_L_POLI_NO;
	}
	public void setPAGE_L_POLI_NO(String pAGE_L_POLI_NO) {
		PAGE_L_POLI_NO = pAGE_L_POLI_NO;
	}
	public String getPAGE_L_BOHUM_SYMD() {
		return PAGE_L_BOHUM_SYMD;
	}
	public void setPAGE_L_BOHUM_SYMD(String pAGE_L_BOHUM_SYMD) {
		PAGE_L_BOHUM_SYMD = pAGE_L_BOHUM_SYMD;
	}
	public String getSCR_BRIGHT_MAP() {
		return SCR_BRIGHT_MAP;
	}
	public void setSCR_BRIGHT_MAP(String sCR_BRIGHT_MAP) {
		SCR_BRIGHT_MAP = sCR_BRIGHT_MAP;
	}
	public String getH_SCR_CAR_NO_B() {
		return H_SCR_CAR_NO_B;
	}
	public void setH_SCR_CAR_NO_B(String h_SCR_CAR_NO_B) {
		H_SCR_CAR_NO_B = h_SCR_CAR_NO_B;
	}
	public static String getProid() {
		return proid;
	}
	public static String getTrid() {
		return trid;
	}	
}
