package com.idongbu.smartcustomer.vo;

import java.util.List;

import com.idongbu.common.vo.CMMVO;

// 수금방법　조회
public class CmmFUZ5917SVO extends CMMVO {
	
	public CmmFUZ5917SVO() {
		super.setPGMID(this.proid);
		super.setTRID(this.trid);
	}	
	
	public static final String  proid	    = "FUA6003R";
	public static final String trid			= "UA63";
	public String rURL					  = "";

	// 입력
	public String CC_TRAN_CD              ="";
	public String CC_TRAN_FLAG            ="";
	public String CC_NET_RC               ="";
	public String CC_TRAN_G_TIME          ="";
	public String CC_PARTNER_GB           ="";
	public String CC_PARTNER_CD           ="";
	public String CC_SYSFIL               ="";
	public String CC_USER_ID              ="";
	public String CC_PART_GY_COM1         ="";
	public String CC_PART_GY_COM2         ="";
	public String CC_UPMU_BUNRYU1         ="";
	public String CC_UPMU_BUNRYU2         ="";
	public String CC_UPMU_BUNRYU3         ="";
	public String CC_CONTINUE_GB          ="";
	public String CC_COMFIL               ="";
	public String CC_RETURN_CD            ="";
	public String CC_MSG_CD1              ="";
	public String CC_MSG_CD2              ="";
	public String HC_MESSAGE1             ="";
	public String CC_MESSAGE2             ="";
	public String JJ_UPMU_CD              ="";
	public String JJ_MAP_ID               ="";
	public String JJ_CHURI_GUBUN          ="";
	public String JJ_HWAKJUNG_YN          ="";
	public String JJ_SULGYE_NO            ="";
	public String JJ_POLI_NO              ="";
	public String JJ_BESU_CNT             ="";
	public String JJ_YUNGSUJNG_NO         ="";
	public String JJ_JIJUM_CODE           ="";
	public String JJ_JIBU_CODE            ="";
	public String JJ_CHIGB_SABUN          ="";
	public String JJ_GY_JUMIN_NO          ="";
	public String JJ_PB_JUMIN_NO          ="";
	public String JJ_GYEJWA_NO            ="";
	public String JJ_SAGO_JUBSU_NO        ="";
	public String JJ_SAGO_JUBSU_NO2       ="";
	public String JJ_PAGE_TOT_CNT         ="";
	public String JJ_PAGE_TOT_NO          ="";
	public String JJ_PAGE_NO              ="";
	public String JJ_JANGGI_FIL           ="";
	public String HD_BJ_NM                ="";
	
	public String[] HD_BUNNAP_NM = new String[0];
	public String[] DD_ICHE_DD = new String[0];
	public String[] HD_BANK_NM = new String[0];
	public String[] DD_GYEJWA_NO = new String[0];
	public String[] HD_YEGMJU_NM = new String[0];
	public String[] DD_SUGUM_FIL = new String[0];
	public List<SubFGZ5917STBLVO> LIST_DATA = null;
	
	public String DD_FIL				  ="";

	public String getrURL() {
		return rURL;
	}

	public void setrURL(String rURL) {
		this.rURL = rURL;
	}

	public String getCC_TRAN_CD() {
		return CC_TRAN_CD;
	}

	public void setCC_TRAN_CD(String cC_TRAN_CD) {
		CC_TRAN_CD = cC_TRAN_CD;
	}

	public String getCC_TRAN_FLAG() {
		return CC_TRAN_FLAG;
	}

	public void setCC_TRAN_FLAG(String cC_TRAN_FLAG) {
		CC_TRAN_FLAG = cC_TRAN_FLAG;
	}

	public String getCC_NET_RC() {
		return CC_NET_RC;
	}

	public void setCC_NET_RC(String cC_NET_RC) {
		CC_NET_RC = cC_NET_RC;
	}

	public String getCC_TRAN_G_TIME() {
		return CC_TRAN_G_TIME;
	}

	public void setCC_TRAN_G_TIME(String cC_TRAN_G_TIME) {
		CC_TRAN_G_TIME = cC_TRAN_G_TIME;
	}

	public String getCC_PARTNER_GB() {
		return CC_PARTNER_GB;
	}

	public void setCC_PARTNER_GB(String cC_PARTNER_GB) {
		CC_PARTNER_GB = cC_PARTNER_GB;
	}

	public String getCC_PARTNER_CD() {
		return CC_PARTNER_CD;
	}

	public void setCC_PARTNER_CD(String cC_PARTNER_CD) {
		CC_PARTNER_CD = cC_PARTNER_CD;
	}

	public String getCC_SYSFIL() {
		return CC_SYSFIL;
	}

	public void setCC_SYSFIL(String cC_SYSFIL) {
		CC_SYSFIL = cC_SYSFIL;
	}

	public String getCC_USER_ID() {
		return CC_USER_ID;
	}

	public void setCC_USER_ID(String cC_USER_ID) {
		CC_USER_ID = cC_USER_ID;
	}

	public String getCC_PART_GY_COM1() {
		return CC_PART_GY_COM1;
	}

	public void setCC_PART_GY_COM1(String cC_PART_GY_COM1) {
		CC_PART_GY_COM1 = cC_PART_GY_COM1;
	}

	public String getCC_PART_GY_COM2() {
		return CC_PART_GY_COM2;
	}

	public void setCC_PART_GY_COM2(String cC_PART_GY_COM2) {
		CC_PART_GY_COM2 = cC_PART_GY_COM2;
	}

	public String getCC_UPMU_BUNRYU1() {
		return CC_UPMU_BUNRYU1;
	}

	public void setCC_UPMU_BUNRYU1(String cC_UPMU_BUNRYU1) {
		CC_UPMU_BUNRYU1 = cC_UPMU_BUNRYU1;
	}

	public String getCC_UPMU_BUNRYU2() {
		return CC_UPMU_BUNRYU2;
	}

	public void setCC_UPMU_BUNRYU2(String cC_UPMU_BUNRYU2) {
		CC_UPMU_BUNRYU2 = cC_UPMU_BUNRYU2;
	}

	public String getCC_UPMU_BUNRYU3() {
		return CC_UPMU_BUNRYU3;
	}

	public void setCC_UPMU_BUNRYU3(String cC_UPMU_BUNRYU3) {
		CC_UPMU_BUNRYU3 = cC_UPMU_BUNRYU3;
	}

	public String getCC_CONTINUE_GB() {
		return CC_CONTINUE_GB;
	}

	public void setCC_CONTINUE_GB(String cC_CONTINUE_GB) {
		CC_CONTINUE_GB = cC_CONTINUE_GB;
	}

	public String getCC_COMFIL() {
		return CC_COMFIL;
	}

	public void setCC_COMFIL(String cC_COMFIL) {
		CC_COMFIL = cC_COMFIL;
	}

	public String getCC_RETURN_CD() {
		return CC_RETURN_CD;
	}

	public void setCC_RETURN_CD(String cC_RETURN_CD) {
		CC_RETURN_CD = cC_RETURN_CD;
	}

	public String getCC_MSG_CD1() {
		return CC_MSG_CD1;
	}

	public void setCC_MSG_CD1(String cC_MSG_CD1) {
		CC_MSG_CD1 = cC_MSG_CD1;
	}

	public String getCC_MSG_CD2() {
		return CC_MSG_CD2;
	}

	public void setCC_MSG_CD2(String cC_MSG_CD2) {
		CC_MSG_CD2 = cC_MSG_CD2;
	}

	public String getHC_MESSAGE1() {
		return HC_MESSAGE1;
	}

	public void setHC_MESSAGE1(String hC_MESSAGE1) {
		HC_MESSAGE1 = hC_MESSAGE1;
	}

	public String getCC_MESSAGE2() {
		return CC_MESSAGE2;
	}

	public void setCC_MESSAGE2(String cC_MESSAGE2) {
		CC_MESSAGE2 = cC_MESSAGE2;
	}

	public String getJJ_UPMU_CD() {
		return JJ_UPMU_CD;
	}

	public void setJJ_UPMU_CD(String jJ_UPMU_CD) {
		JJ_UPMU_CD = jJ_UPMU_CD;
	}

	public String getJJ_MAP_ID() {
		return JJ_MAP_ID;
	}

	public void setJJ_MAP_ID(String jJ_MAP_ID) {
		JJ_MAP_ID = jJ_MAP_ID;
	}

	public String getJJ_CHURI_GUBUN() {
		return JJ_CHURI_GUBUN;
	}

	public void setJJ_CHURI_GUBUN(String jJ_CHURI_GUBUN) {
		JJ_CHURI_GUBUN = jJ_CHURI_GUBUN;
	}

	public String getJJ_HWAKJUNG_YN() {
		return JJ_HWAKJUNG_YN;
	}

	public void setJJ_HWAKJUNG_YN(String jJ_HWAKJUNG_YN) {
		JJ_HWAKJUNG_YN = jJ_HWAKJUNG_YN;
	}

	public String getJJ_SULGYE_NO() {
		return JJ_SULGYE_NO;
	}

	public void setJJ_SULGYE_NO(String jJ_SULGYE_NO) {
		JJ_SULGYE_NO = jJ_SULGYE_NO;
	}

	public String getJJ_POLI_NO() {
		return JJ_POLI_NO;
	}

	public void setJJ_POLI_NO(String jJ_POLI_NO) {
		JJ_POLI_NO = jJ_POLI_NO;
	}

	public String getJJ_BESU_CNT() {
		return JJ_BESU_CNT;
	}

	public void setJJ_BESU_CNT(String jJ_BESU_CNT) {
		JJ_BESU_CNT = jJ_BESU_CNT;
	}

	public String getJJ_YUNGSUJNG_NO() {
		return JJ_YUNGSUJNG_NO;
	}

	public void setJJ_YUNGSUJNG_NO(String jJ_YUNGSUJNG_NO) {
		JJ_YUNGSUJNG_NO = jJ_YUNGSUJNG_NO;
	}

	public String getJJ_JIJUM_CODE() {
		return JJ_JIJUM_CODE;
	}

	public void setJJ_JIJUM_CODE(String jJ_JIJUM_CODE) {
		JJ_JIJUM_CODE = jJ_JIJUM_CODE;
	}

	public String getJJ_JIBU_CODE() {
		return JJ_JIBU_CODE;
	}

	public void setJJ_JIBU_CODE(String jJ_JIBU_CODE) {
		JJ_JIBU_CODE = jJ_JIBU_CODE;
	}

	public String getJJ_CHIGB_SABUN() {
		return JJ_CHIGB_SABUN;
	}

	public void setJJ_CHIGB_SABUN(String jJ_CHIGB_SABUN) {
		JJ_CHIGB_SABUN = jJ_CHIGB_SABUN;
	}

	public String getJJ_GY_JUMIN_NO() {
		return JJ_GY_JUMIN_NO;
	}

	public void setJJ_GY_JUMIN_NO(String jJ_GY_JUMIN_NO) {
		JJ_GY_JUMIN_NO = jJ_GY_JUMIN_NO;
	}

	public String getJJ_PB_JUMIN_NO() {
		return JJ_PB_JUMIN_NO;
	}

	public void setJJ_PB_JUMIN_NO(String jJ_PB_JUMIN_NO) {
		JJ_PB_JUMIN_NO = jJ_PB_JUMIN_NO;
	}

	public String getJJ_GYEJWA_NO() {
		return JJ_GYEJWA_NO;
	}

	public void setJJ_GYEJWA_NO(String jJ_GYEJWA_NO) {
		JJ_GYEJWA_NO = jJ_GYEJWA_NO;
	}

	public String getJJ_SAGO_JUBSU_NO() {
		return JJ_SAGO_JUBSU_NO;
	}

	public void setJJ_SAGO_JUBSU_NO(String jJ_SAGO_JUBSU_NO) {
		JJ_SAGO_JUBSU_NO = jJ_SAGO_JUBSU_NO;
	}

	public String getJJ_SAGO_JUBSU_NO2() {
		return JJ_SAGO_JUBSU_NO2;
	}

	public void setJJ_SAGO_JUBSU_NO2(String jJ_SAGO_JUBSU_NO2) {
		JJ_SAGO_JUBSU_NO2 = jJ_SAGO_JUBSU_NO2;
	}

	public String getJJ_PAGE_TOT_CNT() {
		return JJ_PAGE_TOT_CNT;
	}

	public void setJJ_PAGE_TOT_CNT(String jJ_PAGE_TOT_CNT) {
		JJ_PAGE_TOT_CNT = jJ_PAGE_TOT_CNT;
	}

	public String getJJ_PAGE_TOT_NO() {
		return JJ_PAGE_TOT_NO;
	}

	public void setJJ_PAGE_TOT_NO(String jJ_PAGE_TOT_NO) {
		JJ_PAGE_TOT_NO = jJ_PAGE_TOT_NO;
	}

	public String getJJ_PAGE_NO() {
		return JJ_PAGE_NO;
	}

	public void setJJ_PAGE_NO(String jJ_PAGE_NO) {
		JJ_PAGE_NO = jJ_PAGE_NO;
	}

	public String getJJ_JANGGI_FIL() {
		return JJ_JANGGI_FIL;
	}

	public void setJJ_JANGGI_FIL(String jJ_JANGGI_FIL) {
		JJ_JANGGI_FIL = jJ_JANGGI_FIL;
	}

	public String getHD_BJ_NM() {
		return HD_BJ_NM;
	}

	public void setHD_BJ_NM(String hD_BJ_NM) {
		HD_BJ_NM = hD_BJ_NM;
	}

	public String[] getHD_BUNNAP_NM() {
		return HD_BUNNAP_NM;
	}

	public void setHD_BUNNAP_NM(String[] hD_BUNNAP_NM) {
		HD_BUNNAP_NM = hD_BUNNAP_NM;
	}

	public String[] getDD_ICHE_DD() {
		return DD_ICHE_DD;
	}

	public void setDD_ICHE_DD(String[] dD_ICHE_DD) {
		DD_ICHE_DD = dD_ICHE_DD;
	}

	public String[] getHD_BANK_NM() {
		return HD_BANK_NM;
	}

	public void setHD_BANK_NM(String[] hD_BANK_NM) {
		HD_BANK_NM = hD_BANK_NM;
	}

	public String[] getDD_GYEJWA_NO() {
		return DD_GYEJWA_NO;
	}

	public void setDD_GYEJWA_NO(String[] dD_GYEJWA_NO) {
		DD_GYEJWA_NO = dD_GYEJWA_NO;
	}

	public String[] getHD_YEGMJU_NM() {
		return HD_YEGMJU_NM;
	}

	public void setHD_YEGMJU_NM(String[] hD_YEGMJU_NM) {
		HD_YEGMJU_NM = hD_YEGMJU_NM;
	}

	public String[] getDD_SUGUM_FIL() {
		return DD_SUGUM_FIL;
	}

	public void setDD_SUGUM_FIL(String[] dD_SUGUM_FIL) {
		DD_SUGUM_FIL = dD_SUGUM_FIL;
	}

	public String getDD_FIL() {
		return DD_FIL;
	}

	public void setDD_FIL(String dD_FIL) {
		DD_FIL = dD_FIL;
	}

	public static String getTrid() {
		return trid;
	}

	public List<SubFGZ5917STBLVO> getLIST_DATA() {
		return LIST_DATA;
	}

	public void setLIST_DATA(List<SubFGZ5917STBLVO> lIST_DATA) {
		LIST_DATA = lIST_DATA;
	}
}
