package com.idongbu.smartcustomer.vo;

public class SubFBM0300RVO {
	//LOOP-DATA	OCCURS  10 
	public String SI_L_SELECT_FLAG       = "";
	public String SO_L_POLI_NO           = "";	//증권번호	
	public String HO_L_CAR_NO            = "";  //차량번호
	public String SO_L_BOJONG_CD         = "";  //보종코드
	public String HO_L_BOJONG_NM         = "";  //보종명
	public String SO_L_GOGEK_GB          = "";  //고객구분
	public String HO_L_GOGEK_GB_NM       = "";  //고객구분명
	public String SO_L_BOHUM_SYMD        = "";  //보험시기
	public String SO_L_BOHUM_EYMD        = "";  //보험종기
	public String SO_L_GEYAK_SANGTE      = "";  //계약상태
	public String HO_L_GEYAK_SANGTE_NM   = "";  //계약상태명
	public String SI_L_SURYUNG_GB        = "";  //수령처구분
	public String SI_L_SINGU_GB          = "";  //주소 신구여부(1:신,2:구,SPACE:구)
	
	public String inpd_dvcd = "";				//보종구분코드
	public String eta_dpp_mngt_no = "";			//기타발송처관리번호
	
	public String getSI_L_SELECT_FLAG() {
		return SI_L_SELECT_FLAG;
	}
	public void setSI_L_SELECT_FLAG(String sI_L_SELECT_FLAG) {
		SI_L_SELECT_FLAG = sI_L_SELECT_FLAG;
	}
	public String getSO_L_POLI_NO() {
		return SO_L_POLI_NO;
	}
	public void setSO_L_POLI_NO(String sO_L_POLI_NO) {
		SO_L_POLI_NO = sO_L_POLI_NO;
	}
	public String getHO_L_CAR_NO() {
		return HO_L_CAR_NO;
	}
	public void setHO_L_CAR_NO(String hO_L_CAR_NO) {
		HO_L_CAR_NO = hO_L_CAR_NO;
	}
	public String getSO_L_BOJONG_CD() {
		return SO_L_BOJONG_CD;
	}
	public void setSO_L_BOJONG_CD(String sO_L_BOJONG_CD) {
		SO_L_BOJONG_CD = sO_L_BOJONG_CD;
	}
	public String getHO_L_BOJONG_NM() {
		return HO_L_BOJONG_NM;
	}
	public void setHO_L_BOJONG_NM(String hO_L_BOJONG_NM) {
		HO_L_BOJONG_NM = hO_L_BOJONG_NM;
	}
	public String getSO_L_GOGEK_GB() {
		return SO_L_GOGEK_GB;
	}
	public void setSO_L_GOGEK_GB(String sO_L_GOGEK_GB) {
		SO_L_GOGEK_GB = sO_L_GOGEK_GB;
	}
	public String getHO_L_GOGEK_GB_NM() {
		return HO_L_GOGEK_GB_NM;
	}
	public void setHO_L_GOGEK_GB_NM(String hO_L_GOGEK_GB_NM) {
		HO_L_GOGEK_GB_NM = hO_L_GOGEK_GB_NM;
	}
	public String getSO_L_BOHUM_SYMD() {
		return SO_L_BOHUM_SYMD;
	}
	public void setSO_L_BOHUM_SYMD(String sO_L_BOHUM_SYMD) {
		SO_L_BOHUM_SYMD = sO_L_BOHUM_SYMD;
	}
	public String getSO_L_BOHUM_EYMD() {
		return SO_L_BOHUM_EYMD;
	}
	public void setSO_L_BOHUM_EYMD(String sO_L_BOHUM_EYMD) {
		SO_L_BOHUM_EYMD = sO_L_BOHUM_EYMD;
	}
	public String getSO_L_GEYAK_SANGTE() {
		return SO_L_GEYAK_SANGTE;
	}
	public void setSO_L_GEYAK_SANGTE(String sO_L_GEYAK_SANGTE) {
		SO_L_GEYAK_SANGTE = sO_L_GEYAK_SANGTE;
	}
	public String getHO_L_GEYAK_SANGTE_NM() {
		return HO_L_GEYAK_SANGTE_NM;
	}
	public void setHO_L_GEYAK_SANGTE_NM(String hO_L_GEYAK_SANGTE_NM) {
		HO_L_GEYAK_SANGTE_NM = hO_L_GEYAK_SANGTE_NM;
	}
	public String getSI_L_SURYUNG_GB() {
		return SI_L_SURYUNG_GB;
	}
	public void setSI_L_SURYUNG_GB(String sI_L_SURYUNG_GB) {
		SI_L_SURYUNG_GB = sI_L_SURYUNG_GB;
	}
	public String getSI_L_SINGU_GB() {
		return SI_L_SINGU_GB;
	}
	public void setSI_L_SINGU_GB(String sI_L_SINGU_GB) {
		SI_L_SINGU_GB = sI_L_SINGU_GB;
	}
	
	public String getInpd_dvcd() {
		return inpd_dvcd;
	}
	public void setInpd_dvcd(String inpd_dvcd) {
		this.inpd_dvcd = inpd_dvcd;
	}
	public String getEta_dpp_mngt_no() {
		return eta_dpp_mngt_no;
	}
	public void setEta_dpp_mngt_no(String eta_dpp_mngt_no) {
		this.eta_dpp_mngt_no = eta_dpp_mngt_no;
	}
}
