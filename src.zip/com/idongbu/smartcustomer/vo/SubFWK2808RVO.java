package com.idongbu.smartcustomer.vo;

public class SubFWK2808RVO {
	public String H_LK_WK2808_GIBON_DAMBO  = null;
	public String LK_WK2808_DAMBO_GAIP_AMT = null;
	public String H_LK_WK2808_TKYAK_DAMBO  = null;
	public String LK_WK2808_TKYAK_GAIP_AMT = null;
	
	
	public String getH_LK_WK2808_GIBON_DAMBO() {
		return H_LK_WK2808_GIBON_DAMBO;
	}
	public void setH_LK_WK2808_GIBON_DAMBO(String h_LK_WK2808_GIBON_DAMBO) {
		H_LK_WK2808_GIBON_DAMBO = h_LK_WK2808_GIBON_DAMBO;
	}
	public String getLK_WK2808_DAMBO_GAIP_AMT() {
		return LK_WK2808_DAMBO_GAIP_AMT;
	}
	public void setLK_WK2808_DAMBO_GAIP_AMT(String lK_WK2808_DAMBO_GAIP_AMT) {
		LK_WK2808_DAMBO_GAIP_AMT = lK_WK2808_DAMBO_GAIP_AMT;
	}
	public String getH_LK_WK2808_TKYAK_DAMBO() {
		return H_LK_WK2808_TKYAK_DAMBO;
	}
	public void setH_LK_WK2808_TKYAK_DAMBO(String h_LK_WK2808_TKYAK_DAMBO) {
		H_LK_WK2808_TKYAK_DAMBO = h_LK_WK2808_TKYAK_DAMBO;
	}
	public String getLK_WK2808_TKYAK_GAIP_AMT() {
		return LK_WK2808_TKYAK_GAIP_AMT;
	}
	public void setLK_WK2808_TKYAK_GAIP_AMT(String lK_WK2808_TKYAK_GAIP_AMT) {
		LK_WK2808_TKYAK_GAIP_AMT = lK_WK2808_TKYAK_GAIP_AMT;
	}
}
