package com.idongbu.smartcustomer.vo;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.idongbu.common.vo.CMMVO;

public class CmmFBM9074RVO extends CMMVO {
	
	public CmmFBM9074RVO() {
		super.setPGMID(this.proid);
		super.setTRID(this.trid);
	}

	private static final String proid		= "FBM9074R";
	private static final String trid		= "BMAY";
	private String rURL						= "";
	
	private String COMM_CHANNEL;   
	private String COMM_UNIQUE_KEY;
	private String COMM_PGMID;     
	private String COMM_PROC_GB;   
	private String COMM_ACTION_KEY;
	private String COMM_USER_GB; 
	private String COMM_USER_ID;
	private String COMM_JIJUM_CD;
	private String COMM_JIBU_CD; 
	private String COMM_PROTOCOL;    
	private String COMM_COND_CD;     
	private String COMM_LAST_FLAG;   
	private String COMM_CURSOR_MAP;  
	private String COMM_CURSOR_IDX;  
	private String COMM_MESSAGE_CD;  
	private String H_COMM_MESSAGE_NM;
	private String COMM_ERR_NAME;
	private String COMM_ERR_TEXT;
	private String COMM_SYS_CODE;
	private String COMM_FILLER;

	private String ARS_LENGTH;    
	private String ARS_PROCESS_ID;
	private String SCR_K_GOGEK_NO;
	private String SCR_K_CAR_NO;  
	private String SCR_K_SVC_CD;
	private String SCR_DASU_CAR;
	private String H_SCR_CAR_NO;     
	private String SCR_POLI_NO;       
	private String SCR_PIBO_CD;       
	private String H_SCR_PIBO_NAME;   
	private String SCR_BJ_CD;         
	private String H_SCR_BOJONG_NM;   
	private String SCR_CHAJONG_CD;    
	private String H_SCR_CHAJONG_NM;  
	private String SCR_CAR_CD;        
	private String H_SCR_CAR_NM;      
	private String H_SCR_SUHE_NM;     
	private String SCR_SAYU_CD;       
	private String SCR_TKYAK_GB;
	private String H_SCR_TKYAK_NM;    
	private String H_SCR_DAN_GB;      
	private String SCR_CHIGPJA_CD;    
	private String SCR_CHANNEL_CD;
	private String SCR_BOHUM_SYMD;
	private String SCR_BOHUM_EYMD;
	private String SCR_DBRT_GB;   
	private String SCR_ELECTRIC_GB;  
	private String SCR_CHULRYUKRYANG;
	private String SCR_BEGIRYANG;  
	private String SCR_JUKJE_TON;  
	private String SCR_JUNGWON_CNT;
	private String SCR_JADONG_GB;
	private String SCR_OVERLAP_YN;
	private String SCR_MI_YN;     
	private String SCR_GYUNIN_YN;
	private String SCR_TKYAK_CNT;     
	private String SCR_TKYAK_GAIP_CNT;
	private String SCR_N_SVC_CNT;     
	private String SCR_P_SVC_CNT;     
	private String SCR_T_SVC_CNT;     
	private String SCR_UNBAN_YN; 
	private String SCR_ABS_GB;   
	private String SCR_AUTO_GB;  
	private String SCR_GPYU_YN;
	private String SCR_NOTRECALL_YN;
	private String H_SCR_UJ_TKYAK;  
	private String H_SCR_UJ_NAME;   
	private String SCR_UJ_JUMIN_NO; 
	private String SCR_UJ_YUNRYUNG; 
	private String SCR_UJ_GWANGE_CD;
	private String H_SCR_UJ_GWANGE; 
	private String SCR_MILEAGE_YN;
	private String SCR_MILEAGE_SMS_YN;
	public List<Map<String,Object>> TKYAK_LIST = null;
	
	public String getrURL() {
		return rURL;
	}
	public void setrURL(String rURL) {
		this.rURL = rURL;
	}
	public String getCOMM_CHANNEL() {
		return COMM_CHANNEL;
	}
	public void setCOMM_CHANNEL(String cOMM_CHANNEL) {
		COMM_CHANNEL = cOMM_CHANNEL;
	}
	public String getCOMM_UNIQUE_KEY() {
		return COMM_UNIQUE_KEY;
	}
	public void setCOMM_UNIQUE_KEY(String cOMM_UNIQUE_KEY) {
		COMM_UNIQUE_KEY = cOMM_UNIQUE_KEY;
	}
	public String getCOMM_PGMID() {
		return COMM_PGMID;
	}
	public void setCOMM_PGMID(String cOMM_PGMID) {
		COMM_PGMID = cOMM_PGMID;
	}
	public String getCOMM_PROC_GB() {
		return COMM_PROC_GB;
	}
	public void setCOMM_PROC_GB(String cOMM_PROC_GB) {
		COMM_PROC_GB = cOMM_PROC_GB;
	}
	public String getCOMM_ACTION_KEY() {
		return COMM_ACTION_KEY;
	}
	public void setCOMM_ACTION_KEY(String cOMM_ACTION_KEY) {
		COMM_ACTION_KEY = cOMM_ACTION_KEY;
	}
	public String getCOMM_USER_GB() {
		return COMM_USER_GB;
	}
	public void setCOMM_USER_GB(String cOMM_USER_GB) {
		COMM_USER_GB = cOMM_USER_GB;
	}
	public String getCOMM_USER_ID() {
		return COMM_USER_ID;
	}
	public void setCOMM_USER_ID(String cOMM_USER_ID) {
		COMM_USER_ID = cOMM_USER_ID;
	}
	public String getCOMM_JIJUM_CD() {
		return COMM_JIJUM_CD;
	}
	public void setCOMM_JIJUM_CD(String cOMM_JIJUM_CD) {
		COMM_JIJUM_CD = cOMM_JIJUM_CD;
	}
	public String getCOMM_JIBU_CD() {
		return COMM_JIBU_CD;
	}
	public void setCOMM_JIBU_CD(String cOMM_JIBU_CD) {
		COMM_JIBU_CD = cOMM_JIBU_CD;
	}
	public String getCOMM_PROTOCOL() {
		return COMM_PROTOCOL;
	}
	public void setCOMM_PROTOCOL(String cOMM_PROTOCOL) {
		COMM_PROTOCOL = cOMM_PROTOCOL;
	}
	public String getCOMM_COND_CD() {
		return COMM_COND_CD;
	}
	public void setCOMM_COND_CD(String cOMM_COND_CD) {
		COMM_COND_CD = cOMM_COND_CD;
	}
	public String getCOMM_LAST_FLAG() {
		return COMM_LAST_FLAG;
	}
	public void setCOMM_LAST_FLAG(String cOMM_LAST_FLAG) {
		COMM_LAST_FLAG = cOMM_LAST_FLAG;
	}
	public String getCOMM_CURSOR_MAP() {
		return COMM_CURSOR_MAP;
	}
	public void setCOMM_CURSOR_MAP(String cOMM_CURSOR_MAP) {
		COMM_CURSOR_MAP = cOMM_CURSOR_MAP;
	}
	public String getCOMM_CURSOR_IDX() {
		return COMM_CURSOR_IDX;
	}
	public void setCOMM_CURSOR_IDX(String cOMM_CURSOR_IDX) {
		COMM_CURSOR_IDX = cOMM_CURSOR_IDX;
	}
	public String getCOMM_MESSAGE_CD() {
		return COMM_MESSAGE_CD;
	}
	public void setCOMM_MESSAGE_CD(String cOMM_MESSAGE_CD) {
		COMM_MESSAGE_CD = cOMM_MESSAGE_CD;
	}
	public String getH_COMM_MESSAGE_NM() {
		return H_COMM_MESSAGE_NM;
	}
	public void setH_COMM_MESSAGE_NM(String h_COMM_MESSAGE_NM) {
		H_COMM_MESSAGE_NM = h_COMM_MESSAGE_NM;
	}
	public String getCOMM_ERR_NAME() {
		return COMM_ERR_NAME;
	}
	public void setCOMM_ERR_NAME(String cOMM_ERR_NAME) {
		COMM_ERR_NAME = cOMM_ERR_NAME;
	}
	public String getCOMM_ERR_TEXT() {
		return COMM_ERR_TEXT;
	}
	public void setCOMM_ERR_TEXT(String cOMM_ERR_TEXT) {
		COMM_ERR_TEXT = cOMM_ERR_TEXT;
	}
	public String getCOMM_SYS_CODE() {
		return COMM_SYS_CODE;
	}
	public void setCOMM_SYS_CODE(String cOMM_SYS_CODE) {
		COMM_SYS_CODE = cOMM_SYS_CODE;
	}
	public String getCOMM_FILLER() {
		return COMM_FILLER;
	}
	public void setCOMM_FILLER(String cOMM_FILLER) {
		COMM_FILLER = cOMM_FILLER;
	}
	public String getARS_LENGTH() {
		return ARS_LENGTH;
	}
	public void setARS_LENGTH(String aRS_LENGTH) {
		ARS_LENGTH = aRS_LENGTH;
	}
	public String getARS_PROCESS_ID() {
		return ARS_PROCESS_ID;
	}
	public void setARS_PROCESS_ID(String aRS_PROCESS_ID) {
		ARS_PROCESS_ID = aRS_PROCESS_ID;
	}
	public String getSCR_K_GOGEK_NO() {
		return SCR_K_GOGEK_NO;
	}
	public void setSCR_K_GOGEK_NO(String sCR_K_GOGEK_NO) {
		SCR_K_GOGEK_NO = sCR_K_GOGEK_NO;
	}
	public String getSCR_K_CAR_NO() {
		return SCR_K_CAR_NO;
	}
	public void setSCR_K_CAR_NO(String sCR_K_CAR_NO) {
		SCR_K_CAR_NO = sCR_K_CAR_NO;
	}
	public String getSCR_K_SVC_CD() {
		return SCR_K_SVC_CD;
	}
	public void setSCR_K_SVC_CD(String sCR_K_SVC_CD) {
		SCR_K_SVC_CD = sCR_K_SVC_CD;
	}
	public String getSCR_DASU_CAR() {
		return SCR_DASU_CAR;
	}
	public void setSCR_DASU_CAR(String sCR_DASU_CAR) {
		SCR_DASU_CAR = sCR_DASU_CAR;
	}
	public String getH_SCR_CAR_NO() {
		return H_SCR_CAR_NO;
	}
	public void setH_SCR_CAR_NO(String h_SCR_CAR_NO) {
		H_SCR_CAR_NO = h_SCR_CAR_NO;
	}
	public String getSCR_POLI_NO() {
		return SCR_POLI_NO;
	}
	public void setSCR_POLI_NO(String sCR_POLI_NO) {
		SCR_POLI_NO = sCR_POLI_NO;
	}
	public String getSCR_PIBO_CD() {
		return SCR_PIBO_CD;
	}
	public void setSCR_PIBO_CD(String sCR_PIBO_CD) {
		SCR_PIBO_CD = sCR_PIBO_CD;
	}
	public String getH_SCR_PIBO_NAME() {
		return H_SCR_PIBO_NAME;
	}
	public void setH_SCR_PIBO_NAME(String h_SCR_PIBO_NAME) {
		H_SCR_PIBO_NAME = h_SCR_PIBO_NAME;
	}
	public String getSCR_BJ_CD() {
		return SCR_BJ_CD;
	}
	public void setSCR_BJ_CD(String sCR_BJ_CD) {
		SCR_BJ_CD = sCR_BJ_CD;
	}
	public String getH_SCR_BOJONG_NM() {
		return H_SCR_BOJONG_NM;
	}
	public void setH_SCR_BOJONG_NM(String h_SCR_BOJONG_NM) {
		H_SCR_BOJONG_NM = h_SCR_BOJONG_NM;
	}
	public String getSCR_CHAJONG_CD() {
		return SCR_CHAJONG_CD;
	}
	public void setSCR_CHAJONG_CD(String sCR_CHAJONG_CD) {
		SCR_CHAJONG_CD = sCR_CHAJONG_CD;
	}
	public String getH_SCR_CHAJONG_NM() {
		return H_SCR_CHAJONG_NM;
	}
	public void setH_SCR_CHAJONG_NM(String h_SCR_CHAJONG_NM) {
		H_SCR_CHAJONG_NM = h_SCR_CHAJONG_NM;
	}
	public String getSCR_CAR_CD() {
		return SCR_CAR_CD;
	}
	public void setSCR_CAR_CD(String sCR_CAR_CD) {
		SCR_CAR_CD = sCR_CAR_CD;
	}
	public String getH_SCR_CAR_NM() {
		return H_SCR_CAR_NM;
	}
	public void setH_SCR_CAR_NM(String h_SCR_CAR_NM) {
		H_SCR_CAR_NM = h_SCR_CAR_NM;
	}
	public String getH_SCR_SUHE_NM() {
		return H_SCR_SUHE_NM;
	}
	public void setH_SCR_SUHE_NM(String h_SCR_SUHE_NM) {
		H_SCR_SUHE_NM = h_SCR_SUHE_NM;
	}
	public String getSCR_SAYU_CD() {
		return SCR_SAYU_CD;
	}
	public void setSCR_SAYU_CD(String sCR_SAYU_CD) {
		SCR_SAYU_CD = sCR_SAYU_CD;
	}
	public String getSCR_TKYAK_GB() {
		return SCR_TKYAK_GB;
	}
	public void setSCR_TKYAK_GB(String sCR_TKYAK_GB) {
		SCR_TKYAK_GB = sCR_TKYAK_GB;
	}
	public String getH_SCR_TKYAK_NM() {
		return H_SCR_TKYAK_NM;
	}
	public void setH_SCR_TKYAK_NM(String h_SCR_TKYAK_NM) {
		H_SCR_TKYAK_NM = h_SCR_TKYAK_NM;
	}
	public String getH_SCR_DAN_GB() {
		return H_SCR_DAN_GB;
	}
	public void setH_SCR_DAN_GB(String h_SCR_DAN_GB) {
		H_SCR_DAN_GB = h_SCR_DAN_GB;
	}
	public String getSCR_CHIGPJA_CD() {
		return SCR_CHIGPJA_CD;
	}
	public void setSCR_CHIGPJA_CD(String sCR_CHIGPJA_CD) {
		SCR_CHIGPJA_CD = sCR_CHIGPJA_CD;
	}
	public String getSCR_CHANNEL_CD() {
		return SCR_CHANNEL_CD;
	}
	public void setSCR_CHANNEL_CD(String sCR_CHANNEL_CD) {
		SCR_CHANNEL_CD = sCR_CHANNEL_CD;
	}
	public String getSCR_BOHUM_SYMD() {
		return SCR_BOHUM_SYMD;
	}
	public void setSCR_BOHUM_SYMD(String sCR_BOHUM_SYMD) {
		SCR_BOHUM_SYMD = sCR_BOHUM_SYMD;
	}
	public String getSCR_BOHUM_EYMD() {
		return SCR_BOHUM_EYMD;
	}
	public void setSCR_BOHUM_EYMD(String sCR_BOHUM_EYMD) {
		SCR_BOHUM_EYMD = sCR_BOHUM_EYMD;
	}
	public String getSCR_DBRT_GB() {
		return SCR_DBRT_GB;
	}
	public void setSCR_DBRT_GB(String sCR_DBRT_GB) {
		SCR_DBRT_GB = sCR_DBRT_GB;
	}
	public String getSCR_ELECTRIC_GB() {
		return SCR_ELECTRIC_GB;
	}
	public void setSCR_ELECTRIC_GB(String sCR_ELECTRIC_GB) {
		SCR_ELECTRIC_GB = sCR_ELECTRIC_GB;
	}
	public String getSCR_CHULRYUKRYANG() {
		return SCR_CHULRYUKRYANG;
	}
	public void setSCR_CHULRYUKRYANG(String sCR_CHULRYUKRYANG) {
		SCR_CHULRYUKRYANG = sCR_CHULRYUKRYANG;
	}
	public String getSCR_BEGIRYANG() {
		return SCR_BEGIRYANG;
	}
	public void setSCR_BEGIRYANG(String sCR_BEGIRYANG) {
		SCR_BEGIRYANG = sCR_BEGIRYANG;
	}
	public String getSCR_JUKJE_TON() {
		return SCR_JUKJE_TON;
	}
	public void setSCR_JUKJE_TON(String sCR_JUKJE_TON) {
		SCR_JUKJE_TON = sCR_JUKJE_TON;
	}
	public String getSCR_JUNGWON_CNT() {
		return SCR_JUNGWON_CNT;
	}
	public void setSCR_JUNGWON_CNT(String sCR_JUNGWON_CNT) {
		SCR_JUNGWON_CNT = sCR_JUNGWON_CNT;
	}
	public String getSCR_JADONG_GB() {
		return SCR_JADONG_GB;
	}
	public void setSCR_JADONG_GB(String sCR_JADONG_GB) {
		SCR_JADONG_GB = sCR_JADONG_GB;
	}
	public String getSCR_OVERLAP_YN() {
		return SCR_OVERLAP_YN;
	}
	public void setSCR_OVERLAP_YN(String sCR_OVERLAP_YN) {
		SCR_OVERLAP_YN = sCR_OVERLAP_YN;
	}
	public String getSCR_MI_YN() {
		return SCR_MI_YN;
	}
	public void setSCR_MI_YN(String sCR_MI_YN) {
		SCR_MI_YN = sCR_MI_YN;
	}
	public String getSCR_GYUNIN_YN() {
		return SCR_GYUNIN_YN;
	}
	public void setSCR_GYUNIN_YN(String sCR_GYUNIN_YN) {
		SCR_GYUNIN_YN = sCR_GYUNIN_YN;
	}
	public String getSCR_TKYAK_CNT() {
		return SCR_TKYAK_CNT;
	}
	public void setSCR_TKYAK_CNT(String sCR_TKYAK_CNT) {
		SCR_TKYAK_CNT = sCR_TKYAK_CNT;
	}
	public String getSCR_TKYAK_GAIP_CNT() {
		return SCR_TKYAK_GAIP_CNT;
	}
	public void setSCR_TKYAK_GAIP_CNT(String sCR_TKYAK_GAIP_CNT) {
		SCR_TKYAK_GAIP_CNT = sCR_TKYAK_GAIP_CNT;
	}
	public String getSCR_N_SVC_CNT() {
		return SCR_N_SVC_CNT;
	}
	public void setSCR_N_SVC_CNT(String sCR_N_SVC_CNT) {
		SCR_N_SVC_CNT = sCR_N_SVC_CNT;
	}
	public String getSCR_P_SVC_CNT() {
		return SCR_P_SVC_CNT;
	}
	public void setSCR_P_SVC_CNT(String sCR_P_SVC_CNT) {
		SCR_P_SVC_CNT = sCR_P_SVC_CNT;
	}
	public String getSCR_T_SVC_CNT() {
		return SCR_T_SVC_CNT;
	}
	public void setSCR_T_SVC_CNT(String sCR_T_SVC_CNT) {
		SCR_T_SVC_CNT = sCR_T_SVC_CNT;
	}
	public String getSCR_UNBAN_YN() {
		return SCR_UNBAN_YN;
	}
	public void setSCR_UNBAN_YN(String sCR_UNBAN_YN) {
		SCR_UNBAN_YN = sCR_UNBAN_YN;
	}
	public String getSCR_ABS_GB() {
		return SCR_ABS_GB;
	}
	public void setSCR_ABS_GB(String sCR_ABS_GB) {
		SCR_ABS_GB = sCR_ABS_GB;
	}
	public String getSCR_AUTO_GB() {
		return SCR_AUTO_GB;
	}
	public void setSCR_AUTO_GB(String sCR_AUTO_GB) {
		SCR_AUTO_GB = sCR_AUTO_GB;
	}
	public String getSCR_GPYU_YN() {
		return SCR_GPYU_YN;
	}
	public void setSCR_GPYU_YN(String sCR_GPYU_YN) {
		SCR_GPYU_YN = sCR_GPYU_YN;
	}
	public String getSCR_NOTRECALL_YN() {
		return SCR_NOTRECALL_YN;
	}
	public void setSCR_NOTRECALL_YN(String sCR_NOTRECALL_YN) {
		SCR_NOTRECALL_YN = sCR_NOTRECALL_YN;
	}
	public String getH_SCR_UJ_TKYAK() {
		return H_SCR_UJ_TKYAK;
	}
	public void setH_SCR_UJ_TKYAK(String h_SCR_UJ_TKYAK) {
		H_SCR_UJ_TKYAK = h_SCR_UJ_TKYAK;
	}
	public String getH_SCR_UJ_NAME() {
		return H_SCR_UJ_NAME;
	}
	public void setH_SCR_UJ_NAME(String h_SCR_UJ_NAME) {
		H_SCR_UJ_NAME = h_SCR_UJ_NAME;
	}
	public String getSCR_UJ_JUMIN_NO() {
		return SCR_UJ_JUMIN_NO;
	}
	public void setSCR_UJ_JUMIN_NO(String sCR_UJ_JUMIN_NO) {
		SCR_UJ_JUMIN_NO = sCR_UJ_JUMIN_NO;
	}
	public String getSCR_UJ_YUNRYUNG() {
		return SCR_UJ_YUNRYUNG;
	}
	public void setSCR_UJ_YUNRYUNG(String sCR_UJ_YUNRYUNG) {
		SCR_UJ_YUNRYUNG = sCR_UJ_YUNRYUNG;
	}
	public String getSCR_UJ_GWANGE_CD() {
		return SCR_UJ_GWANGE_CD;
	}
	public void setSCR_UJ_GWANGE_CD(String sCR_UJ_GWANGE_CD) {
		SCR_UJ_GWANGE_CD = sCR_UJ_GWANGE_CD;
	}
	public String getH_SCR_UJ_GWANGE() {
		return H_SCR_UJ_GWANGE;
	}
	public void setH_SCR_UJ_GWANGE(String h_SCR_UJ_GWANGE) {
		H_SCR_UJ_GWANGE = h_SCR_UJ_GWANGE;
	}
	public String getSCR_MILEAGE_YN() {
		return SCR_MILEAGE_YN;
	}
	public void setSCR_MILEAGE_YN(String sCR_MILEAGE_YN) {
		SCR_MILEAGE_YN = sCR_MILEAGE_YN;
	}
	public String getSCR_MILEAGE_SMS_YN() {
		return SCR_MILEAGE_SMS_YN;
	}
	public void setSCR_MILEAGE_SMS_YN(String sCR_MILEAGE_SMS_YN) {
		SCR_MILEAGE_SMS_YN = sCR_MILEAGE_SMS_YN;
	}
	public static String getProid() {
		return proid;
	}
	public static String getTrid() {
		return trid;
	}
	public List<Map<String, Object>> getTKYAK_LIST() {
		return TKYAK_LIST;
	}
	public void setTKYAK_LIST(List<Map<String, Object>> tKYAK_LIST) {
		TKYAK_LIST = tKYAK_LIST;
	}

	
}
