package com.idongbu.smartcustomer.vo;

import java.util.List;

import com.idongbu.common.vo.CMMVO;

public class CyConVO extends CMMVO {
	private String ssnUserJumin             = ""; // 2차 CmmVO에서 상속
	private String ssnUserName              = ""; // 2차 CmmVO에서 상속
	
	private String fd_mb_email              = "";
	private String fd_mb_haddress           = "";
	private String fd_mb_haddress2          = "";
                                           
	private String so_bj_gb                 = "";
	private String so_bj_cd                 = "";
	private String so_poli_no               = ""; 
	private String so_poli_no_main          = "";
	private String name                     = "";
	private String phone                    = "";
	private String so_pa_mail               = "";
	private String gy_jumn_no	            = "";
	private String so_jumin_no              = "";
	private String cust_addr                = ""; //피보험자주소
	private String contact_addr             = ""; //보험계약자주소
	private String suikja_addr              = ""; //사망보험금 수익자 주소
	private String so_bojong_nm             = "";
	private String so_bohum_gigan_symd      = "";
	private String so_bohum_gigan_eymd      = "";
	private String so_hj_bank_nm			= "";
	private String so_jj_gyejwa_no1         = "";
	private String so_hj_yegmju             = "";
	private String so_jj_iche_dd            = "";
	private String so_jj_last_ym            = "";
	private String so_hj_sangte_nm          = "";
	private String so_hj_dechul_nm          = "";
	private String so_hj_ipchulgm			= "";
	private String jj_gyejwa_no				= "";
	private String so_jj_bank_cd			= "";
	private String so_jj_bank_code			= "";
	private String so_jj_iche_d				= "";
	private String so_chungyak_ymd			= "";	//청약일자
	private String so_gaip_type1			= "";	//가입유형1
	private String so_bohum_eymd			= "";	//보험기간종기
	private String so_bohum_symd			= "";	//보험기간시기
	
	//업종추가                             
	private String upjongNm                 = "";
	                                       
	private String SAYONG_YONGDO_CD         = "";
	private String SAYONG_SEBU              = "";
	private String TUKYAK_limits            = "";
	private String TUKYAK_age               = "";
	private String strDtk                   = "";
	private String BUNNAP_BANGCD            = "";
	private String LK_GA1085_BULIP_CNT      = "";
	private String Napip_Date               = "";
	private String PIB_TEL_NO               = "";
	private String GYE_TEL_NO               = "";
	private String TUKYAK_UNJUNJA           = "";
	private String TUKYAK_jadongiche        = "";
	                                       
	//사망금수익자                         
	private String TEMP_SUIKJA_GOGEKNO      = "";
	private String TEMP_SUIKJA_ZIP          = "";
	private String TEMP_SUIKJA_ADDR         = "";
	private String TEMP_SUIKJA_HP_TEL1_NO   = "";
	private String TEMP_SUIKJA_HOME_TEL2_NO = "";
	

	private String[] TUKYAK_CD 	            = new String[0];
	private String[] TUKYAK_RATE            = new String[0];
	private String[] TUKBUL_CD 	            = new String[0];
	private String[] TUKBUL_RATE            = new String[0];
	
	private String HJ_BJ_NM                 = "";
	private String HJ_BJ_CD                 = "";
	private String HJ_BIGO                  = "";
	private String HJ_GYEYAK_NM             = "";
	private String HJ_PIBO_NM               = "";
	private String HJ_CHIGUB_NM             = "";
	private String JJ_BOHUM_GIGANCD         = "";
	private String JJ_BOHUM_GIGAN_S         = "";
	private String JJ_BOHUM_GIGAN_E         = "";
	private String JJ_CHIGUB_TEL            = "";
	private String JJ_GAIP_TYPE             = "";
	private String JJ_GYEYAK_JMNO           = "";
	private String JJ_PIBO_JMNO           = ""; // 3차 추가
	private String JJ_JUPSU                 = "";
	private String JJ_POLI_NO               = "";

	//1 : 자녀보험 주소변경, 2:자동이체 계좌변경, 3. 자동이체일 변경, 4. 장기보험료 납입, 5. 자녀보험 출력용
	private String contract		            = "";
	
	private String UD_FK_POLI_NO            = "";
	private String UD_LK_POLI_NO            = "";
	private String PREV_UD_FK_POLI_NO       = "";
	private String SI_K_GOGEK_NO            = "";
	
	private String place_name1              = "";
	private String place_name2              = "";
	private String poli_no_normal           = "";
	

	private String JJ_GIBON_PRM             = "";
	private String change_baseo_gb          = "";
	private String HJ_PI_NAME               = "";
	
	private String prevPageName             = "";
	
	//장기보험 약관대출 금액
	private String RE_STPLT_LOAN_RESID_AMT  = "";
	
	//pa정보(2009.03.18.yhj추가)
	private String[] sabeon 	            = new String[20];
	private String[] area_tel_no 	        = new String[20];
	private String[] frnt_tel_no 	        = new String[20];
	private String[] aftr_tel_no 	        = new String[20];
	private String[] frnt_hphon_no 	        = new String[20];
	private String[] intmd_hphon_no 	    = new String[20];
	private String[] hphon_aftr_tel_no 	    = new String[20];
	private String[] email_addr_name 	    = new String[20];
	private String[] greetPic 	            = new String[20];
	private String[] greetText 	            = new String[20];
	private String[] gender                 = new String[20]; //pa성별(2009.08.14)
	
	//메일발송
	private String send_name                = ""; //메일 받는 분
	private String send_email               = ""; //메일 받는 분
	private String send_title               = ""; //메일 제목
	private String send_html                = ""; //메일 내용 
	                                       
	private String check                    = "";
	
	private String chauffeurService	= ""; // 대리운전자보험인 경우 "1"
	
	public List<SubFUB2032RVO> LIST_DATA = null;
	
	public String getSsnUserJumin() {
		return ssnUserJumin;
	}

	public void setSsnUserJumin(String ssnUserJumin) {
		this.ssnUserJumin = ssnUserJumin;
	}

	public String getSsnUserName() {
		return ssnUserName;
	}

	public void setSsnUserName(String ssnUserName) {
		this.ssnUserName = ssnUserName;
	}

	public String getFd_mb_email() {
		return fd_mb_email;
	}

	public void setFd_mb_email(String fd_mb_email) {
		this.fd_mb_email = fd_mb_email;
	}

	public String getFd_mb_haddress() {
		return fd_mb_haddress;
	}

	public void setFd_mb_haddress(String fd_mb_haddress) {
		this.fd_mb_haddress = fd_mb_haddress;
	}

	public String getFd_mb_haddress2() {
		return fd_mb_haddress2;
	}

	public void setFd_mb_haddress2(String fd_mb_haddress2) {
		this.fd_mb_haddress2 = fd_mb_haddress2;
	}

	public String getSo_bj_gb() {
		return so_bj_gb;
	}

	public void setSo_bj_gb(String so_bj_gb) {
		this.so_bj_gb = so_bj_gb;
	}


	
	public String getSo_poli_no() {
		return so_poli_no;
	}

	public void setSo_poli_no(String so_poli_no) {
		this.so_poli_no = so_poli_no;
	}

	public String getSo_poli_no_main() {
		return so_poli_no_main;
	}

	public void setSo_poli_no_main(String so_poli_no_main) {
		this.so_poli_no_main = so_poli_no_main;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getSo_pa_mail() {
		return so_pa_mail;
	}

	public void setSo_pa_mail(String so_pa_mail) {
		this.so_pa_mail = so_pa_mail;
	}

	public String getGy_jumn_no() {
		return gy_jumn_no;
	}

	public void setGy_jumn_no(String gy_jumn_no) {
		this.gy_jumn_no = gy_jumn_no;
	}

	public String getCust_addr() {
		return cust_addr;
	}

	public void setCust_addr(String cust_addr) {
		this.cust_addr = cust_addr;
	}

	public String getContact_addr() {
		return contact_addr;
	}

	public void setContact_addr(String contact_addr) {
		this.contact_addr = contact_addr;
	}

	public String getSuikja_addr() {
		return suikja_addr;
	}

	public void setSuikja_addr(String suikja_addr) {
		this.suikja_addr = suikja_addr;
	}

	public String getUpjongNm() {
		return upjongNm;
	}

	public void setUpjongNm(String upjongNm) {
		this.upjongNm = upjongNm;
	}

	public String getSAYONG_YONGDO_CD() {
		return SAYONG_YONGDO_CD;
	}

	public void setSAYONG_YONGDO_CD(String sAYONG_YONGDO_CD) {
		SAYONG_YONGDO_CD = sAYONG_YONGDO_CD;
	}

	public String getSAYONG_SEBU() {
		return SAYONG_SEBU;
	}

	public void setSAYONG_SEBU(String sAYONG_SEBU) {
		SAYONG_SEBU = sAYONG_SEBU;
	}

	public String getTUKYAK_limits() {
		return TUKYAK_limits;
	}

	public void setTUKYAK_limits(String tUKYAK_limits) {
		TUKYAK_limits = tUKYAK_limits;
	}

	public String getTUKYAK_age() {
		return TUKYAK_age;
	}

	public void setTUKYAK_age(String tUKYAK_age) {
		TUKYAK_age = tUKYAK_age;
	}

	public String getStrDtk() {
		return strDtk;
	}

	public void setStrDtk(String strDtk) {
		this.strDtk = strDtk;
	}

	public String getBUNNAP_BANGCD() {
		return BUNNAP_BANGCD;
	}

	public void setBUNNAP_BANGCD(String bUNNAP_BANGCD) {
		BUNNAP_BANGCD = bUNNAP_BANGCD;
	}

	public String getLK_GA1085_BULIP_CNT() {
		return LK_GA1085_BULIP_CNT;
	}

	public void setLK_GA1085_BULIP_CNT(String lK_GA1085_BULIP_CNT) {
		LK_GA1085_BULIP_CNT = lK_GA1085_BULIP_CNT;
	}

	public String getNapip_Date() {
		return Napip_Date;
	}

	public void setNapip_Date(String napip_Date) {
		Napip_Date = napip_Date;
	}

	public String getPIB_TEL_NO() {
		return PIB_TEL_NO;
	}

	public void setPIB_TEL_NO(String pIB_TEL_NO) {
		PIB_TEL_NO = pIB_TEL_NO;
	}

	public String getGYE_TEL_NO() {
		return GYE_TEL_NO;
	}

	public void setGYE_TEL_NO(String gYE_TEL_NO) {
		GYE_TEL_NO = gYE_TEL_NO;
	}

	public String getTUKYAK_UNJUNJA() {
		return TUKYAK_UNJUNJA;
	}

	public void setTUKYAK_UNJUNJA(String tUKYAK_UNJUNJA) {
		TUKYAK_UNJUNJA = tUKYAK_UNJUNJA;
	}

	public String getTUKYAK_jadongiche() {
		return TUKYAK_jadongiche;
	}

	public void setTUKYAK_jadongiche(String tUKYAK_jadongiche) {
		TUKYAK_jadongiche = tUKYAK_jadongiche;
	}

	public String getTEMP_SUIKJA_GOGEKNO() {
		return TEMP_SUIKJA_GOGEKNO;
	}

	public void setTEMP_SUIKJA_GOGEKNO(String tEMP_SUIKJA_GOGEKNO) {
		TEMP_SUIKJA_GOGEKNO = tEMP_SUIKJA_GOGEKNO;
	}

	public String getTEMP_SUIKJA_ZIP() {
		return TEMP_SUIKJA_ZIP;
	}

	public void setTEMP_SUIKJA_ZIP(String tEMP_SUIKJA_ZIP) {
		TEMP_SUIKJA_ZIP = tEMP_SUIKJA_ZIP;
	}

	public String getTEMP_SUIKJA_ADDR() {
		return TEMP_SUIKJA_ADDR;
	}

	public void setTEMP_SUIKJA_ADDR(String tEMP_SUIKJA_ADDR) {
		TEMP_SUIKJA_ADDR = tEMP_SUIKJA_ADDR;
	}

	public String getTEMP_SUIKJA_HP_TEL1_NO() {
		return TEMP_SUIKJA_HP_TEL1_NO;
	}

	public void setTEMP_SUIKJA_HP_TEL1_NO(String tEMP_SUIKJA_HP_TEL1_NO) {
		TEMP_SUIKJA_HP_TEL1_NO = tEMP_SUIKJA_HP_TEL1_NO;
	}

	public String getTEMP_SUIKJA_HOME_TEL2_NO() {
		return TEMP_SUIKJA_HOME_TEL2_NO;
	}

	public void setTEMP_SUIKJA_HOME_TEL2_NO(String tEMP_SUIKJA_HOME_TEL2_NO) {
		TEMP_SUIKJA_HOME_TEL2_NO = tEMP_SUIKJA_HOME_TEL2_NO;
	}

	public String[] getTUKYAK_CD() {
		return TUKYAK_CD;
	}

	public void setTUKYAK_CD(String[] tUKYAK_CD) {
		TUKYAK_CD = tUKYAK_CD;
	}

	public String[] getTUKYAK_RATE() {
		return TUKYAK_RATE;
	}

	public void setTUKYAK_RATE(String[] tUKYAK_RATE) {
		TUKYAK_RATE = tUKYAK_RATE;
	}

	public String[] getTUKBUL_CD() {
		return TUKBUL_CD;
	}

	public void setTUKBUL_CD(String[] tUKBUL_CD) {
		TUKBUL_CD = tUKBUL_CD;
	}

	public String[] getTUKBUL_RATE() {
		return TUKBUL_RATE;
	}

	public void setTUKBUL_RATE(String[] tUKBUL_RATE) {
		TUKBUL_RATE = tUKBUL_RATE;
	}

	public String getHJ_BJ_NM() {
		return HJ_BJ_NM;
	}

	public void setHJ_BJ_NM(String hJ_BJ_NM) {
		HJ_BJ_NM = hJ_BJ_NM;
	}

	public String getHJ_BIGO() {
		return HJ_BIGO;
	}

	public void setHJ_BIGO(String hJ_BIGO) {
		HJ_BIGO = hJ_BIGO;
	}

	public String getHJ_GYEYAK_NM() {
		return HJ_GYEYAK_NM;
	}

	public void setHJ_GYEYAK_NM(String hJ_GYEYAK_NM) {
		HJ_GYEYAK_NM = hJ_GYEYAK_NM;
	}

	public String getHJ_PIBO_NM() {
		return HJ_PIBO_NM;
	}

	public void setHJ_PIBO_NM(String hJ_PIBO_NM) {
		HJ_PIBO_NM = hJ_PIBO_NM;
	}

	public String getHJ_CHIGUB_NM() {
		return HJ_CHIGUB_NM;
	}

	public void setHJ_CHIGUB_NM(String hJ_CHIGUB_NM) {
		HJ_CHIGUB_NM = hJ_CHIGUB_NM;
	}

	public String getJJ_BOHUM_GIGANCD() {
		return JJ_BOHUM_GIGANCD;
	}

	public void setJJ_BOHUM_GIGANCD(String jJ_BOHUM_GIGANCD) {
		JJ_BOHUM_GIGANCD = jJ_BOHUM_GIGANCD;
	}

	public String getJJ_BOHUM_GIGAN_S() {
		return JJ_BOHUM_GIGAN_S;
	}

	public void setJJ_BOHUM_GIGAN_S(String jJ_BOHUM_GIGAN_S) {
		JJ_BOHUM_GIGAN_S = jJ_BOHUM_GIGAN_S;
	}

	public String getJJ_BOHUM_GIGAN_E() {
		return JJ_BOHUM_GIGAN_E;
	}

	public void setJJ_BOHUM_GIGAN_E(String jJ_BOHUM_GIGAN_E) {
		JJ_BOHUM_GIGAN_E = jJ_BOHUM_GIGAN_E;
	}

	public String getJJ_CHIGUB_TEL() {
		return JJ_CHIGUB_TEL;
	}

	public void setJJ_CHIGUB_TEL(String jJ_CHIGUB_TEL) {
		JJ_CHIGUB_TEL = jJ_CHIGUB_TEL;
	}

	public String getJJ_GAIP_TYPE() {
		return JJ_GAIP_TYPE;
	}

	public void setJJ_GAIP_TYPE(String jJ_GAIP_TYPE) {
		JJ_GAIP_TYPE = jJ_GAIP_TYPE;
	}

	public String getJJ_GYEYAK_JMNO() {
		return JJ_GYEYAK_JMNO;
	}

	public void setJJ_GYEYAK_JMNO(String jJ_GYEYAK_JMNO) {
		JJ_GYEYAK_JMNO = jJ_GYEYAK_JMNO;
	}
	
	public String getJJ_PIBO_JMNO() {
		return JJ_PIBO_JMNO;
	}

	public void setJJ_PIBO_JMNO(String jJ_PIBO_JMNO) {
		JJ_PIBO_JMNO = jJ_PIBO_JMNO;
	}

	public String getJJ_JUPSU() {
		return JJ_JUPSU;
	}

	public void setJJ_JUPSU(String jJ_JUPSU) {
		JJ_JUPSU = jJ_JUPSU;
	}

	public String getJJ_POLI_NO() {
		return JJ_POLI_NO;
	}

	public void setJJ_POLI_NO(String jJ_POLI_NO) {
		JJ_POLI_NO = jJ_POLI_NO;
	}

	public String getContract() {
		return contract;
	}

	public void setContract(String contract) {
		this.contract = contract;
	}

	public String getUD_FK_POLI_NO() {
		return UD_FK_POLI_NO;
	}

	public void setUD_FK_POLI_NO(String uD_FK_POLI_NO) {
		UD_FK_POLI_NO = uD_FK_POLI_NO;
	}

	public String getUD_LK_POLI_NO() {
		return UD_LK_POLI_NO;
	}

	public void setUD_LK_POLI_NO(String uD_LK_POLI_NO) {
		UD_LK_POLI_NO = uD_LK_POLI_NO;
	}

	public String getPREV_UD_FK_POLI_NO() {
		return PREV_UD_FK_POLI_NO;
	}

	public void setPREV_UD_FK_POLI_NO(String pREV_UD_FK_POLI_NO) {
		PREV_UD_FK_POLI_NO = pREV_UD_FK_POLI_NO;
	}

	public String getSI_K_GOGEK_NO() {
		return SI_K_GOGEK_NO;
	}

	public void setSI_K_GOGEK_NO(String sI_K_GOGEK_NO) {
		SI_K_GOGEK_NO = sI_K_GOGEK_NO;
	}

	public String getPlace_name1() {
		return place_name1;
	}

	public void setPlace_name1(String place_name1) {
		this.place_name1 = place_name1;
	}

	public String getPlace_name2() {
		return place_name2;
	}

	public void setPlace_name2(String place_name2) {
		this.place_name2 = place_name2;
	}

	public String getPoli_no_normal() {
		return poli_no_normal;
	}

	public void setPoli_no_normal(String poli_no_normal) {
		this.poli_no_normal = poli_no_normal;
	}

	public String getJJ_GIBON_PRM() {
		return JJ_GIBON_PRM;
	}

	public void setJJ_GIBON_PRM(String jJ_GIBON_PRM) {
		JJ_GIBON_PRM = jJ_GIBON_PRM;
	}

	public String getChange_baseo_gb() {
		return change_baseo_gb;
	}

	public void setChange_baseo_gb(String change_baseo_gb) {
		this.change_baseo_gb = change_baseo_gb;
	}

	public String getHJ_PI_NAME() {
		return HJ_PI_NAME;
	}

	public void setHJ_PI_NAME(String hJ_PI_NAME) {
		HJ_PI_NAME = hJ_PI_NAME;
	}

	public String getPrevPageName() {
		return prevPageName;
	}

	public void setPrevPageName(String prevPageName) {
		this.prevPageName = prevPageName;
	}

	public String getRE_STPLT_LOAN_RESID_AMT() {
		return RE_STPLT_LOAN_RESID_AMT;
	}

	public void setRE_STPLT_LOAN_RESID_AMT(String rE_STPLT_LOAN_RESID_AMT) {
		RE_STPLT_LOAN_RESID_AMT = rE_STPLT_LOAN_RESID_AMT;
	}

	public String[] getSabeon() {
		return sabeon;
	}

	public void setSabeon(String[] sabeon) {
		this.sabeon = sabeon;
	}

	public String[] getArea_tel_no() {
		return area_tel_no;
	}

	public void setArea_tel_no(String[] area_tel_no) {
		this.area_tel_no = area_tel_no;
	}

	public String[] getFrnt_tel_no() {
		return frnt_tel_no;
	}

	public void setFrnt_tel_no(String[] frnt_tel_no) {
		this.frnt_tel_no = frnt_tel_no;
	}

	public String[] getAftr_tel_no() {
		return aftr_tel_no;
	}

	public void setAftr_tel_no(String[] aftr_tel_no) {
		this.aftr_tel_no = aftr_tel_no;
	}

	public String[] getFrnt_hphon_no() {
		return frnt_hphon_no;
	}

	public void setFrnt_hphon_no(String[] frnt_hphon_no) {
		this.frnt_hphon_no = frnt_hphon_no;
	}

	public String[] getIntmd_hphon_no() {
		return intmd_hphon_no;
	}

	public void setIntmd_hphon_no(String[] intmd_hphon_no) {
		this.intmd_hphon_no = intmd_hphon_no;
	}

	public String[] getHphon_aftr_tel_no() {
		return hphon_aftr_tel_no;
	}

	public void setHphon_aftr_tel_no(String[] hphon_aftr_tel_no) {
		this.hphon_aftr_tel_no = hphon_aftr_tel_no;
	}

	public String[] getEmail_addr_name() {
		return email_addr_name;
	}

	public void setEmail_addr_name(String[] email_addr_name) {
		this.email_addr_name = email_addr_name;
	}

	public String[] getGreetPic() {
		return greetPic;
	}

	public void setGreetPic(String[] greetPic) {
		this.greetPic = greetPic;
	}

	public String[] getGreetText() {
		return greetText;
	}

	public void setGreetText(String[] greetText) {
		this.greetText = greetText;
	}

	public String[] getGender() {
		return gender;
	}

	public void setGender(String[] gender) {
		this.gender = gender;
	}

	public String getSend_name() {
		return send_name;
	}

	public void setSend_name(String send_name) {
		this.send_name = send_name;
	}

	public String getSend_email() {
		return send_email;
	}

	public void setSend_email(String send_email) {
		this.send_email = send_email;
	}

	public String getSend_title() {
		return send_title;
	}

	public void setSend_title(String send_title) {
		this.send_title = send_title;
	}

	public String getSend_html() {
		return send_html;
	}

	public void setSend_html(String send_html) {
		this.send_html = send_html;
	}

	public String getCheck() {
		return check;
	}

	public void setCheck(String check) {
		this.check = check;
	}

	public String getSo_jumin_no() {
		return so_jumin_no;
	}

	public void setSo_jumin_no(String so_jumin_no) {
		this.so_jumin_no = so_jumin_no;
	}

	public String getSo_bojong_nm() {
		return so_bojong_nm;
	}

	public void setSo_bojong_nm(String so_bojong_nm) {
		this.so_bojong_nm = so_bojong_nm;
	}

	public String getSo_bohum_gigan_symd() {
		return so_bohum_gigan_symd;
	}

	public void setSo_bohum_gigan_symd(String so_bohum_gigan_symd) {
		this.so_bohum_gigan_symd = so_bohum_gigan_symd;
	}

	public String getSo_bohum_gigan_eymd() {
		return so_bohum_gigan_eymd;
	}

	public void setSo_bohum_gigan_eymd(String so_bohum_gigan_eymd) {
		this.so_bohum_gigan_eymd = so_bohum_gigan_eymd;
	}

	public String getSo_hj_bank_nm() {
		return so_hj_bank_nm;
	}

	public void setSo_hj_bank_nm(String so_hj_bank_nm) {
		this.so_hj_bank_nm = so_hj_bank_nm;
	}

	public String getSo_jj_gyejwa_no1() {
		return so_jj_gyejwa_no1;
	}

	public void setSo_jj_gyejwa_no1(String so_jj_gyejwa_no1) {
		this.so_jj_gyejwa_no1 = so_jj_gyejwa_no1;
	}

	public String getSo_hj_yegmju() {
		return so_hj_yegmju;
	}

	public void setSo_hj_yegmju(String so_hj_yegmju) {
		this.so_hj_yegmju = so_hj_yegmju;
	}

	public String getSo_jj_iche_dd() {
		return so_jj_iche_dd;
	}

	public void setSo_jj_iche_dd(String so_jj_iche_dd) {
		this.so_jj_iche_dd = so_jj_iche_dd;
	}

	public String getSo_jj_last_ym() {
		return so_jj_last_ym;
	}

	public void setSo_jj_last_ym(String so_jj_last_ym) {
		this.so_jj_last_ym = so_jj_last_ym;
	}

	public String getSo_hj_sangte_nm() {
		return so_hj_sangte_nm;
	}

	public void setSo_hj_sangte_nm(String so_hj_sangte_nm) {
		this.so_hj_sangte_nm = so_hj_sangte_nm;
	}

	public String getSo_hj_dechul_nm() {
		return so_hj_dechul_nm;
	}

	public void setSo_hj_dechul_nm(String so_hj_dechul_nm) {
		this.so_hj_dechul_nm = so_hj_dechul_nm;
	}

	public String getSo_hj_ipchulgm() {
		return so_hj_ipchulgm;
	}

	public void setSo_hj_ipchulgm(String so_hj_ipchulgm) {
		this.so_hj_ipchulgm = so_hj_ipchulgm;
	}

	public String getJj_gyejwa_no() {
		return jj_gyejwa_no;
	}

	public void setJj_gyejwa_no(String jj_gyejwa_no) {
		this.jj_gyejwa_no = jj_gyejwa_no;
	}

	public String getSo_jj_bank_cd() {
		return so_jj_bank_cd;
	}

	public void setSo_jj_bank_cd(String so_jj_bank_cd) {
		this.so_jj_bank_cd = so_jj_bank_cd;
	}

	public String getSo_jj_iche_d() {
		return so_jj_iche_d;
	}

	public void setSo_jj_iche_d(String so_jj_iche_d) {
		this.so_jj_iche_d = so_jj_iche_d;
	}

	public String getSo_jj_bank_code() {
		return so_jj_bank_code;
	}

	public void setSo_jj_bank_code(String so_jj_bank_code) {
		this.so_jj_bank_code = so_jj_bank_code;
	}

	public String getSo_bj_cd() {
		return so_bj_cd;
	}

	public void setSo_bj_cd(String so_bj_cd) {
		this.so_bj_cd = so_bj_cd;
	}

	public String getHJ_BJ_CD() {
		return HJ_BJ_CD;
	}

	public void setHJ_BJ_CD(String hJ_BJ_CD) {
		HJ_BJ_CD = hJ_BJ_CD;
	}
	
	public String getSo_chungyak_ymd() {
		return so_chungyak_ymd;
	}

	public void setSo_chungyak_ymd(String so_chungyak_ymd) {
		this.so_chungyak_ymd = so_chungyak_ymd;
	}
	
	public String getSo_gaip_type1() {
		return so_gaip_type1;
	}

	public void setSo_gaip_type1(String so_gaip_type1) {
		this.so_gaip_type1 = so_gaip_type1;
	}
	
	public String getSo_bohum_eymd() {
		return so_bohum_eymd;
	}

	public void setSo_bohum_eymd(String so_bohum_eymd) {
		this.so_bohum_eymd = so_bohum_eymd;
	}
	
	public String getSo_bohum_symd() {
		return so_bohum_symd;
	}

	public void setSo_bohum_symd(String so_bohum_symd) {
		this.so_bohum_symd = so_bohum_symd;
	}
	
	/**
	 * @return the chauffeurService
	 */
	public String getChauffeurService() {
		return chauffeurService;
	}

	/**
	 * @param chauffeurService the chauffeurService to set
	 */
	public void setChauffeurService(String chauffeurService) {
		this.chauffeurService = chauffeurService;
	}
	
}
