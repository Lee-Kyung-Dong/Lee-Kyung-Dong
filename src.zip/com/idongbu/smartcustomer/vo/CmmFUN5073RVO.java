package com.idongbu.smartcustomer.vo;

import java.util.List;
import java.util.Map;

import com.idongbu.common.vo.CMMVO;

// 컨버전스 담보 및 가입금액 조회
public class CmmFUN5073RVO extends CMMVO {
	public CmmFUN5073RVO() {
		super.setPGMID(this.proid);
		super.setTRID(this.trid);
	}
	
	public static final String proid		= "FUN5073R";
	public static final String trid			= "UN73";
	public String rURL						= "";

	// 입력
	public String CC_CHANNEL        		= null;
	public String CC_UKEY               	= null;
	public String CC_PGMID            		= null;
	public String CC_PROC_GB       			= null;
	public String CC_FUN_KEY         		= null;
	public String CC_USER_GB        		= null;
	public String CC_USER_CD       			= null;
	public String CC_JIJUM_CD        		= null;
	public String CC_JIBU_CD         		= null;
	public String CC_PROTOCOL      			= null;
	public String CC_COND_CD      			= null;
	public String CC_LAST_FLAG      		= null;
	public String CC_CURSOR_MAP 			= null;
	public String CC_CURSOR_IDX  			= null;
	public String CC_MESSAGE_CD 			= null;
	public String HC_MESSAGE_NM  			= null;
	public String CC_SYS_ERR        		= null;
	public String CC_FILLER             	= null;
	public String JJ_POLI_NO          	 	= null;
	public String JJ_BESU_NO          		= null;

	public String JJ_BESU_SEQ 				= null;
	public String JJ_BJ_CD 					= null;
	public String HJ_BJ_NAME 				= null;
	public String HJ_BJ_GBN 				= null;
	public String HJ_CAR_UNHENG_NM 			= null;
	public String HJ_MULGUN_GUBUN 			= null;
	public String HJ_SANGHE_CD15 			= null;
	public String HJ_TUKJU_GIGAN1 			= null;
	public String HJ_TUKJU_GIGAN2 			= null;
	public String HJ_TUKJU_1 				= null;
	public String HJ_TUKJU_2 				= null;
	public String HJ_HAL_CODE_NM 			= null;
	public String JJ_HAL_PRM 				= null;
	public List<Map<String,Object>>	JJ_OUT_OCCURS	= null;
	public String UU_POLI_NO 				= null;
	public String UU_BESU_SEQ 				= null;
	public String UU_PI_NAME 				= null;
	public List<SubFUN5073RVO> LIST_DATA 	= null;
	
	public String getrURL() {
		return rURL;
	}
	public void setrURL(String rURL) {
		this.rURL = rURL;
	}
	public String getCC_CHANNEL() {
		return CC_CHANNEL;
	}
	public void setCC_CHANNEL(String cC_CHANNEL) {
		CC_CHANNEL = cC_CHANNEL;
	}
	public String getCC_UKEY() {
		return CC_UKEY;
	}
	public void setCC_UKEY(String cC_UKEY) {
		CC_UKEY = cC_UKEY;
	}
	public String getCC_PGMID() {
		return CC_PGMID;
	}
	public void setCC_PGMID(String cC_PGMID) {
		CC_PGMID = cC_PGMID;
	}
	public String getCC_PROC_GB() {
		return CC_PROC_GB;
	}
	public void setCC_PROC_GB(String cC_PROC_GB) {
		CC_PROC_GB = cC_PROC_GB;
	}
	public String getCC_FUN_KEY() {
		return CC_FUN_KEY;
	}
	public void setCC_FUN_KEY(String cC_FUN_KEY) {
		CC_FUN_KEY = cC_FUN_KEY;
	}
	public String getCC_USER_GB() {
		return CC_USER_GB;
	}
	public void setCC_USER_GB(String cC_USER_GB) {
		CC_USER_GB = cC_USER_GB;
	}
	public String getCC_USER_CD() {
		return CC_USER_CD;
	}
	public void setCC_USER_CD(String cC_USER_CD) {
		CC_USER_CD = cC_USER_CD;
	}
	public String getCC_JIJUM_CD() {
		return CC_JIJUM_CD;
	}
	public void setCC_JIJUM_CD(String cC_JIJUM_CD) {
		CC_JIJUM_CD = cC_JIJUM_CD;
	}
	public String getCC_JIBU_CD() {
		return CC_JIBU_CD;
	}
	public void setCC_JIBU_CD(String cC_JIBU_CD) {
		CC_JIBU_CD = cC_JIBU_CD;
	}
	public String getCC_PROTOCOL() {
		return CC_PROTOCOL;
	}
	public void setCC_PROTOCOL(String cC_PROTOCOL) {
		CC_PROTOCOL = cC_PROTOCOL;
	}
	public String getCC_COND_CD() {
		return CC_COND_CD;
	}
	public void setCC_COND_CD(String cC_COND_CD) {
		CC_COND_CD = cC_COND_CD;
	}
	public String getCC_LAST_FLAG() {
		return CC_LAST_FLAG;
	}
	public void setCC_LAST_FLAG(String cC_LAST_FLAG) {
		CC_LAST_FLAG = cC_LAST_FLAG;
	}
	public String getCC_CURSOR_MAP() {
		return CC_CURSOR_MAP;
	}
	public void setCC_CURSOR_MAP(String cC_CURSOR_MAP) {
		CC_CURSOR_MAP = cC_CURSOR_MAP;
	}
	public String getCC_CURSOR_IDX() {
		return CC_CURSOR_IDX;
	}
	public void setCC_CURSOR_IDX(String cC_CURSOR_IDX) {
		CC_CURSOR_IDX = cC_CURSOR_IDX;
	}
	public String getCC_MESSAGE_CD() {
		return CC_MESSAGE_CD;
	}
	public void setCC_MESSAGE_CD(String cC_MESSAGE_CD) {
		CC_MESSAGE_CD = cC_MESSAGE_CD;
	}
	public String getHC_MESSAGE_NM() {
		return HC_MESSAGE_NM;
	}
	public void setHC_MESSAGE_NM(String hC_MESSAGE_NM) {
		HC_MESSAGE_NM = hC_MESSAGE_NM;
	}
	public String getCC_SYS_ERR() {
		return CC_SYS_ERR;
	}
	public void setCC_SYS_ERR(String cC_SYS_ERR) {
		CC_SYS_ERR = cC_SYS_ERR;
	}
	public String getCC_FILLER() {
		return CC_FILLER;
	}
	public void setCC_FILLER(String cC_FILLER) {
		CC_FILLER = cC_FILLER;
	}
	public String getJJ_POLI_NO() {
		return JJ_POLI_NO;
	}
	public void setJJ_POLI_NO(String jJ_POLI_NO) {
		JJ_POLI_NO = jJ_POLI_NO;
	}
	public String getJJ_BESU_NO() {
		return JJ_BESU_NO;
	}
	public void setJJ_BESU_NO(String jJ_BESU_NO) {
		JJ_BESU_NO = jJ_BESU_NO;
	}
	public String getJJ_BESU_SEQ() {
		return JJ_BESU_SEQ;
	}
	public void setJJ_BESU_SEQ(String jJ_BESU_SEQ) {
		JJ_BESU_SEQ = jJ_BESU_SEQ;
	}
	public String getJJ_BJ_CD() {
		return JJ_BJ_CD;
	}
	public void setJJ_BJ_CD(String jJ_BJ_CD) {
		JJ_BJ_CD = jJ_BJ_CD;
	}
	public String getHJ_BJ_NAME() {
		return HJ_BJ_NAME;
	}
	public void setHJ_BJ_NAME(String hJ_BJ_NAME) {
		HJ_BJ_NAME = hJ_BJ_NAME;
	}
	public String getHJ_BJ_GBN() {
		return HJ_BJ_GBN;
	}
	public void setHJ_BJ_GBN(String hJ_BJ_GBN) {
		HJ_BJ_GBN = hJ_BJ_GBN;
	}
	public String getHJ_CAR_UNHENG_NM() {
		return HJ_CAR_UNHENG_NM;
	}
	public void setHJ_CAR_UNHENG_NM(String hJ_CAR_UNHENG_NM) {
		HJ_CAR_UNHENG_NM = hJ_CAR_UNHENG_NM;
	}
	public String getHJ_MULGUN_GUBUN() {
		return HJ_MULGUN_GUBUN;
	}
	public void setHJ_MULGUN_GUBUN(String hJ_MULGUN_GUBUN) {
		HJ_MULGUN_GUBUN = hJ_MULGUN_GUBUN;
	}
	public String getHJ_SANGHE_CD15() {
		return HJ_SANGHE_CD15;
	}
	public void setHJ_SANGHE_CD15(String hJ_SANGHE_CD15) {
		HJ_SANGHE_CD15 = hJ_SANGHE_CD15;
	}
	public String getHJ_TUKJU_GIGAN1() {
		return HJ_TUKJU_GIGAN1;
	}
	public void setHJ_TUKJU_GIGAN1(String hJ_TUKJU_GIGAN1) {
		HJ_TUKJU_GIGAN1 = hJ_TUKJU_GIGAN1;
	}
	public String getHJ_TUKJU_GIGAN2() {
		return HJ_TUKJU_GIGAN2;
	}
	public void setHJ_TUKJU_GIGAN2(String hJ_TUKJU_GIGAN2) {
		HJ_TUKJU_GIGAN2 = hJ_TUKJU_GIGAN2;
	}
	public String getHJ_TUKJU_1() {
		return HJ_TUKJU_1;
	}
	public void setHJ_TUKJU_1(String hJ_TUKJU_1) {
		HJ_TUKJU_1 = hJ_TUKJU_1;
	}
	public String getHJ_TUKJU_2() {
		return HJ_TUKJU_2;
	}
	public void setHJ_TUKJU_2(String hJ_TUKJU_2) {
		HJ_TUKJU_2 = hJ_TUKJU_2;
	}
	public String getHJ_HAL_CODE_NM() {
		return HJ_HAL_CODE_NM;
	}
	public void setHJ_HAL_CODE_NM(String hJ_HAL_CODE_NM) {
		HJ_HAL_CODE_NM = hJ_HAL_CODE_NM;
	}
	public String getJJ_HAL_PRM() {
		return JJ_HAL_PRM;
	}
	public void setJJ_HAL_PRM(String jJ_HAL_PRM) {
		JJ_HAL_PRM = jJ_HAL_PRM;
	}
	public String getUU_POLI_NO() {
		return UU_POLI_NO;
	}
	public void setUU_POLI_NO(String uU_POLI_NO) {
		UU_POLI_NO = uU_POLI_NO;
	}
	public String getUU_BESU_SEQ() {
		return UU_BESU_SEQ;
	}
	public void setUU_BESU_SEQ(String uU_BESU_SEQ) {
		UU_BESU_SEQ = uU_BESU_SEQ;
	}
	public String getUU_PI_NAME() {
		return UU_PI_NAME;
	}
	public void setUU_PI_NAME(String uU_PI_NAME) {
		UU_PI_NAME = uU_PI_NAME;
	}
	public static String getProid() {
		return proid;
	}
	public static String getTrid() {
		return trid;
	}
	public List<Map<String, Object>> getJJ_OUT_OCCURS() {
		return JJ_OUT_OCCURS;
	}
	public void setJJ_OUT_OCCURS(List<Map<String, Object>> jJ_OUT_OCCURS) {
		JJ_OUT_OCCURS = jJ_OUT_OCCURS;
	}
	public List<SubFUN5073RVO> getLIST_DATA() {
		return LIST_DATA;
	}
	public void setLIST_DATA(List<SubFUN5073RVO> lIST_DATA) {
		LIST_DATA = lIST_DATA;
	}
}
