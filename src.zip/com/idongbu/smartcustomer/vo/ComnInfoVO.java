package com.idongbu.smartcustomer.vo;

/**
 * @info 홈페이지 DB COMN_INFO 조회용  VO
 * @author F1F14A81
 *
 */
public class ComnInfoVO {
	private String CL_CD;
	private String DSTIN_CD;
	private String CL_NAME;
	private String CD_NAME;
	private String SORT_CNT;
	
	public String getCL_CD() {
		return CL_CD;
	}
	public void setCL_CD(String cL_CD) {
		CL_CD = cL_CD;
	}
	public String getDSTIN_CD() {
		return DSTIN_CD;
	}
	public void setDSTIN_CD(String dSTIN_CD) {
		DSTIN_CD = dSTIN_CD;
	}
	public String getCL_NAME() {
		return CL_NAME;
	}
	public void setCL_NAME(String cL_NAME) {
		CL_NAME = cL_NAME;
	}
	public String getCD_NAME() {
		return CD_NAME;
	}
	public void setCD_NAME(String cD_NAME) {
		CD_NAME = cD_NAME;
	}
	public String getSORT_CNT() {
		return SORT_CNT;
	}
	public void setSORT_CNT(String sORT_CNT) {
		SORT_CNT = sORT_CNT;
	}
	
}
