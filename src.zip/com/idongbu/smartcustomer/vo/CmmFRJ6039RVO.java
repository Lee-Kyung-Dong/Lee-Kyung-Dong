package com.idongbu.smartcustomer.vo;

import java.util.List;
import java.util.Map;

import com.idongbu.common.vo.CMMVO;
import com.idongbu.smartzone.vo.CCLM0013VO;

public class CmmFRJ6039RVO extends CMMVO {
	
	public CmmFRJ6039RVO() {
		super.setPGMID(this.proid);
		super.setTRID(this.trid);
	}		
	
	private static final String proid = "FRJ6039R";        
	private static final String trid  = "RHJM";                    
	private String rURL			      = "";
	                                  
	private String CC_CHANNEL		  = "";
	private String CC_UKEY		      = "";
	private String CC_PGMID		      = "";
	private String CC_PROC_GB		  = "";
	private String CC_FUN_KEY		  = "";
	private String CC_USER_GB		  = "";
	private String CC_USER_CD		  = "";
	private String CC_JIJUM_CD		  = "";
	private String CC_JIBU_CD		  = "";
	private String CC_PROTOCOL		  = "";
	private String CC_COND_CD		  = "";
	private String CC_LAST_FLAG		  = "";
	private String CC_CURSOR_MAP	  = "";
	private String CC_CURSOR_IDX	  = "";
	private String CC_MESSAGE_CD	  = "";
	private String HC_MESSAGE_NM	  = "";
	private String CC_SYS_ERR		  = "";
	private String CC_FILLER		  = "";
	private String SS_SAGO_JUBSU_NO	  = "";
	private String SS_SAGO_MOKJUK_GB  = "";
	private String SS_SAGO_MOKJUK_SEQ = "";
	/*
	private String[] SS_SANCHUL_SEQ	  = new String[0]; // 100
	private String[] HS_PIBO_NM		  = new String[0]; // 100
	private String[] SS_BOJONG_CD	  = new String[0]; // 100
	private String[] HS_BOJONG_NM	  = new String[0]; // 100
	private String[] SS_POLI_NO		  = new String[0]; // 100
	private String[] SS_BESU_SEQ	  = new String[0]; // 100
	private String[] SS_DAMBO_CD	  = new String[0]; // 100
	private String[] HS_DAMBO_NM	  = new String[0]; // 100
	private String[] SS_PL_CMT		  = new String[0]; // 100
	private String[] SS_WHAKJUNG_YMD  = new String[0]; // 100
	private String[] HS_PL_TYPE		  = new String[0]; // 100
	private String[] SS_DAMDANGJA_CD  = new String[0]; // 100
	private String[] HS_DAMDANGJA_NM  = new String[0]; // 100
	private String[] SS_ILJANGJA	  = new String[0]; // 100
	*/
	private List<Map<String, String>> LOOP_DATA = null;
	private String SS_TOT_CNT		  = "";
	private String SS_TOT_AMT		  = "";
	private CCLM0013VO cclm0013vo     = null;
	
	public String getrURL() {
		return rURL;
	}
	public void setrURL(String rURL) {
		this.rURL = rURL;
	}
	public String getCC_CHANNEL() {
		return CC_CHANNEL;
	}
	public void setCC_CHANNEL(String cC_CHANNEL) {
		CC_CHANNEL = cC_CHANNEL;
	}
	public String getCC_UKEY() {
		return CC_UKEY;
	}
	public void setCC_UKEY(String cC_UKEY) {
		CC_UKEY = cC_UKEY;
	}
	public String getCC_PGMID() {
		return CC_PGMID;
	}
	public void setCC_PGMID(String cC_PGMID) {
		CC_PGMID = cC_PGMID;
	}
	public String getCC_PROC_GB() {
		return CC_PROC_GB;
	}
	public void setCC_PROC_GB(String cC_PROC_GB) {
		CC_PROC_GB = cC_PROC_GB;
	}
	public String getCC_FUN_KEY() {
		return CC_FUN_KEY;
	}
	public void setCC_FUN_KEY(String cC_FUN_KEY) {
		CC_FUN_KEY = cC_FUN_KEY;
	}
	public String getCC_USER_GB() {
		return CC_USER_GB;
	}
	public void setCC_USER_GB(String cC_USER_GB) {
		CC_USER_GB = cC_USER_GB;
	}
	public String getCC_USER_CD() {
		return CC_USER_CD;
	}
	public void setCC_USER_CD(String cC_USER_CD) {
		CC_USER_CD = cC_USER_CD;
	}
	public String getCC_JIJUM_CD() {
		return CC_JIJUM_CD;
	}
	public void setCC_JIJUM_CD(String cC_JIJUM_CD) {
		CC_JIJUM_CD = cC_JIJUM_CD;
	}
	public String getCC_JIBU_CD() {
		return CC_JIBU_CD;
	}
	public void setCC_JIBU_CD(String cC_JIBU_CD) {
		CC_JIBU_CD = cC_JIBU_CD;
	}
	public String getCC_PROTOCOL() {
		return CC_PROTOCOL;
	}
	public void setCC_PROTOCOL(String cC_PROTOCOL) {
		CC_PROTOCOL = cC_PROTOCOL;
	}
	public String getCC_COND_CD() {
		return CC_COND_CD;
	}
	public void setCC_COND_CD(String cC_COND_CD) {
		CC_COND_CD = cC_COND_CD;
	}
	public String getCC_LAST_FLAG() {
		return CC_LAST_FLAG;
	}
	public void setCC_LAST_FLAG(String cC_LAST_FLAG) {
		CC_LAST_FLAG = cC_LAST_FLAG;
	}
	public String getCC_CURSOR_MAP() {
		return CC_CURSOR_MAP;
	}
	public void setCC_CURSOR_MAP(String cC_CURSOR_MAP) {
		CC_CURSOR_MAP = cC_CURSOR_MAP;
	}
	public String getCC_CURSOR_IDX() {
		return CC_CURSOR_IDX;
	}
	public void setCC_CURSOR_IDX(String cC_CURSOR_IDX) {
		CC_CURSOR_IDX = cC_CURSOR_IDX;
	}
	public String getCC_MESSAGE_CD() {
		return CC_MESSAGE_CD;
	}
	public void setCC_MESSAGE_CD(String cC_MESSAGE_CD) {
		CC_MESSAGE_CD = cC_MESSAGE_CD;
	}
	public String getHC_MESSAGE_NM() {
		return HC_MESSAGE_NM;
	}
	public void setHC_MESSAGE_NM(String hC_MESSAGE_NM) {
		HC_MESSAGE_NM = hC_MESSAGE_NM;
	}
	public String getCC_SYS_ERR() {
		return CC_SYS_ERR;
	}
	public void setCC_SYS_ERR(String cC_SYS_ERR) {
		CC_SYS_ERR = cC_SYS_ERR;
	}
	public String getCC_FILLER() {
		return CC_FILLER;
	}
	public void setCC_FILLER(String cC_FILLER) {
		CC_FILLER = cC_FILLER;
	}
	public String getSS_SAGO_JUBSU_NO() {
		return SS_SAGO_JUBSU_NO;
	}
	public void setSS_SAGO_JUBSU_NO(String sS_SAGO_JUBSU_NO) {
		SS_SAGO_JUBSU_NO = sS_SAGO_JUBSU_NO;
	}
	public String getSS_SAGO_MOKJUK_GB() {
		return SS_SAGO_MOKJUK_GB;
	}
	public void setSS_SAGO_MOKJUK_GB(String sS_SAGO_MOKJUK_GB) {
		SS_SAGO_MOKJUK_GB = sS_SAGO_MOKJUK_GB;
	}
	public String getSS_SAGO_MOKJUK_SEQ() {
		return SS_SAGO_MOKJUK_SEQ;
	}
	public void setSS_SAGO_MOKJUK_SEQ(String sS_SAGO_MOKJUK_SEQ) {
		SS_SAGO_MOKJUK_SEQ = sS_SAGO_MOKJUK_SEQ;
	}
	public List<Map<String, String>> getLOOP_DATA() {
		return LOOP_DATA;
	}
	public void setLOOP_DATA(List<Map<String, String>> lOOP_DATA) {
		LOOP_DATA = lOOP_DATA;
	}
	public String getSS_TOT_CNT() {
		return SS_TOT_CNT;
	}
	public void setSS_TOT_CNT(String sS_TOT_CNT) {
		SS_TOT_CNT = sS_TOT_CNT;
	}
	public String getSS_TOT_AMT() {
		return SS_TOT_AMT;
	}
	public void setSS_TOT_AMT(String sS_TOT_AMT) {
		SS_TOT_AMT = sS_TOT_AMT;
	}
	public static String getProid() {
		return proid;
	}
	public static String getTrid() {
		return trid;
	}
	public CCLM0013VO getCclm0013vo() {
		return cclm0013vo;
	}
	public void setCclm0013vo(CCLM0013VO cclm0013vo) {
		this.cclm0013vo = cclm0013vo;
	}	
}
