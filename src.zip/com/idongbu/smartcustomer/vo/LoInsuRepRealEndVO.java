package com.idongbu.smartcustomer.vo;

/**
 * @author F1F13H26
 */
public class LoInsuRepRealEndVO {
	
	private String RE_BANK_CD;
	private String RE_BANK_NM;
	private String RE_GYEJWA_NO;
	private String H_name;
	private String customerTelNo;
	
	private String RE_GOGEK_NO 		= ""; 
	private String Total_sang 		= ""; 
	private String fd_mb_mphone1		= ""; 
	private String fd_mb_mphone2		= ""; 
	private String fd_mb_mphone3		= ""; 
	private String phone1			= ""; 
	private String phone2			= ""; 
	private String phone3			= ""; 
	private String sang				= ""; 
	
	private String stock_seq                = "";
	private String remit_seq                = "";
	private String pd_cd                    = "";
	private String pd_name                  = "";
	private String expec_loan_resid_amt     = "";
	private String npay_day_int_amt         = "";
	private String prncint_sum              = "";
	private String last_int_pay_day         = "";
	private String int_rate                 = "";
	private String pamet_acc_no             = "";
	private String dposr_inhab_no           = "";
	private String dposr_name               = "";
	private String dposr_reltn_name         = "";
	private String bank_cd                  = "";
	private String bank_name                = "";
	private String paybk_apply_amt          = "";
	private String rcv_day                  = "";
	private String req_text                 = "";
	private String slip_no                  = "";
	private String rcv_cd                   = "";
	private String sttus_name               = "";
	private String sttus_text               = "";
	private String why_cd                   = "";
	private String why_text                 = "";
	
	public String getRE_BANK_CD() {
		return RE_BANK_CD;
	}
	public void setRE_BANK_CD(String rE_BANK_CD) {
		RE_BANK_CD = rE_BANK_CD;
	}
	public String getRE_GYEJWA_NO() {
		return RE_GYEJWA_NO;
	}
	public void setRE_GYEJWA_NO(String rE_GYEJWA_NO) {
		RE_GYEJWA_NO = rE_GYEJWA_NO;
	}
	public String getH_name() {
		return H_name;
	}
	public void setH_name(String h_name) {
		H_name = h_name;
	}
	public String getCustomerTelNo() {
		return customerTelNo;
	}
	public void setCustomerTelNo(String customerTelNo) {
		this.customerTelNo = customerTelNo;
	}
	public String getRE_GOGEK_NO() {
		return RE_GOGEK_NO;
	}
	public void setRE_GOGEK_NO(String rE_GOGEK_NO) {
		RE_GOGEK_NO = rE_GOGEK_NO;
	}
	public String getTotal_sang() {
		return Total_sang;
	}
	public void setTotal_sang(String total_sang) {
		Total_sang = total_sang;
	}
	public String getFd_mb_mphone1() {
		return fd_mb_mphone1;
	}
	public void setFd_mb_mphone1(String fd_mb_mphone1) {
		this.fd_mb_mphone1 = fd_mb_mphone1;
	}
	public String getFd_mb_mphone2() {
		return fd_mb_mphone2;
	}
	public void setFd_mb_mphone2(String fd_mb_mphone2) {
		this.fd_mb_mphone2 = fd_mb_mphone2;
	}
	public String getFd_mb_mphone3() {
		return fd_mb_mphone3;
	}
	public void setFd_mb_mphone3(String fd_mb_mphone3) {
		this.fd_mb_mphone3 = fd_mb_mphone3;
	}
	public String getPhone1() {
		return phone1;
	}
	public void setPhone1(String phone1) {
		this.phone1 = phone1;
	}
	public String getPhone2() {
		return phone2;
	}
	public void setPhone2(String phone2) {
		this.phone2 = phone2;
	}
	public String getPhone3() {
		return phone3;
	}
	public void setPhone3(String phone3) {
		this.phone3 = phone3;
	}
	public String getSang() {
		return sang;
	}
	public void setSang(String sang) {
		this.sang = sang;
	}
	public String getStock_seq() {
		return stock_seq;
	}
	public void setStock_seq(String stock_seq) {
		this.stock_seq = stock_seq;
	}
	public String getRemit_seq() {
		return remit_seq;
	}
	public void setRemit_seq(String remit_seq) {
		this.remit_seq = remit_seq;
	}
	public String getPd_cd() {
		return pd_cd;
	}
	public void setPd_cd(String pd_cd) {
		this.pd_cd = pd_cd;
	}
	public String getPd_name() {
		return pd_name;
	}
	public void setPd_name(String pd_name) {
		this.pd_name = pd_name;
	}
	public String getExpec_loan_resid_amt() {
		return expec_loan_resid_amt;
	}
	public void setExpec_loan_resid_amt(String expec_loan_resid_amt) {
		this.expec_loan_resid_amt = expec_loan_resid_amt;
	}
	public String getNpay_day_int_amt() {
		return npay_day_int_amt;
	}
	public void setNpay_day_int_amt(String npay_day_int_amt) {
		this.npay_day_int_amt = npay_day_int_amt;
	}
	public String getPrncint_sum() {
		return prncint_sum;
	}
	public void setPrncint_sum(String prncint_sum) {
		this.prncint_sum = prncint_sum;
	}
	public String getLast_int_pay_day() {
		return last_int_pay_day;
	}
	public void setLast_int_pay_day(String last_int_pay_day) {
		this.last_int_pay_day = last_int_pay_day;
	}
	public String getInt_rate() {
		return int_rate;
	}
	public void setInt_rate(String int_rate) {
		this.int_rate = int_rate;
	}
	public String getPamet_acc_no() {
		return pamet_acc_no;
	}
	public void setPamet_acc_no(String pamet_acc_no) {
		this.pamet_acc_no = pamet_acc_no;
	}
	public String getDposr_inhab_no() {
		return dposr_inhab_no;
	}
	public void setDposr_inhab_no(String dposr_inhab_no) {
		this.dposr_inhab_no = dposr_inhab_no;
	}
	public String getDposr_name() {
		return dposr_name;
	}
	public void setDposr_name(String dposr_name) {
		this.dposr_name = dposr_name;
	}
	public String getDposr_reltn_name() {
		return dposr_reltn_name;
	}
	public void setDposr_reltn_name(String dposr_reltn_name) {
		this.dposr_reltn_name = dposr_reltn_name;
	}
	public String getBank_cd() {
		return bank_cd;
	}
	public void setBank_cd(String bank_cd) {
		this.bank_cd = bank_cd;
	}
	public String getBank_name() {
		return bank_name;
	}
	public void setBank_name(String bank_name) {
		this.bank_name = bank_name;
	}
	public String getPaybk_apply_amt() {
		return paybk_apply_amt;
	}
	public void setPaybk_apply_amt(String paybk_apply_amt) {
		this.paybk_apply_amt = paybk_apply_amt;
	}
	public String getRcv_day() {
		return rcv_day;
	}
	public void setRcv_day(String rcv_day) {
		this.rcv_day = rcv_day;
	}
	public String getReq_text() {
		return req_text;
	}
	public void setReq_text(String req_text) {
		this.req_text = req_text;
	}
	public String getSlip_no() {
		return slip_no;
	}
	public void setSlip_no(String slip_no) {
		this.slip_no = slip_no;
	}
	public String getRcv_cd() {
		return rcv_cd;
	}
	public void setRcv_cd(String rcv_cd) {
		this.rcv_cd = rcv_cd;
	}
	public String getSttus_name() {
		return sttus_name;
	}
	public void setSttus_name(String sttus_name) {
		this.sttus_name = sttus_name;
	}
	public String getSttus_text() {
		return sttus_text;
	}
	public void setSttus_text(String sttus_text) {
		this.sttus_text = sttus_text;
	}
	public String getWhy_cd() {
		return why_cd;
	}
	public void setWhy_cd(String why_cd) {
		this.why_cd = why_cd;
	}
	public String getWhy_text() {
		return why_text;
	}
	public void setWhy_text(String why_text) {
		this.why_text = why_text;
	}
	public String getRE_BANK_NM() {
		return RE_BANK_NM;
	}
	public void setRE_BANK_NM(String rE_BANK_NM) {
		RE_BANK_NM = rE_BANK_NM;
	}
	
	
	
}
