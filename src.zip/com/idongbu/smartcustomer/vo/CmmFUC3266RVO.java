package com.idongbu.smartcustomer.vo;

import java.util.List;

import com.idongbu.common.vo.CMMVO;

//장기보험료납입(가상계좌)
public class CmmFUC3266RVO extends CMMVO {
	
	public CmmFUC3266RVO() {
		super.setPGMID(this.proid);
		super.setTRID(this.trid);
	}
	
	public static final String proid		= "FUC3266R";
	public static final String trid		= "UCDO";
	public String rURL						= "";

	// 입력
	public String JJ_GUBUN = null; // 구분코드
	public String JJ_IPGMJA = null; // 입금자
	public String JJ_IPGMJA_JIJUM = null; // 입금자지점코드
	public String JJ_IPGMJA_JIBU = null; // 입금자지부코드
	public String JJ_HOIGE_CHEORIIL = null; // 회계처리일
	public String JJ_IPGMIL = null; // 입금일
	public String JJ_POLI_NO = null; // 증권번호
	public String JJ_HOIBUN = null; // 입금횟수
	public String JJ_BANK_CD = null; // 은행코드

	// 출력
	public String CC_CHANNEL = null;
	public String CC_UKEY = null;
	public String CC_PGMID = null;
	public String CC_PROC_GB = null;
	public String CC_FUN_KEY = null;
	public String CC_USER_GB = null;
	public String CC_USER_CD = null;
	public String CC_JIJUM_CD = null;
	public String CC_JIBU_CD = null;
	public String CC_PROTOCOL = null;
	public String CC_COND_CD = null;
	public String CC_LAST_FLAG = null;
	public String CC_CURSOR_MAP = null;
	public String CC_CURSOR_IDX = null;
	public String CC_MESSAGE_CD = null;
	public String HC_MESSAGE_NM = null;
	public String CC_SYS_ERR = null;
	public String CC_FILLER = null;
//	public String JJ_GUBUN = null;
//	public String JJ_IPGMJA = null;
//	public String JJ_IPGMJA_JIJUM = null;
//	public String JJ_IPGMJA_JIBU = null;
//	public String JJ_HOIGE_CHEORIIL = null;
//	public String JJ_IPGMIL = null;
//	public String JJ_POLI_NO = null;
//	public String JJ_HOIBUN = null;
	public String JJ_FROM_WOLDO = null;
	public String JJ_FROM_HOI = null;
	public String JJ_TO_WOLDO = null;
	public String JJ_TO_HOI = null;
	public String HJ_GYEYAKJA_NAME = null;
	public String HJ_PIBOJA_NAME = null;
	public String HJ_SUGMJA_NAME = null;
	public String JJ_SUGMJA_JIJUM = null;
	public String JJ_SUGMJA_JIBU = null;
	public String JJ_SUGMJA_CD = null;
	public String JJ_LAST_WOLDO = null;
	public String JJ_LAST_HOI = null;
	public String HJ_NAPIP_BANGBUP = null;
	public String JJ_INJUNG_WOLDO = null;
	public String HJ_CHAKO_GUBUN = null;
	public String JJ_CHAKO_PRM = null;
	public String HJ_CHEKIM_GUBUN = null;
	public String JJ_CHEKIM_JUNBIGM = null;
	public String HJ_SANGTE_NAME = null;
	public String JJ_SANGTE_YMD = null;
	public String JJ_TOT_BATUL_GMEK = null;
	public String JJ_TOT_SUNNAP_HALIN = null;
	public String JJ_TOT_BUHWAL_IJA = null;
	public String JJ_YUNGSUJNG_1 = null;
	public String JJ_YUNGSUGMEK_1 = null;
	public String JJ_GMJONG_1 = null;
//	public String JJ_BANK_CD = null;
	public String HJ_BANK_NM = null;
	public String JJ_GYEJWA_NO = null;
	public String HJ_REMARK = null;
	public String UU_POLI_NO = null;
	public String UU_TOT_PG = null;
	public String UU_JOHOI_FIRST = null;
	public String UU_JOHOI_LAST = null;
	public String UU_JOHOI_CURR = null;
	public List<SubFUC3266RVO> LIST_DATA = null;
	public String getrURL() {
		return rURL;
	}
	public void setrURL(String rURL) {
		this.rURL = rURL;
	}
	public String getJJ_GUBUN() {
		return JJ_GUBUN;
	}
	public void setJJ_GUBUN(String jJ_GUBUN) {
		JJ_GUBUN = jJ_GUBUN;
	}
	public String getJJ_IPGMJA() {
		return JJ_IPGMJA;
	}
	public void setJJ_IPGMJA(String jJ_IPGMJA) {
		JJ_IPGMJA = jJ_IPGMJA;
	}
	public String getJJ_IPGMJA_JIJUM() {
		return JJ_IPGMJA_JIJUM;
	}
	public void setJJ_IPGMJA_JIJUM(String jJ_IPGMJA_JIJUM) {
		JJ_IPGMJA_JIJUM = jJ_IPGMJA_JIJUM;
	}
	public String getJJ_IPGMJA_JIBU() {
		return JJ_IPGMJA_JIBU;
	}
	public void setJJ_IPGMJA_JIBU(String jJ_IPGMJA_JIBU) {
		JJ_IPGMJA_JIBU = jJ_IPGMJA_JIBU;
	}
	public String getJJ_HOIGE_CHEORIIL() {
		return JJ_HOIGE_CHEORIIL;
	}
	public void setJJ_HOIGE_CHEORIIL(String jJ_HOIGE_CHEORIIL) {
		JJ_HOIGE_CHEORIIL = jJ_HOIGE_CHEORIIL;
	}
	public String getJJ_IPGMIL() {
		return JJ_IPGMIL;
	}
	public void setJJ_IPGMIL(String jJ_IPGMIL) {
		JJ_IPGMIL = jJ_IPGMIL;
	}
	public String getJJ_POLI_NO() {
		return JJ_POLI_NO;
	}
	public void setJJ_POLI_NO(String jJ_POLI_NO) {
		JJ_POLI_NO = jJ_POLI_NO;
	}
	public String getJJ_HOIBUN() {
		return JJ_HOIBUN;
	}
	public void setJJ_HOIBUN(String jJ_HOIBUN) {
		JJ_HOIBUN = jJ_HOIBUN;
	}
	public String getJJ_BANK_CD() {
		return JJ_BANK_CD;
	}
	public void setJJ_BANK_CD(String jJ_BANK_CD) {
		JJ_BANK_CD = jJ_BANK_CD;
	}
	public String getCC_CHANNEL() {
		return CC_CHANNEL;
	}
	public void setCC_CHANNEL(String cC_CHANNEL) {
		CC_CHANNEL = cC_CHANNEL;
	}
	public String getCC_UKEY() {
		return CC_UKEY;
	}
	public void setCC_UKEY(String cC_UKEY) {
		CC_UKEY = cC_UKEY;
	}
	public String getCC_PGMID() {
		return CC_PGMID;
	}
	public void setCC_PGMID(String cC_PGMID) {
		CC_PGMID = cC_PGMID;
	}
	public String getCC_PROC_GB() {
		return CC_PROC_GB;
	}
	public void setCC_PROC_GB(String cC_PROC_GB) {
		CC_PROC_GB = cC_PROC_GB;
	}
	public String getCC_FUN_KEY() {
		return CC_FUN_KEY;
	}
	public void setCC_FUN_KEY(String cC_FUN_KEY) {
		CC_FUN_KEY = cC_FUN_KEY;
	}
	public String getCC_USER_GB() {
		return CC_USER_GB;
	}
	public void setCC_USER_GB(String cC_USER_GB) {
		CC_USER_GB = cC_USER_GB;
	}
	public String getCC_USER_CD() {
		return CC_USER_CD;
	}
	public void setCC_USER_CD(String cC_USER_CD) {
		CC_USER_CD = cC_USER_CD;
	}
	public String getCC_JIJUM_CD() {
		return CC_JIJUM_CD;
	}
	public void setCC_JIJUM_CD(String cC_JIJUM_CD) {
		CC_JIJUM_CD = cC_JIJUM_CD;
	}
	public String getCC_JIBU_CD() {
		return CC_JIBU_CD;
	}
	public void setCC_JIBU_CD(String cC_JIBU_CD) {
		CC_JIBU_CD = cC_JIBU_CD;
	}
	public String getCC_PROTOCOL() {
		return CC_PROTOCOL;
	}
	public void setCC_PROTOCOL(String cC_PROTOCOL) {
		CC_PROTOCOL = cC_PROTOCOL;
	}
	public String getCC_COND_CD() {
		return CC_COND_CD;
	}
	public void setCC_COND_CD(String cC_COND_CD) {
		CC_COND_CD = cC_COND_CD;
	}
	public String getCC_LAST_FLAG() {
		return CC_LAST_FLAG;
	}
	public void setCC_LAST_FLAG(String cC_LAST_FLAG) {
		CC_LAST_FLAG = cC_LAST_FLAG;
	}
	public String getCC_CURSOR_MAP() {
		return CC_CURSOR_MAP;
	}
	public void setCC_CURSOR_MAP(String cC_CURSOR_MAP) {
		CC_CURSOR_MAP = cC_CURSOR_MAP;
	}
	public String getCC_CURSOR_IDX() {
		return CC_CURSOR_IDX;
	}
	public void setCC_CURSOR_IDX(String cC_CURSOR_IDX) {
		CC_CURSOR_IDX = cC_CURSOR_IDX;
	}
	public String getCC_MESSAGE_CD() {
		return CC_MESSAGE_CD;
	}
	public void setCC_MESSAGE_CD(String cC_MESSAGE_CD) {
		CC_MESSAGE_CD = cC_MESSAGE_CD;
	}
	public String getHC_MESSAGE_NM() {
		return HC_MESSAGE_NM;
	}
	public void setHC_MESSAGE_NM(String hC_MESSAGE_NM) {
		HC_MESSAGE_NM = hC_MESSAGE_NM;
	}
	public String getCC_SYS_ERR() {
		return CC_SYS_ERR;
	}
	public void setCC_SYS_ERR(String cC_SYS_ERR) {
		CC_SYS_ERR = cC_SYS_ERR;
	}
	public String getCC_FILLER() {
		return CC_FILLER;
	}
	public void setCC_FILLER(String cC_FILLER) {
		CC_FILLER = cC_FILLER;
	}
	public String getJJ_FROM_WOLDO() {
		return JJ_FROM_WOLDO;
	}
	public void setJJ_FROM_WOLDO(String jJ_FROM_WOLDO) {
		JJ_FROM_WOLDO = jJ_FROM_WOLDO;
	}
	public String getJJ_FROM_HOI() {
		return JJ_FROM_HOI;
	}
	public void setJJ_FROM_HOI(String jJ_FROM_HOI) {
		JJ_FROM_HOI = jJ_FROM_HOI;
	}
	public String getJJ_TO_WOLDO() {
		return JJ_TO_WOLDO;
	}
	public void setJJ_TO_WOLDO(String jJ_TO_WOLDO) {
		JJ_TO_WOLDO = jJ_TO_WOLDO;
	}
	public String getJJ_TO_HOI() {
		return JJ_TO_HOI;
	}
	public void setJJ_TO_HOI(String jJ_TO_HOI) {
		JJ_TO_HOI = jJ_TO_HOI;
	}
	public String getHJ_GYEYAKJA_NAME() {
		return HJ_GYEYAKJA_NAME;
	}
	public void setHJ_GYEYAKJA_NAME(String hJ_GYEYAKJA_NAME) {
		HJ_GYEYAKJA_NAME = hJ_GYEYAKJA_NAME;
	}
	public String getHJ_PIBOJA_NAME() {
		return HJ_PIBOJA_NAME;
	}
	public void setHJ_PIBOJA_NAME(String hJ_PIBOJA_NAME) {
		HJ_PIBOJA_NAME = hJ_PIBOJA_NAME;
	}
	public String getHJ_SUGMJA_NAME() {
		return HJ_SUGMJA_NAME;
	}
	public void setHJ_SUGMJA_NAME(String hJ_SUGMJA_NAME) {
		HJ_SUGMJA_NAME = hJ_SUGMJA_NAME;
	}
	public String getJJ_SUGMJA_JIJUM() {
		return JJ_SUGMJA_JIJUM;
	}
	public void setJJ_SUGMJA_JIJUM(String jJ_SUGMJA_JIJUM) {
		JJ_SUGMJA_JIJUM = jJ_SUGMJA_JIJUM;
	}
	public String getJJ_SUGMJA_JIBU() {
		return JJ_SUGMJA_JIBU;
	}
	public void setJJ_SUGMJA_JIBU(String jJ_SUGMJA_JIBU) {
		JJ_SUGMJA_JIBU = jJ_SUGMJA_JIBU;
	}
	public String getJJ_SUGMJA_CD() {
		return JJ_SUGMJA_CD;
	}
	public void setJJ_SUGMJA_CD(String jJ_SUGMJA_CD) {
		JJ_SUGMJA_CD = jJ_SUGMJA_CD;
	}
	public String getJJ_LAST_WOLDO() {
		return JJ_LAST_WOLDO;
	}
	public void setJJ_LAST_WOLDO(String jJ_LAST_WOLDO) {
		JJ_LAST_WOLDO = jJ_LAST_WOLDO;
	}
	public String getJJ_LAST_HOI() {
		return JJ_LAST_HOI;
	}
	public void setJJ_LAST_HOI(String jJ_LAST_HOI) {
		JJ_LAST_HOI = jJ_LAST_HOI;
	}
	public String getHJ_NAPIP_BANGBUP() {
		return HJ_NAPIP_BANGBUP;
	}
	public void setHJ_NAPIP_BANGBUP(String hJ_NAPIP_BANGBUP) {
		HJ_NAPIP_BANGBUP = hJ_NAPIP_BANGBUP;
	}
	public String getJJ_INJUNG_WOLDO() {
		return JJ_INJUNG_WOLDO;
	}
	public void setJJ_INJUNG_WOLDO(String jJ_INJUNG_WOLDO) {
		JJ_INJUNG_WOLDO = jJ_INJUNG_WOLDO;
	}
	public String getHJ_CHAKO_GUBUN() {
		return HJ_CHAKO_GUBUN;
	}
	public void setHJ_CHAKO_GUBUN(String hJ_CHAKO_GUBUN) {
		HJ_CHAKO_GUBUN = hJ_CHAKO_GUBUN;
	}
	public String getJJ_CHAKO_PRM() {
		return JJ_CHAKO_PRM;
	}
	public void setJJ_CHAKO_PRM(String jJ_CHAKO_PRM) {
		JJ_CHAKO_PRM = jJ_CHAKO_PRM;
	}
	public String getHJ_CHEKIM_GUBUN() {
		return HJ_CHEKIM_GUBUN;
	}
	public void setHJ_CHEKIM_GUBUN(String hJ_CHEKIM_GUBUN) {
		HJ_CHEKIM_GUBUN = hJ_CHEKIM_GUBUN;
	}
	public String getJJ_CHEKIM_JUNBIGM() {
		return JJ_CHEKIM_JUNBIGM;
	}
	public void setJJ_CHEKIM_JUNBIGM(String jJ_CHEKIM_JUNBIGM) {
		JJ_CHEKIM_JUNBIGM = jJ_CHEKIM_JUNBIGM;
	}
	public String getHJ_SANGTE_NAME() {
		return HJ_SANGTE_NAME;
	}
	public void setHJ_SANGTE_NAME(String hJ_SANGTE_NAME) {
		HJ_SANGTE_NAME = hJ_SANGTE_NAME;
	}
	public String getJJ_SANGTE_YMD() {
		return JJ_SANGTE_YMD;
	}
	public void setJJ_SANGTE_YMD(String jJ_SANGTE_YMD) {
		JJ_SANGTE_YMD = jJ_SANGTE_YMD;
	}
	public String getJJ_TOT_BATUL_GMEK() {
		return JJ_TOT_BATUL_GMEK;
	}
	public void setJJ_TOT_BATUL_GMEK(String jJ_TOT_BATUL_GMEK) {
		JJ_TOT_BATUL_GMEK = jJ_TOT_BATUL_GMEK;
	}
	public String getJJ_TOT_SUNNAP_HALIN() {
		return JJ_TOT_SUNNAP_HALIN;
	}
	public void setJJ_TOT_SUNNAP_HALIN(String jJ_TOT_SUNNAP_HALIN) {
		JJ_TOT_SUNNAP_HALIN = jJ_TOT_SUNNAP_HALIN;
	}
	public String getJJ_TOT_BUHWAL_IJA() {
		return JJ_TOT_BUHWAL_IJA;
	}
	public void setJJ_TOT_BUHWAL_IJA(String jJ_TOT_BUHWAL_IJA) {
		JJ_TOT_BUHWAL_IJA = jJ_TOT_BUHWAL_IJA;
	}
	public String getJJ_YUNGSUJNG_1() {
		return JJ_YUNGSUJNG_1;
	}
	public void setJJ_YUNGSUJNG_1(String jJ_YUNGSUJNG_1) {
		JJ_YUNGSUJNG_1 = jJ_YUNGSUJNG_1;
	}
	public String getJJ_YUNGSUGMEK_1() {
		return JJ_YUNGSUGMEK_1;
	}
	public void setJJ_YUNGSUGMEK_1(String jJ_YUNGSUGMEK_1) {
		JJ_YUNGSUGMEK_1 = jJ_YUNGSUGMEK_1;
	}
	public String getJJ_GMJONG_1() {
		return JJ_GMJONG_1;
	}
	public void setJJ_GMJONG_1(String jJ_GMJONG_1) {
		JJ_GMJONG_1 = jJ_GMJONG_1;
	}
	public String getHJ_BANK_NM() {
		return HJ_BANK_NM;
	}
	public void setHJ_BANK_NM(String hJ_BANK_NM) {
		HJ_BANK_NM = hJ_BANK_NM;
	}
	public String getJJ_GYEJWA_NO() {
		return JJ_GYEJWA_NO;
	}
	public void setJJ_GYEJWA_NO(String jJ_GYEJWA_NO) {
		JJ_GYEJWA_NO = jJ_GYEJWA_NO;
	}
	public String getHJ_REMARK() {
		return HJ_REMARK;
	}
	public void setHJ_REMARK(String hJ_REMARK) {
		HJ_REMARK = hJ_REMARK;
	}
	public String getUU_POLI_NO() {
		return UU_POLI_NO;
	}
	public void setUU_POLI_NO(String uU_POLI_NO) {
		UU_POLI_NO = uU_POLI_NO;
	}
	public String getUU_TOT_PG() {
		return UU_TOT_PG;
	}
	public void setUU_TOT_PG(String uU_TOT_PG) {
		UU_TOT_PG = uU_TOT_PG;
	}
	public String getUU_JOHOI_FIRST() {
		return UU_JOHOI_FIRST;
	}
	public void setUU_JOHOI_FIRST(String uU_JOHOI_FIRST) {
		UU_JOHOI_FIRST = uU_JOHOI_FIRST;
	}
	public String getUU_JOHOI_LAST() {
		return UU_JOHOI_LAST;
	}
	public void setUU_JOHOI_LAST(String uU_JOHOI_LAST) {
		UU_JOHOI_LAST = uU_JOHOI_LAST;
	}
	public String getUU_JOHOI_CURR() {
		return UU_JOHOI_CURR;
	}
	public void setUU_JOHOI_CURR(String uU_JOHOI_CURR) {
		UU_JOHOI_CURR = uU_JOHOI_CURR;
	}
	public List<SubFUC3266RVO> getLIST_DATA() {
		return LIST_DATA;
	}
	public void setLIST_DATA(List<SubFUC3266RVO> lIST_DATA) {
		LIST_DATA = lIST_DATA;
	}
	public static String getProid() {
		return proid;
	}
	public static String getTrid() {
		return trid;
	}

	
	
}
