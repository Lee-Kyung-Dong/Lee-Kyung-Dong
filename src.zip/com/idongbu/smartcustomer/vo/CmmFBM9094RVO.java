package com.idongbu.smartcustomer.vo;

import java.util.List;
import java.util.Map;

import com.idongbu.common.vo.CMMVO;

// 계약조회
public class CmmFBM9094RVO extends CMMVO {
	
	public CmmFBM9094RVO() {
		super.setPGMID(this.proid);
		super.setTRID(this.trid);
	}
	
	public static final String proid		  = "FBM9094R";
	public static final String trid			  = "BMBY";
	public String rURL						  = "";
	                                          
	public String COMM_CHANNEL    = null;
	public String COMM_UNIQUE_KEY = null;
	public String COMM_PGMID      = null;
	public String COMM_PROC_GB    = null;
	public String COMM_ACTION_KEY = null;
	public String COMM_USER_GB  = null;
	public String COMM_USER_ID  = null;
	public String COMM_JIJUM_CD = null;
	public String COMM_JIBU_CD  = null;
	public String COMM_PROTOCOL     = null;
	public String COMM_COND_CD      = null;
	public String COMM_LAST_FLAG    = null;
	public String COMM_CURSOR_MAP   = null;
	public String COMM_CURSOR_IDX   = null;
	public String COMM_MESSAGE_CD   = null;
	public String H_COMM_MESSAGE_NM = null;
	public String COMM_ERR_NAME = null;
	public String COMM_ERR_TEXT = null;
	public String COMM_SYS_CODE = null;
	public String FILLER = null;
	
	public String MBL_LENGTH     = null;  
	public String MBL_PROCESS_ID   = null;
	public String SCR_K_HP_TEL1  = null;
	public String SCR_K_HP_TEL2  = null;
	public String SCR_K_HP_TEL3  = null;
	public String SCR_K_JUMIN_NO = null;
	public String H_SCR_SUHE_NM = null;
	public String SCR_SAYU_CD   = null;
	public String SCR_D_JUMIN_NO   = null;
	
	public String USER_CAR_NO = null;
	
	public List<Map<String,Object>> LOOP_DATA = null;
	
	public String getrURL() {
		return rURL;
	}
	public void setrURL(String rURL) {
		this.rURL = rURL;
	}
	public String getCOMM_CHANNEL() {
		return COMM_CHANNEL;
	}
	public void setCOMM_CHANNEL(String cOMM_CHANNEL) {
		COMM_CHANNEL = cOMM_CHANNEL;
	}
	public String getCOMM_UNIQUE_KEY() {
		return COMM_UNIQUE_KEY;
	}
	public void setCOMM_UNIQUE_KEY(String cOMM_UNIQUE_KEY) {
		COMM_UNIQUE_KEY = cOMM_UNIQUE_KEY;
	}
	public String getCOMM_PGMID() {
		return COMM_PGMID;
	}
	public void setCOMM_PGMID(String cOMM_PGMID) {
		COMM_PGMID = cOMM_PGMID;
	}
	public String getCOMM_PROC_GB() {
		return COMM_PROC_GB;
	}
	public void setCOMM_PROC_GB(String cOMM_PROC_GB) {
		COMM_PROC_GB = cOMM_PROC_GB;
	}
	public String getCOMM_ACTION_KEY() {
		return COMM_ACTION_KEY;
	}
	public void setCOMM_ACTION_KEY(String cOMM_ACTION_KEY) {
		COMM_ACTION_KEY = cOMM_ACTION_KEY;
	}
	public String getCOMM_USER_GB() {
		return COMM_USER_GB;
	}
	public void setCOMM_USER_GB(String cOMM_USER_GB) {
		COMM_USER_GB = cOMM_USER_GB;
	}
	public String getCOMM_USER_ID() {
		return COMM_USER_ID;
	}
	public void setCOMM_USER_ID(String cOMM_USER_ID) {
		COMM_USER_ID = cOMM_USER_ID;
	}
	public String getCOMM_JIJUM_CD() {
		return COMM_JIJUM_CD;
	}
	public void setCOMM_JIJUM_CD(String cOMM_JIJUM_CD) {
		COMM_JIJUM_CD = cOMM_JIJUM_CD;
	}
	public String getCOMM_JIBU_CD() {
		return COMM_JIBU_CD;
	}
	public void setCOMM_JIBU_CD(String cOMM_JIBU_CD) {
		COMM_JIBU_CD = cOMM_JIBU_CD;
	}
	public String getCOMM_PROTOCOL() {
		return COMM_PROTOCOL;
	}
	public void setCOMM_PROTOCOL(String cOMM_PROTOCOL) {
		COMM_PROTOCOL = cOMM_PROTOCOL;
	}
	public String getCOMM_COND_CD() {
		return COMM_COND_CD;
	}
	public void setCOMM_COND_CD(String cOMM_COND_CD) {
		COMM_COND_CD = cOMM_COND_CD;
	}
	public String getCOMM_LAST_FLAG() {
		return COMM_LAST_FLAG;
	}
	public void setCOMM_LAST_FLAG(String cOMM_LAST_FLAG) {
		COMM_LAST_FLAG = cOMM_LAST_FLAG;
	}
	public String getCOMM_CURSOR_MAP() {
		return COMM_CURSOR_MAP;
	}
	public void setCOMM_CURSOR_MAP(String cOMM_CURSOR_MAP) {
		COMM_CURSOR_MAP = cOMM_CURSOR_MAP;
	}
	public String getCOMM_CURSOR_IDX() {
		return COMM_CURSOR_IDX;
	}
	public void setCOMM_CURSOR_IDX(String cOMM_CURSOR_IDX) {
		COMM_CURSOR_IDX = cOMM_CURSOR_IDX;
	}
	public String getCOMM_MESSAGE_CD() {
		return COMM_MESSAGE_CD;
	}
	public void setCOMM_MESSAGE_CD(String cOMM_MESSAGE_CD) {
		COMM_MESSAGE_CD = cOMM_MESSAGE_CD;
	}
	public String getH_COMM_MESSAGE_NM() {
		return H_COMM_MESSAGE_NM;
	}
	public void setH_COMM_MESSAGE_NM(String h_COMM_MESSAGE_NM) {
		H_COMM_MESSAGE_NM = h_COMM_MESSAGE_NM;
	}
	public String getCOMM_ERR_NAME() {
		return COMM_ERR_NAME;
	}
	public void setCOMM_ERR_NAME(String cOMM_ERR_NAME) {
		COMM_ERR_NAME = cOMM_ERR_NAME;
	}
	public String getCOMM_ERR_TEXT() {
		return COMM_ERR_TEXT;
	}
	public void setCOMM_ERR_TEXT(String cOMM_ERR_TEXT) {
		COMM_ERR_TEXT = cOMM_ERR_TEXT;
	}
	public String getCOMM_SYS_CODE() {
		return COMM_SYS_CODE;
	}
	public void setCOMM_SYS_CODE(String cOMM_SYS_CODE) {
		COMM_SYS_CODE = cOMM_SYS_CODE;
	}
	public String getFILLER() {
		return FILLER;
	}
	public void setFILLER(String fILLER) {
		FILLER = fILLER;
	}
	public String getMBL_LENGTH() {
		return MBL_LENGTH;
	}
	public void setMBL_LENGTH(String mBL_LENGTH) {
		MBL_LENGTH = mBL_LENGTH;
	}
	public String getMBL_PROCESS_ID() {
		return MBL_PROCESS_ID;
	}
	public void setMBL_PROCESS_ID(String mBL_PROCESS_ID) {
		MBL_PROCESS_ID = mBL_PROCESS_ID;
	}
	public String getSCR_K_HP_TEL1() {
		return SCR_K_HP_TEL1;
	}
	public void setSCR_K_HP_TEL1(String sCR_K_HP_TEL1) {
		SCR_K_HP_TEL1 = sCR_K_HP_TEL1;
	}
	public String getSCR_K_HP_TEL2() {
		return SCR_K_HP_TEL2;
	}
	public void setSCR_K_HP_TEL2(String sCR_K_HP_TEL2) {
		SCR_K_HP_TEL2 = sCR_K_HP_TEL2;
	}
	public String getSCR_K_HP_TEL3() {
		return SCR_K_HP_TEL3;
	}
	public void setSCR_K_HP_TEL3(String sCR_K_HP_TEL3) {
		SCR_K_HP_TEL3 = sCR_K_HP_TEL3;
	}
	public String getSCR_K_JUMIN_NO() {
		return SCR_K_JUMIN_NO;
	}
	public void setSCR_K_JUMIN_NO(String sCR_K_JUMIN_NO) {
		SCR_K_JUMIN_NO = sCR_K_JUMIN_NO;
	}
	public String getH_SCR_SUHE_NM() {
		return H_SCR_SUHE_NM;
	}
	public void setH_SCR_SUHE_NM(String h_SCR_SUHE_NM) {
		H_SCR_SUHE_NM = h_SCR_SUHE_NM;
	}
	public String getSCR_SAYU_CD() {
		return SCR_SAYU_CD;
	}
	public void setSCR_SAYU_CD(String sCR_SAYU_CD) {
		SCR_SAYU_CD = sCR_SAYU_CD;
	}
	public static String getProid() {
		return proid;
	}
	public static String getTrid() {
		return trid;
	}
	public List<Map<String, Object>> getLOOP_DATA() {
		return LOOP_DATA;
	}
	public void setLOOP_DATA(List<Map<String, Object>> lOOP_DATA) {
		LOOP_DATA = lOOP_DATA;
	}
	public String getUSER_CAR_NO() {
		return USER_CAR_NO;
	}
	public void setUSER_CAR_NO(String uSER_CAR_NO) {
		USER_CAR_NO = uSER_CAR_NO;
	}
	public String getSCR_D_JUMIN_NO() {
		return SCR_D_JUMIN_NO;
	}
	public void setSCR_D_JUMIN_NO(String sCR_D_JUMIN_NO) {
		SCR_D_JUMIN_NO = sCR_D_JUMIN_NO;
	}
	
}
