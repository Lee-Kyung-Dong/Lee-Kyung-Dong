package com.idongbu.smartcustomer.vo;

public class MPhoneKmcCheckVO {

	public String rec_cert;
	public String k_certNum;
	public String encPara;
	public String encMsg1;
	public String encMsg2;
	public String msgChk;
	public String certNum;
	public String date;
	public String CI;
    public String phoneNo;
    public String phoneCorp;
    public String birthDay;
    public String gender;
    public String nation;
    public String name;
    public String result;
    public String certMet	;
    public String ip;
    public String M_name;
    public String M_birthDay;
    public String M_Gender;
    public String M_nation;
    public String plusInfo;
    public String DI;
	public final static String cpId = "DBIM2002";	// 회원사ID
	public final static String urlCode = "005001"; 	// URL코드
	public final static String extendVar = "0000000000000000";	//확장변수
	
	/*
	 * 	mchkvo.cpId = "DBIM1002"; //2013차세대 대출은 본인인증시 별도 아이디 사용함.
			
			if(Env.isServerModeTest()){
				//mchkvo.urlCode = "001002";	//테스트계URL코드
				mchkvo.urlCode = "003001";	//세미계URL코드
				//mchkvo.urlCode = "006001";	//장차법 테스트계 URL코드
			}else{
				mchkvo.urlCode = "004001";	//운영계 URL코드
			}	       
	 */
}
