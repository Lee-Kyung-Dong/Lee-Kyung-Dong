package com.idongbu.smartcustomer.vo;

import java.util.List;

public class SubFGZ5916SVO {

	public String LK_BJ_NM  	        		= null;
	public List<SubFGZ5916STBLVO> LK_GZ5916_TBL = null;
	public String LK_FIL				    	= null;
	public String LK_PIBO_CD			    	= null;
	public String LK_FIL2				    	= null;

	public String getLK_BJ_NM() {
		return LK_BJ_NM;
	}
	public void setLK_BJ_NM(String lK_BJ_NM) {
		LK_BJ_NM = lK_BJ_NM;
	}
	public List<SubFGZ5916STBLVO> getLK_GZ5916_TBL() {
		return LK_GZ5916_TBL;
	}
	public void setLK_GZ5916_TBL(List<SubFGZ5916STBLVO> lK_GZ5916_TBL) {
		LK_GZ5916_TBL = lK_GZ5916_TBL;
	}
	public String getLK_FIL() {
		return LK_FIL;
	}
	public void setLK_FIL(String lK_FIL) {
		LK_FIL = lK_FIL;
	}
	public String getLK_PIBO_CD() {
		return LK_PIBO_CD;
	}
	public void setLK_PIBO_CD(String lK_PIBO_CD) {
		LK_PIBO_CD = lK_PIBO_CD;
	}
	public String getLK_FIL2() {
		return LK_FIL2;
	}
	public void setLK_FIL2(String lK_FIL2) {
		LK_FIL2 = lK_FIL2;
	}
	
}
