package com.idongbu.smartcustomer.vo;

public class SubFUN5073RVO {
	public String HJ_DAMBO_GUN 			= null;
	public String HJ_DAMBO_NAME 		= null;
	public String JJ_DAMBO_CD 			= null;
	public String JJ_DAMBO_GIGAN 		= null;
	public String JJ_GAIP_GMEK 			= null;
	public String JJ_GIBON_PRM 			= null;
	public String JJ_BOHUM_GIGAN_SYMD 	= null;
	public String JJ_BOHUM_GIGAN_EYMD 	= null;
	public String JJ_DAMBO_LNAPIP_YM 	= null;
	public String getHJ_DAMBO_GUN() {
		return HJ_DAMBO_GUN;
	}
	public void setHJ_DAMBO_GUN(String hJ_DAMBO_GUN) {
		HJ_DAMBO_GUN = hJ_DAMBO_GUN;
	}
	public String getHJ_DAMBO_NAME() {
		return HJ_DAMBO_NAME;
	}
	public void setHJ_DAMBO_NAME(String hJ_DAMBO_NAME) {
		HJ_DAMBO_NAME = hJ_DAMBO_NAME;
	}
	public String getJJ_DAMBO_CD() {
		return JJ_DAMBO_CD;
	}
	public void setJJ_DAMBO_CD(String jJ_DAMBO_CD) {
		JJ_DAMBO_CD = jJ_DAMBO_CD;
	}
	public String getJJ_DAMBO_GIGAN() {
		return JJ_DAMBO_GIGAN;
	}
	public void setJJ_DAMBO_GIGAN(String jJ_DAMBO_GIGAN) {
		JJ_DAMBO_GIGAN = jJ_DAMBO_GIGAN;
	}
	public String getJJ_GAIP_GMEK() {
		return JJ_GAIP_GMEK;
	}
	public void setJJ_GAIP_GMEK(String jJ_GAIP_GMEK) {
		JJ_GAIP_GMEK = jJ_GAIP_GMEK;
	}
	public String getJJ_GIBON_PRM() {
		return JJ_GIBON_PRM;
	}
	public void setJJ_GIBON_PRM(String jJ_GIBON_PRM) {
		JJ_GIBON_PRM = jJ_GIBON_PRM;
	}
	public String getJJ_BOHUM_GIGAN_SYMD() {
		return JJ_BOHUM_GIGAN_SYMD;
	}
	public void setJJ_BOHUM_GIGAN_SYMD(String jJ_BOHUM_GIGAN_SYMD) {
		JJ_BOHUM_GIGAN_SYMD = jJ_BOHUM_GIGAN_SYMD;
	}
	public String getJJ_BOHUM_GIGAN_EYMD() {
		return JJ_BOHUM_GIGAN_EYMD;
	}
	public void setJJ_BOHUM_GIGAN_EYMD(String jJ_BOHUM_GIGAN_EYMD) {
		JJ_BOHUM_GIGAN_EYMD = jJ_BOHUM_GIGAN_EYMD;
	}
	public String getJJ_DAMBO_LNAPIP_YM() {
		return JJ_DAMBO_LNAPIP_YM;
	}
	public void setJJ_DAMBO_LNAPIP_YM(String jJ_DAMBO_LNAPIP_YM) {
		JJ_DAMBO_LNAPIP_YM = jJ_DAMBO_LNAPIP_YM;
	}
}
