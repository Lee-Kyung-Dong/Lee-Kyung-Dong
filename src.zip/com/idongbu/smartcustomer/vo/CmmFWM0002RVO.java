package com.idongbu.smartcustomer.vo;

import com.idongbu.common.vo.CMMVO;


// 산출 내역 확정
public class CmmFWM0002RVO extends CMMVO {
	public CmmFWM0002RVO() {
		super.setPGMID(this.proid);
		super.setTRID(this.trid);
	}
	public static final String proid		= "FWM0002R";
	public static final String trid		= "WM02";
	public String rURL						= "";

	// 입력
	private String COMM_CHANNEL        = null; // 채널구분
	private String COMM_UNIQUE         = null; // TSQ,VSAM FILE용 UNIQUE
	private String COMM_PROGRAM          = null; // PROGRAM-ID
	private String COMM_TRANS        = null; // 처리구분
	private String COMM_ACTION        = null; // 기능키
	private String COMM_USER_GB   = null; // 사용자구분
	private String COMM_USER_ID   = null; // 사용자ID
	private String COMM_JIJUM_CD  = null; // 사용자지점
	private String COMM_JIBU_CD   = null; // 사용자지부
	private String COMM_PROTOCOL       = null; // 전문사용구분
	private String COMM_FIL = null; // FILLER
	private String SCREEN_AREA = null;
	private String COMM_SULGYE_NO = null; // 설계번호
	private String COMM_CHUNGYAK_DTE = null; // 청약일
	private String COMM_BO_GIGAN_SYMD = null; // 보험기간 시작일
	private String COMM_BO_GIGAN_EYMD = null; // 보험기간 종료일
	private String COMM_JUKYONG_RATE1 = null; // 적용 1
	private String COMM_JUKYONG_RATE2 = null; // 적용 2
	private String COMM_JUKYONG_RATE3 = null; // 적용 3
	private String COMM_JUKYONG_RATE4 = null; // 적용 4
	private String H_COMM_NABIB_BANG = null; // 납입방법
	private String H_COMM_PIBOHUMJA = null; // 피보험자명
	private String H_COMM_GAJOK = null; // 가족사항
	private String COMM_GU_POLI_NO1 = null; // 구증권번호 1
	private String COMM_GU_POLI_NO2 = null; // 구증권번호 2
	private String COMM_NAPIP_PRM = null; // 납입보험료
	private String COMM_UD_AREA = null;
	private String USER_FBRT_AREA = null;
	private String USER_FBRT_MAP = null; // FIELD BRIGHT MAP
	private String[] USER_FBRT_INDEX = new String[0]; // 10
	private String[] USER_FBRT_IDX = new String[0]; // 10
	private String USER_FPRT_AREA = null;
	private String USER_FPRT_MAP = null; // FIELD PROTECT MAP
	private String[] USER_FPRT_INDEX = new String[0]; // 5
	private String[] USER_FPRT_IDX = new String[0]; // 5
	private String USER_UD_AREA = null;
	private String USER_BOJONG_CD = null; // 보종코드
	private String USER_U_UPMU_GB    = null; // 업무구분
	private String USER_U_BJ_CD = null; // 보종코드
	private String USER_U_SULGYE_NO = null; // 설계번호
	private String USER_U_POLI_NO = null; // 증권번호
	private String USER_U_BAESEO = null; // 배서 SEQ
	private String USER_U_CHUNGYAK_DTE = null; // 청약일
	private String USER_U_UPMU_GB1    = null; // 업무구분1
	private String USER_U_BJ_CD1 = null; // 보종 CD 1
	private String USER_U_SULGYE_NO1 = null; // 설계번호1
	private String USER_U_POLI_NO1 = null; // 증권번호1
	private String USER_U_BAESEO1 = null; // 배서 1

	// 출력
//	private String COMM_CHANNEL = null;
//	private String COMM_UNIQUE = null;
//	private String COMM_PROGRAM = null;
//	private String COMM_TRANS = null;
//	private String COMM_ACTION = null;
//	private String COMM_USER_GB = null;
//	private String COMM_USER_ID = null;
//	private String COMM_JIJUM_CD = null;
//	private String COMM_JIBU_CD = null;
//	private String COMM_PROTOCOL = null;
	private String COMM_RETN_CODE = null;
	private String COMM_LAST_FLAG = null;
	private String COMM_CUR_FLD = null;
	private String COMM_CUR_POS = null;
	private String COMM_MSG_CODE = null;
	private String H_COMM_MSG_NAME = null;
	private String COMM_SYS_ERR = null;
//	private String COMM_FIL = null;
	private String H_COMM_BOJONG_NM = null;
//	private String COMM_SULGYE_NO = null;
	private String COMM_POLI_NO = null;
	private String COMM_POLI_NO1 = null;
	private String COMM_POLI_NO2 = null;
	private String COMM_BAESE01 = null;
	private String H_COMM_BOTONG_NM = null;
	private String H_COMM_GYEYAK_HT = null;
//	private String COMM_CHUNGYAK_DTE = null;
	private String COMM_GYESANG_DTE = null;
//	private String COMM_BO_GIGAN_SYMD = null;
//	private String COMM_BO_GIGAN_EYMD = null;
//	private String COMM_JUKYONG_RATE1 = null;
//	private String COMM_JUKYONG_RATE2 = null;
//	private String COMM_JUKYONG_RATE3 = null;
//	private String COMM_JUKYONG_RATE4 = null;
//	private String H_COMM_NABIB_BANG = null;
	private String H_COMM_GONGDONG_INSU = null;
	private String H_COMM_GANSASA = null;
	private String COMM_CHAMYEO_RATE = null;
//	private String H_COMM_PIBOHUMJA = null;
//	private String H_COMM_GAJOK = null;
	private String COMM_GU_POLI_NO = null;
//	private String COMM_GU_POLI_NO1 = null;
//	private String COMM_GU_POLI_NO2 = null;
//	private String COMM_NAPIP_PRM = null;
//	private String USER_FBRT_MAP = null;
//	private String[] USER_FBRT_INDEX = new String[0]; // 10
//	private String[] USER_FBRT_IDX = new String[0]; // 10
//	private String USER_FPRT_MAP = null;
//	private String[] USER_FPRT_INDEX = new String[0]; // 5
//	private String[] USER_FPRT_IDX = new String[0]; // 5
//	private String USER_BOJONG_CD = null;
//	private String USER_U_UPMU_GB = null;
//	private String USER_U_BJ_CD = null;
//	private String USER_U_SULGYE_NO = null;
//	private String USER_U_POLI_NO = null;
//	private String USER_U_BAESEO = null;
//	private String USER_U_CHUNGYAK_DTE = null;
//	private String USER_U_UPMU_GB1 = null;
//	private String USER_U_BJ_CD1 = null;
//	private String USER_U_SULGYE_NO1 = null;
//	private String USER_U_POLI_NO1 = null;
//	private String USER_U_BAESEO1 = null;
	private String Length = null;
	private String RecordName = null;
	private String RecordShortDescription = null;
	private String Version = null;
	public String getrURL() {
		return rURL;
	}
	public void setrURL(String rURL) {
		this.rURL = rURL;
	}
	public String getCOMM_CHANNEL() {
		return COMM_CHANNEL;
	}
	public void setCOMM_CHANNEL(String cOMM_CHANNEL) {
		COMM_CHANNEL = cOMM_CHANNEL;
	}
	public String getCOMM_UNIQUE() {
		return COMM_UNIQUE;
	}
	public void setCOMM_UNIQUE(String cOMM_UNIQUE) {
		COMM_UNIQUE = cOMM_UNIQUE;
	}
	public String getCOMM_PROGRAM() {
		return COMM_PROGRAM;
	}
	public void setCOMM_PROGRAM(String cOMM_PROGRAM) {
		COMM_PROGRAM = cOMM_PROGRAM;
	}
	public String getCOMM_TRANS() {
		return COMM_TRANS;
	}
	public void setCOMM_TRANS(String cOMM_TRANS) {
		COMM_TRANS = cOMM_TRANS;
	}
	public String getCOMM_ACTION() {
		return COMM_ACTION;
	}
	public void setCOMM_ACTION(String cOMM_ACTION) {
		COMM_ACTION = cOMM_ACTION;
	}
	public String getCOMM_USER_GB() {
		return COMM_USER_GB;
	}
	public void setCOMM_USER_GB(String cOMM_USER_GB) {
		COMM_USER_GB = cOMM_USER_GB;
	}
	public String getCOMM_USER_ID() {
		return COMM_USER_ID;
	}
	public void setCOMM_USER_ID(String cOMM_USER_ID) {
		COMM_USER_ID = cOMM_USER_ID;
	}
	public String getCOMM_JIJUM_CD() {
		return COMM_JIJUM_CD;
	}
	public void setCOMM_JIJUM_CD(String cOMM_JIJUM_CD) {
		COMM_JIJUM_CD = cOMM_JIJUM_CD;
	}
	public String getCOMM_JIBU_CD() {
		return COMM_JIBU_CD;
	}
	public void setCOMM_JIBU_CD(String cOMM_JIBU_CD) {
		COMM_JIBU_CD = cOMM_JIBU_CD;
	}
	public String getCOMM_PROTOCOL() {
		return COMM_PROTOCOL;
	}
	public void setCOMM_PROTOCOL(String cOMM_PROTOCOL) {
		COMM_PROTOCOL = cOMM_PROTOCOL;
	}
	public String getCOMM_FIL() {
		return COMM_FIL;
	}
	public void setCOMM_FIL(String cOMM_FIL) {
		COMM_FIL = cOMM_FIL;
	}
	public String getSCREEN_AREA() {
		return SCREEN_AREA;
	}
	public void setSCREEN_AREA(String sCREEN_AREA) {
		SCREEN_AREA = sCREEN_AREA;
	}
	public String getCOMM_SULGYE_NO() {
		return COMM_SULGYE_NO;
	}
	public void setCOMM_SULGYE_NO(String cOMM_SULGYE_NO) {
		COMM_SULGYE_NO = cOMM_SULGYE_NO;
	}
	public String getCOMM_CHUNGYAK_DTE() {
		return COMM_CHUNGYAK_DTE;
	}
	public void setCOMM_CHUNGYAK_DTE(String cOMM_CHUNGYAK_DTE) {
		COMM_CHUNGYAK_DTE = cOMM_CHUNGYAK_DTE;
	}
	public String getCOMM_BO_GIGAN_SYMD() {
		return COMM_BO_GIGAN_SYMD;
	}
	public void setCOMM_BO_GIGAN_SYMD(String cOMM_BO_GIGAN_SYMD) {
		COMM_BO_GIGAN_SYMD = cOMM_BO_GIGAN_SYMD;
	}
	public String getCOMM_BO_GIGAN_EYMD() {
		return COMM_BO_GIGAN_EYMD;
	}
	public void setCOMM_BO_GIGAN_EYMD(String cOMM_BO_GIGAN_EYMD) {
		COMM_BO_GIGAN_EYMD = cOMM_BO_GIGAN_EYMD;
	}
	public String getCOMM_JUKYONG_RATE1() {
		return COMM_JUKYONG_RATE1;
	}
	public void setCOMM_JUKYONG_RATE1(String cOMM_JUKYONG_RATE1) {
		COMM_JUKYONG_RATE1 = cOMM_JUKYONG_RATE1;
	}
	public String getCOMM_JUKYONG_RATE2() {
		return COMM_JUKYONG_RATE2;
	}
	public void setCOMM_JUKYONG_RATE2(String cOMM_JUKYONG_RATE2) {
		COMM_JUKYONG_RATE2 = cOMM_JUKYONG_RATE2;
	}
	public String getCOMM_JUKYONG_RATE3() {
		return COMM_JUKYONG_RATE3;
	}
	public void setCOMM_JUKYONG_RATE3(String cOMM_JUKYONG_RATE3) {
		COMM_JUKYONG_RATE3 = cOMM_JUKYONG_RATE3;
	}
	public String getCOMM_JUKYONG_RATE4() {
		return COMM_JUKYONG_RATE4;
	}
	public void setCOMM_JUKYONG_RATE4(String cOMM_JUKYONG_RATE4) {
		COMM_JUKYONG_RATE4 = cOMM_JUKYONG_RATE4;
	}
	public String getH_COMM_NABIB_BANG() {
		return H_COMM_NABIB_BANG;
	}
	public void setH_COMM_NABIB_BANG(String h_COMM_NABIB_BANG) {
		H_COMM_NABIB_BANG = h_COMM_NABIB_BANG;
	}
	public String getH_COMM_PIBOHUMJA() {
		return H_COMM_PIBOHUMJA;
	}
	public void setH_COMM_PIBOHUMJA(String h_COMM_PIBOHUMJA) {
		H_COMM_PIBOHUMJA = h_COMM_PIBOHUMJA;
	}
	public String getH_COMM_GAJOK() {
		return H_COMM_GAJOK;
	}
	public void setH_COMM_GAJOK(String h_COMM_GAJOK) {
		H_COMM_GAJOK = h_COMM_GAJOK;
	}
	public String getCOMM_GU_POLI_NO1() {
		return COMM_GU_POLI_NO1;
	}
	public void setCOMM_GU_POLI_NO1(String cOMM_GU_POLI_NO1) {
		COMM_GU_POLI_NO1 = cOMM_GU_POLI_NO1;
	}
	public String getCOMM_GU_POLI_NO2() {
		return COMM_GU_POLI_NO2;
	}
	public void setCOMM_GU_POLI_NO2(String cOMM_GU_POLI_NO2) {
		COMM_GU_POLI_NO2 = cOMM_GU_POLI_NO2;
	}
	public String getCOMM_NAPIP_PRM() {
		return COMM_NAPIP_PRM;
	}
	public void setCOMM_NAPIP_PRM(String cOMM_NAPIP_PRM) {
		COMM_NAPIP_PRM = cOMM_NAPIP_PRM;
	}
	public String getCOMM_UD_AREA() {
		return COMM_UD_AREA;
	}
	public void setCOMM_UD_AREA(String cOMM_UD_AREA) {
		COMM_UD_AREA = cOMM_UD_AREA;
	}
	public String getUSER_FBRT_AREA() {
		return USER_FBRT_AREA;
	}
	public void setUSER_FBRT_AREA(String uSER_FBRT_AREA) {
		USER_FBRT_AREA = uSER_FBRT_AREA;
	}
	public String getUSER_FBRT_MAP() {
		return USER_FBRT_MAP;
	}
	public void setUSER_FBRT_MAP(String uSER_FBRT_MAP) {
		USER_FBRT_MAP = uSER_FBRT_MAP;
	}
	public String[] getUSER_FBRT_INDEX() {
		return USER_FBRT_INDEX;
	}
	public void setUSER_FBRT_INDEX(String[] uSER_FBRT_INDEX) {
		USER_FBRT_INDEX = uSER_FBRT_INDEX;
	}
	public String[] getUSER_FBRT_IDX() {
		return USER_FBRT_IDX;
	}
	public void setUSER_FBRT_IDX(String[] uSER_FBRT_IDX) {
		USER_FBRT_IDX = uSER_FBRT_IDX;
	}
	public String getUSER_FPRT_AREA() {
		return USER_FPRT_AREA;
	}
	public void setUSER_FPRT_AREA(String uSER_FPRT_AREA) {
		USER_FPRT_AREA = uSER_FPRT_AREA;
	}
	public String getUSER_FPRT_MAP() {
		return USER_FPRT_MAP;
	}
	public void setUSER_FPRT_MAP(String uSER_FPRT_MAP) {
		USER_FPRT_MAP = uSER_FPRT_MAP;
	}
	public String[] getUSER_FPRT_INDEX() {
		return USER_FPRT_INDEX;
	}
	public void setUSER_FPRT_INDEX(String[] uSER_FPRT_INDEX) {
		USER_FPRT_INDEX = uSER_FPRT_INDEX;
	}
	public String[] getUSER_FPRT_IDX() {
		return USER_FPRT_IDX;
	}
	public void setUSER_FPRT_IDX(String[] uSER_FPRT_IDX) {
		USER_FPRT_IDX = uSER_FPRT_IDX;
	}
	public String getUSER_UD_AREA() {
		return USER_UD_AREA;
	}
	public void setUSER_UD_AREA(String uSER_UD_AREA) {
		USER_UD_AREA = uSER_UD_AREA;
	}
	public String getUSER_BOJONG_CD() {
		return USER_BOJONG_CD;
	}
	public void setUSER_BOJONG_CD(String uSER_BOJONG_CD) {
		USER_BOJONG_CD = uSER_BOJONG_CD;
	}
	public String getUSER_U_UPMU_GB() {
		return USER_U_UPMU_GB;
	}
	public void setUSER_U_UPMU_GB(String uSER_U_UPMU_GB) {
		USER_U_UPMU_GB = uSER_U_UPMU_GB;
	}
	public String getUSER_U_BJ_CD() {
		return USER_U_BJ_CD;
	}
	public void setUSER_U_BJ_CD(String uSER_U_BJ_CD) {
		USER_U_BJ_CD = uSER_U_BJ_CD;
	}
	public String getUSER_U_SULGYE_NO() {
		return USER_U_SULGYE_NO;
	}
	public void setUSER_U_SULGYE_NO(String uSER_U_SULGYE_NO) {
		USER_U_SULGYE_NO = uSER_U_SULGYE_NO;
	}
	public String getUSER_U_POLI_NO() {
		return USER_U_POLI_NO;
	}
	public void setUSER_U_POLI_NO(String uSER_U_POLI_NO) {
		USER_U_POLI_NO = uSER_U_POLI_NO;
	}
	public String getUSER_U_BAESEO() {
		return USER_U_BAESEO;
	}
	public void setUSER_U_BAESEO(String uSER_U_BAESEO) {
		USER_U_BAESEO = uSER_U_BAESEO;
	}
	public String getUSER_U_CHUNGYAK_DTE() {
		return USER_U_CHUNGYAK_DTE;
	}
	public void setUSER_U_CHUNGYAK_DTE(String uSER_U_CHUNGYAK_DTE) {
		USER_U_CHUNGYAK_DTE = uSER_U_CHUNGYAK_DTE;
	}
	public String getUSER_U_UPMU_GB1() {
		return USER_U_UPMU_GB1;
	}
	public void setUSER_U_UPMU_GB1(String uSER_U_UPMU_GB1) {
		USER_U_UPMU_GB1 = uSER_U_UPMU_GB1;
	}
	public String getUSER_U_BJ_CD1() {
		return USER_U_BJ_CD1;
	}
	public void setUSER_U_BJ_CD1(String uSER_U_BJ_CD1) {
		USER_U_BJ_CD1 = uSER_U_BJ_CD1;
	}
	public String getUSER_U_SULGYE_NO1() {
		return USER_U_SULGYE_NO1;
	}
	public void setUSER_U_SULGYE_NO1(String uSER_U_SULGYE_NO1) {
		USER_U_SULGYE_NO1 = uSER_U_SULGYE_NO1;
	}
	public String getUSER_U_POLI_NO1() {
		return USER_U_POLI_NO1;
	}
	public void setUSER_U_POLI_NO1(String uSER_U_POLI_NO1) {
		USER_U_POLI_NO1 = uSER_U_POLI_NO1;
	}
	public String getUSER_U_BAESEO1() {
		return USER_U_BAESEO1;
	}
	public void setUSER_U_BAESEO1(String uSER_U_BAESEO1) {
		USER_U_BAESEO1 = uSER_U_BAESEO1;
	}
	public String getCOMM_RETN_CODE() {
		return COMM_RETN_CODE;
	}
	public void setCOMM_RETN_CODE(String cOMM_RETN_CODE) {
		COMM_RETN_CODE = cOMM_RETN_CODE;
	}
	public String getCOMM_LAST_FLAG() {
		return COMM_LAST_FLAG;
	}
	public void setCOMM_LAST_FLAG(String cOMM_LAST_FLAG) {
		COMM_LAST_FLAG = cOMM_LAST_FLAG;
	}
	public String getCOMM_CUR_FLD() {
		return COMM_CUR_FLD;
	}
	public void setCOMM_CUR_FLD(String cOMM_CUR_FLD) {
		COMM_CUR_FLD = cOMM_CUR_FLD;
	}
	public String getCOMM_CUR_POS() {
		return COMM_CUR_POS;
	}
	public void setCOMM_CUR_POS(String cOMM_CUR_POS) {
		COMM_CUR_POS = cOMM_CUR_POS;
	}
	public String getCOMM_MSG_CODE() {
		return COMM_MSG_CODE;
	}
	public void setCOMM_MSG_CODE(String cOMM_MSG_CODE) {
		COMM_MSG_CODE = cOMM_MSG_CODE;
	}
	public String getH_COMM_MSG_NAME() {
		return H_COMM_MSG_NAME;
	}
	public void setH_COMM_MSG_NAME(String h_COMM_MSG_NAME) {
		H_COMM_MSG_NAME = h_COMM_MSG_NAME;
	}
	public String getCOMM_SYS_ERR() {
		return COMM_SYS_ERR;
	}
	public void setCOMM_SYS_ERR(String cOMM_SYS_ERR) {
		COMM_SYS_ERR = cOMM_SYS_ERR;
	}
	public String getH_COMM_BOJONG_NM() {
		return H_COMM_BOJONG_NM;
	}
	public void setH_COMM_BOJONG_NM(String h_COMM_BOJONG_NM) {
		H_COMM_BOJONG_NM = h_COMM_BOJONG_NM;
	}
	public String getCOMM_POLI_NO() {
		return COMM_POLI_NO;
	}
	public void setCOMM_POLI_NO(String cOMM_POLI_NO) {
		COMM_POLI_NO = cOMM_POLI_NO;
	}
	public String getCOMM_POLI_NO1() {
		return COMM_POLI_NO1;
	}
	public void setCOMM_POLI_NO1(String cOMM_POLI_NO1) {
		COMM_POLI_NO1 = cOMM_POLI_NO1;
	}
	public String getCOMM_POLI_NO2() {
		return COMM_POLI_NO2;
	}
	public void setCOMM_POLI_NO2(String cOMM_POLI_NO2) {
		COMM_POLI_NO2 = cOMM_POLI_NO2;
	}
	public String getCOMM_BAESE01() {
		return COMM_BAESE01;
	}
	public void setCOMM_BAESE01(String cOMM_BAESE01) {
		COMM_BAESE01 = cOMM_BAESE01;
	}
	public String getH_COMM_BOTONG_NM() {
		return H_COMM_BOTONG_NM;
	}
	public void setH_COMM_BOTONG_NM(String h_COMM_BOTONG_NM) {
		H_COMM_BOTONG_NM = h_COMM_BOTONG_NM;
	}
	public String getH_COMM_GYEYAK_HT() {
		return H_COMM_GYEYAK_HT;
	}
	public void setH_COMM_GYEYAK_HT(String h_COMM_GYEYAK_HT) {
		H_COMM_GYEYAK_HT = h_COMM_GYEYAK_HT;
	}
	public String getCOMM_GYESANG_DTE() {
		return COMM_GYESANG_DTE;
	}
	public void setCOMM_GYESANG_DTE(String cOMM_GYESANG_DTE) {
		COMM_GYESANG_DTE = cOMM_GYESANG_DTE;
	}
	public String getH_COMM_GONGDONG_INSU() {
		return H_COMM_GONGDONG_INSU;
	}
	public void setH_COMM_GONGDONG_INSU(String h_COMM_GONGDONG_INSU) {
		H_COMM_GONGDONG_INSU = h_COMM_GONGDONG_INSU;
	}
	public String getH_COMM_GANSASA() {
		return H_COMM_GANSASA;
	}
	public void setH_COMM_GANSASA(String h_COMM_GANSASA) {
		H_COMM_GANSASA = h_COMM_GANSASA;
	}
	public String getCOMM_CHAMYEO_RATE() {
		return COMM_CHAMYEO_RATE;
	}
	public void setCOMM_CHAMYEO_RATE(String cOMM_CHAMYEO_RATE) {
		COMM_CHAMYEO_RATE = cOMM_CHAMYEO_RATE;
	}
	public String getCOMM_GU_POLI_NO() {
		return COMM_GU_POLI_NO;
	}
	public void setCOMM_GU_POLI_NO(String cOMM_GU_POLI_NO) {
		COMM_GU_POLI_NO = cOMM_GU_POLI_NO;
	}
	public String getLength() {
		return Length;
	}
	public void setLength(String length) {
		Length = length;
	}
	public String getRecordName() {
		return RecordName;
	}
	public void setRecordName(String recordName) {
		RecordName = recordName;
	}
	public String getRecordShortDescription() {
		return RecordShortDescription;
	}
	public void setRecordShortDescription(String recordShortDescription) {
		RecordShortDescription = recordShortDescription;
	}
	public String getVersion() {
		return Version;
	}
	public void setVersion(String version) {
		Version = version;
	}
	
}
