package com.idongbu.smartcustomer.vo;

//대출송금계좌신청 및 변경 VO
public class LoInsuRemitVO {
	
	private String proc_dvn = "";			//[I] 처리구분 (0:조회, 1:등록, 5:해지)
	private String cust_no = "";				//[I] 고객번호
	private String rmn_acc_chng_sqno = "";	//[O] 송금계좌변경일련번호
	private String str_dt = "";				//[O] 시작일자
	private String fin_dt = "";				//[O] 종료일자
	private String tsfr_aply_dvcd = "";		//[O] 이체신청구분코드(1:등록,5:해지)	
	private String bank_cd = "";				//[I/O] 은행코드
	private String acc_no = "";				//[I/O] 계좌번호
	private String dpsr_nm = "";				//[I/O] 예금주명
	private String dpsr_rlt_cd = "";			//[O] 예금주관계코드(101 : 고정 -계약자본인계좌만 가능)
	private String regt_dt = "";				//[O] 등록일자
	private String trmt_dt = "";				//[O] 해지일자
	private String regt_dlmn_empno = "";		//[O] 등록처리자사원번호(처리구분이 조회/등록/변경인경우) 
	private String trmt_dlmn_empno = "";		//[O] 해지처리자사원번호(처리구분이 해지인경우)
	private String sc_yn = "";				//[O] 스캔여부
	
	public String errorCode = "";
	public String returnMessage = "";
	public String z_resp_msg = "";
	public String z_resp_cd = "";
	
	private String bank_nm = "";			//은행명
	private String apply_way_nm = "";		//등록방법
	private String acc_no_view = "";		//계좌번호 view
	private String regt_dt_view = "";		//등록일자 view
	
	private String bank_nm_next = "";		//은행명(변경할 정보)
	private String bank_cd_next = "";		//은행코드(변경할 정보)
	private String acc_no_next = "";		//계좌번호(변경할 정보)
	private String acc_no_next_view = "";	//계좌번호(변경할 정보) view
	private String dpsr_nm_next = "";		//예금주명(변경할 정보)
	
	public String getProc_dvn() {
		return proc_dvn;
	}

	public void setProc_dvn(String proc_dvn) {
		this.proc_dvn = proc_dvn;
	}

	public String getCust_no() {
		return cust_no;
	}

	public void setCust_no(String cust_no) {
		this.cust_no = cust_no;
	}

	public String getRmn_acc_chng_sqno() {
		return rmn_acc_chng_sqno;
	}

	public void setRmn_acc_chng_sqno(String rmn_acc_chng_sqno) {
		this.rmn_acc_chng_sqno = rmn_acc_chng_sqno;
	}

	public String getStr_dt() {
		return str_dt;
	}

	public void setStr_dt(String str_dt) {
		this.str_dt = str_dt;
	}

	public String getFin_dt() {
		return fin_dt;
	}

	public void setFin_dt(String fin_dt) {
		this.fin_dt = fin_dt;
	}

	public String getTsfr_aply_dvcd() {
		return tsfr_aply_dvcd;
	}

	public void setTsfr_aply_dvcd(String tsfr_aply_dvcd) {
		this.tsfr_aply_dvcd = tsfr_aply_dvcd;
	}

	public String getBank_cd() {
		return bank_cd;
	}

	public void setBank_cd(String bank_cd) {
		this.bank_cd = bank_cd;
	}

	public String getAcc_no() {
		return acc_no;
	}

	public void setAcc_no(String acc_no) {
		this.acc_no = acc_no;
	}

	public String getDpsr_nm() {
		return dpsr_nm;
	}

	public void setDpsr_nm(String dpsr_nm) {
		this.dpsr_nm = dpsr_nm;
	}

	public String getDpsr_rlt_cd() {
		return dpsr_rlt_cd;
	}

	public void setDpsr_rlt_cd(String dpsr_rlt_cd) {
		this.dpsr_rlt_cd = dpsr_rlt_cd;
	}

	public String getRegt_dt() {
		return regt_dt;
	}

	public void setRegt_dt(String regt_dt) {
		this.regt_dt = regt_dt;
	}

	public String getTrmt_dt() {
		return trmt_dt;
	}

	public void setTrmt_dt(String trmt_dt) {
		this.trmt_dt = trmt_dt;
	}

	public String getRegt_dlmn_empno() {
		return regt_dlmn_empno;
	}

	public void setRegt_dlmn_empno(String regt_dlmn_empno) {
		this.regt_dlmn_empno = regt_dlmn_empno;
	}

	public String getTrmt_dlmn_empno() {
		return trmt_dlmn_empno;
	}

	public void setTrmt_dlmn_empno(String trmt_dlmn_empno) {
		this.trmt_dlmn_empno = trmt_dlmn_empno;
	}

	public String getSc_yn() {
		return sc_yn;
	}

	public void setSc_yn(String sc_yn) {
		this.sc_yn = sc_yn;
	}
	
	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getReturnMessage() {
		return returnMessage;
	}

	public void setReturnMessage(String returnMessage) {
		this.returnMessage = returnMessage;
	}

	public String getZ_resp_msg() {
		return z_resp_msg;
	}

	public void setZ_resp_msg(String z_resp_msg) {
		this.z_resp_msg = z_resp_msg;
	}

	public String getZ_resp_cd() {
		return z_resp_cd;
	}

	public void setZ_resp_cd(String z_resp_cd) {
		this.z_resp_cd = z_resp_cd;
	}

	public String getBank_nm() {
		return bank_nm;
	}

	public void setBank_nm(String bank_nm) {
		this.bank_nm = bank_nm;
	}

	public String getApply_way_nm() {
		return apply_way_nm;
	}

	public void setApply_way_nm(String apply_way_nm) {
		this.apply_way_nm = apply_way_nm;
	}

	public String getAcc_no_view() {
		return acc_no_view;
	}

	public void setAcc_no_view(String acc_no_view) {
		this.acc_no_view = acc_no_view;
	}

	public String getRegt_dt_view() {
		return regt_dt_view;
	}

	public void setRegt_dt_view(String regt_dt_view) {
		this.regt_dt_view = regt_dt_view;
	}
	
	public String getBank_nm_next() {
		return bank_nm_next;
	}

	public void setBank_nm_next(String bank_nm_next) {
		this.bank_nm_next = bank_nm_next;
	}

	public String getBank_cd_next() {
		return bank_cd_next;
	}

	public void setBank_cd_next(String bank_cd_next) {
		this.bank_cd_next = bank_cd_next;
	}

	public String getAcc_no_next() {
		return acc_no_next;
	}

	public void setAcc_no_next(String acc_no_next) {
		this.acc_no_next = acc_no_next;
	}
	
	public String getAcc_no_next_view() {
		return acc_no_next_view;
	}

	public void setAcc_no_next_view(String acc_no_next_view) {
		this.acc_no_next_view = acc_no_next_view;
	}

	public String getDpsr_nm_next() {
		return dpsr_nm_next;
	}

	public void setDpsr_nm_next(String dpsr_nm_next) {
		this.dpsr_nm_next = dpsr_nm_next;
	}
	
	
}
