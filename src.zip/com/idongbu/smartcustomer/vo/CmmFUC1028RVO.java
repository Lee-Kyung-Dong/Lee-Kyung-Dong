package com.idongbu.smartcustomer.vo;

import com.idongbu.common.vo.CMMVO;

public class CmmFUC1028RVO extends CMMVO {
	
	public CmmFUC1028RVO() {
		super.setPGMID(proid);
		super.setTRID(trid);
	}
	
	private final static String proid		= "FUC1028R";
	private final static String trid		= "UC1S";
	
	private String CC_CHANNEL;
	private String CC_UKEY;
	private String CC_PGMID;
	private String CC_PROC_GB;
	private String CC_FUN_KEY;
	
	private String CC_USER_GB;
	private String CC_USER_CD;
	
	private String CC_JIJUM_CD;
	private String CC_JIBU_CD;
	
	private String CC_PROTOCOL;
	private String CC_COND_CD;
	private String CC_LAST_FLAG;
	private String CC_CURSOR_MAP;
	private String CC_CURSOR_IDX;
	private String CC_MESSAGE_CD;
	private String HC_MESSAGE_NM;
	private String CC_SYS_ERR;
	private String CC_TS_ITEM;
	private String CC_FORM_ID;
	private String CC_PRT_GB;
	private String CC_PRINT_GB;
	private String CC_PRINT_TYPE;
	private String CC_WRITEQ_YN;
	private String CC_FORM_PAGE;
	private String CC_FILLER;
	
	private String JJ_SELECT;
	
	private String JJ_POLINO;
	
	private String JJ_DATE_FR;
	private String JJ_DATE_TO;
	private String JJ_JIJUM;
	private String JJ_TEAM;
	private String JJ_BOJONG;
	
	private String JJ_IPRYUKJA;
	
	private String JJ_PRINT_DATA;
	private String JJ_PRINT_ESIGN;
	private String JJ_REWRT_GB;
	
	private String RD_POLICY_YN;
	private String RD_COPY_YN;
	private String RD_GREEN_YN;
	private String RD_ENCRYPT_YN;
	private String RD_ENCRYPT_KEY;
	private String RD_UPMU_GB;
	private String RD_DOCU_GB;
	private String RD_SIGN_KEY;
	private String RD_FORM_GB;
	
	private String UU_ITEM;
	private String UU_INDX;
	
	public String getCC_CHANNEL() {
		return CC_CHANNEL;
	}
	public void setCC_CHANNEL(String cC_CHANNEL) {
		CC_CHANNEL = cC_CHANNEL;
	}
	public String getCC_UKEY() {
		return CC_UKEY;
	}
	public void setCC_UKEY(String cC_UKEY) {
		CC_UKEY = cC_UKEY;
	}
	public String getCC_PGMID() {
		return CC_PGMID;
	}
	public void setCC_PGMID(String cC_PGMID) {
		CC_PGMID = cC_PGMID;
	}
	public String getCC_PROC_GB() {
		return CC_PROC_GB;
	}
	public void setCC_PROC_GB(String cC_PROC_GB) {
		CC_PROC_GB = cC_PROC_GB;
	}
	public String getCC_FUN_KEY() {
		return CC_FUN_KEY;
	}
	public void setCC_FUN_KEY(String cC_FUN_KEY) {
		CC_FUN_KEY = cC_FUN_KEY;
	}
	public String getCC_USER_GB() {
		return CC_USER_GB;
	}
	public void setCC_USER_GB(String cC_USER_GB) {
		CC_USER_GB = cC_USER_GB;
	}
	public String getCC_USER_CD() {
		return CC_USER_CD;
	}
	public void setCC_USER_CD(String cC_USER_CD) {
		CC_USER_CD = cC_USER_CD;
	}
	public String getCC_JIJUM_CD() {
		return CC_JIJUM_CD;
	}
	public void setCC_JIJUM_CD(String cC_JIJUM_CD) {
		CC_JIJUM_CD = cC_JIJUM_CD;
	}
	public String getCC_JIBU_CD() {
		return CC_JIBU_CD;
	}
	public void setCC_JIBU_CD(String cC_JIBU_CD) {
		CC_JIBU_CD = cC_JIBU_CD;
	}
	public String getCC_PROTOCOL() {
		return CC_PROTOCOL;
	}
	public void setCC_PROTOCOL(String cC_PROTOCOL) {
		CC_PROTOCOL = cC_PROTOCOL;
	}
	public String getCC_COND_CD() {
		return CC_COND_CD;
	}
	public void setCC_COND_CD(String cC_COND_CD) {
		CC_COND_CD = cC_COND_CD;
	}
	public String getCC_LAST_FLAG() {
		return CC_LAST_FLAG;
	}
	public void setCC_LAST_FLAG(String cC_LAST_FLAG) {
		CC_LAST_FLAG = cC_LAST_FLAG;
	}
	public String getCC_CURSOR_MAP() {
		return CC_CURSOR_MAP;
	}
	public void setCC_CURSOR_MAP(String cC_CURSOR_MAP) {
		CC_CURSOR_MAP = cC_CURSOR_MAP;
	}
	public String getCC_CURSOR_IDX() {
		return CC_CURSOR_IDX;
	}
	public void setCC_CURSOR_IDX(String cC_CURSOR_IDX) {
		CC_CURSOR_IDX = cC_CURSOR_IDX;
	}
	public String getCC_MESSAGE_CD() {
		return CC_MESSAGE_CD;
	}
	public void setCC_MESSAGE_CD(String cC_MESSAGE_CD) {
		CC_MESSAGE_CD = cC_MESSAGE_CD;
	}
	public String getHC_MESSAGE_NM() {
		return HC_MESSAGE_NM;
	}
	public void setHC_MESSAGE_NM(String hC_MESSAGE_NM) {
		HC_MESSAGE_NM = hC_MESSAGE_NM;
	}
	public String getCC_SYS_ERR() {
		return CC_SYS_ERR;
	}
	public void setCC_SYS_ERR(String cC_SYS_ERR) {
		CC_SYS_ERR = cC_SYS_ERR;
	}
	public String getCC_TS_ITEM() {
		return CC_TS_ITEM;
	}
	public void setCC_TS_ITEM(String cC_TS_ITEM) {
		CC_TS_ITEM = cC_TS_ITEM;
	}
	public String getCC_FORM_ID() {
		return CC_FORM_ID;
	}
	public void setCC_FORM_ID(String cC_FORM_ID) {
		CC_FORM_ID = cC_FORM_ID;
	}
	public String getCC_PRT_GB() {
		return CC_PRT_GB;
	}
	public void setCC_PRT_GB(String cC_PRT_GB) {
		CC_PRT_GB = cC_PRT_GB;
	}
	public String getCC_PRINT_GB() {
		return CC_PRINT_GB;
	}
	public void setCC_PRINT_GB(String cC_PRINT_GB) {
		CC_PRINT_GB = cC_PRINT_GB;
	}
	public String getCC_PRINT_TYPE() {
		return CC_PRINT_TYPE;
	}
	public void setCC_PRINT_TYPE(String cC_PRINT_TYPE) {
		CC_PRINT_TYPE = cC_PRINT_TYPE;
	}
	public String getCC_WRITEQ_YN() {
		return CC_WRITEQ_YN;
	}
	public void setCC_WRITEQ_YN(String cC_WRITEQ_YN) {
		CC_WRITEQ_YN = cC_WRITEQ_YN;
	}
	public String getCC_FORM_PAGE() {
		return CC_FORM_PAGE;
	}
	public void setCC_FORM_PAGE(String cC_FORM_PAGE) {
		CC_FORM_PAGE = cC_FORM_PAGE;
	}
	public String getCC_FILLER() {
		return CC_FILLER;
	}
	public void setCC_FILLER(String cC_FILLER) {
		CC_FILLER = cC_FILLER;
	}
	public String getJJ_SELECT() {
		return JJ_SELECT;
	}
	public void setJJ_SELECT(String jJ_SELECT) {
		JJ_SELECT = jJ_SELECT;
	}
	public String getJJ_POLINO() {
		return JJ_POLINO;
	}
	public void setJJ_POLINO(String jJ_POLINO) {
		JJ_POLINO = jJ_POLINO;
	}
	public String getJJ_DATE_FR() {
		return JJ_DATE_FR;
	}
	public void setJJ_DATE_FR(String jJ_DATE_FR) {
		JJ_DATE_FR = jJ_DATE_FR;
	}
	public String getJJ_DATE_TO() {
		return JJ_DATE_TO;
	}
	public void setJJ_DATE_TO(String jJ_DATE_TO) {
		JJ_DATE_TO = jJ_DATE_TO;
	}
	public String getJJ_JIJUM() {
		return JJ_JIJUM;
	}
	public void setJJ_JIJUM(String jJ_JIJUM) {
		JJ_JIJUM = jJ_JIJUM;
	}
	public String getJJ_TEAM() {
		return JJ_TEAM;
	}
	public void setJJ_TEAM(String jJ_TEAM) {
		JJ_TEAM = jJ_TEAM;
	}
	public String getJJ_BOJONG() {
		return JJ_BOJONG;
	}
	public void setJJ_BOJONG(String jJ_BOJONG) {
		JJ_BOJONG = jJ_BOJONG;
	}
	public String getJJ_IPRYUKJA() {
		return JJ_IPRYUKJA;
	}
	public void setJJ_IPRYUKJA(String jJ_IPRYUKJA) {
		JJ_IPRYUKJA = jJ_IPRYUKJA;
	}
	public String getJJ_PRINT_DATA() {
		return JJ_PRINT_DATA;
	}
	public void setJJ_PRINT_DATA(String jJ_PRINT_DATA) {
		JJ_PRINT_DATA = jJ_PRINT_DATA;
	}
	public String getJJ_PRINT_ESIGN() {
		return JJ_PRINT_ESIGN;
	}
	public void setJJ_PRINT_ESIGN(String jJ_PRINT_ESIGN) {
		JJ_PRINT_ESIGN = jJ_PRINT_ESIGN;
	}
	public String getRD_POLICY_YN() {
		return RD_POLICY_YN;
	}
	public void setRD_POLICY_YN(String rD_POLICY_YN) {
		RD_POLICY_YN = rD_POLICY_YN;
	}
	public String getRD_COPY_YN() {
		return RD_COPY_YN;
	}
	public void setRD_COPY_YN(String rD_COPY_YN) {
		RD_COPY_YN = rD_COPY_YN;
	}
	public String getRD_GREEN_YN() {
		return RD_GREEN_YN;
	}
	public void setRD_GREEN_YN(String rD_GREEN_YN) {
		RD_GREEN_YN = rD_GREEN_YN;
	}
	public String getRD_ENCRYPT_YN() {
		return RD_ENCRYPT_YN;
	}
	public void setRD_ENCRYPT_YN(String rD_ENCRYPT_YN) {
		RD_ENCRYPT_YN = rD_ENCRYPT_YN;
	}
	public String getRD_ENCRYPT_KEY() {
		return RD_ENCRYPT_KEY;
	}
	public void setRD_ENCRYPT_KEY(String rD_ENCRYPT_KEY) {
		RD_ENCRYPT_KEY = rD_ENCRYPT_KEY;
	}
	public String getRD_UPMU_GB() {
		return RD_UPMU_GB;
	}
	public void setRD_UPMU_GB(String rD_UPMU_GB) {
		RD_UPMU_GB = rD_UPMU_GB;
	}
	public String getRD_DOCU_GB() {
		return RD_DOCU_GB;
	}
	public void setRD_DOCU_GB(String rD_DOCU_GB) {
		RD_DOCU_GB = rD_DOCU_GB;
	}
	public String getRD_SIGN_KEY() {
		return RD_SIGN_KEY;
	}
	public void setRD_SIGN_KEY(String rD_SIGN_KEY) {
		RD_SIGN_KEY = rD_SIGN_KEY;
	}
	public String getRD_FORM_GB() {
		return RD_FORM_GB;
	}
	public void setRD_FORM_GB(String rD_FORM_GB) {
		RD_FORM_GB = rD_FORM_GB;
	}
	public String getUU_ITEM() {
		return UU_ITEM;
	}
	public void setUU_ITEM(String uU_ITEM) {
		UU_ITEM = uU_ITEM;
	}
	public String getUU_INDX() {
		return UU_INDX;
	}
	public void setUU_INDX(String uU_INDX) {
		UU_INDX = uU_INDX;
	}
	public String getProid() {
		return proid;
	}
	public String getTrid() {
		return trid;
	}
	public String getJJ_REWRT_GB() {
		return JJ_REWRT_GB;
	}
	public void setJJ_REWRT_GB(String jJ_REWRT_GB) {
		JJ_REWRT_GB = jJ_REWRT_GB;
	}
	
	
}
