package com.idongbu.smartcustomer.vo;

import com.idongbu.common.vo.CMMVO;

public class CustomerInfoVO extends CMMVO{
	public String r_susinhow =""; //E-Mail 수신 여부

	public String FBM299_COMM_CHANNEL    = "";
	public String FBM299_COMM_UNIQUE_KEY = "";
	public String FBM299_COMM_PGMID      = "";
	public String FBM299_COMM_PROC_GB    = "";
	public String FBM299_COMM_ACTION_KEY = "";
	public String FBM299_COMM_USER_GB    = "";
	public String FBM299_COMM_PROTOCOL   = "";
	public String FBM299_COMM_COND_CD    = "";
	public String FBM299_COMM_LAST_FLAG  = "";
	public String FBM299_COMM_CURSOR_MAP = "";
	public String FBM299_COMM_CURSOR_IDX = "";
	
	//집
	public String SI_H_ZIP   =""; //자택 우편번호 앞자리
	public String SI_H_ZIP1  =""; //자택 우편번호 뒷자리
	public String SI_H_ZIP2  =""; //자택 우편번호 뒷자리
	public String HO_H_JUSO  =""; //자택 주소
	public String HI_H_ADDR  =""; //자택 주소 상세
	public String SI_H_TEL1  =""; //핸드폰1
	public String SI_H_TEL2  =""; //핸드폰2
	public String SI_H_TEL3  =""; //핸드폰3
	public String SI_H_TEL  =""; //핸드폰 총3개
	public String H_ZIP      =""; //변경전 자택 우편번호 앞자리
	public String H_ADDR     =""; //변경전 자택 주소 상세
	public String H_TEL1     =""; //변경전 핸드폰1
	public String H_TEL2     =""; //변경전 핸드폰2
	public String H_TEL3     =""; //변경전 핸드폰3
	public String H_TEL      =""; //변경전 핸드폰 총 합힌거
	//집 (새주소)
	public String SI_H_ZIP_2   =""; //자택 우편번호 앞자리
	public String SI_H_ZIP1_2  =""; //자택 우편번호 뒷자리
	public String SI_H_ZIP2_2  =""; //자택 우편번호 뒷자리
	public String HO_H_JUSO_2  =""; //자택 주소
	public String HI_H_ADDR_2  =""; //자택 주소 상세
	public String H_ZIP_2      =""; //변경전 자택 우편번호 앞자리
	public String H_ADDR_2     =""; //변경전 자택 주소 상세
	
	//직장
	public String SI_J_ZIP   =""; //직장 우편번호 앞자리
	public String SI_J_ZIP1  =""; //직장 우편번호 앞자리
	public String SI_J_ZIP2  =""; //직장 우편번호 뒷자리
	public String HO_J_JUSO  =""; //직장 주소
	public String HI_J_ADDR  =""; //직장 주소 상세
	public String SI_J_TEL1  =""; //직장전화번호1
	public String SI_J_TEL2  =""; //직장전화번호2
	public String SI_J_TEL3  =""; //직장전화번호3
	public String J_ZIP      =""; //변경전 직장 우편번호 앞자리
	public String J_ADDR     =""; //변경전 직장 주소 상세
	public String J_TEL1     =""; //변경전 직장전화번호1
	public String J_TEL2     =""; //변경전 직장전화번호2
	public String J_TEL3     =""; //변경전 직장전화번호3

	// 직장 (새주소)
	public String SI_J_ZIP_2   =""; //직장 우편번호 앞자리
	public String SI_J_ZIP1_2  =""; //직장 우편번호 앞자리
	public String SI_J_ZIP2_2  =""; //직장 우편번호 뒷자리
	public String HO_J_JUSO_2  =""; //직장 주소
	public String HI_J_ADDR_2  =""; //직장 주소 상세
	public String J_ZIP_2      =""; //변경전 직장 우편번호 앞자리
	public String J_ADDR_2     =""; //변경전 직장 주소 상세
	
	//기타
	public String SI_G_ZIP   =""; //기타 우편번호 앞자리
	public String SI_G_ZIP1  =""; //기타 우편번호 앞자리
	public String SI_G_ZIP2  =""; //기타 우편번호 뒷자리
	public String HO_G_JUSO  =""; //기타 주소
	public String HI_G_ADDR  =""; //기타 주소 상세
	public String SI_HP_TEL1 =""; //전화번호1
	public String SI_HP_TEL2 =""; //전화번호2
	public String SI_HP_TEL3 =""; //전화번호3
	public String SI_HP_TEL =""; //전화번호 총3개
	public String G_ZIP      =""; //변경전 기타 우편번호 앞자리
	public String G_ADDR     =""; //변경전 기타 주소 상세
	public String HP_TEL1    =""; //변경전 전화번호1
	public String HP_TEL2    =""; //변경전 전화번호2
	public String HP_TEL3    =""; //변경전 전화번호3
	public String HP_TEL     =""; //변경전 전화번호(총)

	// 기타 (새주소)
	public String SI_G_ZIP_2   =""; //기타 우편번호 앞자리
	public String SI_G_ZIP1_2  =""; //기타 우편번호 앞자리
	public String SI_G_ZIP2_2  =""; //기타 우편번호 뒷자리
	public String HO_G_JUSO_2  =""; //기타 주소
	public String HI_G_ADDR_2  =""; //기타 주소 상세
	public String G_ZIP_2      =""; //변경전 기타 우편번호 앞자리
	public String G_ADDR_2     =""; //변경전 기타 주소 상세
	
	public String SO_H_GBN  = ""; 	//집주소 변경 여부		: #1 고객정보정제 카운트 항목 (HAA_CONFIRM_MBR_INFO.item001) 2008.04.29 by hsahn
	public String SO_J_GBN  = ""; 	//직장 주소 변경여부
	public String SO_G_GBN  = ""; 	//기타 주소 변경여부
	public String SO_HP_GBN = "";	//핸드폰 변경여부		: #3 고객정보정제 카운트 항목 (HAA_CONFIRM_MBR_INFO.item003) 2008.04.29 by hsahn
	public String SO_HT_GBN = "";	//집전화 변경여부 		: #2 고객정보정제 카운트 항목 (HAA_CONFIRM_MBR_INFO.item002) 2008.04.29 by hsahn
	public String SO_JT_GBN = "";	//직장 전화 변경여부
	public String SO_E_GBN  = "";	//이메일  변경여부		: #4 고객정보정제 카운트 항목 (HAA_CONFIRM_MBR_INFO.item004) 2008.04.29 by hsahn
	
	public String SO_H_GBN_2  = ""; 	//집주소 변경 여부 (새주소)
	public String SO_J_GBN_2  = ""; 	//직장 주소 변경여부 (새주소)
	public String SO_G_GBN_2  = ""; 	//기타 주소 변경여부 (새주소)
	
	public String SI_EMAIL_ID  =""; //이메일
	public String EMAIL_ID     =""; //변경전 이메일
	public String SI_EMAIL_SUSIN_YN = "";	//이메일수신여부 (1 수신, 2 거부)
	
	
	public String [] suryung_gb  = new String[0];
	public String [] poli_no     = new String[0];
	public String [] suryung_gb_2 = new String[0]; // 지번주소, 새주소
	// 기본 조회 필드
	public boolean fbm299 = false;
	public boolean fbm048 = false;
	public boolean fbm300 = false;
	
	//자녀 보험 로그 
	public String HJ_BJ_NM         = "";
	public String HJ_BIGO          = "";
	public String HJ_GYEYAK_NM     = "";
	public String HJ_PIBO_NM       = "";
	public String HJ_CHIGUB_NM     = "";
	public String JJ_BOHUM_GIGANCD = "";
	public String JJ_BOHUM_GIGAN_S = "";
	public String JJ_BOHUM_GIGAN_E = "";
	public String JJ_CHIGUB_TEL    = "";
	public String JJ_GAIP_TYPE     = "";
	public String JJ_GYEYAK_JMNO   = "";
	public String JJ_JUPSU         = "";
	public String JJ_POLI_NO       = "";
	
	
	//페이징을 위해
//	public String COMM_CHANNEL = "";
	public String UD_FK_POLI_NO = "";
	public String UD_LK_POLI_NO = "";
	public String PREV_UD_FK_POLI_NO = "";
	public String SI_K_GOGEK_NO = "";
	public String UD_UK_POLI_NO = "";
//	public String []SO_POLI_NO = new String[0];
	
	// 검색
	public String Contract    = ""; //구분값
	
	public String srch_jumin  = ""; //주민번호
	public String srch_userid = ""; //유저 아이디
	public String srch_name   = ""; //유저 이름
	public int    rowcnt      = 0; //유저 이름
	public int    maxseq      = 0;
	
	
	//300
	public String FBM300_COMM_CHANNEL          = "";                   
	public String FBM300_COMM_UNIQUE_KEY       = "";                   
	public String FBM300_COMM_PGMID            = "";                   
	public String FBM300_COMM_PROC_GB          = "";                   
	public String FBM300_COMM_ACTION_KEY       = "";                   
	public String FBM300_COMM_USER_GB          = "";                   
	public String FBM300_COMM_USER_ID          = "";                   
	public String FBM300_COMM_JIJUM_CD         = "";                   
	public String FBM300_COMM_JIBU_CD          = "";                   
	public String FBM300_COMM_PROTOCOL         = "";                   
	public String FBM300_COMM_COND_CD          = "";                   
	public String FBM300_COMM_LAST_FLAG        = "";                   
	public String FBM300_COMM_CURSOR_MAP       = "";                   
	public String FBM300_COMM_CURSOR_IDX       = "";                   
	public String FBM300_COMM_MESSAGE_CD       = "";                   
	public String FBM300_HOMM_MESSAGE_NM       = "";                   
	public String FBM300_COMM_ERR_NAME         = "";                   
	public String FBM300_COMM_ERR_TEXT         = "";                   
	public String FBM300_COMM_SYS_CODE         = "";                   
	public String FBM300_COMM_FILLER           = "";                   
	                                                                   
	public String FBM300_SO_H_ZIP              = "";                   
	public String FBM300_HO_H_JUSO             = "";                   
	public String FBM300_HO_H_ADDR             = "";                   
	public String FBM300_SO_J_ZIP              = "";                   
	public String FBM300_HO_J_JUSO             = "";                   
	public String FBM300_HO_J_ADDR             = "";                   
	public String FBM300_SO_G_ZIP              = "";                   
	public String FBM300_HO_G_JUSO             = "";                   
	public String FBM300_HO_G_ADDR             = "";                   
	                                                                   
	public String [] FBM300_SI_L_SELECT_FLAG      = new String[0];     
	public String [] FBM300_SO_L_POLI_NO          = new String[0];     
	public String [] FBM300_HO_L_CAR_NO           = new String[0];     
	public String [] FBM300_SO_L_BOJONG_CD        = new String[0];     
	public String [] FBM300_HO_L_BOJONG_NM        = new String[0];     
	public String [] FBM300_SO_L_GOGEK_GB         = new String[0];     
	public String [] FBM300_HO_L_GOGEK_GB_NM      = new String[0];     
	public String [] FBM300_SO_L_BOHUM_SYMD       = new String[0];     
	public String [] FBM300_SO_L_BOHUM_EYMD       = new String[0];     
	public String [] FBM300_SO_L_GEYAK_SANGTE     = new String[0];     
	public String [] FBM300_HO_L_GEYAK_SANGTE_NM  = new String[0];     
	public String [] FBM300_SI_L_SURYUNG_GB       = new String[0];     
	                                                                   
	public String FBM300_UD_FK_POLI_NO         	= "";                   
	public String FBM300_UD_LK_POLI_NO         	= "";                   
	public String FBM300_UD_UK_POLI_NO         	= "";                   

	// 고객정보정제 입력 경로  (HAA_CONFIRM_MBR_INFO.input_path_name) 2008.04.29 by hsahn
	public String input_path_name				= "";
	public boolean jmRequested					= false;
	
	public String name = "";
	public String phone = "";
	public String so_poli_no = "";
	public String baby_jumin_no="";
	
	public String checkCustInModEvt = "";	//고객정보 수정이벤트 중복체크 "1"이면 중복
	
	public String SI_L_SURYUNG_GB = ""; // 수령처구분
	public String SI_L_SINGU_GB = ""; // 주소 신구여부(1:신,2:구,SPACE:구)
	
	public String notModifyGubun = "";	//변경없이 확인버튼 클릭시 : Y // 2013차세대 수정 , 확인버튼 클릭시 변경한 내용없으면 이메일,sms 발송안되게 수정 , 2013.03.15, 박형규
	
	public String insertSeqNo = "";
	public String retmsg = "";
	public String so_ht_gbn_name = "";
	public String so_hp_gbn_name = "";
	public String so_e_gbn_name = "";
	public String gubun = "";
	public String stat = "";
	public String msg = "";
	public String addr_yn = "";
	public String bizaddr_yn = "";
	public long cus_seq = 0;
	public String hp_yn = "";
	public String prv_hp = "";
	public String aft_hp = "";
	
	public String tel_yn = "";
	public String prv_tel = "";
	public String aft_tel = "";
	
	public String office_yn = "";
	public String prv_office = "";
	public String aft_office = "";
	
	public String email_yn = "";
	public String prv_email = "";
	public String aft_email = "";
	
	public String prv_addr = "";
	public String aft_addr = "";
	public String prv_bizaddr = "";
	public String aft_bizaddr = "";
	public String erroryn	=	"";
	public String biztel_yn  = "";
	public String prv_biztel = "";
	public String aft_biztel = "";
	
	public String getR_susinhow() {
		return r_susinhow;
	}

	public void setR_susinhow(String r_susinhow) {
		this.r_susinhow = r_susinhow;
	}

	public String getFBM299_COMM_CHANNEL() {
		return FBM299_COMM_CHANNEL;
	}

	public void setFBM299_COMM_CHANNEL(String fBM299_COMM_CHANNEL) {
		FBM299_COMM_CHANNEL = fBM299_COMM_CHANNEL;
	}

	public String getFBM299_COMM_UNIQUE_KEY() {
		return FBM299_COMM_UNIQUE_KEY;
	}

	public void setFBM299_COMM_UNIQUE_KEY(String fBM299_COMM_UNIQUE_KEY) {
		FBM299_COMM_UNIQUE_KEY = fBM299_COMM_UNIQUE_KEY;
	}

	public String getFBM299_COMM_PGMID() {
		return FBM299_COMM_PGMID;
	}

	public void setFBM299_COMM_PGMID(String fBM299_COMM_PGMID) {
		FBM299_COMM_PGMID = fBM299_COMM_PGMID;
	}

	public String getFBM299_COMM_PROC_GB() {
		return FBM299_COMM_PROC_GB;
	}

	public void setFBM299_COMM_PROC_GB(String fBM299_COMM_PROC_GB) {
		FBM299_COMM_PROC_GB = fBM299_COMM_PROC_GB;
	}

	public String getFBM299_COMM_ACTION_KEY() {
		return FBM299_COMM_ACTION_KEY;
	}

	public void setFBM299_COMM_ACTION_KEY(String fBM299_COMM_ACTION_KEY) {
		FBM299_COMM_ACTION_KEY = fBM299_COMM_ACTION_KEY;
	}

	public String getFBM299_COMM_USER_GB() {
		return FBM299_COMM_USER_GB;
	}

	public void setFBM299_COMM_USER_GB(String fBM299_COMM_USER_GB) {
		FBM299_COMM_USER_GB = fBM299_COMM_USER_GB;
	}

	public String getFBM299_COMM_PROTOCOL() {
		return FBM299_COMM_PROTOCOL;
	}

	public void setFBM299_COMM_PROTOCOL(String fBM299_COMM_PROTOCOL) {
		FBM299_COMM_PROTOCOL = fBM299_COMM_PROTOCOL;
	}

	public String getFBM299_COMM_COND_CD() {
		return FBM299_COMM_COND_CD;
	}

	public void setFBM299_COMM_COND_CD(String fBM299_COMM_COND_CD) {
		FBM299_COMM_COND_CD = fBM299_COMM_COND_CD;
	}

	public String getFBM299_COMM_LAST_FLAG() {
		return FBM299_COMM_LAST_FLAG;
	}

	public void setFBM299_COMM_LAST_FLAG(String fBM299_COMM_LAST_FLAG) {
		FBM299_COMM_LAST_FLAG = fBM299_COMM_LAST_FLAG;
	}

	public String getFBM299_COMM_CURSOR_MAP() {
		return FBM299_COMM_CURSOR_MAP;
	}

	public void setFBM299_COMM_CURSOR_MAP(String fBM299_COMM_CURSOR_MAP) {
		FBM299_COMM_CURSOR_MAP = fBM299_COMM_CURSOR_MAP;
	}

	public String getFBM299_COMM_CURSOR_IDX() {
		return FBM299_COMM_CURSOR_IDX;
	}

	public void setFBM299_COMM_CURSOR_IDX(String fBM299_COMM_CURSOR_IDX) {
		FBM299_COMM_CURSOR_IDX = fBM299_COMM_CURSOR_IDX;
	}

	public String getSI_H_ZIP() {
		return SI_H_ZIP;
	}

	public void setSI_H_ZIP(String sI_H_ZIP) {
		SI_H_ZIP = sI_H_ZIP;
	}

	public String getSI_H_ZIP1() {
		return SI_H_ZIP1;
	}

	public void setSI_H_ZIP1(String sI_H_ZIP1) {
		SI_H_ZIP1 = sI_H_ZIP1;
	}

	public String getSI_H_ZIP2() {
		return SI_H_ZIP2;
	}

	public void setSI_H_ZIP2(String sI_H_ZIP2) {
		SI_H_ZIP2 = sI_H_ZIP2;
	}

	public String getHO_H_JUSO() {
		return HO_H_JUSO;
	}

	public void setHO_H_JUSO(String hO_H_JUSO) {
		HO_H_JUSO = hO_H_JUSO;
	}

	public String getHI_H_ADDR() {
		return HI_H_ADDR;
	}

	public void setHI_H_ADDR(String hI_H_ADDR) {
		HI_H_ADDR = hI_H_ADDR;
	}

	public String getSI_H_TEL1() {
		return SI_H_TEL1;
	}

	public void setSI_H_TEL1(String sI_H_TEL1) {
		SI_H_TEL1 = sI_H_TEL1;
	}

	public String getSI_H_TEL2() {
		return SI_H_TEL2;
	}

	public void setSI_H_TEL2(String sI_H_TEL2) {
		SI_H_TEL2 = sI_H_TEL2;
	}

	public String getSI_H_TEL3() {
		return SI_H_TEL3;
	}

	public void setSI_H_TEL3(String sI_H_TEL3) {
		SI_H_TEL3 = sI_H_TEL3;
	}

	public String getH_ZIP() {
		return H_ZIP;
	}

	public void setH_ZIP(String h_ZIP) {
		H_ZIP = h_ZIP;
	}

	public String getH_ADDR() {
		return H_ADDR;
	}

	public void setH_ADDR(String h_ADDR) {
		H_ADDR = h_ADDR;
	}

	public String getH_TEL1() {
		return H_TEL1;
	}

	public void setH_TEL1(String h_TEL1) {
		H_TEL1 = h_TEL1;
	}

	public String getH_TEL2() {
		return H_TEL2;
	}

	public void setH_TEL2(String h_TEL2) {
		H_TEL2 = h_TEL2;
	}

	public String getH_TEL3() {
		return H_TEL3;
	}

	public void setH_TEL3(String h_TEL3) {
		H_TEL3 = h_TEL3;
	}

	public String getSI_H_ZIP_2() {
		return SI_H_ZIP_2;
	}

	public void setSI_H_ZIP_2(String sI_H_ZIP_2) {
		SI_H_ZIP_2 = sI_H_ZIP_2;
	}

	public String getSI_H_ZIP1_2() {
		return SI_H_ZIP1_2;
	}

	public void setSI_H_ZIP1_2(String sI_H_ZIP1_2) {
		SI_H_ZIP1_2 = sI_H_ZIP1_2;
	}

	public String getSI_H_ZIP2_2() {
		return SI_H_ZIP2_2;
	}

	public void setSI_H_ZIP2_2(String sI_H_ZIP2_2) {
		SI_H_ZIP2_2 = sI_H_ZIP2_2;
	}

	public String getHO_H_JUSO_2() {
		return HO_H_JUSO_2;
	}

	public void setHO_H_JUSO_2(String hO_H_JUSO_2) {
		HO_H_JUSO_2 = hO_H_JUSO_2;
	}

	public String getHI_H_ADDR_2() {
		return HI_H_ADDR_2;
	}

	public void setHI_H_ADDR_2(String hI_H_ADDR_2) {
		HI_H_ADDR_2 = hI_H_ADDR_2;
	}

	public String getH_ZIP_2() {
		return H_ZIP_2;
	}

	public void setH_ZIP_2(String h_ZIP_2) {
		H_ZIP_2 = h_ZIP_2;
	}

	public String getH_ADDR_2() {
		return H_ADDR_2;
	}

	public void setH_ADDR_2(String h_ADDR_2) {
		H_ADDR_2 = h_ADDR_2;
	}

	public String getSI_J_ZIP() {
		return SI_J_ZIP;
	}

	public void setSI_J_ZIP(String sI_J_ZIP) {
		SI_J_ZIP = sI_J_ZIP;
	}

	public String getSI_J_ZIP1() {
		return SI_J_ZIP1;
	}

	public void setSI_J_ZIP1(String sI_J_ZIP1) {
		SI_J_ZIP1 = sI_J_ZIP1;
	}

	public String getSI_J_ZIP2() {
		return SI_J_ZIP2;
	}

	public void setSI_J_ZIP2(String sI_J_ZIP2) {
		SI_J_ZIP2 = sI_J_ZIP2;
	}

	public String getHO_J_JUSO() {
		return HO_J_JUSO;
	}

	public void setHO_J_JUSO(String hO_J_JUSO) {
		HO_J_JUSO = hO_J_JUSO;
	}

	public String getHI_J_ADDR() {
		return HI_J_ADDR;
	}

	public void setHI_J_ADDR(String hI_J_ADDR) {
		HI_J_ADDR = hI_J_ADDR;
	}

	public String getSI_J_TEL1() {
		return SI_J_TEL1;
	}

	public void setSI_J_TEL1(String sI_J_TEL1) {
		SI_J_TEL1 = sI_J_TEL1;
	}

	public String getSI_J_TEL2() {
		return SI_J_TEL2;
	}

	public void setSI_J_TEL2(String sI_J_TEL2) {
		SI_J_TEL2 = sI_J_TEL2;
	}

	public String getSI_J_TEL3() {
		return SI_J_TEL3;
	}

	public void setSI_J_TEL3(String sI_J_TEL3) {
		SI_J_TEL3 = sI_J_TEL3;
	}

	public String getJ_ZIP() {
		return J_ZIP;
	}

	public void setJ_ZIP(String j_ZIP) {
		J_ZIP = j_ZIP;
	}

	public String getJ_ADDR() {
		return J_ADDR;
	}

	public void setJ_ADDR(String j_ADDR) {
		J_ADDR = j_ADDR;
	}

	public String getJ_TEL1() {
		return J_TEL1;
	}

	public void setJ_TEL1(String j_TEL1) {
		J_TEL1 = j_TEL1;
	}

	public String getJ_TEL2() {
		return J_TEL2;
	}

	public void setJ_TEL2(String j_TEL2) {
		J_TEL2 = j_TEL2;
	}

	public String getJ_TEL3() {
		return J_TEL3;
	}

	public void setJ_TEL3(String j_TEL3) {
		J_TEL3 = j_TEL3;
	}

	public String getSI_J_ZIP_2() {
		return SI_J_ZIP_2;
	}

	public void setSI_J_ZIP_2(String sI_J_ZIP_2) {
		SI_J_ZIP_2 = sI_J_ZIP_2;
	}

	public String getSI_J_ZIP1_2() {
		return SI_J_ZIP1_2;
	}

	public void setSI_J_ZIP1_2(String sI_J_ZIP1_2) {
		SI_J_ZIP1_2 = sI_J_ZIP1_2;
	}

	public String getSI_J_ZIP2_2() {
		return SI_J_ZIP2_2;
	}

	public void setSI_J_ZIP2_2(String sI_J_ZIP2_2) {
		SI_J_ZIP2_2 = sI_J_ZIP2_2;
	}

	public String getHO_J_JUSO_2() {
		return HO_J_JUSO_2;
	}

	public void setHO_J_JUSO_2(String hO_J_JUSO_2) {
		HO_J_JUSO_2 = hO_J_JUSO_2;
	}

	public String getHI_J_ADDR_2() {
		return HI_J_ADDR_2;
	}

	public void setHI_J_ADDR_2(String hI_J_ADDR_2) {
		HI_J_ADDR_2 = hI_J_ADDR_2;
	}

	public String getJ_ZIP_2() {
		return J_ZIP_2;
	}

	public void setJ_ZIP_2(String j_ZIP_2) {
		J_ZIP_2 = j_ZIP_2;
	}

	public String getJ_ADDR_2() {
		return J_ADDR_2;
	}

	public void setJ_ADDR_2(String j_ADDR_2) {
		J_ADDR_2 = j_ADDR_2;
	}

	public String getSI_G_ZIP() {
		return SI_G_ZIP;
	}

	public void setSI_G_ZIP(String sI_G_ZIP) {
		SI_G_ZIP = sI_G_ZIP;
	}

	public String getSI_G_ZIP1() {
		return SI_G_ZIP1;
	}

	public void setSI_G_ZIP1(String sI_G_ZIP1) {
		SI_G_ZIP1 = sI_G_ZIP1;
	}

	public String getSI_G_ZIP2() {
		return SI_G_ZIP2;
	}

	public void setSI_G_ZIP2(String sI_G_ZIP2) {
		SI_G_ZIP2 = sI_G_ZIP2;
	}

	public String getHO_G_JUSO() {
		return HO_G_JUSO;
	}

	public void setHO_G_JUSO(String hO_G_JUSO) {
		HO_G_JUSO = hO_G_JUSO;
	}

	public String getHI_G_ADDR() {
		return HI_G_ADDR;
	}

	public void setHI_G_ADDR(String hI_G_ADDR) {
		HI_G_ADDR = hI_G_ADDR;
	}

	public String getSI_HP_TEL1() {
		return SI_HP_TEL1;
	}

	public void setSI_HP_TEL1(String sI_HP_TEL1) {
		SI_HP_TEL1 = sI_HP_TEL1;
	}

	public String getSI_HP_TEL2() {
		return SI_HP_TEL2;
	}

	public void setSI_HP_TEL2(String sI_HP_TEL2) {
		SI_HP_TEL2 = sI_HP_TEL2;
	}

	public String getSI_HP_TEL3() {
		return SI_HP_TEL3;
	}

	public void setSI_HP_TEL3(String sI_HP_TEL3) {
		SI_HP_TEL3 = sI_HP_TEL3;
	}

	public String getG_ZIP() {
		return G_ZIP;
	}

	public void setG_ZIP(String g_ZIP) {
		G_ZIP = g_ZIP;
	}

	public String getG_ADDR() {
		return G_ADDR;
	}

	public void setG_ADDR(String g_ADDR) {
		G_ADDR = g_ADDR;
	}

	public String getHP_TEL1() {
		return HP_TEL1;
	}

	public void setHP_TEL1(String hP_TEL1) {
		HP_TEL1 = hP_TEL1;
	}

	public String getHP_TEL2() {
		return HP_TEL2;
	}

	public void setHP_TEL2(String hP_TEL2) {
		HP_TEL2 = hP_TEL2;
	}

	public String getHP_TEL3() {
		return HP_TEL3;
	}

	public void setHP_TEL3(String hP_TEL3) {
		HP_TEL3 = hP_TEL3;
	}

	public String getSI_G_ZIP_2() {
		return SI_G_ZIP_2;
	}

	public void setSI_G_ZIP_2(String sI_G_ZIP_2) {
		SI_G_ZIP_2 = sI_G_ZIP_2;
	}

	public String getSI_G_ZIP1_2() {
		return SI_G_ZIP1_2;
	}

	public void setSI_G_ZIP1_2(String sI_G_ZIP1_2) {
		SI_G_ZIP1_2 = sI_G_ZIP1_2;
	}

	public String getSI_G_ZIP2_2() {
		return SI_G_ZIP2_2;
	}

	public void setSI_G_ZIP2_2(String sI_G_ZIP2_2) {
		SI_G_ZIP2_2 = sI_G_ZIP2_2;
	}

	public String getHO_G_JUSO_2() {
		return HO_G_JUSO_2;
	}

	public void setHO_G_JUSO_2(String hO_G_JUSO_2) {
		HO_G_JUSO_2 = hO_G_JUSO_2;
	}

	public String getHI_G_ADDR_2() {
		return HI_G_ADDR_2;
	}

	public void setHI_G_ADDR_2(String hI_G_ADDR_2) {
		HI_G_ADDR_2 = hI_G_ADDR_2;
	}

	public String getG_ZIP_2() {
		return G_ZIP_2;
	}

	public void setG_ZIP_2(String g_ZIP_2) {
		G_ZIP_2 = g_ZIP_2;
	}

	public String getG_ADDR_2() {
		return G_ADDR_2;
	}

	public void setG_ADDR_2(String g_ADDR_2) {
		G_ADDR_2 = g_ADDR_2;
	}

	public String getSO_H_GBN() {
		return SO_H_GBN;
	}

	public void setSO_H_GBN(String sO_H_GBN) {
		SO_H_GBN = sO_H_GBN;
	}

	public String getSO_J_GBN() {
		return SO_J_GBN;
	}

	public void setSO_J_GBN(String sO_J_GBN) {
		SO_J_GBN = sO_J_GBN;
	}

	public String getSO_G_GBN() {
		return SO_G_GBN;
	}

	public void setSO_G_GBN(String sO_G_GBN) {
		SO_G_GBN = sO_G_GBN;
	}

	public String getSO_HP_GBN() {
		return SO_HP_GBN;
	}

	public void setSO_HP_GBN(String sO_HP_GBN) {
		SO_HP_GBN = sO_HP_GBN;
	}

	public String getSO_HT_GBN() {
		return SO_HT_GBN;
	}

	public void setSO_HT_GBN(String sO_HT_GBN) {
		SO_HT_GBN = sO_HT_GBN;
	}

	public String getSO_JT_GBN() {
		return SO_JT_GBN;
	}

	public void setSO_JT_GBN(String sO_JT_GBN) {
		SO_JT_GBN = sO_JT_GBN;
	}

	public String getSO_E_GBN() {
		return SO_E_GBN;
	}

	public void setSO_E_GBN(String sO_E_GBN) {
		SO_E_GBN = sO_E_GBN;
	}

	public String getSO_H_GBN_2() {
		return SO_H_GBN_2;
	}

	public void setSO_H_GBN_2(String sO_H_GBN_2) {
		SO_H_GBN_2 = sO_H_GBN_2;
	}

	public String getSO_J_GBN_2() {
		return SO_J_GBN_2;
	}

	public void setSO_J_GBN_2(String sO_J_GBN_2) {
		SO_J_GBN_2 = sO_J_GBN_2;
	}

	public String getSO_G_GBN_2() {
		return SO_G_GBN_2;
	}

	public void setSO_G_GBN_2(String sO_G_GBN_2) {
		SO_G_GBN_2 = sO_G_GBN_2;
	}

	public String getSI_EMAIL_ID() {
		return SI_EMAIL_ID;
	}

	public void setSI_EMAIL_ID(String sI_EMAIL_ID) {
		SI_EMAIL_ID = sI_EMAIL_ID;
	}

	public String getEMAIL_ID() {
		return EMAIL_ID;
	}

	public void setEMAIL_ID(String eMAIL_ID) {
		EMAIL_ID = eMAIL_ID;
	}

	public String getSI_EMAIL_SUSIN_YN() {
		return SI_EMAIL_SUSIN_YN;
	}

	public void setSI_EMAIL_SUSIN_YN(String sI_EMAIL_SUSIN_YN) {
		SI_EMAIL_SUSIN_YN = sI_EMAIL_SUSIN_YN;
	}

	public String[] getSuryung_gb() {
		return suryung_gb;
	}

	public void setSuryung_gb(String[] suryung_gb) {
		this.suryung_gb = suryung_gb;
	}

	public String[] getPoli_no() {
		return poli_no;
	}

	public void setPoli_no(String[] poli_no) {
		this.poli_no = poli_no;
	}

	public String[] getSuryung_gb_2() {
		return suryung_gb_2;
	}

	public void setSuryung_gb_2(String[] suryung_gb_2) {
		this.suryung_gb_2 = suryung_gb_2;
	}

	public boolean isFbm299() {
		return fbm299;
	}

	public void setFbm299(boolean fbm299) {
		this.fbm299 = fbm299;
	}

	public boolean isFbm048() {
		return fbm048;
	}

	public void setFbm048(boolean fbm048) {
		this.fbm048 = fbm048;
	}

	public boolean isFbm300() {
		return fbm300;
	}

	public void setFbm300(boolean fbm300) {
		this.fbm300 = fbm300;
	}

	public String getHJ_BJ_NM() {
		return HJ_BJ_NM;
	}

	public void setHJ_BJ_NM(String hJ_BJ_NM) {
		HJ_BJ_NM = hJ_BJ_NM;
	}

	public String getHJ_BIGO() {
		return HJ_BIGO;
	}

	public void setHJ_BIGO(String hJ_BIGO) {
		HJ_BIGO = hJ_BIGO;
	}

	public String getHJ_GYEYAK_NM() {
		return HJ_GYEYAK_NM;
	}

	public void setHJ_GYEYAK_NM(String hJ_GYEYAK_NM) {
		HJ_GYEYAK_NM = hJ_GYEYAK_NM;
	}

	public String getHJ_PIBO_NM() {
		return HJ_PIBO_NM;
	}

	public void setHJ_PIBO_NM(String hJ_PIBO_NM) {
		HJ_PIBO_NM = hJ_PIBO_NM;
	}

	public String getHJ_CHIGUB_NM() {
		return HJ_CHIGUB_NM;
	}

	public void setHJ_CHIGUB_NM(String hJ_CHIGUB_NM) {
		HJ_CHIGUB_NM = hJ_CHIGUB_NM;
	}

	public String getJJ_BOHUM_GIGANCD() {
		return JJ_BOHUM_GIGANCD;
	}

	public void setJJ_BOHUM_GIGANCD(String jJ_BOHUM_GIGANCD) {
		JJ_BOHUM_GIGANCD = jJ_BOHUM_GIGANCD;
	}

	public String getJJ_BOHUM_GIGAN_S() {
		return JJ_BOHUM_GIGAN_S;
	}

	public void setJJ_BOHUM_GIGAN_S(String jJ_BOHUM_GIGAN_S) {
		JJ_BOHUM_GIGAN_S = jJ_BOHUM_GIGAN_S;
	}

	public String getJJ_BOHUM_GIGAN_E() {
		return JJ_BOHUM_GIGAN_E;
	}

	public void setJJ_BOHUM_GIGAN_E(String jJ_BOHUM_GIGAN_E) {
		JJ_BOHUM_GIGAN_E = jJ_BOHUM_GIGAN_E;
	}

	public String getJJ_CHIGUB_TEL() {
		return JJ_CHIGUB_TEL;
	}

	public void setJJ_CHIGUB_TEL(String jJ_CHIGUB_TEL) {
		JJ_CHIGUB_TEL = jJ_CHIGUB_TEL;
	}

	public String getJJ_GAIP_TYPE() {
		return JJ_GAIP_TYPE;
	}

	public void setJJ_GAIP_TYPE(String jJ_GAIP_TYPE) {
		JJ_GAIP_TYPE = jJ_GAIP_TYPE;
	}

	public String getJJ_GYEYAK_JMNO() {
		return JJ_GYEYAK_JMNO;
	}

	public void setJJ_GYEYAK_JMNO(String jJ_GYEYAK_JMNO) {
		JJ_GYEYAK_JMNO = jJ_GYEYAK_JMNO;
	}

	public String getJJ_JUPSU() {
		return JJ_JUPSU;
	}

	public void setJJ_JUPSU(String jJ_JUPSU) {
		JJ_JUPSU = jJ_JUPSU;
	}

	public String getJJ_POLI_NO() {
		return JJ_POLI_NO;
	}

	public void setJJ_POLI_NO(String jJ_POLI_NO) {
		JJ_POLI_NO = jJ_POLI_NO;
	}

	public String getUD_FK_POLI_NO() {
		return UD_FK_POLI_NO;
	}

	public void setUD_FK_POLI_NO(String uD_FK_POLI_NO) {
		UD_FK_POLI_NO = uD_FK_POLI_NO;
	}

	public String getUD_LK_POLI_NO() {
		return UD_LK_POLI_NO;
	}

	public void setUD_LK_POLI_NO(String uD_LK_POLI_NO) {
		UD_LK_POLI_NO = uD_LK_POLI_NO;
	}

	public String getPREV_UD_FK_POLI_NO() {
		return PREV_UD_FK_POLI_NO;
	}

	public void setPREV_UD_FK_POLI_NO(String pREV_UD_FK_POLI_NO) {
		PREV_UD_FK_POLI_NO = pREV_UD_FK_POLI_NO;
	}

	public String getSI_K_GOGEK_NO() {
		return SI_K_GOGEK_NO;
	}

	public void setSI_K_GOGEK_NO(String sI_K_GOGEK_NO) {
		SI_K_GOGEK_NO = sI_K_GOGEK_NO;
	}

	public String getUD_UK_POLI_NO() {
		return UD_UK_POLI_NO;
	}

	public void setUD_UK_POLI_NO(String uD_UK_POLI_NO) {
		UD_UK_POLI_NO = uD_UK_POLI_NO;
	}

	public String getContract() {
		return Contract;
	}

	public void setContract(String contract) {
		Contract = contract;
	}

	public String getSrch_jumin() {
		return srch_jumin;
	}

	public void setSrch_jumin(String srch_jumin) {
		this.srch_jumin = srch_jumin;
	}

	public String getSrch_userid() {
		return srch_userid;
	}

	public void setSrch_userid(String srch_userid) {
		this.srch_userid = srch_userid;
	}

	public String getSrch_name() {
		return srch_name;
	}

	public void setSrch_name(String srch_name) {
		this.srch_name = srch_name;
	}

	public int getRowcnt() {
		return rowcnt;
	}

	public void setRowcnt(int rowcnt) {
		this.rowcnt = rowcnt;
	}

	public String getFBM300_COMM_CHANNEL() {
		return FBM300_COMM_CHANNEL;
	}

	public void setFBM300_COMM_CHANNEL(String fBM300_COMM_CHANNEL) {
		FBM300_COMM_CHANNEL = fBM300_COMM_CHANNEL;
	}

	public String getFBM300_COMM_UNIQUE_KEY() {
		return FBM300_COMM_UNIQUE_KEY;
	}

	public void setFBM300_COMM_UNIQUE_KEY(String fBM300_COMM_UNIQUE_KEY) {
		FBM300_COMM_UNIQUE_KEY = fBM300_COMM_UNIQUE_KEY;
	}

	public String getFBM300_COMM_PGMID() {
		return FBM300_COMM_PGMID;
	}

	public void setFBM300_COMM_PGMID(String fBM300_COMM_PGMID) {
		FBM300_COMM_PGMID = fBM300_COMM_PGMID;
	}

	public String getFBM300_COMM_PROC_GB() {
		return FBM300_COMM_PROC_GB;
	}

	public void setFBM300_COMM_PROC_GB(String fBM300_COMM_PROC_GB) {
		FBM300_COMM_PROC_GB = fBM300_COMM_PROC_GB;
	}

	public String getFBM300_COMM_ACTION_KEY() {
		return FBM300_COMM_ACTION_KEY;
	}

	public void setFBM300_COMM_ACTION_KEY(String fBM300_COMM_ACTION_KEY) {
		FBM300_COMM_ACTION_KEY = fBM300_COMM_ACTION_KEY;
	}

	public String getFBM300_COMM_USER_GB() {
		return FBM300_COMM_USER_GB;
	}

	public void setFBM300_COMM_USER_GB(String fBM300_COMM_USER_GB) {
		FBM300_COMM_USER_GB = fBM300_COMM_USER_GB;
	}

	public String getFBM300_COMM_USER_ID() {
		return FBM300_COMM_USER_ID;
	}

	public void setFBM300_COMM_USER_ID(String fBM300_COMM_USER_ID) {
		FBM300_COMM_USER_ID = fBM300_COMM_USER_ID;
	}

	public String getFBM300_COMM_JIJUM_CD() {
		return FBM300_COMM_JIJUM_CD;
	}

	public void setFBM300_COMM_JIJUM_CD(String fBM300_COMM_JIJUM_CD) {
		FBM300_COMM_JIJUM_CD = fBM300_COMM_JIJUM_CD;
	}

	public String getFBM300_COMM_JIBU_CD() {
		return FBM300_COMM_JIBU_CD;
	}

	public void setFBM300_COMM_JIBU_CD(String fBM300_COMM_JIBU_CD) {
		FBM300_COMM_JIBU_CD = fBM300_COMM_JIBU_CD;
	}

	public String getFBM300_COMM_PROTOCOL() {
		return FBM300_COMM_PROTOCOL;
	}

	public void setFBM300_COMM_PROTOCOL(String fBM300_COMM_PROTOCOL) {
		FBM300_COMM_PROTOCOL = fBM300_COMM_PROTOCOL;
	}

	public String getFBM300_COMM_COND_CD() {
		return FBM300_COMM_COND_CD;
	}

	public void setFBM300_COMM_COND_CD(String fBM300_COMM_COND_CD) {
		FBM300_COMM_COND_CD = fBM300_COMM_COND_CD;
	}

	public String getFBM300_COMM_LAST_FLAG() {
		return FBM300_COMM_LAST_FLAG;
	}

	public void setFBM300_COMM_LAST_FLAG(String fBM300_COMM_LAST_FLAG) {
		FBM300_COMM_LAST_FLAG = fBM300_COMM_LAST_FLAG;
	}

	public String getFBM300_COMM_CURSOR_MAP() {
		return FBM300_COMM_CURSOR_MAP;
	}

	public void setFBM300_COMM_CURSOR_MAP(String fBM300_COMM_CURSOR_MAP) {
		FBM300_COMM_CURSOR_MAP = fBM300_COMM_CURSOR_MAP;
	}

	public String getFBM300_COMM_CURSOR_IDX() {
		return FBM300_COMM_CURSOR_IDX;
	}

	public void setFBM300_COMM_CURSOR_IDX(String fBM300_COMM_CURSOR_IDX) {
		FBM300_COMM_CURSOR_IDX = fBM300_COMM_CURSOR_IDX;
	}

	public String getFBM300_COMM_MESSAGE_CD() {
		return FBM300_COMM_MESSAGE_CD;
	}

	public void setFBM300_COMM_MESSAGE_CD(String fBM300_COMM_MESSAGE_CD) {
		FBM300_COMM_MESSAGE_CD = fBM300_COMM_MESSAGE_CD;
	}

	public String getFBM300_HOMM_MESSAGE_NM() {
		return FBM300_HOMM_MESSAGE_NM;
	}

	public void setFBM300_HOMM_MESSAGE_NM(String fBM300_HOMM_MESSAGE_NM) {
		FBM300_HOMM_MESSAGE_NM = fBM300_HOMM_MESSAGE_NM;
	}

	public String getFBM300_COMM_ERR_NAME() {
		return FBM300_COMM_ERR_NAME;
	}

	public void setFBM300_COMM_ERR_NAME(String fBM300_COMM_ERR_NAME) {
		FBM300_COMM_ERR_NAME = fBM300_COMM_ERR_NAME;
	}

	public String getFBM300_COMM_ERR_TEXT() {
		return FBM300_COMM_ERR_TEXT;
	}

	public void setFBM300_COMM_ERR_TEXT(String fBM300_COMM_ERR_TEXT) {
		FBM300_COMM_ERR_TEXT = fBM300_COMM_ERR_TEXT;
	}

	public String getFBM300_COMM_SYS_CODE() {
		return FBM300_COMM_SYS_CODE;
	}

	public void setFBM300_COMM_SYS_CODE(String fBM300_COMM_SYS_CODE) {
		FBM300_COMM_SYS_CODE = fBM300_COMM_SYS_CODE;
	}

	public String getFBM300_COMM_FILLER() {
		return FBM300_COMM_FILLER;
	}

	public void setFBM300_COMM_FILLER(String fBM300_COMM_FILLER) {
		FBM300_COMM_FILLER = fBM300_COMM_FILLER;
	}

	public String getFBM300_SO_H_ZIP() {
		return FBM300_SO_H_ZIP;
	}

	public void setFBM300_SO_H_ZIP(String fBM300_SO_H_ZIP) {
		FBM300_SO_H_ZIP = fBM300_SO_H_ZIP;
	}

	public String getFBM300_HO_H_JUSO() {
		return FBM300_HO_H_JUSO;
	}

	public void setFBM300_HO_H_JUSO(String fBM300_HO_H_JUSO) {
		FBM300_HO_H_JUSO = fBM300_HO_H_JUSO;
	}

	public String getFBM300_HO_H_ADDR() {
		return FBM300_HO_H_ADDR;
	}

	public void setFBM300_HO_H_ADDR(String fBM300_HO_H_ADDR) {
		FBM300_HO_H_ADDR = fBM300_HO_H_ADDR;
	}

	public String getFBM300_SO_J_ZIP() {
		return FBM300_SO_J_ZIP;
	}

	public void setFBM300_SO_J_ZIP(String fBM300_SO_J_ZIP) {
		FBM300_SO_J_ZIP = fBM300_SO_J_ZIP;
	}

	public String getFBM300_HO_J_JUSO() {
		return FBM300_HO_J_JUSO;
	}

	public void setFBM300_HO_J_JUSO(String fBM300_HO_J_JUSO) {
		FBM300_HO_J_JUSO = fBM300_HO_J_JUSO;
	}

	public String getFBM300_HO_J_ADDR() {
		return FBM300_HO_J_ADDR;
	}

	public void setFBM300_HO_J_ADDR(String fBM300_HO_J_ADDR) {
		FBM300_HO_J_ADDR = fBM300_HO_J_ADDR;
	}

	public String getFBM300_SO_G_ZIP() {
		return FBM300_SO_G_ZIP;
	}

	public void setFBM300_SO_G_ZIP(String fBM300_SO_G_ZIP) {
		FBM300_SO_G_ZIP = fBM300_SO_G_ZIP;
	}

	public String getFBM300_HO_G_JUSO() {
		return FBM300_HO_G_JUSO;
	}

	public void setFBM300_HO_G_JUSO(String fBM300_HO_G_JUSO) {
		FBM300_HO_G_JUSO = fBM300_HO_G_JUSO;
	}

	public String getFBM300_HO_G_ADDR() {
		return FBM300_HO_G_ADDR;
	}

	public void setFBM300_HO_G_ADDR(String fBM300_HO_G_ADDR) {
		FBM300_HO_G_ADDR = fBM300_HO_G_ADDR;
	}

	public String[] getFBM300_SI_L_SELECT_FLAG() {
		return FBM300_SI_L_SELECT_FLAG;
	}

	public void setFBM300_SI_L_SELECT_FLAG(String[] fBM300_SI_L_SELECT_FLAG) {
		FBM300_SI_L_SELECT_FLAG = fBM300_SI_L_SELECT_FLAG;
	}

	public String[] getFBM300_SO_L_POLI_NO() {
		return FBM300_SO_L_POLI_NO;
	}

	public void setFBM300_SO_L_POLI_NO(String[] fBM300_SO_L_POLI_NO) {
		FBM300_SO_L_POLI_NO = fBM300_SO_L_POLI_NO;
	}

	public String[] getFBM300_HO_L_CAR_NO() {
		return FBM300_HO_L_CAR_NO;
	}

	public void setFBM300_HO_L_CAR_NO(String[] fBM300_HO_L_CAR_NO) {
		FBM300_HO_L_CAR_NO = fBM300_HO_L_CAR_NO;
	}

	public String[] getFBM300_SO_L_BOJONG_CD() {
		return FBM300_SO_L_BOJONG_CD;
	}

	public void setFBM300_SO_L_BOJONG_CD(String[] fBM300_SO_L_BOJONG_CD) {
		FBM300_SO_L_BOJONG_CD = fBM300_SO_L_BOJONG_CD;
	}

	public String[] getFBM300_HO_L_BOJONG_NM() {
		return FBM300_HO_L_BOJONG_NM;
	}

	public void setFBM300_HO_L_BOJONG_NM(String[] fBM300_HO_L_BOJONG_NM) {
		FBM300_HO_L_BOJONG_NM = fBM300_HO_L_BOJONG_NM;
	}

	public String[] getFBM300_SO_L_GOGEK_GB() {
		return FBM300_SO_L_GOGEK_GB;
	}

	public void setFBM300_SO_L_GOGEK_GB(String[] fBM300_SO_L_GOGEK_GB) {
		FBM300_SO_L_GOGEK_GB = fBM300_SO_L_GOGEK_GB;
	}

	public String[] getFBM300_HO_L_GOGEK_GB_NM() {
		return FBM300_HO_L_GOGEK_GB_NM;
	}

	public void setFBM300_HO_L_GOGEK_GB_NM(String[] fBM300_HO_L_GOGEK_GB_NM) {
		FBM300_HO_L_GOGEK_GB_NM = fBM300_HO_L_GOGEK_GB_NM;
	}

	public String[] getFBM300_SO_L_BOHUM_SYMD() {
		return FBM300_SO_L_BOHUM_SYMD;
	}

	public void setFBM300_SO_L_BOHUM_SYMD(String[] fBM300_SO_L_BOHUM_SYMD) {
		FBM300_SO_L_BOHUM_SYMD = fBM300_SO_L_BOHUM_SYMD;
	}

	public String[] getFBM300_SO_L_BOHUM_EYMD() {
		return FBM300_SO_L_BOHUM_EYMD;
	}

	public void setFBM300_SO_L_BOHUM_EYMD(String[] fBM300_SO_L_BOHUM_EYMD) {
		FBM300_SO_L_BOHUM_EYMD = fBM300_SO_L_BOHUM_EYMD;
	}

	public String[] getFBM300_SO_L_GEYAK_SANGTE() {
		return FBM300_SO_L_GEYAK_SANGTE;
	}

	public void setFBM300_SO_L_GEYAK_SANGTE(String[] fBM300_SO_L_GEYAK_SANGTE) {
		FBM300_SO_L_GEYAK_SANGTE = fBM300_SO_L_GEYAK_SANGTE;
	}

	public String[] getFBM300_HO_L_GEYAK_SANGTE_NM() {
		return FBM300_HO_L_GEYAK_SANGTE_NM;
	}

	public void setFBM300_HO_L_GEYAK_SANGTE_NM(String[] fBM300_HO_L_GEYAK_SANGTE_NM) {
		FBM300_HO_L_GEYAK_SANGTE_NM = fBM300_HO_L_GEYAK_SANGTE_NM;
	}

	public String[] getFBM300_SI_L_SURYUNG_GB() {
		return FBM300_SI_L_SURYUNG_GB;
	}

	public void setFBM300_SI_L_SURYUNG_GB(String[] fBM300_SI_L_SURYUNG_GB) {
		FBM300_SI_L_SURYUNG_GB = fBM300_SI_L_SURYUNG_GB;
	}

	public String getFBM300_UD_FK_POLI_NO() {
		return FBM300_UD_FK_POLI_NO;
	}

	public void setFBM300_UD_FK_POLI_NO(String fBM300_UD_FK_POLI_NO) {
		FBM300_UD_FK_POLI_NO = fBM300_UD_FK_POLI_NO;
	}

	public String getFBM300_UD_LK_POLI_NO() {
		return FBM300_UD_LK_POLI_NO;
	}

	public void setFBM300_UD_LK_POLI_NO(String fBM300_UD_LK_POLI_NO) {
		FBM300_UD_LK_POLI_NO = fBM300_UD_LK_POLI_NO;
	}

	public String getFBM300_UD_UK_POLI_NO() {
		return FBM300_UD_UK_POLI_NO;
	}

	public void setFBM300_UD_UK_POLI_NO(String fBM300_UD_UK_POLI_NO) {
		FBM300_UD_UK_POLI_NO = fBM300_UD_UK_POLI_NO;
	}

	public String getInput_path_name() {
		return input_path_name;
	}

	public void setInput_path_name(String input_path_name) {
		this.input_path_name = input_path_name;
	}

	public boolean isJmRequested() {
		return jmRequested;
	}

	public void setJmRequested(boolean jmRequested) {
		this.jmRequested = jmRequested;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getSo_poli_no() {
		return so_poli_no;
	}

	public void setSo_poli_no(String so_poli_no) {
		this.so_poli_no = so_poli_no;
	}

	public String getBaby_jumin_no() {
		return baby_jumin_no;
	}

	public void setBaby_jumin_no(String baby_jumin_no) {
		this.baby_jumin_no = baby_jumin_no;
	}

	public String getCheckCustInModEvt() {
		return checkCustInModEvt;
	}

	public void setCheckCustInModEvt(String checkCustInModEvt) {
		this.checkCustInModEvt = checkCustInModEvt;
	}

	public String getSI_L_SURYUNG_GB() {
		return SI_L_SURYUNG_GB;
	}

	public void setSI_L_SURYUNG_GB(String sI_L_SURYUNG_GB) {
		SI_L_SURYUNG_GB = sI_L_SURYUNG_GB;
	}

	public String getSI_L_SINGU_GB() {
		return SI_L_SINGU_GB;
	}

	public void setSI_L_SINGU_GB(String sI_L_SINGU_GB) {
		SI_L_SINGU_GB = sI_L_SINGU_GB;
	}

	public String getNotModifyGubun() {
		return notModifyGubun;
	}

	public void setNotModifyGubun(String notModifyGubun) {
		this.notModifyGubun = notModifyGubun;
	}

	public String getInsertSeqNo() {
		return insertSeqNo;
	}

	public void setInsertSeqNo(String insertSeqNo) {
		this.insertSeqNo = insertSeqNo;
	}

	public int getMaxseq() {
		return maxseq;
	}

	public void setMaxseq(int maxseq) {
		this.maxseq = maxseq;
	}

	public String getHP_TEL() {
		return HP_TEL;
	}

	public void setHP_TEL(String hP_TEL) {
		HP_TEL = hP_TEL;
	}

	public String getH_TEL() {
		return H_TEL;
	}

	public void setH_TEL(String h_TEL) {
		H_TEL = h_TEL;
	}

	public String getSI_HP_TEL() {
		return SI_HP_TEL;
	}

	public void setSI_HP_TEL(String sI_HP_TEL) {
		SI_HP_TEL = sI_HP_TEL;
	}

	public String getSI_H_TEL() {
		return SI_H_TEL;
	}

	public void setSI_H_TEL(String sI_H_TEL) {
		SI_H_TEL = sI_H_TEL;
	}

	public String getRetmsg() {
		return retmsg;
	}

	public void setRetmsg(String retmsg) {
		this.retmsg = retmsg;
	}

	public String getSo_ht_gbn_name() {
		return so_ht_gbn_name;
	}

	public void setSo_ht_gbn_name(String so_ht_gbn_name) {
		this.so_ht_gbn_name = so_ht_gbn_name;
	}

	public String getSo_hp_gbn_name() {
		return so_hp_gbn_name;
	}

	public void setSo_hp_gbn_name(String so_hp_gbn_name) {
		this.so_hp_gbn_name = so_hp_gbn_name;
	}

	public String getSo_e_gbn_name() {
		return so_e_gbn_name;
	}

	public void setSo_e_gbn_name(String so_e_gbn_name) {
		this.so_e_gbn_name = so_e_gbn_name;
	}

	public String getGubun() {
		return gubun;
	}

	public void setGubun(String gubun) {
		this.gubun = gubun;
	}

	public String getStat() {
		return stat;
	}

	public void setStat(String stat) {
		this.stat = stat;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public String getAddr_yn() {
		return addr_yn;
	}

	public void setAddr_yn(String addr_yn) {
		this.addr_yn = addr_yn;
	}

	public String getBizaddr_yn() {
		return bizaddr_yn;
	}

	public void setBizaddr_yn(String bizaddr_yn) {
		this.bizaddr_yn = bizaddr_yn;
	}

	public long getCus_seq() {
		return cus_seq;
	}

	public void setCus_seq(long cus_seq) {
		this.cus_seq = cus_seq;
	}

	public String getHp_yn() {
		return hp_yn;
	}

	public void setHp_yn(String hp_yn) {
		this.hp_yn = hp_yn;
	}

	public String getPrv_hp() {
		return prv_hp;
	}

	public void setPrv_hp(String prv_hp) {
		this.prv_hp = prv_hp;
	}

	public String getAft_hp() {
		return aft_hp;
	}

	public void setAft_hp(String aft_hp) {
		this.aft_hp = aft_hp;
	}

	public String getTel_yn() {
		return tel_yn;
	}

	public void setTel_yn(String tel_yn) {
		this.tel_yn = tel_yn;
	}

	public String getPrv_tel() {
		return prv_tel;
	}

	public void setPrv_tel(String prv_tel) {
		this.prv_tel = prv_tel;
	}

	public String getAft_tel() {
		return aft_tel;
	}

	public void setAft_tel(String aft_tel) {
		this.aft_tel = aft_tel;
	}

	public String getEmail_yn() {
		return email_yn;
	}

	public void setEmail_yn(String email_yn) {
		this.email_yn = email_yn;
	}

	public String getPrv_email() {
		return prv_email;
	}

	public void setPrv_email(String prv_email) {
		this.prv_email = prv_email;
	}

	public String getAft_email() {
		return aft_email;
	}

	public void setAft_email(String aft_email) {
		this.aft_email = aft_email;
	}

	public String getOffice_yn() {
		return office_yn;
	}

	public void setOffice_yn(String office_yn) {
		this.office_yn = office_yn;
	}

	public String getPrv_office() {
		return prv_office;
	}

	public void setPrv_office(String prv_office) {
		this.prv_office = prv_office;
	}

	public String getAft_office() {
		return aft_office;
	}

	public void setAft_office(String aft_office) {
		this.aft_office = aft_office;
	}

	public String getPrv_addr() {
		return prv_addr;
	}

	public void setPrv_addr(String prv_addr) {
		this.prv_addr = prv_addr;
	}

	public String getAft_addr() {
		return aft_addr;
	}

	public void setAft_addr(String aft_addr) {
		this.aft_addr = aft_addr;
	}

	public String getPrv_bizaddr() {
		return prv_bizaddr;
	}

	public void setPrv_bizaddr(String prv_bizaddr) {
		this.prv_bizaddr = prv_bizaddr;
	}

	public String getAft_bizaddr() {
		return aft_bizaddr;
	}

	public void setAft_bizaddr(String aft_bizaddr) {
		this.aft_bizaddr = aft_bizaddr;
	}

	public String getErroryn() {
		return erroryn;
	}

	public void setErroryn(String erroryn) {
		this.erroryn = erroryn;
	}

	public String getBiztel_yn() {
		return biztel_yn;
	}

	public void setBiztel_yn(String biztel_yn) {
		this.biztel_yn = biztel_yn;
	}

	public String getPrv_biztel() {
		return prv_biztel;
	}

	public void setPrv_biztel(String prv_biztel) {
		this.prv_biztel = prv_biztel;
	}

	public String getAft_biztel() {
		return aft_biztel;
	}

	public void setAft_biztel(String aft_biztel) {
		this.aft_biztel = aft_biztel;
	}
	
}
