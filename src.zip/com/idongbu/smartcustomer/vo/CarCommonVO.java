package com.idongbu.smartcustomer.vo;

/**
 *  자동차계약조회시 자동차모듈호출
 *  개발자              : CIK
 *  작성날짜            : 2014.02.27
 */

public class CarCommonVO{
	public String fd_mb_email = "";
	public String fd_mb_haddress = "";
	public String fd_mb_haddress2 = "";

	public String so_bj_gb = "";
	public String so_poli_no = "";
	public String so_poli_no_main = "";
	public String name = "";
	public String phone = "";
	public String so_pa_mail = "";
	public String gy_jumn_no			= "";
	
	public String CUST_ADDR = "";	//피보험자주소
	public String contact_addr = "";	//보험계약자주소
	public String suikja_addr = "";	//사망보험금 수익자 주소

	//업종추가
	public String upjongNm = "";
	
	public String SAYONG_YONGDO_CD = "";
	public String SAYONG_SEBU = "";
	public String TUKYAK_limits = "";
	public String TUKYAK_age = "";
	public String strDtk = "";
	public String BUNNAP_BANGCD = "";
	public String LK_GA1085_BULIP_CNT = "";
	public String NAPIP_DATE = "";
	public String PIB_TEL_NO = "";
	public String GYE_TEL_NO = "";
	public String TUKYAK_UNJUNJA = "";
	public String TUKYAK_jadongiche = "";
	
	//사망금수익자
	public String TEMP_SUIKJA_GOGEKNO = "";
	public String TEMP_SUIKJA_ZIP = "";
	public String TEMP_SUIKJA_ADDR = "";
	public String TEMP_SUIKJA_HP_TEL1_NO = "";
	public String TEMP_SUIKJA_HOME_TEL2_NO = "";
	

	public String[] TUKYAK_CD 	= new String[0];
	public String[] TUKYAK_RATE = new String[0];
	public String[] TUKBUL_CD 	= new String[0];
	public String[] TUKBUL_RATE = new String[0];
	
	public String HJ_BJ_NM         = "";
	public String HJ_BIGO          = "";
	public String HJ_GYEYAK_NM     = "";
	public String HJ_PIBO_NM       = "";
	public String HJ_CHIGUB_NM     = "";
	public String JJ_BOHUM_GIGANCD = "";
	public String JJ_BOHUM_GIGAN_S = "";
	public String JJ_BOHUM_GIGAN_E = "";
	public String JJ_CHIGUB_TEL    = "";
	public String JJ_GAIP_TYPE     = "";
	public String JJ_GYEYAK_JMNO   = "";
	public String JJ_JUPSU         = "";
	public String JJ_POLI_NO       = "";

	//1 : 자녀보험 주소변경, 2:자동이체 계좌변경, 3. 자동이체일 변경, 4. 장기보험료 납입, 5. 자녀보험 출력용
	public String contract		= "";
	
//	public String COMM_CHANNEL = "";
	public String UD_FK_POLI_NO = "";
	public String UD_LK_POLI_NO = "";
	public String PREV_UD_FK_POLI_NO = "";
	public String SI_K_GOGEK_NO = "";
//	public String []SO_POLI_NO = new String[0];
	
	public String place_name1 = "";
	public String place_name2 = "";
	public String poli_no_normal = "";
	

	public String JJ_GIBON_PRM = "";
	public String change_baseo_gb = "";
	public String HJ_PI_NAME = "";
	
	public String prevPageName = "";
	
	//장기보험 약관대출 금액
	public String RE_STPLT_LOAN_RESID_AMT = "";
	
	//pa정보(2009.03.18.yhj추가)
	public String[] sabeon 	= new String[20];
	public String[] area_tel_no 	= new String[20];
	public String[] frnt_tel_no 	= new String[20];
	public String[] aftr_tel_no 	= new String[20];
	public String[] frnt_hphon_no 	= new String[20];
	public String[] intmd_hphon_no 	= new String[20];
	public String[] hphon_aftr_tel_no 	= new String[20];
	public String[] email_addr_name 	= new String[20];
	public String[] greetPic 	= new String[20];
	public String[] greetText 	= new String[20];
	public String[] gender = new String[20];  //pa성별(2009.08.14)
	
	//메일발송
	public String send_name = "";	//메일 받는 분
	public String send_email = "";		//메일 받는 분
	public String send_title = "";	//메일 제목
	public String send_html = "";	//메일 내용 
	
	public String check = "";

	public String getFd_mb_email() {
		return fd_mb_email;
	}

	public void setFd_mb_email(String fd_mb_email) {
		this.fd_mb_email = fd_mb_email;
	}

	public String getFd_mb_haddress() {
		return fd_mb_haddress;
	}

	public void setFd_mb_haddress(String fd_mb_haddress) {
		this.fd_mb_haddress = fd_mb_haddress;
	}

	public String getFd_mb_haddress2() {
		return fd_mb_haddress2;
	}

	public void setFd_mb_haddress2(String fd_mb_haddress2) {
		this.fd_mb_haddress2 = fd_mb_haddress2;
	}

	public String getSo_bj_gb() {
		return so_bj_gb;
	}

	public void setSo_bj_gb(String so_bj_gb) {
		this.so_bj_gb = so_bj_gb;
	}

	public String getSo_poli_no() {
		return so_poli_no;
	}

	public void setSo_poli_no(String so_poli_no) {
		this.so_poli_no = so_poli_no;
	}

	public String getSo_poli_no_main() {
		return so_poli_no_main;
	}

	public void setSo_poli_no_main(String so_poli_no_main) {
		this.so_poli_no_main = so_poli_no_main;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getSo_pa_mail() {
		return so_pa_mail;
	}

	public void setSo_pa_mail(String so_pa_mail) {
		this.so_pa_mail = so_pa_mail;
	}

	public String getGy_jumn_no() {
		return gy_jumn_no;
	}

	public void setGy_jumn_no(String gy_jumn_no) {
		this.gy_jumn_no = gy_jumn_no;
	}


	public String getCUST_ADDR() {
		return CUST_ADDR;
	}

	public void setCUST_ADDR(String cUST_ADDR) {
		CUST_ADDR = cUST_ADDR;
	}

	public String getContact_addr() {
		return contact_addr;
	}

	public void setContact_addr(String contact_addr) {
		this.contact_addr = contact_addr;
	}

	public String getSuikja_addr() {
		return suikja_addr;
	}

	public void setSuikja_addr(String suikja_addr) {
		this.suikja_addr = suikja_addr;
	}

	public String getUpjongNm() {
		return upjongNm;
	}

	public void setUpjongNm(String upjongNm) {
		this.upjongNm = upjongNm;
	}

	public String getSAYONG_YONGDO_CD() {
		return SAYONG_YONGDO_CD;
	}

	public void setSAYONG_YONGDO_CD(String sAYONG_YONGDO_CD) {
		SAYONG_YONGDO_CD = sAYONG_YONGDO_CD;
	}

	public String getSAYONG_SEBU() {
		return SAYONG_SEBU;
	}

	public void setSAYONG_SEBU(String sAYONG_SEBU) {
		SAYONG_SEBU = sAYONG_SEBU;
	}

	public String getTUKYAK_limits() {
		return TUKYAK_limits;
	}

	public void setTUKYAK_limits(String tUKYAK_limits) {
		TUKYAK_limits = tUKYAK_limits;
	}

	public String getTUKYAK_age() {
		return TUKYAK_age;
	}

	public void setTUKYAK_age(String tUKYAK_age) {
		TUKYAK_age = tUKYAK_age;
	}

	public String getStrDtk() {
		return strDtk;
	}

	public void setStrDtk(String strDtk) {
		this.strDtk = strDtk;
	}

	public String getBUNNAP_BANGCD() {
		return BUNNAP_BANGCD;
	}

	public void setBUNNAP_BANGCD(String bUNNAP_BANGCD) {
		BUNNAP_BANGCD = bUNNAP_BANGCD;
	}

	public String getLK_GA1085_BULIP_CNT() {
		return LK_GA1085_BULIP_CNT;
	}

	public void setLK_GA1085_BULIP_CNT(String lK_GA1085_BULIP_CNT) {
		LK_GA1085_BULIP_CNT = lK_GA1085_BULIP_CNT;
	}


	public String getPIB_TEL_NO() {
		return PIB_TEL_NO;
	}

	public void setPIB_TEL_NO(String pIB_TEL_NO) {
		PIB_TEL_NO = pIB_TEL_NO;
	}

	public String getGYE_TEL_NO() {
		return GYE_TEL_NO;
	}

	public void setGYE_TEL_NO(String gYE_TEL_NO) {
		GYE_TEL_NO = gYE_TEL_NO;
	}

	public String getTUKYAK_UNJUNJA() {
		return TUKYAK_UNJUNJA;
	}

	public void setTUKYAK_UNJUNJA(String tUKYAK_UNJUNJA) {
		TUKYAK_UNJUNJA = tUKYAK_UNJUNJA;
	}

	public String getTUKYAK_jadongiche() {
		return TUKYAK_jadongiche;
	}

	public void setTUKYAK_jadongiche(String tUKYAK_jadongiche) {
		TUKYAK_jadongiche = tUKYAK_jadongiche;
	}

	public String getTEMP_SUIKJA_GOGEKNO() {
		return TEMP_SUIKJA_GOGEKNO;
	}

	public void setTEMP_SUIKJA_GOGEKNO(String tEMP_SUIKJA_GOGEKNO) {
		TEMP_SUIKJA_GOGEKNO = tEMP_SUIKJA_GOGEKNO;
	}

	public String getTEMP_SUIKJA_ZIP() {
		return TEMP_SUIKJA_ZIP;
	}

	public void setTEMP_SUIKJA_ZIP(String tEMP_SUIKJA_ZIP) {
		TEMP_SUIKJA_ZIP = tEMP_SUIKJA_ZIP;
	}

	public String getTEMP_SUIKJA_ADDR() {
		return TEMP_SUIKJA_ADDR;
	}

	public void setTEMP_SUIKJA_ADDR(String tEMP_SUIKJA_ADDR) {
		TEMP_SUIKJA_ADDR = tEMP_SUIKJA_ADDR;
	}

	public String getTEMP_SUIKJA_HP_TEL1_NO() {
		return TEMP_SUIKJA_HP_TEL1_NO;
	}

	public void setTEMP_SUIKJA_HP_TEL1_NO(String tEMP_SUIKJA_HP_TEL1_NO) {
		TEMP_SUIKJA_HP_TEL1_NO = tEMP_SUIKJA_HP_TEL1_NO;
	}

	public String getTEMP_SUIKJA_HOME_TEL2_NO() {
		return TEMP_SUIKJA_HOME_TEL2_NO;
	}

	public void setTEMP_SUIKJA_HOME_TEL2_NO(String tEMP_SUIKJA_HOME_TEL2_NO) {
		TEMP_SUIKJA_HOME_TEL2_NO = tEMP_SUIKJA_HOME_TEL2_NO;
	}

	public String[] getTUKYAK_CD() {
		return TUKYAK_CD;
	}

	public void setTUKYAK_CD(String[] tUKYAK_CD) {
		TUKYAK_CD = tUKYAK_CD;
	}

	public String[] getTUKYAK_RATE() {
		return TUKYAK_RATE;
	}

	public void setTUKYAK_RATE(String[] tUKYAK_RATE) {
		TUKYAK_RATE = tUKYAK_RATE;
	}

	public String[] getTUKBUL_CD() {
		return TUKBUL_CD;
	}

	public void setTUKBUL_CD(String[] tUKBUL_CD) {
		TUKBUL_CD = tUKBUL_CD;
	}

	public String[] getTUKBUL_RATE() {
		return TUKBUL_RATE;
	}

	public void setTUKBUL_RATE(String[] tUKBUL_RATE) {
		TUKBUL_RATE = tUKBUL_RATE;
	}

	public String getHJ_BJ_NM() {
		return HJ_BJ_NM;
	}

	public void setHJ_BJ_NM(String hJ_BJ_NM) {
		HJ_BJ_NM = hJ_BJ_NM;
	}

	public String getHJ_BIGO() {
		return HJ_BIGO;
	}

	public void setHJ_BIGO(String hJ_BIGO) {
		HJ_BIGO = hJ_BIGO;
	}

	public String getHJ_GYEYAK_NM() {
		return HJ_GYEYAK_NM;
	}

	public void setHJ_GYEYAK_NM(String hJ_GYEYAK_NM) {
		HJ_GYEYAK_NM = hJ_GYEYAK_NM;
	}

	public String getHJ_PIBO_NM() {
		return HJ_PIBO_NM;
	}

	public void setHJ_PIBO_NM(String hJ_PIBO_NM) {
		HJ_PIBO_NM = hJ_PIBO_NM;
	}

	public String getHJ_CHIGUB_NM() {
		return HJ_CHIGUB_NM;
	}

	public void setHJ_CHIGUB_NM(String hJ_CHIGUB_NM) {
		HJ_CHIGUB_NM = hJ_CHIGUB_NM;
	}

	public String getJJ_BOHUM_GIGANCD() {
		return JJ_BOHUM_GIGANCD;
	}

	public void setJJ_BOHUM_GIGANCD(String jJ_BOHUM_GIGANCD) {
		JJ_BOHUM_GIGANCD = jJ_BOHUM_GIGANCD;
	}

	public String getJJ_BOHUM_GIGAN_S() {
		return JJ_BOHUM_GIGAN_S;
	}

	public void setJJ_BOHUM_GIGAN_S(String jJ_BOHUM_GIGAN_S) {
		JJ_BOHUM_GIGAN_S = jJ_BOHUM_GIGAN_S;
	}

	public String getJJ_BOHUM_GIGAN_E() {
		return JJ_BOHUM_GIGAN_E;
	}

	public void setJJ_BOHUM_GIGAN_E(String jJ_BOHUM_GIGAN_E) {
		JJ_BOHUM_GIGAN_E = jJ_BOHUM_GIGAN_E;
	}

	public String getJJ_CHIGUB_TEL() {
		return JJ_CHIGUB_TEL;
	}

	public void setJJ_CHIGUB_TEL(String jJ_CHIGUB_TEL) {
		JJ_CHIGUB_TEL = jJ_CHIGUB_TEL;
	}

	public String getJJ_GAIP_TYPE() {
		return JJ_GAIP_TYPE;
	}

	public void setJJ_GAIP_TYPE(String jJ_GAIP_TYPE) {
		JJ_GAIP_TYPE = jJ_GAIP_TYPE;
	}

	public String getJJ_GYEYAK_JMNO() {
		return JJ_GYEYAK_JMNO;
	}

	public void setJJ_GYEYAK_JMNO(String jJ_GYEYAK_JMNO) {
		JJ_GYEYAK_JMNO = jJ_GYEYAK_JMNO;
	}

	public String getJJ_JUPSU() {
		return JJ_JUPSU;
	}

	public void setJJ_JUPSU(String jJ_JUPSU) {
		JJ_JUPSU = jJ_JUPSU;
	}

	public String getJJ_POLI_NO() {
		return JJ_POLI_NO;
	}

	public void setJJ_POLI_NO(String jJ_POLI_NO) {
		JJ_POLI_NO = jJ_POLI_NO;
	}

	public String getContract() {
		return contract;
	}

	public void setContract(String contract) {
		this.contract = contract;
	}

	public String getUD_FK_POLI_NO() {
		return UD_FK_POLI_NO;
	}

	public void setUD_FK_POLI_NO(String uD_FK_POLI_NO) {
		UD_FK_POLI_NO = uD_FK_POLI_NO;
	}

	public String getUD_LK_POLI_NO() {
		return UD_LK_POLI_NO;
	}

	public void setUD_LK_POLI_NO(String uD_LK_POLI_NO) {
		UD_LK_POLI_NO = uD_LK_POLI_NO;
	}

	public String getPREV_UD_FK_POLI_NO() {
		return PREV_UD_FK_POLI_NO;
	}

	public void setPREV_UD_FK_POLI_NO(String pREV_UD_FK_POLI_NO) {
		PREV_UD_FK_POLI_NO = pREV_UD_FK_POLI_NO;
	}

	public String getSI_K_GOGEK_NO() {
		return SI_K_GOGEK_NO;
	}

	public void setSI_K_GOGEK_NO(String sI_K_GOGEK_NO) {
		SI_K_GOGEK_NO = sI_K_GOGEK_NO;
	}

	public String getPlace_name1() {
		return place_name1;
	}

	public void setPlace_name1(String place_name1) {
		this.place_name1 = place_name1;
	}

	public String getPlace_name2() {
		return place_name2;
	}

	public void setPlace_name2(String place_name2) {
		this.place_name2 = place_name2;
	}

	public String getPoli_no_normal() {
		return poli_no_normal;
	}

	public void setPoli_no_normal(String poli_no_normal) {
		this.poli_no_normal = poli_no_normal;
	}

	public String getJJ_GIBON_PRM() {
		return JJ_GIBON_PRM;
	}

	public void setJJ_GIBON_PRM(String jJ_GIBON_PRM) {
		JJ_GIBON_PRM = jJ_GIBON_PRM;
	}

	public String getChange_baseo_gb() {
		return change_baseo_gb;
	}

	public void setChange_baseo_gb(String change_baseo_gb) {
		this.change_baseo_gb = change_baseo_gb;
	}

	public String getHJ_PI_NAME() {
		return HJ_PI_NAME;
	}

	public void setHJ_PI_NAME(String hJ_PI_NAME) {
		HJ_PI_NAME = hJ_PI_NAME;
	}

	public String getPrevPageName() {
		return prevPageName;
	}

	public void setPrevPageName(String prevPageName) {
		this.prevPageName = prevPageName;
	}

	public String getRE_STPLT_LOAN_RESID_AMT() {
		return RE_STPLT_LOAN_RESID_AMT;
	}

	public void setRE_STPLT_LOAN_RESID_AMT(String rE_STPLT_LOAN_RESID_AMT) {
		RE_STPLT_LOAN_RESID_AMT = rE_STPLT_LOAN_RESID_AMT;
	}

	public String[] getSabeon() {
		return sabeon;
	}

	public void setSabeon(String[] sabeon) {
		this.sabeon = sabeon;
	}

	public String[] getArea_tel_no() {
		return area_tel_no;
	}

	public void setArea_tel_no(String[] area_tel_no) {
		this.area_tel_no = area_tel_no;
	}

	public String[] getFrnt_tel_no() {
		return frnt_tel_no;
	}

	public void setFrnt_tel_no(String[] frnt_tel_no) {
		this.frnt_tel_no = frnt_tel_no;
	}

	public String[] getAftr_tel_no() {
		return aftr_tel_no;
	}

	public void setAftr_tel_no(String[] aftr_tel_no) {
		this.aftr_tel_no = aftr_tel_no;
	}

	public String[] getFrnt_hphon_no() {
		return frnt_hphon_no;
	}

	public void setFrnt_hphon_no(String[] frnt_hphon_no) {
		this.frnt_hphon_no = frnt_hphon_no;
	}

	public String[] getIntmd_hphon_no() {
		return intmd_hphon_no;
	}

	public void setIntmd_hphon_no(String[] intmd_hphon_no) {
		this.intmd_hphon_no = intmd_hphon_no;
	}

	public String[] getHphon_aftr_tel_no() {
		return hphon_aftr_tel_no;
	}

	public void setHphon_aftr_tel_no(String[] hphon_aftr_tel_no) {
		this.hphon_aftr_tel_no = hphon_aftr_tel_no;
	}

	public String[] getEmail_addr_name() {
		return email_addr_name;
	}

	public void setEmail_addr_name(String[] email_addr_name) {
		this.email_addr_name = email_addr_name;
	}

	public String[] getGreetPic() {
		return greetPic;
	}

	public void setGreetPic(String[] greetPic) {
		this.greetPic = greetPic;
	}

	public String[] getGreetText() {
		return greetText;
	}

	public void setGreetText(String[] greetText) {
		this.greetText = greetText;
	}

	public String[] getGender() {
		return gender;
	}

	public void setGender(String[] gender) {
		this.gender = gender;
	}

	public String getSend_name() {
		return send_name;
	}

	public void setSend_name(String send_name) {
		this.send_name = send_name;
	}

	public String getSend_email() {
		return send_email;
	}

	public void setSend_email(String send_email) {
		this.send_email = send_email;
	}

	public String getSend_title() {
		return send_title;
	}

	public void setSend_title(String send_title) {
		this.send_title = send_title;
	}

	public String getSend_html() {
		return send_html;
	}

	public void setSend_html(String send_html) {
		this.send_html = send_html;
	}

	public String getCheck() {
		return check;
	}

	public void setCheck(String check) {
		this.check = check;
	}

	public String getNAPIP_DATE() {
		return NAPIP_DATE;
	}

	public void setNAPIP_DATE(String nAPIP_DATE) {
		NAPIP_DATE = nAPIP_DATE;
	}
	
}
