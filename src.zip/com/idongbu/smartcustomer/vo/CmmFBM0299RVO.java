package com.idongbu.smartcustomer.vo;

import com.idongbu.common.vo.CMMVO;

//약관대출가능조회
public class CmmFBM0299RVO  extends CMMVO{
	
	public CmmFBM0299RVO() {
		super.setPGMID(proid);
		super.setTRID(trid);
	}
	
	private final static String proid		= "FBM0299R";
	private final static String trid		= "BMY5";
	private String rURL						= "";
	
	// 입력
	private String SI_GUBUN = ""; // 구분자
	private String SI_GOGEK_NO    = ""; // 고객번호
	private String SO_H_GBN = ""; // 변경여부
	private String SO_J_GBN = ""; // 변경여부
	private String SO_G_GBN = ""; // 변경여부
	private String SO_HP_GBN = ""; // 변경여부
	private String SO_HT_GBN = ""; // 변경여부
	private String SO_JT_GBN = ""; // 변경여부
	private String SO_E_GBN = ""; // 변경여부
	private String SI_EMAIL_SUSIN_YN = ""; // 1 수신, 2 거부
	private String SI_EMAIL_DM_YN = ""; // 01 수신, 공백 거부
	private String SO_H_GBN_2	= "";
	private String SO_J_GBN_2   = "";
	
	// 출력
	private String COMM_CHANNEL = "";
	private String COMM_UNIQUE_KEY = "";
	private String COMM_PGMID = "";
	private String COMM_PROC_GB = "";
	private String COMM_ACTION_KEY = "";
	private String COMM_USER_GB = "";
	private String COMM_USER_ID = "";
	private String COMM_JIJUM_CD = "";
	private String COMM_JIBU_CD = "";
	private String COMM_PROTOCOL = "";
	private String COMM_COND_CD = "";
	private String COMM_LAST_FLAG = "";
	private String COMM_CURSOR_MAP = "";
	private String COMM_CURSOR_IDX = "";
	private String COMM_MESSAGE_CD = "";
	private String HOMM_MESSAGE_NM = "";
	private String COMM_ERR_NAME = "";
	private String COMM_ERR_TEXT = "";
	private String COMM_SYS_CODE = "";
	private String COMM_FILLER = "";
	//private String SI_GUBUN = "";
	//private String SI_GOGEK_NO = "";
	private String HO_GOGEK_NM = "";
	private String SI_H_ZIP = "";
	private String SI_H_ZIP1 = "";
	private String SI_H_ZIP2 = "";
	private String HO_H_JUSO = "";
	private String HI_H_ADDR = "";
	//private String SO_H_GBN = "";
	private String SI_J_ZIP = "";
	private String SI_J_ZIP1 = "";
	private String SI_J_ZIP2 = "";
	private String HO_J_JUSO = "";
	private String HI_J_ADDR = "";
	//private String SO_J_GBN = "";
	private String SI_G_ZIP = "";
	private String HO_G_JUSO = "";
	private String HI_G_ADDR = "";
	//private String SO_G_GBN = "";
	private String SI_HP_TEL1 = "";
	private String SI_HP_TEL2 = "";
	private String SI_HP_TEL3 = "";
	//private String SO_HP_GBN = "";
	private String SI_H_TEL1 = "";
	private String SI_H_TEL2 = "";
	private String SI_H_TEL3 = "";
	//private String SO_HT_GBN = "";
	private String SI_J_TEL1 = "";
	private String SI_J_TEL2 = "";
	private String SI_J_TEL3 = "";
	//private String SO_JT_GBN = "";
	private String SI_EMAIL_ID = "";
	//private String SI_EMAIL_SUSIN_YN = "";
	//private String SI_EMAIL_DM_YN = "";
	//private String SO_E_GBN = "";
	private String FILLER = "";
	
	// 도로명주소 관련추가
	private String SI_ST_H_ZIP	= "";		//집도로명우편번호
	private String SI_ST_H_ZIP1 = "";
	private String SI_ST_H_ZIP2 = "";
	private String HI_ST_H_ADDR	= "";		//집도로명주소    
	private String HI_ST_H_GITA	= "";		//집도로명주소기타       
	private String SO_ST_H_GBN	= "";		//집도로명주소수정구분       
	private String SI_ST_J_ZIP	= "";		//직장도로명우편번호
	private String SI_ST_J_ZIP1	= "";		
	private String SI_ST_J_ZIP2	= "";
	private String HI_ST_J_ADDR	= "";		//직장도로명주소       
	private String HI_ST_J_GITA	= "";		//직장도로명주소기타       
	private String SO_ST_J_GBN	= "";		//직장도로명주소수정구분       
	private String SI_ST_G_ZIP	= "";		//기타도로명우편번호        
	private String HI_ST_G_ADDR	= "";		//기타도로명주소       
	private String HI_ST_G_GITA	= "";		//기타도로명주소기타       
	private String SO_ST_G_GBN	= "";		//기타도로명주소수정구분
	private String RET_MSG		= "";
	
	public String getrURL() {
		return rURL;
	}
	public void setrURL(String rURL) {
		this.rURL = rURL;
	}
	public String getSI_GUBUN() {
		return SI_GUBUN;
	}
	public void setSI_GUBUN(String sI_GUBUN) {
		SI_GUBUN = sI_GUBUN;
	}
	public String getSI_GOGEK_NO() {
		return SI_GOGEK_NO;
	}
	public void setSI_GOGEK_NO(String sI_GOGEK_NO) {
		SI_GOGEK_NO = sI_GOGEK_NO;
	}
	public String getSO_H_GBN() {
		return SO_H_GBN;
	}
	public void setSO_H_GBN(String sO_H_GBN) {
		SO_H_GBN = sO_H_GBN;
	}
	public String getSO_J_GBN() {
		return SO_J_GBN;
	}
	public void setSO_J_GBN(String sO_J_GBN) {
		SO_J_GBN = sO_J_GBN;
	}
	public String getSO_G_GBN() {
		return SO_G_GBN;
	}
	public void setSO_G_GBN(String sO_G_GBN) {
		SO_G_GBN = sO_G_GBN;
	}
	public String getSO_HP_GBN() {
		return SO_HP_GBN;
	}
	public void setSO_HP_GBN(String sO_HP_GBN) {
		SO_HP_GBN = sO_HP_GBN;
	}
	public String getSO_HT_GBN() {
		return SO_HT_GBN;
	}
	public void setSO_HT_GBN(String sO_HT_GBN) {
		SO_HT_GBN = sO_HT_GBN;
	}
	public String getSO_JT_GBN() {
		return SO_JT_GBN;
	}
	public void setSO_JT_GBN(String sO_JT_GBN) {
		SO_JT_GBN = sO_JT_GBN;
	}
	public String getSO_E_GBN() {
		return SO_E_GBN;
	}
	public void setSO_E_GBN(String sO_E_GBN) {
		SO_E_GBN = sO_E_GBN;
	}
	public String getSI_EMAIL_SUSIN_YN() {
		return SI_EMAIL_SUSIN_YN;
	}
	public void setSI_EMAIL_SUSIN_YN(String sI_EMAIL_SUSIN_YN) {
		SI_EMAIL_SUSIN_YN = sI_EMAIL_SUSIN_YN;
	}
	public String getSI_EMAIL_DM_YN() {
		return SI_EMAIL_DM_YN;
	}
	public void setSI_EMAIL_DM_YN(String sI_EMAIL_DM_YN) {
		SI_EMAIL_DM_YN = sI_EMAIL_DM_YN;
	}
	public String getCOMM_CHANNEL() {
		return COMM_CHANNEL;
	}
	public void setCOMM_CHANNEL(String cOMM_CHANNEL) {
		COMM_CHANNEL = cOMM_CHANNEL;
	}
	public String getCOMM_UNIQUE_KEY() {
		return COMM_UNIQUE_KEY;
	}
	public void setCOMM_UNIQUE_KEY(String cOMM_UNIQUE_KEY) {
		COMM_UNIQUE_KEY = cOMM_UNIQUE_KEY;
	}
	public String getCOMM_PGMID() {
		return COMM_PGMID;
	}
	public void setCOMM_PGMID(String cOMM_PGMID) {
		COMM_PGMID = cOMM_PGMID;
	}
	public String getCOMM_PROC_GB() {
		return COMM_PROC_GB;
	}
	public void setCOMM_PROC_GB(String cOMM_PROC_GB) {
		COMM_PROC_GB = cOMM_PROC_GB;
	}
	public String getCOMM_ACTION_KEY() {
		return COMM_ACTION_KEY;
	}
	public void setCOMM_ACTION_KEY(String cOMM_ACTION_KEY) {
		COMM_ACTION_KEY = cOMM_ACTION_KEY;
	}
	public String getCOMM_USER_GB() {
		return COMM_USER_GB;
	}
	public void setCOMM_USER_GB(String cOMM_USER_GB) {
		COMM_USER_GB = cOMM_USER_GB;
	}
	public String getCOMM_USER_ID() {
		return COMM_USER_ID;
	}
	public void setCOMM_USER_ID(String cOMM_USER_ID) {
		COMM_USER_ID = cOMM_USER_ID;
	}
	public String getCOMM_JIJUM_CD() {
		return COMM_JIJUM_CD;
	}
	public void setCOMM_JIJUM_CD(String cOMM_JIJUM_CD) {
		COMM_JIJUM_CD = cOMM_JIJUM_CD;
	}
	public String getCOMM_JIBU_CD() {
		return COMM_JIBU_CD;
	}
	public void setCOMM_JIBU_CD(String cOMM_JIBU_CD) {
		COMM_JIBU_CD = cOMM_JIBU_CD;
	}
	public String getCOMM_PROTOCOL() {
		return COMM_PROTOCOL;
	}
	public void setCOMM_PROTOCOL(String cOMM_PROTOCOL) {
		COMM_PROTOCOL = cOMM_PROTOCOL;
	}
	public String getCOMM_COND_CD() {
		return COMM_COND_CD;
	}
	public void setCOMM_COND_CD(String cOMM_COND_CD) {
		COMM_COND_CD = cOMM_COND_CD;
	}
	public String getCOMM_LAST_FLAG() {
		return COMM_LAST_FLAG;
	}
	public void setCOMM_LAST_FLAG(String cOMM_LAST_FLAG) {
		COMM_LAST_FLAG = cOMM_LAST_FLAG;
	}
	public String getCOMM_CURSOR_MAP() {
		return COMM_CURSOR_MAP;
	}
	public void setCOMM_CURSOR_MAP(String cOMM_CURSOR_MAP) {
		COMM_CURSOR_MAP = cOMM_CURSOR_MAP;
	}
	public String getCOMM_CURSOR_IDX() {
		return COMM_CURSOR_IDX;
	}
	public void setCOMM_CURSOR_IDX(String cOMM_CURSOR_IDX) {
		COMM_CURSOR_IDX = cOMM_CURSOR_IDX;
	}
	public String getCOMM_MESSAGE_CD() {
		return COMM_MESSAGE_CD;
	}
	public void setCOMM_MESSAGE_CD(String cOMM_MESSAGE_CD) {
		COMM_MESSAGE_CD = cOMM_MESSAGE_CD;
	}
	public String getHOMM_MESSAGE_NM() {
		return HOMM_MESSAGE_NM;
	}
	public void setHOMM_MESSAGE_NM(String hOMM_MESSAGE_NM) {
		HOMM_MESSAGE_NM = hOMM_MESSAGE_NM;
	}
	public String getCOMM_ERR_NAME() {
		return COMM_ERR_NAME;
	}
	public void setCOMM_ERR_NAME(String cOMM_ERR_NAME) {
		COMM_ERR_NAME = cOMM_ERR_NAME;
	}
	public String getCOMM_ERR_TEXT() {
		return COMM_ERR_TEXT;
	}
	public void setCOMM_ERR_TEXT(String cOMM_ERR_TEXT) {
		COMM_ERR_TEXT = cOMM_ERR_TEXT;
	}
	public String getCOMM_SYS_CODE() {
		return COMM_SYS_CODE;
	}
	public void setCOMM_SYS_CODE(String cOMM_SYS_CODE) {
		COMM_SYS_CODE = cOMM_SYS_CODE;
	}
	public String getCOMM_FILLER() {
		return COMM_FILLER;
	}
	public void setCOMM_FILLER(String cOMM_FILLER) {
		COMM_FILLER = cOMM_FILLER;
	}
	public String getHO_GOGEK_NM() {
		return HO_GOGEK_NM;
	}
	public void setHO_GOGEK_NM(String hO_GOGEK_NM) {
		HO_GOGEK_NM = hO_GOGEK_NM;
	}
	public void setSI_H_ZIP(String sI_H_ZIP) {
		SI_H_ZIP = sI_H_ZIP;
	}
	public String getHO_H_JUSO() {
		return HO_H_JUSO;
	}
	public void setHO_H_JUSO(String hO_H_JUSO) {
		HO_H_JUSO = hO_H_JUSO;
	}
	public String getHI_H_ADDR() {
		return HI_H_ADDR;
	}
	public void setHI_H_ADDR(String hI_H_ADDR) {
		HI_H_ADDR = hI_H_ADDR;
	}
	public String getSI_J_ZIP() {
		return SI_J_ZIP;
	}
	public void setSI_J_ZIP(String sI_J_ZIP) {
		SI_J_ZIP = sI_J_ZIP;
	}
	public String getHO_J_JUSO() {
		return HO_J_JUSO;
	}
	public void setHO_J_JUSO(String hO_J_JUSO) {
		HO_J_JUSO = hO_J_JUSO;
	}
	public String getHI_J_ADDR() {
		return HI_J_ADDR;
	}
	public void setHI_J_ADDR(String hI_J_ADDR) {
		HI_J_ADDR = hI_J_ADDR;
	}
	public String getSI_G_ZIP() {
		return SI_G_ZIP;
	}
	public void setSI_G_ZIP(String sI_G_ZIP) {
		SI_G_ZIP = sI_G_ZIP;
	}
	public String getHO_G_JUSO() {
		return HO_G_JUSO;
	}
	public void setHO_G_JUSO(String hO_G_JUSO) {
		HO_G_JUSO = hO_G_JUSO;
	}
	public String getHI_G_ADDR() {
		return HI_G_ADDR;
	}
	public void setHI_G_ADDR(String hI_G_ADDR) {
		HI_G_ADDR = hI_G_ADDR;
	}
	public String getSI_HP_TEL1() {
		return SI_HP_TEL1;
	}
	public void setSI_HP_TEL1(String sI_HP_TEL1) {
		SI_HP_TEL1 = sI_HP_TEL1;
	}
	public String getSI_HP_TEL2() {
		return SI_HP_TEL2;
	}
	public void setSI_HP_TEL2(String sI_HP_TEL2) {
		SI_HP_TEL2 = sI_HP_TEL2;
	}
	public String getSI_HP_TEL3() {
		return SI_HP_TEL3;
	}
	public void setSI_HP_TEL3(String sI_HP_TEL3) {
		SI_HP_TEL3 = sI_HP_TEL3;
	}
	public String getSI_H_TEL1() {
		return SI_H_TEL1;
	}
	public void setSI_H_TEL1(String sI_H_TEL1) {
		SI_H_TEL1 = sI_H_TEL1;
	}
	public String getSI_H_TEL2() {
		return SI_H_TEL2;
	}
	public void setSI_H_TEL2(String sI_H_TEL2) {
		SI_H_TEL2 = sI_H_TEL2;
	}
	public String getSI_H_TEL3() {
		return SI_H_TEL3;
	}
	public void setSI_H_TEL3(String sI_H_TEL3) {
		SI_H_TEL3 = sI_H_TEL3;
	}
	public String getSI_J_TEL1() {
		return SI_J_TEL1;
	}
	public void setSI_J_TEL1(String sI_J_TEL1) {
		SI_J_TEL1 = sI_J_TEL1;
	}
	public String getSI_J_TEL2() {
		return SI_J_TEL2;
	}
	public void setSI_J_TEL2(String sI_J_TEL2) {
		SI_J_TEL2 = sI_J_TEL2;
	}
	public String getSI_J_TEL3() {
		return SI_J_TEL3;
	}
	public void setSI_J_TEL3(String sI_J_TEL3) {
		SI_J_TEL3 = sI_J_TEL3;
	}
	public String getSI_EMAIL_ID() {
		return SI_EMAIL_ID;
	}
	public void setSI_EMAIL_ID(String sI_EMAIL_ID) {
		SI_EMAIL_ID = sI_EMAIL_ID;
	}
	public String getFILLER() {
		return FILLER;
	}
	public void setFILLER(String fILLER) {
		FILLER = fILLER;
	}
	public String getHI_ST_H_ADDR() {
		return HI_ST_H_ADDR;
	}
	public void setHI_ST_H_ADDR(String hI_ST_H_ADDR) {
		HI_ST_H_ADDR = hI_ST_H_ADDR;
	}
	public String getHI_ST_H_GITA() {
		return HI_ST_H_GITA;
	}
	public void setHI_ST_H_GITA(String hI_ST_H_GITA) {
		HI_ST_H_GITA = hI_ST_H_GITA;
	}
	public String getSO_ST_H_GBN() {
		return SO_ST_H_GBN;
	}
	public void setSO_ST_H_GBN(String sO_ST_H_GBN) {
		SO_ST_H_GBN = sO_ST_H_GBN;
	}
	public String getSI_ST_J_ZIP() {
		return SI_ST_J_ZIP;
	}
	public void setSI_ST_J_ZIP(String sI_ST_J_ZIP) {
		SI_ST_J_ZIP = sI_ST_J_ZIP;
	}
	public String getHI_ST_J_ADDR() {
		return HI_ST_J_ADDR;
	}
	public void setHI_ST_J_ADDR(String hI_ST_J_ADDR) {
		HI_ST_J_ADDR = hI_ST_J_ADDR;
	}
	public String getHI_ST_J_GITA() {
		return HI_ST_J_GITA;
	}
	public void setHI_ST_J_GITA(String hI_ST_J_GITA) {
		HI_ST_J_GITA = hI_ST_J_GITA;
	}
	public String getSO_ST_J_GBN() {
		return SO_ST_J_GBN;
	}
	public void setSO_ST_J_GBN(String sO_ST_J_GBN) {
		SO_ST_J_GBN = sO_ST_J_GBN;
	}
	public String getSI_ST_G_ZIP() {
		return SI_ST_G_ZIP;
	}
	public void setSI_ST_G_ZIP(String sI_ST_G_ZIP) {
		SI_ST_G_ZIP = sI_ST_G_ZIP;
	}
	public String getHI_ST_G_ADDR() {
		return HI_ST_G_ADDR;
	}
	public void setHI_ST_G_ADDR(String hI_ST_G_ADDR) {
		HI_ST_G_ADDR = hI_ST_G_ADDR;
	}
	public String getHI_ST_G_GITA() {
		return HI_ST_G_GITA;
	}
	public void setHI_ST_G_GITA(String hI_ST_G_GITA) {
		HI_ST_G_GITA = hI_ST_G_GITA;
	}
	public String getSO_ST_G_GBN() {
		return SO_ST_G_GBN;
	}
	public void setSO_ST_G_GBN(String sO_ST_G_GBN) {
		SO_ST_G_GBN = sO_ST_G_GBN;
	}
	public String getProid() {
		return proid;
	}
	public String getTrid() {
		return trid;
	}
	public String getRET_MSG() {
		return RET_MSG;
	}
	public void setRET_MSG(String rET_MSG) {
		RET_MSG = rET_MSG;
	}
	public String getSI_H_ZIP2() {
		return SI_H_ZIP2;
	}
	public void setSI_H_ZIP2(String sI_H_ZIP2) {
		SI_H_ZIP2 = sI_H_ZIP2;
	}
	public String getSI_J_ZIP1() {
		return SI_J_ZIP1;
	}
	public void setSI_J_ZIP1(String sI_J_ZIP1) {
		SI_J_ZIP1 = sI_J_ZIP1;
	}
	public String getSI_J_ZIP2() {
		return SI_J_ZIP2;
	}
	public void setSI_J_ZIP2(String sI_J_ZIP2) {
		SI_J_ZIP2 = sI_J_ZIP2;
	}
	public String getSI_ST_H_ZIP1() {
		return SI_ST_H_ZIP1;
	}
	public void setSI_ST_H_ZIP1(String sI_ST_H_ZIP1) {
		SI_ST_H_ZIP1 = sI_ST_H_ZIP1;
	}
	public String getSI_ST_H_ZIP2() {
		return SI_ST_H_ZIP2;
	}
	public void setSI_ST_H_ZIP2(String sI_ST_H_ZIP2) {
		SI_ST_H_ZIP2 = sI_ST_H_ZIP2;
	}
	public String getSI_H_ZIP() {
		return SI_H_ZIP;
	}
	public String getSI_H_ZIP1() {
		return SI_H_ZIP1;
	}
	public void setSI_H_ZIP1(String sI_H_ZIP1) {
		SI_H_ZIP1 = sI_H_ZIP1;
	}
	public String getSI_ST_J_ZIP1() {
		return SI_ST_J_ZIP1;
	}
	public void setSI_ST_J_ZIP1(String sI_ST_J_ZIP1) {
		SI_ST_J_ZIP1 = sI_ST_J_ZIP1;
	}
	public String getSI_ST_J_ZIP2() {
		return SI_ST_J_ZIP2;
	}
	public void setSI_ST_J_ZIP2(String sI_ST_J_ZIP2) {
		SI_ST_J_ZIP2 = sI_ST_J_ZIP2;
	}
	public String getSO_H_GBN_2() {
		return SO_H_GBN_2;
	}
	public void setSO_H_GBN_2(String sO_H_GBN_2) {
		SO_H_GBN_2 = sO_H_GBN_2;
	}
	public String getSO_J_GBN_2() {
		return SO_J_GBN_2;
	}
	public void setSO_J_GBN_2(String sO_J_GBN_2) {
		SO_J_GBN_2 = sO_J_GBN_2;
	}
	public String getSI_ST_H_ZIP() {
		return SI_ST_H_ZIP;
	}
	public void setSI_ST_H_ZIP(String sI_ST_H_ZIP) {
		SI_ST_H_ZIP = sI_ST_H_ZIP;
	}
	
}