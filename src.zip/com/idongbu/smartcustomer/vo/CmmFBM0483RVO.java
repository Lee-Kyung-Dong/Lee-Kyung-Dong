package com.idongbu.smartcustomer.vo;
import com.idongbu.common.vo.CMMVO;

// 통고 홈페이지 우수고객 등급 확인 
public class CmmFBM0483RVO extends CMMVO {
	public CmmFBM0483RVO() {
		super.setPGMID(this.proid);
		super.setTRID(this.trid);
	}
	public static final String proid		= "FBM0483R";
	public static final String trid		= "BMIO";
	public String rURL						= "";

	
//SCREEN-DATA-AREA
	// 입력
	public String SI_GOGEK_NO = null; //주민번호
	public String SI_YEAR_MM = null; //우수고객 등급 기준 년월
	// 출력
	public String SO_USU_GOGEK_GB = null;
	public String SO_BOSANG_CONST = null;
	public String SO_IPRYUK_YMD = null;
	public String SO_IPRYUK_HMS = null;
	public String SO_POINT = null;
	public String SO_GRADE = null; 
	public String SO_DNGGP_NM = null;
	
	
	public String CM_CHANNEL_GB = null;
	public String CM_UNIQUE_KEY = null;
	public String CM_0QPGM_ID = null;
	public String CM_0QPROC_GB = null;
	public String CM_FUNCTION_PGUD = null;
	public String CM_USER_GB = null;
	public String CM_USER_ID = null;
	public String CM_JIJUM_CD = null;
	public String CM_JIBU_CD = null;
	public String CM_PROTOCOL_GB = null;
	public String CM_COND_CD = null;
	public String CM_LAST_FLAG = null;
	public String CM_CUR_LAYER = null;
	public String CM_CUR_INDEX = null;
	public String CM_MESSAGE_CD = null;
	public String HM_MESSAGE_NM = null;
	public String CM_SYS_ERR = null;
	public String CM_SPARE = null;
	public String getrURL() {
		return rURL;
	}
	public void setrURL(String rURL) {
		this.rURL = rURL;
	}
	public String getSI_GOGEK_NO() {
		return SI_GOGEK_NO;
	}
	public void setSI_GOGEK_NO(String sI_GOGEK_NO) {
		SI_GOGEK_NO = sI_GOGEK_NO;
	}
	public String getSI_YEAR_MM() {
		return SI_YEAR_MM;
	}
	public void setSI_YEAR_MM(String sI_YEAR_MM) {
		SI_YEAR_MM = sI_YEAR_MM;
	}
	public String getSO_USU_GOGEK_GB() {
		return SO_USU_GOGEK_GB;
	}
	public void setSO_USU_GOGEK_GB(String sO_USU_GOGEK_GB) {
		SO_USU_GOGEK_GB = sO_USU_GOGEK_GB;
	}
	public String getSO_BOSANG_CONST() {
		return SO_BOSANG_CONST;
	}
	public void setSO_BOSANG_CONST(String sO_BOSANG_CONST) {
		SO_BOSANG_CONST = sO_BOSANG_CONST;
	}
	public String getSO_IPRYUK_YMD() {
		return SO_IPRYUK_YMD;
	}
	public void setSO_IPRYUK_YMD(String sO_IPRYUK_YMD) {
		SO_IPRYUK_YMD = sO_IPRYUK_YMD;
	}
	public String getSO_IPRYUK_HMS() {
		return SO_IPRYUK_HMS;
	}
	public void setSO_IPRYUK_HMS(String sO_IPRYUK_HMS) {
		SO_IPRYUK_HMS = sO_IPRYUK_HMS;
	}
	public String getSO_POINT() {
		return SO_POINT;
	}
	public void setSO_POINT(String sO_POINT) {
		SO_POINT = sO_POINT;
	}
	public String getSO_GRADE() {
		return SO_GRADE;
	}
	public void setSO_GRADE(String sO_GRADE) {
		SO_GRADE = sO_GRADE;
	}
	public String getSO_DNGGP_NM() {
		return SO_DNGGP_NM;
	}
	public void setSO_DNGGP_NM(String sO_DNGGP_NM) {
		SO_DNGGP_NM = sO_DNGGP_NM;
	}
	public String getCM_CHANNEL_GB() {
		return CM_CHANNEL_GB;
	}
	public void setCM_CHANNEL_GB(String cM_CHANNEL_GB) {
		CM_CHANNEL_GB = cM_CHANNEL_GB;
	}
	public String getCM_UNIQUE_KEY() {
		return CM_UNIQUE_KEY;
	}
	public void setCM_UNIQUE_KEY(String cM_UNIQUE_KEY) {
		CM_UNIQUE_KEY = cM_UNIQUE_KEY;
	}
	public String getCM_0QPGM_ID() {
		return CM_0QPGM_ID;
	}
	public void setCM_0QPGM_ID(String cM_0QPGM_ID) {
		CM_0QPGM_ID = cM_0QPGM_ID;
	}
	public String getCM_0QPROC_GB() {
		return CM_0QPROC_GB;
	}
	public void setCM_0QPROC_GB(String cM_0QPROC_GB) {
		CM_0QPROC_GB = cM_0QPROC_GB;
	}
	public String getCM_FUNCTION_PGUD() {
		return CM_FUNCTION_PGUD;
	}
	public void setCM_FUNCTION_PGUD(String cM_FUNCTION_PGUD) {
		CM_FUNCTION_PGUD = cM_FUNCTION_PGUD;
	}
	public String getCM_USER_GB() {
		return CM_USER_GB;
	}
	public void setCM_USER_GB(String cM_USER_GB) {
		CM_USER_GB = cM_USER_GB;
	}
	public String getCM_USER_ID() {
		return CM_USER_ID;
	}
	public void setCM_USER_ID(String cM_USER_ID) {
		CM_USER_ID = cM_USER_ID;
	}
	public String getCM_JIJUM_CD() {
		return CM_JIJUM_CD;
	}
	public void setCM_JIJUM_CD(String cM_JIJUM_CD) {
		CM_JIJUM_CD = cM_JIJUM_CD;
	}
	public String getCM_JIBU_CD() {
		return CM_JIBU_CD;
	}
	public void setCM_JIBU_CD(String cM_JIBU_CD) {
		CM_JIBU_CD = cM_JIBU_CD;
	}
	public String getCM_PROTOCOL_GB() {
		return CM_PROTOCOL_GB;
	}
	public void setCM_PROTOCOL_GB(String cM_PROTOCOL_GB) {
		CM_PROTOCOL_GB = cM_PROTOCOL_GB;
	}
	public String getCM_COND_CD() {
		return CM_COND_CD;
	}
	public void setCM_COND_CD(String cM_COND_CD) {
		CM_COND_CD = cM_COND_CD;
	}
	public String getCM_LAST_FLAG() {
		return CM_LAST_FLAG;
	}
	public void setCM_LAST_FLAG(String cM_LAST_FLAG) {
		CM_LAST_FLAG = cM_LAST_FLAG;
	}
	public String getCM_CUR_LAYER() {
		return CM_CUR_LAYER;
	}
	public void setCM_CUR_LAYER(String cM_CUR_LAYER) {
		CM_CUR_LAYER = cM_CUR_LAYER;
	}
	public String getCM_CUR_INDEX() {
		return CM_CUR_INDEX;
	}
	public void setCM_CUR_INDEX(String cM_CUR_INDEX) {
		CM_CUR_INDEX = cM_CUR_INDEX;
	}
	public String getCM_MESSAGE_CD() {
		return CM_MESSAGE_CD;
	}
	public void setCM_MESSAGE_CD(String cM_MESSAGE_CD) {
		CM_MESSAGE_CD = cM_MESSAGE_CD;
	}
	public String getHM_MESSAGE_NM() {
		return HM_MESSAGE_NM;
	}
	public void setHM_MESSAGE_NM(String hM_MESSAGE_NM) {
		HM_MESSAGE_NM = hM_MESSAGE_NM;
	}
	public String getCM_SYS_ERR() {
		return CM_SYS_ERR;
	}
	public void setCM_SYS_ERR(String cM_SYS_ERR) {
		CM_SYS_ERR = cM_SYS_ERR;
	}
	public String getCM_SPARE() {
		return CM_SPARE;
	}
	public void setCM_SPARE(String cM_SPARE) {
		CM_SPARE = cM_SPARE;
	}
}
