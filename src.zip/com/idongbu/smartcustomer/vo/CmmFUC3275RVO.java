package com.idongbu.smartcustomer.vo;

import java.util.List;
import java.util.Map;

import com.idongbu.common.vo.CMMVO;


// 장기보험납입증명서
public class CmmFUC3275RVO extends CMMVO {
	
	public CmmFUC3275RVO() {
		super.setPGMID(this.proid);
		super.setTRID(this.trid);
	}	
	
	private static final String proid		= "FUC3275R";
	private static final String trid		= "UCDX";
	private String rURL						= "";

	// 입력
	private String JJ_P_JUMIN_NO = null;

	// 출력
	private String CC_CHANNEL = null;
	private String CC_UKEY = null;
	private String CC_PGMID = null;
	private String CC_PROC_GB = null;
	private String CC_FUN_KEY = null;
	private String CC_USER_GB = null;
	private String CC_USER_CD = null;
	private String CC_JIJUM_CD = null;
	private String CC_JIBU_CD = null;
	private String CC_PROTOCOL = null;
	private String CC_COND_CD = null;
	private String CC_LAST_FLAG = null;
	private String CC_CURSOR_MAP = null;
	private String CC_CURSOR_IDX = null;
	private String CC_MESSAGE_CD = null;
	private String HC_MESSAGE_NM = null;
	private String CC_SYS_ERR = null;
	private String CC_FILLER = null;
	private String HJ_P_GOGEK_NAME = null;
//	private String JJ_P_JUMIN_NO = null;
	
	private List<Map<String,Object>> JJ_P_CONT_O = null;

//	private String[] JJ_P_POLI_NO_O = new String[0]; // 10
//	private String[] JJ_P_NAPIP_PRM_O = new String[0]; // 10
//	private String[] HJ_P_BUN_NAME_O = new String[0]; // 10
//	private String[] JJ_P_GYEYAK_YMD_O = new String[0]; // 10
//	private String[] JJ_P_YAKGWAN_GM_O = new String[0]; // 10
//	private String[] JJ_P_LAST_NAP_Y_O = new String[0]; // 10
//	private String[] JJ_P_LAST_NAP_M_O = new String[0]; // 10
//	private String[] JJ_P_NAPIP_YMD_O = new String[0]; // 10
//	private String[] JJ_P_DECHUL_YMD_O = new String[0]; // 10
	private String JJ_P_HAP_NAPIP_PRM = null;
	private String JJ_P_HAP_YAKGWAN_GM = null;
	private String UU_POLI_NO = null;
	private String UU_BESU_NO = null;
	
	public String getrURL() {
		return rURL;
	}
	public void setrURL(String rURL) {
		this.rURL = rURL;
	}
	public String getJJ_P_JUMIN_NO() {
		return JJ_P_JUMIN_NO;
	}
	public void setJJ_P_JUMIN_NO(String jJ_P_JUMIN_NO) {
		JJ_P_JUMIN_NO = jJ_P_JUMIN_NO;
	}
	public String getCC_CHANNEL() {
		return CC_CHANNEL;
	}
	public void setCC_CHANNEL(String cC_CHANNEL) {
		CC_CHANNEL = cC_CHANNEL;
	}
	public String getCC_UKEY() {
		return CC_UKEY;
	}
	public void setCC_UKEY(String cC_UKEY) {
		CC_UKEY = cC_UKEY;
	}
	public String getCC_PGMID() {
		return CC_PGMID;
	}
	public void setCC_PGMID(String cC_PGMID) {
		CC_PGMID = cC_PGMID;
	}
	public String getCC_PROC_GB() {
		return CC_PROC_GB;
	}
	public void setCC_PROC_GB(String cC_PROC_GB) {
		CC_PROC_GB = cC_PROC_GB;
	}
	public String getCC_FUN_KEY() {
		return CC_FUN_KEY;
	}
	public void setCC_FUN_KEY(String cC_FUN_KEY) {
		CC_FUN_KEY = cC_FUN_KEY;
	}
	public String getCC_USER_GB() {
		return CC_USER_GB;
	}
	public void setCC_USER_GB(String cC_USER_GB) {
		CC_USER_GB = cC_USER_GB;
	}
	public String getCC_USER_CD() {
		return CC_USER_CD;
	}
	public void setCC_USER_CD(String cC_USER_CD) {
		CC_USER_CD = cC_USER_CD;
	}
	public String getCC_JIJUM_CD() {
		return CC_JIJUM_CD;
	}
	public void setCC_JIJUM_CD(String cC_JIJUM_CD) {
		CC_JIJUM_CD = cC_JIJUM_CD;
	}
	public String getCC_JIBU_CD() {
		return CC_JIBU_CD;
	}
	public void setCC_JIBU_CD(String cC_JIBU_CD) {
		CC_JIBU_CD = cC_JIBU_CD;
	}
	public String getCC_PROTOCOL() {
		return CC_PROTOCOL;
	}
	public void setCC_PROTOCOL(String cC_PROTOCOL) {
		CC_PROTOCOL = cC_PROTOCOL;
	}
	public String getCC_COND_CD() {
		return CC_COND_CD;
	}
	public void setCC_COND_CD(String cC_COND_CD) {
		CC_COND_CD = cC_COND_CD;
	}
	public String getCC_LAST_FLAG() {
		return CC_LAST_FLAG;
	}
	public void setCC_LAST_FLAG(String cC_LAST_FLAG) {
		CC_LAST_FLAG = cC_LAST_FLAG;
	}
	public String getCC_CURSOR_MAP() {
		return CC_CURSOR_MAP;
	}
	public void setCC_CURSOR_MAP(String cC_CURSOR_MAP) {
		CC_CURSOR_MAP = cC_CURSOR_MAP;
	}
	public String getCC_CURSOR_IDX() {
		return CC_CURSOR_IDX;
	}
	public void setCC_CURSOR_IDX(String cC_CURSOR_IDX) {
		CC_CURSOR_IDX = cC_CURSOR_IDX;
	}
	public String getCC_MESSAGE_CD() {
		return CC_MESSAGE_CD;
	}
	public void setCC_MESSAGE_CD(String cC_MESSAGE_CD) {
		CC_MESSAGE_CD = cC_MESSAGE_CD;
	}
	public String getHC_MESSAGE_NM() {
		return HC_MESSAGE_NM;
	}
	public void setHC_MESSAGE_NM(String hC_MESSAGE_NM) {
		HC_MESSAGE_NM = hC_MESSAGE_NM;
	}
	public String getCC_SYS_ERR() {
		return CC_SYS_ERR;
	}
	public void setCC_SYS_ERR(String cC_SYS_ERR) {
		CC_SYS_ERR = cC_SYS_ERR;
	}
	public String getCC_FILLER() {
		return CC_FILLER;
	}
	public void setCC_FILLER(String cC_FILLER) {
		CC_FILLER = cC_FILLER;
	}
	public String getHJ_P_GOGEK_NAME() {
		return HJ_P_GOGEK_NAME;
	}
	public void setHJ_P_GOGEK_NAME(String hJ_P_GOGEK_NAME) {
		HJ_P_GOGEK_NAME = hJ_P_GOGEK_NAME;
	}
	public String getJJ_P_HAP_NAPIP_PRM() {
		return JJ_P_HAP_NAPIP_PRM;
	}
	public void setJJ_P_HAP_NAPIP_PRM(String jJ_P_HAP_NAPIP_PRM) {
		JJ_P_HAP_NAPIP_PRM = jJ_P_HAP_NAPIP_PRM;
	}
	public String getJJ_P_HAP_YAKGWAN_GM() {
		return JJ_P_HAP_YAKGWAN_GM;
	}
	public void setJJ_P_HAP_YAKGWAN_GM(String jJ_P_HAP_YAKGWAN_GM) {
		JJ_P_HAP_YAKGWAN_GM = jJ_P_HAP_YAKGWAN_GM;
	}
	public String getUU_POLI_NO() {
		return UU_POLI_NO;
	}
	public void setUU_POLI_NO(String uU_POLI_NO) {
		UU_POLI_NO = uU_POLI_NO;
	}
	public String getUU_BESU_NO() {
		return UU_BESU_NO;
	}
	public void setUU_BESU_NO(String uU_BESU_NO) {
		UU_BESU_NO = uU_BESU_NO;
	}
	public static String getProid() {
		return proid;
	}
	public static String getTrid() {
		return trid;
	}
	public List<Map<String, Object>> getJJ_P_CONT_O() {
		return JJ_P_CONT_O;
	}
	public void setJJ_P_CONT_O(List<Map<String, Object>> jJ_P_CONT_O) {
		JJ_P_CONT_O = jJ_P_CONT_O;
	}
}
