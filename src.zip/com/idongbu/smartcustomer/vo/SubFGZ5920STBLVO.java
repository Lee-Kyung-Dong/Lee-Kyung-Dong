package com.idongbu.smartcustomer.vo;

public class SubFGZ5920STBLVO {
	public String LK_BUNNAP_CNT  = null;
	public String LK_BANG_CD     = null;
	public String LK_NAPIP_YM    = null;
	public String LK_YUNG_YMD    = null;
	public String LK_YUNG_PRM    = null;

	public String getLK_BUNNAP_CNT() {
		return LK_BUNNAP_CNT;
	}
	public void setLK_BUNNAP_CNT(String lK_BUNNAP_CNT) {
		LK_BUNNAP_CNT = lK_BUNNAP_CNT;
	}
	public String getLK_BANG_CD() {
		return LK_BANG_CD;
	}
	public void setLK_BANG_CD(String lK_BANG_CD) {
		LK_BANG_CD = lK_BANG_CD;
	}
	public String getLK_NAPIP_YM() {
		return LK_NAPIP_YM;
	}
	public void setLK_NAPIP_YM(String lK_NAPIP_YM) {
		LK_NAPIP_YM = lK_NAPIP_YM;
	}
	public String getLK_YUNG_YMD() {
		return LK_YUNG_YMD;
	}
	public void setLK_YUNG_YMD(String lK_YUNG_YMD) {
		LK_YUNG_YMD = lK_YUNG_YMD;
	}
	public String getLK_YUNG_PRM() {
		return LK_YUNG_PRM;
	}
	public void setLK_YUNG_PRM(String lK_YUNG_PRM) {
		LK_YUNG_PRM = lK_YUNG_PRM;
	}

}
