package com.idongbu.smartcustomer.vo;

import java.util.List;
import java.util.Map;

import com.idongbu.common.vo.CMMVO;

public class ReOneCarMobileVO extends CMMVO {

	private String DAMBO_NM	       = ""; // 담보
	private String MOKJUK_SEQ      = ""; // 서열
	private int GONGIM_AMT         = 0;  // 공임/합의금
	private int BUPUM_AMT          = 0;  // 부품/치료비
	private String PIHEMUL_NM      = ""; // 피해자/피해물
	private String HAPGYE_AMT      = ""; // 계
	private String JONGKYUL_YMD    = ""; // 종결일
	private String DAMDANGJA       = ""; // 담당자
	private String TEL_NO          = ""; // 연락처
	private String BOSANG_SEQ      = ""; // 자차일 경우 서열
	private String JUBSU_NO	       = ""; // 접수번호
	private String IsIndex09	   = ""; // EDMS > 세부업무코드
	                                     
	// 사고조사                          
	private String SAGO_TYPE_NAME  = ""; // 사고유형
	private String GWASIL_NAME	   = ""; // 과실명
	private String POLICE_SINGO	   = ""; // 경찰서 신고여부
	private String SAGO_CONT	   = ""; // 사고조사자 의견	
	                                     
	// 보상진행                          
	private String SURICHEO_NM	   = ""; // 병원/수리처
	private String SONHE_JUNGDO_NM = ""; // 손해 or 부당급수
	private String JINHENG_GB	   = ""; // 진행상태
	private String PL_AMT		   = ""; // 결정보험금
	
	private String SAGO_YMD        = ""; // 사고일시
	
	// 서류제출
	private String reg_dt		   = ""; // 제출일자
	private String cnt			   = ""; // 전송건수
	
	public String getDAMBO_NM() {
		return DAMBO_NM;
	}
	public void setDAMBO_NM(String dAMBO_NM) {
		DAMBO_NM = dAMBO_NM;
	}
	public String getMOKJUK_SEQ() {
		return MOKJUK_SEQ;
	}
	public void setMOKJUK_SEQ(String mOKJUK_SEQ) {
		MOKJUK_SEQ = mOKJUK_SEQ;
	}
	public int getGONGIM_AMT() {
		return GONGIM_AMT;
	}
	public void setGONGIM_AMT(int gONGIM_AMT) {
		GONGIM_AMT = gONGIM_AMT;
	}
	public int getBUPUM_AMT() {
		return BUPUM_AMT;
	}
	public void setBUPUM_AMT(int bUPUM_AMT) {
		BUPUM_AMT = bUPUM_AMT;
	}
	public String getPIHEMUL_NM() {
		return PIHEMUL_NM;
	}
	public void setPIHEMUL_NM(String pIHEMUL_NM) {
		PIHEMUL_NM = pIHEMUL_NM;
	}
	public String getHAPGYE_AMT() {
		return HAPGYE_AMT;
	}
	public void setHAPGYE_AMT(String hAPGYE_AMT) {
		HAPGYE_AMT = hAPGYE_AMT;
	}
	public String getJONGKYUL_YMD() {
		return JONGKYUL_YMD;
	}
	public void setJONGKYUL_YMD(String jONGKYUL_YMD) {
		JONGKYUL_YMD = jONGKYUL_YMD;
	}
	public String getDAMDANGJA() {
		return DAMDANGJA;
	}
	public void setDAMDANGJA(String dAMDANGJA) {
		DAMDANGJA = dAMDANGJA;
	}
	public String getTEL_NO() {
		return TEL_NO;
	}
	public void setTEL_NO(String tEL_NO) {
		TEL_NO = tEL_NO;
	}
	public String getBOSANG_SEQ() {
		return BOSANG_SEQ;
	}
	public void setBOSANG_SEQ(String bOSANG_SEQ) {
		BOSANG_SEQ = bOSANG_SEQ;
	}
	public String getJUBSU_NO() {
		return JUBSU_NO;
	}
	public void setJUBSU_NO(String jUBSU_NO) {
		JUBSU_NO = jUBSU_NO;
	}
	public String getIsIndex09() {
		return IsIndex09;
	}
	public void setIsIndex09(String isIndex09) {
		IsIndex09 = isIndex09;
	}
	public String getSAGO_TYPE_NAME() {
		return SAGO_TYPE_NAME;
	}
	public void setSAGO_TYPE_NAME(String sAGO_TYPE_NAME) {
		SAGO_TYPE_NAME = sAGO_TYPE_NAME;
	}
	public String getGWASIL_NAME() {
		return GWASIL_NAME;
	}
	public void setGWASIL_NAME(String gWASIL_NAME) {
		GWASIL_NAME = gWASIL_NAME;
	}
	public String getPOLICE_SINGO() {
		return POLICE_SINGO;
	}
	public void setPOLICE_SINGO(String pOLICE_SINGO) {
		POLICE_SINGO = pOLICE_SINGO;
	}
	public String getSAGO_CONT() {
		return SAGO_CONT;
	}
	public void setSAGO_CONT(String sAGO_CONT) {
		SAGO_CONT = sAGO_CONT;
	}
	public String getSURICHEO_NM() {
		return SURICHEO_NM;
	}
	public void setSURICHEO_NM(String sURICHEO_NM) {
		SURICHEO_NM = sURICHEO_NM;
	}
	public String getSONHE_JUNGDO_NM() {
		return SONHE_JUNGDO_NM;
	}
	public void setSONHE_JUNGDO_NM(String sONHE_JUNGDO_NM) {
		SONHE_JUNGDO_NM = sONHE_JUNGDO_NM;
	}
	public String getJINHENG_GB() {
		return JINHENG_GB;
	}
	public void setJINHENG_GB(String jINHENG_GB) {
		JINHENG_GB = jINHENG_GB;
	}
	public String getPL_AMT() {
		return PL_AMT;
	}
	public void setPL_AMT(String pL_AMT) {
		PL_AMT = pL_AMT;
	}	
	public String getSAGO_YMD() {
		return SAGO_YMD;
	}
	public void setSAGO_YMD(String sAGO_YMD) {
		SAGO_YMD = sAGO_YMD;
	}
	public String getReg_dt() {
		return reg_dt;
	}
	public void setReg_dt(String reg_dt) {
		this.reg_dt = reg_dt;
	}
	public String getCnt() {
		return cnt;
	}
	public void setCnt(String cnt) {
		this.cnt = cnt;
	}	
}
