package com.idongbu.smartcustomer.vo;

public class AutoIcheTableVO {
	public  int  	NOSEQ                       ;     
	public  String  STOCK_SEQ                   = null;     
	public  String  LAST_PAY_MONTH              = null;     
	public  String  BRANC_CD                    = null;     
	public  String  HANDLERS_NAME               = null;     
	public  String  SECU_CD                     = null;     
	public  String  BEF_BILCL_METH_NAME         = null;     
	public  String  BEF_ACC_NO                  = null;     
	public  String  BEF_DPOSR_INHNO             = null;     
	public  String  BEF_TRANSFER_DAY            = null;     
	public  String  AFTR_BILCLMETH_CD           = null;     
	public  String  AFTR_BANK_CD                = null;     
	public  String  AFTR_CTR_RELTN              = null;     
	public  String  AFTR_DPOSR_FRNT_TEL_NO      = null;     
	public  String  AFTR_INIT_MONTH             = null;     
	public  String  MSG_NAME                    = null;     
	public  int  SEQ_NO                         ;
	public  String  CUST_NAME                   = null;
	public  String  LAST_PAY_TIME_CNT           = null;
	public  String  HANDLERS_CD                 = null;
	public  String  BILCL_METH_TEXT             = null;
	public  String  SECU_NAME                   = null;
	public  String  BEF_PARTY_HANDL_PAMET_APPLY = null;
	public  String  BEF_CTR_RELTN_CD            = null;
	public  String  BEF_DPOSR_TEL_AREA_NO       = null;
	public  String  BEF_INIT_YY                 = null;
	public  String  AFTR_BILCLMETH_NAME         = null;
	public  String  AFTR_BANK_NAME              = null;
	public  String  AFTR_DPOSR_NAME             = null;
	public  String  AFTR_DPOSR_AFTR_TEL_NO      = null;
	public  String  AFTR_INIT_CNT               = null;
	public  String  ERR_CD                      = null;
	public  String  NAME                        = null;
	public  String  CUST_INHAB_NO               = null;
	public  String  PAY_METH_NAME               = null;
	public  String  BSTOR_NAME                  = null;
	public  String  SUBS_TYPE_NAME              = null;
	public  String  STPLT_LOAN_YN               = null;
	public  String  BEF_BANK_CD                 = null;
	public  String  BEF_CTR_RELTN               = null;
	public  String  BEF_DPOSR_TEL_ACOFI_NO      = null;
	public  String  BEF_INIT_MON                = null;
	public  String  PARTY_HANDL_PAMET_APPLY_YN  = null;
	public  String  AFTR_ACC_NO                 = null;
	public  String  AFTR_DPOSR_INHNO            = null;
	public  String  AFTR_TRANSFER_DAY           = null;
	public  String  AR_STTUS_CD                 = null;
	public  String  APPLY_YN                    = null;             
	public  String  INHAB_NO                    = null;
	public  String  LAST_PAY_YY                 = null;
	public  String  BSTOR_CD                    = null;
	public  String  BRANC_NAME                  = null;
	public  String  PARTY_HANDL_NO              = null;
	public  String  BEF_BILCL_METH_CD           = null;
	public  String  BEF_BANK_NAME               = null;
	public  String  BEF_DPOSR_NAME              = null;
	public  String  BEF_DPOSR_TEL_NUM_NO        = null;
	public  String  BEF_INIT_CNT                = null;
	public  String  HJ_DANCHE_NAME              = null;
	public  String  AFTR_CTR_RELTN_CD           = null;
	public  String  AFTR_DPOSR_AREA_TEL_NO      = null;
	public  String  AFTR_INIT_YY                = null;
	public  String  MSG_CD                      = null;
	public  String  PPLY_YN						= null;
	public  String  TRANSFER_COND_CD			= null;
	public  String  BILCL_METH_CD				= null;
	public  String  BANK_CD						= null;
	public  String  BANK_NAME                   = null;
	public  String  ACC_NO                      = null;
	public  String  RELTN_CD                    = null;
	public  String  RELTN_NAME                  = null;
	public  String  DPOSR_NAME                  = null;
	public  String  DPOSR_INHAB_NO              = null;
	public  String  DPOSR_TEL_NO                = null;
	public  String  TRANSFER_DD                 = null; 
	public  String  NEXT_CNT                    = null; 
	public  String  TRANSFER_YY                 = null; 
	public  String  TRANSFER_MM                 = null; 
	public  String  NEXT_1_CNT                  = null;
	public  String  OCCUR_DAY_TIME              = null;
	
	public int getNOSEQ() {
		return NOSEQ;
	}
	public void setNOSEQ(int nOSEQ) {
		NOSEQ = nOSEQ;
	}
	public String getLAST_PAY_MONTH() {
		return LAST_PAY_MONTH;
	}
	public void setLAST_PAY_MONTH(String lAST_PAY_MONTH) {
		LAST_PAY_MONTH = lAST_PAY_MONTH;
	}
	public String getBRANC_CD() {
		return BRANC_CD;
	}
	public void setBRANC_CD(String bRANC_CD) {
		BRANC_CD = bRANC_CD;
	}
	public String getHANDLERS_NAME() {
		return HANDLERS_NAME;
	}
	public void setHANDLERS_NAME(String hANDLERS_NAME) {
		HANDLERS_NAME = hANDLERS_NAME;
	}
	public String getSECU_CD() {
		return SECU_CD;
	}
	public void setSECU_CD(String sECU_CD) {
		SECU_CD = sECU_CD;
	}
	public String getBEF_BILCL_METH_NAME() {
		return BEF_BILCL_METH_NAME;
	}
	public void setBEF_BILCL_METH_NAME(String bEF_BILCL_METH_NAME) {
		BEF_BILCL_METH_NAME = bEF_BILCL_METH_NAME;
	}
	public String getBEF_ACC_NO() {
		return BEF_ACC_NO;
	}
	public void setBEF_ACC_NO(String bEF_ACC_NO) {
		BEF_ACC_NO = bEF_ACC_NO;
	}
	public String getBEF_DPOSR_INHNO() {
		return BEF_DPOSR_INHNO;
	}
	public void setBEF_DPOSR_INHNO(String bEF_DPOSR_INHNO) {
		BEF_DPOSR_INHNO = bEF_DPOSR_INHNO;
	}
	public String getBEF_TRANSFER_DAY() {
		return BEF_TRANSFER_DAY;
	}
	public void setBEF_TRANSFER_DAY(String bEF_TRANSFER_DAY) {
		BEF_TRANSFER_DAY = bEF_TRANSFER_DAY;
	}
	public String getAFTR_BILCLMETH_CD() {
		return AFTR_BILCLMETH_CD;
	}
	public void setAFTR_BILCLMETH_CD(String aFTR_BILCLMETH_CD) {
		AFTR_BILCLMETH_CD = aFTR_BILCLMETH_CD;
	}
	public String getAFTR_BANK_CD() {
		return AFTR_BANK_CD;
	}
	public void setAFTR_BANK_CD(String aFTR_BANK_CD) {
		AFTR_BANK_CD = aFTR_BANK_CD;
	}
	public String getAFTR_CTR_RELTN() {
		return AFTR_CTR_RELTN;
	}
	public void setAFTR_CTR_RELTN(String aFTR_CTR_RELTN) {
		AFTR_CTR_RELTN = aFTR_CTR_RELTN;
	}
	public String getAFTR_DPOSR_FRNT_TEL_NO() {
		return AFTR_DPOSR_FRNT_TEL_NO;
	}
	public void setAFTR_DPOSR_FRNT_TEL_NO(String aFTR_DPOSR_FRNT_TEL_NO) {
		AFTR_DPOSR_FRNT_TEL_NO = aFTR_DPOSR_FRNT_TEL_NO;
	}
	public String getAFTR_INIT_MONTH() {
		return AFTR_INIT_MONTH;
	}
	public void setAFTR_INIT_MONTH(String aFTR_INIT_MONTH) {
		AFTR_INIT_MONTH = aFTR_INIT_MONTH;
	}
	public String getMSG_NAME() {
		return MSG_NAME;
	}
	public void setMSG_NAME(String mSG_NAME) {
		MSG_NAME = mSG_NAME;
	}
	public String getCUST_NAME() {
		return CUST_NAME;
	}
	public void setCUST_NAME(String cUST_NAME) {
		CUST_NAME = cUST_NAME;
	}
	public String getLAST_PAY_TIME_CNT() {
		return LAST_PAY_TIME_CNT;
	}
	public void setLAST_PAY_TIME_CNT(String lAST_PAY_TIME_CNT) {
		LAST_PAY_TIME_CNT = lAST_PAY_TIME_CNT;
	}
	public String getHANDLERS_CD() {
		return HANDLERS_CD;
	}
	public void setHANDLERS_CD(String hANDLERS_CD) {
		HANDLERS_CD = hANDLERS_CD;
	}
	public String getBILCL_METH_TEXT() {
		return BILCL_METH_TEXT;
	}
	public void setBILCL_METH_TEXT(String bILCL_METH_TEXT) {
		BILCL_METH_TEXT = bILCL_METH_TEXT;
	}
	public String getSECU_NAME() {
		return SECU_NAME;
	}
	public void setSECU_NAME(String sECU_NAME) {
		SECU_NAME = sECU_NAME;
	}
	public String getBEF_PARTY_HANDL_PAMET_APPLY() {
		return BEF_PARTY_HANDL_PAMET_APPLY;
	}
	public void setBEF_PARTY_HANDL_PAMET_APPLY(String bEF_PARTY_HANDL_PAMET_APPLY) {
		BEF_PARTY_HANDL_PAMET_APPLY = bEF_PARTY_HANDL_PAMET_APPLY;
	}
	public String getBEF_CTR_RELTN_CD() {
		return BEF_CTR_RELTN_CD;
	}
	public void setBEF_CTR_RELTN_CD(String bEF_CTR_RELTN_CD) {
		BEF_CTR_RELTN_CD = bEF_CTR_RELTN_CD;
	}
	public String getBEF_DPOSR_TEL_AREA_NO() {
		return BEF_DPOSR_TEL_AREA_NO;
	}
	public void setBEF_DPOSR_TEL_AREA_NO(String bEF_DPOSR_TEL_AREA_NO) {
		BEF_DPOSR_TEL_AREA_NO = bEF_DPOSR_TEL_AREA_NO;
	}
	public String getBEF_INIT_YY() {
		return BEF_INIT_YY;
	}
	public void setBEF_INIT_YY(String bEF_INIT_YY) {
		BEF_INIT_YY = bEF_INIT_YY;
	}
	public String getAFTR_BILCLMETH_NAME() {
		return AFTR_BILCLMETH_NAME;
	}
	public void setAFTR_BILCLMETH_NAME(String aFTR_BILCLMETH_NAME) {
		AFTR_BILCLMETH_NAME = aFTR_BILCLMETH_NAME;
	}
	public String getAFTR_BANK_NAME() {
		return AFTR_BANK_NAME;
	}
	public void setAFTR_BANK_NAME(String aFTR_BANK_NAME) {
		AFTR_BANK_NAME = aFTR_BANK_NAME;
	}
	public String getAFTR_DPOSR_NAME() {
		return AFTR_DPOSR_NAME;
	}
	public void setAFTR_DPOSR_NAME(String aFTR_DPOSR_NAME) {
		AFTR_DPOSR_NAME = aFTR_DPOSR_NAME;
	}
	public String getAFTR_DPOSR_AFTR_TEL_NO() {
		return AFTR_DPOSR_AFTR_TEL_NO;
	}
	public void setAFTR_DPOSR_AFTR_TEL_NO(String aFTR_DPOSR_AFTR_TEL_NO) {
		AFTR_DPOSR_AFTR_TEL_NO = aFTR_DPOSR_AFTR_TEL_NO;
	}
	public String getAFTR_INIT_CNT() {
		return AFTR_INIT_CNT;
	}
	public void setAFTR_INIT_CNT(String aFTR_INIT_CNT) {
		AFTR_INIT_CNT = aFTR_INIT_CNT;
	}
	public String getERR_CD() {
		return ERR_CD;
	}
	public void setERR_CD(String eRR_CD) {
		ERR_CD = eRR_CD;
	}
	public String getNAME() {
		return NAME;
	}
	public void setNAME(String nAME) {
		NAME = nAME;
	}
	public String getCUST_INHAB_NO() {
		return CUST_INHAB_NO;
	}
	public void setCUST_INHAB_NO(String cUST_INHAB_NO) {
		CUST_INHAB_NO = cUST_INHAB_NO;
	}
	public String getPAY_METH_NAME() {
		return PAY_METH_NAME;
	}
	public void setPAY_METH_NAME(String pAY_METH_NAME) {
		PAY_METH_NAME = pAY_METH_NAME;
	}
	public String getBSTOR_NAME() {
		return BSTOR_NAME;
	}
	public void setBSTOR_NAME(String bSTOR_NAME) {
		BSTOR_NAME = bSTOR_NAME;
	}
	public String getSUBS_TYPE_NAME() {
		return SUBS_TYPE_NAME;
	}
	public void setSUBS_TYPE_NAME(String sUBS_TYPE_NAME) {
		SUBS_TYPE_NAME = sUBS_TYPE_NAME;
	}
	public String getSTPLT_LOAN_YN() {
		return STPLT_LOAN_YN;
	}
	public void setSTPLT_LOAN_YN(String sTPLT_LOAN_YN) {
		STPLT_LOAN_YN = sTPLT_LOAN_YN;
	}
	public String getBEF_BANK_CD() {
		return BEF_BANK_CD;
	}
	public void setBEF_BANK_CD(String bEF_BANK_CD) {
		BEF_BANK_CD = bEF_BANK_CD;
	}
	public String getBEF_CTR_RELTN() {
		return BEF_CTR_RELTN;
	}
	public void setBEF_CTR_RELTN(String bEF_CTR_RELTN) {
		BEF_CTR_RELTN = bEF_CTR_RELTN;
	}
	public String getBEF_DPOSR_TEL_ACOFI_NO() {
		return BEF_DPOSR_TEL_ACOFI_NO;
	}
	public void setBEF_DPOSR_TEL_ACOFI_NO(String bEF_DPOSR_TEL_ACOFI_NO) {
		BEF_DPOSR_TEL_ACOFI_NO = bEF_DPOSR_TEL_ACOFI_NO;
	}
	public String getBEF_INIT_MON() {
		return BEF_INIT_MON;
	}
	public void setBEF_INIT_MON(String bEF_INIT_MON) {
		BEF_INIT_MON = bEF_INIT_MON;
	}
	public String getPARTY_HANDL_PAMET_APPLY_YN() {
		return PARTY_HANDL_PAMET_APPLY_YN;
	}
	public void setPARTY_HANDL_PAMET_APPLY_YN(String pARTY_HANDL_PAMET_APPLY_YN) {
		PARTY_HANDL_PAMET_APPLY_YN = pARTY_HANDL_PAMET_APPLY_YN;
	}
	public String getAFTR_ACC_NO() {
		return AFTR_ACC_NO;
	}
	public void setAFTR_ACC_NO(String aFTR_ACC_NO) {
		AFTR_ACC_NO = aFTR_ACC_NO;
	}
	public String getAFTR_DPOSR_INHNO() {
		return AFTR_DPOSR_INHNO;
	}
	public void setAFTR_DPOSR_INHNO(String aFTR_DPOSR_INHNO) {
		AFTR_DPOSR_INHNO = aFTR_DPOSR_INHNO;
	}
	public String getAFTR_TRANSFER_DAY() {
		return AFTR_TRANSFER_DAY;
	}
	public void setAFTR_TRANSFER_DAY(String aFTR_TRANSFER_DAY) {
		AFTR_TRANSFER_DAY = aFTR_TRANSFER_DAY;
	}
	public String getAR_STTUS_CD() {
		return AR_STTUS_CD;
	}
	public void setAR_STTUS_CD(String aR_STTUS_CD) {
		AR_STTUS_CD = aR_STTUS_CD;
	}
	public String getAPPLY_YN() {
		return APPLY_YN;
	}
	public void setAPPLY_YN(String aPPLY_YN) {
		APPLY_YN = aPPLY_YN;
	}
	public String getINHAB_NO() {
		return INHAB_NO;
	}
	public void setINHAB_NO(String iNHAB_NO) {
		INHAB_NO = iNHAB_NO;
	}
	public String getLAST_PAY_YY() {
		return LAST_PAY_YY;
	}
	public void setLAST_PAY_YY(String lAST_PAY_YY) {
		LAST_PAY_YY = lAST_PAY_YY;
	}
	public String getBSTOR_CD() {
		return BSTOR_CD;
	}
	public void setBSTOR_CD(String bSTOR_CD) {
		BSTOR_CD = bSTOR_CD;
	}
	public String getBRANC_NAME() {
		return BRANC_NAME;
	}
	public void setBRANC_NAME(String bRANC_NAME) {
		BRANC_NAME = bRANC_NAME;
	}
	public String getPARTY_HANDL_NO() {
		return PARTY_HANDL_NO;
	}
	public void setPARTY_HANDL_NO(String pARTY_HANDL_NO) {
		PARTY_HANDL_NO = pARTY_HANDL_NO;
	}
	public String getBEF_BILCL_METH_CD() {
		return BEF_BILCL_METH_CD;
	}
	public void setBEF_BILCL_METH_CD(String bEF_BILCL_METH_CD) {
		BEF_BILCL_METH_CD = bEF_BILCL_METH_CD;
	}
	public String getBEF_BANK_NAME() {
		return BEF_BANK_NAME;
	}
	public void setBEF_BANK_NAME(String bEF_BANK_NAME) {
		BEF_BANK_NAME = bEF_BANK_NAME;
	}
	public String getBEF_DPOSR_NAME() {
		return BEF_DPOSR_NAME;
	}
	public void setBEF_DPOSR_NAME(String bEF_DPOSR_NAME) {
		BEF_DPOSR_NAME = bEF_DPOSR_NAME;
	}
	public String getBEF_DPOSR_TEL_NUM_NO() {
		return BEF_DPOSR_TEL_NUM_NO;
	}
	public void setBEF_DPOSR_TEL_NUM_NO(String bEF_DPOSR_TEL_NUM_NO) {
		BEF_DPOSR_TEL_NUM_NO = bEF_DPOSR_TEL_NUM_NO;
	}
	public String getBEF_INIT_CNT() {
		return BEF_INIT_CNT;
	}
	public void setBEF_INIT_CNT(String bEF_INIT_CNT) {
		BEF_INIT_CNT = bEF_INIT_CNT;
	}
	public String getHJ_DANCHE_NAME() {
		return HJ_DANCHE_NAME;
	}
	public void setHJ_DANCHE_NAME(String hJ_DANCHE_NAME) {
		HJ_DANCHE_NAME = hJ_DANCHE_NAME;
	}
	public String getAFTR_CTR_RELTN_CD() {
		return AFTR_CTR_RELTN_CD;
	}
	public void setAFTR_CTR_RELTN_CD(String aFTR_CTR_RELTN_CD) {
		AFTR_CTR_RELTN_CD = aFTR_CTR_RELTN_CD;
	}
	public String getAFTR_DPOSR_AREA_TEL_NO() {
		return AFTR_DPOSR_AREA_TEL_NO;
	}
	public void setAFTR_DPOSR_AREA_TEL_NO(String aFTR_DPOSR_AREA_TEL_NO) {
		AFTR_DPOSR_AREA_TEL_NO = aFTR_DPOSR_AREA_TEL_NO;
	}
	public String getAFTR_INIT_YY() {
		return AFTR_INIT_YY;
	}
	public void setAFTR_INIT_YY(String aFTR_INIT_YY) {
		AFTR_INIT_YY = aFTR_INIT_YY;
	}
	public String getMSG_CD() {
		return MSG_CD;
	}
	public void setMSG_CD(String mSG_CD) {
		MSG_CD = mSG_CD;
	}
	public String getSTOCK_SEQ() {
		return STOCK_SEQ;
	}
	public void setSTOCK_SEQ(String sTOCK_SEQ) {
		STOCK_SEQ = sTOCK_SEQ;
	}
	public int getSEQ_NO() {
		return SEQ_NO;
	}
	public void setSEQ_NO(int sEQ_NO) {
		SEQ_NO = sEQ_NO;
	}
	public String getPPLY_YN() {
		return PPLY_YN;
	}
	public void setPPLY_YN(String pPLY_YN) {
		PPLY_YN = pPLY_YN;
	}
	public String getTRANSFER_COND_CD() {
		return TRANSFER_COND_CD;
	}
	public void setTRANSFER_COND_CD(String tRANSFER_COND_CD) {
		TRANSFER_COND_CD = tRANSFER_COND_CD;
	}
	public String getBILCL_METH_CD() {
		return BILCL_METH_CD;
	}
	public void setBILCL_METH_CD(String bILCL_METH_CD) {
		BILCL_METH_CD = bILCL_METH_CD;
	}
	public String getBANK_CD() {
		return BANK_CD;
	}
	public void setBANK_CD(String bANK_CD) {
		BANK_CD = bANK_CD;
	}
	public String getBANK_NAME() {
		return BANK_NAME;
	}
	public void setBANK_NAME(String bANK_NAME) {
		BANK_NAME = bANK_NAME;
	}
	public String getACC_NO() {
		return ACC_NO;
	}
	public void setACC_NO(String aCC_NO) {
		ACC_NO = aCC_NO;
	}
	public String getRELTN_CD() {
		return RELTN_CD;
	}
	public void setRELTN_CD(String rELTN_CD) {
		RELTN_CD = rELTN_CD;
	}
	public String getRELTN_NAME() {
		return RELTN_NAME;
	}
	public void setRELTN_NAME(String rELTN_NAME) {
		RELTN_NAME = rELTN_NAME;
	}
	public String getDPOSR_NAME() {
		return DPOSR_NAME;
	}
	public void setDPOSR_NAME(String dPOSR_NAME) {
		DPOSR_NAME = dPOSR_NAME;
	}
	public String getDPOSR_INHAB_NO() {
		return DPOSR_INHAB_NO;
	}
	public void setDPOSR_INHAB_NO(String dPOSR_INHAB_NO) {
		DPOSR_INHAB_NO = dPOSR_INHAB_NO;
	}
	public String getDPOSR_TEL_NO() {
		return DPOSR_TEL_NO;
	}
	public void setDPOSR_TEL_NO(String dPOSR_TEL_NO) {
		DPOSR_TEL_NO = dPOSR_TEL_NO;
	}
	public String getNEXT_1_CNT() {
		return NEXT_1_CNT;
	}
	public void setNEXT_1_CNT(String nEXT_1_CNT) {
		NEXT_1_CNT = nEXT_1_CNT;
	}
	public String getOCCUR_DAY_TIME() {
		return OCCUR_DAY_TIME;
	}
	public void setOCCUR_DAY_TIME(String oCCUR_DAY_TIME) {
		OCCUR_DAY_TIME = oCCUR_DAY_TIME;
	}
	public String getTRANSFER_DD() {
		return TRANSFER_DD;
	}
	public void setTRANSFER_DD(String tRANSFER_DD) {
		TRANSFER_DD = tRANSFER_DD;
	}
	public String getNEXT_CNT() {
		return NEXT_CNT;
	}
	public void setNEXT_CNT(String nEXT_CNT) {
		NEXT_CNT = nEXT_CNT;
	}
	public String getTRANSFER_YY() {
		return TRANSFER_YY;
	}
	public void setTRANSFER_YY(String tRANSFER_YY) {
		TRANSFER_YY = tRANSFER_YY;
	}
	public String getTRANSFER_MM() {
		return TRANSFER_MM;
	}
	public void setTRANSFER_MM(String tRANSFER_MM) {
		TRANSFER_MM = tRANSFER_MM;
	}
}
