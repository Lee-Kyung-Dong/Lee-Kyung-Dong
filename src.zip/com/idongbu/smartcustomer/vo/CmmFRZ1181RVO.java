package com.idongbu.smartcustomer.vo;

import java.util.List;
import java.util.Map;

import com.idongbu.common.vo.CMMVO;

//사고조회
public class CmmFRZ1181RVO extends CMMVO {
	
	public CmmFRZ1181RVO() {
		super.setPGMID(this.proid);
		super.setTRID(this.trid);
	}
	
	private static final String proid         = "FRZ1181R";
	private static final String trid	      = "RZF1";
	private String rURL				          = "";
                                              
	// 출력                                   
	private String LK_TRID		              = null; // TR 아이디
	private String LK_FLAG		              = null; // 플래그
	private String LK_NT_CD		              = null; // 응답코드
	private String LK_RSP_TIME		          = null; // 응답시간
	private String LK_COMP_GB		          = null; // 보상구분
	private String LK_COMP_CD		          = null; // 보상코드
	private String LK_FILLER		          = null; // 여분
	private String LK_USER_ID		          = null; // 사용자 아이디
	private String LK_PART_GB1		          = null; // 파트구분 1	
	private String LK_PART_GB2		          = null; // 파트구분 2
	private String LK_UPMU_CD1		          = null; // 업무구분 1
	private String LK_UPMU_CD2		          = null; // 업무구분 2
	private String LK_UPMU_CD3		          = null; // 업무구분 3
	private String LK_GULK_GB		          = null; // 결과구분
	private String LK_CM_FILLER		          = null; // 여분
	private String LK_RETURN_CD		          = null; // 결과코드
	private String LK_MSG_CD1		          = null; // 메시지코드 1
	private String LK_MSG_CD2		          = null; // 메세지코드 2
	private String H_LK_MESSAGE1		      = null; // 메세지 1
	private String H_LK_MESSAGE2		      = null; // 메세지 2
	private String LK_I_GOGEK_NO              = null; // 고객번호	

	/***********************************************
	 *      
	 * loopData 에 포함되는 필드
	 * 
	 * LK_SAGO_JUBSU_NO // 사고접수번호
	 * LK_CAR_NO        // 차량번호
	 * LK_SAGO_YMDSB    // 사고일시
	 * LK_JINHANG_GB    // 진행구분
	 * 
	 ***********************************************/	
	
	private List<Map<String,Object>> loopData = null;
	private String FILLER		              = null;
	
	public String getrURL() {
		return rURL;
	}
	public void setrURL(String rURL) {
		this.rURL = rURL;
	}
	public String getLK_TRID() {
		return LK_TRID;
	}
	public void setLK_TRID(String lK_TRID) {
		LK_TRID = lK_TRID;
	}
	public String getLK_FLAG() {
		return LK_FLAG;
	}
	public void setLK_FLAG(String lK_FLAG) {
		LK_FLAG = lK_FLAG;
	}
	public String getLK_NT_CD() {
		return LK_NT_CD;
	}
	public void setLK_NT_CD(String lK_NT_CD) {
		LK_NT_CD = lK_NT_CD;
	}
	public String getLK_RSP_TIME() {
		return LK_RSP_TIME;
	}
	public void setLK_RSP_TIME(String lK_RSP_TIME) {
		LK_RSP_TIME = lK_RSP_TIME;
	}
	public String getLK_COMP_GB() {
		return LK_COMP_GB;
	}
	public void setLK_COMP_GB(String lK_COMP_GB) {
		LK_COMP_GB = lK_COMP_GB;
	}
	public String getLK_COMP_CD() {
		return LK_COMP_CD;
	}
	public void setLK_COMP_CD(String lK_COMP_CD) {
		LK_COMP_CD = lK_COMP_CD;
	}
	public String getLK_FILLER() {
		return LK_FILLER;
	}
	public void setLK_FILLER(String lK_FILLER) {
		LK_FILLER = lK_FILLER;
	}
	public String getLK_USER_ID() {
		return LK_USER_ID;
	}
	public void setLK_USER_ID(String lK_USER_ID) {
		LK_USER_ID = lK_USER_ID;
	}
	public String getLK_PART_GB1() {
		return LK_PART_GB1;
	}
	public void setLK_PART_GB1(String lK_PART_GB1) {
		LK_PART_GB1 = lK_PART_GB1;
	}
	public String getLK_PART_GB2() {
		return LK_PART_GB2;
	}
	public void setLK_PART_GB2(String lK_PART_GB2) {
		LK_PART_GB2 = lK_PART_GB2;
	}
	public String getLK_UPMU_CD1() {
		return LK_UPMU_CD1;
	}
	public void setLK_UPMU_CD1(String lK_UPMU_CD1) {
		LK_UPMU_CD1 = lK_UPMU_CD1;
	}
	public String getLK_UPMU_CD2() {
		return LK_UPMU_CD2;
	}
	public void setLK_UPMU_CD2(String lK_UPMU_CD2) {
		LK_UPMU_CD2 = lK_UPMU_CD2;
	}
	public String getLK_UPMU_CD3() {
		return LK_UPMU_CD3;
	}
	public void setLK_UPMU_CD3(String lK_UPMU_CD3) {
		LK_UPMU_CD3 = lK_UPMU_CD3;
	}
	public String getLK_GULK_GB() {
		return LK_GULK_GB;
	}
	public void setLK_GULK_GB(String lK_GULK_GB) {
		LK_GULK_GB = lK_GULK_GB;
	}
	public String getLK_CM_FILLER() {
		return LK_CM_FILLER;
	}
	public void setLK_CM_FILLER(String lK_CM_FILLER) {
		LK_CM_FILLER = lK_CM_FILLER;
	}
	public String getLK_RETURN_CD() {
		return LK_RETURN_CD;
	}
	public void setLK_RETURN_CD(String lK_RETURN_CD) {
		LK_RETURN_CD = lK_RETURN_CD;
	}
	public String getLK_MSG_CD1() {
		return LK_MSG_CD1;
	}
	public void setLK_MSG_CD1(String lK_MSG_CD1) {
		LK_MSG_CD1 = lK_MSG_CD1;
	}
	public String getLK_MSG_CD2() {
		return LK_MSG_CD2;
	}
	public void setLK_MSG_CD2(String lK_MSG_CD2) {
		LK_MSG_CD2 = lK_MSG_CD2;
	}
	public String getH_LK_MESSAGE1() {
		return H_LK_MESSAGE1;
	}
	public void setH_LK_MESSAGE1(String h_LK_MESSAGE1) {
		H_LK_MESSAGE1 = h_LK_MESSAGE1;
	}
	public String getH_LK_MESSAGE2() {
		return H_LK_MESSAGE2;
	}
	public void setH_LK_MESSAGE2(String h_LK_MESSAGE2) {
		H_LK_MESSAGE2 = h_LK_MESSAGE2;
	}
	public String getLK_I_GOGEK_NO() {
		return LK_I_GOGEK_NO;
	}
	public void setLK_I_GOGEK_NO(String lK_I_GOGEK_NO) {
		LK_I_GOGEK_NO = lK_I_GOGEK_NO;
	}
	public List<Map<String, Object>> getLoopData() {
		return loopData;
	}
	public void setLoopData(List<Map<String, Object>> loopData) {
		this.loopData = loopData;
	}
	public String getFILLER() {
		return FILLER;
	}
	public void setFILLER(String fILLER) {
		FILLER = fILLER;
	}
	public static String getProid() {
		return proid;
	}
	public static String getTrid() {
		return trid;
	}	
}
