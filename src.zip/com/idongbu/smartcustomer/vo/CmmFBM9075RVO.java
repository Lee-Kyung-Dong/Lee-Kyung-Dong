package com.idongbu.smartcustomer.vo;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.idongbu.common.vo.CMMVO;

public class CmmFBM9075RVO extends CMMVO {
	
	public CmmFBM9075RVO() {
		super.setPGMID(this.proid);
		super.setTRID(this.trid);
	}

	private static final String proid		= "FBM9075R";
	private static final String trid		= "BMAZ";
	private String rURL						= "";
	
	private String COMM_CHANNEL;   
	private String COMM_UNIQUE_KEY;
	private String COMM_PGMID;     
	private String COMM_PROC_GB;   
	private String COMM_ACTION_KEY;
	private String COMM_USER_GB; 
	private String COMM_USER_ID;
	private String COMM_JIJUM_CD;
	private String COMM_JIBU_CD; 
	private String COMM_PROTOCOL;    
	private String COMM_COND_CD;     
	private String COMM_LAST_FLAG;   
	private String COMM_CURSOR_MAP;  
	private String COMM_CURSOR_IDX;  
	private String COMM_MESSAGE_CD;  
	private String H_COMM_MESSAGE_NM;
	private String COMM_ERR_NAME;
	private String COMM_ERR_TEXT;
	private String COMM_SYS_CODE;
	private String FILLER;

	private String ARS_LENGTH;    
	private String ARS_PROCESS_ID;
	private String SCR_K_CHURY_GB; 
	private String SCR_JUBSU_NO;   
	private String SCR_JUBSU_DATE; 
	private String SCR_SOS_GB;     
	private String H_SCR_CAR_NO;   
	private String SCR_JUMIN_NO;   
	private String SCR_POLI_NO;    
	private String H_SCR_YOCHUNGJA;        
	private String SCR_YOCHUNGJA_REL;      
	private String SCR_YOCHUNGJA1_AREA;    
	private String SCR_YOCHUNGJA1_GUK;     
	private String SCR_YOCHUNGJA1_PH;      
	private String SCR_YOCHUNGJA1_GB;      
	private String SCR_YOCHUNGJA2_AREA;    
	private String SCR_YOCHUNGJA2_GUK;     
	private String SCR_YOCHUNGJA2_PH;      
	private String SCR_YOCHUNGJA2_GB;      
	private String SCR_YOCHUNG_CD;         
	private String SCR_YOCHUNG_AREA_ZIP;   
	private String H_SCR_YOCHUNG_AREA_GITA;
	private String H_SCR_YOCHUNG_NOTE1;    
	private String H_SCR_YOCHUNG_NOTE2;    
	private String SCR_CO_CD;              
	private String H_SCR_CO_TEL_NM;        
	private String SCR_CO_TEL_DATE;        
	private String SCR_CO_TEL_JUBSUJA;     
	private String SCR_CHURY_CD;           
	private String SCR_CHURY_ENDCD;        
	private String SCR_YANGHE_CD;       
	private String SCR_YANGHE_SAWON;    
	private String SCR_YANGHE_DATE;     
	private String SCR_CHURY_GIGAN;     
	private String H_SCR_CHURY_NAME;    
	private String SCR_CHURY_GIBON_GM;  
	private String SCR_DOCHAK_DATE;     
	private String SCR_CHURY_DC_GB;     
	private String SCR_CHURY_DC_GM;     
	private String SCR_BUDAM_AMT;       
	private String SCR_CO_YN;           
	private String H_SCR_CHURY_CONT1;   
	private String H_SCR_CHURY_CONT2;   
	private String H_SCR_CHURY_CONT3;   
	private String H_SCR_CHURY_CONT4;   
	private String H_SCR_CHURY_CONT5;   
	private String H_SCR_CHURY_CONT6;   
	private String SCR_IPRYUK_SAWON_NO; 
	private String SCR_IPRYUK_DATE;     
	private String SCR_GUMSA_YMD;       
	private String SCR_TKYAK_GB;        
	private String H_SCR_PIBO_NM;       
	private String SCR_PIBO_CD;         
	private String SCR_BJ_CD;           
	private String SCR_CAR_CD;          
	private String H_SCR_CAR_NAME;      
	private String SCR_SUHAE_YN;        
	private String SCR_BIDAESANG_CD;    
	private String H_SCR_TKYAK_NM;      
	private String SCR_LAST_UPDATE_DATE;
	private String SCR_LAST_UPDATED_BY; 
	private String SCR_SVC_CHAJONG;     
	private String H_SCR_SVC_CAR;       
	private String SCR_GUMSA_GB;        
	private String SCR_GUMSA_BUDAMGM;   
	private String SCR_JIRYUK_GB;       
	private String SCR_PYECHA_CD;       
	private String SCR_CHAJONG_CD;      
	private String SCR_SINSOK_SCORE;    
	private String SCR_MANJOK_SCORE;    
	private String SCR_JOCHI_SCORE;     
	private String SCR_CHURY_CH_CD;     
	private String SCR_TEKBE_YN;      
	private String SCR_IPGO_CO_CD;    
	private String SCR_IPGO_SAYU_CD;  
	private String H_SCR_IPGO_CO_NAME;
	private String SCR_DC_TYPE;       
	private String SCR_DC_TYPE_SEBU;  
	private String H_SCR_DC_SEBU_CONT;
	private String SCR_PM_TYPE;       
	private String SCR_PM_TYPE_SEBU;  
	private String SCR_PM_KM;         
	private String H_SCR_CHUL_EMP_NAME; 
	private String SCR_CHUL_HP1;        
	private String SCR_CHUL_HP2;        
	private String SCR_CHUL_HP3;        
	private String SCR_SMS_CHUL_YN;     
	private String SCR_SMS_CHUL_YMDHMS; 
	private String SCR_SMS_GOGEK_YN;    
	private String SCR_SMS_GOGEK_YMDHMS;
	private String SCR_GYUNIN_GAIP_YN;  
	private String SCR_SMS_YN; 
	private String SCR_SMS_PA; 
	private String SCR_SMS_HP1;
	private String SCR_SMS_HP2;
	private String SCR_SMS_HP3;
	private String SCR_JUSO_SINGU_GB;  
	private String H_SCR_ST_GOGEK_ADDR;
	private String H_SCR_ST_GOGEK_GITA;
	private String SCR_MILEAGE_YN;    
	private String SCR_MILEAGE_SMS_YN;
	private String SCR_DRIVE_KM;      
	private String SCR_DRIVE_YMD;     
	private String SCR_PHOTO_YN;      
	private String SCR_SOS_DANGA; 
	private String SCR_SOS_GUBSU; 
	private String SCR_MILEAGE_GM;
	private String SCR_FILLER;
	
	public String getrURL() {
		return rURL;
	}
	public void setrURL(String rURL) {
		this.rURL = rURL;
	}
	public String getCOMM_CHANNEL() {
		return COMM_CHANNEL;
	}
	public void setCOMM_CHANNEL(String cOMM_CHANNEL) {
		COMM_CHANNEL = cOMM_CHANNEL;
	}
	public String getCOMM_UNIQUE_KEY() {
		return COMM_UNIQUE_KEY;
	}
	public void setCOMM_UNIQUE_KEY(String cOMM_UNIQUE_KEY) {
		COMM_UNIQUE_KEY = cOMM_UNIQUE_KEY;
	}
	public String getCOMM_PGMID() {
		return COMM_PGMID;
	}
	public void setCOMM_PGMID(String cOMM_PGMID) {
		COMM_PGMID = cOMM_PGMID;
	}
	public String getCOMM_PROC_GB() {
		return COMM_PROC_GB;
	}
	public void setCOMM_PROC_GB(String cOMM_PROC_GB) {
		COMM_PROC_GB = cOMM_PROC_GB;
	}
	public String getCOMM_ACTION_KEY() {
		return COMM_ACTION_KEY;
	}
	public void setCOMM_ACTION_KEY(String cOMM_ACTION_KEY) {
		COMM_ACTION_KEY = cOMM_ACTION_KEY;
	}
	public String getCOMM_USER_GB() {
		return COMM_USER_GB;
	}
	public void setCOMM_USER_GB(String cOMM_USER_GB) {
		COMM_USER_GB = cOMM_USER_GB;
	}
	public String getCOMM_USER_ID() {
		return COMM_USER_ID;
	}
	public void setCOMM_USER_ID(String cOMM_USER_ID) {
		COMM_USER_ID = cOMM_USER_ID;
	}
	public String getCOMM_JIJUM_CD() {
		return COMM_JIJUM_CD;
	}
	public void setCOMM_JIJUM_CD(String cOMM_JIJUM_CD) {
		COMM_JIJUM_CD = cOMM_JIJUM_CD;
	}
	public String getCOMM_JIBU_CD() {
		return COMM_JIBU_CD;
	}
	public void setCOMM_JIBU_CD(String cOMM_JIBU_CD) {
		COMM_JIBU_CD = cOMM_JIBU_CD;
	}
	public String getCOMM_PROTOCOL() {
		return COMM_PROTOCOL;
	}
	public void setCOMM_PROTOCOL(String cOMM_PROTOCOL) {
		COMM_PROTOCOL = cOMM_PROTOCOL;
	}
	public String getCOMM_COND_CD() {
		return COMM_COND_CD;
	}
	public void setCOMM_COND_CD(String cOMM_COND_CD) {
		COMM_COND_CD = cOMM_COND_CD;
	}
	public String getCOMM_LAST_FLAG() {
		return COMM_LAST_FLAG;
	}
	public void setCOMM_LAST_FLAG(String cOMM_LAST_FLAG) {
		COMM_LAST_FLAG = cOMM_LAST_FLAG;
	}
	public String getCOMM_CURSOR_MAP() {
		return COMM_CURSOR_MAP;
	}
	public void setCOMM_CURSOR_MAP(String cOMM_CURSOR_MAP) {
		COMM_CURSOR_MAP = cOMM_CURSOR_MAP;
	}
	public String getCOMM_CURSOR_IDX() {
		return COMM_CURSOR_IDX;
	}
	public void setCOMM_CURSOR_IDX(String cOMM_CURSOR_IDX) {
		COMM_CURSOR_IDX = cOMM_CURSOR_IDX;
	}
	public String getCOMM_MESSAGE_CD() {
		return COMM_MESSAGE_CD;
	}
	public void setCOMM_MESSAGE_CD(String cOMM_MESSAGE_CD) {
		COMM_MESSAGE_CD = cOMM_MESSAGE_CD;
	}
	public String getH_COMM_MESSAGE_NM() {
		return H_COMM_MESSAGE_NM;
	}
	public void setH_COMM_MESSAGE_NM(String h_COMM_MESSAGE_NM) {
		H_COMM_MESSAGE_NM = h_COMM_MESSAGE_NM;
	}
	public String getCOMM_ERR_NAME() {
		return COMM_ERR_NAME;
	}
	public void setCOMM_ERR_NAME(String cOMM_ERR_NAME) {
		COMM_ERR_NAME = cOMM_ERR_NAME;
	}
	public String getCOMM_ERR_TEXT() {
		return COMM_ERR_TEXT;
	}
	public void setCOMM_ERR_TEXT(String cOMM_ERR_TEXT) {
		COMM_ERR_TEXT = cOMM_ERR_TEXT;
	}
	public String getCOMM_SYS_CODE() {
		return COMM_SYS_CODE;
	}
	public void setCOMM_SYS_CODE(String cOMM_SYS_CODE) {
		COMM_SYS_CODE = cOMM_SYS_CODE;
	}
	public String getFILLER() {
		return FILLER;
	}
	public void setFILLER(String fILLER) {
		FILLER = fILLER;
	}
	public String getARS_LENGTH() {
		return ARS_LENGTH;
	}
	public void setARS_LENGTH(String aRS_LENGTH) {
		ARS_LENGTH = aRS_LENGTH;
	}
	public String getARS_PROCESS_ID() {
		return ARS_PROCESS_ID;
	}
	public void setARS_PROCESS_ID(String aRS_PROCESS_ID) {
		ARS_PROCESS_ID = aRS_PROCESS_ID;
	}
	public String getSCR_K_CHURY_GB() {
		return SCR_K_CHURY_GB;
	}
	public void setSCR_K_CHURY_GB(String sCR_K_CHURY_GB) {
		SCR_K_CHURY_GB = sCR_K_CHURY_GB;
	}
	public String getSCR_JUBSU_NO() {
		return SCR_JUBSU_NO;
	}
	public void setSCR_JUBSU_NO(String sCR_JUBSU_NO) {
		SCR_JUBSU_NO = sCR_JUBSU_NO;
	}
	public String getSCR_JUBSU_DATE() {
		return SCR_JUBSU_DATE;
	}
	public void setSCR_JUBSU_DATE(String sCR_JUBSU_DATE) {
		SCR_JUBSU_DATE = sCR_JUBSU_DATE;
	}
	public String getSCR_SOS_GB() {
		return SCR_SOS_GB;
	}
	public void setSCR_SOS_GB(String sCR_SOS_GB) {
		SCR_SOS_GB = sCR_SOS_GB;
	}
	public String getH_SCR_CAR_NO() {
		return H_SCR_CAR_NO;
	}
	public void setH_SCR_CAR_NO(String h_SCR_CAR_NO) {
		H_SCR_CAR_NO = h_SCR_CAR_NO;
	}
	public String getSCR_JUMIN_NO() {
		return SCR_JUMIN_NO;
	}
	public void setSCR_JUMIN_NO(String sCR_JUMIN_NO) {
		SCR_JUMIN_NO = sCR_JUMIN_NO;
	}
	public String getSCR_POLI_NO() {
		return SCR_POLI_NO;
	}
	public void setSCR_POLI_NO(String sCR_POLI_NO) {
		SCR_POLI_NO = sCR_POLI_NO;
	}
	public String getH_SCR_YOCHUNGJA() {
		return H_SCR_YOCHUNGJA;
	}
	public void setH_SCR_YOCHUNGJA(String h_SCR_YOCHUNGJA) {
		H_SCR_YOCHUNGJA = h_SCR_YOCHUNGJA;
	}
	public String getSCR_YOCHUNGJA_REL() {
		return SCR_YOCHUNGJA_REL;
	}
	public void setSCR_YOCHUNGJA_REL(String sCR_YOCHUNGJA_REL) {
		SCR_YOCHUNGJA_REL = sCR_YOCHUNGJA_REL;
	}
	public String getSCR_YOCHUNGJA1_AREA() {
		return SCR_YOCHUNGJA1_AREA;
	}
	public void setSCR_YOCHUNGJA1_AREA(String sCR_YOCHUNGJA1_AREA) {
		SCR_YOCHUNGJA1_AREA = sCR_YOCHUNGJA1_AREA;
	}
	public String getSCR_YOCHUNGJA1_GUK() {
		return SCR_YOCHUNGJA1_GUK;
	}
	public void setSCR_YOCHUNGJA1_GUK(String sCR_YOCHUNGJA1_GUK) {
		SCR_YOCHUNGJA1_GUK = sCR_YOCHUNGJA1_GUK;
	}
	public String getSCR_YOCHUNGJA1_PH() {
		return SCR_YOCHUNGJA1_PH;
	}
	public void setSCR_YOCHUNGJA1_PH(String sCR_YOCHUNGJA1_PH) {
		SCR_YOCHUNGJA1_PH = sCR_YOCHUNGJA1_PH;
	}
	public String getSCR_YOCHUNGJA1_GB() {
		return SCR_YOCHUNGJA1_GB;
	}
	public void setSCR_YOCHUNGJA1_GB(String sCR_YOCHUNGJA1_GB) {
		SCR_YOCHUNGJA1_GB = sCR_YOCHUNGJA1_GB;
	}
	public String getSCR_YOCHUNGJA2_AREA() {
		return SCR_YOCHUNGJA2_AREA;
	}
	public void setSCR_YOCHUNGJA2_AREA(String sCR_YOCHUNGJA2_AREA) {
		SCR_YOCHUNGJA2_AREA = sCR_YOCHUNGJA2_AREA;
	}
	public String getSCR_YOCHUNGJA2_GUK() {
		return SCR_YOCHUNGJA2_GUK;
	}
	public void setSCR_YOCHUNGJA2_GUK(String sCR_YOCHUNGJA2_GUK) {
		SCR_YOCHUNGJA2_GUK = sCR_YOCHUNGJA2_GUK;
	}
	public String getSCR_YOCHUNGJA2_PH() {
		return SCR_YOCHUNGJA2_PH;
	}
	public void setSCR_YOCHUNGJA2_PH(String sCR_YOCHUNGJA2_PH) {
		SCR_YOCHUNGJA2_PH = sCR_YOCHUNGJA2_PH;
	}
	public String getSCR_YOCHUNGJA2_GB() {
		return SCR_YOCHUNGJA2_GB;
	}
	public void setSCR_YOCHUNGJA2_GB(String sCR_YOCHUNGJA2_GB) {
		SCR_YOCHUNGJA2_GB = sCR_YOCHUNGJA2_GB;
	}
	public String getSCR_YOCHUNG_CD() {
		return SCR_YOCHUNG_CD;
	}
	public void setSCR_YOCHUNG_CD(String sCR_YOCHUNG_CD) {
		SCR_YOCHUNG_CD = sCR_YOCHUNG_CD;
	}
	public String getSCR_YOCHUNG_AREA_ZIP() {
		return SCR_YOCHUNG_AREA_ZIP;
	}
	public void setSCR_YOCHUNG_AREA_ZIP(String sCR_YOCHUNG_AREA_ZIP) {
		SCR_YOCHUNG_AREA_ZIP = sCR_YOCHUNG_AREA_ZIP;
	}
	public String getH_SCR_YOCHUNG_AREA_GITA() {
		return H_SCR_YOCHUNG_AREA_GITA;
	}
	public void setH_SCR_YOCHUNG_AREA_GITA(String h_SCR_YOCHUNG_AREA_GITA) {
		H_SCR_YOCHUNG_AREA_GITA = h_SCR_YOCHUNG_AREA_GITA;
	}
	public String getH_SCR_YOCHUNG_NOTE1() {
		return H_SCR_YOCHUNG_NOTE1;
	}
	public void setH_SCR_YOCHUNG_NOTE1(String h_SCR_YOCHUNG_NOTE1) {
		H_SCR_YOCHUNG_NOTE1 = h_SCR_YOCHUNG_NOTE1;
	}
	public String getH_SCR_YOCHUNG_NOTE2() {
		return H_SCR_YOCHUNG_NOTE2;
	}
	public void setH_SCR_YOCHUNG_NOTE2(String h_SCR_YOCHUNG_NOTE2) {
		H_SCR_YOCHUNG_NOTE2 = h_SCR_YOCHUNG_NOTE2;
	}
	public String getSCR_CO_CD() {
		return SCR_CO_CD;
	}
	public void setSCR_CO_CD(String sCR_CO_CD) {
		SCR_CO_CD = sCR_CO_CD;
	}
	public String getH_SCR_CO_TEL_NM() {
		return H_SCR_CO_TEL_NM;
	}
	public void setH_SCR_CO_TEL_NM(String h_SCR_CO_TEL_NM) {
		H_SCR_CO_TEL_NM = h_SCR_CO_TEL_NM;
	}
	public String getSCR_CO_TEL_DATE() {
		return SCR_CO_TEL_DATE;
	}
	public void setSCR_CO_TEL_DATE(String sCR_CO_TEL_DATE) {
		SCR_CO_TEL_DATE = sCR_CO_TEL_DATE;
	}
	public String getSCR_CO_TEL_JUBSUJA() {
		return SCR_CO_TEL_JUBSUJA;
	}
	public void setSCR_CO_TEL_JUBSUJA(String sCR_CO_TEL_JUBSUJA) {
		SCR_CO_TEL_JUBSUJA = sCR_CO_TEL_JUBSUJA;
	}
	public String getSCR_CHURY_CD() {
		return SCR_CHURY_CD;
	}
	public void setSCR_CHURY_CD(String sCR_CHURY_CD) {
		SCR_CHURY_CD = sCR_CHURY_CD;
	}
	public String getSCR_CHURY_ENDCD() {
		return SCR_CHURY_ENDCD;
	}
	public void setSCR_CHURY_ENDCD(String sCR_CHURY_ENDCD) {
		SCR_CHURY_ENDCD = sCR_CHURY_ENDCD;
	}
	public String getSCR_YANGHE_CD() {
		return SCR_YANGHE_CD;
	}
	public void setSCR_YANGHE_CD(String sCR_YANGHE_CD) {
		SCR_YANGHE_CD = sCR_YANGHE_CD;
	}
	public String getSCR_YANGHE_SAWON() {
		return SCR_YANGHE_SAWON;
	}
	public void setSCR_YANGHE_SAWON(String sCR_YANGHE_SAWON) {
		SCR_YANGHE_SAWON = sCR_YANGHE_SAWON;
	}
	public String getSCR_YANGHE_DATE() {
		return SCR_YANGHE_DATE;
	}
	public void setSCR_YANGHE_DATE(String sCR_YANGHE_DATE) {
		SCR_YANGHE_DATE = sCR_YANGHE_DATE;
	}
	public String getSCR_CHURY_GIGAN() {
		return SCR_CHURY_GIGAN;
	}
	public void setSCR_CHURY_GIGAN(String sCR_CHURY_GIGAN) {
		SCR_CHURY_GIGAN = sCR_CHURY_GIGAN;
	}
	public String getH_SCR_CHURY_NAME() {
		return H_SCR_CHURY_NAME;
	}
	public void setH_SCR_CHURY_NAME(String h_SCR_CHURY_NAME) {
		H_SCR_CHURY_NAME = h_SCR_CHURY_NAME;
	}
	public String getSCR_CHURY_GIBON_GM() {
		return SCR_CHURY_GIBON_GM;
	}
	public void setSCR_CHURY_GIBON_GM(String sCR_CHURY_GIBON_GM) {
		SCR_CHURY_GIBON_GM = sCR_CHURY_GIBON_GM;
	}
	public String getSCR_DOCHAK_DATE() {
		return SCR_DOCHAK_DATE;
	}
	public void setSCR_DOCHAK_DATE(String sCR_DOCHAK_DATE) {
		SCR_DOCHAK_DATE = sCR_DOCHAK_DATE;
	}
	public String getSCR_CHURY_DC_GB() {
		return SCR_CHURY_DC_GB;
	}
	public void setSCR_CHURY_DC_GB(String sCR_CHURY_DC_GB) {
		SCR_CHURY_DC_GB = sCR_CHURY_DC_GB;
	}
	public String getSCR_CHURY_DC_GM() {
		return SCR_CHURY_DC_GM;
	}
	public void setSCR_CHURY_DC_GM(String sCR_CHURY_DC_GM) {
		SCR_CHURY_DC_GM = sCR_CHURY_DC_GM;
	}
	public String getSCR_BUDAM_AMT() {
		return SCR_BUDAM_AMT;
	}
	public void setSCR_BUDAM_AMT(String sCR_BUDAM_AMT) {
		SCR_BUDAM_AMT = sCR_BUDAM_AMT;
	}
	public String getSCR_CO_YN() {
		return SCR_CO_YN;
	}
	public void setSCR_CO_YN(String sCR_CO_YN) {
		SCR_CO_YN = sCR_CO_YN;
	}
	public String getH_SCR_CHURY_CONT1() {
		return H_SCR_CHURY_CONT1;
	}
	public void setH_SCR_CHURY_CONT1(String h_SCR_CHURY_CONT1) {
		H_SCR_CHURY_CONT1 = h_SCR_CHURY_CONT1;
	}
	public String getH_SCR_CHURY_CONT2() {
		return H_SCR_CHURY_CONT2;
	}
	public void setH_SCR_CHURY_CONT2(String h_SCR_CHURY_CONT2) {
		H_SCR_CHURY_CONT2 = h_SCR_CHURY_CONT2;
	}
	public String getH_SCR_CHURY_CONT3() {
		return H_SCR_CHURY_CONT3;
	}
	public void setH_SCR_CHURY_CONT3(String h_SCR_CHURY_CONT3) {
		H_SCR_CHURY_CONT3 = h_SCR_CHURY_CONT3;
	}
	public String getH_SCR_CHURY_CONT4() {
		return H_SCR_CHURY_CONT4;
	}
	public void setH_SCR_CHURY_CONT4(String h_SCR_CHURY_CONT4) {
		H_SCR_CHURY_CONT4 = h_SCR_CHURY_CONT4;
	}
	public String getH_SCR_CHURY_CONT5() {
		return H_SCR_CHURY_CONT5;
	}
	public void setH_SCR_CHURY_CONT5(String h_SCR_CHURY_CONT5) {
		H_SCR_CHURY_CONT5 = h_SCR_CHURY_CONT5;
	}
	public String getH_SCR_CHURY_CONT6() {
		return H_SCR_CHURY_CONT6;
	}
	public void setH_SCR_CHURY_CONT6(String h_SCR_CHURY_CONT6) {
		H_SCR_CHURY_CONT6 = h_SCR_CHURY_CONT6;
	}
	public String getSCR_IPRYUK_SAWON_NO() {
		return SCR_IPRYUK_SAWON_NO;
	}
	public void setSCR_IPRYUK_SAWON_NO(String sCR_IPRYUK_SAWON_NO) {
		SCR_IPRYUK_SAWON_NO = sCR_IPRYUK_SAWON_NO;
	}
	public String getSCR_IPRYUK_DATE() {
		return SCR_IPRYUK_DATE;
	}
	public void setSCR_IPRYUK_DATE(String sCR_IPRYUK_DATE) {
		SCR_IPRYUK_DATE = sCR_IPRYUK_DATE;
	}
	public String getSCR_GUMSA_YMD() {
		return SCR_GUMSA_YMD;
	}
	public void setSCR_GUMSA_YMD(String sCR_GUMSA_YMD) {
		SCR_GUMSA_YMD = sCR_GUMSA_YMD;
	}
	public String getSCR_TKYAK_GB() {
		return SCR_TKYAK_GB;
	}
	public void setSCR_TKYAK_GB(String sCR_TKYAK_GB) {
		SCR_TKYAK_GB = sCR_TKYAK_GB;
	}
	public String getH_SCR_PIBO_NM() {
		return H_SCR_PIBO_NM;
	}
	public void setH_SCR_PIBO_NM(String h_SCR_PIBO_NM) {
		H_SCR_PIBO_NM = h_SCR_PIBO_NM;
	}
	public String getSCR_PIBO_CD() {
		return SCR_PIBO_CD;
	}
	public void setSCR_PIBO_CD(String sCR_PIBO_CD) {
		SCR_PIBO_CD = sCR_PIBO_CD;
	}
	public String getSCR_BJ_CD() {
		return SCR_BJ_CD;
	}
	public void setSCR_BJ_CD(String sCR_BJ_CD) {
		SCR_BJ_CD = sCR_BJ_CD;
	}
	public String getSCR_CAR_CD() {
		return SCR_CAR_CD;
	}
	public void setSCR_CAR_CD(String sCR_CAR_CD) {
		SCR_CAR_CD = sCR_CAR_CD;
	}
	public String getH_SCR_CAR_NAME() {
		return H_SCR_CAR_NAME;
	}
	public void setH_SCR_CAR_NAME(String h_SCR_CAR_NAME) {
		H_SCR_CAR_NAME = h_SCR_CAR_NAME;
	}
	public String getSCR_SUHAE_YN() {
		return SCR_SUHAE_YN;
	}
	public void setSCR_SUHAE_YN(String sCR_SUHAE_YN) {
		SCR_SUHAE_YN = sCR_SUHAE_YN;
	}
	public String getSCR_BIDAESANG_CD() {
		return SCR_BIDAESANG_CD;
	}
	public void setSCR_BIDAESANG_CD(String sCR_BIDAESANG_CD) {
		SCR_BIDAESANG_CD = sCR_BIDAESANG_CD;
	}
	public String getH_SCR_TKYAK_NM() {
		return H_SCR_TKYAK_NM;
	}
	public void setH_SCR_TKYAK_NM(String h_SCR_TKYAK_NM) {
		H_SCR_TKYAK_NM = h_SCR_TKYAK_NM;
	}
	public String getSCR_LAST_UPDATE_DATE() {
		return SCR_LAST_UPDATE_DATE;
	}
	public void setSCR_LAST_UPDATE_DATE(String sCR_LAST_UPDATE_DATE) {
		SCR_LAST_UPDATE_DATE = sCR_LAST_UPDATE_DATE;
	}
	public String getSCR_LAST_UPDATED_BY() {
		return SCR_LAST_UPDATED_BY;
	}
	public void setSCR_LAST_UPDATED_BY(String sCR_LAST_UPDATED_BY) {
		SCR_LAST_UPDATED_BY = sCR_LAST_UPDATED_BY;
	}
	public String getSCR_SVC_CHAJONG() {
		return SCR_SVC_CHAJONG;
	}
	public void setSCR_SVC_CHAJONG(String sCR_SVC_CHAJONG) {
		SCR_SVC_CHAJONG = sCR_SVC_CHAJONG;
	}
	public String getH_SCR_SVC_CAR() {
		return H_SCR_SVC_CAR;
	}
	public void setH_SCR_SVC_CAR(String h_SCR_SVC_CAR) {
		H_SCR_SVC_CAR = h_SCR_SVC_CAR;
	}
	public String getSCR_GUMSA_GB() {
		return SCR_GUMSA_GB;
	}
	public void setSCR_GUMSA_GB(String sCR_GUMSA_GB) {
		SCR_GUMSA_GB = sCR_GUMSA_GB;
	}
	public String getSCR_GUMSA_BUDAMGM() {
		return SCR_GUMSA_BUDAMGM;
	}
	public void setSCR_GUMSA_BUDAMGM(String sCR_GUMSA_BUDAMGM) {
		SCR_GUMSA_BUDAMGM = sCR_GUMSA_BUDAMGM;
	}
	public String getSCR_JIRYUK_GB() {
		return SCR_JIRYUK_GB;
	}
	public void setSCR_JIRYUK_GB(String sCR_JIRYUK_GB) {
		SCR_JIRYUK_GB = sCR_JIRYUK_GB;
	}
	public String getSCR_PYECHA_CD() {
		return SCR_PYECHA_CD;
	}
	public void setSCR_PYECHA_CD(String sCR_PYECHA_CD) {
		SCR_PYECHA_CD = sCR_PYECHA_CD;
	}
	public String getSCR_CHAJONG_CD() {
		return SCR_CHAJONG_CD;
	}
	public void setSCR_CHAJONG_CD(String sCR_CHAJONG_CD) {
		SCR_CHAJONG_CD = sCR_CHAJONG_CD;
	}
	public String getSCR_SINSOK_SCORE() {
		return SCR_SINSOK_SCORE;
	}
	public void setSCR_SINSOK_SCORE(String sCR_SINSOK_SCORE) {
		SCR_SINSOK_SCORE = sCR_SINSOK_SCORE;
	}
	public String getSCR_MANJOK_SCORE() {
		return SCR_MANJOK_SCORE;
	}
	public void setSCR_MANJOK_SCORE(String sCR_MANJOK_SCORE) {
		SCR_MANJOK_SCORE = sCR_MANJOK_SCORE;
	}
	public String getSCR_JOCHI_SCORE() {
		return SCR_JOCHI_SCORE;
	}
	public void setSCR_JOCHI_SCORE(String sCR_JOCHI_SCORE) {
		SCR_JOCHI_SCORE = sCR_JOCHI_SCORE;
	}
	public String getSCR_CHURY_CH_CD() {
		return SCR_CHURY_CH_CD;
	}
	public void setSCR_CHURY_CH_CD(String sCR_CHURY_CH_CD) {
		SCR_CHURY_CH_CD = sCR_CHURY_CH_CD;
	}
	public String getSCR_TEKBE_YN() {
		return SCR_TEKBE_YN;
	}
	public void setSCR_TEKBE_YN(String sCR_TEKBE_YN) {
		SCR_TEKBE_YN = sCR_TEKBE_YN;
	}
	public String getSCR_IPGO_CO_CD() {
		return SCR_IPGO_CO_CD;
	}
	public void setSCR_IPGO_CO_CD(String sCR_IPGO_CO_CD) {
		SCR_IPGO_CO_CD = sCR_IPGO_CO_CD;
	}
	public String getSCR_IPGO_SAYU_CD() {
		return SCR_IPGO_SAYU_CD;
	}
	public void setSCR_IPGO_SAYU_CD(String sCR_IPGO_SAYU_CD) {
		SCR_IPGO_SAYU_CD = sCR_IPGO_SAYU_CD;
	}
	public String getH_SCR_IPGO_CO_NAME() {
		return H_SCR_IPGO_CO_NAME;
	}
	public void setH_SCR_IPGO_CO_NAME(String h_SCR_IPGO_CO_NAME) {
		H_SCR_IPGO_CO_NAME = h_SCR_IPGO_CO_NAME;
	}
	public String getSCR_DC_TYPE() {
		return SCR_DC_TYPE;
	}
	public void setSCR_DC_TYPE(String sCR_DC_TYPE) {
		SCR_DC_TYPE = sCR_DC_TYPE;
	}
	public String getSCR_DC_TYPE_SEBU() {
		return SCR_DC_TYPE_SEBU;
	}
	public void setSCR_DC_TYPE_SEBU(String sCR_DC_TYPE_SEBU) {
		SCR_DC_TYPE_SEBU = sCR_DC_TYPE_SEBU;
	}
	public String getH_SCR_DC_SEBU_CONT() {
		return H_SCR_DC_SEBU_CONT;
	}
	public void setH_SCR_DC_SEBU_CONT(String h_SCR_DC_SEBU_CONT) {
		H_SCR_DC_SEBU_CONT = h_SCR_DC_SEBU_CONT;
	}
	public String getSCR_PM_TYPE() {
		return SCR_PM_TYPE;
	}
	public void setSCR_PM_TYPE(String sCR_PM_TYPE) {
		SCR_PM_TYPE = sCR_PM_TYPE;
	}
	public String getSCR_PM_TYPE_SEBU() {
		return SCR_PM_TYPE_SEBU;
	}
	public void setSCR_PM_TYPE_SEBU(String sCR_PM_TYPE_SEBU) {
		SCR_PM_TYPE_SEBU = sCR_PM_TYPE_SEBU;
	}
	public String getSCR_PM_KM() {
		return SCR_PM_KM;
	}
	public void setSCR_PM_KM(String sCR_PM_KM) {
		SCR_PM_KM = sCR_PM_KM;
	}
	public String getH_SCR_CHUL_EMP_NAME() {
		return H_SCR_CHUL_EMP_NAME;
	}
	public void setH_SCR_CHUL_EMP_NAME(String h_SCR_CHUL_EMP_NAME) {
		H_SCR_CHUL_EMP_NAME = h_SCR_CHUL_EMP_NAME;
	}
	public String getSCR_CHUL_HP1() {
		return SCR_CHUL_HP1;
	}
	public void setSCR_CHUL_HP1(String sCR_CHUL_HP1) {
		SCR_CHUL_HP1 = sCR_CHUL_HP1;
	}
	public String getSCR_CHUL_HP2() {
		return SCR_CHUL_HP2;
	}
	public void setSCR_CHUL_HP2(String sCR_CHUL_HP2) {
		SCR_CHUL_HP2 = sCR_CHUL_HP2;
	}
	public String getSCR_CHUL_HP3() {
		return SCR_CHUL_HP3;
	}
	public void setSCR_CHUL_HP3(String sCR_CHUL_HP3) {
		SCR_CHUL_HP3 = sCR_CHUL_HP3;
	}
	public String getSCR_SMS_CHUL_YN() {
		return SCR_SMS_CHUL_YN;
	}
	public void setSCR_SMS_CHUL_YN(String sCR_SMS_CHUL_YN) {
		SCR_SMS_CHUL_YN = sCR_SMS_CHUL_YN;
	}
	public String getSCR_SMS_CHUL_YMDHMS() {
		return SCR_SMS_CHUL_YMDHMS;
	}
	public void setSCR_SMS_CHUL_YMDHMS(String sCR_SMS_CHUL_YMDHMS) {
		SCR_SMS_CHUL_YMDHMS = sCR_SMS_CHUL_YMDHMS;
	}
	public String getSCR_SMS_GOGEK_YN() {
		return SCR_SMS_GOGEK_YN;
	}
	public void setSCR_SMS_GOGEK_YN(String sCR_SMS_GOGEK_YN) {
		SCR_SMS_GOGEK_YN = sCR_SMS_GOGEK_YN;
	}
	public String getSCR_SMS_GOGEK_YMDHMS() {
		return SCR_SMS_GOGEK_YMDHMS;
	}
	public void setSCR_SMS_GOGEK_YMDHMS(String sCR_SMS_GOGEK_YMDHMS) {
		SCR_SMS_GOGEK_YMDHMS = sCR_SMS_GOGEK_YMDHMS;
	}
	public String getSCR_GYUNIN_GAIP_YN() {
		return SCR_GYUNIN_GAIP_YN;
	}
	public void setSCR_GYUNIN_GAIP_YN(String sCR_GYUNIN_GAIP_YN) {
		SCR_GYUNIN_GAIP_YN = sCR_GYUNIN_GAIP_YN;
	}
	public String getSCR_SMS_YN() {
		return SCR_SMS_YN;
	}
	public void setSCR_SMS_YN(String sCR_SMS_YN) {
		SCR_SMS_YN = sCR_SMS_YN;
	}
	public String getSCR_SMS_PA() {
		return SCR_SMS_PA;
	}
	public void setSCR_SMS_PA(String sCR_SMS_PA) {
		SCR_SMS_PA = sCR_SMS_PA;
	}
	public String getSCR_SMS_HP1() {
		return SCR_SMS_HP1;
	}
	public void setSCR_SMS_HP1(String sCR_SMS_HP1) {
		SCR_SMS_HP1 = sCR_SMS_HP1;
	}
	public String getSCR_SMS_HP2() {
		return SCR_SMS_HP2;
	}
	public void setSCR_SMS_HP2(String sCR_SMS_HP2) {
		SCR_SMS_HP2 = sCR_SMS_HP2;
	}
	public String getSCR_SMS_HP3() {
		return SCR_SMS_HP3;
	}
	public void setSCR_SMS_HP3(String sCR_SMS_HP3) {
		SCR_SMS_HP3 = sCR_SMS_HP3;
	}
	public String getSCR_JUSO_SINGU_GB() {
		return SCR_JUSO_SINGU_GB;
	}
	public void setSCR_JUSO_SINGU_GB(String sCR_JUSO_SINGU_GB) {
		SCR_JUSO_SINGU_GB = sCR_JUSO_SINGU_GB;
	}
	public String getH_SCR_ST_GOGEK_ADDR() {
		return H_SCR_ST_GOGEK_ADDR;
	}
	public void setH_SCR_ST_GOGEK_ADDR(String h_SCR_ST_GOGEK_ADDR) {
		H_SCR_ST_GOGEK_ADDR = h_SCR_ST_GOGEK_ADDR;
	}
	public String getH_SCR_ST_GOGEK_GITA() {
		return H_SCR_ST_GOGEK_GITA;
	}
	public void setH_SCR_ST_GOGEK_GITA(String h_SCR_ST_GOGEK_GITA) {
		H_SCR_ST_GOGEK_GITA = h_SCR_ST_GOGEK_GITA;
	}
	public String getSCR_MILEAGE_YN() {
		return SCR_MILEAGE_YN;
	}
	public void setSCR_MILEAGE_YN(String sCR_MILEAGE_YN) {
		SCR_MILEAGE_YN = sCR_MILEAGE_YN;
	}
	public String getSCR_MILEAGE_SMS_YN() {
		return SCR_MILEAGE_SMS_YN;
	}
	public void setSCR_MILEAGE_SMS_YN(String sCR_MILEAGE_SMS_YN) {
		SCR_MILEAGE_SMS_YN = sCR_MILEAGE_SMS_YN;
	}
	public String getSCR_DRIVE_KM() {
		return SCR_DRIVE_KM;
	}
	public void setSCR_DRIVE_KM(String sCR_DRIVE_KM) {
		SCR_DRIVE_KM = sCR_DRIVE_KM;
	}
	public String getSCR_DRIVE_YMD() {
		return SCR_DRIVE_YMD;
	}
	public void setSCR_DRIVE_YMD(String sCR_DRIVE_YMD) {
		SCR_DRIVE_YMD = sCR_DRIVE_YMD;
	}
	public String getSCR_PHOTO_YN() {
		return SCR_PHOTO_YN;
	}
	public void setSCR_PHOTO_YN(String sCR_PHOTO_YN) {
		SCR_PHOTO_YN = sCR_PHOTO_YN;
	}
	public String getSCR_SOS_DANGA() {
		return SCR_SOS_DANGA;
	}
	public void setSCR_SOS_DANGA(String sCR_SOS_DANGA) {
		SCR_SOS_DANGA = sCR_SOS_DANGA;
	}
	public String getSCR_SOS_GUBSU() {
		return SCR_SOS_GUBSU;
	}
	public void setSCR_SOS_GUBSU(String sCR_SOS_GUBSU) {
		SCR_SOS_GUBSU = sCR_SOS_GUBSU;
	}
	public String getSCR_MILEAGE_GM() {
		return SCR_MILEAGE_GM;
	}
	public void setSCR_MILEAGE_GM(String sCR_MILEAGE_GM) {
		SCR_MILEAGE_GM = sCR_MILEAGE_GM;
	}
	public String getSCR_FILLER() {
		return SCR_FILLER;
	}
	public void setSCR_FILLER(String sCR_FILLER) {
		SCR_FILLER = sCR_FILLER;
	}
	public static String getProid() {
		return proid;
	}
	public static String getTrid() {
		return trid;
	}
}
