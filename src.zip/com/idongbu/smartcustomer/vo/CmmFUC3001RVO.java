package com.idongbu.smartcustomer.vo;

import com.idongbu.common.vo.CMMVO;

//장기 연금 보종 상세 전문
public class CmmFUC3001RVO extends CMMVO {
	public static final String proid	= "FUC3001R";
	public static final String trid		= "UC31";
	public String rURL					= "";
	
	//입력
	public String UU_POLI_NO			= "";
	public String CC_PGMID          	= null;
	public String CC_CHANNEL        	= null; 
	public String CC_PROC_GB        	= null; 
	public String CC_FUN_KEY        	= null; 
	public String CC_COND_CD        	= null; // 처리결과('01','  ':정상, 나머지:비정상)
	//출력
	public String CC_USER_GB = "";
	public String CC_USER_CD = "";
	public String JJ_POLI_NO = "";
	public String JJ_BESU_SEQ = "";
	public String JJ_BJ_CD = "";
	public String HJ_BJ_NAME = "";
	public String HJ_BJ_GBN = "";
	public String HJ_PI_NAME1 = "";
	public String JJ_PI_JUMIN1 = "";
	public String JJ_BH_SYMD = "";
	public String JJ_BH_EYMD = "";
	public String JJ_BOHUM_GIGANCD = "";
	
	public String HJ_BH_NM = "";
	public String HJ_BUNNAP_NM1 = "";
	public String JJ_GBSU_CD1 = "";
	public String JJ_PIBO_AGE1 = "";
	public String HJ_CAR_UNHENG_NM = "";
	public String HJ_MULGUN_GUBUN = "";
	public String HJ_SANGHE_CD15 = "";
	public String JJ_GAIP_TYPE1 = "";
	
	public String HJ_TYPE1_NM = "";
	public String HJ_TYPE2_NM = "";
	public String HJ_MULGUN_GUBUNNM = "";
	public String HJ_JONG_NM = "";
	public String JJ_TKYAK_SYMD = "";
	public String JJ_TKYAK_EYMD = "";
	public String JJ_TKYAK_YY = "";
	public String HJ_TKYAK_MANGI = "";
	public String JJ_JIGUB_GIGAN = "";
	public String HJ_PI_NAME2 = "";
	public String JJ_PI_JUMIN2 = "";
	public String HJ_BUNNAP_NM2 = "";
	public String JJ_PIBO_AGE2 = "";
	public String JJ_GBSU_CD2 = "";
	public String HJ_BOHUM_GG_NM = "";
	public String JJ_GUCHI_YCNT = "";
	public String JJ_BOHUM_SYMD = "";
	public String JJ_BOHUM_EYMD = "";
	public String JJ_JONGBYL_CD = "";
	public String JJ_1BOHUM_SYMD = "";
	public String JJ_1BOHUM_EYMD = "";
	public String JJ_1BOHUM_YY = "";
	public String HJ_1BOHUM_MANGI = "";
	public String JJ_2BOHUM_SYMD = "";
	public String JJ_2BOHUM_EYMD = "";
	public String JJ_2BOHUM_YY = "";
	public String HJ_2BOHUM_MANGI = "";
	public String HJ_GESI_AGE_NM = "";
	public String HJ_JIGP_BB_NM = "";
	public String HJ_JIGP_YCNT_NM = "";
	public String HJ_JIGP_GB_NM = "";
	public String HJ_DRIV_LICENSENM = "";
	public String HJ_TUKJU_1 = "";
	public String HJ_TUKJU_2 = "";
	//특정부위부담보３，４추가 2010.09.30 기간계 이상대
	public String HJ_TUKJU_3  = "";
	public String HJ_TUKJU_4  = "";
	public String HJ_TUKJU_GIGAN = "";
	public String HJ_TUKJU_GIGAN2 = "";
	//특정부위부담보기간３，４추가 2010.09.30 기간계 이상대 
	public String HJ_TUKJU_GIGAN3  = "";
	public String HJ_TUKJU_GIGAN4  = ""; 	
	public String HJ_TUKJU_SANGHE_1 = "";
	public String HJ_TUKJU_SANGHE_2 = "";
	public String HJ_TUKJU_SANGHE_GIGAN = "";
	public String HJ_TUKJU_SANGHE_GIGAN2 = "";
	public String HJ_HAL_LEV = "";
	public String HJ_SAK_GIGAN = "";
	public String JJ_HAL_PRM = "";
	public String HJ_CAR_M = "";
	public String HJ_JUKSUNG = "";
	public String JJ_GIUP_CD = "";
	public String HJ_GIUP_NM = "";
	public String HJ_JUKRIP_IYUL = "";
	public String[] HJ_DAMBO_NAME = new String[0];//[50]
	public String[] JJ_GAIP_GMEK = new String[0];//[50]
	public String[] JJ_GIBON_PRM = new String[0];//[50]
	public String[] JJ_DAMBO_CD = new String[0];//[50]
	public String[] JJ_APER_GAIP_GMEK = new String[0];//[50]
	public String[] JJ_GENGSIN_YN = new String[0];//[50]

	public String HJ_MESSAGE = "";
	public String JJ_GAJOK_YN = "";
	public String JJ_GAJOK_TOT = "";
	public String JJ_BOJANG_PRM = "";
	public String JJ_JUKRIP_BUMUN_PRM = "";
	public String JJ_SUM_PRM = "";
	public String JJ_NAPIPHAL_PRM = "";
	public String JJ_MULGUNL_PRM = "";
	public String JJ_SIGI_GUBUN = "";
	
	//기간계 홍경애 2011.02.16 prod 이행
	public String JJ_BALGUP_GB= "";//수령처구분
	public String HJ_BALGUP_NM= "";//수령처명
	
	//기간계 홍경애 2011.02.25 prod 이행
	public String HJ_GUCHI_CNT = "";             //연금거치기간    

	public String JJ_3212_SEQ = "";
	public String[] JJ_3212_YYYY = new String[0];//[15]
	public String[] JJ_3212_NAPIP_PRM = new String[0];//[15]
	public String[] JJ_3212_BALGB_PRM = new String[0];//[15]
	public String[] JJ_3212_NUGYE = new String[0];//[15]
	public String[] JJ_3212_CHAIK = new String[0];//[15]
	public String HJ_SOYU = "";
	public String HJ_CAR = "";
	public String JJ_GEOMSA = "";
	public String JJ_283_SU = "";
	public String JJ_GAJOK_SU = "";
	public String JJ_GAJOK_JA = "";
	public String HJ_JANYU_NAME = "";
	public String JJ_JA_JUMIN = "";
	public String JJ_PRM_282 = "";
	public String JJ_TOUR_FROM = "";
	public String JJ_TOUR_TO = "";
	public String HJ_TOUR_NAME = "";
	public String HJ_3219_JANYU_NAME = "";
	public String JJ_3219_JANYU_YMD = "";
	public String JJ_ARMY_WOL = "";
	public String HJ_SO_NM = "";
	public String JJ_SO_JUMIN = "";
	public String JJ_SO_ZIP = "";
	public String HJ_SO_ADDR = "";
	public String HJ_SO_GITA = "";
	public String JJ_JOB_JIK = "";
	public String JJ_YOYUL_JIK = "";
	public String JJ_GUJO_GBSU = "";
	
	public String[] JJ_MOKJUK = new String[0];//[4]
	public String[] JJ_MOKJUK_GBSU = new String[0];//[4]
	public String[] JJ_MYUNJUK = new String[0];//[4]
	public String[] JJ_GAIP = new String[0];//[4]
	public String[] JJ_PRM = new String[0];//[4]
	public String[] HJ_GUJO = new String[0];//[4]
	
	public String HJ_SUYONG1 = "";
	public String HJ_SUYONG2 = "";
	public String UU_BESU_SEQ = "";	
	
	public String HJ_JIGP_NM  = "";	// 261보종 이자지급방법

	public String getrURL() {
		return rURL;
	}

	public void setrURL(String rURL) {
		this.rURL = rURL;
	}

	public String getCC_PGMID() {
		return CC_PGMID;
	}

	public void setCC_PGMID(String cC_PGMID) {
		CC_PGMID = cC_PGMID;
	}

	public String getCC_CHANNEL() {
		return CC_CHANNEL;
	}

	public void setCC_CHANNEL(String cC_CHANNEL) {
		CC_CHANNEL = cC_CHANNEL;
	}

	public String getCC_PROC_GB() {
		return CC_PROC_GB;
	}

	public void setCC_PROC_GB(String cC_PROC_GB) {
		CC_PROC_GB = cC_PROC_GB;
	}

	public String getCC_FUN_KEY() {
		return CC_FUN_KEY;
	}

	public void setCC_FUN_KEY(String cC_FUN_KEY) {
		CC_FUN_KEY = cC_FUN_KEY;
	}

	public String getUU_POLI_NO() {
		return UU_POLI_NO;
	}

	public void setUU_POLI_NO(String uU_POLI_NO) {
		UU_POLI_NO = uU_POLI_NO;
	}

	public String getCC_USER_GB() {
		return CC_USER_GB;
	}

	public void setCC_USER_GB(String cC_USER_GB) {
		CC_USER_GB = cC_USER_GB;
	}

	public String getCC_USER_CD() {
		return CC_USER_CD;
	}

	public void setCC_USER_CD(String cC_USER_CD) {
		CC_USER_CD = cC_USER_CD;
	}

	public String getJJ_POLI_NO() {
		return JJ_POLI_NO;
	}

	public void setJJ_POLI_NO(String jJ_POLI_NO) {
		JJ_POLI_NO = jJ_POLI_NO;
	}

	public String getJJ_BESU_SEQ() {
		return JJ_BESU_SEQ;
	}

	public void setJJ_BESU_SEQ(String jJ_BESU_SEQ) {
		JJ_BESU_SEQ = jJ_BESU_SEQ;
	}

	public String getJJ_BJ_CD() {
		return JJ_BJ_CD;
	}

	public void setJJ_BJ_CD(String jJ_BJ_CD) {
		JJ_BJ_CD = jJ_BJ_CD;
	}

	public String getHJ_BJ_NAME() {
		return HJ_BJ_NAME;
	}

	public void setHJ_BJ_NAME(String hJ_BJ_NAME) {
		HJ_BJ_NAME = hJ_BJ_NAME;
	}

	public String getHJ_BJ_GBN() {
		return HJ_BJ_GBN;
	}

	public void setHJ_BJ_GBN(String hJ_BJ_GBN) {
		HJ_BJ_GBN = hJ_BJ_GBN;
	}

	public String getHJ_PI_NAME1() {
		return HJ_PI_NAME1;
	}

	public void setHJ_PI_NAME1(String hJ_PI_NAME1) {
		HJ_PI_NAME1 = hJ_PI_NAME1;
	}

	public String getJJ_PI_JUMIN1() {
		return JJ_PI_JUMIN1;
	}

	public void setJJ_PI_JUMIN1(String jJ_PI_JUMIN1) {
		JJ_PI_JUMIN1 = jJ_PI_JUMIN1;
	}

	public String getJJ_BH_SYMD() {
		return JJ_BH_SYMD;
	}

	public void setJJ_BH_SYMD(String jJ_BH_SYMD) {
		JJ_BH_SYMD = jJ_BH_SYMD;
	}

	public String getJJ_BH_EYMD() {
		return JJ_BH_EYMD;
	}

	public void setJJ_BH_EYMD(String jJ_BH_EYMD) {
		JJ_BH_EYMD = jJ_BH_EYMD;
	}

	public String getJJ_BOHUM_GIGANCD() {
		return JJ_BOHUM_GIGANCD;
	}

	public void setJJ_BOHUM_GIGANCD(String jJ_BOHUM_GIGANCD) {
		JJ_BOHUM_GIGANCD = jJ_BOHUM_GIGANCD;
	}

	public String getHJ_BH_NM() {
		return HJ_BH_NM;
	}

	public void setHJ_BH_NM(String hJ_BH_NM) {
		HJ_BH_NM = hJ_BH_NM;
	}

	public String getHJ_BUNNAP_NM1() {
		return HJ_BUNNAP_NM1;
	}

	public void setHJ_BUNNAP_NM1(String hJ_BUNNAP_NM1) {
		HJ_BUNNAP_NM1 = hJ_BUNNAP_NM1;
	}

	public String getJJ_GBSU_CD1() {
		return JJ_GBSU_CD1;
	}

	public void setJJ_GBSU_CD1(String jJ_GBSU_CD1) {
		JJ_GBSU_CD1 = jJ_GBSU_CD1;
	}

	public String getJJ_PIBO_AGE1() {
		return JJ_PIBO_AGE1;
	}

	public void setJJ_PIBO_AGE1(String jJ_PIBO_AGE1) {
		JJ_PIBO_AGE1 = jJ_PIBO_AGE1;
	}

	public String getHJ_CAR_UNHENG_NM() {
		return HJ_CAR_UNHENG_NM;
	}

	public void setHJ_CAR_UNHENG_NM(String hJ_CAR_UNHENG_NM) {
		HJ_CAR_UNHENG_NM = hJ_CAR_UNHENG_NM;
	}

	public String getHJ_MULGUN_GUBUN() {
		return HJ_MULGUN_GUBUN;
	}

	public void setHJ_MULGUN_GUBUN(String hJ_MULGUN_GUBUN) {
		HJ_MULGUN_GUBUN = hJ_MULGUN_GUBUN;
	}

	public String getHJ_SANGHE_CD15() {
		return HJ_SANGHE_CD15;
	}

	public void setHJ_SANGHE_CD15(String hJ_SANGHE_CD15) {
		HJ_SANGHE_CD15 = hJ_SANGHE_CD15;
	}

	public String getJJ_GAIP_TYPE1() {
		return JJ_GAIP_TYPE1;
	}

	public void setJJ_GAIP_TYPE1(String jJ_GAIP_TYPE1) {
		JJ_GAIP_TYPE1 = jJ_GAIP_TYPE1;
	}

	public String getHJ_TYPE1_NM() {
		return HJ_TYPE1_NM;
	}

	public void setHJ_TYPE1_NM(String hJ_TYPE1_NM) {
		HJ_TYPE1_NM = hJ_TYPE1_NM;
	}

	public String getHJ_TYPE2_NM() {
		return HJ_TYPE2_NM;
	}

	public void setHJ_TYPE2_NM(String hJ_TYPE2_NM) {
		HJ_TYPE2_NM = hJ_TYPE2_NM;
	}

	public String getHJ_MULGUN_GUBUNNM() {
		return HJ_MULGUN_GUBUNNM;
	}

	public void setHJ_MULGUN_GUBUNNM(String hJ_MULGUN_GUBUNNM) {
		HJ_MULGUN_GUBUNNM = hJ_MULGUN_GUBUNNM;
	}

	public String getHJ_JONG_NM() {
		return HJ_JONG_NM;
	}

	public void setHJ_JONG_NM(String hJ_JONG_NM) {
		HJ_JONG_NM = hJ_JONG_NM;
	}

	public String getJJ_TKYAK_SYMD() {
		return JJ_TKYAK_SYMD;
	}

	public void setJJ_TKYAK_SYMD(String jJ_TKYAK_SYMD) {
		JJ_TKYAK_SYMD = jJ_TKYAK_SYMD;
	}

	public String getJJ_TKYAK_EYMD() {
		return JJ_TKYAK_EYMD;
	}

	public void setJJ_TKYAK_EYMD(String jJ_TKYAK_EYMD) {
		JJ_TKYAK_EYMD = jJ_TKYAK_EYMD;
	}

	public String getJJ_TKYAK_YY() {
		return JJ_TKYAK_YY;
	}

	public void setJJ_TKYAK_YY(String jJ_TKYAK_YY) {
		JJ_TKYAK_YY = jJ_TKYAK_YY;
	}

	public String getHJ_TKYAK_MANGI() {
		return HJ_TKYAK_MANGI;
	}

	public void setHJ_TKYAK_MANGI(String hJ_TKYAK_MANGI) {
		HJ_TKYAK_MANGI = hJ_TKYAK_MANGI;
	}

	public String getJJ_JIGUB_GIGAN() {
		return JJ_JIGUB_GIGAN;
	}

	public void setJJ_JIGUB_GIGAN(String jJ_JIGUB_GIGAN) {
		JJ_JIGUB_GIGAN = jJ_JIGUB_GIGAN;
	}

	public String getHJ_PI_NAME2() {
		return HJ_PI_NAME2;
	}

	public void setHJ_PI_NAME2(String hJ_PI_NAME2) {
		HJ_PI_NAME2 = hJ_PI_NAME2;
	}

	public String getJJ_PI_JUMIN2() {
		return JJ_PI_JUMIN2;
	}

	public void setJJ_PI_JUMIN2(String jJ_PI_JUMIN2) {
		JJ_PI_JUMIN2 = jJ_PI_JUMIN2;
	}

	public String getHJ_BUNNAP_NM2() {
		return HJ_BUNNAP_NM2;
	}

	public void setHJ_BUNNAP_NM2(String hJ_BUNNAP_NM2) {
		HJ_BUNNAP_NM2 = hJ_BUNNAP_NM2;
	}

	public String getJJ_PIBO_AGE2() {
		return JJ_PIBO_AGE2;
	}

	public void setJJ_PIBO_AGE2(String jJ_PIBO_AGE2) {
		JJ_PIBO_AGE2 = jJ_PIBO_AGE2;
	}

	public String getJJ_GBSU_CD2() {
		return JJ_GBSU_CD2;
	}

	public void setJJ_GBSU_CD2(String jJ_GBSU_CD2) {
		JJ_GBSU_CD2 = jJ_GBSU_CD2;
	}

	public String getHJ_BOHUM_GG_NM() {
		return HJ_BOHUM_GG_NM;
	}

	public void setHJ_BOHUM_GG_NM(String hJ_BOHUM_GG_NM) {
		HJ_BOHUM_GG_NM = hJ_BOHUM_GG_NM;
	}

	public String getJJ_GUCHI_YCNT() {
		return JJ_GUCHI_YCNT;
	}

	public void setJJ_GUCHI_YCNT(String jJ_GUCHI_YCNT) {
		JJ_GUCHI_YCNT = jJ_GUCHI_YCNT;
	}

	public String getJJ_BOHUM_SYMD() {
		return JJ_BOHUM_SYMD;
	}

	public void setJJ_BOHUM_SYMD(String jJ_BOHUM_SYMD) {
		JJ_BOHUM_SYMD = jJ_BOHUM_SYMD;
	}

	public String getJJ_BOHUM_EYMD() {
		return JJ_BOHUM_EYMD;
	}

	public void setJJ_BOHUM_EYMD(String jJ_BOHUM_EYMD) {
		JJ_BOHUM_EYMD = jJ_BOHUM_EYMD;
	}

	public String getJJ_JONGBYL_CD() {
		return JJ_JONGBYL_CD;
	}

	public void setJJ_JONGBYL_CD(String jJ_JONGBYL_CD) {
		JJ_JONGBYL_CD = jJ_JONGBYL_CD;
	}

	public String getJJ_1BOHUM_SYMD() {
		return JJ_1BOHUM_SYMD;
	}

	public void setJJ_1BOHUM_SYMD(String jJ_1BOHUM_SYMD) {
		JJ_1BOHUM_SYMD = jJ_1BOHUM_SYMD;
	}

	public String getJJ_1BOHUM_EYMD() {
		return JJ_1BOHUM_EYMD;
	}

	public void setJJ_1BOHUM_EYMD(String jJ_1BOHUM_EYMD) {
		JJ_1BOHUM_EYMD = jJ_1BOHUM_EYMD;
	}

	public String getJJ_1BOHUM_YY() {
		return JJ_1BOHUM_YY;
	}

	public void setJJ_1BOHUM_YY(String jJ_1BOHUM_YY) {
		JJ_1BOHUM_YY = jJ_1BOHUM_YY;
	}

	public String getHJ_1BOHUM_MANGI() {
		return HJ_1BOHUM_MANGI;
	}

	public void setHJ_1BOHUM_MANGI(String hJ_1BOHUM_MANGI) {
		HJ_1BOHUM_MANGI = hJ_1BOHUM_MANGI;
	}

	public String getJJ_2BOHUM_SYMD() {
		return JJ_2BOHUM_SYMD;
	}

	public void setJJ_2BOHUM_SYMD(String jJ_2BOHUM_SYMD) {
		JJ_2BOHUM_SYMD = jJ_2BOHUM_SYMD;
	}

	public String getJJ_2BOHUM_EYMD() {
		return JJ_2BOHUM_EYMD;
	}

	public void setJJ_2BOHUM_EYMD(String jJ_2BOHUM_EYMD) {
		JJ_2BOHUM_EYMD = jJ_2BOHUM_EYMD;
	}

	public String getJJ_2BOHUM_YY() {
		return JJ_2BOHUM_YY;
	}

	public void setJJ_2BOHUM_YY(String jJ_2BOHUM_YY) {
		JJ_2BOHUM_YY = jJ_2BOHUM_YY;
	}

	public String getHJ_2BOHUM_MANGI() {
		return HJ_2BOHUM_MANGI;
	}

	public void setHJ_2BOHUM_MANGI(String hJ_2BOHUM_MANGI) {
		HJ_2BOHUM_MANGI = hJ_2BOHUM_MANGI;
	}

	public String getHJ_GESI_AGE_NM() {
		return HJ_GESI_AGE_NM;
	}

	public void setHJ_GESI_AGE_NM(String hJ_GESI_AGE_NM) {
		HJ_GESI_AGE_NM = hJ_GESI_AGE_NM;
	}

	public String getHJ_JIGP_BB_NM() {
		return HJ_JIGP_BB_NM;
	}

	public void setHJ_JIGP_BB_NM(String hJ_JIGP_BB_NM) {
		HJ_JIGP_BB_NM = hJ_JIGP_BB_NM;
	}

	public String getHJ_JIGP_YCNT_NM() {
		return HJ_JIGP_YCNT_NM;
	}

	public void setHJ_JIGP_YCNT_NM(String hJ_JIGP_YCNT_NM) {
		HJ_JIGP_YCNT_NM = hJ_JIGP_YCNT_NM;
	}

	public String getHJ_JIGP_GB_NM() {
		return HJ_JIGP_GB_NM;
	}

	public void setHJ_JIGP_GB_NM(String hJ_JIGP_GB_NM) {
		HJ_JIGP_GB_NM = hJ_JIGP_GB_NM;
	}

	public String getHJ_DRIV_LICENSENM() {
		return HJ_DRIV_LICENSENM;
	}

	public void setHJ_DRIV_LICENSENM(String hJ_DRIV_LICENSENM) {
		HJ_DRIV_LICENSENM = hJ_DRIV_LICENSENM;
	}

	public String getHJ_TUKJU_1() {
		return HJ_TUKJU_1;
	}

	public void setHJ_TUKJU_1(String hJ_TUKJU_1) {
		HJ_TUKJU_1 = hJ_TUKJU_1;
	}

	public String getHJ_TUKJU_2() {
		return HJ_TUKJU_2;
	}

	public void setHJ_TUKJU_2(String hJ_TUKJU_2) {
		HJ_TUKJU_2 = hJ_TUKJU_2;
	}

	public String getHJ_TUKJU_3() {
		return HJ_TUKJU_3;
	}

	public void setHJ_TUKJU_3(String hJ_TUKJU_3) {
		HJ_TUKJU_3 = hJ_TUKJU_3;
	}

	public String getHJ_TUKJU_4() {
		return HJ_TUKJU_4;
	}

	public void setHJ_TUKJU_4(String hJ_TUKJU_4) {
		HJ_TUKJU_4 = hJ_TUKJU_4;
	}

	public String getHJ_TUKJU_GIGAN() {
		return HJ_TUKJU_GIGAN;
	}

	public void setHJ_TUKJU_GIGAN(String hJ_TUKJU_GIGAN) {
		HJ_TUKJU_GIGAN = hJ_TUKJU_GIGAN;
	}

	public String getHJ_TUKJU_GIGAN2() {
		return HJ_TUKJU_GIGAN2;
	}

	public void setHJ_TUKJU_GIGAN2(String hJ_TUKJU_GIGAN2) {
		HJ_TUKJU_GIGAN2 = hJ_TUKJU_GIGAN2;
	}

	public String getHJ_TUKJU_GIGAN3() {
		return HJ_TUKJU_GIGAN3;
	}

	public void setHJ_TUKJU_GIGAN3(String hJ_TUKJU_GIGAN3) {
		HJ_TUKJU_GIGAN3 = hJ_TUKJU_GIGAN3;
	}

	public String getHJ_TUKJU_GIGAN4() {
		return HJ_TUKJU_GIGAN4;
	}

	public void setHJ_TUKJU_GIGAN4(String hJ_TUKJU_GIGAN4) {
		HJ_TUKJU_GIGAN4 = hJ_TUKJU_GIGAN4;
	}

	public String getHJ_TUKJU_SANGHE_1() {
		return HJ_TUKJU_SANGHE_1;
	}

	public void setHJ_TUKJU_SANGHE_1(String hJ_TUKJU_SANGHE_1) {
		HJ_TUKJU_SANGHE_1 = hJ_TUKJU_SANGHE_1;
	}

	public String getHJ_TUKJU_SANGHE_2() {
		return HJ_TUKJU_SANGHE_2;
	}

	public void setHJ_TUKJU_SANGHE_2(String hJ_TUKJU_SANGHE_2) {
		HJ_TUKJU_SANGHE_2 = hJ_TUKJU_SANGHE_2;
	}

	public String getHJ_TUKJU_SANGHE_GIGAN() {
		return HJ_TUKJU_SANGHE_GIGAN;
	}

	public void setHJ_TUKJU_SANGHE_GIGAN(String hJ_TUKJU_SANGHE_GIGAN) {
		HJ_TUKJU_SANGHE_GIGAN = hJ_TUKJU_SANGHE_GIGAN;
	}

	public String getHJ_TUKJU_SANGHE_GIGAN2() {
		return HJ_TUKJU_SANGHE_GIGAN2;
	}

	public void setHJ_TUKJU_SANGHE_GIGAN2(String hJ_TUKJU_SANGHE_GIGAN2) {
		HJ_TUKJU_SANGHE_GIGAN2 = hJ_TUKJU_SANGHE_GIGAN2;
	}

	public String getHJ_HAL_LEV() {
		return HJ_HAL_LEV;
	}

	public void setHJ_HAL_LEV(String hJ_HAL_LEV) {
		HJ_HAL_LEV = hJ_HAL_LEV;
	}

	public String getHJ_SAK_GIGAN() {
		return HJ_SAK_GIGAN;
	}

	public void setHJ_SAK_GIGAN(String hJ_SAK_GIGAN) {
		HJ_SAK_GIGAN = hJ_SAK_GIGAN;
	}

	public String getJJ_HAL_PRM() {
		return JJ_HAL_PRM;
	}

	public void setJJ_HAL_PRM(String jJ_HAL_PRM) {
		JJ_HAL_PRM = jJ_HAL_PRM;
	}

	public String getHJ_CAR_M() {
		return HJ_CAR_M;
	}

	public void setHJ_CAR_M(String hJ_CAR_M) {
		HJ_CAR_M = hJ_CAR_M;
	}

	public String getHJ_JUKSUNG() {
		return HJ_JUKSUNG;
	}

	public void setHJ_JUKSUNG(String hJ_JUKSUNG) {
		HJ_JUKSUNG = hJ_JUKSUNG;
	}

	public String getJJ_GIUP_CD() {
		return JJ_GIUP_CD;
	}

	public void setJJ_GIUP_CD(String jJ_GIUP_CD) {
		JJ_GIUP_CD = jJ_GIUP_CD;
	}

	public String getHJ_GIUP_NM() {
		return HJ_GIUP_NM;
	}

	public void setHJ_GIUP_NM(String hJ_GIUP_NM) {
		HJ_GIUP_NM = hJ_GIUP_NM;
	}

	public String getHJ_JUKRIP_IYUL() {
		return HJ_JUKRIP_IYUL;
	}

	public void setHJ_JUKRIP_IYUL(String hJ_JUKRIP_IYUL) {
		HJ_JUKRIP_IYUL = hJ_JUKRIP_IYUL;
	}

	public String[] getHJ_DAMBO_NAME() {
		return HJ_DAMBO_NAME;
	}

	public void setHJ_DAMBO_NAME(String[] hJ_DAMBO_NAME) {
		HJ_DAMBO_NAME = hJ_DAMBO_NAME;
	}

	public String[] getJJ_GAIP_GMEK() {
		return JJ_GAIP_GMEK;
	}

	public void setJJ_GAIP_GMEK(String[] jJ_GAIP_GMEK) {
		JJ_GAIP_GMEK = jJ_GAIP_GMEK;
	}

	public String[] getJJ_GIBON_PRM() {
		return JJ_GIBON_PRM;
	}

	public void setJJ_GIBON_PRM(String[] jJ_GIBON_PRM) {
		JJ_GIBON_PRM = jJ_GIBON_PRM;
	}

	public String[] getJJ_DAMBO_CD() {
		return JJ_DAMBO_CD;
	}

	public void setJJ_DAMBO_CD(String[] jJ_DAMBO_CD) {
		JJ_DAMBO_CD = jJ_DAMBO_CD;
	}

	public String[] getJJ_APER_GAIP_GMEK() {
		return JJ_APER_GAIP_GMEK;
	}

	public void setJJ_APER_GAIP_GMEK(String[] jJ_APER_GAIP_GMEK) {
		JJ_APER_GAIP_GMEK = jJ_APER_GAIP_GMEK;
	}

	public String[] getJJ_GENGSIN_YN() {
		return JJ_GENGSIN_YN;
	}

	public void setJJ_GENGSIN_YN(String[] jJ_GENGSIN_YN) {
		JJ_GENGSIN_YN = jJ_GENGSIN_YN;
	}

	public String getHJ_MESSAGE() {
		return HJ_MESSAGE;
	}

	public void setHJ_MESSAGE(String hJ_MESSAGE) {
		HJ_MESSAGE = hJ_MESSAGE;
	}

	public String getJJ_GAJOK_YN() {
		return JJ_GAJOK_YN;
	}

	public void setJJ_GAJOK_YN(String jJ_GAJOK_YN) {
		JJ_GAJOK_YN = jJ_GAJOK_YN;
	}

	public String getJJ_GAJOK_TOT() {
		return JJ_GAJOK_TOT;
	}

	public void setJJ_GAJOK_TOT(String jJ_GAJOK_TOT) {
		JJ_GAJOK_TOT = jJ_GAJOK_TOT;
	}

	public String getJJ_BOJANG_PRM() {
		return JJ_BOJANG_PRM;
	}

	public void setJJ_BOJANG_PRM(String jJ_BOJANG_PRM) {
		JJ_BOJANG_PRM = jJ_BOJANG_PRM;
	}

	public String getJJ_JUKRIP_BUMUN_PRM() {
		return JJ_JUKRIP_BUMUN_PRM;
	}

	public void setJJ_JUKRIP_BUMUN_PRM(String jJ_JUKRIP_BUMUN_PRM) {
		JJ_JUKRIP_BUMUN_PRM = jJ_JUKRIP_BUMUN_PRM;
	}

	public String getJJ_SUM_PRM() {
		return JJ_SUM_PRM;
	}

	public void setJJ_SUM_PRM(String jJ_SUM_PRM) {
		JJ_SUM_PRM = jJ_SUM_PRM;
	}

	public String getJJ_NAPIPHAL_PRM() {
		return JJ_NAPIPHAL_PRM;
	}

	public void setJJ_NAPIPHAL_PRM(String jJ_NAPIPHAL_PRM) {
		JJ_NAPIPHAL_PRM = jJ_NAPIPHAL_PRM;
	}

	public String getJJ_MULGUNL_PRM() {
		return JJ_MULGUNL_PRM;
	}

	public void setJJ_MULGUNL_PRM(String jJ_MULGUNL_PRM) {
		JJ_MULGUNL_PRM = jJ_MULGUNL_PRM;
	}

	public String getJJ_SIGI_GUBUN() {
		return JJ_SIGI_GUBUN;
	}

	public void setJJ_SIGI_GUBUN(String jJ_SIGI_GUBUN) {
		JJ_SIGI_GUBUN = jJ_SIGI_GUBUN;
	}

	public String getJJ_BALGUP_GB() {
		return JJ_BALGUP_GB;
	}

	public void setJJ_BALGUP_GB(String jJ_BALGUP_GB) {
		JJ_BALGUP_GB = jJ_BALGUP_GB;
	}

	public String getHJ_BALGUP_NM() {
		return HJ_BALGUP_NM;
	}

	public void setHJ_BALGUP_NM(String hJ_BALGUP_NM) {
		HJ_BALGUP_NM = hJ_BALGUP_NM;
	}

	public String getHJ_GUCHI_CNT() {
		return HJ_GUCHI_CNT;
	}

	public void setHJ_GUCHI_CNT(String hJ_GUCHI_CNT) {
		HJ_GUCHI_CNT = hJ_GUCHI_CNT;
	}

	public String getJJ_3212_SEQ() {
		return JJ_3212_SEQ;
	}

	public void setJJ_3212_SEQ(String jJ_3212_SEQ) {
		JJ_3212_SEQ = jJ_3212_SEQ;
	}

	public String[] getJJ_3212_YYYY() {
		return JJ_3212_YYYY;
	}

	public void setJJ_3212_YYYY(String[] jJ_3212_YYYY) {
		JJ_3212_YYYY = jJ_3212_YYYY;
	}

	public String[] getJJ_3212_NAPIP_PRM() {
		return JJ_3212_NAPIP_PRM;
	}

	public void setJJ_3212_NAPIP_PRM(String[] jJ_3212_NAPIP_PRM) {
		JJ_3212_NAPIP_PRM = jJ_3212_NAPIP_PRM;
	}

	public String[] getJJ_3212_BALGB_PRM() {
		return JJ_3212_BALGB_PRM;
	}

	public void setJJ_3212_BALGB_PRM(String[] jJ_3212_BALGB_PRM) {
		JJ_3212_BALGB_PRM = jJ_3212_BALGB_PRM;
	}

	public String[] getJJ_3212_NUGYE() {
		return JJ_3212_NUGYE;
	}

	public void setJJ_3212_NUGYE(String[] jJ_3212_NUGYE) {
		JJ_3212_NUGYE = jJ_3212_NUGYE;
	}

	public String[] getJJ_3212_CHAIK() {
		return JJ_3212_CHAIK;
	}

	public void setJJ_3212_CHAIK(String[] jJ_3212_CHAIK) {
		JJ_3212_CHAIK = jJ_3212_CHAIK;
	}

	public String getHJ_SOYU() {
		return HJ_SOYU;
	}

	public void setHJ_SOYU(String hJ_SOYU) {
		HJ_SOYU = hJ_SOYU;
	}

	public String getHJ_CAR() {
		return HJ_CAR;
	}

	public void setHJ_CAR(String hJ_CAR) {
		HJ_CAR = hJ_CAR;
	}

	public String getJJ_GEOMSA() {
		return JJ_GEOMSA;
	}

	public void setJJ_GEOMSA(String jJ_GEOMSA) {
		JJ_GEOMSA = jJ_GEOMSA;
	}

	public String getJJ_283_SU() {
		return JJ_283_SU;
	}

	public void setJJ_283_SU(String jJ_283_SU) {
		JJ_283_SU = jJ_283_SU;
	}

	public String getJJ_GAJOK_SU() {
		return JJ_GAJOK_SU;
	}

	public void setJJ_GAJOK_SU(String jJ_GAJOK_SU) {
		JJ_GAJOK_SU = jJ_GAJOK_SU;
	}

	public String getJJ_GAJOK_JA() {
		return JJ_GAJOK_JA;
	}

	public void setJJ_GAJOK_JA(String jJ_GAJOK_JA) {
		JJ_GAJOK_JA = jJ_GAJOK_JA;
	}

	public String getHJ_JANYU_NAME() {
		return HJ_JANYU_NAME;
	}

	public void setHJ_JANYU_NAME(String hJ_JANYU_NAME) {
		HJ_JANYU_NAME = hJ_JANYU_NAME;
	}

	public String getJJ_JA_JUMIN() {
		return JJ_JA_JUMIN;
	}

	public void setJJ_JA_JUMIN(String jJ_JA_JUMIN) {
		JJ_JA_JUMIN = jJ_JA_JUMIN;
	}

	public String getJJ_PRM_282() {
		return JJ_PRM_282;
	}

	public void setJJ_PRM_282(String jJ_PRM_282) {
		JJ_PRM_282 = jJ_PRM_282;
	}

	public String getJJ_TOUR_FROM() {
		return JJ_TOUR_FROM;
	}

	public void setJJ_TOUR_FROM(String jJ_TOUR_FROM) {
		JJ_TOUR_FROM = jJ_TOUR_FROM;
	}

	public String getJJ_TOUR_TO() {
		return JJ_TOUR_TO;
	}

	public void setJJ_TOUR_TO(String jJ_TOUR_TO) {
		JJ_TOUR_TO = jJ_TOUR_TO;
	}

	public String getHJ_TOUR_NAME() {
		return HJ_TOUR_NAME;
	}

	public void setHJ_TOUR_NAME(String hJ_TOUR_NAME) {
		HJ_TOUR_NAME = hJ_TOUR_NAME;
	}

	public String getHJ_3219_JANYU_NAME() {
		return HJ_3219_JANYU_NAME;
	}

	public void setHJ_3219_JANYU_NAME(String hJ_3219_JANYU_NAME) {
		HJ_3219_JANYU_NAME = hJ_3219_JANYU_NAME;
	}

	public String getJJ_3219_JANYU_YMD() {
		return JJ_3219_JANYU_YMD;
	}

	public void setJJ_3219_JANYU_YMD(String jJ_3219_JANYU_YMD) {
		JJ_3219_JANYU_YMD = jJ_3219_JANYU_YMD;
	}

	public String getJJ_ARMY_WOL() {
		return JJ_ARMY_WOL;
	}

	public void setJJ_ARMY_WOL(String jJ_ARMY_WOL) {
		JJ_ARMY_WOL = jJ_ARMY_WOL;
	}

	public String getHJ_SO_NM() {
		return HJ_SO_NM;
	}

	public void setHJ_SO_NM(String hJ_SO_NM) {
		HJ_SO_NM = hJ_SO_NM;
	}

	public String getJJ_SO_JUMIN() {
		return JJ_SO_JUMIN;
	}

	public void setJJ_SO_JUMIN(String jJ_SO_JUMIN) {
		JJ_SO_JUMIN = jJ_SO_JUMIN;
	}

	public String getJJ_SO_ZIP() {
		return JJ_SO_ZIP;
	}

	public void setJJ_SO_ZIP(String jJ_SO_ZIP) {
		JJ_SO_ZIP = jJ_SO_ZIP;
	}

	public String getHJ_SO_ADDR() {
		return HJ_SO_ADDR;
	}

	public void setHJ_SO_ADDR(String hJ_SO_ADDR) {
		HJ_SO_ADDR = hJ_SO_ADDR;
	}

	public String getHJ_SO_GITA() {
		return HJ_SO_GITA;
	}

	public void setHJ_SO_GITA(String hJ_SO_GITA) {
		HJ_SO_GITA = hJ_SO_GITA;
	}

	public String getJJ_JOB_JIK() {
		return JJ_JOB_JIK;
	}

	public void setJJ_JOB_JIK(String jJ_JOB_JIK) {
		JJ_JOB_JIK = jJ_JOB_JIK;
	}

	public String getJJ_YOYUL_JIK() {
		return JJ_YOYUL_JIK;
	}

	public void setJJ_YOYUL_JIK(String jJ_YOYUL_JIK) {
		JJ_YOYUL_JIK = jJ_YOYUL_JIK;
	}

	public String getJJ_GUJO_GBSU() {
		return JJ_GUJO_GBSU;
	}

	public void setJJ_GUJO_GBSU(String jJ_GUJO_GBSU) {
		JJ_GUJO_GBSU = jJ_GUJO_GBSU;
	}

	public String[] getJJ_MOKJUK() {
		return JJ_MOKJUK;
	}

	public void setJJ_MOKJUK(String[] jJ_MOKJUK) {
		JJ_MOKJUK = jJ_MOKJUK;
	}

	public String[] getJJ_MOKJUK_GBSU() {
		return JJ_MOKJUK_GBSU;
	}

	public void setJJ_MOKJUK_GBSU(String[] jJ_MOKJUK_GBSU) {
		JJ_MOKJUK_GBSU = jJ_MOKJUK_GBSU;
	}

	public String[] getJJ_MYUNJUK() {
		return JJ_MYUNJUK;
	}

	public void setJJ_MYUNJUK(String[] jJ_MYUNJUK) {
		JJ_MYUNJUK = jJ_MYUNJUK;
	}

	public String[] getJJ_GAIP() {
		return JJ_GAIP;
	}

	public void setJJ_GAIP(String[] jJ_GAIP) {
		JJ_GAIP = jJ_GAIP;
	}

	public String[] getJJ_PRM() {
		return JJ_PRM;
	}

	public void setJJ_PRM(String[] jJ_PRM) {
		JJ_PRM = jJ_PRM;
	}

	public String[] getHJ_GUJO() {
		return HJ_GUJO;
	}

	public void setHJ_GUJO(String[] hJ_GUJO) {
		HJ_GUJO = hJ_GUJO;
	}

	public String getHJ_SUYONG1() {
		return HJ_SUYONG1;
	}

	public void setHJ_SUYONG1(String hJ_SUYONG1) {
		HJ_SUYONG1 = hJ_SUYONG1;
	}

	public String getHJ_SUYONG2() {
		return HJ_SUYONG2;
	}

	public void setHJ_SUYONG2(String hJ_SUYONG2) {
		HJ_SUYONG2 = hJ_SUYONG2;
	}

	public String getUU_BESU_SEQ() {
		return UU_BESU_SEQ;
	}

	public void setUU_BESU_SEQ(String uU_BESU_SEQ) {
		UU_BESU_SEQ = uU_BESU_SEQ;
	}

	public String getHJ_JIGP_NM() {
		return HJ_JIGP_NM;
	}

	public void setHJ_JIGP_NM(String hJ_JIGP_NM) {
		HJ_JIGP_NM = hJ_JIGP_NM;
	}

	public static String getProid() {
		return proid;
	}

	public static String getTrid() {
		return trid;
	}

	public String getCC_COND_CD() {
		return CC_COND_CD;
	}

	public void setCC_COND_CD(String cC_COND_CD) {
		CC_COND_CD = cC_COND_CD;
	}
}
