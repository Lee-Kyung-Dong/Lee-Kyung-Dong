package com.idongbu.smartcustomer.vo;

import java.util.List;
import java.util.Map;

import com.idongbu.common.vo.CMMVO;

//약관대출가능조회
public class CmmFUC2113RVO  extends CMMVO{
	
	public CmmFUC2113RVO() {
		super.setPGMID(proid);
		super.setTRID(trid);
	}
	
	private final static String proid		= "FUC2113R";
	private final static String trid		= "UCLA";
	
	//CC-HEAD.
	private String CC_CHANNEL		= "";
	private String CC_UKEY		= "";
	private String CC_PGMID		= "";
	private String CC_PROC_GB		= "";
	private String CC_FUN_KEY		= "";
	
	//CC-SAWON-NO.
	private String CC_USER_GB		= "";
	private String CC_USER_CD		= "";
	
	
	//CC-JIJUM.
	private String CC_JIJUM_CD		= "";
	private String CC_JIBU_CD		= "";
	
	private String CC_PROTOCOL		= "";
	private String CC_COND_CD		= "";
	private String CC_LAST_FLAG		= "";
	private String CC_CURSOR_MAP		= "";
	private String CC_CURSOR_IDX		= "";
	private String CC_MESSAGE_CD		= "";
	private String HC_MESSAGE_NM		= "";
	private String CC_SYS_ERR		= "";
	private String CC_TS_ITEM		= "";
	private String CC_FORM_ID		= "";
	private String CC_PRT_GB		= "";
	private String CC_FILLER		= "";
	
	//JJ-SCREEN-DATA.
	private String JJ_JIJUM		= "";
	private String HJ_JIJUM 		= "";
	
	private String JJ_SAWON		= "";
	private String HJ_SAWON 		= "";
	
	private String JJ_PASSWORD		= "";
	private String JJ_JUMIN_NO		= "";
	private String HJ_GY_NM		= "";
	private String JJ_GUBUN		= "";
	private String JJ_DATE		= "";
	
	//JJ_LIST_AREA              
//	private String[] JJ_SUNTAK		= new String[0]; // 10
//	private String[] JJ_POLI_NO 		= new String[0]; // 10
//	private String[] JJ_DE_DATE		= new String[0]; // 10
//	private String[] HJ_SUGUM		= new String[0]; // 10
//	private String[] HJ_ICHE 		= new String[0]; // 10
//	private String[] HJ_BANK		= new String[0]; // 10
//	private String[] HJ_YEGMJU1		= new String[0]; // 10
//	private String[] JJ_GYEJWA  		= new String[0]; // 10
//	private String[] HJ_JE_CG		= new String[0]; // 10
	
	private String JJ_SUNTAK1 		= "";
	private String HJ_SUGUM_NM 		= "";
	private String HJ_ICHE_NM		= "";
	private String HJ_BANK_NM		= "";
	private String HJ_YEGMJU_NM		= "";
	private String JJ_GYEJWA_NO		= "";
	private String JJ_YEGMJU2 		= "";
	//JJ_TAIL.
	private String JJ_SUGUM		= "";
	private String HJ_SUGUM1 		= "";
	private String JJ_BANK 		= "";
	private String HJ_BANK1 		= "";
	private String JJ_GYEJWA1 		= "";
	private String JJ_YEGMJU		= "";
	private String HJ_YEGMJU		= "";
	private String HJ_YEGMJU2    		= "";
	private String JJ_YE_JUMIN		= "";
	private String JJ_YEGMJU_TEL		= "";
	private String JJ_ICHE 		= "";
	private String JJ_JUKY_YM		= "";
	private String JJ_VIS_CD		= "";
	
	//UU_USER_DEFINE_DATA.
	private String UU_JUMIN_NO		= "";
	
	//UUC_CURRENT_KEY.
	private String UUC_INQ_POLI_NO		= "";
	private String UUC_INQ_YMD		= "";
	private String UUC_INQ_HMS		= "";
	
	//UUC_FIRST_KEY.
	private String UUC_F_POLI_NO 		= "";
	private String UUC_F_YMD		= "";
	private String UUC_F_HMS		= "";
	
	//UUC_LAST_KEY..
	private String UUC_L_POLI_NO 		= "";
	private String UUC_L_YMD		= "";
	private String UUC_L_HMS		= "";	
	
	private List<Map<String,String>> loopData = null;	//2차때 []형태 vo을 list에 담음
	
	// 추가필드
//	private String[] JJ_NAPIP_YMD = new String[0];	// 최종이자수납일
//	private String[] HJ_BJ_NM = new String[0];       // 보종명
	
	public String getProid() {
		return proid;
	}
	public String getTrid() {
		return trid;
	}
	public String getCC_CHANNEL() {
		return CC_CHANNEL;
	}
	public void setCC_CHANNEL(String cC_CHANNEL) {
		CC_CHANNEL = cC_CHANNEL;
	}
	public String getCC_UKEY() {
		return CC_UKEY;
	}
	public void setCC_UKEY(String cC_UKEY) {
		CC_UKEY = cC_UKEY;
	}
	public String getCC_PGMID() {
		return CC_PGMID;
	}
	public void setCC_PGMID(String cC_PGMID) {
		CC_PGMID = cC_PGMID;
	}
	public String getCC_PROC_GB() {
		return CC_PROC_GB;
	}
	public void setCC_PROC_GB(String cC_PROC_GB) {
		CC_PROC_GB = cC_PROC_GB;
	}
	public String getCC_FUN_KEY() {
		return CC_FUN_KEY;
	}
	public void setCC_FUN_KEY(String cC_FUN_KEY) {
		CC_FUN_KEY = cC_FUN_KEY;
	}
	public String getCC_USER_GB() {
		return CC_USER_GB;
	}
	public void setCC_USER_GB(String cC_USER_GB) {
		CC_USER_GB = cC_USER_GB;
	}
	public String getCC_USER_CD() {
		return CC_USER_CD;
	}
	public void setCC_USER_CD(String cC_USER_CD) {
		CC_USER_CD = cC_USER_CD;
	}
	public String getCC_JIJUM_CD() {
		return CC_JIJUM_CD;
	}
	public void setCC_JIJUM_CD(String cC_JIJUM_CD) {
		CC_JIJUM_CD = cC_JIJUM_CD;
	}
	public String getCC_JIBU_CD() {
		return CC_JIBU_CD;
	}
	public void setCC_JIBU_CD(String cC_JIBU_CD) {
		CC_JIBU_CD = cC_JIBU_CD;
	}
	public String getCC_PROTOCOL() {
		return CC_PROTOCOL;
	}
	public void setCC_PROTOCOL(String cC_PROTOCOL) {
		CC_PROTOCOL = cC_PROTOCOL;
	}
	public String getCC_COND_CD() {
		return CC_COND_CD;
	}
	public void setCC_COND_CD(String cC_COND_CD) {
		CC_COND_CD = cC_COND_CD;
	}
	public String getCC_LAST_FLAG() {
		return CC_LAST_FLAG;
	}
	public void setCC_LAST_FLAG(String cC_LAST_FLAG) {
		CC_LAST_FLAG = cC_LAST_FLAG;
	}
	public String getCC_CURSOR_MAP() {
		return CC_CURSOR_MAP;
	}
	public void setCC_CURSOR_MAP(String cC_CURSOR_MAP) {
		CC_CURSOR_MAP = cC_CURSOR_MAP;
	}
	public String getCC_CURSOR_IDX() {
		return CC_CURSOR_IDX;
	}
	public void setCC_CURSOR_IDX(String cC_CURSOR_IDX) {
		CC_CURSOR_IDX = cC_CURSOR_IDX;
	}
	public String getCC_MESSAGE_CD() {
		return CC_MESSAGE_CD;
	}
	public void setCC_MESSAGE_CD(String cC_MESSAGE_CD) {
		CC_MESSAGE_CD = cC_MESSAGE_CD;
	}
	public String getHC_MESSAGE_NM() {
		return HC_MESSAGE_NM;
	}
	public void setHC_MESSAGE_NM(String hC_MESSAGE_NM) {
		HC_MESSAGE_NM = hC_MESSAGE_NM;
	}
	public String getCC_SYS_ERR() {
		return CC_SYS_ERR;
	}
	public void setCC_SYS_ERR(String cC_SYS_ERR) {
		CC_SYS_ERR = cC_SYS_ERR;
	}
	public String getCC_TS_ITEM() {
		return CC_TS_ITEM;
	}
	public void setCC_TS_ITEM(String cC_TS_ITEM) {
		CC_TS_ITEM = cC_TS_ITEM;
	}
	public String getCC_FORM_ID() {
		return CC_FORM_ID;
	}
	public void setCC_FORM_ID(String cC_FORM_ID) {
		CC_FORM_ID = cC_FORM_ID;
	}
	public String getCC_PRT_GB() {
		return CC_PRT_GB;
	}
	public void setCC_PRT_GB(String cC_PRT_GB) {
		CC_PRT_GB = cC_PRT_GB;
	}
	public String getCC_FILLER() {
		return CC_FILLER;
	}
	public void setCC_FILLER(String cC_FILLER) {
		CC_FILLER = cC_FILLER;
	}
	public String getJJ_JIJUM() {
		return JJ_JIJUM;
	}
	public void setJJ_JIJUM(String jJ_JIJUM) {
		JJ_JIJUM = jJ_JIJUM;
	}
	public String getHJ_JIJUM() {
		return HJ_JIJUM;
	}
	public void setHJ_JIJUM(String hJ_JIJUM) {
		HJ_JIJUM = hJ_JIJUM;
	}
	public String getJJ_SAWON() {
		return JJ_SAWON;
	}
	public void setJJ_SAWON(String jJ_SAWON) {
		JJ_SAWON = jJ_SAWON;
	}
	public String getHJ_SAWON() {
		return HJ_SAWON;
	}
	public void setHJ_SAWON(String hJ_SAWON) {
		HJ_SAWON = hJ_SAWON;
	}
	public String getJJ_PASSWORD() {
		return JJ_PASSWORD;
	}
	public void setJJ_PASSWORD(String jJ_PASSWORD) {
		JJ_PASSWORD = jJ_PASSWORD;
	}
	public String getJJ_JUMIN_NO() {
		return JJ_JUMIN_NO;
	}
	public void setJJ_JUMIN_NO(String jJ_JUMIN_NO) {
		JJ_JUMIN_NO = jJ_JUMIN_NO;
	}
	public String getHJ_GY_NM() {
		return HJ_GY_NM;
	}
	public void setHJ_GY_NM(String hJ_GY_NM) {
		HJ_GY_NM = hJ_GY_NM;
	}
	public String getJJ_GUBUN() {
		return JJ_GUBUN;
	}
	public void setJJ_GUBUN(String jJ_GUBUN) {
		JJ_GUBUN = jJ_GUBUN;
	}
	public String getJJ_DATE() {
		return JJ_DATE;
	}
	public void setJJ_DATE(String jJ_DATE) {
		JJ_DATE = jJ_DATE;
	}
	public String getJJ_SUNTAK1() {
		return JJ_SUNTAK1;
	}
	public void setJJ_SUNTAK1(String jJ_SUNTAK1) {
		JJ_SUNTAK1 = jJ_SUNTAK1;
	}
	public String getHJ_SUGUM_NM() {
		return HJ_SUGUM_NM;
	}
	public void setHJ_SUGUM_NM(String hJ_SUGUM_NM) {
		HJ_SUGUM_NM = hJ_SUGUM_NM;
	}
	public String getHJ_ICHE_NM() {
		return HJ_ICHE_NM;
	}
	public void setHJ_ICHE_NM(String hJ_ICHE_NM) {
		HJ_ICHE_NM = hJ_ICHE_NM;
	}
	public String getHJ_BANK_NM() {
		return HJ_BANK_NM;
	}
	public void setHJ_BANK_NM(String hJ_BANK_NM) {
		HJ_BANK_NM = hJ_BANK_NM;
	}
	public String getHJ_YEGMJU_NM() {
		return HJ_YEGMJU_NM;
	}
	public void setHJ_YEGMJU_NM(String hJ_YEGMJU_NM) {
		HJ_YEGMJU_NM = hJ_YEGMJU_NM;
	}
	public String getJJ_GYEJWA_NO() {
		return JJ_GYEJWA_NO;
	}
	public void setJJ_GYEJWA_NO(String jJ_GYEJWA_NO) {
		JJ_GYEJWA_NO = jJ_GYEJWA_NO;
	}
	public String getJJ_YEGMJU2() {
		return JJ_YEGMJU2;
	}
	public void setJJ_YEGMJU2(String jJ_YEGMJU2) {
		JJ_YEGMJU2 = jJ_YEGMJU2;
	}
	public String getJJ_SUGUM() {
		return JJ_SUGUM;
	}
	public void setJJ_SUGUM(String jJ_SUGUM) {
		JJ_SUGUM = jJ_SUGUM;
	}
	public String getHJ_SUGUM1() {
		return HJ_SUGUM1;
	}
	public void setHJ_SUGUM1(String hJ_SUGUM1) {
		HJ_SUGUM1 = hJ_SUGUM1;
	}
	public String getJJ_BANK() {
		return JJ_BANK;
	}
	public void setJJ_BANK(String jJ_BANK) {
		JJ_BANK = jJ_BANK;
	}
	public String getHJ_BANK1() {
		return HJ_BANK1;
	}
	public void setHJ_BANK1(String hJ_BANK1) {
		HJ_BANK1 = hJ_BANK1;
	}
	public String getJJ_GYEJWA1() {
		return JJ_GYEJWA1;
	}
	public void setJJ_GYEJWA1(String jJ_GYEJWA1) {
		JJ_GYEJWA1 = jJ_GYEJWA1;
	}
	public String getJJ_YEGMJU() {
		return JJ_YEGMJU;
	}
	public void setJJ_YEGMJU(String jJ_YEGMJU) {
		JJ_YEGMJU = jJ_YEGMJU;
	}
	public String getHJ_YEGMJU() {
		return HJ_YEGMJU;
	}
	public void setHJ_YEGMJU(String hJ_YEGMJU) {
		HJ_YEGMJU = hJ_YEGMJU;
	}
	public String getHJ_YEGMJU2() {
		return HJ_YEGMJU2;
	}
	public void setHJ_YEGMJU2(String hJ_YEGMJU2) {
		HJ_YEGMJU2 = hJ_YEGMJU2;
	}
	public String getJJ_YE_JUMIN() {
		return JJ_YE_JUMIN;
	}
	public void setJJ_YE_JUMIN(String jJ_YE_JUMIN) {
		JJ_YE_JUMIN = jJ_YE_JUMIN;
	}
	public String getJJ_YEGMJU_TEL() {
		return JJ_YEGMJU_TEL;
	}
	public void setJJ_YEGMJU_TEL(String jJ_YEGMJU_TEL) {
		JJ_YEGMJU_TEL = jJ_YEGMJU_TEL;
	}
	public String getJJ_ICHE() {
		return JJ_ICHE;
	}
	public void setJJ_ICHE(String jJ_ICHE) {
		JJ_ICHE = jJ_ICHE;
	}
	public String getJJ_JUKY_YM() {
		return JJ_JUKY_YM;
	}
	public void setJJ_JUKY_YM(String jJ_JUKY_YM) {
		JJ_JUKY_YM = jJ_JUKY_YM;
	}
	public String getJJ_VIS_CD() {
		return JJ_VIS_CD;
	}
	public void setJJ_VIS_CD(String jJ_VIS_CD) {
		JJ_VIS_CD = jJ_VIS_CD;
	}
	public String getUU_JUMIN_NO() {
		return UU_JUMIN_NO;
	}
	public void setUU_JUMIN_NO(String uU_JUMIN_NO) {
		UU_JUMIN_NO = uU_JUMIN_NO;
	}
	public String getUUC_INQ_POLI_NO() {
		return UUC_INQ_POLI_NO;
	}
	public void setUUC_INQ_POLI_NO(String uUC_INQ_POLI_NO) {
		UUC_INQ_POLI_NO = uUC_INQ_POLI_NO;
	}
	public String getUUC_INQ_YMD() {
		return UUC_INQ_YMD;
	}
	public void setUUC_INQ_YMD(String uUC_INQ_YMD) {
		UUC_INQ_YMD = uUC_INQ_YMD;
	}
	public String getUUC_INQ_HMS() {
		return UUC_INQ_HMS;
	}
	public void setUUC_INQ_HMS(String uUC_INQ_HMS) {
		UUC_INQ_HMS = uUC_INQ_HMS;
	}
	public String getUUC_F_POLI_NO() {
		return UUC_F_POLI_NO;
	}
	public void setUUC_F_POLI_NO(String uUC_F_POLI_NO) {
		UUC_F_POLI_NO = uUC_F_POLI_NO;
	}
	public String getUUC_F_YMD() {
		return UUC_F_YMD;
	}
	public void setUUC_F_YMD(String uUC_F_YMD) {
		UUC_F_YMD = uUC_F_YMD;
	}
	public String getUUC_F_HMS() {
		return UUC_F_HMS;
	}
	public void setUUC_F_HMS(String uUC_F_HMS) {
		UUC_F_HMS = uUC_F_HMS;
	}
	public String getUUC_L_POLI_NO() {
		return UUC_L_POLI_NO;
	}
	public void setUUC_L_POLI_NO(String uUC_L_POLI_NO) {
		UUC_L_POLI_NO = uUC_L_POLI_NO;
	}
	public String getUUC_L_YMD() {
		return UUC_L_YMD;
	}
	public void setUUC_L_YMD(String uUC_L_YMD) {
		UUC_L_YMD = uUC_L_YMD;
	}
	public String getUUC_L_HMS() {
		return UUC_L_HMS;
	}
	public void setUUC_L_HMS(String uUC_L_HMS) {
		UUC_L_HMS = uUC_L_HMS;
	}
	public List<Map<String, String>> getLoopData() {
		return loopData;
	}
	public void setLoopData(List<Map<String, String>> loopData) {
		this.loopData = loopData;
	}
		
	
}