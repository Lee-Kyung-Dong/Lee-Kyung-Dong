package com.idongbu.smartcustomer.vo;

import com.idongbu.common.vo.CMMVO;

public class CmmFRH0009RVO extends CMMVO {

	public CmmFRH0009RVO() {
		super.setPGMID(this.proid);
		super.setTRID(this.trid);
	}	
	
	private static final String proid = "FRH0009R";        
	private static final String trid  = "RH08";                    
	private String rURL			      = "";
	                                                                     
	private String CC_CHANNEL		  = "";
	private String CC_UKEY			  = "";
	private String CC_PGMID			  = "";
	private String CC_PROC_GB		  = "";
	private String CC_FUN_KEY		  = "";
	private String CC_USER_GB		  = "";
	private String CC_USER_CD		  = "";
	private String CC_JIJUM_CD		  = "";
	private String CC_JIBU_CD		  = "";
	private String CC_PROTOCOL		  = "";
	private String CC_COND_CD		  = "";
	private String CC_LAST_FLAG		  = "";
	private String CC_CURSOR_MAP	  = "";
	private String CC_CURSOR_IDX	  = "";
	private String CC_MESSAGE_CD	  = "";
	private String HC_MESSAGE_NM	  = "";
	private String CC_SYS_ERR		  = "";
	private String CC_FILLER		  = "";
	                                  
	private String SS_DAMDANGJA		  = "";
	private String HS_BOSANG_BR		  = "";
	private String HS_BOSANG_TEAM	  = "";
	private String HS_DAMDANGJA_NM	  = "";
	private String HS_JIKCHEK		  = "";
	private String SS_TEL			  = "";
	private String SS_HANDPHONE_NO	  = "";
	private String SS_FAX_NO		  = "";
	private String SS_EMAIL			  = "";
	private String HS_DAERIJUM_NM	  = "";
	private String HS_BANK_NM		  = "";
	private String SS_ACCT_NO		  = "";
	
	public String getrURL() {
		return rURL;
	}
	public void setrURL(String rURL) {
		this.rURL = rURL;
	}
	public String getCC_CHANNEL() {
		return CC_CHANNEL;
	}
	public void setCC_CHANNEL(String cC_CHANNEL) {
		CC_CHANNEL = cC_CHANNEL;
	}
	public String getCC_UKEY() {
		return CC_UKEY;
	}
	public void setCC_UKEY(String cC_UKEY) {
		CC_UKEY = cC_UKEY;
	}
	public String getCC_PGMID() {
		return CC_PGMID;
	}
	public void setCC_PGMID(String cC_PGMID) {
		CC_PGMID = cC_PGMID;
	}
	public String getCC_PROC_GB() {
		return CC_PROC_GB;
	}
	public void setCC_PROC_GB(String cC_PROC_GB) {
		CC_PROC_GB = cC_PROC_GB;
	}
	public String getCC_FUN_KEY() {
		return CC_FUN_KEY;
	}
	public void setCC_FUN_KEY(String cC_FUN_KEY) {
		CC_FUN_KEY = cC_FUN_KEY;
	}
	public String getCC_USER_GB() {
		return CC_USER_GB;
	}
	public void setCC_USER_GB(String cC_USER_GB) {
		CC_USER_GB = cC_USER_GB;
	}
	public String getCC_USER_CD() {
		return CC_USER_CD;
	}
	public void setCC_USER_CD(String cC_USER_CD) {
		CC_USER_CD = cC_USER_CD;
	}
	public String getCC_JIJUM_CD() {
		return CC_JIJUM_CD;
	}
	public void setCC_JIJUM_CD(String cC_JIJUM_CD) {
		CC_JIJUM_CD = cC_JIJUM_CD;
	}
	public String getCC_JIBU_CD() {
		return CC_JIBU_CD;
	}
	public void setCC_JIBU_CD(String cC_JIBU_CD) {
		CC_JIBU_CD = cC_JIBU_CD;
	}
	public String getCC_PROTOCOL() {
		return CC_PROTOCOL;
	}
	public void setCC_PROTOCOL(String cC_PROTOCOL) {
		CC_PROTOCOL = cC_PROTOCOL;
	}
	public String getCC_COND_CD() {
		return CC_COND_CD;
	}
	public void setCC_COND_CD(String cC_COND_CD) {
		CC_COND_CD = cC_COND_CD;
	}
	public String getCC_LAST_FLAG() {
		return CC_LAST_FLAG;
	}
	public void setCC_LAST_FLAG(String cC_LAST_FLAG) {
		CC_LAST_FLAG = cC_LAST_FLAG;
	}
	public String getCC_CURSOR_MAP() {
		return CC_CURSOR_MAP;
	}
	public void setCC_CURSOR_MAP(String cC_CURSOR_MAP) {
		CC_CURSOR_MAP = cC_CURSOR_MAP;
	}
	public String getCC_CURSOR_IDX() {
		return CC_CURSOR_IDX;
	}
	public void setCC_CURSOR_IDX(String cC_CURSOR_IDX) {
		CC_CURSOR_IDX = cC_CURSOR_IDX;
	}
	public String getCC_MESSAGE_CD() {
		return CC_MESSAGE_CD;
	}
	public void setCC_MESSAGE_CD(String cC_MESSAGE_CD) {
		CC_MESSAGE_CD = cC_MESSAGE_CD;
	}
	public String getHC_MESSAGE_NM() {
		return HC_MESSAGE_NM;
	}
	public void setHC_MESSAGE_NM(String hC_MESSAGE_NM) {
		HC_MESSAGE_NM = hC_MESSAGE_NM;
	}
	public String getCC_SYS_ERR() {
		return CC_SYS_ERR;
	}
	public void setCC_SYS_ERR(String cC_SYS_ERR) {
		CC_SYS_ERR = cC_SYS_ERR;
	}
	public String getCC_FILLER() {
		return CC_FILLER;
	}
	public void setCC_FILLER(String cC_FILLER) {
		CC_FILLER = cC_FILLER;
	}
	public String getSS_DAMDANGJA() {
		return SS_DAMDANGJA;
	}
	public void setSS_DAMDANGJA(String sS_DAMDANGJA) {
		SS_DAMDANGJA = sS_DAMDANGJA;
	}
	public String getHS_BOSANG_BR() {
		return HS_BOSANG_BR;
	}
	public void setHS_BOSANG_BR(String hS_BOSANG_BR) {
		HS_BOSANG_BR = hS_BOSANG_BR;
	}
	public String getHS_BOSANG_TEAM() {
		return HS_BOSANG_TEAM;
	}
	public void setHS_BOSANG_TEAM(String hS_BOSANG_TEAM) {
		HS_BOSANG_TEAM = hS_BOSANG_TEAM;
	}
	public String getHS_DAMDANGJA_NM() {
		return HS_DAMDANGJA_NM;
	}
	public void setHS_DAMDANGJA_NM(String hS_DAMDANGJA_NM) {
		HS_DAMDANGJA_NM = hS_DAMDANGJA_NM;
	}
	public String getHS_JIKCHEK() {
		return HS_JIKCHEK;
	}
	public void setHS_JIKCHEK(String hS_JIKCHEK) {
		HS_JIKCHEK = hS_JIKCHEK;
	}
	public String getSS_TEL() {
		return SS_TEL;
	}
	public void setSS_TEL(String sS_TEL) {
		SS_TEL = sS_TEL;
	}
	public String getSS_HANDPHONE_NO() {
		return SS_HANDPHONE_NO;
	}
	public void setSS_HANDPHONE_NO(String sS_HANDPHONE_NO) {
		SS_HANDPHONE_NO = sS_HANDPHONE_NO;
	}
	public String getSS_FAX_NO() {
		return SS_FAX_NO;
	}
	public void setSS_FAX_NO(String sS_FAX_NO) {
		SS_FAX_NO = sS_FAX_NO;
	}
	public String getSS_EMAIL() {
		return SS_EMAIL;
	}
	public void setSS_EMAIL(String sS_EMAIL) {
		SS_EMAIL = sS_EMAIL;
	}
	public String getHS_DAERIJUM_NM() {
		return HS_DAERIJUM_NM;
	}
	public void setHS_DAERIJUM_NM(String hS_DAERIJUM_NM) {
		HS_DAERIJUM_NM = hS_DAERIJUM_NM;
	}
	public String getHS_BANK_NM() {
		return HS_BANK_NM;
	}
	public void setHS_BANK_NM(String hS_BANK_NM) {
		HS_BANK_NM = hS_BANK_NM;
	}
	public String getSS_ACCT_NO() {
		return SS_ACCT_NO;
	}
	public void setSS_ACCT_NO(String sS_ACCT_NO) {
		SS_ACCT_NO = sS_ACCT_NO;
	}
	public static String getProid() {
		return proid;
	}
	public static String getTrid() {
		return trid;
	}	
}
