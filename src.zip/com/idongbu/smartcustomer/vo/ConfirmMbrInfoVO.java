package com.idongbu.smartcustomer.vo;

/************************************************************************************************
기능명 : (관리자) 계약관리> 고객정보정제 카운트
설  명 :

수정일		수정자		내 용
----------	--------	-------
************************************************************************************************/
public class ConfirmMbrInfoVO{
	
	/**
	 * 목록화면
	 */
	public String seq_no                      	= "";
	public String fd_mb_name              		= "";
	public String fd_mb_jumin         			= "";
	public String gubun      					= "";	// C: 신규, R: 확인, U: 변경
	public String create_date          			= "";
	public String update_date         			= "";
	
	public String item001      					= "";	// 자택주소
	public String item002      					= "";	// 자택전화
	public String item003      					= "";	// 휴대폰
	public String item004      					= "";	// EMAIL
	public String item005      					= "";	// Reserved
	public String item006      					= "";	// Reserved
	public String item007      					= "";	// Reserved
	public String item008      					= "";	// Reserved
	public String item009      					= "";	// Reserved
	public String item010      					= "";	// Reserved			
	public String input_path_name        		= "";	// 입력(유입) 경록 예) 계약조회, 대출목록화면

	/**
	 * 통계화면
	 */
	public String sum1                      	= "";	// 자택주소
	public String sum2                  		= "";	// 자택전화
	public String sum3              			= "";	// 휴대폰
	public String sum4         					= "";	// EMAIL
	public String cnt1      					= "";	// 고객수
	public String rowcnt      					= "";	// 데이터건수	
	
	/**
	 * 공통 (검색조건)
	 */
	public String from_date                   	= "";  	// 검색조건 시작날짜
	public String to_date                     	= "";  	// 검색조건 종료날짜
	public String getSeq_no() {
		return seq_no;
	}
	public void setSeq_no(String seq_no) {
		this.seq_no = seq_no;
	}
	public String getFd_mb_name() {
		return fd_mb_name;
	}
	public void setFd_mb_name(String fd_mb_name) {
		this.fd_mb_name = fd_mb_name;
	}
	public String getFd_mb_jumin() {
		return fd_mb_jumin;
	}
	public void setFd_mb_jumin(String fd_mb_jumin) {
		this.fd_mb_jumin = fd_mb_jumin;
	}
	public String getGubun() {
		return gubun;
	}
	public void setGubun(String gubun) {
		this.gubun = gubun;
	}
	public String getCreate_date() {
		return create_date;
	}
	public void setCreate_date(String create_date) {
		this.create_date = create_date;
	}
	public String getUpdate_date() {
		return update_date;
	}
	public void setUpdate_date(String update_date) {
		this.update_date = update_date;
	}
	public String getItem001() {
		return item001;
	}
	public void setItem001(String item001) {
		this.item001 = item001;
	}
	public String getItem002() {
		return item002;
	}
	public void setItem002(String item002) {
		this.item002 = item002;
	}
	public String getItem003() {
		return item003;
	}
	public void setItem003(String item003) {
		this.item003 = item003;
	}
	public String getItem004() {
		return item004;
	}
	public void setItem004(String item004) {
		this.item004 = item004;
	}
	public String getItem005() {
		return item005;
	}
	public void setItem005(String item005) {
		this.item005 = item005;
	}
	public String getItem006() {
		return item006;
	}
	public void setItem006(String item006) {
		this.item006 = item006;
	}
	public String getItem007() {
		return item007;
	}
	public void setItem007(String item007) {
		this.item007 = item007;
	}
	public String getItem008() {
		return item008;
	}
	public void setItem008(String item008) {
		this.item008 = item008;
	}
	public String getItem009() {
		return item009;
	}
	public void setItem009(String item009) {
		this.item009 = item009;
	}
	public String getItem010() {
		return item010;
	}
	public void setItem010(String item010) {
		this.item010 = item010;
	}
	public String getInput_path_name() {
		return input_path_name;
	}
	public void setInput_path_name(String input_path_name) {
		this.input_path_name = input_path_name;
	}
	public String getSum1() {
		return sum1;
	}
	public void setSum1(String sum1) {
		this.sum1 = sum1;
	}
	public String getSum2() {
		return sum2;
	}
	public void setSum2(String sum2) {
		this.sum2 = sum2;
	}
	public String getSum3() {
		return sum3;
	}
	public void setSum3(String sum3) {
		this.sum3 = sum3;
	}
	public String getSum4() {
		return sum4;
	}
	public void setSum4(String sum4) {
		this.sum4 = sum4;
	}
	public String getCnt1() {
		return cnt1;
	}
	public void setCnt1(String cnt1) {
		this.cnt1 = cnt1;
	}
	public String getRowcnt() {
		return rowcnt;
	}
	public void setRowcnt(String rowcnt) {
		this.rowcnt = rowcnt;
	}
	public String getFrom_date() {
		return from_date;
	}
	public void setFrom_date(String from_date) {
		this.from_date = from_date;
	}
	public String getTo_date() {
		return to_date;
	}
	public void setTo_date(String to_date) {
		this.to_date = to_date;
	}
}