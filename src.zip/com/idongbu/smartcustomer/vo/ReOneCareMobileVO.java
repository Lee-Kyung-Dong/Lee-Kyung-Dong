package com.idongbu.smartcustomer.vo;

import java.util.List;
import java.util.Map;

import com.idongbu.common.vo.CMMVO;

public class ReOneCareMobileVO extends CMMVO {

	private String JUBSU_NO	     = ""; // 접수번호
	private String MOKJUK_SEQ    = ""; // 서열
	private String PIBO_NM	     = ""; // 피보험자명
	private String PIBO_JUMIN_NO = ""; // 피보험자 주민번호
	private String JINHANG_STAT  = ""; // 진행상태 
	private String JONGGYUL_YMD  = ""; // 종결일
	private String DAMDANGJA	 = ""; // 담당자
	private String OFF_TEL_NO    = ""; // 담당자 사무실 전화번호
	private String TEL_NO     	 = ""; // 담당자 전화번호
	private String GYULJUNG_AMT	 = ""; // 결정보험금
	private String SAGO_YMD      = ""; // 사고일자
		                               
	// 전송건수                        
	private String reg_dt		 = ""; // 제출일자
	private String cnt			 = ""; // 전송건수
	
	private String pdc_nm		 = ""; // 상품명
	private String plhd_nm		 = ""; // 계약자
	private String askg_typ		 = ""; // 청구유형
	private String accd_rpt_dt	 = ""; // 접수일
	private String prg_crs_cd	 = ""; // 진행과정코드
	private String prg_stat_nm	 = ""; // 진행상태명
	
	private List<Map<String, String>> docSendInfo = null;
	
	public String getJUBSU_NO() {
		return JUBSU_NO;
	}
	public void setJUBSU_NO(String jUBSU_NO) {
		JUBSU_NO = jUBSU_NO;
	}
	public String getMOKJUK_SEQ() {
		return MOKJUK_SEQ;
	}
	public void setMOKJUK_SEQ(String mOKJUK_SEQ) {
		MOKJUK_SEQ = mOKJUK_SEQ;
	}
	public String getPIBO_NM() {
		return PIBO_NM;
	}
	public void setPIBO_NM(String pIBO_NM) {
		PIBO_NM = pIBO_NM;
	}
	public String getPIBO_JUMIN_NO() {
		return PIBO_JUMIN_NO;
	}
	public void setPIBO_JUMIN_NO(String pIBO_JUMIN_NO) {
		PIBO_JUMIN_NO = pIBO_JUMIN_NO;
	}
	public String getJINHANG_STAT() {
		return JINHANG_STAT;
	}
	public void setJINHANG_STAT(String jINHANG_STAT) {
		JINHANG_STAT = jINHANG_STAT;
	}
	public String getJONGGYUL_YMD() {
		return JONGGYUL_YMD;
	}
	public void setJONGGYUL_YMD(String jONGGYUL_YMD) {
		JONGGYUL_YMD = jONGGYUL_YMD;
	}
	public String getDAMDANGJA() {
		return DAMDANGJA;
	}
	public void setDAMDANGJA(String dAMDANGJA) {
		DAMDANGJA = dAMDANGJA;
	}
	public String getOFF_TEL_NO() {
		return OFF_TEL_NO;
	}
	public void setOFF_TEL_NO(String oFF_TEL_NO) {
		OFF_TEL_NO = oFF_TEL_NO;
	}
	public String getTEL_NO() {
		return TEL_NO;
	}
	public void setTEL_NO(String tEL_NO) {
		TEL_NO = tEL_NO;
	}
	public String getGYULJUNG_AMT() {
		return GYULJUNG_AMT;
	}
	public void setGYULJUNG_AMT(String gYULJUNG_AMT) {
		GYULJUNG_AMT = gYULJUNG_AMT;
	}	
	public String getSAGO_YMD() {
		return SAGO_YMD;
	}
	public void setSAGO_YMD(String sAGO_YMD) {
		SAGO_YMD = sAGO_YMD;
	}
	public String getReg_dt() {
		return reg_dt;
	}
	public void setReg_dt(String reg_dt) {
		this.reg_dt = reg_dt;
	}
	public String getCnt() {
		return cnt;
	}
	public void setCnt(String cnt) {
		this.cnt = cnt;
	}
	public List<Map<String, String>> getDocSendInfo() {
		return docSendInfo;
	}
	public void setDocSendInfo(List<Map<String, String>> docSendInfo) {
		this.docSendInfo = docSendInfo;
	}
	/**
	 * @return the pdc_nm
	 */
	public String getPdc_nm() {
		return pdc_nm;
	}
	/**
	 * @param pdc_nm the pdc_nm to set
	 */
	public void setPdc_nm(String pdc_nm) {
		this.pdc_nm = pdc_nm;
	}
	/**
	 * @return the plhd_nm
	 */
	public String getPlhd_nm() {
		return plhd_nm;
	}
	/**
	 * @param plhd_nm the plhd_nm to set
	 */
	public void setPlhd_nm(String plhd_nm) {
		this.plhd_nm = plhd_nm;
	}
	/**
	 * @return the askg_typ
	 */
	public String getAskg_typ() {
		return askg_typ;
	}
	/**
	 * @param askg_typ the askg_typ to set
	 */
	public void setAskg_typ(String askg_typ) {
		this.askg_typ = askg_typ;
	}
	/**
	 * @return the accd_rpt_dt
	 */
	public String getAccd_rpt_dt() {
		return accd_rpt_dt;
	}
	/**
	 * @param accd_rpt_dt the accd_rpt_dt to set
	 */
	public void setAccd_rpt_dt(String accd_rpt_dt) {
		this.accd_rpt_dt = accd_rpt_dt;
	}
	/**
	 * @return the prg_crs_cd
	 */
	public String getPrg_crs_cd() {
		return prg_crs_cd;
	}
	/**
	 * @param prg_crs_cd the prg_crs_cd to set
	 */
	public void setPrg_crs_cd(String prg_crs_cd) {
		this.prg_crs_cd = prg_crs_cd;
	}
	/**
	 * @return the prg_stat_nm
	 */
	public String getPrg_stat_nm() {
		return prg_stat_nm;
	}
	/**
	 * @param prg_stat_nm the prg_stat_nm to set
	 */
	public void setPrg_stat_nm(String prg_stat_nm) {
		this.prg_stat_nm = prg_stat_nm;
	}

}
