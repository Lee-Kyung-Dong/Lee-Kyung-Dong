package com.idongbu.smartcustomer.vo;

import com.idongbu.common.vo.CMMVO;

// 계약조회
public class LbsSearchVO extends CMMVO {
	private String i_Hp_No = null;
	private String i_Jubsu_Date = null;
	private String i_Program = null;
	private String i_User_Id = null;
	private String i_Pos_X = null;
	private String i_Pos_Y = null;
	private String i_Err = null;
	
	public String getI_Hp_No() {
		return i_Hp_No;
	}
	public void setI_Hp_No(String i_Hp_No) {
		this.i_Hp_No = i_Hp_No;
	}
	public String getI_Jubsu_Date() {
		return i_Jubsu_Date;
	}
	public void setI_Jubsu_Date(String i_Jubsu_Date) {
		this.i_Jubsu_Date = i_Jubsu_Date;
	}
	public String getI_Program() {
		return i_Program;
	}
	public void setI_Program(String i_Program) {
		this.i_Program = i_Program;
	}
	public String getI_User_Id() {
		return i_User_Id;
	}
	public void setI_User_Id(String i_User_Id) {
		this.i_User_Id = i_User_Id;
	}
	public String getI_Pos_X() {
		return i_Pos_X;
	}
	public void setI_Pos_X(String i_Pos_X) {
		this.i_Pos_X = i_Pos_X;
	}
	public String getI_Pos_Y() {
		return i_Pos_Y;
	}
	public void setI_Pos_Y(String i_Pos_Y) {
		this.i_Pos_Y = i_Pos_Y;
	}
	public String getI_Err() {
		return i_Err;
	}
	public void setI_Err(String i_Err) {
		this.i_Err = i_Err;
	}
}