package com.idongbu.smartcustomer.vo;

import java.util.List;
import java.util.Map;

import com.idongbu.common.vo.CMMVO;

//대출 상환 목록 조회
public class CmmFUA6014RVO  extends CMMVO{
	
	public CmmFUA6014RVO() {
		super.setPGMID(proid);
		super.setTRID(trid);
	}
	
	private final static String proid		= "FUA6014R";
	private final static String trid		= "UA6E";
	private String rURL						= "";

	// 입력
	private String JJ_GY_JUMIN    = null; // 고객 주민등록번호
	private String UU_INQ_JUMIN = null; // INQ-주민번호
	private String UU_INQ_POLI = null; // INQ-증권번호

	// 출력
	private String CC_SAWON_NO = null;
	private String CC_CHANNEL = null;
	private String CC_UKEY = null;
	private String CC_PGMID = null;
	private String CC_PROC_GB = null;
	private String CC_FUN_KEY = null;
	private String CC_USER_GB = null;
	private String CC_USER_CD = null;
	private String CC_JIJUM_CD = null;
	private String CC_JIBU_CD = null;
	private String CC_PROTOCOL = null;
	private String CC_COND_CD = null;
	private String CC_LAST_FLAG = null;
	private String CC_CURSOR_MAP = null;
	private String CC_CURSOR_IDX = null;
	private String CC_MESSAGE_CD = null;
	private String HC_MESSAGE_NM = null;
	private String CC_SYS_ERR = null;
	private String CC_FILLER = null;
//	private String JJ_GY_JUMIN = null;
	private String HJ_GY_NM = null;
//	private String[] JJ_POLI_NO = new String[0]; // 10
//	private String[] JJ_BJ = new String[0]; // 10
//	private String[] HJ_BJ = new String[0]; // 10
//	private String[] JJ_GISAN_GM = new String[0]; // 10
//	private String[] JJ_MINAP_IJA = new String[0]; // 10
//	private String[] JJ_SANG_TOT = new String[0]; // 10
//	private String[] JJ_GISAN_YMD = new String[0]; // 10
//	private String[] JJ_IYUL = new String[0]; // 10
//	private String[] JJ_GYEJWA_NO = new String[0]; // 10
//	private String[] JJ_YEGMJU_JUMINNO = new String[0]; // 10
//	private String[] HJ_YEGMJU_NAME = new String[0]; // 10
//	private String[] JJ_ICHE_GWANCD = new String[0]; // 10
//	private String[] JJ_BANK_CD = new String[0]; // 10
//	private String[] HJ_BANK_NAME = new String[0]; // 10
//	private String[] JJ_ICHE_DD = new String[0]; // 10
//	private String[] JJ_SINCHERNG_RST = new String[0]; // 10
	private String JJ_FILLER = null;
//	private String UU_INQ_JUMIN = null;
//	private String UU_INQ_POLI = null;
	private String UU_F_JUMIN = null;
	private String UU_F_POLI = null;
	private String UU_L_JUMIN = null;
	private String UU_L_POLI = null;
	private String UU_FILLER = null;

	private String JJ_NAPIPHAL_PRM = null;
	private String JJ_CHANGE_YMD = null;
	
	private List<Map<String,String>> loopData = null;	//2차때 []형태 vo을 list에 담음
	
	
	
	public List<Map<String, String>> getLoopData() {
		return loopData;
	}
	public void setLoopData(List<Map<String, String>> loopData) {
		this.loopData = loopData;
	}
	public String getrURL() {
		return rURL;
	}
	public void setrURL(String rURL) {
		this.rURL = rURL;
	}
	public String getJJ_GY_JUMIN() {
		return JJ_GY_JUMIN;
	}
	public void setJJ_GY_JUMIN(String jJ_GY_JUMIN) {
		JJ_GY_JUMIN = jJ_GY_JUMIN;
	}
	public String getUU_INQ_JUMIN() {
		return UU_INQ_JUMIN;
	}
	public void setUU_INQ_JUMIN(String uU_INQ_JUMIN) {
		UU_INQ_JUMIN = uU_INQ_JUMIN;
	}
	public String getUU_INQ_POLI() {
		return UU_INQ_POLI;
	}
	public void setUU_INQ_POLI(String uU_INQ_POLI) {
		UU_INQ_POLI = uU_INQ_POLI;
	}
	public String getCC_CHANNEL() {
		return CC_CHANNEL;
	}
	public void setCC_CHANNEL(String cC_CHANNEL) {
		CC_CHANNEL = cC_CHANNEL;
	}
	public String getCC_UKEY() {
		return CC_UKEY;
	}
	public void setCC_UKEY(String cC_UKEY) {
		CC_UKEY = cC_UKEY;
	}
	public String getCC_PGMID() {
		return CC_PGMID;
	}
	public void setCC_PGMID(String cC_PGMID) {
		CC_PGMID = cC_PGMID;
	}
	public String getCC_PROC_GB() {
		return CC_PROC_GB;
	}
	public void setCC_PROC_GB(String cC_PROC_GB) {
		CC_PROC_GB = cC_PROC_GB;
	}
	public String getCC_FUN_KEY() {
		return CC_FUN_KEY;
	}
	public void setCC_FUN_KEY(String cC_FUN_KEY) {
		CC_FUN_KEY = cC_FUN_KEY;
	}
	public String getCC_USER_GB() {
		return CC_USER_GB;
	}
	public void setCC_USER_GB(String cC_USER_GB) {
		CC_USER_GB = cC_USER_GB;
	}
	public String getCC_USER_CD() {
		return CC_USER_CD;
	}
	public void setCC_USER_CD(String cC_USER_CD) {
		CC_USER_CD = cC_USER_CD;
	}
	public String getCC_JIJUM_CD() {
		return CC_JIJUM_CD;
	}
	public void setCC_JIJUM_CD(String cC_JIJUM_CD) {
		CC_JIJUM_CD = cC_JIJUM_CD;
	}
	public String getCC_JIBU_CD() {
		return CC_JIBU_CD;
	}
	public void setCC_JIBU_CD(String cC_JIBU_CD) {
		CC_JIBU_CD = cC_JIBU_CD;
	}
	public String getCC_PROTOCOL() {
		return CC_PROTOCOL;
	}
	public void setCC_PROTOCOL(String cC_PROTOCOL) {
		CC_PROTOCOL = cC_PROTOCOL;
	}
	public String getCC_COND_CD() {
		return CC_COND_CD;
	}
	public void setCC_COND_CD(String cC_COND_CD) {
		CC_COND_CD = cC_COND_CD;
	}
	public String getCC_LAST_FLAG() {
		return CC_LAST_FLAG;
	}
	public void setCC_LAST_FLAG(String cC_LAST_FLAG) {
		CC_LAST_FLAG = cC_LAST_FLAG;
	}
	public String getCC_CURSOR_MAP() {
		return CC_CURSOR_MAP;
	}
	public void setCC_CURSOR_MAP(String cC_CURSOR_MAP) {
		CC_CURSOR_MAP = cC_CURSOR_MAP;
	}
	public String getCC_CURSOR_IDX() {
		return CC_CURSOR_IDX;
	}
	public void setCC_CURSOR_IDX(String cC_CURSOR_IDX) {
		CC_CURSOR_IDX = cC_CURSOR_IDX;
	}
	public String getCC_MESSAGE_CD() {
		return CC_MESSAGE_CD;
	}
	public void setCC_MESSAGE_CD(String cC_MESSAGE_CD) {
		CC_MESSAGE_CD = cC_MESSAGE_CD;
	}
	public String getHC_MESSAGE_NM() {
		return HC_MESSAGE_NM;
	}
	public void setHC_MESSAGE_NM(String hC_MESSAGE_NM) {
		HC_MESSAGE_NM = hC_MESSAGE_NM;
	}
	public String getCC_SYS_ERR() {
		return CC_SYS_ERR;
	}
	public void setCC_SYS_ERR(String cC_SYS_ERR) {
		CC_SYS_ERR = cC_SYS_ERR;
	}
	public String getCC_FILLER() {
		return CC_FILLER;
	}
	public void setCC_FILLER(String cC_FILLER) {
		CC_FILLER = cC_FILLER;
	}
	public String getHJ_GY_NM() {
		return HJ_GY_NM;
	}
	public void setHJ_GY_NM(String hJ_GY_NM) {
		HJ_GY_NM = hJ_GY_NM;
	}
	public String getJJ_FILLER() {
		return JJ_FILLER;
	}
	public void setJJ_FILLER(String jJ_FILLER) {
		JJ_FILLER = jJ_FILLER;
	}
	public String getUU_F_JUMIN() {
		return UU_F_JUMIN;
	}
	public void setUU_F_JUMIN(String uU_F_JUMIN) {
		UU_F_JUMIN = uU_F_JUMIN;
	}
	public String getUU_F_POLI() {
		return UU_F_POLI;
	}
	public void setUU_F_POLI(String uU_F_POLI) {
		UU_F_POLI = uU_F_POLI;
	}
	public String getUU_L_JUMIN() {
		return UU_L_JUMIN;
	}
	public void setUU_L_JUMIN(String uU_L_JUMIN) {
		UU_L_JUMIN = uU_L_JUMIN;
	}
	public String getUU_L_POLI() {
		return UU_L_POLI;
	}
	public void setUU_L_POLI(String uU_L_POLI) {
		UU_L_POLI = uU_L_POLI;
	}
	public String getUU_FILLER() {
		return UU_FILLER;
	}
	public void setUU_FILLER(String uU_FILLER) {
		UU_FILLER = uU_FILLER;
	}
	public String getJJ_NAPIPHAL_PRM() {
		return JJ_NAPIPHAL_PRM;
	}
	public void setJJ_NAPIPHAL_PRM(String jJ_NAPIPHAL_PRM) {
		JJ_NAPIPHAL_PRM = jJ_NAPIPHAL_PRM;
	}
	public String getJJ_CHANGE_YMD() {
		return JJ_CHANGE_YMD;
	}
	public void setJJ_CHANGE_YMD(String jJ_CHANGE_YMD) {
		JJ_CHANGE_YMD = jJ_CHANGE_YMD;
	}
	public String getProid() {
		return proid;
	}
	public String getTrid() {
		return trid;
	}
	public String getCC_SAWON_NO() {
		return CC_SAWON_NO;
	}
	public void setCC_SAWON_NO(String cC_SAWON_NO) {
		CC_SAWON_NO = cC_SAWON_NO;
	}
}