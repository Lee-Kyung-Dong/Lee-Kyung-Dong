package com.idongbu.smartcustomer.vo;

import com.idongbu.util.Sms;


public class SmsVO {
	
	private int retCode = 0;
	private String retMsg = "";
	
	private String sn			= "1";	// 일련번호
	private String dest_num		= "";			// 받는 사람
	private String send_num		= "";	// 보내는 사람
	private String id			= "SYSTEM";		// 취급자
	private String svcname		= "1-HOY";		// 추가로 받은 구분값(1-HOY, 1-DIR, 1-WEB, ...)
	private String send_date	= Sms.getSendDate(); //StringUtil.dateToYmd(new Date(),"yyyyMMddHHmmss"); 원래 이거
	private String send_name	= "DB손해보험";
	private String send_msg		= "";
	
	private String res			= "";
	
	private String sttus_cd		= ""; 
	private String dstin_cd 		= "";
	private String cust_inhab_no = "";
	private String etc_text 		= "";
	private String rcept_no 		= "";
	private String stock_seq 	= "";
	private String insrd_name 	= "";
	private String coffr_name 	= "";
	
	public String getSn() {
		return sn;
	}
	public void setSn(String sn) {
		this.sn = sn;
	}
	public String getDest_num() {
		return dest_num;
	}
	public void setDest_num(String dest_num) {
		this.dest_num = dest_num;
	}
	public String getSend_num() {
		return send_num;
	}
	public void setSend_num(String send_num) {
		this.send_num = send_num;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getSvcname() {
		return svcname;
	}
	public void setSvcname(String svcname) {
		this.svcname = svcname;
	}
	public String getSend_date() {
		return send_date;
	}
	public void setSend_date(String send_date) {
		this.send_date = send_date;
	}
	public String getSend_name() {
		return send_name;
	}
	public void setSend_name(String send_name) {
		this.send_name = send_name;
	}
	public String getSend_msg() {
		return send_msg;
	}
	public void setSend_msg(String send_msg) {
		this.send_msg = send_msg;
	}
	public String getRes() {
		return res;
	}
	public void setRes(String res) {
		this.res = res;
	}
	public String getSttus_cd() {
		return sttus_cd;
	}
	public void setSttus_cd(String sttus_cd) {
		this.sttus_cd = sttus_cd;
	}
	public String getDstin_cd() {
		return dstin_cd;
	}
	public void setDstin_cd(String dstin_cd) {
		this.dstin_cd = dstin_cd;
	}
	public String getCust_inhab_no() {
		return cust_inhab_no;
	}
	public void setCust_inhab_no(String cust_inhab_no) {
		this.cust_inhab_no = cust_inhab_no;
	}
	public String getEtc_text() {
		return etc_text;
	}
	public void setEtc_text(String etc_text) {
		this.etc_text = etc_text;
	}
	public String getRcept_no() {
		return rcept_no;
	}
	public void setRcept_no(String rcept_no) {
		this.rcept_no = rcept_no;
	}
	public String getStock_seq() {
		return stock_seq;
	}
	public void setStock_seq(String stock_seq) {
		this.stock_seq = stock_seq;
	}
	public String getInsrd_name() {
		return insrd_name;
	}
	public void setInsrd_name(String insrd_name) {
		this.insrd_name = insrd_name;
	}
	public String getCoffr_name() {
		return coffr_name;
	}
	public void setCoffr_name(String coffr_name) {
		this.coffr_name = coffr_name;
	}
	public int getRetCode() {
		return retCode;
	}
	public void setRetCode(int retCode) {
		this.retCode = retCode;
	}
	public String getRetMsg() {
		return retMsg;
	}
	public void setRetMsg(String retMsg) {
		this.retMsg = retMsg;
	}
	@Override
	public String toString() {
		return "SmsVO [retCode=" + retCode + ", retMsg=" + retMsg + ", sn="
				+ sn + ", dest_num=" + dest_num + ", send_num=" + send_num
				+ ", id=" + id + ", svcname=" + svcname + ", send_date="
				+ send_date + ", send_name=" + send_name + ", send_msg="
				+ send_msg + ", res=" + res + ", sttus_cd=" + sttus_cd
				+ ", dstin_cd=" + dstin_cd + ", cust_inhab_no=" + cust_inhab_no
				+ ", etc_text=" + etc_text + ", rcept_no=" + rcept_no
				+ ", stock_seq=" + stock_seq + ", insrd_name=" + insrd_name
				+ ", coffr_name=" + coffr_name + ", getSn()=" + getSn()
				+ ", getDest_num()=" + getDest_num() + ", getSend_num()="
				+ getSend_num() + ", getId()=" + getId() + ", getSvcname()="
				+ getSvcname() + ", getSend_date()=" + getSend_date()
				+ ", getSend_name()=" + getSend_name() + ", getSend_msg()="
				+ getSend_msg() + ", getRes()=" + getRes() + ", getSttus_cd()="
				+ getSttus_cd() + ", getDstin_cd()=" + getDstin_cd()
				+ ", getCust_inhab_no()=" + getCust_inhab_no()
				+ ", getEtc_text()=" + getEtc_text() + ", getRcept_no()="
				+ getRcept_no() + ", getStock_seq()=" + getStock_seq()
				+ ", getInsrd_name()=" + getInsrd_name() + ", getCoffr_name()="
				+ getCoffr_name() + ", getRetCode()=" + getRetCode()
				+ ", getRetMsg()=" + getRetMsg() + ", getClass()=" + getClass()
				+ ", hashCode()=" + hashCode() + ", toString()="
				+ super.toString() + "]";
	}
	
	
	/**
	 * @param dstin_cd   	코드(HAA_SMS_DSTIN_CDT 의 DSTIN_CD)
	 * @param jumin_no   	받는사람 주민번호(없으면 '')
	 * @param etc_text   	기타내용
	 * @param rcept_no   	접수번호(보상)
	 * @param stock_seq		증권번호
	 * @param insrd_name	피보험자명
	 * @param coffr_name	받는사람이름
	 * <BR><BR>
	 * dstin_cd는 반드시 입력해야 한다
	 * 메뉴에 해당하는 코드값이 없을 경우 추가해야 한다.
	 */
	public void setInfo(String dstin_cd, String jumin_no, String etc_text, String rcept_no, String stock_seq, String insrd_name, String coffr_name){
		this.dstin_cd 		= dstin_cd;
		this.cust_inhab_no 	= jumin_no;
		this.etc_text 		= etc_text;
		this.rcept_no 		= rcept_no;
		this.stock_seq 		= stock_seq;
		this.insrd_name 	= insrd_name;
		this.coffr_name 	= coffr_name;
	}
}
