package com.idongbu.smartcustomer.vo;

public class SubFGZ5916STBLVO {

	public String LK_DAMBO_CD      = null;
	public String LK_DAMBO_NM      = null;
	public String LK_GAIP_GMEK     = null;

	public String getLK_DAMBO_CD() {
		return LK_DAMBO_CD;
	}
	public void setLK_DAMBO_CD(String lK_DAMBO_CD) {
		LK_DAMBO_CD = lK_DAMBO_CD;
	}
	public String getLK_DAMBO_NM() {
		return LK_DAMBO_NM;
	}
	public void setLK_DAMBO_NM(String lK_DAMBO_NM) {
		LK_DAMBO_NM = lK_DAMBO_NM;
	}
	public String getLK_GAIP_GMEK() {
		return LK_GAIP_GMEK;
	}
	public void setLK_GAIP_GMEK(String lK_GAIP_GMEK) {
		LK_GAIP_GMEK = lK_GAIP_GMEK;
	}

}
