package com.idongbu.smartcustomer.vo;

public class SubFQA1085RVO {
	public String LK_GA1085_TUKYAK_CD = null;
	public String LK_GA1085_TUKYAK_RATE = null;
	public String eny_tty_spc_if__dsn = null;
	
	public String getLK_GA1085_TUKYAK_CD() {
		return LK_GA1085_TUKYAK_CD;
	}
	public void setLK_GA1085_TUKYAK_CD(String lK_GA1085_TUKYAK_CD) {
		LK_GA1085_TUKYAK_CD = lK_GA1085_TUKYAK_CD;
	}
	public String getLK_GA1085_TUKYAK_RATE() {
		return LK_GA1085_TUKYAK_RATE;
	}
	public void setLK_GA1085_TUKYAK_RATE(String lK_GA1085_TUKYAK_RATE) {
		LK_GA1085_TUKYAK_RATE = lK_GA1085_TUKYAK_RATE;
	}
	public String getEny_tty_spc_if__dsn() {
		return eny_tty_spc_if__dsn;
	}
	public void setEny_tty_spc_if__dsn(String eny_tty_spc_if__dsn) {
		this.eny_tty_spc_if__dsn = eny_tty_spc_if__dsn;
	}
}
