package com.idongbu.smartcustomer.vo;

import com.idongbu.common.vo.CMMVO;


// 신용카드신청입력
public class CmmFYA0109RVO extends CMMVO {
	public CmmFYA0109RVO() {
		super.setPGMID(this.proid);
		super.setTRID(this.trid);
	}
	public static final String proid		= "FYA0109R";
	public static final String trid		= "YAA9";
	public String rURL						= "";

	// 입력
	private String NODE_NAME1 = " "; // NODE NAME1
	private String NODE_NAME2 = " "; // NODE NAME2
	private String NODE_NAME3 = " "; // NODE NAME3
	private String NODE_NAME4 = " "; // NODE NAME4
	private String TR_SOCKET_NO = " "; // SOCKET NO
	private String LOG_SOCKET_NO = " "; // LOG SOCKET NO
	private String LK_LENGTH = " "; // LENGTH
	private String RE_JOJIKWON_CD = " "; // 조직원 코드
	private String RE_CARD_NO = " "; // 카드 번호
	private String RE_JUMIN_NO = " "; // 주민번호
	private String RE_YUHYO_GIGAN = " "; // 유효 기간
	private String RE_HALBU_GIGAN = " "; // 할부 기간
	private String RE_U_D_UPMU_GUBUN = " "; // 1.일반승인  2.신한tm 3.직판 4.ARS
	private String RE_NEW_RENW_DVCD = " "; //직판시스템과 신한카드 제휴내용반영 (홈페이지 안씀)
	private String TRID = "";

	// 출력
	private String CHANNEL = " ";
	private String TERM_ID = " ";
	private String PGM_ID = " ";
	private String PATH = " ";
	private String FUNCTION_KEY = " ";
	private String USER_ID_F = " ";
	private String USER_ID = " ";
	private String JIJUM_CODE = " ";
	private String JIBU_CODE = " ";
	private String PROTOCOL = " ";
	private String COND_CODE = " ";
	private String SE_LAST_FLAG = " ";
	private String CUR_POS_MAP_ID = " ";
	private String CUR_POS_INDEX = " ";
	private String SE_MSG_ID = " ";
	private String H_MESSAGE_NM = " ";
	private String SE_SM_LEVEL = " ";
	private String SE_SM_ID = " ";
	private String SE_SM_PRC = " ";
	private String SE_SM_RC = " ";
	private String FILLER = " ";
	private String H_MSG_NAME = "";
	private String MSG_CODE = "";
	private String RETN_CODE = "";
	
//	private String NODE_NAME1 = " ";
//	private String NODE_NAME2 = " ";
//	private String NODE_NAME3 = " ";
//	private String NODE_NAME4 = " ";
//	private String TR_SOCKET_NO = " ";
//	private String LOG_SOCKET_NO = " ";
//	private String LK_LENGTH = " ";
	private String LK_PROCESS_ID = " ";
//	private String RE_JOJIKWON_CD = " ";
	private String RE_YUNGSUJNG_NO = " ";
//	private String RE_CARD_NO = " ";
//	private String RE_JUMIN_NO = " ";
	private String RE_BALGPSA_CD = " ";
	private String H_RE_BALGPSA_NM = " ";
//	private String RE_YUHYO_GIGAN = " ";
//	private String RE_HALBU_GIGAN = " ";
	private String RE_GEORE_AMT = " ";
	private String RE_SEUNGIN_NO = " ";
	private String RE_MESSAGE_CD = " ";
	private String H_RE_MESSAGE_NM = " ";
	private String RE_JIJUM_CD = " ";
	private String RE_PUM_YEAR = " ";
	private String RE_PUM_SEQ_NO = " ";
	private String RE_U_D_JIJUM_CD_C = " ";
	private String RE_U_D_JIJUM_CD_A = " ";
	private String RE_U_D_JIBU_CD = " ";
	private String RE_U_D_YEAR = " ";
	private String RE_U_D_SEQ_NO = " ";
	private String RE_U_D_CARDSA_YN = " ";
	private String RE_U_D_VAN_GUBUN = " ";
	private String RE_U_D_SEUNGIN_DATA = " ";
	private String RE_U_D_KEY_IN = " ";
	private String RE_U_D_INJNG_GUBUN = " ";
	private String RE_U_D_VAN_SEQ = " ";
	private String RE_DETAIL_C = " ";
//	private String RE_U_D_UPMU_GUBUN = " ";
	private String exception = "";
	private String retCode = "";
	private String RE_BCTOP_POINT = "";
	private String RE_POINT_JOHOI = "";
	
	private String serialNO = "";
	private String card_junpyo = "";
	private String transaction = "";
	private String mertid = "";
	
	public String getrURL() {
		return rURL;
	}
	public void setrURL(String rURL) {
		this.rURL = rURL;
	}
	public String getNODE_NAME1() {
		return NODE_NAME1;
	}
	public void setNODE_NAME1(String nODE_NAME1) {
		NODE_NAME1 = nODE_NAME1;
	}
	public String getNODE_NAME2() {
		return NODE_NAME2;
	}
	public void setNODE_NAME2(String nODE_NAME2) {
		NODE_NAME2 = nODE_NAME2;
	}
	public String getNODE_NAME3() {
		return NODE_NAME3;
	}
	public void setNODE_NAME3(String nODE_NAME3) {
		NODE_NAME3 = nODE_NAME3;
	}
	public String getNODE_NAME4() {
		return NODE_NAME4;
	}
	public void setNODE_NAME4(String nODE_NAME4) {
		NODE_NAME4 = nODE_NAME4;
	}
	public String getTR_SOCKET_NO() {
		return TR_SOCKET_NO;
	}
	public void setTR_SOCKET_NO(String tR_SOCKET_NO) {
		TR_SOCKET_NO = tR_SOCKET_NO;
	}
	public String getLOG_SOCKET_NO() {
		return LOG_SOCKET_NO;
	}
	public void setLOG_SOCKET_NO(String lOG_SOCKET_NO) {
		LOG_SOCKET_NO = lOG_SOCKET_NO;
	}
	public String getLK_LENGTH() {
		return LK_LENGTH;
	}
	public void setLK_LENGTH(String lK_LENGTH) {
		LK_LENGTH = lK_LENGTH;
	}
	public String getRE_JOJIKWON_CD() {
		return RE_JOJIKWON_CD;
	}
	public void setRE_JOJIKWON_CD(String rE_JOJIKWON_CD) {
		RE_JOJIKWON_CD = rE_JOJIKWON_CD;
	}
	public String getRE_CARD_NO() {
		return RE_CARD_NO;
	}
	public void setRE_CARD_NO(String rE_CARD_NO) {
		RE_CARD_NO = rE_CARD_NO;
	}
	public String getRE_JUMIN_NO() {
		return RE_JUMIN_NO;
	}
	public void setRE_JUMIN_NO(String rE_JUMIN_NO) {
		RE_JUMIN_NO = rE_JUMIN_NO;
	}
	public String getRE_YUHYO_GIGAN() {
		return RE_YUHYO_GIGAN;
	}
	public void setRE_YUHYO_GIGAN(String rE_YUHYO_GIGAN) {
		RE_YUHYO_GIGAN = rE_YUHYO_GIGAN;
	}
	public String getRE_HALBU_GIGAN() {
		return RE_HALBU_GIGAN;
	}
	public void setRE_HALBU_GIGAN(String rE_HALBU_GIGAN) {
		RE_HALBU_GIGAN = rE_HALBU_GIGAN;
	}
	public String getRE_U_D_UPMU_GUBUN() {
		return RE_U_D_UPMU_GUBUN;
	}
	public void setRE_U_D_UPMU_GUBUN(String rE_U_D_UPMU_GUBUN) {
		RE_U_D_UPMU_GUBUN = rE_U_D_UPMU_GUBUN;
	}
	public String getRE_NEW_RENW_DVCD() {
		return RE_NEW_RENW_DVCD;
	}
	public void setRE_NEW_RENW_DVCD(String rE_NEW_RENW_DVCD) {
		RE_NEW_RENW_DVCD = rE_NEW_RENW_DVCD;
	}
	public String getTRID() {
		return TRID;
	}
	public void setTRID(String tRID) {
		TRID = tRID;
	}
	public String getCHANNEL() {
		return CHANNEL;
	}
	public void setCHANNEL(String cHANNEL) {
		CHANNEL = cHANNEL;
	}
	public String getTERM_ID() {
		return TERM_ID;
	}
	public void setTERM_ID(String tERM_ID) {
		TERM_ID = tERM_ID;
	}
	public String getPGM_ID() {
		return PGM_ID;
	}
	public void setPGM_ID(String pGM_ID) {
		PGM_ID = pGM_ID;
	}
	public String getPATH() {
		return PATH;
	}
	public void setPATH(String pATH) {
		PATH = pATH;
	}
	public String getFUNCTION_KEY() {
		return FUNCTION_KEY;
	}
	public void setFUNCTION_KEY(String fUNCTION_KEY) {
		FUNCTION_KEY = fUNCTION_KEY;
	}
	public String getUSER_ID_F() {
		return USER_ID_F;
	}
	public void setUSER_ID_F(String uSER_ID_F) {
		USER_ID_F = uSER_ID_F;
	}
	public String getUSER_ID() {
		return USER_ID;
	}
	public void setUSER_ID(String uSER_ID) {
		USER_ID = uSER_ID;
	}
	public String getJIJUM_CODE() {
		return JIJUM_CODE;
	}
	public void setJIJUM_CODE(String jIJUM_CODE) {
		JIJUM_CODE = jIJUM_CODE;
	}
	public String getJIBU_CODE() {
		return JIBU_CODE;
	}
	public void setJIBU_CODE(String jIBU_CODE) {
		JIBU_CODE = jIBU_CODE;
	}
	public String getPROTOCOL() {
		return PROTOCOL;
	}
	public void setPROTOCOL(String pROTOCOL) {
		PROTOCOL = pROTOCOL;
	}
	public String getCOND_CODE() {
		return COND_CODE;
	}
	public void setCOND_CODE(String cOND_CODE) {
		COND_CODE = cOND_CODE;
	}
	public String getSE_LAST_FLAG() {
		return SE_LAST_FLAG;
	}
	public void setSE_LAST_FLAG(String sE_LAST_FLAG) {
		SE_LAST_FLAG = sE_LAST_FLAG;
	}
	public String getCUR_POS_MAP_ID() {
		return CUR_POS_MAP_ID;
	}
	public void setCUR_POS_MAP_ID(String cUR_POS_MAP_ID) {
		CUR_POS_MAP_ID = cUR_POS_MAP_ID;
	}
	public String getCUR_POS_INDEX() {
		return CUR_POS_INDEX;
	}
	public void setCUR_POS_INDEX(String cUR_POS_INDEX) {
		CUR_POS_INDEX = cUR_POS_INDEX;
	}
	public String getSE_MSG_ID() {
		return SE_MSG_ID;
	}
	public void setSE_MSG_ID(String sE_MSG_ID) {
		SE_MSG_ID = sE_MSG_ID;
	}
	public String getH_MESSAGE_NM() {
		return H_MESSAGE_NM;
	}
	public void setH_MESSAGE_NM(String h_MESSAGE_NM) {
		H_MESSAGE_NM = h_MESSAGE_NM;
	}
	public String getSE_SM_LEVEL() {
		return SE_SM_LEVEL;
	}
	public void setSE_SM_LEVEL(String sE_SM_LEVEL) {
		SE_SM_LEVEL = sE_SM_LEVEL;
	}
	public String getSE_SM_ID() {
		return SE_SM_ID;
	}
	public void setSE_SM_ID(String sE_SM_ID) {
		SE_SM_ID = sE_SM_ID;
	}
	public String getSE_SM_PRC() {
		return SE_SM_PRC;
	}
	public void setSE_SM_PRC(String sE_SM_PRC) {
		SE_SM_PRC = sE_SM_PRC;
	}
	public String getSE_SM_RC() {
		return SE_SM_RC;
	}
	public void setSE_SM_RC(String sE_SM_RC) {
		SE_SM_RC = sE_SM_RC;
	}
	public String getFILLER() {
		return FILLER;
	}
	public void setFILLER(String fILLER) {
		FILLER = fILLER;
	}
	public String getLK_PROCESS_ID() {
		return LK_PROCESS_ID;
	}
	public void setLK_PROCESS_ID(String lK_PROCESS_ID) {
		LK_PROCESS_ID = lK_PROCESS_ID;
	}
	public String getRE_YUNGSUJNG_NO() {
		return RE_YUNGSUJNG_NO;
	}
	public void setRE_YUNGSUJNG_NO(String rE_YUNGSUJNG_NO) {
		RE_YUNGSUJNG_NO = rE_YUNGSUJNG_NO;
	}
	public String getRE_BALGPSA_CD() {
		return RE_BALGPSA_CD;
	}
	public void setRE_BALGPSA_CD(String rE_BALGPSA_CD) {
		RE_BALGPSA_CD = rE_BALGPSA_CD;
	}
	public String getH_RE_BALGPSA_NM() {
		return H_RE_BALGPSA_NM;
	}
	public void setH_RE_BALGPSA_NM(String h_RE_BALGPSA_NM) {
		H_RE_BALGPSA_NM = h_RE_BALGPSA_NM;
	}
	public String getRE_GEORE_AMT() {
		return RE_GEORE_AMT;
	}
	public void setRE_GEORE_AMT(String rE_GEORE_AMT) {
		RE_GEORE_AMT = rE_GEORE_AMT;
	}
	public String getRE_SEUNGIN_NO() {
		return RE_SEUNGIN_NO;
	}
	public void setRE_SEUNGIN_NO(String rE_SEUNGIN_NO) {
		RE_SEUNGIN_NO = rE_SEUNGIN_NO;
	}
	public String getRE_MESSAGE_CD() {
		return RE_MESSAGE_CD;
	}
	public void setRE_MESSAGE_CD(String rE_MESSAGE_CD) {
		RE_MESSAGE_CD = rE_MESSAGE_CD;
	}
	public String getH_RE_MESSAGE_NM() {
		return H_RE_MESSAGE_NM;
	}
	public void setH_RE_MESSAGE_NM(String h_RE_MESSAGE_NM) {
		H_RE_MESSAGE_NM = h_RE_MESSAGE_NM;
	}
	public String getRE_JIJUM_CD() {
		return RE_JIJUM_CD;
	}
	public void setRE_JIJUM_CD(String rE_JIJUM_CD) {
		RE_JIJUM_CD = rE_JIJUM_CD;
	}
	public String getRE_PUM_YEAR() {
		return RE_PUM_YEAR;
	}
	public void setRE_PUM_YEAR(String rE_PUM_YEAR) {
		RE_PUM_YEAR = rE_PUM_YEAR;
	}
	public String getRE_PUM_SEQ_NO() {
		return RE_PUM_SEQ_NO;
	}
	public void setRE_PUM_SEQ_NO(String rE_PUM_SEQ_NO) {
		RE_PUM_SEQ_NO = rE_PUM_SEQ_NO;
	}
	public String getRE_U_D_JIJUM_CD_C() {
		return RE_U_D_JIJUM_CD_C;
	}
	public void setRE_U_D_JIJUM_CD_C(String rE_U_D_JIJUM_CD_C) {
		RE_U_D_JIJUM_CD_C = rE_U_D_JIJUM_CD_C;
	}
	public String getRE_U_D_JIJUM_CD_A() {
		return RE_U_D_JIJUM_CD_A;
	}
	public void setRE_U_D_JIJUM_CD_A(String rE_U_D_JIJUM_CD_A) {
		RE_U_D_JIJUM_CD_A = rE_U_D_JIJUM_CD_A;
	}
	public String getRE_U_D_JIBU_CD() {
		return RE_U_D_JIBU_CD;
	}
	public void setRE_U_D_JIBU_CD(String rE_U_D_JIBU_CD) {
		RE_U_D_JIBU_CD = rE_U_D_JIBU_CD;
	}
	public String getRE_U_D_YEAR() {
		return RE_U_D_YEAR;
	}
	public void setRE_U_D_YEAR(String rE_U_D_YEAR) {
		RE_U_D_YEAR = rE_U_D_YEAR;
	}
	public String getRE_U_D_SEQ_NO() {
		return RE_U_D_SEQ_NO;
	}
	public void setRE_U_D_SEQ_NO(String rE_U_D_SEQ_NO) {
		RE_U_D_SEQ_NO = rE_U_D_SEQ_NO;
	}
	public String getRE_U_D_CARDSA_YN() {
		return RE_U_D_CARDSA_YN;
	}
	public void setRE_U_D_CARDSA_YN(String rE_U_D_CARDSA_YN) {
		RE_U_D_CARDSA_YN = rE_U_D_CARDSA_YN;
	}
	public String getRE_U_D_VAN_GUBUN() {
		return RE_U_D_VAN_GUBUN;
	}
	public void setRE_U_D_VAN_GUBUN(String rE_U_D_VAN_GUBUN) {
		RE_U_D_VAN_GUBUN = rE_U_D_VAN_GUBUN;
	}
	public String getRE_U_D_SEUNGIN_DATA() {
		return RE_U_D_SEUNGIN_DATA;
	}
	public void setRE_U_D_SEUNGIN_DATA(String rE_U_D_SEUNGIN_DATA) {
		RE_U_D_SEUNGIN_DATA = rE_U_D_SEUNGIN_DATA;
	}
	public String getRE_U_D_KEY_IN() {
		return RE_U_D_KEY_IN;
	}
	public void setRE_U_D_KEY_IN(String rE_U_D_KEY_IN) {
		RE_U_D_KEY_IN = rE_U_D_KEY_IN;
	}
	public String getRE_U_D_INJNG_GUBUN() {
		return RE_U_D_INJNG_GUBUN;
	}
	public void setRE_U_D_INJNG_GUBUN(String rE_U_D_INJNG_GUBUN) {
		RE_U_D_INJNG_GUBUN = rE_U_D_INJNG_GUBUN;
	}
	public String getRE_U_D_VAN_SEQ() {
		return RE_U_D_VAN_SEQ;
	}
	public void setRE_U_D_VAN_SEQ(String rE_U_D_VAN_SEQ) {
		RE_U_D_VAN_SEQ = rE_U_D_VAN_SEQ;
	}
	public String getRE_DETAIL_C() {
		return RE_DETAIL_C;
	}
	public void setRE_DETAIL_C(String rE_DETAIL_C) {
		RE_DETAIL_C = rE_DETAIL_C;
	}
	public String getException() {
		return exception;
	}
	public void setException(String exception) {
		this.exception = exception;
	}
	public String getRetCode() {
		return retCode;
	}
	public void setRetCode(String retCode) {
		this.retCode = retCode;
	}
	public String getRE_BCTOP_POINT() {
		return RE_BCTOP_POINT;
	}
	public void setRE_BCTOP_POINT(String rE_BCTOP_POINT) {
		RE_BCTOP_POINT = rE_BCTOP_POINT;
	}
	public String getRE_POINT_JOHOI() {
		return RE_POINT_JOHOI;
	}
	public void setRE_POINT_JOHOI(String rE_POINT_JOHOI) {
		RE_POINT_JOHOI = rE_POINT_JOHOI;
	}
	public String getSerialNO() {
		return serialNO;
	}
	public void setSerialNO(String serialNO) {
		this.serialNO = serialNO;
	}
	public String getCard_junpyo() {
		return card_junpyo;
	}
	public void setCard_junpyo(String card_junpyo) {
		this.card_junpyo = card_junpyo;
	}
	public String getTransaction() {
		return transaction;
	}
	public void setTransaction(String transaction) {
		this.transaction = transaction;
	}
	public String getMertid() {
		return mertid;
	}
	public void setMertid(String mertid) {
		this.mertid = mertid;
	}
	public String getH_MSG_NAME() {
		return H_MSG_NAME;
	}
	public void setH_MSG_NAME(String h_MSG_NAME) {
		H_MSG_NAME = h_MSG_NAME;
	}
	public String getMSG_CODE() {
		return MSG_CODE;
	}
	public void setMSG_CODE(String mSG_CODE) {
		MSG_CODE = mSG_CODE;
	}
	public String getRETN_CODE() {
		return RETN_CODE;
	}
	public void setRETN_CODE(String rETN_CODE) {
		RETN_CODE = rETN_CODE;
	}
	
	
}
