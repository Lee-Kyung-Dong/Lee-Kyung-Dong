package com.idongbu.smartcustomer.vo;



public class SubFUA6028RVO {

	

	public String JJ_POLI_NO;
	public String HJ_BJ_NAME;
	public String JJ_BOHUM_SYMD;
	public String JJ_BOHUM_EYMD;
	public String JJ_HANDO_AMT;
	public String HJ_SANGTE_NAME;
	public String JJ_CURSOR_IDX;
	
	public String mway_wdra_pss_aot_if__dpsr_rrno;			//중도인출가능액정보_예금주주민등록번호
	public String mway_wdra_pss_aot_if__dpsr_nm;			//중도인출가능액정보_예금주명 
	public String mway_wdra_pss_aot_if__aut_tsfr_bank_cd;	//중도인출가능액정보_자동이체은행코드
	public String mway_wdra_pss_aot_if__aut_tsfr_bank_nm;	//중도인출가능액정보_자동이체은행명
	public String mway_wdra_pss_aot_if__acc_no;				//중도인출가능액정보_계좌번호
		
	public String getJJ_POLI_NO() {
		return JJ_POLI_NO;
	}
	public void setJJ_POLI_NO(String jJ_POLI_NO) {
		JJ_POLI_NO = jJ_POLI_NO;
	}
	public String getHJ_BJ_NAME() {
		return HJ_BJ_NAME;
	}
	public void setHJ_BJ_NAME(String hJ_BJ_NAME) {
		HJ_BJ_NAME = hJ_BJ_NAME;
	}
	public String getJJ_BOHUM_SYMD() {
		return JJ_BOHUM_SYMD;
	}
	public void setJJ_BOHUM_SYMD(String jJ_BOHUM_SYMD) {
		JJ_BOHUM_SYMD = jJ_BOHUM_SYMD;
	}
	public String getJJ_BOHUM_EYMD() {
		return JJ_BOHUM_EYMD;
	}
	public void setJJ_BOHUM_EYMD(String jJ_BOHUM_EYMD) {
		JJ_BOHUM_EYMD = jJ_BOHUM_EYMD;
	}
	public String getJJ_HANDO_AMT() {
		return JJ_HANDO_AMT;
	}
	public void setJJ_HANDO_AMT(String jJ_HANDO_AMT) {
		JJ_HANDO_AMT = jJ_HANDO_AMT;
	}
	public String getHJ_SANGTE_NAME() {
		return HJ_SANGTE_NAME;
	}
	public void setHJ_SANGTE_NAME(String hJ_SANGTE_NAME) {
		HJ_SANGTE_NAME = hJ_SANGTE_NAME;
	}
	public String getJJ_CURSOR_IDX() {
		return JJ_CURSOR_IDX;
	}
	public void setJJ_CURSOR_IDX(String jJ_CURSOR_IDX) {
		JJ_CURSOR_IDX = jJ_CURSOR_IDX;
	}
	
	//중도인출가능액정보_예금주주민등록번호
	public String getMway_wdra_pss_aot_if__dpsr_rrno() {
		return mway_wdra_pss_aot_if__dpsr_rrno;
	}
	public void setMway_wdra_pss_aot_if__dpsr_rrno(String jMway_wdra_pss_aot_if__dpsr_rrno) {
		mway_wdra_pss_aot_if__dpsr_rrno = jMway_wdra_pss_aot_if__dpsr_rrno;
	}
	//중도인출가능액정보_예금주명
	public String getMway_wdra_pss_aot_if__dpsr_nm() {
		return mway_wdra_pss_aot_if__dpsr_nm;
	}
	public void setMway_wdra_pss_aot_if__dpsr_nm(String jMway_wdra_pss_aot_if__dpsr_nm) {
		mway_wdra_pss_aot_if__dpsr_nm = jMway_wdra_pss_aot_if__dpsr_nm;
	}
	//중도인출가능액정보_자동이체은행코드
	public String getMway_wdra_pss_aot_if__aut_tsfr_bank_cd() {
		return mway_wdra_pss_aot_if__aut_tsfr_bank_cd;
	}
	public void setMway_wdra_pss_aot_if__aut_tsfr_bank_cd(String jMway_wdra_pss_aot_if__aut_tsfr_bank_cd) {
		mway_wdra_pss_aot_if__aut_tsfr_bank_cd = jMway_wdra_pss_aot_if__aut_tsfr_bank_cd;
	}
	//중도인출가능액정보_자동이체은행명
	public String getMway_wdra_pss_aot_if__aut_tsfr_bank_nm() {
		return mway_wdra_pss_aot_if__aut_tsfr_bank_nm;
	}
	public void setMway_wdra_pss_aot_if__aut_tsfr_bank_nm(String jMway_wdra_pss_aot_if__aut_tsfr_bank_nm) {
		mway_wdra_pss_aot_if__aut_tsfr_bank_nm = jMway_wdra_pss_aot_if__aut_tsfr_bank_nm;
	}
	//중도인출가능액정보_계좌번호
	public String getMway_wdra_pss_aot_if__acc_no() {
		return mway_wdra_pss_aot_if__acc_no;
	}
	public void setMway_wdra_pss_aot_if__acc_no(String jMway_wdra_pss_aot_if__acc_no) {
		mway_wdra_pss_aot_if__acc_no = jMway_wdra_pss_aot_if__acc_no;
	}
	
	
}