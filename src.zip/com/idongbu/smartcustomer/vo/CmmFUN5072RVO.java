package com.idongbu.smartcustomer.vo;

import java.util.List;

import com.idongbu.common.vo.CMMVO;


// 계약조회-컨버전스보험의 경우이고 모증권인경우
public class CmmFUN5072RVO extends CMMVO {
	public CmmFUN5072RVO() {
		super.setPGMID(this.proid);
		super.setTRID(this.trid);
	}	
	
	public static final String proid		= "FUN5072R";
	public static final String trid			= "UN72";
	public String rURL						= "";

	// 입력
	public String JJ_POLI_NO 				= null; // 증권번호

	// 출력
	public String CC_CHANNEL 				= null;
	public String CC_UKEY 					= null;
	public String CC_PGMID 					= null;
	public String CC_PROC_GB 				= null;
	public String CC_FUN_KEY 				= null;
	public String CC_USER_GB 				= null;
	public String CC_USER_CD 				= null;
	public String CC_JIJUM_CD 				= null;
	public String CC_JIBU_CD 				= null;
	public String CC_PROTOCOL 				= null;
	public String CC_COND_CD 				= null;
	public String CC_LAST_FLAG 				= null;
	public String CC_CURSOR_MAP 			= null;
	public String CC_CURSOR_IDX 			= null;
	public String CC_MESSAGE_CD 			= null;
	public String HC_MESSAGE_NM 			= null;
	public String CC_SYS_ERR 				= null;
	public String CC_FILLER 				= null;
//	public String JJ_POLI_NO = null;
	public String JJ_BESU_NO 				= null;
	public String JJ_SEL_GB 				= null;
	public String JJ_BJ_CD 					= null;
	public String JJ_DANCHE_GB 				= null;
	public String HJ_BJ_NAME 				= null;
	public String HJ_BJ_GBN 				= null;
	public String JJ_GOGEK_GB 				= null;
	public String JJ_BH_SYMD 				= null;
	public String JJ_BH_EYMD 				= null;
	public String HJ_BH_NM 					= null;
	public String JJ_CHUNG_YMD 				= null;
	public String HJ_GYE_NAME 				= null;
	public String JJ_GYE_JUMIN 				= null;
	public String JJ_GYE_TEL1 				= null;
	public String JJ_GYE_TEL2 				= null;
	public String JJ_GYE_TEL3 				= null;
	public String HJ_GUKGA_NM 				= null;
	public String JJ_GYE_ZIP1 				= null;
	public String JJ_GYE_ZIP2 				= null;
	public String HJ_GYE_ADDR1 				= null;
	public String HJ_GYE_ADDR2 				= null;
	public String JJ_BALGUP_GB 				= null;
	public String HJ_BALGUP_NM 				= null;
	
	
	public String JJ_ILBAN_POLI_NO 			= null;
	public String HJ_ILBAN_PIBO_NM 			= null;
	public String JJ_ILBAN_PIBO_JUMIN 		= null;
	public String JJ_ILBAN_BJ_NM 			= null;
	public String JJ_ILBAN_BOHUM_SYMD 		= null;
	public String JJ_ILBAN_BOHUM_EYMD 		= null;
	public String JJ_ILBAN_JUKYONG_PRM 		= null;
	
	public String HJ_GYE_SANGTE 			= null;
	public String JJ_SANGTE_YMD 			= null;
	public String JJ_C_JIJUM_CD 			= null;
	public String HJ_C_JIJUM_NM 			= null;
	public String JJ_C_GMEK 				= null;
	public String HJ_C_NM 					= null;
	public String JJ_GIBON_PRM 				= null;
	public String JJ_JADONG_CHUNGU_PRM 		= null;
	public String JJ_BOJANG_PRM 			= null;
	public String JJ_JUKRIP_BUMUN_PRM 		= null;
	public String JJ_L_NAPIP_YY 			= null;
	public String JJ_L_NAPIP_MM 			= null;
	public String JJ_NAPIP_CNT 				= null;
	public String JJ_INJUNG_YY 				= null;
	public String JJ_INJUNG_MM 				= null;
	public String HJ_BUNNAP_NM 				= null;
	public String HJ_SU_BANGBAP 			= null;
	public String HJ_BANK_NM 				= null;
	public String JJ_ICHE_ILSU 				= null;
	public String JJ_GYEJA_NO 				= null;
	public String HJ_YEGUM_JU 				= null;
	public String HJ_BE_NM 					= null;
	public String JJ_BE_CNT 				= null;
	public String HJ_YAKGWAN 				= null;
	public String HJ_M_REM 					= null;
	public String JJ_FIL 					= null;
	public String JJ_M_YMD 					= null;
	public String HJ_JADONG 				= null;
	public String JJ_FIL1 					= null;
	public String JJ_J_YMD 					= null;
	public String HJ_JIL_GA 				= null;
	public String HJ_SAGO_NM 				= null;
	public String JJ_SAGO_CNT 				= null;
	public String JJ_SAGO_YMD1 				= null;
	public String JJ_SAGO_YMD2 				= null;
	public String JJ_SAGO_YMD3 				= null;
	public String HJ_INSU_PUMI 				= null;
	public String JJ_BALGB_CNT 				= null;
	public String JJ_BALGB_YMD 				= null;
	public String HJ_M_JIJUM_NM 			= null;
	public String HJ_M_JIBU_NM 				= null;
	public String HJ_M_JOJIK_NM 			= null;
	public String JJ_M_JIJUM_CD 			= null;
	public String JJ_M_JIBU_CD 				= null;
	public String JJ_M_JOJIK_CD 			= null;
	public String HJ_S_JIJUM_NM 			= null;
	public String HJ_S_JIBU_NM 				= null;
	public String HJ_S_JOJIK_NM 			= null;
	public String JJ_S_JIJUM_CD 			= null;
	public String JJ_S_JIBU_CD 				= null;
	public String JJ_S_JOJIK_CD 			= null;
	public String UU_POLI_NO 				= null;
	public String UU_BESU_NO 				= null;	
	public List<SubFUN5072RVO> 	LIST_DATA 	= null;
	
	//2011.03.02 컨버전스 조회 전문에 유선해지 동의여부 한글 필드 추가 (장기보험파트 박준성)
	public String HJ_HEJI_YN = null;
	
	//2011.06.16 컨버전스 조회 전문에 유선해지 동의여부 코드 필드 추가 (장기보험파트 박준성)
	public String JJ_HEJI_YN = null;

	public String getrURL() {
		return rURL;
	}

	public void setrURL(String rURL) {
		this.rURL = rURL;
	}

	public String getJJ_POLI_NO() {
		return JJ_POLI_NO;
	}

	public void setJJ_POLI_NO(String jJ_POLI_NO) {
		JJ_POLI_NO = jJ_POLI_NO;
	}

	public String getCC_CHANNEL() {
		return CC_CHANNEL;
	}

	public void setCC_CHANNEL(String cC_CHANNEL) {
		CC_CHANNEL = cC_CHANNEL;
	}

	public String getCC_UKEY() {
		return CC_UKEY;
	}

	public void setCC_UKEY(String cC_UKEY) {
		CC_UKEY = cC_UKEY;
	}

	public String getCC_PGMID() {
		return CC_PGMID;
	}

	public void setCC_PGMID(String cC_PGMID) {
		CC_PGMID = cC_PGMID;
	}

	public String getCC_PROC_GB() {
		return CC_PROC_GB;
	}

	public void setCC_PROC_GB(String cC_PROC_GB) {
		CC_PROC_GB = cC_PROC_GB;
	}

	public String getCC_FUN_KEY() {
		return CC_FUN_KEY;
	}

	public void setCC_FUN_KEY(String cC_FUN_KEY) {
		CC_FUN_KEY = cC_FUN_KEY;
	}

	public String getCC_USER_GB() {
		return CC_USER_GB;
	}

	public void setCC_USER_GB(String cC_USER_GB) {
		CC_USER_GB = cC_USER_GB;
	}

	public String getCC_USER_CD() {
		return CC_USER_CD;
	}

	public void setCC_USER_CD(String cC_USER_CD) {
		CC_USER_CD = cC_USER_CD;
	}

	public String getCC_JIJUM_CD() {
		return CC_JIJUM_CD;
	}

	public void setCC_JIJUM_CD(String cC_JIJUM_CD) {
		CC_JIJUM_CD = cC_JIJUM_CD;
	}

	public String getCC_JIBU_CD() {
		return CC_JIBU_CD;
	}

	public void setCC_JIBU_CD(String cC_JIBU_CD) {
		CC_JIBU_CD = cC_JIBU_CD;
	}

	public String getCC_PROTOCOL() {
		return CC_PROTOCOL;
	}

	public void setCC_PROTOCOL(String cC_PROTOCOL) {
		CC_PROTOCOL = cC_PROTOCOL;
	}

	public String getCC_COND_CD() {
		return CC_COND_CD;
	}

	public void setCC_COND_CD(String cC_COND_CD) {
		CC_COND_CD = cC_COND_CD;
	}

	public String getCC_LAST_FLAG() {
		return CC_LAST_FLAG;
	}

	public void setCC_LAST_FLAG(String cC_LAST_FLAG) {
		CC_LAST_FLAG = cC_LAST_FLAG;
	}

	public String getCC_CURSOR_MAP() {
		return CC_CURSOR_MAP;
	}

	public void setCC_CURSOR_MAP(String cC_CURSOR_MAP) {
		CC_CURSOR_MAP = cC_CURSOR_MAP;
	}

	public String getCC_CURSOR_IDX() {
		return CC_CURSOR_IDX;
	}

	public void setCC_CURSOR_IDX(String cC_CURSOR_IDX) {
		CC_CURSOR_IDX = cC_CURSOR_IDX;
	}

	public String getCC_MESSAGE_CD() {
		return CC_MESSAGE_CD;
	}

	public void setCC_MESSAGE_CD(String cC_MESSAGE_CD) {
		CC_MESSAGE_CD = cC_MESSAGE_CD;
	}

	public String getHC_MESSAGE_NM() {
		return HC_MESSAGE_NM;
	}

	public void setHC_MESSAGE_NM(String hC_MESSAGE_NM) {
		HC_MESSAGE_NM = hC_MESSAGE_NM;
	}

	public String getCC_SYS_ERR() {
		return CC_SYS_ERR;
	}

	public void setCC_SYS_ERR(String cC_SYS_ERR) {
		CC_SYS_ERR = cC_SYS_ERR;
	}

	public String getCC_FILLER() {
		return CC_FILLER;
	}

	public void setCC_FILLER(String cC_FILLER) {
		CC_FILLER = cC_FILLER;
	}

	public String getJJ_BESU_NO() {
		return JJ_BESU_NO;
	}

	public void setJJ_BESU_NO(String jJ_BESU_NO) {
		JJ_BESU_NO = jJ_BESU_NO;
	}

	public String getJJ_SEL_GB() {
		return JJ_SEL_GB;
	}

	public void setJJ_SEL_GB(String jJ_SEL_GB) {
		JJ_SEL_GB = jJ_SEL_GB;
	}

	public String getJJ_BJ_CD() {
		return JJ_BJ_CD;
	}

	public void setJJ_BJ_CD(String jJ_BJ_CD) {
		JJ_BJ_CD = jJ_BJ_CD;
	}

	public String getJJ_DANCHE_GB() {
		return JJ_DANCHE_GB;
	}

	public void setJJ_DANCHE_GB(String jJ_DANCHE_GB) {
		JJ_DANCHE_GB = jJ_DANCHE_GB;
	}

	public String getHJ_BJ_NAME() {
		return HJ_BJ_NAME;
	}

	public void setHJ_BJ_NAME(String hJ_BJ_NAME) {
		HJ_BJ_NAME = hJ_BJ_NAME;
	}

	public String getHJ_BJ_GBN() {
		return HJ_BJ_GBN;
	}

	public void setHJ_BJ_GBN(String hJ_BJ_GBN) {
		HJ_BJ_GBN = hJ_BJ_GBN;
	}

	public String getJJ_GOGEK_GB() {
		return JJ_GOGEK_GB;
	}

	public void setJJ_GOGEK_GB(String jJ_GOGEK_GB) {
		JJ_GOGEK_GB = jJ_GOGEK_GB;
	}

	public String getJJ_BH_SYMD() {
		return JJ_BH_SYMD;
	}

	public void setJJ_BH_SYMD(String jJ_BH_SYMD) {
		JJ_BH_SYMD = jJ_BH_SYMD;
	}

	public String getJJ_BH_EYMD() {
		return JJ_BH_EYMD;
	}

	public void setJJ_BH_EYMD(String jJ_BH_EYMD) {
		JJ_BH_EYMD = jJ_BH_EYMD;
	}

	public String getHJ_BH_NM() {
		return HJ_BH_NM;
	}

	public void setHJ_BH_NM(String hJ_BH_NM) {
		HJ_BH_NM = hJ_BH_NM;
	}

	public String getJJ_CHUNG_YMD() {
		return JJ_CHUNG_YMD;
	}

	public void setJJ_CHUNG_YMD(String jJ_CHUNG_YMD) {
		JJ_CHUNG_YMD = jJ_CHUNG_YMD;
	}

	public String getHJ_GYE_NAME() {
		return HJ_GYE_NAME;
	}

	public void setHJ_GYE_NAME(String hJ_GYE_NAME) {
		HJ_GYE_NAME = hJ_GYE_NAME;
	}

	public String getJJ_GYE_JUMIN() {
		return JJ_GYE_JUMIN;
	}

	public void setJJ_GYE_JUMIN(String jJ_GYE_JUMIN) {
		JJ_GYE_JUMIN = jJ_GYE_JUMIN;
	}

	public String getJJ_GYE_TEL1() {
		return JJ_GYE_TEL1;
	}

	public void setJJ_GYE_TEL1(String jJ_GYE_TEL1) {
		JJ_GYE_TEL1 = jJ_GYE_TEL1;
	}

	public String getJJ_GYE_TEL2() {
		return JJ_GYE_TEL2;
	}

	public void setJJ_GYE_TEL2(String jJ_GYE_TEL2) {
		JJ_GYE_TEL2 = jJ_GYE_TEL2;
	}

	public String getJJ_GYE_TEL3() {
		return JJ_GYE_TEL3;
	}

	public void setJJ_GYE_TEL3(String jJ_GYE_TEL3) {
		JJ_GYE_TEL3 = jJ_GYE_TEL3;
	}

	public String getHJ_GUKGA_NM() {
		return HJ_GUKGA_NM;
	}

	public void setHJ_GUKGA_NM(String hJ_GUKGA_NM) {
		HJ_GUKGA_NM = hJ_GUKGA_NM;
	}

	public String getJJ_GYE_ZIP1() {
		return JJ_GYE_ZIP1;
	}

	public void setJJ_GYE_ZIP1(String jJ_GYE_ZIP1) {
		JJ_GYE_ZIP1 = jJ_GYE_ZIP1;
	}

	public String getJJ_GYE_ZIP2() {
		return JJ_GYE_ZIP2;
	}

	public void setJJ_GYE_ZIP2(String jJ_GYE_ZIP2) {
		JJ_GYE_ZIP2 = jJ_GYE_ZIP2;
	}

	public String getHJ_GYE_ADDR1() {
		return HJ_GYE_ADDR1;
	}

	public void setHJ_GYE_ADDR1(String hJ_GYE_ADDR1) {
		HJ_GYE_ADDR1 = hJ_GYE_ADDR1;
	}

	public String getHJ_GYE_ADDR2() {
		return HJ_GYE_ADDR2;
	}

	public void setHJ_GYE_ADDR2(String hJ_GYE_ADDR2) {
		HJ_GYE_ADDR2 = hJ_GYE_ADDR2;
	}

	public String getJJ_BALGUP_GB() {
		return JJ_BALGUP_GB;
	}

	public void setJJ_BALGUP_GB(String jJ_BALGUP_GB) {
		JJ_BALGUP_GB = jJ_BALGUP_GB;
	}

	public String getHJ_BALGUP_NM() {
		return HJ_BALGUP_NM;
	}

	public void setHJ_BALGUP_NM(String hJ_BALGUP_NM) {
		HJ_BALGUP_NM = hJ_BALGUP_NM;
	}

	public String getJJ_ILBAN_POLI_NO() {
		return JJ_ILBAN_POLI_NO;
	}

	public void setJJ_ILBAN_POLI_NO(String jJ_ILBAN_POLI_NO) {
		JJ_ILBAN_POLI_NO = jJ_ILBAN_POLI_NO;
	}

	public String getHJ_ILBAN_PIBO_NM() {
		return HJ_ILBAN_PIBO_NM;
	}

	public void setHJ_ILBAN_PIBO_NM(String hJ_ILBAN_PIBO_NM) {
		HJ_ILBAN_PIBO_NM = hJ_ILBAN_PIBO_NM;
	}

	public String getJJ_ILBAN_PIBO_JUMIN() {
		return JJ_ILBAN_PIBO_JUMIN;
	}

	public void setJJ_ILBAN_PIBO_JUMIN(String jJ_ILBAN_PIBO_JUMIN) {
		JJ_ILBAN_PIBO_JUMIN = jJ_ILBAN_PIBO_JUMIN;
	}

	public String getJJ_ILBAN_BJ_NM() {
		return JJ_ILBAN_BJ_NM;
	}

	public void setJJ_ILBAN_BJ_NM(String jJ_ILBAN_BJ_NM) {
		JJ_ILBAN_BJ_NM = jJ_ILBAN_BJ_NM;
	}

	public String getJJ_ILBAN_BOHUM_SYMD() {
		return JJ_ILBAN_BOHUM_SYMD;
	}

	public void setJJ_ILBAN_BOHUM_SYMD(String jJ_ILBAN_BOHUM_SYMD) {
		JJ_ILBAN_BOHUM_SYMD = jJ_ILBAN_BOHUM_SYMD;
	}

	public String getJJ_ILBAN_BOHUM_EYMD() {
		return JJ_ILBAN_BOHUM_EYMD;
	}

	public void setJJ_ILBAN_BOHUM_EYMD(String jJ_ILBAN_BOHUM_EYMD) {
		JJ_ILBAN_BOHUM_EYMD = jJ_ILBAN_BOHUM_EYMD;
	}

	public String getJJ_ILBAN_JUKYONG_PRM() {
		return JJ_ILBAN_JUKYONG_PRM;
	}

	public void setJJ_ILBAN_JUKYONG_PRM(String jJ_ILBAN_JUKYONG_PRM) {
		JJ_ILBAN_JUKYONG_PRM = jJ_ILBAN_JUKYONG_PRM;
	}

	public String getHJ_GYE_SANGTE() {
		return HJ_GYE_SANGTE;
	}

	public void setHJ_GYE_SANGTE(String hJ_GYE_SANGTE) {
		HJ_GYE_SANGTE = hJ_GYE_SANGTE;
	}

	public String getJJ_SANGTE_YMD() {
		return JJ_SANGTE_YMD;
	}

	public void setJJ_SANGTE_YMD(String jJ_SANGTE_YMD) {
		JJ_SANGTE_YMD = jJ_SANGTE_YMD;
	}

	public String getJJ_C_JIJUM_CD() {
		return JJ_C_JIJUM_CD;
	}

	public void setJJ_C_JIJUM_CD(String jJ_C_JIJUM_CD) {
		JJ_C_JIJUM_CD = jJ_C_JIJUM_CD;
	}

	public String getHJ_C_JIJUM_NM() {
		return HJ_C_JIJUM_NM;
	}

	public void setHJ_C_JIJUM_NM(String hJ_C_JIJUM_NM) {
		HJ_C_JIJUM_NM = hJ_C_JIJUM_NM;
	}

	public String getJJ_C_GMEK() {
		return JJ_C_GMEK;
	}

	public void setJJ_C_GMEK(String jJ_C_GMEK) {
		JJ_C_GMEK = jJ_C_GMEK;
	}

	public String getHJ_C_NM() {
		return HJ_C_NM;
	}

	public void setHJ_C_NM(String hJ_C_NM) {
		HJ_C_NM = hJ_C_NM;
	}

	public String getJJ_GIBON_PRM() {
		return JJ_GIBON_PRM;
	}

	public void setJJ_GIBON_PRM(String jJ_GIBON_PRM) {
		JJ_GIBON_PRM = jJ_GIBON_PRM;
	}

	public String getJJ_JADONG_CHUNGU_PRM() {
		return JJ_JADONG_CHUNGU_PRM;
	}

	public void setJJ_JADONG_CHUNGU_PRM(String jJ_JADONG_CHUNGU_PRM) {
		JJ_JADONG_CHUNGU_PRM = jJ_JADONG_CHUNGU_PRM;
	}

	public String getJJ_BOJANG_PRM() {
		return JJ_BOJANG_PRM;
	}

	public void setJJ_BOJANG_PRM(String jJ_BOJANG_PRM) {
		JJ_BOJANG_PRM = jJ_BOJANG_PRM;
	}

	public String getJJ_JUKRIP_BUMUN_PRM() {
		return JJ_JUKRIP_BUMUN_PRM;
	}

	public void setJJ_JUKRIP_BUMUN_PRM(String jJ_JUKRIP_BUMUN_PRM) {
		JJ_JUKRIP_BUMUN_PRM = jJ_JUKRIP_BUMUN_PRM;
	}

	public String getJJ_L_NAPIP_YY() {
		return JJ_L_NAPIP_YY;
	}

	public void setJJ_L_NAPIP_YY(String jJ_L_NAPIP_YY) {
		JJ_L_NAPIP_YY = jJ_L_NAPIP_YY;
	}

	public String getJJ_L_NAPIP_MM() {
		return JJ_L_NAPIP_MM;
	}

	public void setJJ_L_NAPIP_MM(String jJ_L_NAPIP_MM) {
		JJ_L_NAPIP_MM = jJ_L_NAPIP_MM;
	}

	public String getJJ_NAPIP_CNT() {
		return JJ_NAPIP_CNT;
	}

	public void setJJ_NAPIP_CNT(String jJ_NAPIP_CNT) {
		JJ_NAPIP_CNT = jJ_NAPIP_CNT;
	}

	public String getJJ_INJUNG_YY() {
		return JJ_INJUNG_YY;
	}

	public void setJJ_INJUNG_YY(String jJ_INJUNG_YY) {
		JJ_INJUNG_YY = jJ_INJUNG_YY;
	}

	public String getJJ_INJUNG_MM() {
		return JJ_INJUNG_MM;
	}

	public void setJJ_INJUNG_MM(String jJ_INJUNG_MM) {
		JJ_INJUNG_MM = jJ_INJUNG_MM;
	}

	public String getHJ_BUNNAP_NM() {
		return HJ_BUNNAP_NM;
	}

	public void setHJ_BUNNAP_NM(String hJ_BUNNAP_NM) {
		HJ_BUNNAP_NM = hJ_BUNNAP_NM;
	}

	public String getHJ_SU_BANGBAP() {
		return HJ_SU_BANGBAP;
	}

	public void setHJ_SU_BANGBAP(String hJ_SU_BANGBAP) {
		HJ_SU_BANGBAP = hJ_SU_BANGBAP;
	}

	public String getHJ_BANK_NM() {
		return HJ_BANK_NM;
	}

	public void setHJ_BANK_NM(String hJ_BANK_NM) {
		HJ_BANK_NM = hJ_BANK_NM;
	}

	public String getJJ_ICHE_ILSU() {
		return JJ_ICHE_ILSU;
	}

	public void setJJ_ICHE_ILSU(String jJ_ICHE_ILSU) {
		JJ_ICHE_ILSU = jJ_ICHE_ILSU;
	}

	public String getJJ_GYEJA_NO() {
		return JJ_GYEJA_NO;
	}

	public void setJJ_GYEJA_NO(String jJ_GYEJA_NO) {
		JJ_GYEJA_NO = jJ_GYEJA_NO;
	}

	public String getHJ_YEGUM_JU() {
		return HJ_YEGUM_JU;
	}

	public void setHJ_YEGUM_JU(String hJ_YEGUM_JU) {
		HJ_YEGUM_JU = hJ_YEGUM_JU;
	}

	public String getHJ_BE_NM() {
		return HJ_BE_NM;
	}

	public void setHJ_BE_NM(String hJ_BE_NM) {
		HJ_BE_NM = hJ_BE_NM;
	}

	public String getJJ_BE_CNT() {
		return JJ_BE_CNT;
	}

	public void setJJ_BE_CNT(String jJ_BE_CNT) {
		JJ_BE_CNT = jJ_BE_CNT;
	}

	public String getHJ_YAKGWAN() {
		return HJ_YAKGWAN;
	}

	public void setHJ_YAKGWAN(String hJ_YAKGWAN) {
		HJ_YAKGWAN = hJ_YAKGWAN;
	}

	public String getHJ_M_REM() {
		return HJ_M_REM;
	}

	public void setHJ_M_REM(String hJ_M_REM) {
		HJ_M_REM = hJ_M_REM;
	}

	public String getJJ_FIL() {
		return JJ_FIL;
	}

	public void setJJ_FIL(String jJ_FIL) {
		JJ_FIL = jJ_FIL;
	}

	public String getJJ_M_YMD() {
		return JJ_M_YMD;
	}

	public void setJJ_M_YMD(String jJ_M_YMD) {
		JJ_M_YMD = jJ_M_YMD;
	}

	public String getHJ_JADONG() {
		return HJ_JADONG;
	}

	public void setHJ_JADONG(String hJ_JADONG) {
		HJ_JADONG = hJ_JADONG;
	}

	public String getJJ_FIL1() {
		return JJ_FIL1;
	}

	public void setJJ_FIL1(String jJ_FIL1) {
		JJ_FIL1 = jJ_FIL1;
	}

	public String getJJ_J_YMD() {
		return JJ_J_YMD;
	}

	public void setJJ_J_YMD(String jJ_J_YMD) {
		JJ_J_YMD = jJ_J_YMD;
	}

	public String getHJ_JIL_GA() {
		return HJ_JIL_GA;
	}

	public void setHJ_JIL_GA(String hJ_JIL_GA) {
		HJ_JIL_GA = hJ_JIL_GA;
	}

	public String getHJ_SAGO_NM() {
		return HJ_SAGO_NM;
	}

	public void setHJ_SAGO_NM(String hJ_SAGO_NM) {
		HJ_SAGO_NM = hJ_SAGO_NM;
	}

	public String getJJ_SAGO_CNT() {
		return JJ_SAGO_CNT;
	}

	public void setJJ_SAGO_CNT(String jJ_SAGO_CNT) {
		JJ_SAGO_CNT = jJ_SAGO_CNT;
	}

	public String getJJ_SAGO_YMD1() {
		return JJ_SAGO_YMD1;
	}

	public void setJJ_SAGO_YMD1(String jJ_SAGO_YMD1) {
		JJ_SAGO_YMD1 = jJ_SAGO_YMD1;
	}

	public String getJJ_SAGO_YMD2() {
		return JJ_SAGO_YMD2;
	}

	public void setJJ_SAGO_YMD2(String jJ_SAGO_YMD2) {
		JJ_SAGO_YMD2 = jJ_SAGO_YMD2;
	}

	public String getJJ_SAGO_YMD3() {
		return JJ_SAGO_YMD3;
	}

	public void setJJ_SAGO_YMD3(String jJ_SAGO_YMD3) {
		JJ_SAGO_YMD3 = jJ_SAGO_YMD3;
	}

	public String getHJ_INSU_PUMI() {
		return HJ_INSU_PUMI;
	}

	public void setHJ_INSU_PUMI(String hJ_INSU_PUMI) {
		HJ_INSU_PUMI = hJ_INSU_PUMI;
	}

	public String getJJ_BALGB_CNT() {
		return JJ_BALGB_CNT;
	}

	public void setJJ_BALGB_CNT(String jJ_BALGB_CNT) {
		JJ_BALGB_CNT = jJ_BALGB_CNT;
	}

	public String getJJ_BALGB_YMD() {
		return JJ_BALGB_YMD;
	}

	public void setJJ_BALGB_YMD(String jJ_BALGB_YMD) {
		JJ_BALGB_YMD = jJ_BALGB_YMD;
	}

	public String getHJ_M_JIJUM_NM() {
		return HJ_M_JIJUM_NM;
	}

	public void setHJ_M_JIJUM_NM(String hJ_M_JIJUM_NM) {
		HJ_M_JIJUM_NM = hJ_M_JIJUM_NM;
	}

	public String getHJ_M_JIBU_NM() {
		return HJ_M_JIBU_NM;
	}

	public void setHJ_M_JIBU_NM(String hJ_M_JIBU_NM) {
		HJ_M_JIBU_NM = hJ_M_JIBU_NM;
	}

	public String getHJ_M_JOJIK_NM() {
		return HJ_M_JOJIK_NM;
	}

	public void setHJ_M_JOJIK_NM(String hJ_M_JOJIK_NM) {
		HJ_M_JOJIK_NM = hJ_M_JOJIK_NM;
	}

	public String getJJ_M_JIJUM_CD() {
		return JJ_M_JIJUM_CD;
	}

	public void setJJ_M_JIJUM_CD(String jJ_M_JIJUM_CD) {
		JJ_M_JIJUM_CD = jJ_M_JIJUM_CD;
	}

	public String getJJ_M_JIBU_CD() {
		return JJ_M_JIBU_CD;
	}

	public void setJJ_M_JIBU_CD(String jJ_M_JIBU_CD) {
		JJ_M_JIBU_CD = jJ_M_JIBU_CD;
	}

	public String getJJ_M_JOJIK_CD() {
		return JJ_M_JOJIK_CD;
	}

	public void setJJ_M_JOJIK_CD(String jJ_M_JOJIK_CD) {
		JJ_M_JOJIK_CD = jJ_M_JOJIK_CD;
	}

	public String getHJ_S_JIJUM_NM() {
		return HJ_S_JIJUM_NM;
	}

	public void setHJ_S_JIJUM_NM(String hJ_S_JIJUM_NM) {
		HJ_S_JIJUM_NM = hJ_S_JIJUM_NM;
	}

	public String getHJ_S_JIBU_NM() {
		return HJ_S_JIBU_NM;
	}

	public void setHJ_S_JIBU_NM(String hJ_S_JIBU_NM) {
		HJ_S_JIBU_NM = hJ_S_JIBU_NM;
	}

	public String getHJ_S_JOJIK_NM() {
		return HJ_S_JOJIK_NM;
	}

	public void setHJ_S_JOJIK_NM(String hJ_S_JOJIK_NM) {
		HJ_S_JOJIK_NM = hJ_S_JOJIK_NM;
	}

	public String getJJ_S_JIJUM_CD() {
		return JJ_S_JIJUM_CD;
	}

	public void setJJ_S_JIJUM_CD(String jJ_S_JIJUM_CD) {
		JJ_S_JIJUM_CD = jJ_S_JIJUM_CD;
	}

	public String getJJ_S_JIBU_CD() {
		return JJ_S_JIBU_CD;
	}

	public void setJJ_S_JIBU_CD(String jJ_S_JIBU_CD) {
		JJ_S_JIBU_CD = jJ_S_JIBU_CD;
	}

	public String getJJ_S_JOJIK_CD() {
		return JJ_S_JOJIK_CD;
	}

	public void setJJ_S_JOJIK_CD(String jJ_S_JOJIK_CD) {
		JJ_S_JOJIK_CD = jJ_S_JOJIK_CD;
	}

	public String getUU_POLI_NO() {
		return UU_POLI_NO;
	}

	public void setUU_POLI_NO(String uU_POLI_NO) {
		UU_POLI_NO = uU_POLI_NO;
	}

	public String getUU_BESU_NO() {
		return UU_BESU_NO;
	}

	public void setUU_BESU_NO(String uU_BESU_NO) {
		UU_BESU_NO = uU_BESU_NO;
	}

	public String getHJ_HEJI_YN() {
		return HJ_HEJI_YN;
	}

	public void setHJ_HEJI_YN(String hJ_HEJI_YN) {
		HJ_HEJI_YN = hJ_HEJI_YN;
	}

	public String getJJ_HEJI_YN() {
		return JJ_HEJI_YN;
	}

	public void setJJ_HEJI_YN(String jJ_HEJI_YN) {
		JJ_HEJI_YN = jJ_HEJI_YN;
	}

	public static String getProid() {
		return proid;
	}

	public static String getTrid() {
		return trid;
	}

	public List<SubFUN5072RVO> getLIST_DATA() {
		return LIST_DATA;
	}

	public void setLIST_DATA(List<SubFUN5072RVO> lIST_DATA) {
		LIST_DATA = lIST_DATA;
	}

}
