package com.idongbu.smartcustomer.vo;


//가상계좌통합부여
public class SubFYA1140RVO  {
	public String RE_PROCESS;
	public String H_RE_BANK_NM;
	public String RE_GYEJWA_NO;
	public String RE_JUMIN_NO;
	public String H_RE_GYEYAKJA_NAME;
	public String RE_ASSIGN_DATE;
	public String RE_SINCHUNG_AMT;
	public String RE_GYEJWA_NO_SEQ; 
	public String RE_BANK_CODE;
	public String SE_PROTECT_FLD;
	
	
	public String getRE_PROCESS() {
		return RE_PROCESS;
	}
	public void setRE_PROCESS(String rE_PROCESS) {
		RE_PROCESS = rE_PROCESS;
	}
	public String getH_RE_BANK_NM() {
		return H_RE_BANK_NM;
	}
	public void setH_RE_BANK_NM(String h_RE_BANK_NM) {
		H_RE_BANK_NM = h_RE_BANK_NM;
	}
	public String getRE_GYEJWA_NO() {
		return RE_GYEJWA_NO;
	}
	public void setRE_GYEJWA_NO(String rE_GYEJWA_NO) {
		RE_GYEJWA_NO = rE_GYEJWA_NO;
	}
	public String getRE_JUMIN_NO() {
		return RE_JUMIN_NO;
	}
	public void setRE_JUMIN_NO(String rE_JUMIN_NO) {
		RE_JUMIN_NO = rE_JUMIN_NO;
	}
	public String getH_RE_GYEYAKJA_NAME() {
		return H_RE_GYEYAKJA_NAME;
	}
	public void setH_RE_GYEYAKJA_NAME(String h_RE_GYEYAKJA_NAME) {
		H_RE_GYEYAKJA_NAME = h_RE_GYEYAKJA_NAME;
	}
	public String getRE_ASSIGN_DATE() {
		return RE_ASSIGN_DATE;
	}
	public void setRE_ASSIGN_DATE(String rE_ASSIGN_DATE) {
		RE_ASSIGN_DATE = rE_ASSIGN_DATE;
	}
	public String getRE_SINCHUNG_AMT() {
		return RE_SINCHUNG_AMT;
	}
	public void setRE_SINCHUNG_AMT(String rE_SINCHUNG_AMT) {
		RE_SINCHUNG_AMT = rE_SINCHUNG_AMT;
	}
	public String getRE_GYEJWA_NO_SEQ() {
		return RE_GYEJWA_NO_SEQ;
	}
	public void setRE_GYEJWA_NO_SEQ(String rE_GYEJWA_NO_SEQ) {
		RE_GYEJWA_NO_SEQ = rE_GYEJWA_NO_SEQ;
	}
	public String getRE_BANK_CODE() {
		return RE_BANK_CODE;
	}
	public void setRE_BANK_CODE(String rE_BANK_CODE) {
		RE_BANK_CODE = rE_BANK_CODE;
	}
	public String getSE_PROTECT_FLD() {
		return SE_PROTECT_FLD;
	}
	public void setSE_PROTECT_FLD(String sE_PROTECT_FLD) {
		SE_PROTECT_FLD = sE_PROTECT_FLD;
	}
	
	
	
	
}