package com.idongbu.smartcustomer.vo;

import com.idongbu.common.vo.CMMVO;


//약관대출신청
public class CmmFUA6011RVO extends CMMVO {
	
	public CmmFUA6011RVO() {
		super.setPGMID(proid);
		super.setTRID(trid);
	}
	
	private final static String proid		= "FUA6011R";
	private final static String trid		= "UA6B";
	private String rURL				= "";

	private String CC_SAWON_NO   = null; // 사번	2차에선 상속받은 필드
	
	// 입력
	private String JJ_LENGTH = null;
	private String JJ_PROCESS_ID = null;
	private String JJ_JUMIN_NO    = null; // 주민등록번호
	private String JJ_POLI_NO   = null; // 증권번호
	private String JJ_POLI_NO_MASKING   = null; // 증권번호 마스킹처리
	private String JJ_SONGGUM_SEQ = null; // 송금일련번호
	private String JJ_DECHUL_GM  = null; // 약대신청액(대출신청액)
	private String JJ_ICHE_D  = null; // 이체일(대출이자납입일)
	private String JJ_BONIN_YN = null; // 본인여부(Y:예금주본인, SPACE  OR  N : 본인아님)
	private String JJ_INJNG = null; // 인증구분(1:공인인증, 2:신용카드)
	private String JJ_ARS_RC = null;
	private String JJ_JUNPYO = null;
	private String JJ_IN1_FIL = null;	
	
	//2008.12.15 전문변경건 추가 luxncool     
	private String JJ_S_POLI_NO = null; 
	private String JJ_S_BANK_CD = null;
	private String JJ_S_BANK_NM = null;
	private String JJ_S_GYEJWA_NO = null;	
	private String JJ_JIKWON_PA = null;
	
	//2010.09.15 이자납입계좌추가 cjh
	private String JJ_I_BANK_CD = null;	
	private String JJ_I_BANK_NM = null;	
	private String JJ_I_GYEJWA_NO = null;
	
	//2012.05.21 계좌구분자 추가 빈현욱 2012.05.21
	private String JJ_GYEJWA_YN = null;
	     
	// 출력
	private String CC_CHANNEL = null;
	private String CC_UKEY = null;
	private String CC_PGMID = null;
	private String CC_PROC_GB = null;
	private String CC_FUN_KEY = null;
	private String CC_USER_GB = null;
	private String CC_USER_CD = null;
	private String CC_JIJUM_CD = null;
	private String CC_JIBU_CD = null;
	private String CC_PROTOCOL = null;
	private String CC_COND_CD = null;
	private String CC_LAST_FLAG = null;
	private String CC_CURSOR_MAP = null;
	private String CC_CURSOR_IDX = null;
	private String CC_MESSAGE_CD = null;
	private String HC_MESSAGE_NM = null;
	private String CC_SYS_ERR = null;
	private String CC_FILLER = null;
//	private String JJ_LENGTH = null;
//	private String JJ_PROCESS_ID = null;
//	private String JJ_POLI_NO = null;
//	private String JJ_SONGGUM_SEQ = null;
//	private String JJ_DECHUL_GM = null;
//	private String JJ_ICHE_D = null;
//	private String JJ_BONIN_YN = null;
//	private String JJ_S_POLI_NO = null; 
//	private String JJ_S_BANK_CD = null;
//	private String JJ_S_GYEJWA_NO = null;		
	private String HJ_BJ_NM = null;
	private String JJ_GISAN_GM = null;
	private String JJ_NAPIP_YMD = null;
	private String JJ_JUNG_IYUL = null;
	private String JJ_GANUNG_GM = null;
	private String JJ_BANK_CD = null;
	private String HJ_BANK_NM = null;
	private String JJ_BANK_JIJUM = null;
	private String HJ_BANK_JIJUM_NM = null;
	private String JJ_GYEJWA_NO = null;
	private String HJ_YEGMJU_NM = null;
	private String JJ_YEGMJU_TEL = null;
	private String JJ_RECI_CD = null;
	private String JJ_NAPIP_IJA = null;
	private String JJ_INJIDAE = null;
	private String JJ_GONGJE_GM = null;
	private String JJ_CHAGAM_GM = null;
	private String JJ_YUNC_IYUL = null;
//	private String JJ_INJNG = null;
//	private String JJ_ARS_RC = null;
//	private String JJ_JUNPYO = null;
//	private String JJ_IN1_FIL = null;
	private String FILLER = null;
	private String FILLER_1 = null;
	public String getrURL() {
		return rURL;
	}
	public void setrURL(String rURL) {
		this.rURL = rURL;
	}
	public String getJJ_LENGTH() {
		return JJ_LENGTH;
	}
	public void setJJ_LENGTH(String jJ_LENGTH) {
		JJ_LENGTH = jJ_LENGTH;
	}
	public String getJJ_PROCESS_ID() {
		return JJ_PROCESS_ID;
	}
	public void setJJ_PROCESS_ID(String jJ_PROCESS_ID) {
		JJ_PROCESS_ID = jJ_PROCESS_ID;
	}
	public String getJJ_JUMIN_NO() {
		return JJ_JUMIN_NO;
	}
	public void setJJ_JUMIN_NO(String jJ_JUMIN_NO) {
		JJ_JUMIN_NO = jJ_JUMIN_NO;
	}
	public String getJJ_POLI_NO() {
		return JJ_POLI_NO;
	}
	public void setJJ_POLI_NO(String jJ_POLI_NO) {
		JJ_POLI_NO = jJ_POLI_NO;
	}
	public String getJJ_SONGGUM_SEQ() {
		return JJ_SONGGUM_SEQ;
	}
	public void setJJ_SONGGUM_SEQ(String jJ_SONGGUM_SEQ) {
		JJ_SONGGUM_SEQ = jJ_SONGGUM_SEQ;
	}
	public String getJJ_DECHUL_GM() {
		return JJ_DECHUL_GM;
	}
	public void setJJ_DECHUL_GM(String jJ_DECHUL_GM) {
		JJ_DECHUL_GM = jJ_DECHUL_GM;
	}
	public String getJJ_ICHE_D() {
		return JJ_ICHE_D;
	}
	public void setJJ_ICHE_D(String jJ_ICHE_D) {
		JJ_ICHE_D = jJ_ICHE_D;
	}
	public String getJJ_BONIN_YN() {
		return JJ_BONIN_YN;
	}
	public void setJJ_BONIN_YN(String jJ_BONIN_YN) {
		JJ_BONIN_YN = jJ_BONIN_YN;
	}
	public String getJJ_INJNG() {
		return JJ_INJNG;
	}
	public void setJJ_INJNG(String jJ_INJNG) {
		JJ_INJNG = jJ_INJNG;
	}
	public String getJJ_ARS_RC() {
		return JJ_ARS_RC;
	}
	public void setJJ_ARS_RC(String jJ_ARS_RC) {
		JJ_ARS_RC = jJ_ARS_RC;
	}
	public String getJJ_JUNPYO() {
		return JJ_JUNPYO;
	}
	public void setJJ_JUNPYO(String jJ_JUNPYO) {
		JJ_JUNPYO = jJ_JUNPYO;
	}
	public String getJJ_IN1_FIL() {
		return JJ_IN1_FIL;
	}
	public void setJJ_IN1_FIL(String jJ_IN1_FIL) {
		JJ_IN1_FIL = jJ_IN1_FIL;
	}
	public String getJJ_S_POLI_NO() {
		return JJ_S_POLI_NO;
	}
	public void setJJ_S_POLI_NO(String jJ_S_POLI_NO) {
		JJ_S_POLI_NO = jJ_S_POLI_NO;
	}
	public String getJJ_S_BANK_CD() {
		return JJ_S_BANK_CD;
	}
	public void setJJ_S_BANK_CD(String jJ_S_BANK_CD) {
		JJ_S_BANK_CD = jJ_S_BANK_CD;
	}
	public String getJJ_S_GYEJWA_NO() {
		return JJ_S_GYEJWA_NO;
	}
	public void setJJ_S_GYEJWA_NO(String jJ_S_GYEJWA_NO) {
		JJ_S_GYEJWA_NO = jJ_S_GYEJWA_NO;
	}
	public String getJJ_JIKWON_PA() {
		return JJ_JIKWON_PA;
	}
	public void setJJ_JIKWON_PA(String jJ_JIKWON_PA) {
		JJ_JIKWON_PA = jJ_JIKWON_PA;
	}
	public String getJJ_I_BANK_CD() {
		return JJ_I_BANK_CD;
	}
	public void setJJ_I_BANK_CD(String jJ_I_BANK_CD) {
		JJ_I_BANK_CD = jJ_I_BANK_CD;
	}
	public String getJJ_I_GYEJWA_NO() {
		return JJ_I_GYEJWA_NO;
	}
	public void setJJ_I_GYEJWA_NO(String jJ_I_GYEJWA_NO) {
		JJ_I_GYEJWA_NO = jJ_I_GYEJWA_NO;
	}
	public String getJJ_GYEJWA_YN() {
		return JJ_GYEJWA_YN;
	}
	public void setJJ_GYEJWA_YN(String jJ_GYEJWA_YN) {
		JJ_GYEJWA_YN = jJ_GYEJWA_YN;
	}
	public String getCC_CHANNEL() {
		return CC_CHANNEL;
	}
	public void setCC_CHANNEL(String cC_CHANNEL) {
		CC_CHANNEL = cC_CHANNEL;
	}
	public String getCC_UKEY() {
		return CC_UKEY;
	}
	public void setCC_UKEY(String cC_UKEY) {
		CC_UKEY = cC_UKEY;
	}
	public String getCC_PGMID() {
		return CC_PGMID;
	}
	public void setCC_PGMID(String cC_PGMID) {
		CC_PGMID = cC_PGMID;
	}
	public String getCC_PROC_GB() {
		return CC_PROC_GB;
	}
	public void setCC_PROC_GB(String cC_PROC_GB) {
		CC_PROC_GB = cC_PROC_GB;
	}
	public String getCC_FUN_KEY() {
		return CC_FUN_KEY;
	}
	public void setCC_FUN_KEY(String cC_FUN_KEY) {
		CC_FUN_KEY = cC_FUN_KEY;
	}
	public String getCC_USER_GB() {
		return CC_USER_GB;
	}
	public void setCC_USER_GB(String cC_USER_GB) {
		CC_USER_GB = cC_USER_GB;
	}
	public String getCC_USER_CD() {
		return CC_USER_CD;
	}
	public void setCC_USER_CD(String cC_USER_CD) {
		CC_USER_CD = cC_USER_CD;
	}
	public String getCC_JIJUM_CD() {
		return CC_JIJUM_CD;
	}
	public void setCC_JIJUM_CD(String cC_JIJUM_CD) {
		CC_JIJUM_CD = cC_JIJUM_CD;
	}
	public String getCC_JIBU_CD() {
		return CC_JIBU_CD;
	}
	public void setCC_JIBU_CD(String cC_JIBU_CD) {
		CC_JIBU_CD = cC_JIBU_CD;
	}
	public String getCC_PROTOCOL() {
		return CC_PROTOCOL;
	}
	public void setCC_PROTOCOL(String cC_PROTOCOL) {
		CC_PROTOCOL = cC_PROTOCOL;
	}
	public String getCC_COND_CD() {
		return CC_COND_CD;
	}
	public void setCC_COND_CD(String cC_COND_CD) {
		CC_COND_CD = cC_COND_CD;
	}
	public String getCC_LAST_FLAG() {
		return CC_LAST_FLAG;
	}
	public void setCC_LAST_FLAG(String cC_LAST_FLAG) {
		CC_LAST_FLAG = cC_LAST_FLAG;
	}
	public String getCC_CURSOR_MAP() {
		return CC_CURSOR_MAP;
	}
	public void setCC_CURSOR_MAP(String cC_CURSOR_MAP) {
		CC_CURSOR_MAP = cC_CURSOR_MAP;
	}
	public String getCC_CURSOR_IDX() {
		return CC_CURSOR_IDX;
	}
	public void setCC_CURSOR_IDX(String cC_CURSOR_IDX) {
		CC_CURSOR_IDX = cC_CURSOR_IDX;
	}
	public String getCC_MESSAGE_CD() {
		return CC_MESSAGE_CD;
	}
	public void setCC_MESSAGE_CD(String cC_MESSAGE_CD) {
		CC_MESSAGE_CD = cC_MESSAGE_CD;
	}
	public String getHC_MESSAGE_NM() {
		return HC_MESSAGE_NM;
	}
	public void setHC_MESSAGE_NM(String hC_MESSAGE_NM) {
		HC_MESSAGE_NM = hC_MESSAGE_NM;
	}
	public String getCC_SYS_ERR() {
		return CC_SYS_ERR;
	}
	public void setCC_SYS_ERR(String cC_SYS_ERR) {
		CC_SYS_ERR = cC_SYS_ERR;
	}
	public String getCC_FILLER() {
		return CC_FILLER;
	}
	public void setCC_FILLER(String cC_FILLER) {
		CC_FILLER = cC_FILLER;
	}
	public String getHJ_BJ_NM() {
		return HJ_BJ_NM;
	}
	public void setHJ_BJ_NM(String hJ_BJ_NM) {
		HJ_BJ_NM = hJ_BJ_NM;
	}
	public String getJJ_GISAN_GM() {
		return JJ_GISAN_GM;
	}
	public void setJJ_GISAN_GM(String jJ_GISAN_GM) {
		JJ_GISAN_GM = jJ_GISAN_GM;
	}
	public String getJJ_NAPIP_YMD() {
		return JJ_NAPIP_YMD;
	}
	public void setJJ_NAPIP_YMD(String jJ_NAPIP_YMD) {
		JJ_NAPIP_YMD = jJ_NAPIP_YMD;
	}
	public String getJJ_JUNG_IYUL() {
		return JJ_JUNG_IYUL;
	}
	public void setJJ_JUNG_IYUL(String jJ_JUNG_IYUL) {
		JJ_JUNG_IYUL = jJ_JUNG_IYUL;
	}
	public String getJJ_GANUNG_GM() {
		return JJ_GANUNG_GM;
	}
	public void setJJ_GANUNG_GM(String jJ_GANUNG_GM) {
		JJ_GANUNG_GM = jJ_GANUNG_GM;
	}
	public String getJJ_BANK_CD() {
		return JJ_BANK_CD;
	}
	public void setJJ_BANK_CD(String jJ_BANK_CD) {
		JJ_BANK_CD = jJ_BANK_CD;
	}
	public String getHJ_BANK_NM() {
		return HJ_BANK_NM;
	}
	public void setHJ_BANK_NM(String hJ_BANK_NM) {
		HJ_BANK_NM = hJ_BANK_NM;
	}
	public String getJJ_BANK_JIJUM() {
		return JJ_BANK_JIJUM;
	}
	public void setJJ_BANK_JIJUM(String jJ_BANK_JIJUM) {
		JJ_BANK_JIJUM = jJ_BANK_JIJUM;
	}
	public String getHJ_BANK_JIJUM_NM() {
		return HJ_BANK_JIJUM_NM;
	}
	public void setHJ_BANK_JIJUM_NM(String hJ_BANK_JIJUM_NM) {
		HJ_BANK_JIJUM_NM = hJ_BANK_JIJUM_NM;
	}
	public String getJJ_GYEJWA_NO() {
		return JJ_GYEJWA_NO;
	}
	public void setJJ_GYEJWA_NO(String jJ_GYEJWA_NO) {
		JJ_GYEJWA_NO = jJ_GYEJWA_NO;
	}
	public String getHJ_YEGMJU_NM() {
		return HJ_YEGMJU_NM;
	}
	public void setHJ_YEGMJU_NM(String hJ_YEGMJU_NM) {
		HJ_YEGMJU_NM = hJ_YEGMJU_NM;
	}
	public String getJJ_YEGMJU_TEL() {
		return JJ_YEGMJU_TEL;
	}
	public void setJJ_YEGMJU_TEL(String jJ_YEGMJU_TEL) {
		JJ_YEGMJU_TEL = jJ_YEGMJU_TEL;
	}
	public String getJJ_RECI_CD() {
		return JJ_RECI_CD;
	}
	public void setJJ_RECI_CD(String jJ_RECI_CD) {
		JJ_RECI_CD = jJ_RECI_CD;
	}
	public String getJJ_NAPIP_IJA() {
		return JJ_NAPIP_IJA;
	}
	public void setJJ_NAPIP_IJA(String jJ_NAPIP_IJA) {
		JJ_NAPIP_IJA = jJ_NAPIP_IJA;
	}
	public String getJJ_INJIDAE() {
		return JJ_INJIDAE;
	}
	public void setJJ_INJIDAE(String jJ_INJIDAE) {
		JJ_INJIDAE = jJ_INJIDAE;
	}
	public String getJJ_GONGJE_GM() {
		return JJ_GONGJE_GM;
	}
	public void setJJ_GONGJE_GM(String jJ_GONGJE_GM) {
		JJ_GONGJE_GM = jJ_GONGJE_GM;
	}
	public String getJJ_CHAGAM_GM() {
		return JJ_CHAGAM_GM;
	}
	public void setJJ_CHAGAM_GM(String jJ_CHAGAM_GM) {
		JJ_CHAGAM_GM = jJ_CHAGAM_GM;
	}
	public String getJJ_YUNC_IYUL() {
		return JJ_YUNC_IYUL;
	}
	public void setJJ_YUNC_IYUL(String jJ_YUNC_IYUL) {
		JJ_YUNC_IYUL = jJ_YUNC_IYUL;
	}
	public String getFILLER() {
		return FILLER;
	}
	public void setFILLER(String fILLER) {
		FILLER = fILLER;
	}
	public String getFILLER_1() {
		return FILLER_1;
	}
	public void setFILLER_1(String fILLER_1) {
		FILLER_1 = fILLER_1;
	}
	public String getJJ_S_BANK_NM() {
		return JJ_S_BANK_NM;
	}
	public void setJJ_S_BANK_NM(String jJ_S_BANK_NM) {
		JJ_S_BANK_NM = jJ_S_BANK_NM;
	}
	public String getJJ_I_BANK_NM() {
		return JJ_I_BANK_NM;
	}
	public void setJJ_I_BANK_NM(String jJ_I_BANK_NM) {
		JJ_I_BANK_NM = jJ_I_BANK_NM;
	}
	public String getCC_SAWON_NO() {
		return CC_SAWON_NO;
	}
	public void setCC_SAWON_NO(String cC_SAWON_NO) {
		CC_SAWON_NO = cC_SAWON_NO;
	}
	public String getJJ_POLI_NO_MASKING() {
		return JJ_POLI_NO_MASKING;
	}
	public void setJJ_POLI_NO_MASKING(String jJ_POLI_NO_MASKING) {
		JJ_POLI_NO_MASKING = jJ_POLI_NO_MASKING;
	}

}

