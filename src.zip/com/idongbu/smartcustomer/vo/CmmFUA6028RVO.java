package com.idongbu.smartcustomer.vo;

import java.util.List;

import com.idongbu.common.vo.CMMVO;

public class CmmFUA6028RVO extends CMMVO{
	
	public CmmFUA6028RVO() {
		super.setPGMID(this.proid);
		super.setTRID(this.trid);
	}
	
	public static final String proid	= "FUA6028R";
	public static final String trid		= "UA6T";
	public String rURL					= "";
	
	public String CC_USER_GB = null;
	public String CC_USER_CD  = null;
	public String CC_JIJUM_CD = null;
	public String CC_JIBU_CD = null;
	
	public String JJ_JUMIN_NO = null;
	public String HJ_GYEAKJA_NAME = null;
	public String CC_PROTOCOL = null;
	public String CC_PROC_GB = null;
	public String JJ_IN_FILLER = null;
	public String UU_INQ_POLI_NO = null;
	public List<SubFUA6028RVO> LIST_DATA = null;
	public String UU_F_POLI_NO = null;
	public String UU_L_POLI_NO = null;
	
	
	public String getrURL() {
		return rURL;
	}
	public void setrURL(String rURL) {
		this.rURL = rURL;
	}
	public String getCC_USER_GB() {
		return CC_USER_GB;
	}
	public void setCC_USER_GB(String cC_USER_GB) {
		CC_USER_GB = cC_USER_GB;
	}
	public String getCC_USER_CD() {
		return CC_USER_CD;
	}
	public void setCC_USER_CD(String cC_USER_CD) {
		CC_USER_CD = cC_USER_CD;
	}
	public String getCC_JIJUM_CD() {
		return CC_JIJUM_CD;
	}
	public void setCC_JIJUM_CD(String cC_JIJUM_CD) {
		CC_JIJUM_CD = cC_JIJUM_CD;
	}
	public String getCC_JIBU_CD() {
		return CC_JIBU_CD;
	}
	public void setCC_JIBU_CD(String cC_JIBU_CD) {
		CC_JIBU_CD = cC_JIBU_CD;
	}
	public String getJJ_JUMIN_NO() {
		return JJ_JUMIN_NO;
	}
	public void setJJ_JUMIN_NO(String jJ_JUMIN_NO) {
		JJ_JUMIN_NO = jJ_JUMIN_NO;
	}
	public String getHJ_GYEAKJA_NAME() {
		return HJ_GYEAKJA_NAME;
	}
	public void setHJ_GYEAKJA_NAME(String hJ_GYEAKJA_NAME) {
		HJ_GYEAKJA_NAME = hJ_GYEAKJA_NAME;
	}
	public String getCC_PROTOCOL() {
		return CC_PROTOCOL;
	}
	public void setCC_PROTOCOL(String cC_PROTOCOL) {
		CC_PROTOCOL = cC_PROTOCOL;
	}
	public String getCC_PROC_GB() {
		return CC_PROC_GB;
	}
	public void setCC_PROC_GB(String cC_PROC_GB) {
		CC_PROC_GB = cC_PROC_GB;
	}	
	public String getJJ_IN_FILLER() {
		return JJ_IN_FILLER;
	}
	public void setJJ_IN_FILLER(String jJ_IN_FILLER) {
		JJ_IN_FILLER = jJ_IN_FILLER;
	}
	public String getUU_INQ_POLI_NO() {
		return UU_INQ_POLI_NO;
	}
	public void setUU_INQ_POLI_NO(String uU_INQ_POLI_NO) {
		UU_INQ_POLI_NO = uU_INQ_POLI_NO;
	}
	public List<SubFUA6028RVO> getLIST_DATA() {
		return LIST_DATA;
	}
	public void setLIST_DATA(List<SubFUA6028RVO> lIST_DATA) {
		LIST_DATA = lIST_DATA;
	}
	public String getUU_F_POLI_NO() {
		return UU_F_POLI_NO;
	}
	public void setUU_F_POLI_NO(String uU_F_POLI_NO) {
		UU_F_POLI_NO = uU_F_POLI_NO;
	}
	public String getUU_L_POLI_NO() {
		return UU_L_POLI_NO;
	}
	public void setUU_L_POLI_NO(String uU_L_POLI_NO) {
		UU_L_POLI_NO = uU_L_POLI_NO;
	}
	public static String getProid() {
		return proid;
	}
	public static String getTrid() {
		return trid;
	}
	
	
	
}
