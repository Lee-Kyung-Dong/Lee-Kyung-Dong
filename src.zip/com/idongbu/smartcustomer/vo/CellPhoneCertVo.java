package com.idongbu.smartcustomer.vo;

public class CellPhoneCertVo {
	private String certNum		= ""; //요청번호
	private String date			= ""; //요청일시
	private String phoneNo		= ""; //휴대폰번호
	private String phoneCorp	= ""; //이통사
	private String birthDay		= ""; //생년월일
	private String gender		= ""; //성별
	private String nation		= ""; //내국인
	private String name			= ""; //성명
	private String CI			= ""; //연계정보(CI)
	private String result		= ""; //인증결과값
	private String resultCode	= ""; //인증결과코드
	private String resultText	= ""; //인증결과텍스트
	private String check_1		= ""; //인증번호 확인결과 전송 및 SMS재전송 요청을 위한 파라미터 1(수정불가)
	private String check_2		= ""; //인증번호 확인결과 전송 및 SMS재전송 요청을 위한 파라미터 2(수정불가)
	private String check_3		= ""; //인증번호 확인결과 전송 및 SMS재전송 요청을 위한 파라미터 3(수정불가)
	private String DI			= ""; //중복가입확인정보(DI)
	
	
	public String getCertNum() {
		return certNum;
	}
	public void setCertNum(String certNum) {
		this.certNum = certNum;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getPhoneCorp() {
		return phoneCorp;
	}
	public void setPhoneCorp(String phoneCorp) {
		this.phoneCorp = phoneCorp;
	}
	public String getBirthDay() {
		return birthDay;
	}
	public void setBirthDay(String birthDay) {
		this.birthDay = birthDay;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getNation() {
		return nation;
	}
	public void setNation(String nation) {
		this.nation = nation;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCI() {
		return CI;
	}
	public void setCI(String cI) {
		CI = cI;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getResultCode() {
		return resultCode;
	}
	public void setResultCode(String resultCode) {
		this.resultCode = resultCode;
	}
	public String getResultText() {
		return resultText;
	}
	public void setResultText(String resultText) {
		this.resultText = resultText;
	}
	public String getCheck_1() {
		return check_1;
	}
	public void setCheck_1(String check_1) {
		this.check_1 = check_1;
	}
	public String getCheck_2() {
		return check_2;
	}
	public void setCheck_2(String check_2) {
		this.check_2 = check_2;
	}
	public String getCheck_3() {
		return check_3;
	}
	public void setCheck_3(String check_3) {
		this.check_3 = check_3;
	}
	public String getDI() {
		return DI;
	}
	public void setDI(String dI) {
		DI = dI;
	}
	@Override
	public String toString() {
		return "CellPhoneCertVo [certNum=" + certNum + ", date=" + date
				+ ", phoneNo=" + phoneNo + ", phoneCorp=" + phoneCorp
				+ ", birthDay=" + birthDay + ", gender=" + gender + ", nation="
				+ nation + ", name=" + name + ", CI=" + CI + ", result="
				+ result + ", resultCode=" + resultCode + ", resultText="
				+ resultText + ", check_1=" + check_1 + ", check_2=" + check_2
				+ ", check_3=" + check_3 + ", DI=" + DI + "]";
	}
	
	
	
	
}
