package com.idongbu.smartcustomer.vo;

import com.idongbu.common.vo.CMMVO;


//2008.09.12 by hsahn 전문 추가 
//홈페이지/콜센타 약관대출 고객정보확인
public class CmmFBM0319RVO extends CMMVO {
	
	public CmmFBM0319RVO() {
		super.setPGMID(proid);
		super.setTRID(trid);
	}	
	
	private final static String proid		= "FBM0319R";
	private final static String trid			= "BMCF";
	private String rURL						= "";


	// 공통
	private String COMM_CHANNEL = null;
	private String COMM_UNIQUE_KEY = null;
	private String COMM_PGMID = null;
	private String COMM_PROC_GB = null;
	private String COMM_ACTION_KEY = null;
	private String COMM_USER_GB = null;
	private String COMM_USER_ID = null;
	private String COMM_JIJUM_CD = null;
	private String COMM_JIBU_CD = null;
	private String COMM_PROTOCOL = null;
	private String COMM_COND_CD = null;
	private String COMM_LAST_FLAG = null;
	private String COMM_CURSOR_MAP = null;
	private String COMM_CURSOR_IDX = null;
	private String COMM_MESSAGE_CD = null;
	private String HOMM_MESSAGE_NM = null;
	private String COMM_ERR_NAME = null;
	private String COMM_ERR_TEXT = null;
	private String COMM_SYS_CODE = null;
	private String COMM_FILLER = null;
	
	// 입력
	private String SI_GOGEK_NO 		= null;		// 주민번호
	private String SI_SKIP_GB 		= null;		// 01: 홈페이지, 02: 콜센터 -- 09.24 풀음 
	
	// 출력
	private String SO_HP_TEL1		= null; 	// 핸드폰
	private String SO_HP_TEL2		= null; 	// 핸드폰
	private String SO_HP_TEL3		= null; 	// 핸드폰
	private String SO_HP_TEL_YMD		= null; 	// 핸드폰변경일자
	private String SO_H_TEL1 		= null; 	// 집전화
	private String SO_H_TEL2 		= null; 	// 집전화
	private String SO_H_TEL3 		= null; 	// 집전화
	private String SO_H_TEL_YMD		= null; 	// 집전화 변경일자
	private String SO_J_TEL1 		= null; 	// 직장전화
	private String SO_J_TEL2 		= null; 	// 직장전화
	private String SO_J_TEL3 		= null; 	// 직장전화
	private String SO_J_TEL_YMD		= null; 	// 직장전화 변경일자
	private String SO_H_ZIP  		= null; 	// 집주소 우편번호
	private String HO_H_GITA 		= null; 	// 집주소 기타주소
	private String SO_H_JUSO_YMD		= null;		// 집주소 변경일자
	private String SO_J_ZIP  		= null; 	// 직장주소 우편번호
	private String HO_J_GITA 		= null; 	// 직장주소 기타주소
	private String SO_J_JUSO_YMD		= null;		// 직장주소 변경일자
	private String SO_G_ZIP  		= null; 	// 기타주소 우편번호
	private String HO_G_GITA 		= null; 	// 기타주소 기타주소
	private String SO_G_JUSO_YMD		= null;		// 기타주소 변경일자
	private String SO_YMD			= null;		// 전체 최종 변경일자
	
	public String getrURL() {
		return rURL;
	}
	public void setrURL(String rURL) {
		this.rURL = rURL;
	}
	public String getCOMM_CHANNEL() {
		return COMM_CHANNEL;
	}
	public void setCOMM_CHANNEL(String cOMM_CHANNEL) {
		COMM_CHANNEL = cOMM_CHANNEL;
	}
	public String getCOMM_UNIQUE_KEY() {
		return COMM_UNIQUE_KEY;
	}
	public void setCOMM_UNIQUE_KEY(String cOMM_UNIQUE_KEY) {
		COMM_UNIQUE_KEY = cOMM_UNIQUE_KEY;
	}
	public String getCOMM_PGMID() {
		return COMM_PGMID;
	}
	public void setCOMM_PGMID(String cOMM_PGMID) {
		COMM_PGMID = cOMM_PGMID;
	}
	public String getCOMM_PROC_GB() {
		return COMM_PROC_GB;
	}
	public void setCOMM_PROC_GB(String cOMM_PROC_GB) {
		COMM_PROC_GB = cOMM_PROC_GB;
	}
	public String getCOMM_ACTION_KEY() {
		return COMM_ACTION_KEY;
	}
	public void setCOMM_ACTION_KEY(String cOMM_ACTION_KEY) {
		COMM_ACTION_KEY = cOMM_ACTION_KEY;
	}
	public String getCOMM_USER_GB() {
		return COMM_USER_GB;
	}
	public void setCOMM_USER_GB(String cOMM_USER_GB) {
		COMM_USER_GB = cOMM_USER_GB;
	}
	public String getCOMM_USER_ID() {
		return COMM_USER_ID;
	}
	public void setCOMM_USER_ID(String cOMM_USER_ID) {
		COMM_USER_ID = cOMM_USER_ID;
	}
	public String getCOMM_JIJUM_CD() {
		return COMM_JIJUM_CD;
	}
	public void setCOMM_JIJUM_CD(String cOMM_JIJUM_CD) {
		COMM_JIJUM_CD = cOMM_JIJUM_CD;
	}
	public String getCOMM_JIBU_CD() {
		return COMM_JIBU_CD;
	}
	public void setCOMM_JIBU_CD(String cOMM_JIBU_CD) {
		COMM_JIBU_CD = cOMM_JIBU_CD;
	}
	public String getCOMM_PROTOCOL() {
		return COMM_PROTOCOL;
	}
	public void setCOMM_PROTOCOL(String cOMM_PROTOCOL) {
		COMM_PROTOCOL = cOMM_PROTOCOL;
	}
	public String getCOMM_COND_CD() {
		return COMM_COND_CD;
	}
	public void setCOMM_COND_CD(String cOMM_COND_CD) {
		COMM_COND_CD = cOMM_COND_CD;
	}
	public String getCOMM_LAST_FLAG() {
		return COMM_LAST_FLAG;
	}
	public void setCOMM_LAST_FLAG(String cOMM_LAST_FLAG) {
		COMM_LAST_FLAG = cOMM_LAST_FLAG;
	}
	public String getCOMM_CURSOR_MAP() {
		return COMM_CURSOR_MAP;
	}
	public void setCOMM_CURSOR_MAP(String cOMM_CURSOR_MAP) {
		COMM_CURSOR_MAP = cOMM_CURSOR_MAP;
	}
	public String getCOMM_CURSOR_IDX() {
		return COMM_CURSOR_IDX;
	}
	public void setCOMM_CURSOR_IDX(String cOMM_CURSOR_IDX) {
		COMM_CURSOR_IDX = cOMM_CURSOR_IDX;
	}
	public String getCOMM_MESSAGE_CD() {
		return COMM_MESSAGE_CD;
	}
	public void setCOMM_MESSAGE_CD(String cOMM_MESSAGE_CD) {
		COMM_MESSAGE_CD = cOMM_MESSAGE_CD;
	}
	public String getHOMM_MESSAGE_NM() {
		return HOMM_MESSAGE_NM;
	}
	public void setHOMM_MESSAGE_NM(String hOMM_MESSAGE_NM) {
		HOMM_MESSAGE_NM = hOMM_MESSAGE_NM;
	}
	public String getCOMM_ERR_NAME() {
		return COMM_ERR_NAME;
	}
	public void setCOMM_ERR_NAME(String cOMM_ERR_NAME) {
		COMM_ERR_NAME = cOMM_ERR_NAME;
	}
	public String getCOMM_ERR_TEXT() {
		return COMM_ERR_TEXT;
	}
	public void setCOMM_ERR_TEXT(String cOMM_ERR_TEXT) {
		COMM_ERR_TEXT = cOMM_ERR_TEXT;
	}
	public String getCOMM_SYS_CODE() {
		return COMM_SYS_CODE;
	}
	public void setCOMM_SYS_CODE(String cOMM_SYS_CODE) {
		COMM_SYS_CODE = cOMM_SYS_CODE;
	}
	public String getCOMM_FILLER() {
		return COMM_FILLER;
	}
	public void setCOMM_FILLER(String cOMM_FILLER) {
		COMM_FILLER = cOMM_FILLER;
	}
	public String getSI_GOGEK_NO() {
		return SI_GOGEK_NO;
	}
	public void setSI_GOGEK_NO(String sI_GOGEK_NO) {
		SI_GOGEK_NO = sI_GOGEK_NO;
	}
	public String getSI_SKIP_GB() {
		return SI_SKIP_GB;
	}
	public void setSI_SKIP_GB(String sI_SKIP_GB) {
		SI_SKIP_GB = sI_SKIP_GB;
	}
	public String getSO_HP_TEL1() {
		return SO_HP_TEL1;
	}
	public void setSO_HP_TEL1(String sO_HP_TEL1) {
		SO_HP_TEL1 = sO_HP_TEL1;
	}
	public String getSO_HP_TEL2() {
		return SO_HP_TEL2;
	}
	public void setSO_HP_TEL2(String sO_HP_TEL2) {
		SO_HP_TEL2 = sO_HP_TEL2;
	}
	public String getSO_HP_TEL3() {
		return SO_HP_TEL3;
	}
	public void setSO_HP_TEL3(String sO_HP_TEL3) {
		SO_HP_TEL3 = sO_HP_TEL3;
	}
	public String getSO_HP_TEL_YMD() {
		return SO_HP_TEL_YMD;
	}
	public void setSO_HP_TEL_YMD(String sO_HP_TEL_YMD) {
		SO_HP_TEL_YMD = sO_HP_TEL_YMD;
	}
	public String getSO_H_TEL1() {
		return SO_H_TEL1;
	}
	public void setSO_H_TEL1(String sO_H_TEL1) {
		SO_H_TEL1 = sO_H_TEL1;
	}
	public String getSO_H_TEL2() {
		return SO_H_TEL2;
	}
	public void setSO_H_TEL2(String sO_H_TEL2) {
		SO_H_TEL2 = sO_H_TEL2;
	}
	public String getSO_H_TEL3() {
		return SO_H_TEL3;
	}
	public void setSO_H_TEL3(String sO_H_TEL3) {
		SO_H_TEL3 = sO_H_TEL3;
	}
	public String getSO_H_TEL_YMD() {
		return SO_H_TEL_YMD;
	}
	public void setSO_H_TEL_YMD(String sO_H_TEL_YMD) {
		SO_H_TEL_YMD = sO_H_TEL_YMD;
	}
	public String getSO_J_TEL1() {
		return SO_J_TEL1;
	}
	public void setSO_J_TEL1(String sO_J_TEL1) {
		SO_J_TEL1 = sO_J_TEL1;
	}
	public String getSO_J_TEL2() {
		return SO_J_TEL2;
	}
	public void setSO_J_TEL2(String sO_J_TEL2) {
		SO_J_TEL2 = sO_J_TEL2;
	}
	public String getSO_J_TEL3() {
		return SO_J_TEL3;
	}
	public void setSO_J_TEL3(String sO_J_TEL3) {
		SO_J_TEL3 = sO_J_TEL3;
	}
	public String getSO_J_TEL_YMD() {
		return SO_J_TEL_YMD;
	}
	public void setSO_J_TEL_YMD(String sO_J_TEL_YMD) {
		SO_J_TEL_YMD = sO_J_TEL_YMD;
	}
	public String getSO_H_ZIP() {
		return SO_H_ZIP;
	}
	public void setSO_H_ZIP(String sO_H_ZIP) {
		SO_H_ZIP = sO_H_ZIP;
	}
	public String getHO_H_GITA() {
		return HO_H_GITA;
	}
	public void setHO_H_GITA(String hO_H_GITA) {
		HO_H_GITA = hO_H_GITA;
	}
	public String getSO_H_JUSO_YMD() {
		return SO_H_JUSO_YMD;
	}
	public void setSO_H_JUSO_YMD(String sO_H_JUSO_YMD) {
		SO_H_JUSO_YMD = sO_H_JUSO_YMD;
	}
	public String getSO_J_ZIP() {
		return SO_J_ZIP;
	}
	public void setSO_J_ZIP(String sO_J_ZIP) {
		SO_J_ZIP = sO_J_ZIP;
	}
	public String getHO_J_GITA() {
		return HO_J_GITA;
	}
	public void setHO_J_GITA(String hO_J_GITA) {
		HO_J_GITA = hO_J_GITA;
	}
	public String getSO_J_JUSO_YMD() {
		return SO_J_JUSO_YMD;
	}
	public void setSO_J_JUSO_YMD(String sO_J_JUSO_YMD) {
		SO_J_JUSO_YMD = sO_J_JUSO_YMD;
	}
	public String getSO_G_ZIP() {
		return SO_G_ZIP;
	}
	public void setSO_G_ZIP(String sO_G_ZIP) {
		SO_G_ZIP = sO_G_ZIP;
	}
	public String getHO_G_GITA() {
		return HO_G_GITA;
	}
	public void setHO_G_GITA(String hO_G_GITA) {
		HO_G_GITA = hO_G_GITA;
	}
	public String getSO_G_JUSO_YMD() {
		return SO_G_JUSO_YMD;
	}
	public void setSO_G_JUSO_YMD(String sO_G_JUSO_YMD) {
		SO_G_JUSO_YMD = sO_G_JUSO_YMD;
	}
	public String getSO_YMD() {
		return SO_YMD;
	}
	public void setSO_YMD(String sO_YMD) {
		SO_YMD = sO_YMD;
	}
}

