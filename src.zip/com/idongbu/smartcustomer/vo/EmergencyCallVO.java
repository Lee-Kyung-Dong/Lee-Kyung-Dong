package com.idongbu.smartcustomer.vo;

import com.idongbu.common.vo.CMMVO;

// 계약조회
public class EmergencyCallVO extends CMMVO {
	private int seq = 0;
	private String jubsu_no = null;
	private String jubsu_date = null;
	private String yochung_nm = null;
	private String chury_nm = null;
	private String chury_endcd = null;
	private String chury_endcd_nm = null;
	
	private String cCarNo = null;
	private String cPoliNo = null;
	private String BOHUM_SYMD = null;

	public int getSeq() {
		return seq;
	}
	public void setSeq(int seq) {
		this.seq = seq;
	}
	public String getJubsu_no() {
		return jubsu_no;
	}
	public void setJubsu_no(String jubsu_no) {
		this.jubsu_no = jubsu_no;
	}
	public String getJubsu_date() {
		return jubsu_date;
	}
	public void setJubsu_date(String jubsu_date) {
		this.jubsu_date = jubsu_date;
	}
	public String getChury_nm() {
		return chury_nm;
	}
	public void setChury_nm(String chury_nm) {
		this.chury_nm = chury_nm;
	}
	public String getChury_endcd() {
		return chury_endcd;
	}
	public void setChury_endcd(String chury_endcd) {
		this.chury_endcd = chury_endcd;
	}
	public String getChury_endcd_nm() {
		return chury_endcd_nm;
	}
	public void setChury_endcd_nm(String chury_endcd_nm) {
		this.chury_endcd_nm = chury_endcd_nm;
	}
	public String getcCarNo() {
		return cCarNo;
	}
	public void setcCarNo(String cCarNo) {
		this.cCarNo = cCarNo;
	}
	public String getcPoliNo() {
		return cPoliNo;
	}
	public void setcPoliNo(String cPoliNo) {
		this.cPoliNo = cPoliNo;
	}
	public String getBOHUM_SYMD() {
		return BOHUM_SYMD;
	}
	public void setBOHUM_SYMD(String bOHUM_SYMD) {
		BOHUM_SYMD = bOHUM_SYMD;
	}
	public String getYochung_nm() {
		return yochung_nm;
	}
	public void setYochung_nm(String yochung_nm) {
		this.yochung_nm = yochung_nm;
	}
}