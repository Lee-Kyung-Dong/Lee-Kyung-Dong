package com.idongbu.smartcustomer.vo;

import com.idongbu.common.vo.CMMVO;

public class CyCerConfirmVO extends CMMVO {
	
	public String [] LK_SAGO_JUBSU_NO = new String[30];
	public String [] LK_SAGO_MOKJUK_GB = new String[30];
	public String [] LK_SAGO_MOKJUK_SEQ = new String[30];
	public String [] LK_BJ_NM = new String[30];
	public String [] LK_PROD_NM = new String[30];
	public String [] LK_PIHEJA_NAME = new String[30];
	public String [] LK_SAGO_YMDSB = new String[30];
	
	public String S_LK_SAGO_JUBSU_NO = "";
	public String S_LK_SAGO_MOKJUK_GB = "";
	public String S_LK_SAGO_MOKJUK_SEQ = "";
	
	
	
	//
	
	public String LK_RZ1173_PIHEJA ="";
	public String LK_RZ1173_JUMIN_NO = "";					//피해자주민번호

	////////////////////사고사항
	public String LK_RZ1173_SAGO_NO = "";					//사고번호
	public String LK_RZ1173_SAGO_YMDSB = "";			    //사고일시
	public String LK_RZ1173_SAGO_SEQ = "";					//서열
	public String LK_RZ1173_SAGO_DAMBO = "";			    //사고담보
	public String LK_RZ1173_CAR_NO = "";					//차량번호
	public String LK_RZ1173_UNJUNJA = "";					//운전자
	public String LK_RZ1173_UNJUNJA_REL = "";				//피보험자와의관계
	public String LK_RZ1173_PIHE_TYPE = "";					//피해유형
	public String LK_RZ1173_JUNGDAE = "";					//중대사고
	public String LK_RZ1173_SAGO_JANGSO = "";			    //사고장소
	public String LK_RZ1173_SAGO_CONT1 = "";				//사고내용1
	public String LK_RZ1173_SAGO_CONT2 = "";				//사고내용2
	////////////////////피해사항
	public String LK_RZ1173_SONHE_JUNGDO = "";		        //손해정도
	public String LK_RZ1173_BUSANG = "";					//상해등급
	public String LK_RZ1173_JANGHE = "";					//장해등급
	public String LK_RZ1173_HOSPITAL_NAME = "";		        //초진병원
	public String LK_RZ1173_CHOJIN_YMD = "";				//초진일자
	public String LK_RZ1173_CHOJIN_ILSU = "";				//초진기간

	public String LK_RZ1173_JUJINDAN_NAME1 = "";	        //주진단명1
	public String LK_RZ1173_JUJINDAN_NAME2 = "";	        //주진단명2
	public String LK_RZ1173_JUJINDAN_NAME3 = "";	        //주진단명3
	public String LK_RZ1173_PL_TOT = "";					//총지급(결정)보험금
	public String LK_RZ1173_COUNT = "";						//총치료건수		
	
	public String [] HOSPITAL_NAME = new String[20];        //치료병원1
	public String [] IPWON_GIGAN = new String[20];          //입원기간1
	public String [] IPWON_ILSU = new String[20];           //입원일수1
	public String [] TONGWON_GIGAN = new String[20];        //통원기간1
	public String [] TONGWON_ILSU = new String[20];         //통원일수1
	public String [] PL_AMT = new String[20];               //지급(결정)보험금1
	
	public String LK_RZ1173_YMDHM = ""; //발급일
	public String LK_RZ1173_BALGBJA = "";//발급담당자
	public String LK_RZ1173_BALGBJA_TEL = "";//발급담당자전화번호

	public String LK_RZ1173_DAMDANGJA = "";//보상담당자
	public String LK_RZ1173_DAMDANGJA_TEL = "";//보상담당자전화번호

//출력용 변수	
	public String arg1  = "";
	public String arg2  = "";
	public String arg3  = "";
	public String arg4  = "";
	public String arg5  = "";
	public String arg6  = "";
	public String arg7  = "";
	public String arg8  = "";
	public String arg9  = "";
	public String arg10 = "";
	public String arg11 = "";
	public String arg12 = "";
	public String arg13 = "";
	public String arg14 = "";
	public String arg15 = "";
	public String arg16 = "";
	public String arg17 = "";
	public String arg18 = "";
	public String arg19 = "";
	public String arg20 = "";
	public String arg21 = "";
	public String arg22 = "";
	public String arg23 = "";
	public String arg24 = "";
	public String arg25 = "";
	public String arg26 = "";
	public String arg27 = "";


}
