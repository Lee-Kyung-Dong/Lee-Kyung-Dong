package com.idongbu.smartcustomer.vo;

import java.util.List;
import java.util.Map;

import com.idongbu.common.vo.CMMVO;

public class CmmFRZ1182RVO extends CMMVO {

	public CmmFRZ1182RVO() {
		super.setPGMID(this.proid);
		super.setTRID(this.trid);
	}		
	
	private static final String proid   = "FRZ1182R";
	private static final String trid    = "RZF2";
	private String rURL				    = "";

	// 입력
	private String LK_I_SAGO_JUBSU_NO   = ""; // 사고접수번호

	// 출력
	private String LK_TRID              = "";
	private String LK_FLAG              = "";
	private String LK_NT_CD             = "";
	private String LK_RSP_TIME          = "";
	private String LK_COMP_GB           = "";
	private String LK_COMP_CD           = "";
	private String LK_FILLER            = "";
	private String LK_USER_ID           = "";
	private String LK_PART_GB1          = "";
	private String LK_PART_GB2          = "";
	private String LK_UPMU_CD1          = "";
	private String LK_UPMU_CD2          = "";
	private String LK_UPMU_CD3          = "";
	private String LK_GULK_GB           = "";
	private String LK_CM_FILLER         = "";
	private String LK_RETURN_CD         = "";
	private String LK_MSG_CD1           = "";
	private String LK_MSG_CD2           = "";
	private String H_LK_MESSAGE1        = "";
	private String H_LK_MESSAGE2        = "";
	private String LK_SAGO_YMDSB        = "";
	private String LK_SAGO_JANGSO1      = "";
	private String LK_TONGBO_NAME       = "";
	private String LK_TONGBO_TEL        = "";
	private String LK_UNJUNJA_NAME      = "";
	private String LK_UNJUNJA_TEL       = "";
	private String LK_SAGO_JANGSO2      = "";
	private String LK_SAGO_CONT         = "";
	private String LK_JUBSU_GUNSU       = "";
	/*
	private String[] LK_SAGO_MOKJUK_GB  = new String[0]; // 20
	private String[] LK_SAGO_MOKJUK_NM  = new String[0]; // 20
	private String[] LK_SAGO_MOKJUK_SEQ = new String[0]; // 20
	private String[] LK_PIHEJAMUL_NM    = new String[0]; // 20
	private String[] LK_HOSP_SURI       = new String[0]; // 20
	private String[] LK_DAMDANGJA       = new String[0]; // 20
	private String[] LK_DAMDANG_TEL     = new String[0]; // 20
	*/
	private List<Map<String, String>> LOOP_DATA = null;
	private String FILLER               = "";
	
	public String getrURL() {
		return rURL;
	}
	public void setrURL(String rURL) {
		this.rURL = rURL;
	}
	public String getLK_I_SAGO_JUBSU_NO() {
		return LK_I_SAGO_JUBSU_NO;
	}
	public void setLK_I_SAGO_JUBSU_NO(String lK_I_SAGO_JUBSU_NO) {
		LK_I_SAGO_JUBSU_NO = lK_I_SAGO_JUBSU_NO;
	}
	public String getLK_TRID() {
		return LK_TRID;
	}
	public void setLK_TRID(String lK_TRID) {
		LK_TRID = lK_TRID;
	}
	public String getLK_FLAG() {
		return LK_FLAG;
	}
	public void setLK_FLAG(String lK_FLAG) {
		LK_FLAG = lK_FLAG;
	}
	public String getLK_NT_CD() {
		return LK_NT_CD;
	}
	public void setLK_NT_CD(String lK_NT_CD) {
		LK_NT_CD = lK_NT_CD;
	}
	public String getLK_RSP_TIME() {
		return LK_RSP_TIME;
	}
	public void setLK_RSP_TIME(String lK_RSP_TIME) {
		LK_RSP_TIME = lK_RSP_TIME;
	}
	public String getLK_COMP_GB() {
		return LK_COMP_GB;
	}
	public void setLK_COMP_GB(String lK_COMP_GB) {
		LK_COMP_GB = lK_COMP_GB;
	}
	public String getLK_COMP_CD() {
		return LK_COMP_CD;
	}
	public void setLK_COMP_CD(String lK_COMP_CD) {
		LK_COMP_CD = lK_COMP_CD;
	}
	public String getLK_FILLER() {
		return LK_FILLER;
	}
	public void setLK_FILLER(String lK_FILLER) {
		LK_FILLER = lK_FILLER;
	}
	public String getLK_USER_ID() {
		return LK_USER_ID;
	}
	public void setLK_USER_ID(String lK_USER_ID) {
		LK_USER_ID = lK_USER_ID;
	}
	public String getLK_PART_GB1() {
		return LK_PART_GB1;
	}
	public void setLK_PART_GB1(String lK_PART_GB1) {
		LK_PART_GB1 = lK_PART_GB1;
	}
	public String getLK_PART_GB2() {
		return LK_PART_GB2;
	}
	public void setLK_PART_GB2(String lK_PART_GB2) {
		LK_PART_GB2 = lK_PART_GB2;
	}
	public String getLK_UPMU_CD1() {
		return LK_UPMU_CD1;
	}
	public void setLK_UPMU_CD1(String lK_UPMU_CD1) {
		LK_UPMU_CD1 = lK_UPMU_CD1;
	}
	public String getLK_UPMU_CD2() {
		return LK_UPMU_CD2;
	}
	public void setLK_UPMU_CD2(String lK_UPMU_CD2) {
		LK_UPMU_CD2 = lK_UPMU_CD2;
	}
	public String getLK_UPMU_CD3() {
		return LK_UPMU_CD3;
	}
	public void setLK_UPMU_CD3(String lK_UPMU_CD3) {
		LK_UPMU_CD3 = lK_UPMU_CD3;
	}
	public String getLK_GULK_GB() {
		return LK_GULK_GB;
	}
	public void setLK_GULK_GB(String lK_GULK_GB) {
		LK_GULK_GB = lK_GULK_GB;
	}
	public String getLK_CM_FILLER() {
		return LK_CM_FILLER;
	}
	public void setLK_CM_FILLER(String lK_CM_FILLER) {
		LK_CM_FILLER = lK_CM_FILLER;
	}
	public String getLK_RETURN_CD() {
		return LK_RETURN_CD;
	}
	public void setLK_RETURN_CD(String lK_RETURN_CD) {
		LK_RETURN_CD = lK_RETURN_CD;
	}
	public String getLK_MSG_CD1() {
		return LK_MSG_CD1;
	}
	public void setLK_MSG_CD1(String lK_MSG_CD1) {
		LK_MSG_CD1 = lK_MSG_CD1;
	}
	public String getLK_MSG_CD2() {
		return LK_MSG_CD2;
	}
	public void setLK_MSG_CD2(String lK_MSG_CD2) {
		LK_MSG_CD2 = lK_MSG_CD2;
	}
	public String getH_LK_MESSAGE1() {
		return H_LK_MESSAGE1;
	}
	public void setH_LK_MESSAGE1(String h_LK_MESSAGE1) {
		H_LK_MESSAGE1 = h_LK_MESSAGE1;
	}
	public String getH_LK_MESSAGE2() {
		return H_LK_MESSAGE2;
	}
	public void setH_LK_MESSAGE2(String h_LK_MESSAGE2) {
		H_LK_MESSAGE2 = h_LK_MESSAGE2;
	}
	public String getLK_SAGO_YMDSB() {
		return LK_SAGO_YMDSB;
	}
	public void setLK_SAGO_YMDSB(String lK_SAGO_YMDSB) {
		LK_SAGO_YMDSB = lK_SAGO_YMDSB;
	}
	public String getLK_SAGO_JANGSO1() {
		return LK_SAGO_JANGSO1;
	}
	public void setLK_SAGO_JANGSO1(String lK_SAGO_JANGSO1) {
		LK_SAGO_JANGSO1 = lK_SAGO_JANGSO1;
	}
	public String getLK_TONGBO_NAME() {
		return LK_TONGBO_NAME;
	}
	public void setLK_TONGBO_NAME(String lK_TONGBO_NAME) {
		LK_TONGBO_NAME = lK_TONGBO_NAME;
	}
	public String getLK_TONGBO_TEL() {
		return LK_TONGBO_TEL;
	}
	public void setLK_TONGBO_TEL(String lK_TONGBO_TEL) {
		LK_TONGBO_TEL = lK_TONGBO_TEL;
	}
	public String getLK_UNJUNJA_NAME() {
		return LK_UNJUNJA_NAME;
	}
	public void setLK_UNJUNJA_NAME(String lK_UNJUNJA_NAME) {
		LK_UNJUNJA_NAME = lK_UNJUNJA_NAME;
	}
	public String getLK_UNJUNJA_TEL() {
		return LK_UNJUNJA_TEL;
	}
	public void setLK_UNJUNJA_TEL(String lK_UNJUNJA_TEL) {
		LK_UNJUNJA_TEL = lK_UNJUNJA_TEL;
	}
	public String getLK_SAGO_JANGSO2() {
		return LK_SAGO_JANGSO2;
	}
	public void setLK_SAGO_JANGSO2(String lK_SAGO_JANGSO2) {
		LK_SAGO_JANGSO2 = lK_SAGO_JANGSO2;
	}
	public String getLK_SAGO_CONT() {
		return LK_SAGO_CONT;
	}
	public void setLK_SAGO_CONT(String lK_SAGO_CONT) {
		LK_SAGO_CONT = lK_SAGO_CONT;
	}
	public String getLK_JUBSU_GUNSU() {
		return LK_JUBSU_GUNSU;
	}
	public void setLK_JUBSU_GUNSU(String lK_JUBSU_GUNSU) {
		LK_JUBSU_GUNSU = lK_JUBSU_GUNSU;
	}
	public List<Map<String, String>> getLOOP_DATA() {
		return LOOP_DATA;
	}
	public void setLOOP_DATA(List<Map<String, String>> lOOP_DATA) {
		LOOP_DATA = lOOP_DATA;
	}
	public String getFILLER() {
		return FILLER;
	}
	public void setFILLER(String fILLER) {
		FILLER = fILLER;
	}
	public static String getProid() {
		return proid;
	}
	public static String getTrid() {
		return trid;
	}		
}
