package com.idongbu.smartcustomer.vo;

import com.idongbu.common.vo.CMMVO;

public class CmmFUC3335RVO extends CMMVO {
	public CmmFUC3335RVO() {
		super.setPGMID(proid);
		super.setTRID(trid);
	}
	
	private String CC_PRT_GB;
	
	private final static String proid		= "FUC3335R";
	private final static String trid		= "UCKN";
	private String rURL						= "";

	// 입력
	private String JJ_POLI_NO; // 증권번호
	private String JJ_POLI_NO_MASKING; // 증권번호 마스킹
	private String JJ_JIJUM_CD; // 지점코드
	private String HJ_JIJUM_NAME; // 지점명
	private String JJ_SAWON_NO; // 사원번호
	private String HJ_SAWON_NAME; // 사원명
	private String JJ_BJ_CD; // 보종코드
	private String HJ_BJ_NAME; // 보종명
	private String JJ_BJ_TYPE; // 보종타입
	private String HJ_SANGTE_NAME; // 상태명
	private String HJ_GYEYAKJA_NAME; // 계약자명
	private String JJ_GEBUPIN_GUBUN;
	private String JJ_GYEYAKJA_ID; // 계약자주민번호
	private String JJ_BOHUM_SYMD; // 보험시기
	private String JJ_BOHUM_EYMD; // 보험종기
	private String JJ_NAPIP_YCNT;
	private String JJ_GUCHI_YCNT;
	private String JJ_MANGI_YCNT;
	private String JJ_SUGUM_BANGBUP; // 수금방법
	private String JJ_LAST_NAPIP_YM;
	private String HJ_NAPBANG_NAME; // 납입방법명
	private String JJ_NAPIPHAL_PRM; // 납입할 보험료
	private String JJ_TOTAL_NAPIP_CNT;
	private String JJ_LAST_NAPIP_CNT;
	private String JJ_TOTAL_NAPIP_PRM;
	private String JJ_DECHUL_JIJUM_CD; // 대출지점코드
	private String HJ_DECHUL_JIJUM_NM; // 대출지점명
	private String HJ_DECHUL_TYPE;
	private String HJ_DECHUL_SUBANG;
	private String JJ_SUGUM_JIJUM_CD; // 수금지점코드
	private String JJ_SUGUM_JIBU_CD; // 수금지부코드
	private String JJ_SUGUM_SAWON_NO; // 수금사원번호
	private String HJ_SUGUM_JIJUM_NAME; // 수금지점명
	private String HJ_SUGUM_JIBU_NAME; // 수금지부명
	private String HJ_SUGUM_SAWON_NAME; // 수금사원명
	private String JJ_SUGUM_TEL_NO; // 수금전화번호
	private String HJ_PROC_NAME;
	private String JJ_GISAN_YMD; // 기산일
	private String JJ_GISAN_GM;
	private String JJ_SANGHWAN_WONGM; // 상환원금
	private String JJ_MINAP_YMD;
	private String JJ_MINAP_IJA;
	private String JJ_SANGHWAN_IJA; // 상환이자
	private String JJ_WONLIGM_YMD;
	private String JJ_WONLIGM; // 원리금
	private String JJ_SANGHWAN_WONLIGM ; // 상환원리금
	private String JJ_HAND_PHONE; // 핸드폰번호
	private String JJ_JUNG_F1;
	private String JJ_JUNG_T1;
	private String JJ_JUNG_ILSU1;
	private String JJ_JUNG_IJA1;
	private String JJ_JUNG_F2;
	private String JJ_JUNG_T2;
	private String JJ_JUNG_ILSU2;
	private String JJ_JUNG_IJA2;
	private String JJ_YUNC_F1;
	private String JJ_YUNC_T1;
	private String JJ_YUNC_ILSU1;
	private String JJ_YUNC_IJA1;
	private String JJ_YUNC_F2;
	private String JJ_YUNC_T2;
	private String JJ_YUNC_ILSU2;
	private String JJ_YUNC_IJA2;
	private String JJ_MIGU_ILSU;
	private String JJ_MIGU_IJA;
	private String JJ_GWAO_GM;
	private String UU_POLI_NO; // 증권번호

	// 출력
	private String CC_CHANNEL;
	private String CC_UKEY;
	private String CC_PGMID;
	private String CC_PROC_GB;
	private String CC_FUN_KEY;
	private String CC_USER_GB;
	private String CC_USER_CD;
	private String CC_JIJUM_CD;
	private String CC_JIBU_CD;
	private String CC_PROTOCOL;
	private String CC_COND_CD;
	private String CC_LAST_FLAG;
	private String CC_CURSOR_MAP;
	private String CC_CURSOR_IDX;
	private String CC_MESSAGE_CD;
	private String HC_MESSAGE_NM;
	private String CC_SYS_ERR;
	private String CC_FILLER;
//	private String JJ_POLI_NO;
//	private String JJ_JIJUM_CD;
//	private String HJ_JIJUM_NAME;
//	private String JJ_SAWON_NO;
//	private String HJ_SAWON_NAME;
//	private String JJ_BJ_CD;
//	private String HJ_BJ_NAME;
//	private String JJ_BJ_TYPE;
//	private String HJ_SANGTE_NAME;
	private String JJ_SANGTE_JIJUM;
	private String JJ_SANGTE_YMD;
//	private String HJ_GYEYAKJA_NAME;
//	private String JJ_GEBUPIN_GUBUN;
//	private String JJ_GYEYAKJA_ID;
//	private String JJ_BOHUM_SYMD;
//	private String JJ_BOHUM_EYMD;
//	private String JJ_NAPIP_YCNT;
//	private String JJ_GUCHI_YCNT;
//	private String JJ_MANGI_YCNT;
//	private String JJ_SUGUM_BANGBUP;
//	private String JJ_LAST_NAPIP_YM;
//	private String HJ_NAPBANG_NAME;
//	private String JJ_NAPIPHAL_PRM;
//	private String JJ_TOTAL_NAPIP_CNT;
//	private String JJ_LAST_NAPIP_CNT;
//	private String JJ_TOTAL_NAPIP_PRM;
//	private String JJ_DECHUL_JIJUM_CD;
//	private String HJ_DECHUL_JIJUM_NM;
//	private String HJ_DECHUL_TYPE;
//	private String HJ_DECHUL_SUBANG;
//	private String JJ_SUGUM_JIJUM_CD;
//	private String JJ_SUGUM_JIBU_CD;
//	private String JJ_SUGUM_SAWON_NO;
//	private String HJ_SUGUM_JIJUM_NAME;
//	private String HJ_SUGUM_JIBU_NAME;
//	private String HJ_SUGUM_SAWON_NAME;
	private String HJ_SUGUM_DERIJUMJU;
//	private String JJ_SUGUM_TEL_NO;
//	private String HJ_PROC_NAME;
	private String JJ_YOC_NO;
//	private String JJ_GISAN_YMD;
//	private String JJ_GISAN_GM;
//	private String JJ_SANGHWAN_WONGM;
//	private String JJ_MINAP_YMD;
//	private String JJ_MINAP_IJA;
//	private String JJ_SANGHWAN_IJA;
//	private String JJ_WONLIGM_YMD;
//	private String JJ_WONLIGM;
//	private String JJ_SANGHWAN_WONLIGM;
	private String JJ_BANK_CD;
	private String HJ_BANK_NAME;
	private String JJ_GYEJWA_NO;
//	private String JJ_HAND_PHONE;
	private String HJ_YEGMJU_NAME;
	private String JJ_YEGMJU_ID;
	private String JJ_YEGMJU_CHECK;
	private String HJ_REMARK;
	private String JJ_SYS_RC;
//	private String JJ_JUNG_F1;
//	private String JJ_JUNG_T1;
//	private String JJ_JUNG_ILSU1;
//	private String JJ_JUNG_IJA1;
//	private String JJ_JUNG_F2;
//	private String JJ_JUNG_T2;
//	private String JJ_JUNG_ILSU2;
//	private String JJ_JUNG_IJA2;
//	private String JJ_YUNC_F1;
//	private String JJ_YUNC_T1;
//	private String JJ_YUNC_ILSU1;
//	private String JJ_YUNC_IJA1;
//	private String JJ_YUNC_F2;
//	private String JJ_YUNC_T2;
//	private String JJ_YUNC_ILSU2;
//	private String JJ_YUNC_IJA2;
	private String JJ_MIGU_F;
	private String JJ_MIGU_T;
//	private String JJ_MIGU_ILSU;
//	private String JJ_MIGU_IJA;
	private String HJ_GWAO_NM;
//	private String JJ_GWAO_GM;
//	private String UU_POLI_NO;
	
	
	public String getrURL() {
		return rURL;
	}
	public void setrURL(String rURL) {
		this.rURL = rURL;
	}
	public String getJJ_POLI_NO() {
		return JJ_POLI_NO;
	}
	public void setJJ_POLI_NO(String jJ_POLI_NO) {
		JJ_POLI_NO = jJ_POLI_NO;
	}
	public String getJJ_JIJUM_CD() {
		return JJ_JIJUM_CD;
	}
	public void setJJ_JIJUM_CD(String jJ_JIJUM_CD) {
		JJ_JIJUM_CD = jJ_JIJUM_CD;
	}
	public String getHJ_JIJUM_NAME() {
		return HJ_JIJUM_NAME;
	}
	public void setHJ_JIJUM_NAME(String hJ_JIJUM_NAME) {
		HJ_JIJUM_NAME = hJ_JIJUM_NAME;
	}
	public String getJJ_SAWON_NO() {
		return JJ_SAWON_NO;
	}
	public void setJJ_SAWON_NO(String jJ_SAWON_NO) {
		JJ_SAWON_NO = jJ_SAWON_NO;
	}
	public String getHJ_SAWON_NAME() {
		return HJ_SAWON_NAME;
	}
	public void setHJ_SAWON_NAME(String hJ_SAWON_NAME) {
		HJ_SAWON_NAME = hJ_SAWON_NAME;
	}
	public String getJJ_BJ_CD() {
		return JJ_BJ_CD;
	}
	public void setJJ_BJ_CD(String jJ_BJ_CD) {
		JJ_BJ_CD = jJ_BJ_CD;
	}
	public String getHJ_BJ_NAME() {
		return HJ_BJ_NAME;
	}
	public void setHJ_BJ_NAME(String hJ_BJ_NAME) {
		HJ_BJ_NAME = hJ_BJ_NAME;
	}
	public String getJJ_BJ_TYPE() {
		return JJ_BJ_TYPE;
	}
	public void setJJ_BJ_TYPE(String jJ_BJ_TYPE) {
		JJ_BJ_TYPE = jJ_BJ_TYPE;
	}
	public String getHJ_SANGTE_NAME() {
		return HJ_SANGTE_NAME;
	}
	public void setHJ_SANGTE_NAME(String hJ_SANGTE_NAME) {
		HJ_SANGTE_NAME = hJ_SANGTE_NAME;
	}
	public String getHJ_GYEYAKJA_NAME() {
		return HJ_GYEYAKJA_NAME;
	}
	public void setHJ_GYEYAKJA_NAME(String hJ_GYEYAKJA_NAME) {
		HJ_GYEYAKJA_NAME = hJ_GYEYAKJA_NAME;
	}
	public String getJJ_GEBUPIN_GUBUN() {
		return JJ_GEBUPIN_GUBUN;
	}
	public void setJJ_GEBUPIN_GUBUN(String jJ_GEBUPIN_GUBUN) {
		JJ_GEBUPIN_GUBUN = jJ_GEBUPIN_GUBUN;
	}
	public String getJJ_GYEYAKJA_ID() {
		return JJ_GYEYAKJA_ID;
	}
	public void setJJ_GYEYAKJA_ID(String jJ_GYEYAKJA_ID) {
		JJ_GYEYAKJA_ID = jJ_GYEYAKJA_ID;
	}
	public String getJJ_BOHUM_SYMD() {
		return JJ_BOHUM_SYMD;
	}
	public void setJJ_BOHUM_SYMD(String jJ_BOHUM_SYMD) {
		JJ_BOHUM_SYMD = jJ_BOHUM_SYMD;
	}
	public String getJJ_BOHUM_EYMD() {
		return JJ_BOHUM_EYMD;
	}
	public void setJJ_BOHUM_EYMD(String jJ_BOHUM_EYMD) {
		JJ_BOHUM_EYMD = jJ_BOHUM_EYMD;
	}
	public String getJJ_NAPIP_YCNT() {
		return JJ_NAPIP_YCNT;
	}
	public void setJJ_NAPIP_YCNT(String jJ_NAPIP_YCNT) {
		JJ_NAPIP_YCNT = jJ_NAPIP_YCNT;
	}
	public String getJJ_GUCHI_YCNT() {
		return JJ_GUCHI_YCNT;
	}
	public void setJJ_GUCHI_YCNT(String jJ_GUCHI_YCNT) {
		JJ_GUCHI_YCNT = jJ_GUCHI_YCNT;
	}
	public String getJJ_MANGI_YCNT() {
		return JJ_MANGI_YCNT;
	}
	public void setJJ_MANGI_YCNT(String jJ_MANGI_YCNT) {
		JJ_MANGI_YCNT = jJ_MANGI_YCNT;
	}
	public String getJJ_SUGUM_BANGBUP() {
		return JJ_SUGUM_BANGBUP;
	}
	public void setJJ_SUGUM_BANGBUP(String jJ_SUGUM_BANGBUP) {
		JJ_SUGUM_BANGBUP = jJ_SUGUM_BANGBUP;
	}
	public String getJJ_LAST_NAPIP_YM() {
		return JJ_LAST_NAPIP_YM;
	}
	public void setJJ_LAST_NAPIP_YM(String jJ_LAST_NAPIP_YM) {
		JJ_LAST_NAPIP_YM = jJ_LAST_NAPIP_YM;
	}
	public String getHJ_NAPBANG_NAME() {
		return HJ_NAPBANG_NAME;
	}
	public void setHJ_NAPBANG_NAME(String hJ_NAPBANG_NAME) {
		HJ_NAPBANG_NAME = hJ_NAPBANG_NAME;
	}
	public String getJJ_NAPIPHAL_PRM() {
		return JJ_NAPIPHAL_PRM;
	}
	public void setJJ_NAPIPHAL_PRM(String jJ_NAPIPHAL_PRM) {
		JJ_NAPIPHAL_PRM = jJ_NAPIPHAL_PRM;
	}
	public String getJJ_TOTAL_NAPIP_CNT() {
		return JJ_TOTAL_NAPIP_CNT;
	}
	public void setJJ_TOTAL_NAPIP_CNT(String jJ_TOTAL_NAPIP_CNT) {
		JJ_TOTAL_NAPIP_CNT = jJ_TOTAL_NAPIP_CNT;
	}
	public String getJJ_LAST_NAPIP_CNT() {
		return JJ_LAST_NAPIP_CNT;
	}
	public void setJJ_LAST_NAPIP_CNT(String jJ_LAST_NAPIP_CNT) {
		JJ_LAST_NAPIP_CNT = jJ_LAST_NAPIP_CNT;
	}
	public String getJJ_TOTAL_NAPIP_PRM() {
		return JJ_TOTAL_NAPIP_PRM;
	}
	public void setJJ_TOTAL_NAPIP_PRM(String jJ_TOTAL_NAPIP_PRM) {
		JJ_TOTAL_NAPIP_PRM = jJ_TOTAL_NAPIP_PRM;
	}
	public String getJJ_DECHUL_JIJUM_CD() {
		return JJ_DECHUL_JIJUM_CD;
	}
	public void setJJ_DECHUL_JIJUM_CD(String jJ_DECHUL_JIJUM_CD) {
		JJ_DECHUL_JIJUM_CD = jJ_DECHUL_JIJUM_CD;
	}
	public String getHJ_DECHUL_JIJUM_NM() {
		return HJ_DECHUL_JIJUM_NM;
	}
	public void setHJ_DECHUL_JIJUM_NM(String hJ_DECHUL_JIJUM_NM) {
		HJ_DECHUL_JIJUM_NM = hJ_DECHUL_JIJUM_NM;
	}
	public String getHJ_DECHUL_TYPE() {
		return HJ_DECHUL_TYPE;
	}
	public void setHJ_DECHUL_TYPE(String hJ_DECHUL_TYPE) {
		HJ_DECHUL_TYPE = hJ_DECHUL_TYPE;
	}
	public String getHJ_DECHUL_SUBANG() {
		return HJ_DECHUL_SUBANG;
	}
	public void setHJ_DECHUL_SUBANG(String hJ_DECHUL_SUBANG) {
		HJ_DECHUL_SUBANG = hJ_DECHUL_SUBANG;
	}
	public String getJJ_SUGUM_JIJUM_CD() {
		return JJ_SUGUM_JIJUM_CD;
	}
	public void setJJ_SUGUM_JIJUM_CD(String jJ_SUGUM_JIJUM_CD) {
		JJ_SUGUM_JIJUM_CD = jJ_SUGUM_JIJUM_CD;
	}
	public String getJJ_SUGUM_JIBU_CD() {
		return JJ_SUGUM_JIBU_CD;
	}
	public void setJJ_SUGUM_JIBU_CD(String jJ_SUGUM_JIBU_CD) {
		JJ_SUGUM_JIBU_CD = jJ_SUGUM_JIBU_CD;
	}
	public String getJJ_SUGUM_SAWON_NO() {
		return JJ_SUGUM_SAWON_NO;
	}
	public void setJJ_SUGUM_SAWON_NO(String jJ_SUGUM_SAWON_NO) {
		JJ_SUGUM_SAWON_NO = jJ_SUGUM_SAWON_NO;
	}
	public String getHJ_SUGUM_JIJUM_NAME() {
		return HJ_SUGUM_JIJUM_NAME;
	}
	public void setHJ_SUGUM_JIJUM_NAME(String hJ_SUGUM_JIJUM_NAME) {
		HJ_SUGUM_JIJUM_NAME = hJ_SUGUM_JIJUM_NAME;
	}
	public String getHJ_SUGUM_JIBU_NAME() {
		return HJ_SUGUM_JIBU_NAME;
	}
	public void setHJ_SUGUM_JIBU_NAME(String hJ_SUGUM_JIBU_NAME) {
		HJ_SUGUM_JIBU_NAME = hJ_SUGUM_JIBU_NAME;
	}
	public String getHJ_SUGUM_SAWON_NAME() {
		return HJ_SUGUM_SAWON_NAME;
	}
	public void setHJ_SUGUM_SAWON_NAME(String hJ_SUGUM_SAWON_NAME) {
		HJ_SUGUM_SAWON_NAME = hJ_SUGUM_SAWON_NAME;
	}
	public String getJJ_SUGUM_TEL_NO() {
		return JJ_SUGUM_TEL_NO;
	}
	public void setJJ_SUGUM_TEL_NO(String jJ_SUGUM_TEL_NO) {
		JJ_SUGUM_TEL_NO = jJ_SUGUM_TEL_NO;
	}
	public String getHJ_PROC_NAME() {
		return HJ_PROC_NAME;
	}
	public void setHJ_PROC_NAME(String hJ_PROC_NAME) {
		HJ_PROC_NAME = hJ_PROC_NAME;
	}
	public String getJJ_GISAN_YMD() {
		return JJ_GISAN_YMD;
	}
	public void setJJ_GISAN_YMD(String jJ_GISAN_YMD) {
		JJ_GISAN_YMD = jJ_GISAN_YMD;
	}
	public String getJJ_GISAN_GM() {
		return JJ_GISAN_GM;
	}
	public void setJJ_GISAN_GM(String jJ_GISAN_GM) {
		JJ_GISAN_GM = jJ_GISAN_GM;
	}
	public String getJJ_SANGHWAN_WONGM() {
		return JJ_SANGHWAN_WONGM;
	}
	public void setJJ_SANGHWAN_WONGM(String jJ_SANGHWAN_WONGM) {
		JJ_SANGHWAN_WONGM = jJ_SANGHWAN_WONGM;
	}
	public String getJJ_MINAP_YMD() {
		return JJ_MINAP_YMD;
	}
	public void setJJ_MINAP_YMD(String jJ_MINAP_YMD) {
		JJ_MINAP_YMD = jJ_MINAP_YMD;
	}
	public String getJJ_MINAP_IJA() {
		return JJ_MINAP_IJA;
	}
	public void setJJ_MINAP_IJA(String jJ_MINAP_IJA) {
		JJ_MINAP_IJA = jJ_MINAP_IJA;
	}
	public String getJJ_SANGHWAN_IJA() {
		return JJ_SANGHWAN_IJA;
	}
	public void setJJ_SANGHWAN_IJA(String jJ_SANGHWAN_IJA) {
		JJ_SANGHWAN_IJA = jJ_SANGHWAN_IJA;
	}
	public String getJJ_WONLIGM_YMD() {
		return JJ_WONLIGM_YMD;
	}
	public void setJJ_WONLIGM_YMD(String jJ_WONLIGM_YMD) {
		JJ_WONLIGM_YMD = jJ_WONLIGM_YMD;
	}
	public String getJJ_WONLIGM() {
		return JJ_WONLIGM;
	}
	public void setJJ_WONLIGM(String jJ_WONLIGM) {
		JJ_WONLIGM = jJ_WONLIGM;
	}
	public String getJJ_SANGHWAN_WONLIGM() {
		return JJ_SANGHWAN_WONLIGM;
	}
	public void setJJ_SANGHWAN_WONLIGM(String jJ_SANGHWAN_WONLIGM) {
		JJ_SANGHWAN_WONLIGM = jJ_SANGHWAN_WONLIGM;
	}
	public String getJJ_HAND_PHONE() {
		return JJ_HAND_PHONE;
	}
	public void setJJ_HAND_PHONE(String jJ_HAND_PHONE) {
		JJ_HAND_PHONE = jJ_HAND_PHONE;
	}
	public String getJJ_JUNG_F1() {
		return JJ_JUNG_F1;
	}
	public void setJJ_JUNG_F1(String jJ_JUNG_F1) {
		JJ_JUNG_F1 = jJ_JUNG_F1;
	}
	public String getJJ_JUNG_T1() {
		return JJ_JUNG_T1;
	}
	public void setJJ_JUNG_T1(String jJ_JUNG_T1) {
		JJ_JUNG_T1 = jJ_JUNG_T1;
	}
	public String getJJ_JUNG_ILSU1() {
		return JJ_JUNG_ILSU1;
	}
	public void setJJ_JUNG_ILSU1(String jJ_JUNG_ILSU1) {
		JJ_JUNG_ILSU1 = jJ_JUNG_ILSU1;
	}
	public String getJJ_JUNG_IJA1() {
		return JJ_JUNG_IJA1;
	}
	public void setJJ_JUNG_IJA1(String jJ_JUNG_IJA1) {
		JJ_JUNG_IJA1 = jJ_JUNG_IJA1;
	}
	public String getJJ_JUNG_F2() {
		return JJ_JUNG_F2;
	}
	public void setJJ_JUNG_F2(String jJ_JUNG_F2) {
		JJ_JUNG_F2 = jJ_JUNG_F2;
	}
	public String getJJ_JUNG_T2() {
		return JJ_JUNG_T2;
	}
	public void setJJ_JUNG_T2(String jJ_JUNG_T2) {
		JJ_JUNG_T2 = jJ_JUNG_T2;
	}
	public String getJJ_JUNG_ILSU2() {
		return JJ_JUNG_ILSU2;
	}
	public void setJJ_JUNG_ILSU2(String jJ_JUNG_ILSU2) {
		JJ_JUNG_ILSU2 = jJ_JUNG_ILSU2;
	}
	public String getJJ_JUNG_IJA2() {
		return JJ_JUNG_IJA2;
	}
	public void setJJ_JUNG_IJA2(String jJ_JUNG_IJA2) {
		JJ_JUNG_IJA2 = jJ_JUNG_IJA2;
	}
	public String getJJ_YUNC_F1() {
		return JJ_YUNC_F1;
	}
	public void setJJ_YUNC_F1(String jJ_YUNC_F1) {
		JJ_YUNC_F1 = jJ_YUNC_F1;
	}
	public String getJJ_YUNC_T1() {
		return JJ_YUNC_T1;
	}
	public void setJJ_YUNC_T1(String jJ_YUNC_T1) {
		JJ_YUNC_T1 = jJ_YUNC_T1;
	}
	public String getJJ_YUNC_ILSU1() {
		return JJ_YUNC_ILSU1;
	}
	public void setJJ_YUNC_ILSU1(String jJ_YUNC_ILSU1) {
		JJ_YUNC_ILSU1 = jJ_YUNC_ILSU1;
	}
	public String getJJ_YUNC_IJA1() {
		return JJ_YUNC_IJA1;
	}
	public void setJJ_YUNC_IJA1(String jJ_YUNC_IJA1) {
		JJ_YUNC_IJA1 = jJ_YUNC_IJA1;
	}
	public String getJJ_YUNC_F2() {
		return JJ_YUNC_F2;
	}
	public void setJJ_YUNC_F2(String jJ_YUNC_F2) {
		JJ_YUNC_F2 = jJ_YUNC_F2;
	}
	public String getJJ_YUNC_T2() {
		return JJ_YUNC_T2;
	}
	public void setJJ_YUNC_T2(String jJ_YUNC_T2) {
		JJ_YUNC_T2 = jJ_YUNC_T2;
	}
	public String getJJ_YUNC_ILSU2() {
		return JJ_YUNC_ILSU2;
	}
	public void setJJ_YUNC_ILSU2(String jJ_YUNC_ILSU2) {
		JJ_YUNC_ILSU2 = jJ_YUNC_ILSU2;
	}
	public String getJJ_YUNC_IJA2() {
		return JJ_YUNC_IJA2;
	}
	public void setJJ_YUNC_IJA2(String jJ_YUNC_IJA2) {
		JJ_YUNC_IJA2 = jJ_YUNC_IJA2;
	}
	public String getJJ_MIGU_ILSU() {
		return JJ_MIGU_ILSU;
	}
	public void setJJ_MIGU_ILSU(String jJ_MIGU_ILSU) {
		JJ_MIGU_ILSU = jJ_MIGU_ILSU;
	}
	public String getJJ_MIGU_IJA() {
		return JJ_MIGU_IJA;
	}
	public void setJJ_MIGU_IJA(String jJ_MIGU_IJA) {
		JJ_MIGU_IJA = jJ_MIGU_IJA;
	}
	public String getJJ_GWAO_GM() {
		return JJ_GWAO_GM;
	}
	public void setJJ_GWAO_GM(String jJ_GWAO_GM) {
		JJ_GWAO_GM = jJ_GWAO_GM;
	}
	public String getUU_POLI_NO() {
		return UU_POLI_NO;
	}
	public void setUU_POLI_NO(String uU_POLI_NO) {
		UU_POLI_NO = uU_POLI_NO;
	}
	public String getCC_CHANNEL() {
		return CC_CHANNEL;
	}
	public void setCC_CHANNEL(String cC_CHANNEL) {
		CC_CHANNEL = cC_CHANNEL;
	}
	public String getCC_UKEY() {
		return CC_UKEY;
	}
	public void setCC_UKEY(String cC_UKEY) {
		CC_UKEY = cC_UKEY;
	}
	public String getCC_PGMID() {
		return CC_PGMID;
	}
	public void setCC_PGMID(String cC_PGMID) {
		CC_PGMID = cC_PGMID;
	}
	public String getCC_PROC_GB() {
		return CC_PROC_GB;
	}
	public void setCC_PROC_GB(String cC_PROC_GB) {
		CC_PROC_GB = cC_PROC_GB;
	}
	public String getCC_FUN_KEY() {
		return CC_FUN_KEY;
	}
	public void setCC_FUN_KEY(String cC_FUN_KEY) {
		CC_FUN_KEY = cC_FUN_KEY;
	}
	public String getCC_USER_GB() {
		return CC_USER_GB;
	}
	public void setCC_USER_GB(String cC_USER_GB) {
		CC_USER_GB = cC_USER_GB;
	}
	public String getCC_USER_CD() {
		return CC_USER_CD;
	}
	public void setCC_USER_CD(String cC_USER_CD) {
		CC_USER_CD = cC_USER_CD;
	}
	public String getCC_JIJUM_CD() {
		return CC_JIJUM_CD;
	}
	public void setCC_JIJUM_CD(String cC_JIJUM_CD) {
		CC_JIJUM_CD = cC_JIJUM_CD;
	}
	public String getCC_JIBU_CD() {
		return CC_JIBU_CD;
	}
	public void setCC_JIBU_CD(String cC_JIBU_CD) {
		CC_JIBU_CD = cC_JIBU_CD;
	}
	public String getCC_PROTOCOL() {
		return CC_PROTOCOL;
	}
	public void setCC_PROTOCOL(String cC_PROTOCOL) {
		CC_PROTOCOL = cC_PROTOCOL;
	}
	public String getCC_COND_CD() {
		return CC_COND_CD;
	}
	public void setCC_COND_CD(String cC_COND_CD) {
		CC_COND_CD = cC_COND_CD;
	}
	public String getCC_LAST_FLAG() {
		return CC_LAST_FLAG;
	}
	public void setCC_LAST_FLAG(String cC_LAST_FLAG) {
		CC_LAST_FLAG = cC_LAST_FLAG;
	}
	public String getCC_CURSOR_MAP() {
		return CC_CURSOR_MAP;
	}
	public void setCC_CURSOR_MAP(String cC_CURSOR_MAP) {
		CC_CURSOR_MAP = cC_CURSOR_MAP;
	}
	public String getCC_CURSOR_IDX() {
		return CC_CURSOR_IDX;
	}
	public void setCC_CURSOR_IDX(String cC_CURSOR_IDX) {
		CC_CURSOR_IDX = cC_CURSOR_IDX;
	}
	public String getCC_MESSAGE_CD() {
		return CC_MESSAGE_CD;
	}
	public void setCC_MESSAGE_CD(String cC_MESSAGE_CD) {
		CC_MESSAGE_CD = cC_MESSAGE_CD;
	}
	public String getHC_MESSAGE_NM() {
		return HC_MESSAGE_NM;
	}
	public void setHC_MESSAGE_NM(String hC_MESSAGE_NM) {
		HC_MESSAGE_NM = hC_MESSAGE_NM;
	}
	public String getCC_SYS_ERR() {
		return CC_SYS_ERR;
	}
	public void setCC_SYS_ERR(String cC_SYS_ERR) {
		CC_SYS_ERR = cC_SYS_ERR;
	}
	public String getCC_FILLER() {
		return CC_FILLER;
	}
	public void setCC_FILLER(String cC_FILLER) {
		CC_FILLER = cC_FILLER;
	}
	public String getJJ_SANGTE_JIJUM() {
		return JJ_SANGTE_JIJUM;
	}
	public void setJJ_SANGTE_JIJUM(String jJ_SANGTE_JIJUM) {
		JJ_SANGTE_JIJUM = jJ_SANGTE_JIJUM;
	}
	public String getJJ_SANGTE_YMD() {
		return JJ_SANGTE_YMD;
	}
	public void setJJ_SANGTE_YMD(String jJ_SANGTE_YMD) {
		JJ_SANGTE_YMD = jJ_SANGTE_YMD;
	}
	public String getHJ_SUGUM_DERIJUMJU() {
		return HJ_SUGUM_DERIJUMJU;
	}
	public void setHJ_SUGUM_DERIJUMJU(String hJ_SUGUM_DERIJUMJU) {
		HJ_SUGUM_DERIJUMJU = hJ_SUGUM_DERIJUMJU;
	}
	public String getJJ_YOC_NO() {
		return JJ_YOC_NO;
	}
	public void setJJ_YOC_NO(String jJ_YOC_NO) {
		JJ_YOC_NO = jJ_YOC_NO;
	}
	public String getJJ_BANK_CD() {
		return JJ_BANK_CD;
	}
	public void setJJ_BANK_CD(String jJ_BANK_CD) {
		JJ_BANK_CD = jJ_BANK_CD;
	}
	public String getHJ_BANK_NAME() {
		return HJ_BANK_NAME;
	}
	public void setHJ_BANK_NAME(String hJ_BANK_NAME) {
		HJ_BANK_NAME = hJ_BANK_NAME;
	}
	public String getJJ_GYEJWA_NO() {
		return JJ_GYEJWA_NO;
	}
	public void setJJ_GYEJWA_NO(String jJ_GYEJWA_NO) {
		JJ_GYEJWA_NO = jJ_GYEJWA_NO;
	}
	public String getHJ_YEGMJU_NAME() {
		return HJ_YEGMJU_NAME;
	}
	public void setHJ_YEGMJU_NAME(String hJ_YEGMJU_NAME) {
		HJ_YEGMJU_NAME = hJ_YEGMJU_NAME;
	}
	public String getJJ_YEGMJU_ID() {
		return JJ_YEGMJU_ID;
	}
	public void setJJ_YEGMJU_ID(String jJ_YEGMJU_ID) {
		JJ_YEGMJU_ID = jJ_YEGMJU_ID;
	}
	public String getJJ_YEGMJU_CHECK() {
		return JJ_YEGMJU_CHECK;
	}
	public void setJJ_YEGMJU_CHECK(String jJ_YEGMJU_CHECK) {
		JJ_YEGMJU_CHECK = jJ_YEGMJU_CHECK;
	}
	public String getHJ_REMARK() {
		return HJ_REMARK;
	}
	public void setHJ_REMARK(String hJ_REMARK) {
		HJ_REMARK = hJ_REMARK;
	}
	public String getJJ_SYS_RC() {
		return JJ_SYS_RC;
	}
	public void setJJ_SYS_RC(String jJ_SYS_RC) {
		JJ_SYS_RC = jJ_SYS_RC;
	}
	public String getJJ_MIGU_F() {
		return JJ_MIGU_F;
	}
	public void setJJ_MIGU_F(String jJ_MIGU_F) {
		JJ_MIGU_F = jJ_MIGU_F;
	}
	public String getJJ_MIGU_T() {
		return JJ_MIGU_T;
	}
	public void setJJ_MIGU_T(String jJ_MIGU_T) {
		JJ_MIGU_T = jJ_MIGU_T;
	}
	public String getHJ_GWAO_NM() {
		return HJ_GWAO_NM;
	}
	public void setHJ_GWAO_NM(String hJ_GWAO_NM) {
		HJ_GWAO_NM = hJ_GWAO_NM;
	}
	public String getProid() {
		return proid;
	}
	public String getTrid() {
		return trid;
	}
	public String getCC_PRT_GB() {
		return CC_PRT_GB;
	}
	public void setCC_PRT_GB(String cC_PRT_GB) {
		CC_PRT_GB = cC_PRT_GB;
	}
	public String getJJ_POLI_NO_MASKING() {
		return JJ_POLI_NO_MASKING;
	}
	public void setJJ_POLI_NO_MASKING(String jJ_POLI_NO_MASKING) {
		JJ_POLI_NO_MASKING = jJ_POLI_NO_MASKING;
	}
	
}
