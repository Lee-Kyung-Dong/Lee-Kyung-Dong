package com.idongbu.smartcustomer.vo;

import java.util.List;

import com.idongbu.common.vo.CMMVO;

// 계약조회 상세
public class CmmFWK2808RVO extends CMMVO {
	public static final String proid		= "FWK2808R";
	public static final String trid			= "WV08";
	public String rURL						= "";

	// 입력
	public String SD_TRID                                                         = null;
	public String SD_FLAG                                                         = null;
	public String SD_NETWORK                                                      = null;
	public String SD_JUNSONG_TIME                                                 = null;
	public String SD_BOHUMSA_GB                                                   = null;
	public String SD_BOGUMSA_CD                                                   = null;
	public String SD_FILL                                                         = null;
	public String LK_WK2808_LOGON_ID                                              = null;
	public String LK_WK2808_PART1                                                 = null;
	public String LK_WK2808_PART2                                                 = null;
	public String LK_WK2808_UPMU_BUNRYU1                                          = null;
	public String LK_WK2808_UPMU_BUNRYU2                                          = null;
	public String LK_WK2808_UPMU_BUNRYU3                                          = null;
	public String LK_WK2808_CON_YN                                                = null;
	public String LK_WK2808_FIL1                                                  = null;
	public String LK_WK2808_POLI_NO                                               = null; // 증권번호

	public String LK_WK2808_RC = null;
	public String LK_WK2808_MSG_CD1 = null;
	public String LK_WK2808_MSG_CD2 = null;
	public String H_LK_WK2808_MSG_ERR1 = null;
	public String H_LK_WK2808_MSG_ERR2 = null;
	public String LK_WK2808_BOJONG_CD = null;
	public String H_LK_WK2808_BOJONG_NM = null;
	public String LK_WK2808_CHUNGYAK_SYMD = null;
	public String LK_WK2808_CHUNGYAK_EYMD = null;
	public String H_LK_WK2808_GYEYAKJA_NM = null;
	public String LK_WK2808_UPYUN_NO = null;
	public String H_LK_WK2808_GITA_BUNJI = null;
	public String LK_WK2808_NAPIP_AMT = null;
	public String LK_WK2808_NAPBANG_CD = null;
	public String H_LK_WK2808_NAPIP_BB = null;
	public String LK_WK2808_GAIP_YUHYUNG_CD = null;
	public String H_LK_WK2808_GAIP_YUHYUNG = null;
	public String LK_WK2808_GYEYAK_ST_CD = null;
	public String H_LK_WK2808_GYEYAK_ST = null;
	public String LK_WK2808_CHUIGPJA = null;
	public String H_LK_WK2808_CHUIGPJA_NM = null;
	public String LK_WK2808_TELEPHONE = null;
	public String LK_ZIP = null;
	public String H_LK_GITA_BUNJI = null;
	public String[] H_LK_WK2808_TKYAK_DAMBO = new String[0]; // 25
	public String[] LK_WK2808_TKYAK_GAIP_AMT = new String[0]; // 25
	public String LK_WK2808_FIL3 = null;
	public List<SubFWK2808RVO> LIST_DATA = null;
	public List<SubFWK2808RVO> TKYAKDATA = null;
	public String LK_WK2808_GAIP_YUHYUNG = null;
	
	// 2011.7.23 김소하. 도로명주소관련 추가
	public String LK_WK2808_ST_ZIP_NO = ""; // 우편번호
	public String H_LK_WK2808_ST_ADDR = ""; // 도로명
	public String H_LK_WK2808_ST_GITA = ""; // 기타주소
	public String LK_WK2808_SINGU_GB = ""; // 신구주소구분
	public String getrURL() {
		return rURL;
	}
	public void setrURL(String rURL) {
		this.rURL = rURL;
	}
	public String getSD_TRID() {
		return SD_TRID;
	}
	public void setSD_TRID(String sD_TRID) {
		SD_TRID = sD_TRID;
	}
	public String getSD_FLAG() {
		return SD_FLAG;
	}
	public void setSD_FLAG(String sD_FLAG) {
		SD_FLAG = sD_FLAG;
	}
	public String getSD_NETWORK() {
		return SD_NETWORK;
	}
	public void setSD_NETWORK(String sD_NETWORK) {
		SD_NETWORK = sD_NETWORK;
	}
	public String getSD_JUNSONG_TIME() {
		return SD_JUNSONG_TIME;
	}
	public void setSD_JUNSONG_TIME(String sD_JUNSONG_TIME) {
		SD_JUNSONG_TIME = sD_JUNSONG_TIME;
	}
	public String getSD_BOHUMSA_GB() {
		return SD_BOHUMSA_GB;
	}
	public void setSD_BOHUMSA_GB(String sD_BOHUMSA_GB) {
		SD_BOHUMSA_GB = sD_BOHUMSA_GB;
	}
	public String getSD_BOGUMSA_CD() {
		return SD_BOGUMSA_CD;
	}
	public void setSD_BOGUMSA_CD(String sD_BOGUMSA_CD) {
		SD_BOGUMSA_CD = sD_BOGUMSA_CD;
	}
	public String getSD_FILL() {
		return SD_FILL;
	}
	public void setSD_FILL(String sD_FILL) {
		SD_FILL = sD_FILL;
	}
	public String getLK_WK2808_LOGON_ID() {
		return LK_WK2808_LOGON_ID;
	}
	public void setLK_WK2808_LOGON_ID(String lK_WK2808_LOGON_ID) {
		LK_WK2808_LOGON_ID = lK_WK2808_LOGON_ID;
	}
	public String getLK_WK2808_PART1() {
		return LK_WK2808_PART1;
	}
	public void setLK_WK2808_PART1(String lK_WK2808_PART1) {
		LK_WK2808_PART1 = lK_WK2808_PART1;
	}
	public String getLK_WK2808_PART2() {
		return LK_WK2808_PART2;
	}
	public void setLK_WK2808_PART2(String lK_WK2808_PART2) {
		LK_WK2808_PART2 = lK_WK2808_PART2;
	}
	public String getLK_WK2808_UPMU_BUNRYU1() {
		return LK_WK2808_UPMU_BUNRYU1;
	}
	public void setLK_WK2808_UPMU_BUNRYU1(String lK_WK2808_UPMU_BUNRYU1) {
		LK_WK2808_UPMU_BUNRYU1 = lK_WK2808_UPMU_BUNRYU1;
	}
	public String getLK_WK2808_UPMU_BUNRYU2() {
		return LK_WK2808_UPMU_BUNRYU2;
	}
	public void setLK_WK2808_UPMU_BUNRYU2(String lK_WK2808_UPMU_BUNRYU2) {
		LK_WK2808_UPMU_BUNRYU2 = lK_WK2808_UPMU_BUNRYU2;
	}
	public String getLK_WK2808_UPMU_BUNRYU3() {
		return LK_WK2808_UPMU_BUNRYU3;
	}
	public void setLK_WK2808_UPMU_BUNRYU3(String lK_WK2808_UPMU_BUNRYU3) {
		LK_WK2808_UPMU_BUNRYU3 = lK_WK2808_UPMU_BUNRYU3;
	}
	public String getLK_WK2808_CON_YN() {
		return LK_WK2808_CON_YN;
	}
	public void setLK_WK2808_CON_YN(String lK_WK2808_CON_YN) {
		LK_WK2808_CON_YN = lK_WK2808_CON_YN;
	}
	public String getLK_WK2808_FIL1() {
		return LK_WK2808_FIL1;
	}
	public void setLK_WK2808_FIL1(String lK_WK2808_FIL1) {
		LK_WK2808_FIL1 = lK_WK2808_FIL1;
	}
	public String getLK_WK2808_POLI_NO() {
		return LK_WK2808_POLI_NO;
	}
	public void setLK_WK2808_POLI_NO(String lK_WK2808_POLI_NO) {
		LK_WK2808_POLI_NO = lK_WK2808_POLI_NO;
	}
	public String getLK_WK2808_RC() {
		return LK_WK2808_RC;
	}
	public void setLK_WK2808_RC(String lK_WK2808_RC) {
		LK_WK2808_RC = lK_WK2808_RC;
	}
	public String getLK_WK2808_MSG_CD1() {
		return LK_WK2808_MSG_CD1;
	}
	public void setLK_WK2808_MSG_CD1(String lK_WK2808_MSG_CD1) {
		LK_WK2808_MSG_CD1 = lK_WK2808_MSG_CD1;
	}
	public String getLK_WK2808_MSG_CD2() {
		return LK_WK2808_MSG_CD2;
	}
	public void setLK_WK2808_MSG_CD2(String lK_WK2808_MSG_CD2) {
		LK_WK2808_MSG_CD2 = lK_WK2808_MSG_CD2;
	}
	public String getH_LK_WK2808_MSG_ERR1() {
		return H_LK_WK2808_MSG_ERR1;
	}
	public void setH_LK_WK2808_MSG_ERR1(String h_LK_WK2808_MSG_ERR1) {
		H_LK_WK2808_MSG_ERR1 = h_LK_WK2808_MSG_ERR1;
	}
	public String getH_LK_WK2808_MSG_ERR2() {
		return H_LK_WK2808_MSG_ERR2;
	}
	public void setH_LK_WK2808_MSG_ERR2(String h_LK_WK2808_MSG_ERR2) {
		H_LK_WK2808_MSG_ERR2 = h_LK_WK2808_MSG_ERR2;
	}
	public String getLK_WK2808_BOJONG_CD() {
		return LK_WK2808_BOJONG_CD;
	}
	public void setLK_WK2808_BOJONG_CD(String lK_WK2808_BOJONG_CD) {
		LK_WK2808_BOJONG_CD = lK_WK2808_BOJONG_CD;
	}
	public String getH_LK_WK2808_BOJONG_NM() {
		return H_LK_WK2808_BOJONG_NM;
	}
	public void setH_LK_WK2808_BOJONG_NM(String h_LK_WK2808_BOJONG_NM) {
		H_LK_WK2808_BOJONG_NM = h_LK_WK2808_BOJONG_NM;
	}
	public String getLK_WK2808_CHUNGYAK_SYMD() {
		return LK_WK2808_CHUNGYAK_SYMD;
	}
	public void setLK_WK2808_CHUNGYAK_SYMD(String lK_WK2808_CHUNGYAK_SYMD) {
		LK_WK2808_CHUNGYAK_SYMD = lK_WK2808_CHUNGYAK_SYMD;
	}
	public String getLK_WK2808_CHUNGYAK_EYMD() {
		return LK_WK2808_CHUNGYAK_EYMD;
	}
	public void setLK_WK2808_CHUNGYAK_EYMD(String lK_WK2808_CHUNGYAK_EYMD) {
		LK_WK2808_CHUNGYAK_EYMD = lK_WK2808_CHUNGYAK_EYMD;
	}
	public String getH_LK_WK2808_GYEYAKJA_NM() {
		return H_LK_WK2808_GYEYAKJA_NM;
	}
	public void setH_LK_WK2808_GYEYAKJA_NM(String h_LK_WK2808_GYEYAKJA_NM) {
		H_LK_WK2808_GYEYAKJA_NM = h_LK_WK2808_GYEYAKJA_NM;
	}
	public String getLK_WK2808_UPYUN_NO() {
		return LK_WK2808_UPYUN_NO;
	}
	public void setLK_WK2808_UPYUN_NO(String lK_WK2808_UPYUN_NO) {
		LK_WK2808_UPYUN_NO = lK_WK2808_UPYUN_NO;
	}
	public String getH_LK_WK2808_GITA_BUNJI() {
		return H_LK_WK2808_GITA_BUNJI;
	}
	public void setH_LK_WK2808_GITA_BUNJI(String h_LK_WK2808_GITA_BUNJI) {
		H_LK_WK2808_GITA_BUNJI = h_LK_WK2808_GITA_BUNJI;
	}
	public String getLK_WK2808_NAPIP_AMT() {
		return LK_WK2808_NAPIP_AMT;
	}
	public void setLK_WK2808_NAPIP_AMT(String lK_WK2808_NAPIP_AMT) {
		LK_WK2808_NAPIP_AMT = lK_WK2808_NAPIP_AMT;
	}
	public String getLK_WK2808_NAPBANG_CD() {
		return LK_WK2808_NAPBANG_CD;
	}
	public void setLK_WK2808_NAPBANG_CD(String lK_WK2808_NAPBANG_CD) {
		LK_WK2808_NAPBANG_CD = lK_WK2808_NAPBANG_CD;
	}
	public String getH_LK_WK2808_NAPIP_BB() {
		return H_LK_WK2808_NAPIP_BB;
	}
	public void setH_LK_WK2808_NAPIP_BB(String h_LK_WK2808_NAPIP_BB) {
		H_LK_WK2808_NAPIP_BB = h_LK_WK2808_NAPIP_BB;
	}
	public String getLK_WK2808_GAIP_YUHYUNG_CD() {
		return LK_WK2808_GAIP_YUHYUNG_CD;
	}
	public void setLK_WK2808_GAIP_YUHYUNG_CD(String lK_WK2808_GAIP_YUHYUNG_CD) {
		LK_WK2808_GAIP_YUHYUNG_CD = lK_WK2808_GAIP_YUHYUNG_CD;
	}
	public String getH_LK_WK2808_GAIP_YUHYUNG() {
		return H_LK_WK2808_GAIP_YUHYUNG;
	}
	public void setH_LK_WK2808_GAIP_YUHYUNG(String h_LK_WK2808_GAIP_YUHYUNG) {
		H_LK_WK2808_GAIP_YUHYUNG = h_LK_WK2808_GAIP_YUHYUNG;
	}
	public String getLK_WK2808_GYEYAK_ST_CD() {
		return LK_WK2808_GYEYAK_ST_CD;
	}
	public void setLK_WK2808_GYEYAK_ST_CD(String lK_WK2808_GYEYAK_ST_CD) {
		LK_WK2808_GYEYAK_ST_CD = lK_WK2808_GYEYAK_ST_CD;
	}
	public String getH_LK_WK2808_GYEYAK_ST() {
		return H_LK_WK2808_GYEYAK_ST;
	}
	public void setH_LK_WK2808_GYEYAK_ST(String h_LK_WK2808_GYEYAK_ST) {
		H_LK_WK2808_GYEYAK_ST = h_LK_WK2808_GYEYAK_ST;
	}
	public String getLK_WK2808_CHUIGPJA() {
		return LK_WK2808_CHUIGPJA;
	}
	public void setLK_WK2808_CHUIGPJA(String lK_WK2808_CHUIGPJA) {
		LK_WK2808_CHUIGPJA = lK_WK2808_CHUIGPJA;
	}
	public String getH_LK_WK2808_CHUIGPJA_NM() {
		return H_LK_WK2808_CHUIGPJA_NM;
	}
	public void setH_LK_WK2808_CHUIGPJA_NM(String h_LK_WK2808_CHUIGPJA_NM) {
		H_LK_WK2808_CHUIGPJA_NM = h_LK_WK2808_CHUIGPJA_NM;
	}
	public String getLK_WK2808_TELEPHONE() {
		return LK_WK2808_TELEPHONE;
	}
	public void setLK_WK2808_TELEPHONE(String lK_WK2808_TELEPHONE) {
		LK_WK2808_TELEPHONE = lK_WK2808_TELEPHONE;
	}
	public String getLK_ZIP() {
		return LK_ZIP;
	}
	public void setLK_ZIP(String lK_ZIP) {
		LK_ZIP = lK_ZIP;
	}
	public String getH_LK_GITA_BUNJI() {
		return H_LK_GITA_BUNJI;
	}
	public void setH_LK_GITA_BUNJI(String h_LK_GITA_BUNJI) {
		H_LK_GITA_BUNJI = h_LK_GITA_BUNJI;
	}
	public String[] getH_LK_WK2808_TKYAK_DAMBO() {
		return H_LK_WK2808_TKYAK_DAMBO;
	}
	public void setH_LK_WK2808_TKYAK_DAMBO(String[] h_LK_WK2808_TKYAK_DAMBO) {
		H_LK_WK2808_TKYAK_DAMBO = h_LK_WK2808_TKYAK_DAMBO;
	}
	public String[] getLK_WK2808_TKYAK_GAIP_AMT() {
		return LK_WK2808_TKYAK_GAIP_AMT;
	}
	public void setLK_WK2808_TKYAK_GAIP_AMT(String[] lK_WK2808_TKYAK_GAIP_AMT) {
		LK_WK2808_TKYAK_GAIP_AMT = lK_WK2808_TKYAK_GAIP_AMT;
	}
	public String getLK_WK2808_FIL3() {
		return LK_WK2808_FIL3;
	}
	public void setLK_WK2808_FIL3(String lK_WK2808_FIL3) {
		LK_WK2808_FIL3 = lK_WK2808_FIL3;
	}
	public String getLK_WK2808_ST_ZIP_NO() {
		return LK_WK2808_ST_ZIP_NO;
	}
	public void setLK_WK2808_ST_ZIP_NO(String lK_WK2808_ST_ZIP_NO) {
		LK_WK2808_ST_ZIP_NO = lK_WK2808_ST_ZIP_NO;
	}
	public String getH_LK_WK2808_ST_ADDR() {
		return H_LK_WK2808_ST_ADDR;
	}
	public void setH_LK_WK2808_ST_ADDR(String h_LK_WK2808_ST_ADDR) {
		H_LK_WK2808_ST_ADDR = h_LK_WK2808_ST_ADDR;
	}
	public String getH_LK_WK2808_ST_GITA() {
		return H_LK_WK2808_ST_GITA;
	}
	public void setH_LK_WK2808_ST_GITA(String h_LK_WK2808_ST_GITA) {
		H_LK_WK2808_ST_GITA = h_LK_WK2808_ST_GITA;
	}
	public String getLK_WK2808_SINGU_GB() {
		return LK_WK2808_SINGU_GB;
	}
	public void setLK_WK2808_SINGU_GB(String lK_WK2808_SINGU_GB) {
		LK_WK2808_SINGU_GB = lK_WK2808_SINGU_GB;
	}
	public static String getProid() {
		return proid;
	}
	public static String getTrid() {
		return trid;
	}
	public List<SubFWK2808RVO> getLIST_DATA() {
		return LIST_DATA;
	}
	public void setLIST_DATA(List<SubFWK2808RVO> lIST_DATA) {
		LIST_DATA = lIST_DATA;
	}
	public List<SubFWK2808RVO> getTKYAKDATA() {
		return TKYAKDATA;
	}
	public void setTKYAKDATA(List<SubFWK2808RVO> tKYAKDATA) {
		TKYAKDATA = tKYAKDATA;
	}
	public String getLK_WK2808_GAIP_YUHYUNG() {
		return LK_WK2808_GAIP_YUHYUNG;
	}
	public void setLK_WK2808_GAIP_YUHYUNG(String lK_WK2808_GAIP_YUHYUNG) {
		LK_WK2808_GAIP_YUHYUNG = lK_WK2808_GAIP_YUHYUNG;
	}
}
