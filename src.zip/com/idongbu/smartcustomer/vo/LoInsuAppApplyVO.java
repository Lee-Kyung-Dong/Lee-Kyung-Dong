package com.idongbu.smartcustomer.vo;

public class LoInsuAppApplyVO  {
	
	private String 	ssnUserJumin			= "";		//2차에서는 CmmVO에서 상속받은 필드
	private String 	ssnUserName			= "";		//2차에서는 CmmVO에서 상속받은 필드	고객명
	private String 	ssnYakgwn			= "";			//2차에서는 CmmVO에서 상속받은 필드
	
	private String 	mode						= "";
	private String   insub_pd_name               = ""; //보험상품명
	private String   stock_seq                   = ""; //증권번호
	private String   ar_sttus_name               = ""; //계약상태명
	private long     re_stplt_loan_resid_amt     = 0; //기약관대출잔액
	private String   int_pay_date			    = ""; //이자납입일자시간
	private String   int_rate				    = ""; //이율
	private String   inet_loan_posbl_yn		    = ""; //인터넷대출가능여부
	private long     stplt_loan_posbl_amt	    = 0; //약관대출가능금액
	private long     tot						    = 0; //총 대출 신청액
	private long     totdaechul				    = 0; //총 대출 신청액
	
	private long     loanMoney				    = 0; //대출금액 (대출확정시 DB insert시 사용)
	
	private String   ins_lcpl_dvcd				    = ""; // 컨버전스 구분코드1
	private String   ply_sqno		    = ""; //컨버전스 구분코드2
	
	// luxncool 2008.12.16	
	private String jj_bank_cd =""; // 은행코드
	private String jj_gyejwa_no =""; // 계좌번호
	private String jj_gyejwa_no_masking =""; // 계좌번호 마스킹
	private String jj_s_ganung_gb =""; // 
	private String jikwonCK          = ""; //직원여부 1=임직원 2=PA
	private String jj_bank_name = "";  //은행명
	private String internetYN = "";

	//이자납입계좌
	private String jj_ij_bank_cd =""; // 은행코드
	private String jj_ij_gyejwa_no =""; // 계좌번호
	private String jj_ij_gyejwa_no_masking =""; // 계좌번호 마스킹
	private String hj_ij_bank_nm =""; // 

	//오프라인 창구 등록 계좌 정보  2012.05.11 빈현욱
	private String JJ_GYEJWA_YN_6011 = "";   // 1이면 창구등록계좌 0이면 기존계좌
	
	private String   flag						= "";
	private boolean  timeflag					= false;
	private String   Yayak						= "";
	private String   encrypted_amount		    = "";
	private String   encrypted_note_url		    = "";
	private String   encrypted_home_url		    = "";
	private String   encrypted_oid			    = "";
	private String   m_mid					    = "";
	private String   hashdata				    = "";
	private int	    noData 					    = 0;
	
//	private boolean  isUserInfoModifiedInMonth	= false;
	// 2008.09.17 by hsahn 최근 3개월(90일)간 휴대폰번호 변경 여부
	private boolean 	isMPhoneModifiedIn3Months	= false;
	// {2008.09.17}

	// 2008.09.11 by hsahn 해지환급금 실수령액이 100만원 이하인 경우 [휴대폰명의확인] 처리 적용
	// 휴대폰 명의확인 결과
	private int mphone_chk						= 0;
	
	private String EncodeData					= "";
	private String DecodeData					= "";	
	
	// 휴대폰 번호 변경 여부 (통합고객에 등록된 휴대폰 번호와 다른 휴대폰으로 명의 확인했는지 여부)
	private String mphone_changed_yn				= "N";
	// {2008.09.11}
	
	private String phoneCompany					= "";	
	private String phoneNum					= "";	
	private String certNum					= "";	
	private String check_1					= "";	
	private String check_2					= "";	
	private String check_3					= "";	
	private String certMessage					= "";
	
	private String make_yymmdd = ""; 
	private String make_hour_min_sec = ""; 
	
	public String getSsnUserJumin() {
		return ssnUserJumin;
	}
	public void setSsnUserJumin(String ssnUserJumin) {
		this.ssnUserJumin = ssnUserJumin;
	}
	public String getSsnYakgwn() {
		return ssnYakgwn;
	}
	public void setSsnYakgwn(String ssnYakgwn) {
		this.ssnYakgwn = ssnYakgwn;
	}
	public String getMode() {
		return mode;
	}
	public void setMode(String mode) {
		this.mode = mode;
	}
	public String getInsub_pd_name() {
		return insub_pd_name;
	}
	public void setInsub_pd_name(String insub_pd_name) {
		this.insub_pd_name = insub_pd_name;
	}
	public String getStock_seq() {
		return stock_seq;
	}
	public void setStock_seq(String stock_seq) {
		this.stock_seq = stock_seq;
	}
	public String getAr_sttus_name() {
		return ar_sttus_name;
	}
	public void setAr_sttus_name(String ar_sttus_name) {
		this.ar_sttus_name = ar_sttus_name;
	}
	public long getRe_stplt_loan_resid_amt() {
		return re_stplt_loan_resid_amt;
	}
	public void setRe_stplt_loan_resid_amt(long re_stplt_loan_resid_amt) {
		this.re_stplt_loan_resid_amt = re_stplt_loan_resid_amt;
	}
	public String getInt_pay_date() {
		return int_pay_date;
	}
	public void setInt_pay_date(String int_pay_date) {
		this.int_pay_date = int_pay_date;
	}
	public String getInt_rate() {
		return int_rate;
	}
	public void setInt_rate(String int_rate) {
		this.int_rate = int_rate;
	}
	public String getInet_loan_posbl_yn() {
		return inet_loan_posbl_yn;
	}
	public void setInet_loan_posbl_yn(String inet_loan_posbl_yn) {
		this.inet_loan_posbl_yn = inet_loan_posbl_yn;
	}
	public long getStplt_loan_posbl_amt() {
		return stplt_loan_posbl_amt;
	}
	public void setStplt_loan_posbl_amt(long stplt_loan_posbl_amt) {
		this.stplt_loan_posbl_amt = stplt_loan_posbl_amt;
	}
	public long getTot() {
		return tot;
	}
	public void setTot(long tot) {
		this.tot = tot;
	}
	public long getTotdaechul() {
		return totdaechul;
	}
	public void setTotdaechul(long totdaechul) {
		this.totdaechul = totdaechul;
	}
	public String getJj_bank_cd() {
		return jj_bank_cd;
	}
	public void setJj_bank_cd(String jj_bank_cd) {
		this.jj_bank_cd = jj_bank_cd;
	}
	public String getJj_gyejwa_no() {
		return jj_gyejwa_no;
	}
	public void setJj_gyejwa_no(String jj_gyejwa_no) {
		this.jj_gyejwa_no = jj_gyejwa_no;
	}
	public String getJj_s_ganung_gb() {
		return jj_s_ganung_gb;
	}
	public void setJj_s_ganung_gb(String jj_s_ganung_gb) {
		this.jj_s_ganung_gb = jj_s_ganung_gb;
	}
	public String getJikwonCK() {
		return jikwonCK;
	}
	public void setJikwonCK(String jikwonCK) {
		this.jikwonCK = jikwonCK;
	}
	public String getJj_bank_name() {
		return jj_bank_name;
	}
	public void setJj_bank_name(String jj_bank_name) {
		this.jj_bank_name = jj_bank_name;
	}
	public String getInternetYN() {
		return internetYN;
	}
	public void setInternetYN(String internetYN) {
		this.internetYN = internetYN;
	}
	public String getJj_ij_bank_cd() {
		return jj_ij_bank_cd;
	}
	public void setJj_ij_bank_cd(String jj_ij_bank_cd) {
		this.jj_ij_bank_cd = jj_ij_bank_cd;
	}
	public String getJj_ij_gyejwa_no() {
		return jj_ij_gyejwa_no;
	}
	public void setJj_ij_gyejwa_no(String jj_ij_gyejwa_no) {
		this.jj_ij_gyejwa_no = jj_ij_gyejwa_no;
	}
	public String getHj_ij_bank_nm() {
		return hj_ij_bank_nm;
	}
	public void setHj_ij_bank_nm(String hj_ij_bank_nm) {
		this.hj_ij_bank_nm = hj_ij_bank_nm;
	}
	public String getJJ_GYEJWA_YN_6011() {
		return JJ_GYEJWA_YN_6011;
	}
	public void setJJ_GYEJWA_YN_6011(String jJ_GYEJWA_YN_6011) {
		JJ_GYEJWA_YN_6011 = jJ_GYEJWA_YN_6011;
	}
	public String getFlag() {
		return flag;
	}
	public void setFlag(String flag) {
		this.flag = flag;
	}
	public boolean isTimeflag() {
		return timeflag;
	}
	public void setTimeflag(boolean timeflag) {
		this.timeflag = timeflag;
	}
	public String getYayak() {
		return Yayak;
	}
	public void setYayak(String yayak) {
		Yayak = yayak;
	}
	public String getEncrypted_amount() {
		return encrypted_amount;
	}
	public void setEncrypted_amount(String encrypted_amount) {
		this.encrypted_amount = encrypted_amount;
	}
	public String getEncrypted_note_url() {
		return encrypted_note_url;
	}
	public void setEncrypted_note_url(String encrypted_note_url) {
		this.encrypted_note_url = encrypted_note_url;
	}
	public String getEncrypted_home_url() {
		return encrypted_home_url;
	}
	public void setEncrypted_home_url(String encrypted_home_url) {
		this.encrypted_home_url = encrypted_home_url;
	}
	public String getEncrypted_oid() {
		return encrypted_oid;
	}
	public void setEncrypted_oid(String encrypted_oid) {
		this.encrypted_oid = encrypted_oid;
	}
	public String getM_mid() {
		return m_mid;
	}
	public void setM_mid(String m_mid) {
		this.m_mid = m_mid;
	}
	public String getHashdata() {
		return hashdata;
	}
	public void setHashdata(String hashdata) {
		this.hashdata = hashdata;
	}
	public int getNoData() {
		return noData;
	}
	public void setNoData(int noData) {
		this.noData = noData;
	}
	public boolean isMPhoneModifiedIn3Months() {
		return isMPhoneModifiedIn3Months;
	}
	public void setMPhoneModifiedIn3Months(boolean isMPhoneModifiedIn3Months) {
		this.isMPhoneModifiedIn3Months = isMPhoneModifiedIn3Months;
	}
	public int getMphone_chk() {
		return mphone_chk;
	}
	public void setMphone_chk(int mphone_chk) {
		this.mphone_chk = mphone_chk;
	}
	public String getEncodeData() {
		return EncodeData;
	}
	public void setEncodeData(String encodeData) {
		EncodeData = encodeData;
	}
	public String getDecodeData() {
		return DecodeData;
	}
	public void setDecodeData(String decodeData) {
		DecodeData = decodeData;
	}
	public String getMphone_changed_yn() {
		return mphone_changed_yn;
	}
	public void setMphone_changed_yn(String mphone_changed_yn) {
		this.mphone_changed_yn = mphone_changed_yn;
	}
	public String getPhoneCompany() {
		return phoneCompany;
	}
	public void setPhoneCompany(String phoneCompany) {
		this.phoneCompany = phoneCompany;
	}
	public String getPhoneNum() {
		return phoneNum;
	}
	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}
	public String getCertNum() {
		return certNum;
	}
	public void setCertNum(String certNum) {
		this.certNum = certNum;
	}
	public String getCheck_1() {
		return check_1;
	}
	public void setCheck_1(String check_1) {
		this.check_1 = check_1;
	}
	public String getCheck_2() {
		return check_2;
	}
	public void setCheck_2(String check_2) {
		this.check_2 = check_2;
	}
	public String getCheck_3() {
		return check_3;
	}
	public void setCheck_3(String check_3) {
		this.check_3 = check_3;
	}
	public String getCertMessage() {
		return certMessage;
	}
	public void setCertMessage(String certMessage) {
		this.certMessage = certMessage;
	}
	public String getSsnUserName() {
		return ssnUserName;
	}
	public void setSsnUserName(String ssnUserName) {
		this.ssnUserName = ssnUserName;
	}
	public String getMake_yymmdd() {
		return make_yymmdd;
	}
	public void setMake_yymmdd(String make_yymmdd) {
		this.make_yymmdd = make_yymmdd;
	}
	public String getMake_hour_min_sec() {
		return make_hour_min_sec;
	}
	public void setMake_hour_min_sec(String make_hour_min_sec) {
		this.make_hour_min_sec = make_hour_min_sec;
	}
	public String getJj_gyejwa_no_masking() {
		return jj_gyejwa_no_masking;
	}
	public void setJj_gyejwa_no_masking(String jj_gyejwa_no_masking) {
		this.jj_gyejwa_no_masking = jj_gyejwa_no_masking;
	}
	public String getJj_ij_gyejwa_no_masking() {
		return jj_ij_gyejwa_no_masking;
	}
	public void setJj_ij_gyejwa_no_masking(String jj_ij_gyejwa_no_masking) {
		this.jj_ij_gyejwa_no_masking = jj_ij_gyejwa_no_masking;
	}
	public long getLoanMoney() {
		return loanMoney;
	}
	public void setLoanMoney(long loanMoney) {
		this.loanMoney = loanMoney;
	}
	
	public String getIns_lcpl_dvcd() {
		return ins_lcpl_dvcd;
	}
	public void setIns_lcpl_dvcd(String ins_lcpl_dvcd) {
		this.ins_lcpl_dvcd = ins_lcpl_dvcd;
	}
	public String getPly_sqno() {
		return ply_sqno;
	}
	public void setPly_sqno(String ply_sqno) {
		this.ply_sqno = ply_sqno;
	}
	@Override
	public String toString() {
		return "LoInsuAppApplyVO [ssnUserJumin=" + ssnUserJumin
				+ ", ssnUserName=" + ssnUserName + ", ssnYakgwn=" + ssnYakgwn
				+ ", mode=" + mode + ", insub_pd_name=" + insub_pd_name
				+ ", stock_seq=" + stock_seq + ", ar_sttus_name="
				+ ar_sttus_name + ", re_stplt_loan_resid_amt="
				+ re_stplt_loan_resid_amt + ", int_pay_date=" + int_pay_date
				+ ", int_rate=" + int_rate + ", inet_loan_posbl_yn="
				+ inet_loan_posbl_yn + ", stplt_loan_posbl_amt="
				+ stplt_loan_posbl_amt + ", tot=" + tot + ", totdaechul="
				+ totdaechul + ", loanMoney=" + loanMoney
				+ ", jj_bank_cd="
				+ jj_bank_cd + ", jj_gyejwa_no=" + jj_gyejwa_no
				+ ", jj_gyejwa_no_masking=" + jj_gyejwa_no_masking
				+ ", jj_s_ganung_gb=" + jj_s_ganung_gb + ", jikwonCK="
				+ jikwonCK + ", jj_bank_name=" + jj_bank_name + ", internetYN="
				+ internetYN + ", jj_ij_bank_cd=" + jj_ij_bank_cd
				+ ", jj_ij_gyejwa_no=" + jj_ij_gyejwa_no
				+ ", jj_ij_gyejwa_no_masking=" + jj_ij_gyejwa_no_masking
				+ ", hj_ij_bank_nm=" + hj_ij_bank_nm + ", JJ_GYEJWA_YN_6011="
				+ JJ_GYEJWA_YN_6011 + ", flag=" + flag + ", timeflag="
				+ timeflag + ", Yayak=" + Yayak + ", encrypted_amount="
				+ encrypted_amount + ", encrypted_note_url="
				+ encrypted_note_url + ", encrypted_home_url="
				+ encrypted_home_url + ", encrypted_oid=" + encrypted_oid
				+ ", m_mid=" + m_mid + ", hashdata=" + hashdata + ", noData="
				+ noData + ", isMPhoneModifiedIn3Months="
				+ isMPhoneModifiedIn3Months + ", mphone_chk=" + mphone_chk
				+ ", EncodeData=" + EncodeData + ", DecodeData=" + DecodeData
				+ ", mphone_changed_yn=" + mphone_changed_yn
				+ ", phoneCompany=" + phoneCompany + ", phoneNum=" + phoneNum
				+ ", certNum=" + certNum + ", check_1=" + check_1
				+ ", check_2=" + check_2 + ", check_3=" + check_3
				+ ", certMessage=" + certMessage + ", make_yymmdd="
				+ make_yymmdd + ", make_hour_min_sec=" + make_hour_min_sec
				+ "]";
	}
	
}
