package com.idongbu.smartcustomer.vo;

//3차 전용 이자납입계좌변경VO
public class LoInsuAppAccountVO {
	private String selectedStock;	//변경하고자 하는 계약의 증권번호
	private String selectedStock_masking;	//변경하고자 하는 계약의 증권번호 마스킹
	private String HJ_ICHE;	//기존 계약의 이체일
	private String current_icheday;	//최종이자납입일
	private String next_icheday;	//다음 이체일
	private String setenable;	//몰랑
	private String JJ_DE_DATE;	//대출일자
	private String HJ_BANK;	//기존 - 은행명
	private String HJ_BANK_CD;	//기존 - 은행코드
	private String HJ_YEGMJU1;	//기존 - 예금주
	private String JJ_GYEJWA;	//기존 - 계좌번호
	private String HJ_BJ_NM;	//보종명
	
	private String sel_Option;	//구분값 (1:둘다변경, 2:납입계좌변경, 3:납입일변경)
	private String bank_name;//변경할 - 은행명
	private String bank_code;//변경할 - 은행코드
	private String bank_num;//변경할 - 은행계좌번호
	private String bank_num_masking;//변경할 - 은행계좌번호(마스킹처리)
	private String sel_icheday;//변경할 - 이체일(05,15,25 일)
	private String ins_lcpl_dvcd;//컨버전스
	private String ply_sqno;//컨버전스
	
	public String getSelectedStock() {
		return selectedStock;
	}
	public void setSelectedStock(String selectedStock) {
		this.selectedStock = selectedStock;
	}
	public String getHJ_ICHE() {
		return HJ_ICHE;
	}
	public void setHJ_ICHE(String hJ_ICHE) {
		HJ_ICHE = hJ_ICHE;
	}
	public String getCurrent_icheday() {
		return current_icheday;
	}
	public void setCurrent_icheday(String current_icheday) {
		this.current_icheday = current_icheday;
	}
	public String getNext_icheday() {
		return next_icheday;
	}
	public void setNext_icheday(String next_icheday) {
		this.next_icheday = next_icheday;
	}
	public String getSetenable() {
		return setenable;
	}
	public void setSetenable(String setenable) {
		this.setenable = setenable;
	}
	public String getJJ_DE_DATE() {
		return JJ_DE_DATE;
	}
	public void setJJ_DE_DATE(String jJ_DE_DATE) {
		JJ_DE_DATE = jJ_DE_DATE;
	}
	public String getHJ_BANK() {
		return HJ_BANK;
	}
	public void setHJ_BANK(String hJ_BANK) {
		HJ_BANK = hJ_BANK;
	}
	public String getHJ_YEGMJU1() {
		return HJ_YEGMJU1;
	}
	public void setHJ_YEGMJU1(String hJ_YEGMJU1) {
		HJ_YEGMJU1 = hJ_YEGMJU1;
	}
	public String getJJ_GYEJWA() {
		return JJ_GYEJWA;
	}
	public void setJJ_GYEJWA(String jJ_GYEJWA) {
		JJ_GYEJWA = jJ_GYEJWA;
	}
	public String getSel_Option() {
		return sel_Option;
	}
	public void setSel_Option(String sel_Option) {
		this.sel_Option = sel_Option;
	}
	public String getBank_name() {
		return bank_name;
	}
	public void setBank_name(String bank_name) {
		this.bank_name = bank_name;
	}
	public String getBank_code() {
		return bank_code;
	}
	public void setBank_code(String bank_code) {
		this.bank_code = bank_code;
	}
	public String getBank_num() {
		return bank_num;
	}
	public void setBank_num(String bank_num) {
		this.bank_num = bank_num;
	}
	public String getSel_icheday() {
		return sel_icheday;
	}
	public void setSel_icheday(String sel_icheday) {
		this.sel_icheday = sel_icheday;
	}
	
	public String getBank_num_masking() {
		return bank_num_masking;
	}
	public void setBank_num_masking(String bank_num_masking) {
		this.bank_num_masking = bank_num_masking;
	}
	public String getHJ_BJ_NM() {
		return HJ_BJ_NM;
	}
	public void setHJ_BJ_NM(String hJ_BJ_NM) {
		HJ_BJ_NM = hJ_BJ_NM;
	}
	public String getHJ_BANK_CD() {
		return HJ_BANK_CD;
	}
	public void setHJ_BANK_CD(String hJ_BANK_CD) {
		HJ_BANK_CD = hJ_BANK_CD;
	}
	public String getIns_lcpl_dvcd() {
		return ins_lcpl_dvcd;
	}
	public void setIns_lcpl_dvcd(String ins_lcpl_dvcd) {
		this.ins_lcpl_dvcd = ins_lcpl_dvcd;
	}
	public String getPly_sqno() {
		return ply_sqno;
	}
	public void setPly_sqno(String ply_sqno) {
		this.ply_sqno = ply_sqno;
	}
	@Override
	public String toString() {
		return "LoInsuAppAccountVO [selectedStock=" + selectedStock
				+ ", HJ_ICHE=" + HJ_ICHE + ", current_icheday="
				+ current_icheday + ", next_icheday=" + next_icheday
				+ ", setenable=" + setenable + ", JJ_DE_DATE=" + JJ_DE_DATE
				+ ", HJ_BANK=" + HJ_BANK + ", HJ_BANK_CD=" + HJ_BANK_CD
				+ ", HJ_YEGMJU1=" + HJ_YEGMJU1 + ", JJ_GYEJWA=" + JJ_GYEJWA
				+ ", HJ_BJ_NM=" + HJ_BJ_NM + ", sel_Option=" + sel_Option
				+ ", bank_name=" + bank_name + ", bank_code=" + bank_code
				+ ", bank_num=" + bank_num + ", bank_num_masking="
				+ ", ins_lcpl_dvcd=" + ins_lcpl_dvcd + ", ply_sqno="
				+ ply_sqno + ", sel_icheday=" + sel_icheday
				+ ", getSelectedStock()=" + getSelectedStock()
				+ ", getHJ_ICHE()=" + getHJ_ICHE() + ", getCurrent_icheday()="
				+ getCurrent_icheday() + ", getNext_icheday()="
				+ getNext_icheday() + ", getSetenable()=" + getSetenable()
				+ ", getJJ_DE_DATE()=" + getJJ_DE_DATE() + ", getHJ_BANK()="
				+ getHJ_BANK() + ", getHJ_YEGMJU1()=" + getHJ_YEGMJU1()
				+ ", getJJ_GYEJWA()=" + getJJ_GYEJWA() + ", getSel_Option()="
				+ getSel_Option() + ", getBank_name()=" + getBank_name()
				+ ", getBank_code()=" + getBank_code() + ", getBank_num()="
				+ getBank_num() + ", getSel_icheday()=" + getSel_icheday()
				+ ", getBank_num_masking()=" + getBank_num_masking()
				+ ", getHJ_BJ_NM()=" + getHJ_BJ_NM() + ", getHJ_BANK_CD()="
				+ getHJ_BANK_CD() + ", getClass()=" + getClass()
				+ ", hashCode()=" + hashCode() + ", toString()="
				+ super.toString() + "]";
	}
	public String getSelectedStock_masking() {
		return selectedStock_masking;
	}
	public void setSelectedStock_masking(String selectedStock_masking) {
		this.selectedStock_masking = selectedStock_masking;
	}
	
}
