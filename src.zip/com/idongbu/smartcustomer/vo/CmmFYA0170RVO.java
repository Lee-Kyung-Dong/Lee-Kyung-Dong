package com.idongbu.smartcustomer.vo;

import com.idongbu.common.vo.CMMVO;

//약관대출가능조회
public class CmmFYA0170RVO  extends CMMVO{
	
	public CmmFYA0170RVO() {
		super.setPGMID(proid);
		super.setTRID(trid);
	}
	
	private final static String proid		= "FYA0170R";
	private final static String trid		= "YAH0";
	
	private String rURL						= "";

	// 입력
	private String TERM_ID = null; // UNIQUE_KEY
	private String PATH = null; // 처리구분
	private String RE_BANK_CD = null; // 은행코드
	private String RE_GYEJWA_NO = null; // 계좌번호
	private String RE_GOGEK_NO = null; // 주민/사업자번호

	
	//2008.02.01 전금법관련 실시간출금전문 추가
	private String RE_UPMU_GUBUN      = null;	//업무구분(01:자동차, 02:장기, 03:일반, A1:약관대출, A2:일반대출, B1:기타출금)
	private String RE_NAPBUJA_CD      = null;	//납부자번호(장기는 증권번호, 자동차(분납:증권번호, 갱신:설계번호)
	private String RE_ASSIGN_GBN		 = null;	//등록여부(출력항목으로 입력값 없음)
	private String RE_RETURN_CD_AS	 = null;	//등록결과(출력항목으로 입력값 없음)


	// 출력
	private String BRIGHT_PROTECT = null;
	private String CHANNEL = null;
	private String COND_CODE = null;
	private String CUR_POS_INDEX = null;
	private String CUR_POS_MAP_ID = null;
	private String FUNCTION_KEY = null;
	private String H_MESSAGE_NM = null;
	private String H_RE_BANK_NM = null;
	private String H_RE_MESSAGE_NM = null;
	private String H_RE_YEGMJU_NM = null;
	private String JIBU_CODE = null;
	private String JIJUM_CODE = null;
	private String LOG_SOCKET_NO = null;
	private String NODE_NAME1 = null;
	private String NODE_NAME2 = null;
	private String NODE_NAME3 = null;
	private String NODE_NAME4 = null;
//	private String PATH = null;
	private String PGM_ID = null;
	private String PROTOCOL = null;
//	private String RE_BANK_CD = null;
	private String RE_DETAIL_DATA = null;
//	private String RE_GOGEK_NO = null;
//	private String RE_GYEJWA_NO = null;
	private String RE_KEY = null;
	private String RE_RETURN_CD = null;
	private String SE_DERR_FBRT_PGM = null;
	private String SE_DERR_FLD = null;
	private String SE_LAST_FLAG = null;
	private String SE_MSG_ID = null;
	private String SE_PROTECT_FLD = null;
	private String SE_PROTECT_PGM = null;
	private String SE_SM_CONTENTS = null;
	private String SE_SM_ID = null;
	private String SE_SM_LEVEL = null;
	private String SE_SM_PRC = null;
	private String SE_SM_RC = null;
	private String SE_SYS_MSG_ID = null;
	private String SOCKET_DATA = null;
	private String SSO_COMMON_DATA = null;
//	private String TERM_ID = null;
	private String TR_SOCKET_NO = null;
	private String USER_ID = null;
	private String USER_ID_1 = null;
	private String Length = null;
	private String RecordName = null;
	private String RecordShortDescription = null;
	private String Version = null;
	
	public String getrURL() {
		return rURL;
	}
	public void setrURL(String rURL) {
		this.rURL = rURL;
	}
	public String getTERM_ID() {
		return TERM_ID;
	}
	public void setTERM_ID(String tERM_ID) {
		TERM_ID = tERM_ID;
	}
	public String getPATH() {
		return PATH;
	}
	public void setPATH(String pATH) {
		PATH = pATH;
	}
	public String getRE_BANK_CD() {
		return RE_BANK_CD;
	}
	public void setRE_BANK_CD(String rE_BANK_CD) {
		RE_BANK_CD = rE_BANK_CD;
	}
	public String getRE_GYEJWA_NO() {
		return RE_GYEJWA_NO;
	}
	public void setRE_GYEJWA_NO(String rE_GYEJWA_NO) {
		RE_GYEJWA_NO = rE_GYEJWA_NO;
	}
	public String getRE_GOGEK_NO() {
		return RE_GOGEK_NO;
	}
	public void setRE_GOGEK_NO(String rE_GOGEK_NO) {
		RE_GOGEK_NO = rE_GOGEK_NO;
	}
	public String getRE_UPMU_GUBUN() {
		return RE_UPMU_GUBUN;
	}
	public void setRE_UPMU_GUBUN(String rE_UPMU_GUBUN) {
		RE_UPMU_GUBUN = rE_UPMU_GUBUN;
	}
	public String getRE_NAPBUJA_CD() {
		return RE_NAPBUJA_CD;
	}
	public void setRE_NAPBUJA_CD(String rE_NAPBUJA_CD) {
		RE_NAPBUJA_CD = rE_NAPBUJA_CD;
	}
	public String getRE_ASSIGN_GBN() {
		return RE_ASSIGN_GBN;
	}
	public void setRE_ASSIGN_GBN(String rE_ASSIGN_GBN) {
		RE_ASSIGN_GBN = rE_ASSIGN_GBN;
	}
	public String getRE_RETURN_CD_AS() {
		return RE_RETURN_CD_AS;
	}
	public void setRE_RETURN_CD_AS(String rE_RETURN_CD_AS) {
		RE_RETURN_CD_AS = rE_RETURN_CD_AS;
	}
	public String getBRIGHT_PROTECT() {
		return BRIGHT_PROTECT;
	}
	public void setBRIGHT_PROTECT(String bRIGHT_PROTECT) {
		BRIGHT_PROTECT = bRIGHT_PROTECT;
	}
	public String getCHANNEL() {
		return CHANNEL;
	}
	public void setCHANNEL(String cHANNEL) {
		CHANNEL = cHANNEL;
	}
	public String getCOND_CODE() {
		return COND_CODE;
	}
	public void setCOND_CODE(String cOND_CODE) {
		COND_CODE = cOND_CODE;
	}
	public String getCUR_POS_INDEX() {
		return CUR_POS_INDEX;
	}
	public void setCUR_POS_INDEX(String cUR_POS_INDEX) {
		CUR_POS_INDEX = cUR_POS_INDEX;
	}
	public String getCUR_POS_MAP_ID() {
		return CUR_POS_MAP_ID;
	}
	public void setCUR_POS_MAP_ID(String cUR_POS_MAP_ID) {
		CUR_POS_MAP_ID = cUR_POS_MAP_ID;
	}
	public String getFUNCTION_KEY() {
		return FUNCTION_KEY;
	}
	public void setFUNCTION_KEY(String fUNCTION_KEY) {
		FUNCTION_KEY = fUNCTION_KEY;
	}
	public String getH_MESSAGE_NM() {
		return H_MESSAGE_NM;
	}
	public void setH_MESSAGE_NM(String h_MESSAGE_NM) {
		H_MESSAGE_NM = h_MESSAGE_NM;
	}
	public String getH_RE_BANK_NM() {
		return H_RE_BANK_NM;
	}
	public void setH_RE_BANK_NM(String h_RE_BANK_NM) {
		H_RE_BANK_NM = h_RE_BANK_NM;
	}
	public String getH_RE_MESSAGE_NM() {
		return H_RE_MESSAGE_NM;
	}
	public void setH_RE_MESSAGE_NM(String h_RE_MESSAGE_NM) {
		H_RE_MESSAGE_NM = h_RE_MESSAGE_NM;
	}
	public String getH_RE_YEGMJU_NM() {
		return H_RE_YEGMJU_NM;
	}
	public void setH_RE_YEGMJU_NM(String h_RE_YEGMJU_NM) {
		H_RE_YEGMJU_NM = h_RE_YEGMJU_NM;
	}
	public String getJIBU_CODE() {
		return JIBU_CODE;
	}
	public void setJIBU_CODE(String jIBU_CODE) {
		JIBU_CODE = jIBU_CODE;
	}
	public String getJIJUM_CODE() {
		return JIJUM_CODE;
	}
	public void setJIJUM_CODE(String jIJUM_CODE) {
		JIJUM_CODE = jIJUM_CODE;
	}
	public String getLOG_SOCKET_NO() {
		return LOG_SOCKET_NO;
	}
	public void setLOG_SOCKET_NO(String lOG_SOCKET_NO) {
		LOG_SOCKET_NO = lOG_SOCKET_NO;
	}
	public String getNODE_NAME1() {
		return NODE_NAME1;
	}
	public void setNODE_NAME1(String nODE_NAME1) {
		NODE_NAME1 = nODE_NAME1;
	}
	public String getNODE_NAME2() {
		return NODE_NAME2;
	}
	public void setNODE_NAME2(String nODE_NAME2) {
		NODE_NAME2 = nODE_NAME2;
	}
	public String getNODE_NAME3() {
		return NODE_NAME3;
	}
	public void setNODE_NAME3(String nODE_NAME3) {
		NODE_NAME3 = nODE_NAME3;
	}
	public String getNODE_NAME4() {
		return NODE_NAME4;
	}
	public void setNODE_NAME4(String nODE_NAME4) {
		NODE_NAME4 = nODE_NAME4;
	}
	public String getPGM_ID() {
		return PGM_ID;
	}
	public void setPGM_ID(String pGM_ID) {
		PGM_ID = pGM_ID;
	}
	public String getPROTOCOL() {
		return PROTOCOL;
	}
	public void setPROTOCOL(String pROTOCOL) {
		PROTOCOL = pROTOCOL;
	}
	public String getRE_DETAIL_DATA() {
		return RE_DETAIL_DATA;
	}
	public void setRE_DETAIL_DATA(String rE_DETAIL_DATA) {
		RE_DETAIL_DATA = rE_DETAIL_DATA;
	}
	public String getRE_KEY() {
		return RE_KEY;
	}
	public void setRE_KEY(String rE_KEY) {
		RE_KEY = rE_KEY;
	}
	public String getRE_RETURN_CD() {
		return RE_RETURN_CD;
	}
	public void setRE_RETURN_CD(String rE_RETURN_CD) {
		RE_RETURN_CD = rE_RETURN_CD;
	}
	public String getSE_DERR_FBRT_PGM() {
		return SE_DERR_FBRT_PGM;
	}
	public void setSE_DERR_FBRT_PGM(String sE_DERR_FBRT_PGM) {
		SE_DERR_FBRT_PGM = sE_DERR_FBRT_PGM;
	}
	public String getSE_DERR_FLD() {
		return SE_DERR_FLD;
	}
	public void setSE_DERR_FLD(String sE_DERR_FLD) {
		SE_DERR_FLD = sE_DERR_FLD;
	}
	public String getSE_LAST_FLAG() {
		return SE_LAST_FLAG;
	}
	public void setSE_LAST_FLAG(String sE_LAST_FLAG) {
		SE_LAST_FLAG = sE_LAST_FLAG;
	}
	public String getSE_MSG_ID() {
		return SE_MSG_ID;
	}
	public void setSE_MSG_ID(String sE_MSG_ID) {
		SE_MSG_ID = sE_MSG_ID;
	}
	public String getSE_PROTECT_FLD() {
		return SE_PROTECT_FLD;
	}
	public void setSE_PROTECT_FLD(String sE_PROTECT_FLD) {
		SE_PROTECT_FLD = sE_PROTECT_FLD;
	}
	public String getSE_PROTECT_PGM() {
		return SE_PROTECT_PGM;
	}
	public void setSE_PROTECT_PGM(String sE_PROTECT_PGM) {
		SE_PROTECT_PGM = sE_PROTECT_PGM;
	}
	public String getSE_SM_CONTENTS() {
		return SE_SM_CONTENTS;
	}
	public void setSE_SM_CONTENTS(String sE_SM_CONTENTS) {
		SE_SM_CONTENTS = sE_SM_CONTENTS;
	}
	public String getSE_SM_ID() {
		return SE_SM_ID;
	}
	public void setSE_SM_ID(String sE_SM_ID) {
		SE_SM_ID = sE_SM_ID;
	}
	public String getSE_SM_LEVEL() {
		return SE_SM_LEVEL;
	}
	public void setSE_SM_LEVEL(String sE_SM_LEVEL) {
		SE_SM_LEVEL = sE_SM_LEVEL;
	}
	public String getSE_SM_PRC() {
		return SE_SM_PRC;
	}
	public void setSE_SM_PRC(String sE_SM_PRC) {
		SE_SM_PRC = sE_SM_PRC;
	}
	public String getSE_SM_RC() {
		return SE_SM_RC;
	}
	public void setSE_SM_RC(String sE_SM_RC) {
		SE_SM_RC = sE_SM_RC;
	}
	public String getSE_SYS_MSG_ID() {
		return SE_SYS_MSG_ID;
	}
	public void setSE_SYS_MSG_ID(String sE_SYS_MSG_ID) {
		SE_SYS_MSG_ID = sE_SYS_MSG_ID;
	}
	public String getSOCKET_DATA() {
		return SOCKET_DATA;
	}
	public void setSOCKET_DATA(String sOCKET_DATA) {
		SOCKET_DATA = sOCKET_DATA;
	}
	public String getSSO_COMMON_DATA() {
		return SSO_COMMON_DATA;
	}
	public void setSSO_COMMON_DATA(String sSO_COMMON_DATA) {
		SSO_COMMON_DATA = sSO_COMMON_DATA;
	}
	public String getTR_SOCKET_NO() {
		return TR_SOCKET_NO;
	}
	public void setTR_SOCKET_NO(String tR_SOCKET_NO) {
		TR_SOCKET_NO = tR_SOCKET_NO;
	}
	public String getUSER_ID() {
		return USER_ID;
	}
	public void setUSER_ID(String uSER_ID) {
		USER_ID = uSER_ID;
	}
	public String getUSER_ID_1() {
		return USER_ID_1;
	}
	public void setUSER_ID_1(String uSER_ID_1) {
		USER_ID_1 = uSER_ID_1;
	}
	public String getLength() {
		return Length;
	}
	public void setLength(String length) {
		Length = length;
	}
	public String getRecordName() {
		return RecordName;
	}
	public void setRecordName(String recordName) {
		RecordName = recordName;
	}
	public String getRecordShortDescription() {
		return RecordShortDescription;
	}
	public void setRecordShortDescription(String recordShortDescription) {
		RecordShortDescription = recordShortDescription;
	}
	public String getVersion() {
		return Version;
	}
	public void setVersion(String version) {
		Version = version;
	}
	public String getProid() {
		return proid;
	}
	public String getTrid() {
		return trid;
	}
	
}