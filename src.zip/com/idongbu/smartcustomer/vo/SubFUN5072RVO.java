package com.idongbu.smartcustomer.vo;

public class SubFUN5072RVO {
	public String JJ_PI_POLI_NO 		= null;
	public String HJ_PI_GWANGE 			= null;
	public String HJ_PI_NAME 			= null;
	public String JJ_PI_JUMIN 			= null;
	public String JJ_PI_SANGTE_YMD 		= null;
	public String JJ_PI_BOJANG_PRM 		= null;
	public String HJ_PI_SANGTE 			= null;
	public String JJ_PI_SANGTE 			= null;
	public String JJ_CAR_POLI_NO 		= null;
	public String HJ_CAR_GWANGE 		= null;
	public String HJ_CAR_NO 			= null;
	public String JJ_CAR_JUMIN 			= null;
	public String JJ_CAR_SANGTE_YMD 	= null;
	public String JJ_CAR_TOTAL_PRM 		= null;
	public String getJJ_PI_POLI_NO() {
		return JJ_PI_POLI_NO;
	}
	public void setJJ_PI_POLI_NO(String jJ_PI_POLI_NO) {
		JJ_PI_POLI_NO = jJ_PI_POLI_NO;
	}
	public String getHJ_PI_GWANGE() {
		return HJ_PI_GWANGE;
	}
	public void setHJ_PI_GWANGE(String hJ_PI_GWANGE) {
		HJ_PI_GWANGE = hJ_PI_GWANGE;
	}
	public String getHJ_PI_NAME() {
		return HJ_PI_NAME;
	}
	public void setHJ_PI_NAME(String hJ_PI_NAME) {
		HJ_PI_NAME = hJ_PI_NAME;
	}
	public String getJJ_PI_JUMIN() {
		return JJ_PI_JUMIN;
	}
	public void setJJ_PI_JUMIN(String jJ_PI_JUMIN) {
		JJ_PI_JUMIN = jJ_PI_JUMIN;
	}
	public String getJJ_PI_SANGTE_YMD() {
		return JJ_PI_SANGTE_YMD;
	}
	public void setJJ_PI_SANGTE_YMD(String jJ_PI_SANGTE_YMD) {
		JJ_PI_SANGTE_YMD = jJ_PI_SANGTE_YMD;
	}
	public String getJJ_PI_BOJANG_PRM() {
		return JJ_PI_BOJANG_PRM;
	}
	public void setJJ_PI_BOJANG_PRM(String jJ_PI_BOJANG_PRM) {
		JJ_PI_BOJANG_PRM = jJ_PI_BOJANG_PRM;
	}
	public String getHJ_PI_SANGTE() {
		return HJ_PI_SANGTE;
	}
	public void setHJ_PI_SANGTE(String hJ_PI_SANGTE) {
		HJ_PI_SANGTE = hJ_PI_SANGTE;
	}
	public String getJJ_PI_SANGTE() {
		return JJ_PI_SANGTE;
	}
	public void setJJ_PI_SANGTE(String jJ_PI_SANGTE) {
		JJ_PI_SANGTE = jJ_PI_SANGTE;
	}
	public String getJJ_CAR_POLI_NO() {
		return JJ_CAR_POLI_NO;
	}
	public void setJJ_CAR_POLI_NO(String jJ_CAR_POLI_NO) {
		JJ_CAR_POLI_NO = jJ_CAR_POLI_NO;
	}
	public String getHJ_CAR_GWANGE() {
		return HJ_CAR_GWANGE;
	}
	public void setHJ_CAR_GWANGE(String hJ_CAR_GWANGE) {
		HJ_CAR_GWANGE = hJ_CAR_GWANGE;
	}
	public String getHJ_CAR_NO() {
		return HJ_CAR_NO;
	}
	public void setHJ_CAR_NO(String hJ_CAR_NO) {
		HJ_CAR_NO = hJ_CAR_NO;
	}
	public String getJJ_CAR_JUMIN() {
		return JJ_CAR_JUMIN;
	}
	public void setJJ_CAR_JUMIN(String jJ_CAR_JUMIN) {
		JJ_CAR_JUMIN = jJ_CAR_JUMIN;
	}
	public String getJJ_CAR_SANGTE_YMD() {
		return JJ_CAR_SANGTE_YMD;
	}
	public void setJJ_CAR_SANGTE_YMD(String jJ_CAR_SANGTE_YMD) {
		JJ_CAR_SANGTE_YMD = jJ_CAR_SANGTE_YMD;
	}
	public String getJJ_CAR_TOTAL_PRM() {
		return JJ_CAR_TOTAL_PRM;
	}
	public void setJJ_CAR_TOTAL_PRM(String jJ_CAR_TOTAL_PRM) {
		JJ_CAR_TOTAL_PRM = jJ_CAR_TOTAL_PRM;
	}

}
