package com.idongbu.smartcustomer.vo;

import com.idongbu.common.vo.CMMVO;

// 계약조회
public class LbsSubmitVO extends CMMVO {
	private String i_Jubsu_No                  = null;
	private String i_Jubsu_Date                = null;
	private String i_Ch_Jeopsu_Cd              = null;
	private String i_Sos_Gb                    = null;
	private String i_Car_No                    = null;
	private String i_Jumin_No                  = null;
	private String i_Poli_No                   = null;
	private String i_Chamyeong                 = null;
	private String i_Yochungja                 = null;
	private String i_Yochungja_Rel             = null;
	private String i_Yochungja1_Area           = null;
	private String i_Yochungja1_Guk            = null;
	private String i_Yochungja1_Ph             = null;
	private String i_Yochung_Cd                = null;
	private String i_Yochung_Note              = null;
	private String i_Youngsu_Yn                = null;
	private String i_Pibo_Nm                   = null;
	private String i_Pibo_Cd                   = null;
	private String i_Bj_Cd                     = null;
	private String i_Bj_Nm                     = null;
	private String i_Chajong_Cd                = null;
	private String i_Chajong_Nm                = null;
	private String i_Car_Cd                    = null;
	private String i_Car_Name                  = null;
	private String i_Suhae_Yn                  = null;
	private String i_Tkyak_Cnt                 = null;
	private String i_Tkyak_Gaip_Cnt            = null;
	private String i_Dangi_Gb                  = null;
	private String i_Tkyak_Cd                  = null;
	private String i_Tkyak_Nm                  = null;
	private String i_Gojang_Yn                 = null;
	private String i_Recall_Cnt                = null;
	private String i_Service_Cnt               = null;
	private String i_Jegong_Cnt                = null;
	private String i_Chigpja_Cd                = null;
	private String i_Alt_Rel_Cd                = null;
	private String i_Unban_Yn                  = null;
	private String i_Tekbe_Yn                  = null;
	private String i_Dapyop_G_No               = null;
	private String i_Bh_S_Ymd                  = null;
	private String i_Bh_E_Ymd                  = null;
	private String i_Dbrt_Gb                   = null;
	private String i_Svc_Cnt                   = null;
	private String i_Begiryang                 = null;
	private String i_Jukje_Ton                 = null;
	private String i_Jungwon_Cnt               = null;
	private String i_T_Svc_Cnt                 = null;
	private String i_Jadong_Gs_Cd              = null;
	private String i_Abs_Gb                    = null;
	private String i_Auto_Gb                   = null;
	private String i_Uj_Tkyak                  = null;
	private String i_Uj_Name                   = null;
	private String i_Uj_Jumin_No               = null;
	private String i_Uj_Yunryung               = null;
	private String i_Uj_Gwange_Cd              = null;
	private String i_Uj_Gwange                 = null;
	private String i_Pos_Yn                    = null;
	private String i_Electric_Gb               = null;
	private String i_Chulryukryang             = null;
	private String i_Chury_Endcd               = null;
	private String i_Chury_Cd                  = null;
	private String i_Mileage_Yn                = null;
	private String i_Mileage_Sms_Yn            = null;
	private String i_Yochung_Area_Gb           = null;
	private String i_Yochung_Area_Zip          = null;
	private String i_Yochung_Area_Addr         = null;
	private String i_Yochung_Area_Gita         = null;
	private String i_Co_Cd                     = null;
	private String i_Co_Tel_Nm                 = null;
	private String i_Co_Tel_Date               = null;
	private String i_Co_Tel_Jubsuja            = null;
	private String i_Sms_Yn                    = null;
	private String i_Chury_Ch_Cd               = null;
	private String i_Chuldong_Nm               = null;
	private String i_Chuldong_Area             = null;
	private String i_Chuldong_Guk              = null;
	private String i_Chuldong_Ph               = null;
	private String i_Chuldong_Yn               = null;
	private String i_Chuldong_Sms_Date         = null;
	private String i_Dc_Type_Cd                = null;
	private String i_Dc_Type_Sub_Cd            = null;
	private String i_Dc_Type_Cont              = null;
	private String i_Pm_Type                   = null;
	private String i_Pm_Type_Sebu              = null;
	private String i_Pm_Km                     = null;
	private String i_Danga_Gb                  = null;
	private String i_Yochung_Juso_Gb           = null;
	private String i_Drive_Km                  = null;
	private String i_Drive_Ymd                 = null;
	private String i_Photo_Yn                  = null;
	private String i_Sos_Gubsu                 = null;
	private String i_Sms_Gogek_Yn              = null;
	private String i_Sms_Gogek_Ymdhms          = null;
	private String i_Err                       = null;
	
	public String getI_Jubsu_No() {
		return i_Jubsu_No;
	}
	public void setI_Jubsu_No(String i_Jubsu_No) {
		this.i_Jubsu_No = i_Jubsu_No;
	}
	public String getI_Jubsu_Date() {
		return i_Jubsu_Date;
	}
	public void setI_Jubsu_Date(String i_Jubsu_Date) {
		this.i_Jubsu_Date = i_Jubsu_Date;
	}
	public String getI_Ch_Jeopsu_Cd() {
		return i_Ch_Jeopsu_Cd;
	}
	public void setI_Ch_Jeopsu_Cd(String i_Ch_Jeopsu_Cd) {
		this.i_Ch_Jeopsu_Cd = i_Ch_Jeopsu_Cd;
	}
	public String getI_Sos_Gb() {
		return i_Sos_Gb;
	}
	public void setI_Sos_Gb(String i_Sos_Gb) {
		this.i_Sos_Gb = i_Sos_Gb;
	}
	public String getI_Car_No() {
		return i_Car_No;
	}
	public void setI_Car_No(String i_Car_No) {
		this.i_Car_No = i_Car_No;
	}
	public String getI_Jumin_No() {
		return i_Jumin_No;
	}
	public void setI_Jumin_No(String i_Jumin_No) {
		this.i_Jumin_No = i_Jumin_No;
	}
	public String getI_Poli_No() {
		return i_Poli_No;
	}
	public void setI_Poli_No(String i_Poli_No) {
		this.i_Poli_No = i_Poli_No;
	}
	public String getI_Chamyeong() {
		return i_Chamyeong;
	}
	public void setI_Chamyeong(String i_Chamyeong) {
		this.i_Chamyeong = i_Chamyeong;
	}
	public String getI_Yochungja() {
		return i_Yochungja;
	}
	public void setI_Yochungja(String i_Yochungja) {
		this.i_Yochungja = i_Yochungja;
	}
	public String getI_Yochungja_Rel() {
		return i_Yochungja_Rel;
	}
	public void setI_Yochungja_Rel(String i_Yochungja_Rel) {
		this.i_Yochungja_Rel = i_Yochungja_Rel;
	}
	public String getI_Yochungja1_Area() {
		return i_Yochungja1_Area;
	}
	public void setI_Yochungja1_Area(String i_Yochungja1_Area) {
		this.i_Yochungja1_Area = i_Yochungja1_Area;
	}
	public String getI_Yochungja1_Guk() {
		return i_Yochungja1_Guk;
	}
	public void setI_Yochungja1_Guk(String i_Yochungja1_Guk) {
		this.i_Yochungja1_Guk = i_Yochungja1_Guk;
	}
	public String getI_Yochungja1_Ph() {
		return i_Yochungja1_Ph;
	}
	public void setI_Yochungja1_Ph(String i_Yochungja1_Ph) {
		this.i_Yochungja1_Ph = i_Yochungja1_Ph;
	}
	public String getI_Yochung_Cd() {
		return i_Yochung_Cd;
	}
	public void setI_Yochung_Cd(String i_Yochung_Cd) {
		this.i_Yochung_Cd = i_Yochung_Cd;
	}
	public String getI_Yochung_Note() {
		return i_Yochung_Note;
	}
	public void setI_Yochung_Note(String i_Yochung_Note) {
		this.i_Yochung_Note = i_Yochung_Note;
	}
	public String getI_Youngsu_Yn() {
		return i_Youngsu_Yn;
	}
	public void setI_Youngsu_Yn(String i_Youngsu_Yn) {
		this.i_Youngsu_Yn = i_Youngsu_Yn;
	}
	public String getI_Pibo_Nm() {
		return i_Pibo_Nm;
	}
	public void setI_Pibo_Nm(String i_Pibo_Nm) {
		this.i_Pibo_Nm = i_Pibo_Nm;
	}
	public String getI_Pibo_Cd() {
		return i_Pibo_Cd;
	}
	public void setI_Pibo_Cd(String i_Pibo_Cd) {
		this.i_Pibo_Cd = i_Pibo_Cd;
	}
	public String getI_Bj_Cd() {
		return i_Bj_Cd;
	}
	public void setI_Bj_Cd(String i_Bj_Cd) {
		this.i_Bj_Cd = i_Bj_Cd;
	}
	public String getI_Bj_Nm() {
		return i_Bj_Nm;
	}
	public void setI_Bj_Nm(String i_Bj_Nm) {
		this.i_Bj_Nm = i_Bj_Nm;
	}
	public String getI_Chajong_Cd() {
		return i_Chajong_Cd;
	}
	public void setI_Chajong_Cd(String i_Chajong_Cd) {
		this.i_Chajong_Cd = i_Chajong_Cd;
	}
	public String getI_Chajong_Nm() {
		return i_Chajong_Nm;
	}
	public void setI_Chajong_Nm(String i_Chajong_Nm) {
		this.i_Chajong_Nm = i_Chajong_Nm;
	}
	public String getI_Car_Cd() {
		return i_Car_Cd;
	}
	public void setI_Car_Cd(String i_Car_Cd) {
		this.i_Car_Cd = i_Car_Cd;
	}
	public String getI_Car_Name() {
		return i_Car_Name;
	}
	public void setI_Car_Name(String i_Car_Name) {
		this.i_Car_Name = i_Car_Name;
	}
	public String getI_Suhae_Yn() {
		return i_Suhae_Yn;
	}
	public void setI_Suhae_Yn(String i_Suhae_Yn) {
		this.i_Suhae_Yn = i_Suhae_Yn;
	}
	public String getI_Tkyak_Cnt() {
		return i_Tkyak_Cnt;
	}
	public void setI_Tkyak_Cnt(String i_Tkyak_Cnt) {
		this.i_Tkyak_Cnt = i_Tkyak_Cnt;
	}
	public String getI_Tkyak_Gaip_Cnt() {
		return i_Tkyak_Gaip_Cnt;
	}
	public void setI_Tkyak_Gaip_Cnt(String i_Tkyak_Gaip_Cnt) {
		this.i_Tkyak_Gaip_Cnt = i_Tkyak_Gaip_Cnt;
	}
	public String getI_Dangi_Gb() {
		return i_Dangi_Gb;
	}
	public void setI_Dangi_Gb(String i_Dangi_Gb) {
		this.i_Dangi_Gb = i_Dangi_Gb;
	}
	public String getI_Tkyak_Cd() {
		return i_Tkyak_Cd;
	}
	public void setI_Tkyak_Cd(String i_Tkyak_Cd) {
		this.i_Tkyak_Cd = i_Tkyak_Cd;
	}
	public String getI_Tkyak_Nm() {
		return i_Tkyak_Nm;
	}
	public void setI_Tkyak_Nm(String i_Tkyak_Nm) {
		this.i_Tkyak_Nm = i_Tkyak_Nm;
	}
	public String getI_Gojang_Yn() {
		return i_Gojang_Yn;
	}
	public void setI_Gojang_Yn(String i_Gojang_Yn) {
		this.i_Gojang_Yn = i_Gojang_Yn;
	}
	public String getI_Recall_Cnt() {
		return i_Recall_Cnt;
	}
	public void setI_Recall_Cnt(String i_Recall_Cnt) {
		this.i_Recall_Cnt = i_Recall_Cnt;
	}
	public String getI_Service_Cnt() {
		return i_Service_Cnt;
	}
	public void setI_Service_Cnt(String i_Service_Cnt) {
		this.i_Service_Cnt = i_Service_Cnt;
	}
	public String getI_Jegong_Cnt() {
		return i_Jegong_Cnt;
	}
	public void setI_Jegong_Cnt(String i_Jegong_Cnt) {
		this.i_Jegong_Cnt = i_Jegong_Cnt;
	}
	public String getI_Chigpja_Cd() {
		return i_Chigpja_Cd;
	}
	public void setI_Chigpja_Cd(String i_Chigpja_Cd) {
		this.i_Chigpja_Cd = i_Chigpja_Cd;
	}
	public String getI_Alt_Rel_Cd() {
		return i_Alt_Rel_Cd;
	}
	public void setI_Alt_Rel_Cd(String i_Alt_Rel_Cd) {
		this.i_Alt_Rel_Cd = i_Alt_Rel_Cd;
	}
	public String getI_Unban_Yn() {
		return i_Unban_Yn;
	}
	public void setI_Unban_Yn(String i_Unban_Yn) {
		this.i_Unban_Yn = i_Unban_Yn;
	}
	public String getI_Tekbe_Yn() {
		return i_Tekbe_Yn;
	}
	public void setI_Tekbe_Yn(String i_Tekbe_Yn) {
		this.i_Tekbe_Yn = i_Tekbe_Yn;
	}
	public String getI_Dapyop_G_No() {
		return i_Dapyop_G_No;
	}
	public void setI_Dapyop_G_No(String i_Dapyop_G_No) {
		this.i_Dapyop_G_No = i_Dapyop_G_No;
	}
	public String getI_Bh_S_Ymd() {
		return i_Bh_S_Ymd;
	}
	public void setI_Bh_S_Ymd(String i_Bh_S_Ymd) {
		this.i_Bh_S_Ymd = i_Bh_S_Ymd;
	}
	public String getI_Bh_E_Ymd() {
		return i_Bh_E_Ymd;
	}
	public void setI_Bh_E_Ymd(String i_Bh_E_Ymd) {
		this.i_Bh_E_Ymd = i_Bh_E_Ymd;
	}
	public String getI_Dbrt_Gb() {
		return i_Dbrt_Gb;
	}
	public void setI_Dbrt_Gb(String i_Dbrt_Gb) {
		this.i_Dbrt_Gb = i_Dbrt_Gb;
	}
	public String getI_Svc_Cnt() {
		return i_Svc_Cnt;
	}
	public void setI_Svc_Cnt(String i_Svc_Cnt) {
		this.i_Svc_Cnt = i_Svc_Cnt;
	}
	public String getI_Begiryang() {
		return i_Begiryang;
	}
	public void setI_Begiryang(String i_Begiryang) {
		this.i_Begiryang = i_Begiryang;
	}
	public String getI_Jukje_Ton() {
		return i_Jukje_Ton;
	}
	public void setI_Jukje_Ton(String i_Jukje_Ton) {
		this.i_Jukje_Ton = i_Jukje_Ton;
	}
	public String getI_Jungwon_Cnt() {
		return i_Jungwon_Cnt;
	}
	public void setI_Jungwon_Cnt(String i_Jungwon_Cnt) {
		this.i_Jungwon_Cnt = i_Jungwon_Cnt;
	}
	public String getI_T_Svc_Cnt() {
		return i_T_Svc_Cnt;
	}
	public void setI_T_Svc_Cnt(String i_T_Svc_Cnt) {
		this.i_T_Svc_Cnt = i_T_Svc_Cnt;
	}
	public String getI_Jadong_Gs_Cd() {
		return i_Jadong_Gs_Cd;
	}
	public void setI_Jadong_Gs_Cd(String i_Jadong_Gs_Cd) {
		this.i_Jadong_Gs_Cd = i_Jadong_Gs_Cd;
	}
	public String getI_Abs_Gb() {
		return i_Abs_Gb;
	}
	public void setI_Abs_Gb(String i_Abs_Gb) {
		this.i_Abs_Gb = i_Abs_Gb;
	}
	public String getI_Auto_Gb() {
		return i_Auto_Gb;
	}
	public void setI_Auto_Gb(String i_Auto_Gb) {
		this.i_Auto_Gb = i_Auto_Gb;
	}
	public String getI_Uj_Tkyak() {
		return i_Uj_Tkyak;
	}
	public void setI_Uj_Tkyak(String i_Uj_Tkyak) {
		this.i_Uj_Tkyak = i_Uj_Tkyak;
	}
	public String getI_Uj_Name() {
		return i_Uj_Name;
	}
	public void setI_Uj_Name(String i_Uj_Name) {
		this.i_Uj_Name = i_Uj_Name;
	}
	public String getI_Uj_Jumin_No() {
		return i_Uj_Jumin_No;
	}
	public void setI_Uj_Jumin_No(String i_Uj_Jumin_No) {
		this.i_Uj_Jumin_No = i_Uj_Jumin_No;
	}
	public String getI_Uj_Yunryung() {
		return i_Uj_Yunryung;
	}
	public void setI_Uj_Yunryung(String i_Uj_Yunryung) {
		this.i_Uj_Yunryung = i_Uj_Yunryung;
	}
	public String getI_Uj_Gwange_Cd() {
		return i_Uj_Gwange_Cd;
	}
	public void setI_Uj_Gwange_Cd(String i_Uj_Gwange_Cd) {
		this.i_Uj_Gwange_Cd = i_Uj_Gwange_Cd;
	}
	public String getI_Uj_Gwange() {
		return i_Uj_Gwange;
	}
	public void setI_Uj_Gwange(String i_Uj_Gwange) {
		this.i_Uj_Gwange = i_Uj_Gwange;
	}
	public String getI_Pos_Yn() {
		return i_Pos_Yn;
	}
	public void setI_Pos_Yn(String i_Pos_Yn) {
		this.i_Pos_Yn = i_Pos_Yn;
	}
	public String getI_Electric_Gb() {
		return i_Electric_Gb;
	}
	public void setI_Electric_Gb(String i_Electric_Gb) {
		this.i_Electric_Gb = i_Electric_Gb;
	}
	public String getI_Chulryukryang() {
		return i_Chulryukryang;
	}
	public void setI_Chulryukryang(String i_Chulryukryang) {
		this.i_Chulryukryang = i_Chulryukryang;
	}
	public String getI_Chury_Endcd() {
		return i_Chury_Endcd;
	}
	public void setI_Chury_Endcd(String i_Chury_Endcd) {
		this.i_Chury_Endcd = i_Chury_Endcd;
	}
	public String getI_Chury_Cd() {
		return i_Chury_Cd;
	}
	public void setI_Chury_Cd(String i_Chury_Cd) {
		this.i_Chury_Cd = i_Chury_Cd;
	}
	public String getI_Mileage_Yn() {
		return i_Mileage_Yn;
	}
	public void setI_Mileage_Yn(String i_Mileage_Yn) {
		this.i_Mileage_Yn = i_Mileage_Yn;
	}
	public String getI_Mileage_Sms_Yn() {
		return i_Mileage_Sms_Yn;
	}
	public void setI_Mileage_Sms_Yn(String i_Mileage_Sms_Yn) {
		this.i_Mileage_Sms_Yn = i_Mileage_Sms_Yn;
	}
	public String getI_Yochung_Area_Gb() {
		return i_Yochung_Area_Gb;
	}
	public void setI_Yochung_Area_Gb(String i_Yochung_Area_Gb) {
		this.i_Yochung_Area_Gb = i_Yochung_Area_Gb;
	}
	public String getI_Yochung_Area_Zip() {
		return i_Yochung_Area_Zip;
	}
	public void setI_Yochung_Area_Zip(String i_Yochung_Area_Zip) {
		this.i_Yochung_Area_Zip = i_Yochung_Area_Zip;
	}
	public String getI_Yochung_Area_Addr() {
		return i_Yochung_Area_Addr;
	}
	public void setI_Yochung_Area_Addr(String i_Yochung_Area_Addr) {
		this.i_Yochung_Area_Addr = i_Yochung_Area_Addr;
	}
	public String getI_Yochung_Area_Gita() {
		return i_Yochung_Area_Gita;
	}
	public void setI_Yochung_Area_Gita(String i_Yochung_Area_Gita) {
		this.i_Yochung_Area_Gita = i_Yochung_Area_Gita;
	}
	public String getI_Co_Cd() {
		return i_Co_Cd;
	}
	public void setI_Co_Cd(String i_Co_Cd) {
		this.i_Co_Cd = i_Co_Cd;
	}
	public String getI_Co_Tel_Nm() {
		return i_Co_Tel_Nm;
	}
	public void setI_Co_Tel_Nm(String i_Co_Tel_Nm) {
		this.i_Co_Tel_Nm = i_Co_Tel_Nm;
	}
	public String getI_Co_Tel_Date() {
		return i_Co_Tel_Date;
	}
	public void setI_Co_Tel_Date(String i_Co_Tel_Date) {
		this.i_Co_Tel_Date = i_Co_Tel_Date;
	}
	public String getI_Co_Tel_Jubsuja() {
		return i_Co_Tel_Jubsuja;
	}
	public void setI_Co_Tel_Jubsuja(String i_Co_Tel_Jubsuja) {
		this.i_Co_Tel_Jubsuja = i_Co_Tel_Jubsuja;
	}
	public String getI_Sms_Yn() {
		return i_Sms_Yn;
	}
	public void setI_Sms_Yn(String i_Sms_Yn) {
		this.i_Sms_Yn = i_Sms_Yn;
	}
	public String getI_Chury_Ch_Cd() {
		return i_Chury_Ch_Cd;
	}
	public void setI_Chury_Ch_Cd(String i_Chury_Ch_Cd) {
		this.i_Chury_Ch_Cd = i_Chury_Ch_Cd;
	}
	public String getI_Chuldong_Nm() {
		return i_Chuldong_Nm;
	}
	public void setI_Chuldong_Nm(String i_Chuldong_Nm) {
		this.i_Chuldong_Nm = i_Chuldong_Nm;
	}
	public String getI_Chuldong_Area() {
		return i_Chuldong_Area;
	}
	public void setI_Chuldong_Area(String i_Chuldong_Area) {
		this.i_Chuldong_Area = i_Chuldong_Area;
	}
	public String getI_Chuldong_Guk() {
		return i_Chuldong_Guk;
	}
	public void setI_Chuldong_Guk(String i_Chuldong_Guk) {
		this.i_Chuldong_Guk = i_Chuldong_Guk;
	}
	public String getI_Chuldong_Ph() {
		return i_Chuldong_Ph;
	}
	public void setI_Chuldong_Ph(String i_Chuldong_Ph) {
		this.i_Chuldong_Ph = i_Chuldong_Ph;
	}
	public String getI_Chuldong_Yn() {
		return i_Chuldong_Yn;
	}
	public void setI_Chuldong_Yn(String i_Chuldong_Yn) {
		this.i_Chuldong_Yn = i_Chuldong_Yn;
	}
	public String getI_Chuldong_Sms_Date() {
		return i_Chuldong_Sms_Date;
	}
	public void setI_Chuldong_Sms_Date(String i_Chuldong_Sms_Date) {
		this.i_Chuldong_Sms_Date = i_Chuldong_Sms_Date;
	}
	public String getI_Dc_Type_Cd() {
		return i_Dc_Type_Cd;
	}
	public void setI_Dc_Type_Cd(String i_Dc_Type_Cd) {
		this.i_Dc_Type_Cd = i_Dc_Type_Cd;
	}
	public String getI_Dc_Type_Sub_Cd() {
		return i_Dc_Type_Sub_Cd;
	}
	public void setI_Dc_Type_Sub_Cd(String i_Dc_Type_Sub_Cd) {
		this.i_Dc_Type_Sub_Cd = i_Dc_Type_Sub_Cd;
	}
	public String getI_Dc_Type_Cont() {
		return i_Dc_Type_Cont;
	}
	public void setI_Dc_Type_Cont(String i_Dc_Type_Cont) {
		this.i_Dc_Type_Cont = i_Dc_Type_Cont;
	}
	public String getI_Pm_Type() {
		return i_Pm_Type;
	}
	public void setI_Pm_Type(String i_Pm_Type) {
		this.i_Pm_Type = i_Pm_Type;
	}
	public String getI_Pm_Type_Sebu() {
		return i_Pm_Type_Sebu;
	}
	public void setI_Pm_Type_Sebu(String i_Pm_Type_Sebu) {
		this.i_Pm_Type_Sebu = i_Pm_Type_Sebu;
	}
	public String getI_Pm_Km() {
		return i_Pm_Km;
	}
	public void setI_Pm_Km(String i_Pm_Km) {
		this.i_Pm_Km = i_Pm_Km;
	}
	public String getI_Danga_Gb() {
		return i_Danga_Gb;
	}
	public void setI_Danga_Gb(String i_Danga_Gb) {
		this.i_Danga_Gb = i_Danga_Gb;
	}
	public String getI_Yochung_Juso_Gb() {
		return i_Yochung_Juso_Gb;
	}
	public void setI_Yochung_Juso_Gb(String i_Yochung_Juso_Gb) {
		this.i_Yochung_Juso_Gb = i_Yochung_Juso_Gb;
	}
	public String getI_Drive_Km() {
		return i_Drive_Km;
	}
	public void setI_Drive_Km(String i_Drive_Km) {
		this.i_Drive_Km = i_Drive_Km;
	}
	public String getI_Drive_Ymd() {
		return i_Drive_Ymd;
	}
	public void setI_Drive_Ymd(String i_Drive_Ymd) {
		this.i_Drive_Ymd = i_Drive_Ymd;
	}
	public String getI_Photo_Yn() {
		return i_Photo_Yn;
	}
	public void setI_Photo_Yn(String i_Photo_Yn) {
		this.i_Photo_Yn = i_Photo_Yn;
	}
	public String getI_Sos_Gubsu() {
		return i_Sos_Gubsu;
	}
	public void setI_Sos_Gubsu(String i_Sos_Gubsu) {
		this.i_Sos_Gubsu = i_Sos_Gubsu;
	}
	public String getI_Sms_Gogek_Yn() {
		return i_Sms_Gogek_Yn;
	}
	public void setI_Sms_Gogek_Yn(String i_Sms_Gogek_Yn) {
		this.i_Sms_Gogek_Yn = i_Sms_Gogek_Yn;
	}
	public String getI_Sms_Gogek_Ymdhms() {
		return i_Sms_Gogek_Ymdhms;
	}
	public void setI_Sms_Gogek_Ymdhms(String i_Sms_Gogek_Ymdhms) {
		this.i_Sms_Gogek_Ymdhms = i_Sms_Gogek_Ymdhms;
	}
	public String getI_Err() {
		return i_Err;
	}
	public void setI_Err(String i_Err) {
		this.i_Err = i_Err;
	}
}