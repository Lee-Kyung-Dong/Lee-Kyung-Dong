package com.idongbu.smartcustomer.vo;

import java.util.List;
import java.util.Map;

import com.idongbu.common.vo.CMMVO;

//약관대출가능조회
public class CmmFUA6010RVO  extends CMMVO{
	
	public CmmFUA6010RVO() {
		super.setPGMID(proid);
		super.setTRID(trid);
	}
	
	private String CC_SAWON_NO   = null; // 사번	2차에서는 CmmFUVO에서 상속받은 필드
	
	private final static String proid		= "FUA6010R";
	private final static String trid		= "UA6A";
	private String rURL						= "";

	// 입력
	private String JJ_JUMIN_NO    = null; // 주민등록번호
	private String JJ_JIKWON_PA   = null; //임직원 = 1, PA = 2;

	// 출력
	private String CC_CHANNEL = null;
	private String CC_UKEY = null;
	private String CC_PGMID = null;
	private String CC_PROC_GB = null;
	private String CC_FUN_KEY = null;    
	private String CC_USER_GB = null;
	private String CC_USER_CD = null;
	private String CC_JIJUM_CD = null;
	private String CC_JIBU_CD = null;
	private String CC_PROTOCOL = null;
	private String CC_COND_CD = null;
	private String CC_LAST_FLAG = null;
	private String CC_CURSOR_MAP = null;
	private String CC_CURSOR_IDX = null;
	private String CC_MESSAGE_CD = null;
	private String HC_MESSAGE_NM = null;
	private String CC_SYS_ERR = null;
	private String CC_FILLER = null;
	
//	private String JJ_JUMIN_NO = null;
//	private String[] HJ_BJ_NM = new String[0]; // 10
//	
//	private String[] JJ_POLI_NO = new String[0]; // 10
//	private String[] HJ_SANGTE_NM = new String[0]; // 10
//	private String[] JJ_GISAN_GM = new String[0]; // 10
//	private String[] JJ_NAPIP_YMD = new String[0]; // 10
//	private String[] JJ_IYUL = new String[0]; // 10
//	private String[] JJ_GANUNG_GB = new String[0]; // 10
//	private String[] JJ_GANUNG_GM = new String[0]; // 10
//	private String[] JJ_ICHE_D = new String[0]; // 10
//	//2008.12.15 전문변경건 추가 luxncool
//	private String[] JJ_BANK_CD = new String[0]; // 은행코드
//	private String[] JJ_GYEJWA_NO = new String[0]; // 계좌번호
//	private String[] JJ_S_GANUNG_GB = new String[0]; // S-구분
//	private String[] HJ_BANK_NM = new String[0]; // 은행명
//	//2010.09.15 이자납입계좌조회 추가 cjh
//	private String[] JJ_IJ_BANK_CD = new String[0]; // 이자납입은행코드
//	private String[] JJ_IJ_GYEJWA_NO = new String[0]; // 이자납입계좌
//	private String[] HJ_IJ_BANK_NM = new String[0]; // 이자납입계좌은행명
//
//	//2012.05.11 오프라인 창구등록  대출금입금 계좌조회 추가 빈현욱
//	private String[] JJ_S_BANK_CD = new String[0]; // 이자납입은행코드
//	private String[] JJ_S_GYEJWA_NO = new String[0]; // 이자납입계좌
//	private String[] HJ_S_BANK_NM = new String[0]; // 이자납입계좌은행명
	
	private List<Map<String,Object>> loopData = null;	//2차때 []형태 vo을 list에 담음
	
	private String JJ_INJNG = null;
	private String JJ_IN1_FIL = null;
	private String FILLER = null;
	private String UU_INQ_POLI_NO = null;			// INQ-증권번호
	private String UU_F_POLI_NO = null;
	private String UU_L_POLI_NO = null;
	private String FILLER_1 = null;
	private List<SubFUA6010RVO> LIST_DATA = null;
	
	public String getCC_SAWON_NO() {
		return CC_SAWON_NO;
	}
	public void setCC_SAWON_NO(String cC_SAWON_NO) {
		CC_SAWON_NO = cC_SAWON_NO;
	}
	public String getrURL() {
		return rURL;
	}
	public void setrURL(String rURL) {
		this.rURL = rURL;
	}
	public String getJJ_JUMIN_NO() {
		return JJ_JUMIN_NO;
	}
	public void setJJ_JUMIN_NO(String jJ_JUMIN_NO) {
		JJ_JUMIN_NO = jJ_JUMIN_NO;
	}
	public String getJJ_JIKWON_PA() {
		return JJ_JIKWON_PA;
	}
	public void setJJ_JIKWON_PA(String jJ_JIKWON_PA) {
		JJ_JIKWON_PA = jJ_JIKWON_PA;
	}
	public String getCC_CHANNEL() {
		return CC_CHANNEL;
	}
	public void setCC_CHANNEL(String cC_CHANNEL) {
		CC_CHANNEL = cC_CHANNEL;
	}
	public String getCC_UKEY() {
		return CC_UKEY;
	}
	public void setCC_UKEY(String cC_UKEY) {
		CC_UKEY = cC_UKEY;
	}
	public String getCC_PGMID() {
		return CC_PGMID;
	}
	public void setCC_PGMID(String cC_PGMID) {
		CC_PGMID = cC_PGMID;
	}
	public String getCC_PROC_GB() {
		return CC_PROC_GB;
	}
	public void setCC_PROC_GB(String cC_PROC_GB) {
		CC_PROC_GB = cC_PROC_GB;
	}
	public String getCC_FUN_KEY() {
		return CC_FUN_KEY;
	}
	public void setCC_FUN_KEY(String cC_FUN_KEY) {
		CC_FUN_KEY = cC_FUN_KEY;
	}
	public String getCC_USER_GB() {
		return CC_USER_GB;
	}
	public void setCC_USER_GB(String cC_USER_GB) {
		CC_USER_GB = cC_USER_GB;
	}
	public String getCC_USER_CD() {
		return CC_USER_CD;
	}
	public void setCC_USER_CD(String cC_USER_CD) {
		CC_USER_CD = cC_USER_CD;
	}
	public String getCC_JIJUM_CD() {
		return CC_JIJUM_CD;
	}
	public void setCC_JIJUM_CD(String cC_JIJUM_CD) {
		CC_JIJUM_CD = cC_JIJUM_CD;
	}
	public String getCC_JIBU_CD() {
		return CC_JIBU_CD;
	}
	public void setCC_JIBU_CD(String cC_JIBU_CD) {
		CC_JIBU_CD = cC_JIBU_CD;
	}
	public String getCC_PROTOCOL() {
		return CC_PROTOCOL;
	}
	public void setCC_PROTOCOL(String cC_PROTOCOL) {
		CC_PROTOCOL = cC_PROTOCOL;
	}
	public String getCC_COND_CD() {
		return CC_COND_CD;
	}
	public void setCC_COND_CD(String cC_COND_CD) {
		CC_COND_CD = cC_COND_CD;
	}
	public String getCC_LAST_FLAG() {
		return CC_LAST_FLAG;
	}
	public void setCC_LAST_FLAG(String cC_LAST_FLAG) {
		CC_LAST_FLAG = cC_LAST_FLAG;
	}
	public String getCC_CURSOR_MAP() {
		return CC_CURSOR_MAP;
	}
	public void setCC_CURSOR_MAP(String cC_CURSOR_MAP) {
		CC_CURSOR_MAP = cC_CURSOR_MAP;
	}
	public String getCC_CURSOR_IDX() {
		return CC_CURSOR_IDX;
	}
	public void setCC_CURSOR_IDX(String cC_CURSOR_IDX) {
		CC_CURSOR_IDX = cC_CURSOR_IDX;
	}
	public String getCC_MESSAGE_CD() {
		return CC_MESSAGE_CD;
	}
	public void setCC_MESSAGE_CD(String cC_MESSAGE_CD) {
		CC_MESSAGE_CD = cC_MESSAGE_CD;
	}
	public String getHC_MESSAGE_NM() {
		return HC_MESSAGE_NM;
	}
	public void setHC_MESSAGE_NM(String hC_MESSAGE_NM) {
		HC_MESSAGE_NM = hC_MESSAGE_NM;
	}
	public String getCC_SYS_ERR() {
		return CC_SYS_ERR;
	}
	public void setCC_SYS_ERR(String cC_SYS_ERR) {
		CC_SYS_ERR = cC_SYS_ERR;
	}
	public String getCC_FILLER() {
		return CC_FILLER;
	}
	public void setCC_FILLER(String cC_FILLER) {
		CC_FILLER = cC_FILLER;
	}
	public String getJJ_INJNG() {
		return JJ_INJNG;
	}
	public void setJJ_INJNG(String jJ_INJNG) {
		JJ_INJNG = jJ_INJNG;
	}
	public String getJJ_IN1_FIL() {
		return JJ_IN1_FIL;
	}
	public void setJJ_IN1_FIL(String jJ_IN1_FIL) {
		JJ_IN1_FIL = jJ_IN1_FIL;
	}
	public String getFILLER() {
		return FILLER;
	}
	public void setFILLER(String fILLER) {
		FILLER = fILLER;
	}
	public String getUU_INQ_POLI_NO() {
		return UU_INQ_POLI_NO;
	}
	public void setUU_INQ_POLI_NO(String uU_INQ_POLI_NO) {
		UU_INQ_POLI_NO = uU_INQ_POLI_NO;
	}
	public String getUU_F_POLI_NO() {
		return UU_F_POLI_NO;
	}
	public void setUU_F_POLI_NO(String uU_F_POLI_NO) {
		UU_F_POLI_NO = uU_F_POLI_NO;
	}
	public String getUU_L_POLI_NO() {
		return UU_L_POLI_NO;
	}
	public void setUU_L_POLI_NO(String uU_L_POLI_NO) {
		UU_L_POLI_NO = uU_L_POLI_NO;
	}
	public String getFILLER_1() {
		return FILLER_1;
	}
	public void setFILLER_1(String fILLER_1) {
		FILLER_1 = fILLER_1;
	}
	public List<Map<String, Object>> getLoopData() {
		return loopData;
	}
	public void setLoopData(List<Map<String, Object>> loopData) {
		this.loopData = loopData;
	}
	public List<SubFUA6010RVO> getLIST_DATA() {
		return LIST_DATA;
	}
	public void setLIST_DATA(List<SubFUA6010RVO> lIST_DATA) {
		LIST_DATA = lIST_DATA;
	}
}