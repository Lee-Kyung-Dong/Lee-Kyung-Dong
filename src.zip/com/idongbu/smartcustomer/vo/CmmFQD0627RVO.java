package com.idongbu.smartcustomer.vo;

import com.idongbu.common.vo.CMMVO;

public class CmmFQD0627RVO extends CMMVO {

	public CmmFQD0627RVO() {
		super.setPGMID(proid);
		super.setTRID(trid);
	}
	
	private final static String proid		= "FQD0627R";
	private final static String trid		= "QDHF";

	private String COMM_CHANNEL;
	private String COMM_UNIQUE;
	private String COMM_PGMID;

	private String COMM_PROC_GB;
	private String COMM_FUN_KEY;

	private String COMM_USER_GB;
	private String COMM_USER_CD;
	private String COMM_JIJUM_CD;
	private String COMM_JIBU_CD;
	private String COMM_PROTOCOL;
	private String COMM_COND_CD;
	private String COMM_LAST_FLAG;
	private String COMM_CURSOR_MAP;
	private String COMM_CURSOR_IDX;
	private String COMM_MESSAGE_CD;
	private String H_COMM_MESSAGE_NM;
	private String COMM_SYS_ERR;
	private String COMM_TS_ITEM;
	private String COMM_FORM_ID;
	private String COMM_PRT_GB;
	private String COMM_FILLER;

	private String H_PRT_DATA;  
	private String PRT_DATA_LEN;

	private String SCR_BALGP_YY;
	private String SCR_GOGEK_NO_GB;
	private String SCR_GOGEK_CONTROL_NO;
	private String H_SCR_GYEYAKJA_NM;
	private String SCR_POLI_NO;
	private String H_SCR_CAR_NO;
	private String SCR_ICHE_YN;
	private String SCR_JIKIN_YN;
	private String SCR_JUSO_YN;

	private String SCR_PRINT_YN;
	private String H_SCR_BO_BJ_NM;
	private String SCR_BO_POLI_NO;
	private String H_SCR_BO_CAR_NO;
	private String SCR_L_BUNNAP;
	private String SCR_L_NAPIP_PRM;
	private String SCR_CHANNEL_CD;

	private String SCR_BALGPJA_NO;
	private String H_SCR_BALGPJA_NM;
	private String SCR_PR_POLI_NO;

	private String SCR_TAB_GUBUN;
	private String SCR_PRINT_TYPE; 
	private String SCR_GREEN_YN;
	private String SCR_I_POLICY_YN; 
	private String SCR_COPY_YN ;
	private String SCR_RECEIVER_ADDR; 
	private String SCR_AGREEMENT_YN;
	private String H_SCR_AGREEMENT_NM;  
	private String SCR_EMAIL_SUSINJA;

	private String BP_SERVER_IP;
	private String BP_PRINT_IP;
	private String COLOR_GB;
	private String REMOTE_GB;
	private String PRINT_JIJUM;
	private String PRINT_JIBU;

	private String PAGE_Q_YEAR;
	private String PAGE_Q_GOGEK_NO_GB;
	private String PAGE_Q_GOGEK_CONTROL_NO;
	private String PAGE_Q_POLI_NO;

	private String PAGE_F_YEAR;
	private String PAGE_F_GOGEK_NO_GB;
	private String PAGE_F_GOGEK_CONTROL_NO;
	private String PAGE_F_POLI_NO;

	private String PAGE_L_YEAR;
	private String PAGE_L_GOGEK_NO_GB;
	private String PAGE_L_GOGEK_CONTROL_NO;
	private String PAGE_L_POLI_NO;

	private String ENCRYPT_YN;
	private String ENCRYPT_KEY;

	private String SCR_BRIGHT_MAP;
	private String SCR_BRIGHT_POS;
	private String SCR_BRIGHT_FOS;

	private String SCR_BRIGHT_NAME;

	public String getCOMM_CHANNEL() {
		return COMM_CHANNEL;
	}

	public void setCOMM_CHANNEL(String cOMM_CHANNEL) {
		COMM_CHANNEL = cOMM_CHANNEL;
	}

	public String getCOMM_UNIQUE() {
		return COMM_UNIQUE;
	}

	public void setCOMM_UNIQUE(String cOMM_UNIQUE) {
		COMM_UNIQUE = cOMM_UNIQUE;
	}

	public String getCOMM_PGMID() {
		return COMM_PGMID;
	}

	public void setCOMM_PGMID(String cOMM_PGMID) {
		COMM_PGMID = cOMM_PGMID;
	}

	public String getCOMM_PROC_GB() {
		return COMM_PROC_GB;
	}

	public void setCOMM_PROC_GB(String cOMM_PROC_GB) {
		COMM_PROC_GB = cOMM_PROC_GB;
	}

	public String getCOMM_FUN_KEY() {
		return COMM_FUN_KEY;
	}

	public void setCOMM_FUN_KEY(String cOMM_FUN_KEY) {
		COMM_FUN_KEY = cOMM_FUN_KEY;
	}

	public String getCOMM_USER_GB() {
		return COMM_USER_GB;
	}

	public void setCOMM_USER_GB(String cOMM_USER_GB) {
		COMM_USER_GB = cOMM_USER_GB;
	}

	public String getCOMM_USER_CD() {
		return COMM_USER_CD;
	}

	public void setCOMM_USER_CD(String cOMM_USER_CD) {
		COMM_USER_CD = cOMM_USER_CD;
	}

	public String getCOMM_JIJUM_CD() {
		return COMM_JIJUM_CD;
	}

	public void setCOMM_JIJUM_CD(String cOMM_JIJUM_CD) {
		COMM_JIJUM_CD = cOMM_JIJUM_CD;
	}

	public String getCOMM_JIBU_CD() {
		return COMM_JIBU_CD;
	}

	public void setCOMM_JIBU_CD(String cOMM_JIBU_CD) {
		COMM_JIBU_CD = cOMM_JIBU_CD;
	}

	public String getCOMM_PROTOCOL() {
		return COMM_PROTOCOL;
	}

	public void setCOMM_PROTOCOL(String cOMM_PROTOCOL) {
		COMM_PROTOCOL = cOMM_PROTOCOL;
	}

	public String getCOMM_COND_CD() {
		return COMM_COND_CD;
	}

	public void setCOMM_COND_CD(String cOMM_COND_CD) {
		COMM_COND_CD = cOMM_COND_CD;
	}

	public String getCOMM_LAST_FLAG() {
		return COMM_LAST_FLAG;
	}

	public void setCOMM_LAST_FLAG(String cOMM_LAST_FLAG) {
		COMM_LAST_FLAG = cOMM_LAST_FLAG;
	}

	public String getCOMM_CURSOR_MAP() {
		return COMM_CURSOR_MAP;
	}

	public void setCOMM_CURSOR_MAP(String cOMM_CURSOR_MAP) {
		COMM_CURSOR_MAP = cOMM_CURSOR_MAP;
	}

	public String getCOMM_CURSOR_IDX() {
		return COMM_CURSOR_IDX;
	}

	public void setCOMM_CURSOR_IDX(String cOMM_CURSOR_IDX) {
		COMM_CURSOR_IDX = cOMM_CURSOR_IDX;
	}

	public String getCOMM_MESSAGE_CD() {
		return COMM_MESSAGE_CD;
	}

	public void setCOMM_MESSAGE_CD(String cOMM_MESSAGE_CD) {
		COMM_MESSAGE_CD = cOMM_MESSAGE_CD;
	}

	public String getH_COMM_MESSAGE_NM() {
		return H_COMM_MESSAGE_NM;
	}

	public void setH_COMM_MESSAGE_NM(String h_COMM_MESSAGE_NM) {
		H_COMM_MESSAGE_NM = h_COMM_MESSAGE_NM;
	}

	public String getCOMM_SYS_ERR() {
		return COMM_SYS_ERR;
	}

	public void setCOMM_SYS_ERR(String cOMM_SYS_ERR) {
		COMM_SYS_ERR = cOMM_SYS_ERR;
	}

	public String getCOMM_TS_ITEM() {
		return COMM_TS_ITEM;
	}

	public void setCOMM_TS_ITEM(String cOMM_TS_ITEM) {
		COMM_TS_ITEM = cOMM_TS_ITEM;
	}

	public String getCOMM_FORM_ID() {
		return COMM_FORM_ID;
	}

	public void setCOMM_FORM_ID(String cOMM_FORM_ID) {
		COMM_FORM_ID = cOMM_FORM_ID;
	}

	public String getCOMM_PRT_GB() {
		return COMM_PRT_GB;
	}

	public void setCOMM_PRT_GB(String cOMM_PRT_GB) {
		COMM_PRT_GB = cOMM_PRT_GB;
	}

	public String getCOMM_FILLER() {
		return COMM_FILLER;
	}

	public void setCOMM_FILLER(String cOMM_FILLER) {
		COMM_FILLER = cOMM_FILLER;
	}

	public String getH_PRT_DATA() {
		return H_PRT_DATA;
	}

	public void setH_PRT_DATA(String h_PRT_DATA) {
		H_PRT_DATA = h_PRT_DATA;
	}

	public String getPRT_DATA_LEN() {
		return PRT_DATA_LEN;
	}

	public void setPRT_DATA_LEN(String pRT_DATA_LEN) {
		PRT_DATA_LEN = pRT_DATA_LEN;
	}

	public String getSCR_BALGP_YY() {
		return SCR_BALGP_YY;
	}

	public void setSCR_BALGP_YY(String sCR_BALGP_YY) {
		SCR_BALGP_YY = sCR_BALGP_YY;
	}

	public String getSCR_GOGEK_NO_GB() {
		return SCR_GOGEK_NO_GB;
	}

	public void setSCR_GOGEK_NO_GB(String sCR_GOGEK_NO_GB) {
		SCR_GOGEK_NO_GB = sCR_GOGEK_NO_GB;
	}

	public String getSCR_GOGEK_CONTROL_NO() {
		return SCR_GOGEK_CONTROL_NO;
	}

	public void setSCR_GOGEK_CONTROL_NO(String sCR_GOGEK_CONTROL_NO) {
		SCR_GOGEK_CONTROL_NO = sCR_GOGEK_CONTROL_NO;
	}

	public String getH_SCR_GYEYAKJA_NM() {
		return H_SCR_GYEYAKJA_NM;
	}

	public void setH_SCR_GYEYAKJA_NM(String h_SCR_GYEYAKJA_NM) {
		H_SCR_GYEYAKJA_NM = h_SCR_GYEYAKJA_NM;
	}

	public String getSCR_POLI_NO() {
		return SCR_POLI_NO;
	}

	public void setSCR_POLI_NO(String sCR_POLI_NO) {
		SCR_POLI_NO = sCR_POLI_NO;
	}

	public String getH_SCR_CAR_NO() {
		return H_SCR_CAR_NO;
	}

	public void setH_SCR_CAR_NO(String h_SCR_CAR_NO) {
		H_SCR_CAR_NO = h_SCR_CAR_NO;
	}

	public String getSCR_ICHE_YN() {
		return SCR_ICHE_YN;
	}

	public void setSCR_ICHE_YN(String sCR_ICHE_YN) {
		SCR_ICHE_YN = sCR_ICHE_YN;
	}

	public String getSCR_JIKIN_YN() {
		return SCR_JIKIN_YN;
	}

	public void setSCR_JIKIN_YN(String sCR_JIKIN_YN) {
		SCR_JIKIN_YN = sCR_JIKIN_YN;
	}

	public String getSCR_JUSO_YN() {
		return SCR_JUSO_YN;
	}

	public void setSCR_JUSO_YN(String sCR_JUSO_YN) {
		SCR_JUSO_YN = sCR_JUSO_YN;
	}

	public String getSCR_PRINT_YN() {
		return SCR_PRINT_YN;
	}

	public void setSCR_PRINT_YN(String sCR_PRINT_YN) {
		SCR_PRINT_YN = sCR_PRINT_YN;
	}

	public String getH_SCR_BO_BJ_NM() {
		return H_SCR_BO_BJ_NM;
	}

	public void setH_SCR_BO_BJ_NM(String h_SCR_BO_BJ_NM) {
		H_SCR_BO_BJ_NM = h_SCR_BO_BJ_NM;
	}

	public String getSCR_BO_POLI_NO() {
		return SCR_BO_POLI_NO;
	}

	public void setSCR_BO_POLI_NO(String sCR_BO_POLI_NO) {
		SCR_BO_POLI_NO = sCR_BO_POLI_NO;
	}

	public String getH_SCR_BO_CAR_NO() {
		return H_SCR_BO_CAR_NO;
	}

	public void setH_SCR_BO_CAR_NO(String h_SCR_BO_CAR_NO) {
		H_SCR_BO_CAR_NO = h_SCR_BO_CAR_NO;
	}

	public String getSCR_L_BUNNAP() {
		return SCR_L_BUNNAP;
	}

	public void setSCR_L_BUNNAP(String sCR_L_BUNNAP) {
		SCR_L_BUNNAP = sCR_L_BUNNAP;
	}

	public String getSCR_L_NAPIP_PRM() {
		return SCR_L_NAPIP_PRM;
	}

	public void setSCR_L_NAPIP_PRM(String sCR_L_NAPIP_PRM) {
		SCR_L_NAPIP_PRM = sCR_L_NAPIP_PRM;
	}

	public String getSCR_CHANNEL_CD() {
		return SCR_CHANNEL_CD;
	}

	public void setSCR_CHANNEL_CD(String sCR_CHANNEL_CD) {
		SCR_CHANNEL_CD = sCR_CHANNEL_CD;
	}

	public String getSCR_BALGPJA_NO() {
		return SCR_BALGPJA_NO;
	}

	public void setSCR_BALGPJA_NO(String sCR_BALGPJA_NO) {
		SCR_BALGPJA_NO = sCR_BALGPJA_NO;
	}

	public String getH_SCR_BALGPJA_NM() {
		return H_SCR_BALGPJA_NM;
	}

	public void setH_SCR_BALGPJA_NM(String h_SCR_BALGPJA_NM) {
		H_SCR_BALGPJA_NM = h_SCR_BALGPJA_NM;
	}

	public String getSCR_PR_POLI_NO() {
		return SCR_PR_POLI_NO;
	}

	public void setSCR_PR_POLI_NO(String sCR_PR_POLI_NO) {
		SCR_PR_POLI_NO = sCR_PR_POLI_NO;
	}

	public String getSCR_TAB_GUBUN() {
		return SCR_TAB_GUBUN;
	}

	public void setSCR_TAB_GUBUN(String sCR_TAB_GUBUN) {
		SCR_TAB_GUBUN = sCR_TAB_GUBUN;
	}

	public String getSCR_PRINT_TYPE() {
		return SCR_PRINT_TYPE;
	}

	public void setSCR_PRINT_TYPE(String sCR_PRINT_TYPE) {
		SCR_PRINT_TYPE = sCR_PRINT_TYPE;
	}

	public String getSCR_GREEN_YN() {
		return SCR_GREEN_YN;
	}

	public void setSCR_GREEN_YN(String sCR_GREEN_YN) {
		SCR_GREEN_YN = sCR_GREEN_YN;
	}

	public String getSCR_I_POLICY_YN() {
		return SCR_I_POLICY_YN;
	}

	public void setSCR_I_POLICY_YN(String sCR_I_POLICY_YN) {
		SCR_I_POLICY_YN = sCR_I_POLICY_YN;
	}

	public String getSCR_COPY_YN() {
		return SCR_COPY_YN;
	}

	public void setSCR_COPY_YN(String sCR_COPY_YN) {
		SCR_COPY_YN = sCR_COPY_YN;
	}

	public String getSCR_RECEIVER_ADDR() {
		return SCR_RECEIVER_ADDR;
	}

	public void setSCR_RECEIVER_ADDR(String sCR_RECEIVER_ADDR) {
		SCR_RECEIVER_ADDR = sCR_RECEIVER_ADDR;
	}

	public String getSCR_AGREEMENT_YN() {
		return SCR_AGREEMENT_YN;
	}

	public void setSCR_AGREEMENT_YN(String sCR_AGREEMENT_YN) {
		SCR_AGREEMENT_YN = sCR_AGREEMENT_YN;
	}

	public String getH_SCR_AGREEMENT_NM() {
		return H_SCR_AGREEMENT_NM;
	}

	public void setH_SCR_AGREEMENT_NM(String h_SCR_AGREEMENT_NM) {
		H_SCR_AGREEMENT_NM = h_SCR_AGREEMENT_NM;
	}

	public String getSCR_EMAIL_SUSINJA() {
		return SCR_EMAIL_SUSINJA;
	}

	public void setSCR_EMAIL_SUSINJA(String sCR_EMAIL_SUSINJA) {
		SCR_EMAIL_SUSINJA = sCR_EMAIL_SUSINJA;
	}

	public String getBP_SERVER_IP() {
		return BP_SERVER_IP;
	}

	public void setBP_SERVER_IP(String bP_SERVER_IP) {
		BP_SERVER_IP = bP_SERVER_IP;
	}

	public String getBP_PRINT_IP() {
		return BP_PRINT_IP;
	}

	public void setBP_PRINT_IP(String bP_PRINT_IP) {
		BP_PRINT_IP = bP_PRINT_IP;
	}

	public String getCOLOR_GB() {
		return COLOR_GB;
	}

	public void setCOLOR_GB(String cOLOR_GB) {
		COLOR_GB = cOLOR_GB;
	}

	public String getREMOTE_GB() {
		return REMOTE_GB;
	}

	public void setREMOTE_GB(String rEMOTE_GB) {
		REMOTE_GB = rEMOTE_GB;
	}

	public String getPRINT_JIJUM() {
		return PRINT_JIJUM;
	}

	public void setPRINT_JIJUM(String pRINT_JIJUM) {
		PRINT_JIJUM = pRINT_JIJUM;
	}

	public String getPRINT_JIBU() {
		return PRINT_JIBU;
	}

	public void setPRINT_JIBU(String pRINT_JIBU) {
		PRINT_JIBU = pRINT_JIBU;
	}

	public String getPAGE_Q_YEAR() {
		return PAGE_Q_YEAR;
	}

	public void setPAGE_Q_YEAR(String pAGE_Q_YEAR) {
		PAGE_Q_YEAR = pAGE_Q_YEAR;
	}

	public String getPAGE_Q_GOGEK_NO_GB() {
		return PAGE_Q_GOGEK_NO_GB;
	}

	public void setPAGE_Q_GOGEK_NO_GB(String pAGE_Q_GOGEK_NO_GB) {
		PAGE_Q_GOGEK_NO_GB = pAGE_Q_GOGEK_NO_GB;
	}

	public String getPAGE_Q_GOGEK_CONTROL_NO() {
		return PAGE_Q_GOGEK_CONTROL_NO;
	}

	public void setPAGE_Q_GOGEK_CONTROL_NO(String pAGE_Q_GOGEK_CONTROL_NO) {
		PAGE_Q_GOGEK_CONTROL_NO = pAGE_Q_GOGEK_CONTROL_NO;
	}

	public String getPAGE_Q_POLI_NO() {
		return PAGE_Q_POLI_NO;
	}

	public void setPAGE_Q_POLI_NO(String pAGE_Q_POLI_NO) {
		PAGE_Q_POLI_NO = pAGE_Q_POLI_NO;
	}

	public String getPAGE_F_YEAR() {
		return PAGE_F_YEAR;
	}

	public void setPAGE_F_YEAR(String pAGE_F_YEAR) {
		PAGE_F_YEAR = pAGE_F_YEAR;
	}

	public String getPAGE_F_GOGEK_NO_GB() {
		return PAGE_F_GOGEK_NO_GB;
	}

	public void setPAGE_F_GOGEK_NO_GB(String pAGE_F_GOGEK_NO_GB) {
		PAGE_F_GOGEK_NO_GB = pAGE_F_GOGEK_NO_GB;
	}

	public String getPAGE_F_GOGEK_CONTROL_NO() {
		return PAGE_F_GOGEK_CONTROL_NO;
	}

	public void setPAGE_F_GOGEK_CONTROL_NO(String pAGE_F_GOGEK_CONTROL_NO) {
		PAGE_F_GOGEK_CONTROL_NO = pAGE_F_GOGEK_CONTROL_NO;
	}

	public String getPAGE_F_POLI_NO() {
		return PAGE_F_POLI_NO;
	}

	public void setPAGE_F_POLI_NO(String pAGE_F_POLI_NO) {
		PAGE_F_POLI_NO = pAGE_F_POLI_NO;
	}

	public String getPAGE_L_YEAR() {
		return PAGE_L_YEAR;
	}

	public void setPAGE_L_YEAR(String pAGE_L_YEAR) {
		PAGE_L_YEAR = pAGE_L_YEAR;
	}

	public String getPAGE_L_GOGEK_NO_GB() {
		return PAGE_L_GOGEK_NO_GB;
	}

	public void setPAGE_L_GOGEK_NO_GB(String pAGE_L_GOGEK_NO_GB) {
		PAGE_L_GOGEK_NO_GB = pAGE_L_GOGEK_NO_GB;
	}

	public String getPAGE_L_GOGEK_CONTROL_NO() {
		return PAGE_L_GOGEK_CONTROL_NO;
	}

	public void setPAGE_L_GOGEK_CONTROL_NO(String pAGE_L_GOGEK_CONTROL_NO) {
		PAGE_L_GOGEK_CONTROL_NO = pAGE_L_GOGEK_CONTROL_NO;
	}

	public String getPAGE_L_POLI_NO() {
		return PAGE_L_POLI_NO;
	}

	public void setPAGE_L_POLI_NO(String pAGE_L_POLI_NO) {
		PAGE_L_POLI_NO = pAGE_L_POLI_NO;
	}

	public String getENCRYPT_YN() {
		return ENCRYPT_YN;
	}

	public void setENCRYPT_YN(String eNCRYPT_YN) {
		ENCRYPT_YN = eNCRYPT_YN;
	}

	public String getENCRYPT_KEY() {
		return ENCRYPT_KEY;
	}

	public void setENCRYPT_KEY(String eNCRYPT_KEY) {
		ENCRYPT_KEY = eNCRYPT_KEY;
	}

	public String getSCR_BRIGHT_MAP() {
		return SCR_BRIGHT_MAP;
	}

	public void setSCR_BRIGHT_MAP(String sCR_BRIGHT_MAP) {
		SCR_BRIGHT_MAP = sCR_BRIGHT_MAP;
	}

	public String getSCR_BRIGHT_POS() {
		return SCR_BRIGHT_POS;
	}

	public void setSCR_BRIGHT_POS(String sCR_BRIGHT_POS) {
		SCR_BRIGHT_POS = sCR_BRIGHT_POS;
	}

	public String getSCR_BRIGHT_FOS() {
		return SCR_BRIGHT_FOS;
	}

	public void setSCR_BRIGHT_FOS(String sCR_BRIGHT_FOS) {
		SCR_BRIGHT_FOS = sCR_BRIGHT_FOS;
	}

	public String getSCR_BRIGHT_NAME() {
		return SCR_BRIGHT_NAME;
	}

	public void setSCR_BRIGHT_NAME(String sCR_BRIGHT_NAME) {
		SCR_BRIGHT_NAME = sCR_BRIGHT_NAME;
	}

	public String getProid() {
		return proid;
	}

	public String getTrid() {
		return trid;
	}

}
