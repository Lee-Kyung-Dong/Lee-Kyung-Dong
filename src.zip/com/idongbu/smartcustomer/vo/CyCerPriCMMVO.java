package com.idongbu.smartcustomer.vo;

import java.util.ArrayList;

public class CyCerPriCMMVO {
	public int retCode;
	public String retMsg;

	// 공통
	public String USER_GB		= "";
	public String USER_CD		= "";
	public String JIJUM_CD		= "";
	public String JIBU_CD		= "";
	
	// 대출 약정 대출서에서 사용
	public String USER_PW		= "";
	public String PRT_GB		= "";
	public String JOHOI_NM		= "";				// 보험계약자
	public ArrayList GANUNG_GM 	 = new ArrayList();	// 대출가능액
	public ArrayList GIDECHUL_GM = new ArrayList();	// 기대출잔액
	public ArrayList SINCHUNG_GM = new ArrayList();	// 대출신청금액
	public ArrayList IYUL		 = new ArrayList();	// 정상이율
	public ArrayList GANUNG_IJA	 = new ArrayList();	// 예상이자
	public ArrayList HEJI_GM	 = new ArrayList();	// 해지환급금
	public ArrayList JUKRIP_PRM	 = new ArrayList();	// 적립부분
	public ArrayList DAMBO_PRM	 = new ArrayList();	// 담보부분
	public ArrayList JILGWUN_NM	 = new ArrayList();	// 질권내용
	public ArrayList JUNGDO_YN	 = new ArrayList();	// 중도인출가능여부
	public ArrayList GA_GYEJWA_NO 	= new ArrayList();	// 가상계좌여부
	public ArrayList SANGTAE_CD	 	= new ArrayList();	// 상태코드
	public ArrayList SANGTAE_NAME 	= new ArrayList();	// 상태명
	public ArrayList BOHUM_SYMD		= new ArrayList();	// 보험기간시기
	public ArrayList BOHUM_EYMD		= new ArrayList();	// 보험기간종기
	public ArrayList SUJOJIKWON_CD  = new ArrayList();	// 수금조직원코드
	public ArrayList BJ_CD		= new ArrayList();	// 보험종목코드
	public ArrayList BJ_NAME	= new ArrayList();	// 보험종목명 - 60
	public ArrayList BJ_NAME40	= new ArrayList();	// 보험종목명 - 40
	public ArrayList BJ_NAME20	= new ArrayList();	// 보험종목명 - 20
	public ArrayList IJA_GIGAN	= new ArrayList();	// 이자납입일
	public ArrayList GISAN_YMD	= new ArrayList();	// 기산일 - 최종이자납입일
	public ArrayList GIDEIJA_GM	= new ArrayList();	// 기대출이자
	public ArrayList INJIDAE_GM	= new ArrayList();	// 인지대
	public ArrayList SILJIGB_GM	= new ArrayList();	// 실지급금액
	public ArrayList NUJUK_DAEC_GM	= new ArrayList();	// 누적대출금액
	public ArrayList CHAGAM_GM	= new ArrayList();	// 차감지급액 = 신청금액 - 기대출금이자
	public ArrayList JADONG_BANK_CD2	= new ArrayList();	// 보험료자동이체계좌
	public ArrayList JADONG_BANK_CD		= new ArrayList();	// 보험료자동이체계좌
	public ArrayList JADONG_BANK_JIJUM_CD	= new ArrayList();	// 은행지점코드
	public ArrayList JADONG_BANK_NAME	= new ArrayList();	// 은행명
	public ArrayList JADONG_GYEJWA_NO	= new ArrayList();	// 계좌번호
	public ArrayList JADONG_YEGMJU_NAME	= new ArrayList();	// 예금주명
	public ArrayList IJSUGM_BANK_CD2	= new ArrayList();	// 은행코드 - 이자수금계좌
	public ArrayList IJSUGM_BANK_CD		= new ArrayList();	// 은행코드
	public ArrayList IJSUGM_BANK_JIJUM_CD		= new ArrayList();	// 은행지점코드
	public ArrayList IJSUGM_BANK_NAME			= new ArrayList();	// 은행명
	public ArrayList IJSUGM_GYEJWA_NO			= new ArrayList();	// 계좌번호
	public ArrayList IJSUGM_YEGMJU_NAME			= new ArrayList();	// 예금주명
	public ArrayList JADONG_YN			= new ArrayList();	// 자동대출여부
	public ArrayList EDI_CHUL_YN		= new ArrayList();	// 이중출금여부
	public ArrayList ICHE_DD			= new ArrayList();	// 이체일
	public ArrayList CHURI_RESULT		= new ArrayList();	// 처리결과
	public ArrayList JUNPYO_NO			= new ArrayList();	// 전표번호
	public ArrayList SEQ_113			= new ArrayList();	// 입출금일련번호 - 31113
	public ArrayList SEQ_115			= new ArrayList();	// 입출금일련번호 - 31115
	public ArrayList RESERV_1			= new ArrayList();	// 신청영역예비
	
	//COMM_HEAD_AREA.	
	public String TRID         	  = "";
	public String CHANNEL         = "";
	public String UNIQUE          = "";
	public String PGMID           = "";
	public String PROC_GB         = "";
	public String FUN_KEY         = "";
	public String PROTOCOL        = "";
	public String LAST_FLAG       = "";
	public String MESSAGE_CD      = "";
	public String MESSAGE_NM      = "";
	public String FORM_ID         = "";
	public String TS_ITEM         = "";
	public String RETURN_FORM_ID  = "";
	
	// 호스트 조회
	public String POLI_NO            	 = "";
	public String JJ_JUMIN           	 = "";
	public ArrayList RETURN_POLI_NO 	 = new ArrayList();
	public String PRT_DATA 		 		 = "";
	public String CHUL_GB            	 = "";
	public String FORM_GB            	 = "";
	public String PIBO_POLI_NO           = "";
	public String LAST_POLI_NO           = "";
	
	// 개인
	public String JUMIN_NO		= "";
	
	// 에러
	public String ERROR_CD		= "";
	
	// 출력구분
//	public String PRINT_GUBUN = "";
}
