package com.idongbu.smartcustomer.vo;

import com.idongbu.common.vo.CMMVO;

public class CmmFBM0056RVO extends CMMVO {

	public CmmFBM0056RVO() {
		super.setPGMID(proid);
		super.setTRID(trid);
	}
	
	private final static String proid		= "FBM0056R";
	private final static String trid		= "BM56";
	
	private String CM_CHANNEL_GB;
	private String CM_UNIQUE_KEY;
	private String CM_0QPGM_ID;
	private String CM_0QPROC_GB;
	private String CM_FUNCTION_PGUD;
	
	private String CM_USER_GB;
	private String CM_USER_ID;
	private String CM_JIJUM_CD;
	private String CM_JIBU_CD;
	
	private String CM_PROTOCOL_GB;
	private String CM_COND_CD;
	private String CM_LAST_FLAG;
	private String CM_CUR_LAYER;
	private String CM_CUR_INDEX;
	private String CM_MESSAGE_CD;
	private String HM_MESSAGE_NM;
	private String CM_SYS_ERR;
	private String CM_TS_ITEM;
	private String CM_FORM_ID;
	private String CM_PRINT_GB;
	private String CM_SPARE;
	
	private String SI_CHIGPJA_CD;
	private String HI_CHIGPJA_NM;
	private String HI_SANGHO_NM;
	private String SI_YEAR;
	private String SI_GOGEK_NO;
	private String SI_GOGEK_NM;
	private String SI_JONGRYU_GB;
	private String SI_JIKIN_YN;
	
	private String PRT_DATA;
	
	private String UD_F_POLI_NO;
	
	private String UD_L_POLI_NO;

	public String getCM_CHANNEL_GB() {
		return CM_CHANNEL_GB;
	}

	public void setCM_CHANNEL_GB(String cM_CHANNEL_GB) {
		CM_CHANNEL_GB = cM_CHANNEL_GB;
	}

	public String getCM_UNIQUE_KEY() {
		return CM_UNIQUE_KEY;
	}

	public void setCM_UNIQUE_KEY(String cM_UNIQUE_KEY) {
		CM_UNIQUE_KEY = cM_UNIQUE_KEY;
	}

	public String getCM_0QPGM_ID() {
		return CM_0QPGM_ID;
	}

	public void setCM_0QPGM_ID(String cM_0QPGM_ID) {
		CM_0QPGM_ID = cM_0QPGM_ID;
	}

	public String getCM_0QPROC_GB() {
		return CM_0QPROC_GB;
	}

	public void setCM_0QPROC_GB(String cM_0QPROC_GB) {
		CM_0QPROC_GB = cM_0QPROC_GB;
	}

	public String getCM_FUNCTION_PGUD() {
		return CM_FUNCTION_PGUD;
	}

	public void setCM_FUNCTION_PGUD(String cM_FUNCTION_PGUD) {
		CM_FUNCTION_PGUD = cM_FUNCTION_PGUD;
	}

	public String getCM_USER_GB() {
		return CM_USER_GB;
	}

	public void setCM_USER_GB(String cM_USER_GB) {
		CM_USER_GB = cM_USER_GB;
	}

	public String getCM_USER_ID() {
		return CM_USER_ID;
	}

	public void setCM_USER_ID(String cM_USER_ID) {
		CM_USER_ID = cM_USER_ID;
	}

	public String getCM_JIJUM_CD() {
		return CM_JIJUM_CD;
	}

	public void setCM_JIJUM_CD(String cM_JIJUM_CD) {
		CM_JIJUM_CD = cM_JIJUM_CD;
	}

	public String getCM_JIBU_CD() {
		return CM_JIBU_CD;
	}

	public void setCM_JIBU_CD(String cM_JIBU_CD) {
		CM_JIBU_CD = cM_JIBU_CD;
	}

	public String getCM_PROTOCOL_GB() {
		return CM_PROTOCOL_GB;
	}

	public void setCM_PROTOCOL_GB(String cM_PROTOCOL_GB) {
		CM_PROTOCOL_GB = cM_PROTOCOL_GB;
	}

	public String getCM_COND_CD() {
		return CM_COND_CD;
	}

	public void setCM_COND_CD(String cM_COND_CD) {
		CM_COND_CD = cM_COND_CD;
	}

	public String getCM_LAST_FLAG() {
		return CM_LAST_FLAG;
	}

	public void setCM_LAST_FLAG(String cM_LAST_FLAG) {
		CM_LAST_FLAG = cM_LAST_FLAG;
	}

	public String getCM_CUR_LAYER() {
		return CM_CUR_LAYER;
	}

	public void setCM_CUR_LAYER(String cM_CUR_LAYER) {
		CM_CUR_LAYER = cM_CUR_LAYER;
	}

	public String getCM_CUR_INDEX() {
		return CM_CUR_INDEX;
	}

	public void setCM_CUR_INDEX(String cM_CUR_INDEX) {
		CM_CUR_INDEX = cM_CUR_INDEX;
	}

	public String getCM_MESSAGE_CD() {
		return CM_MESSAGE_CD;
	}

	public void setCM_MESSAGE_CD(String cM_MESSAGE_CD) {
		CM_MESSAGE_CD = cM_MESSAGE_CD;
	}

	public String getHM_MESSAGE_NM() {
		return HM_MESSAGE_NM;
	}

	public void setHM_MESSAGE_NM(String hM_MESSAGE_NM) {
		HM_MESSAGE_NM = hM_MESSAGE_NM;
	}

	public String getCM_SYS_ERR() {
		return CM_SYS_ERR;
	}

	public void setCM_SYS_ERR(String cM_SYS_ERR) {
		CM_SYS_ERR = cM_SYS_ERR;
	}

	public String getCM_TS_ITEM() {
		return CM_TS_ITEM;
	}

	public void setCM_TS_ITEM(String cM_TS_ITEM) {
		CM_TS_ITEM = cM_TS_ITEM;
	}

	public String getCM_FORM_ID() {
		return CM_FORM_ID;
	}

	public void setCM_FORM_ID(String cM_FORM_ID) {
		CM_FORM_ID = cM_FORM_ID;
	}

	public String getCM_PRINT_GB() {
		return CM_PRINT_GB;
	}

	public void setCM_PRINT_GB(String cM_PRINT_GB) {
		CM_PRINT_GB = cM_PRINT_GB;
	}

	public String getCM_SPARE() {
		return CM_SPARE;
	}

	public void setCM_SPARE(String cM_SPARE) {
		CM_SPARE = cM_SPARE;
	}

	public String getSI_CHIGPJA_CD() {
		return SI_CHIGPJA_CD;
	}

	public void setSI_CHIGPJA_CD(String sI_CHIGPJA_CD) {
		SI_CHIGPJA_CD = sI_CHIGPJA_CD;
	}

	public String getHI_CHIGPJA_NM() {
		return HI_CHIGPJA_NM;
	}

	public void setHI_CHIGPJA_NM(String hI_CHIGPJA_NM) {
		HI_CHIGPJA_NM = hI_CHIGPJA_NM;
	}

	public String getHI_SANGHO_NM() {
		return HI_SANGHO_NM;
	}

	public void setHI_SANGHO_NM(String hI_SANGHO_NM) {
		HI_SANGHO_NM = hI_SANGHO_NM;
	}

	public String getSI_YEAR() {
		return SI_YEAR;
	}

	public void setSI_YEAR(String sI_YEAR) {
		SI_YEAR = sI_YEAR;
	}

	public String getSI_GOGEK_NO() {
		return SI_GOGEK_NO;
	}

	public void setSI_GOGEK_NO(String sI_GOGEK_NO) {
		SI_GOGEK_NO = sI_GOGEK_NO;
	}

	public String getSI_GOGEK_NM() {
		return SI_GOGEK_NM;
	}

	public void setSI_GOGEK_NM(String sI_GOGEK_NM) {
		SI_GOGEK_NM = sI_GOGEK_NM;
	}

	public String getSI_JONGRYU_GB() {
		return SI_JONGRYU_GB;
	}

	public void setSI_JONGRYU_GB(String sI_JONGRYU_GB) {
		SI_JONGRYU_GB = sI_JONGRYU_GB;
	}

	public String getSI_JIKIN_YN() {
		return SI_JIKIN_YN;
	}

	public void setSI_JIKIN_YN(String sI_JIKIN_YN) {
		SI_JIKIN_YN = sI_JIKIN_YN;
	}

	public String getPRT_DATA() {
		return PRT_DATA;
	}

	public void setPRT_DATA(String pRT_DATA) {
		PRT_DATA = pRT_DATA;
	}

	public String getUD_F_POLI_NO() {
		return UD_F_POLI_NO;
	}

	public void setUD_F_POLI_NO(String uD_F_POLI_NO) {
		UD_F_POLI_NO = uD_F_POLI_NO;
	}

	public String getUD_L_POLI_NO() {
		return UD_L_POLI_NO;
	}

	public void setUD_L_POLI_NO(String uD_L_POLI_NO) {
		UD_L_POLI_NO = uD_L_POLI_NO;
	}

	public String getProid() {
		return proid;
	}

	public String getTrid() {
		return trid;
	}
	
}
