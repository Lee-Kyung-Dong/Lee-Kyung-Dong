package com.idongbu.smartcustomer.vo;

public class ReOneListVO {
	
	private String jubsuNO              = ""; // 3차 추가
	private String chunguMemo           = ""; // 3차 추가
	
	private String ssnTermId            = ""; // 2차에서는 CmmVO에서 상속받은 필드
	private int page_num                = 1;  // 2차에서 BaseVO에서 상속받은 필드
	private String ssnUserJumin	        = ""; // 2차에서는 CmmVO에서 상속받은 필드
	
	private String mode			        = "";	
	                                    
	private String f                    = "";
	private String t                    = "";
	                                    
	private String UD_FK_POLI_NO        = ""; // 리스트의 첫번째 증권번호
	private String UD_LK_POLI_NO        = ""; // 다음 리스트의 첫번째 증권번호
	private String SI_K_GOGEK_NO        = ""; // 고객번호(주민번호)
	private String PREV_UD_FK_POLI_NO   = ""; // 첫번째 증권번호를 저장할 변수
	                                    
	private String page                 = "";
	
	private String seq_no               = "";
	private String inhab_no             = "";
	private String spew_dstin_cd        = "";
	private String job_dstin_cd         = "";
	private String accid_rcept_no       = "";
	private String progr_dstin_cd       = "";
	private String progr_dstin_cd_nm       = "";
	private String car_no               = "";
	private String accid_day            = "";
	private String consl_lclas_rcept_no = "";
	private String consl_rcept_no       = "";
	private String consl_rcept_seq_no   = "";
	private String consl_type_name      = "";
	private String accid_type_cd        = "";
	private String accid_cause_cd       = "";
	private String etc_1_cd             = "";
	private String etc_2_cd             = "";
	private String etc_3_cd             = "";
	private String etc_4_cd             = "";
	private String etc_5_cd             = "";
	
	//개인정보보호 동의용
	private String next_mode            = "";
	private String next_action          = "";
	//개인정보보호 동의용 - 자동차 추가
	private String name                 = "";
	private String carnum               = "";
	private String ins                  = "";
	private String from                 = "";
	private String to                   = "";
	
	private String f_id                 = "";
	private String tab                  = "";
	
	// 개인정보 동의 : 모바일
	private String modeType             = "";
	private String agree01              = "";
	private String agree02              = "";
	private String agree03              = "";
	private String agree04              = "";
	private String agree05              = "";
	
	private String accd_rpt_dt			= ""; // 접수일
	private String accd_oj_dvcd			= "";
	private String accd_oj_rnk			= "";
	
	// 자동차 / 장기 구분               
	private String docType              = "";			
	
	public String getJubsuNO() {
		return jubsuNO;
	}

	public void setJubsuNO(String jubsuNO) {
		this.jubsuNO = jubsuNO;
	}

	public String getChunguMemo() {
		return chunguMemo;
	}

	public void setChunguMemo(String chunguMemo) {
		this.chunguMemo = chunguMemo;
	}

	public String getSsnTermId() {
		return ssnTermId;
	}

	public void setSsnTermId(String ssnTermId) {
		this.ssnTermId = ssnTermId;
	}

	public int getPage_num() {
		return page_num;
	}

	public void setPage_num(int page_num) {
		this.page_num = page_num;
	}

	public String getSsnUserJumin() {
		return ssnUserJumin;
	}

	public void setSsnUserJumin(String ssnUserJumin) {
		this.ssnUserJumin = ssnUserJumin;
	}

	public String getMode() {
		return mode;
	}

	public void setMode(String mode) {
		this.mode = mode;
	}

	public String getF() {
		return f;
	}

	public void setF(String f) {
		this.f = f;
	}

	public String getT() {
		return t;
	}

	public void setT(String t) {
		this.t = t;
	}

	public String getUD_FK_POLI_NO() {
		return UD_FK_POLI_NO;
	}

	public void setUD_FK_POLI_NO(String uD_FK_POLI_NO) {
		UD_FK_POLI_NO = uD_FK_POLI_NO;
	}

	public String getUD_LK_POLI_NO() {
		return UD_LK_POLI_NO;
	}

	public void setUD_LK_POLI_NO(String uD_LK_POLI_NO) {
		UD_LK_POLI_NO = uD_LK_POLI_NO;
	}

	public String getSI_K_GOGEK_NO() {
		return SI_K_GOGEK_NO;
	}

	public void setSI_K_GOGEK_NO(String sI_K_GOGEK_NO) {
		SI_K_GOGEK_NO = sI_K_GOGEK_NO;
	}

	public String getPREV_UD_FK_POLI_NO() {
		return PREV_UD_FK_POLI_NO;
	}

	public void setPREV_UD_FK_POLI_NO(String pREV_UD_FK_POLI_NO) {
		PREV_UD_FK_POLI_NO = pREV_UD_FK_POLI_NO;
	}

	public String getPage() {
		return page;
	}

	public void setPage(String page) {
		this.page = page;
	}

	public String getSeq_no() {
		return seq_no;
	}

	public void setSeq_no(String seq_no) {
		this.seq_no = seq_no;
	}

	public String getInhab_no() {
		return inhab_no;
	}

	public void setInhab_no(String inhab_no) {
		this.inhab_no = inhab_no;
	}

	public String getSpew_dstin_cd() {
		return spew_dstin_cd;
	}

	public void setSpew_dstin_cd(String spew_dstin_cd) {
		this.spew_dstin_cd = spew_dstin_cd;
	}

	public String getJob_dstin_cd() {
		return job_dstin_cd;
	}

	public void setJob_dstin_cd(String job_dstin_cd) {
		this.job_dstin_cd = job_dstin_cd;
	}

	public String getAccid_rcept_no() {
		return accid_rcept_no;
	}

	public void setAccid_rcept_no(String accid_rcept_no) {
		this.accid_rcept_no = accid_rcept_no;
	}

	public String getProgr_dstin_cd() {
		return progr_dstin_cd;
	}

	public void setProgr_dstin_cd(String progr_dstin_cd) {
		this.progr_dstin_cd = progr_dstin_cd;
	}

	public String getCar_no() {
		return car_no;
	}

	public void setCar_no(String car_no) {
		this.car_no = car_no;
	}

	public String getAccid_day() {
		return accid_day;
	}

	public void setAccid_day(String accid_day) {
		this.accid_day = accid_day;
	}

	public String getConsl_lclas_rcept_no() {
		return consl_lclas_rcept_no;
	}

	public void setConsl_lclas_rcept_no(String consl_lclas_rcept_no) {
		this.consl_lclas_rcept_no = consl_lclas_rcept_no;
	}

	public String getConsl_rcept_no() {
		return consl_rcept_no;
	}

	public void setConsl_rcept_no(String consl_rcept_no) {
		this.consl_rcept_no = consl_rcept_no;
	}

	public String getConsl_rcept_seq_no() {
		return consl_rcept_seq_no;
	}

	public void setConsl_rcept_seq_no(String consl_rcept_seq_no) {
		this.consl_rcept_seq_no = consl_rcept_seq_no;
	}

	public String getConsl_type_name() {
		return consl_type_name;
	}

	public void setConsl_type_name(String consl_type_name) {
		this.consl_type_name = consl_type_name;
	}

	public String getAccid_type_cd() {
		return accid_type_cd;
	}

	public void setAccid_type_cd(String accid_type_cd) {
		this.accid_type_cd = accid_type_cd;
	}

	public String getAccid_cause_cd() {
		return accid_cause_cd;
	}

	public void setAccid_cause_cd(String accid_cause_cd) {
		this.accid_cause_cd = accid_cause_cd;
	}

	public String getEtc_1_cd() {
		return etc_1_cd;
	}

	public void setEtc_1_cd(String etc_1_cd) {
		this.etc_1_cd = etc_1_cd;
	}

	public String getEtc_2_cd() {
		return etc_2_cd;
	}

	public void setEtc_2_cd(String etc_2_cd) {
		this.etc_2_cd = etc_2_cd;
	}

	public String getEtc_3_cd() {
		return etc_3_cd;
	}

	public void setEtc_3_cd(String etc_3_cd) {
		this.etc_3_cd = etc_3_cd;
	}

	public String getEtc_4_cd() {
		return etc_4_cd;
	}

	public void setEtc_4_cd(String etc_4_cd) {
		this.etc_4_cd = etc_4_cd;
	}

	public String getEtc_5_cd() {
		return etc_5_cd;
	}

	public void setEtc_5_cd(String etc_5_cd) {
		this.etc_5_cd = etc_5_cd;
	}

	public String getNext_mode() {
		return next_mode;
	}

	public void setNext_mode(String next_mode) {
		this.next_mode = next_mode;
	}

	public String getNext_action() {
		return next_action;
	}

	public void setNext_action(String next_action) {
		this.next_action = next_action;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCarnum() {
		return carnum;
	}

	public void setCarnum(String carnum) {
		this.carnum = carnum;
	}

	public String getIns() {
		return ins;
	}

	public void setIns(String ins) {
		this.ins = ins;
	}

	public String getFrom() {
		return from;
	}

	public void setFrom(String from) {
		this.from = from;
	}

	public String getTo() {
		return to;
	}

	public void setTo(String to) {
		this.to = to;
	}

	public String getF_id() {
		return f_id;
	}

	public void setF_id(String f_id) {
		this.f_id = f_id;
	}

	public String getTab() {
		return tab;
	}

	public void setTab(String tab) {
		this.tab = tab;
	}

	public String getModeType() {
		return modeType;
	}

	public void setModeType(String modeType) {
		this.modeType = modeType;
	}

	public String getAgree01() {
		return agree01;
	}

	public void setAgree01(String agree01) {
		this.agree01 = agree01;
	}

	public String getAgree02() {
		return agree02;
	}

	public void setAgree02(String agree02) {
		this.agree02 = agree02;
	}

	public String getAgree03() {
		return agree03;
	}

	public void setAgree03(String agree03) {
		this.agree03 = agree03;
	}

	public String getAgree04() {
		return agree04;
	}

	public void setAgree04(String agree04) {
		this.agree04 = agree04;
	}

	public String getAgree05() {
		return agree05;
	}

	public void setAgree05(String agree05) {
		this.agree05 = agree05;
	}

	public String getDocType() {
		return docType;
	}

	public void setDocType(String docType) {
		this.docType = docType;
	}
	
	public String getProgr_dstin_cd_nm() {
		return progr_dstin_cd_nm;
	}

	public void setProgr_dstin_cd_nm(String progr_dstin_cd_nm) {
		this.progr_dstin_cd_nm = progr_dstin_cd_nm;
	}

	//저장된 증권번호중 이전 페이지 증권번호를 구하고 문자열에서 삭제한다.
    public String getPrevFK_POLI_NO(){
		int lastidx = this.PREV_UD_FK_POLI_NO.lastIndexOf(",");
		String result = this.PREV_UD_FK_POLI_NO.substring(lastidx + 1);
		this.PREV_UD_FK_POLI_NO = this.PREV_UD_FK_POLI_NO.substring(0, lastidx);
		
		return result;
	}    

	/**
	 * @return the accd_rpt_dt
	 */
	public String getAccd_rpt_dt() {
		return accd_rpt_dt;
	}

	/**
	 * @param accd_rpt_dt the accd_rpt_dt to set
	 */
	public void setAccd_rpt_dt(String accd_rpt_dt) {
		this.accd_rpt_dt = accd_rpt_dt;
	}
	
	/**
	 * @return the accd_oj_dvcd
	 */
	public String getAccd_oj_dvcd() {
		return accd_oj_dvcd;
	}

	/**
	 * @param accd_oj_dvcd the accd_oj_dvcd to set
	 */
	public void setAccd_oj_dvcd(String accd_oj_dvcd) {
		this.accd_oj_dvcd = accd_oj_dvcd;
	}

	/**
	 * @return the accd_oj_rnk
	 */
	public String getAccd_oj_rnk() {
		return accd_oj_rnk;
	}

	/**
	 * @param accd_oj_rnk the accd_oj_rnk to set
	 */
	public void setAccd_oj_rnk(String accd_oj_rnk) {
		this.accd_oj_rnk = accd_oj_rnk;
	}	
}
