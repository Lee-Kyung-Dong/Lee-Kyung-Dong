package com.idongbu.smartcustomer.vo;

import com.idongbu.common.vo.CMMVO;

// 통합고객센터
public class CmmFBM0531RVO extends CMMVO {
	
	public CmmFBM0531RVO() {
		super.setPGMID(this.proid);
		super.setTRID(this.trid);
	}	
	
	public static final String proid		= "FBM0531R";
	public static final String trid		= "BMKU";
	public String rURL						= "";

	// 공통                             
	private String COMM_CHANNEL         = "";
	private String COMM_UNIQUE_KEY      = "";
	private String COMM_PGMID           = "";
	private String COMM_PROC_GB         = "";
	private String COMM_ACTION_KEY      = "";
	private String COMM_USER_GB         = "";
	private String COMM_USER_ID         = "";
	private String COMM_JIJUM_CD        = "";
	private String COMM_JIBU_CD         = "";
	private String COMM_PROTOCOL        = "";
	private String COMM_COND_CD         = "";
	private String COMM_LAST_FLAG       = "";
	private String COMM_CURSOR_MAP      = "";
	private String COMM_CURSOR_IDX      = "";
	private String COMM_MESSAGE_CD      = "";
	private String HOMM_MESSAGE_NM      = "";
	private String COMM_ERR_NAME        = "";
	private String COMM_ERR_TEXT        = "";
	private String COMM_SYS_CODE        = "";
	private String COMM_FILLER          = "";
	private String SCREEN_DATA_AREA     = "";
	private String SCR_KEY              = "";
	
	// 입력                            
	private String SI_K_CHANNEL_GB      = "";
	private String SI_K_PA_CD           = "";
	private String SI_K_GOGEK_NO        = "";
	private String SI_K_AGREE_YN1       = "";
	private String SI_K_AGREE_YN2       = "";
	private String SI_K_AGREE_YMD       = "";
	private String SI_K_AGREE_INFO      = "";
	private String SI_K_AGREE_MET_GB    = "";
	private String SI_K_FILLER          = "";
	public String getrURL() {
		return rURL;
	}
	public void setrURL(String rURL) {
		this.rURL = rURL;
	}
	public String getCOMM_CHANNEL() {
		return COMM_CHANNEL;
	}
	public void setCOMM_CHANNEL(String cOMM_CHANNEL) {
		COMM_CHANNEL = cOMM_CHANNEL;
	}
	public String getCOMM_UNIQUE_KEY() {
		return COMM_UNIQUE_KEY;
	}
	public void setCOMM_UNIQUE_KEY(String cOMM_UNIQUE_KEY) {
		COMM_UNIQUE_KEY = cOMM_UNIQUE_KEY;
	}
	public String getCOMM_PGMID() {
		return COMM_PGMID;
	}
	public void setCOMM_PGMID(String cOMM_PGMID) {
		COMM_PGMID = cOMM_PGMID;
	}
	public String getCOMM_PROC_GB() {
		return COMM_PROC_GB;
	}
	public void setCOMM_PROC_GB(String cOMM_PROC_GB) {
		COMM_PROC_GB = cOMM_PROC_GB;
	}
	public String getCOMM_ACTION_KEY() {
		return COMM_ACTION_KEY;
	}
	public void setCOMM_ACTION_KEY(String cOMM_ACTION_KEY) {
		COMM_ACTION_KEY = cOMM_ACTION_KEY;
	}
	public String getCOMM_USER_GB() {
		return COMM_USER_GB;
	}
	public void setCOMM_USER_GB(String cOMM_USER_GB) {
		COMM_USER_GB = cOMM_USER_GB;
	}
	public String getCOMM_USER_ID() {
		return COMM_USER_ID;
	}
	public void setCOMM_USER_ID(String cOMM_USER_ID) {
		COMM_USER_ID = cOMM_USER_ID;
	}
	public String getCOMM_JIJUM_CD() {
		return COMM_JIJUM_CD;
	}
	public void setCOMM_JIJUM_CD(String cOMM_JIJUM_CD) {
		COMM_JIJUM_CD = cOMM_JIJUM_CD;
	}
	public String getCOMM_JIBU_CD() {
		return COMM_JIBU_CD;
	}
	public void setCOMM_JIBU_CD(String cOMM_JIBU_CD) {
		COMM_JIBU_CD = cOMM_JIBU_CD;
	}
	public String getCOMM_PROTOCOL() {
		return COMM_PROTOCOL;
	}
	public void setCOMM_PROTOCOL(String cOMM_PROTOCOL) {
		COMM_PROTOCOL = cOMM_PROTOCOL;
	}
	public String getCOMM_COND_CD() {
		return COMM_COND_CD;
	}
	public void setCOMM_COND_CD(String cOMM_COND_CD) {
		COMM_COND_CD = cOMM_COND_CD;
	}
	public String getCOMM_LAST_FLAG() {
		return COMM_LAST_FLAG;
	}
	public void setCOMM_LAST_FLAG(String cOMM_LAST_FLAG) {
		COMM_LAST_FLAG = cOMM_LAST_FLAG;
	}
	public String getCOMM_CURSOR_MAP() {
		return COMM_CURSOR_MAP;
	}
	public void setCOMM_CURSOR_MAP(String cOMM_CURSOR_MAP) {
		COMM_CURSOR_MAP = cOMM_CURSOR_MAP;
	}
	public String getCOMM_CURSOR_IDX() {
		return COMM_CURSOR_IDX;
	}
	public void setCOMM_CURSOR_IDX(String cOMM_CURSOR_IDX) {
		COMM_CURSOR_IDX = cOMM_CURSOR_IDX;
	}
	public String getCOMM_MESSAGE_CD() {
		return COMM_MESSAGE_CD;
	}
	public void setCOMM_MESSAGE_CD(String cOMM_MESSAGE_CD) {
		COMM_MESSAGE_CD = cOMM_MESSAGE_CD;
	}
	public String getHOMM_MESSAGE_NM() {
		return HOMM_MESSAGE_NM;
	}
	public void setHOMM_MESSAGE_NM(String hOMM_MESSAGE_NM) {
		HOMM_MESSAGE_NM = hOMM_MESSAGE_NM;
	}
	public String getCOMM_ERR_NAME() {
		return COMM_ERR_NAME;
	}
	public void setCOMM_ERR_NAME(String cOMM_ERR_NAME) {
		COMM_ERR_NAME = cOMM_ERR_NAME;
	}
	public String getCOMM_ERR_TEXT() {
		return COMM_ERR_TEXT;
	}
	public void setCOMM_ERR_TEXT(String cOMM_ERR_TEXT) {
		COMM_ERR_TEXT = cOMM_ERR_TEXT;
	}
	public String getCOMM_SYS_CODE() {
		return COMM_SYS_CODE;
	}
	public void setCOMM_SYS_CODE(String cOMM_SYS_CODE) {
		COMM_SYS_CODE = cOMM_SYS_CODE;
	}
	public String getCOMM_FILLER() {
		return COMM_FILLER;
	}
	public void setCOMM_FILLER(String cOMM_FILLER) {
		COMM_FILLER = cOMM_FILLER;
	}
	public String getSCREEN_DATA_AREA() {
		return SCREEN_DATA_AREA;
	}
	public void setSCREEN_DATA_AREA(String sCREEN_DATA_AREA) {
		SCREEN_DATA_AREA = sCREEN_DATA_AREA;
	}
	public String getSCR_KEY() {
		return SCR_KEY;
	}
	public void setSCR_KEY(String sCR_KEY) {
		SCR_KEY = sCR_KEY;
	}
	public String getSI_K_CHANNEL_GB() {
		return SI_K_CHANNEL_GB;
	}
	public void setSI_K_CHANNEL_GB(String sI_K_CHANNEL_GB) {
		SI_K_CHANNEL_GB = sI_K_CHANNEL_GB;
	}
	public String getSI_K_PA_CD() {
		return SI_K_PA_CD;
	}
	public void setSI_K_PA_CD(String sI_K_PA_CD) {
		SI_K_PA_CD = sI_K_PA_CD;
	}
	public String getSI_K_GOGEK_NO() {
		return SI_K_GOGEK_NO;
	}
	public void setSI_K_GOGEK_NO(String sI_K_GOGEK_NO) {
		SI_K_GOGEK_NO = sI_K_GOGEK_NO;
	}
	public String getSI_K_AGREE_YN1() {
		return SI_K_AGREE_YN1;
	}
	public void setSI_K_AGREE_YN1(String sI_K_AGREE_YN1) {
		SI_K_AGREE_YN1 = sI_K_AGREE_YN1;
	}
	public String getSI_K_AGREE_YN2() {
		return SI_K_AGREE_YN2;
	}
	public void setSI_K_AGREE_YN2(String sI_K_AGREE_YN2) {
		SI_K_AGREE_YN2 = sI_K_AGREE_YN2;
	}
	public String getSI_K_AGREE_YMD() {
		return SI_K_AGREE_YMD;
	}
	public void setSI_K_AGREE_YMD(String sI_K_AGREE_YMD) {
		SI_K_AGREE_YMD = sI_K_AGREE_YMD;
	}
	public String getSI_K_AGREE_INFO() {
		return SI_K_AGREE_INFO;
	}
	public void setSI_K_AGREE_INFO(String sI_K_AGREE_INFO) {
		SI_K_AGREE_INFO = sI_K_AGREE_INFO;
	}
	public String getSI_K_AGREE_MET_GB() {
		return SI_K_AGREE_MET_GB;
	}
	public void setSI_K_AGREE_MET_GB(String sI_K_AGREE_MET_GB) {
		SI_K_AGREE_MET_GB = sI_K_AGREE_MET_GB;
	}
	public String getSI_K_FILLER() {
		return SI_K_FILLER;
	}
	public void setSI_K_FILLER(String sI_K_FILLER) {
		SI_K_FILLER = sI_K_FILLER;
	}
	
}
