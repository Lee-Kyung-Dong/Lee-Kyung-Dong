package com.idongbu.smartcustomer.vo;

import java.util.List;

public class SubFGZ5920SVO {
	public List<SubFGZ5920STBLVO> LK_GZ5920_TBL = null;
	public String LK_SUM_BUNNAP			    	= null;

	public List<SubFGZ5920STBLVO> getLK_GZ5920_TBL() {
		return LK_GZ5920_TBL;
	}
	public void setLK_GZ5920_TBL(List<SubFGZ5920STBLVO> lK_GZ5920_TBL) {
		LK_GZ5920_TBL = lK_GZ5920_TBL;
	}
	public String getLK_SUM_BUNNAP() {
		return LK_SUM_BUNNAP;
	}
	public void setLK_SUM_BUNNAP(String lK_SUM_BUNNAP) {
		LK_SUM_BUNNAP = lK_SUM_BUNNAP;
	}
}
