package com.idongbu.smartcustomer.vo;

import java.util.List;
import java.util.Map;

import com.idongbu.common.vo.CMMVO;

public class CmmFRH5003RVO extends CMMVO {
	
	public CmmFRH5003RVO() {
		super.setPGMID(this.proid);
		super.setTRID(this.trid);
	}	
	
	private static final String proid = "FRH5003R";
	private static final String trid  = "RHK2";
	private String rURL				  = "";
	
	private String CC_CHANNEL		  = "";
	private String CC_UKEY		      = "";
	private String CC_PGMID		      = "";
	private String CC_PROC_GB		  = "";
	private String CC_FUN_KEY		  = "";
	private String CC_USER_GB		  = "";
	private String CC_USER_CD		  = "";
	private String CC_JIJUM_CD		  = "";
	private String CC_JIBU_CD		  = "";
	private String CC_PROTOCOL		  = "";
	private String CC_COND_CD		  = "";
	private String CC_LAST_FLAG		  = "";
	private String CC_CURSOR_MAP      = "";
	private String CC_CURSOR_IDX      = "";
	private String CC_MESSAGE_CD      = "";
	private String HC_MESSAGE_NM      = "";
	private String CC_SYS_ERR		  = "";
	private String CC_FILLER		  = "";
	private String SS_JOGUN		      = "";
	private String SS_JOGUN_NO		  = "";
	private String SS_SAGO_JUBSU_NO	  = "";
	private String SS_SAGO_JUBSU_SEQ  = "";
	private String SS_DUNGGB		  = "";
	private String HS_DUNGGB		  = "";
	private String SS_USU_CD		  = "";
	private String SS_CONSULTANT	  = "";
	private String SS_H_CNT		      = "";
	private String SS_H_PAGE		  = "";
	private String SS_H_T_PAGE		  = "";
//	private String[] SS_CHECK_YN	  = new String[0]; // 10
//	private String[] SS_POLI_NO		  = new String[0]; // 10
//	private String[] SS_BESU_NO		  = new String[0]; // 10
//	private String[] SS_BOJ_GB		  = new String[0]; // 10
//	private String[] SS_HWAKJUNG_YN	  = new String[0]; // 10
//	private String[] SS_BJ_CD		  = new String[0]; // 10
//	private String[] HS_BJ_NM		  = new String[0]; // 10
//	private String[] SS_JOJIKWON	  = new String[0]; // 10
//	private String[] HS_JOJIKWON	  = new String[0]; // 10
//	private String[] SS_DBRT		  = new String[0]; // 10
	private List<Map<String, String>> LOOP_DATA = null;
	private String UUC_INQ_GYEYAK_SEQ = "";
	private String UUC_F_GYEYAK_SEQ	  = "";
	private String UUC_L_GYEYAK_SEQ	  = "";
	private String BB_ST_PATH		  = "";
	private String BB_TERM_ID		  = "";
	private String BB_MAP_ID		  = "";
	private String BB_JOGUN		      = "";
	private String BB_JOGUN_NO		  = "";
	private String BB_SAGO_JUBSU_NO	  = "";
	private String BB_SAGO_JUBSU_SEQ  = "";
	private String BB_SAGO_MOKJUK_GB  = "";
	private String BB_SAGO_MOKJUK_SEQ = "";
	private String BB_LAST_JUBSU_SEQ  = "";
	private String BB_INMUL		      = "";
	private String BB_IN_CNT		  = "";
	private String BB_JAEMUL_CNT	  = "";
	private String BB_DEIN_CNT		  = "";
	private String BB_DAEMUL_CNT      = "";
	private String BB_SAGO_DAMBO      = "";
	private String BB_GOGEK_GB		  = "";
	private String BB_GOGEK_NO		  = "";
	
	public String getrURL() {
		return rURL;
	}
	public void setrURL(String rURL) {
		this.rURL = rURL;
	}
	public String getCC_CHANNEL() {
		return CC_CHANNEL;
	}
	public void setCC_CHANNEL(String cC_CHANNEL) {
		CC_CHANNEL = cC_CHANNEL;
	}
	public String getCC_UKEY() {
		return CC_UKEY;
	}
	public void setCC_UKEY(String cC_UKEY) {
		CC_UKEY = cC_UKEY;
	}
	public String getCC_PGMID() {
		return CC_PGMID;
	}
	public void setCC_PGMID(String cC_PGMID) {
		CC_PGMID = cC_PGMID;
	}
	public String getCC_PROC_GB() {
		return CC_PROC_GB;
	}
	public void setCC_PROC_GB(String cC_PROC_GB) {
		CC_PROC_GB = cC_PROC_GB;
	}
	public String getCC_FUN_KEY() {
		return CC_FUN_KEY;
	}
	public void setCC_FUN_KEY(String cC_FUN_KEY) {
		CC_FUN_KEY = cC_FUN_KEY;
	}
	public String getCC_USER_GB() {
		return CC_USER_GB;
	}
	public void setCC_USER_GB(String cC_USER_GB) {
		CC_USER_GB = cC_USER_GB;
	}
	public String getCC_USER_CD() {
		return CC_USER_CD;
	}
	public void setCC_USER_CD(String cC_USER_CD) {
		CC_USER_CD = cC_USER_CD;
	}
	public String getCC_JIJUM_CD() {
		return CC_JIJUM_CD;
	}
	public void setCC_JIJUM_CD(String cC_JIJUM_CD) {
		CC_JIJUM_CD = cC_JIJUM_CD;
	}
	public String getCC_JIBU_CD() {
		return CC_JIBU_CD;
	}
	public void setCC_JIBU_CD(String cC_JIBU_CD) {
		CC_JIBU_CD = cC_JIBU_CD;
	}
	public String getCC_PROTOCOL() {
		return CC_PROTOCOL;
	}
	public void setCC_PROTOCOL(String cC_PROTOCOL) {
		CC_PROTOCOL = cC_PROTOCOL;
	}
	public String getCC_COND_CD() {
		return CC_COND_CD;
	}
	public void setCC_COND_CD(String cC_COND_CD) {
		CC_COND_CD = cC_COND_CD;
	}
	public String getCC_LAST_FLAG() {
		return CC_LAST_FLAG;
	}
	public void setCC_LAST_FLAG(String cC_LAST_FLAG) {
		CC_LAST_FLAG = cC_LAST_FLAG;
	}
	public String getCC_CURSOR_MAP() {
		return CC_CURSOR_MAP;
	}
	public void setCC_CURSOR_MAP(String cC_CURSOR_MAP) {
		CC_CURSOR_MAP = cC_CURSOR_MAP;
	}
	public String getCC_CURSOR_IDX() {
		return CC_CURSOR_IDX;
	}
	public void setCC_CURSOR_IDX(String cC_CURSOR_IDX) {
		CC_CURSOR_IDX = cC_CURSOR_IDX;
	}
	public String getCC_MESSAGE_CD() {
		return CC_MESSAGE_CD;
	}
	public void setCC_MESSAGE_CD(String cC_MESSAGE_CD) {
		CC_MESSAGE_CD = cC_MESSAGE_CD;
	}
	public String getHC_MESSAGE_NM() {
		return HC_MESSAGE_NM;
	}
	public void setHC_MESSAGE_NM(String hC_MESSAGE_NM) {
		HC_MESSAGE_NM = hC_MESSAGE_NM;
	}
	public String getCC_SYS_ERR() {
		return CC_SYS_ERR;
	}
	public void setCC_SYS_ERR(String cC_SYS_ERR) {
		CC_SYS_ERR = cC_SYS_ERR;
	}
	public String getCC_FILLER() {
		return CC_FILLER;
	}
	public void setCC_FILLER(String cC_FILLER) {
		CC_FILLER = cC_FILLER;
	}
	public String getSS_JOGUN() {
		return SS_JOGUN;
	}
	public void setSS_JOGUN(String sS_JOGUN) {
		SS_JOGUN = sS_JOGUN;
	}
	public String getSS_JOGUN_NO() {
		return SS_JOGUN_NO;
	}
	public void setSS_JOGUN_NO(String sS_JOGUN_NO) {
		SS_JOGUN_NO = sS_JOGUN_NO;
	}
	public String getSS_SAGO_JUBSU_NO() {
		return SS_SAGO_JUBSU_NO;
	}
	public void setSS_SAGO_JUBSU_NO(String sS_SAGO_JUBSU_NO) {
		SS_SAGO_JUBSU_NO = sS_SAGO_JUBSU_NO;
	}
	public String getSS_SAGO_JUBSU_SEQ() {
		return SS_SAGO_JUBSU_SEQ;
	}
	public void setSS_SAGO_JUBSU_SEQ(String sS_SAGO_JUBSU_SEQ) {
		SS_SAGO_JUBSU_SEQ = sS_SAGO_JUBSU_SEQ;
	}
	public String getSS_DUNGGB() {
		return SS_DUNGGB;
	}
	public void setSS_DUNGGB(String sS_DUNGGB) {
		SS_DUNGGB = sS_DUNGGB;
	}
	public String getHS_DUNGGB() {
		return HS_DUNGGB;
	}
	public void setHS_DUNGGB(String hS_DUNGGB) {
		HS_DUNGGB = hS_DUNGGB;
	}
	public String getSS_USU_CD() {
		return SS_USU_CD;
	}
	public void setSS_USU_CD(String sS_USU_CD) {
		SS_USU_CD = sS_USU_CD;
	}
	public String getSS_CONSULTANT() {
		return SS_CONSULTANT;
	}
	public void setSS_CONSULTANT(String sS_CONSULTANT) {
		SS_CONSULTANT = sS_CONSULTANT;
	}
	public String getSS_H_CNT() {
		return SS_H_CNT;
	}
	public void setSS_H_CNT(String sS_H_CNT) {
		SS_H_CNT = sS_H_CNT;
	}
	public String getSS_H_PAGE() {
		return SS_H_PAGE;
	}
	public void setSS_H_PAGE(String sS_H_PAGE) {
		SS_H_PAGE = sS_H_PAGE;
	}
	public String getSS_H_T_PAGE() {
		return SS_H_T_PAGE;
	}
	public void setSS_H_T_PAGE(String sS_H_T_PAGE) {
		SS_H_T_PAGE = sS_H_T_PAGE;
	}
//	public String[] getSS_CHECK_YN() {
//		return SS_CHECK_YN;
//	}
//	public void setSS_CHECK_YN(String[] sS_CHECK_YN) {
//		SS_CHECK_YN = sS_CHECK_YN;
//	}
//	public String[] getSS_POLI_NO() {
//		return SS_POLI_NO;
//	}
//	public void setSS_POLI_NO(String[] sS_POLI_NO) {
//		SS_POLI_NO = sS_POLI_NO;
//	}
//	public String[] getSS_BESU_NO() {
//		return SS_BESU_NO;
//	}
//	public void setSS_BESU_NO(String[] sS_BESU_NO) {
//		SS_BESU_NO = sS_BESU_NO;
//	}
//	public String[] getSS_BOJ_GB() {
//		return SS_BOJ_GB;
//	}
//	public void setSS_BOJ_GB(String[] sS_BOJ_GB) {
//		SS_BOJ_GB = sS_BOJ_GB;
//	}
//	public String[] getSS_HWAKJUNG_YN() {
//		return SS_HWAKJUNG_YN;
//	}
//	public void setSS_HWAKJUNG_YN(String[] sS_HWAKJUNG_YN) {
//		SS_HWAKJUNG_YN = sS_HWAKJUNG_YN;
//	}
//	public String[] getSS_BJ_CD() {
//		return SS_BJ_CD;
//	}
//	public void setSS_BJ_CD(String[] sS_BJ_CD) {
//		SS_BJ_CD = sS_BJ_CD;
//	}
//	public String[] getHS_BJ_NM() {
//		return HS_BJ_NM;
//	}
//	public void setHS_BJ_NM(String[] hS_BJ_NM) {
//		HS_BJ_NM = hS_BJ_NM;
//	}
//	public String[] getSS_JOJIKWON() {
//		return SS_JOJIKWON;
//	}
//	public void setSS_JOJIKWON(String[] sS_JOJIKWON) {
//		SS_JOJIKWON = sS_JOJIKWON;
//	}
//	public String[] getHS_JOJIKWON() {
//		return HS_JOJIKWON;
//	}
//	public void setHS_JOJIKWON(String[] hS_JOJIKWON) {
//		HS_JOJIKWON = hS_JOJIKWON;
//	}
//	public String[] getSS_DBRT() {
//		return SS_DBRT;
//	}
//	public void setSS_DBRT(String[] sS_DBRT) {
//		SS_DBRT = sS_DBRT;
//	}
	public List<Map<String, String>> getLOOP_DATA() {
		return LOOP_DATA;
	}
	public void setLOOP_DATA(List<Map<String, String>> lOOP_DATA) {
		LOOP_DATA = lOOP_DATA;
	}		
	public String getUUC_INQ_GYEYAK_SEQ() {
		return UUC_INQ_GYEYAK_SEQ;
	}
	public void setUUC_INQ_GYEYAK_SEQ(String uUC_INQ_GYEYAK_SEQ) {
		UUC_INQ_GYEYAK_SEQ = uUC_INQ_GYEYAK_SEQ;
	}
	public String getUUC_F_GYEYAK_SEQ() {
		return UUC_F_GYEYAK_SEQ;
	}
	public void setUUC_F_GYEYAK_SEQ(String uUC_F_GYEYAK_SEQ) {
		UUC_F_GYEYAK_SEQ = uUC_F_GYEYAK_SEQ;
	}
	public String getUUC_L_GYEYAK_SEQ() {
		return UUC_L_GYEYAK_SEQ;
	}
	public void setUUC_L_GYEYAK_SEQ(String uUC_L_GYEYAK_SEQ) {
		UUC_L_GYEYAK_SEQ = uUC_L_GYEYAK_SEQ;
	}
	public String getBB_ST_PATH() {
		return BB_ST_PATH;
	}
	public void setBB_ST_PATH(String bB_ST_PATH) {
		BB_ST_PATH = bB_ST_PATH;
	}
	public String getBB_TERM_ID() {
		return BB_TERM_ID;
	}
	public void setBB_TERM_ID(String bB_TERM_ID) {
		BB_TERM_ID = bB_TERM_ID;
	}
	public String getBB_MAP_ID() {
		return BB_MAP_ID;
	}
	public void setBB_MAP_ID(String bB_MAP_ID) {
		BB_MAP_ID = bB_MAP_ID;
	}
	public String getBB_JOGUN() {
		return BB_JOGUN;
	}
	public void setBB_JOGUN(String bB_JOGUN) {
		BB_JOGUN = bB_JOGUN;
	}
	public String getBB_JOGUN_NO() {
		return BB_JOGUN_NO;
	}
	public void setBB_JOGUN_NO(String bB_JOGUN_NO) {
		BB_JOGUN_NO = bB_JOGUN_NO;
	}
	public String getBB_SAGO_JUBSU_NO() {
		return BB_SAGO_JUBSU_NO;
	}
	public void setBB_SAGO_JUBSU_NO(String bB_SAGO_JUBSU_NO) {
		BB_SAGO_JUBSU_NO = bB_SAGO_JUBSU_NO;
	}
	public String getBB_SAGO_JUBSU_SEQ() {
		return BB_SAGO_JUBSU_SEQ;
	}
	public void setBB_SAGO_JUBSU_SEQ(String bB_SAGO_JUBSU_SEQ) {
		BB_SAGO_JUBSU_SEQ = bB_SAGO_JUBSU_SEQ;
	}
	public String getBB_SAGO_MOKJUK_GB() {
		return BB_SAGO_MOKJUK_GB;
	}
	public void setBB_SAGO_MOKJUK_GB(String bB_SAGO_MOKJUK_GB) {
		BB_SAGO_MOKJUK_GB = bB_SAGO_MOKJUK_GB;
	}
	public String getBB_SAGO_MOKJUK_SEQ() {
		return BB_SAGO_MOKJUK_SEQ;
	}
	public void setBB_SAGO_MOKJUK_SEQ(String bB_SAGO_MOKJUK_SEQ) {
		BB_SAGO_MOKJUK_SEQ = bB_SAGO_MOKJUK_SEQ;
	}
	public String getBB_LAST_JUBSU_SEQ() {
		return BB_LAST_JUBSU_SEQ;
	}
	public void setBB_LAST_JUBSU_SEQ(String bB_LAST_JUBSU_SEQ) {
		BB_LAST_JUBSU_SEQ = bB_LAST_JUBSU_SEQ;
	}
	public String getBB_INMUL() {
		return BB_INMUL;
	}
	public void setBB_INMUL(String bB_INMUL) {
		BB_INMUL = bB_INMUL;
	}
	public String getBB_IN_CNT() {
		return BB_IN_CNT;
	}
	public void setBB_IN_CNT(String bB_IN_CNT) {
		BB_IN_CNT = bB_IN_CNT;
	}
	public String getBB_JAEMUL_CNT() {
		return BB_JAEMUL_CNT;
	}
	public void setBB_JAEMUL_CNT(String bB_JAEMUL_CNT) {
		BB_JAEMUL_CNT = bB_JAEMUL_CNT;
	}
	public String getBB_DEIN_CNT() {
		return BB_DEIN_CNT;
	}
	public void setBB_DEIN_CNT(String bB_DEIN_CNT) {
		BB_DEIN_CNT = bB_DEIN_CNT;
	}
	public String getBB_DAEMUL_CNT() {
		return BB_DAEMUL_CNT;
	}
	public void setBB_DAEMUL_CNT(String bB_DAEMUL_CNT) {
		BB_DAEMUL_CNT = bB_DAEMUL_CNT;
	}
	public String getBB_SAGO_DAMBO() {
		return BB_SAGO_DAMBO;
	}
	public void setBB_SAGO_DAMBO(String bB_SAGO_DAMBO) {
		BB_SAGO_DAMBO = bB_SAGO_DAMBO;
	}
	public String getBB_GOGEK_GB() {
		return BB_GOGEK_GB;
	}
	public void setBB_GOGEK_GB(String bB_GOGEK_GB) {
		BB_GOGEK_GB = bB_GOGEK_GB;
	}
	public String getBB_GOGEK_NO() {
		return BB_GOGEK_NO;
	}
	public void setBB_GOGEK_NO(String bB_GOGEK_NO) {
		BB_GOGEK_NO = bB_GOGEK_NO;
	}
	public static String getProid() {
		return proid;
	}
	public static String getTrid() {
		return trid;
	}		
}
