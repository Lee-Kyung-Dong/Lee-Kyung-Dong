package com.idongbu.smartcustomer.vo;

public class MemJoinVO {
	public String fd_mb_pwd_enc	= "";	// 비밀번호

	// 폼변수
	public String reg_cert_yn		= "";
	public String fd_mb_jumin1		= "";
	public String fd_mb_jumin2		= "";
	public String fd_mb_jumin		= "";
	public String fd_mb_pwd1		= "";
	public String fd_mb_email1	= "";
	public String fd_mb_email2	= "";
	public String fd_mb_email   = "";
	public String fd_mb_mphone1 = "";
	public String fd_mb_mphone2 = "";
	public String fd_mb_mphone3 = "";
	public String fd_mb_hphone1 = "";
	public String fd_mb_hphone2 = "";
	public String fd_mb_hphone3 = "";
	public String fd_mb_cphone1 = "";
	public String fd_mb_cphone2 = "";
	public String fd_mb_cphone3 = "";
	public String fd_mb_name 	= "";
	public String parent_email1	= "";
	public String parent_email2	= "";
	public String parent_jumin1	= "";
	public String parent_jumin2	= "";
	public String parent_phone1	= "";
	public String parent_phone2	= "";
	public String parent_phone3	= "";
	public String fd_mb_bank_gb	= "";	//금융회원가입여부 추가(2009.03.17.yhj)
	public String fd_event_course = "";	//이벤트 통한 가입자 경로(2009.10.29.하재원)
	public String fd_mail_permission = "";
	public String fd_mb_temp_gb = "";
	public String fd_mb_no		= "";
	public String fd_post_state = "";
	public String fd_insu_tot   = "";
	
	public String gbn		= "";
	public String url		= "";
	public String chk_foreign	= "";
	public String nc_url_gbn	= "";	// 실명확인 실패후 돌아갈 URL구분, 1:일반회원, 2:PA
	public int nc_result_code	= 0;
	public String result_code	= "";
	public String y_jumin		= "";
	public String reg_course	= "";
	public String jijum	= "";
	public String pa_memb	= "";

	public String zip_no	= "";
	public String addr_text	= "";
	public String detl_addr_name	= "";
	
	// 추천경로관련
	public String qstnr_sel_cd	= "";
	public String stock_seq	= "";
	public String stock_name	= "";
	public String pa_name	= "";
	public String pa_emp_no	= "";
	public String qstnr_sel_txt = "";

	// 임시세션
	public String fd_mb_jumin_tmp	= "";
	public String fd_mb_name_tmp	= "";
	
	public String sabeon	= "";	// PA가입시 사번
	public String req_cert_gbn	= "";	// PA가입시 인증구분: 공인인증 1, 신용카드 2 
	
	/* 계약 확인 */
	public String  ssnUserJumin = ""; 
	public String  ssnUserName = ""; 
	
	public int  cntInsuTot = 0; //전체 계약 카운트

	public int  cntInsu1 = 0; //정상 계약 카운트
	public int  cntInsu2 = 0; //연체 계약 카운트
	public int  cntInsu3 = 0; //실효 계약 카운트

	public int  cntInsu4 = 0; //정상 자동차 계약 카운트
	public int  cntInsu5 = 0; //정상 장기 카운트
	public int  cntInsu6 = 0; //정상 일반 카운트
	
	public int  cntInsuNew = 0; //보험가입 30일 이내 건수

	public int  cntCarInsuDate = 0; //자동차 보험 만기 도래일 계산
	
	//	집전화
	public String  H_TEL1 = ""; 
	public String  H_TEL2 = ""; 
	public String  H_TEL3 = ""; 
	
	//	휴대폰
	public String  HP_TEL1 = ""; 
	public String  HP_TEL2 = ""; 
	public String  HP_TEL3 = ""; 

	//	집주소 
	public String  H_ZIP = ""; 
	public String  H_JUSO = ""; 
	public String  H_ADDR = ""; 

	//	이메일
	public String  EMAIL_ID = ""; 
	
	//계약조회 시 추가 조회 여부
	public String  chkNext = ""; 
	//계약조회 다음 페이징 용 데이터
	public String  UD_LK_POLI_NO = ""; 	
	/* 계약  확인 */
	
	public String bank_gbn = "";  // 공인인증 1. 신용카드 2. 일반회원 3.
	public String fd_mb_gbn = ""; // 금융회원 여부 임시 저장 금융Y 일반N 
	
	public String cert_err_no = "";
	public String cert_outmsg = "";
	
	public String type = "";		// type=f 인경우, 금융회원 가입 url 변경 
	
	
	// IPIN DB
	public String IPIN = ""; 			// IPIN 프로세스 Y,N
	public String IPIN_ENC_DATA = ""; 	// IPIN 암호화 데이터
	public String IPIN_CI = "";
	public String IPIN_DI = "";
	public String IPIN_VJUMIN = "";
	public String IPIN_CERT_DATE = "";
	
	public String prm_ssnMbBankGb = ""; // 2012차세대 수정, 회원가입 프로세스 변경, 2012.08.21 김소하
	
	// 2012 차세대 , 카드인증 방식 변경 
	public String RE_CARD_NO1	= "";
	public String RE_CARD_NO2	= "";
	public String RE_CARD_NO3	= "";
	public String RE_CARD_NO4	= "";
	public String RE_YUHYO_GIGAN_MM	= "";
	public String RE_YUHYO_GIGAN_YY	= "";
	public String enc_data = "";
	public String member_name = "";
	public String jumin1 = "";
	public String jumin2 = "";
	public String jumin = "";
	public String retMsg = "";
	public String retCode = "";
	public String idx_max = "";
	public String point = "";
	public String grade = "";
	public String errmsg = "";
	public String fd_mb_id = "";
	public String fd_mb_marketing_agree_gb = "";
	public String ipin_yn	= "";
	public String fd_business_gb = "";
	public String fd_sp_account_no = "";
	public String cl_cd = "";
	public String cd_name = "";
	public String si_email_susin_yn = "";
	public String si_email_id = "";
	public String channel = "";
	public String certInfo = "";
	public String expSdate = "";
	public String expEdate = "";
	
	public String getFd_mb_pwd_enc() {
		return fd_mb_pwd_enc;
	}
	public void setFd_mb_pwd_enc(String fd_mb_pwd_enc) {
		this.fd_mb_pwd_enc = fd_mb_pwd_enc;
	}
	public String getReg_cert_yn() {
		return reg_cert_yn;
	}
	public void setReg_cert_yn(String reg_cert_yn) {
		this.reg_cert_yn = reg_cert_yn;
	}
	public String getFd_mb_jumin1() {
		return fd_mb_jumin1;
	}
	public void setFd_mb_jumin1(String fd_mb_jumin1) {
		this.fd_mb_jumin1 = fd_mb_jumin1;
	}
	public String getFd_mb_jumin2() {
		return fd_mb_jumin2;
	}
	public void setFd_mb_jumin2(String fd_mb_jumin2) {
		this.fd_mb_jumin2 = fd_mb_jumin2;
	}
	public String getFd_mb_jumin() {
		return fd_mb_jumin;
	}
	public void setFd_mb_jumin(String fd_mb_jumin) {
		this.fd_mb_jumin = fd_mb_jumin;
	}
	public String getFd_mb_pwd1() {
		return fd_mb_pwd1;
	}
	public void setFd_mb_pwd1(String fd_mb_pwd1) {
		this.fd_mb_pwd1 = fd_mb_pwd1;
	}
	public String getFd_mb_email1() {
		return fd_mb_email1;
	}
	public void setFd_mb_email1(String fd_mb_email1) {
		this.fd_mb_email1 = fd_mb_email1;
	}
	public String getFd_mb_email2() {
		return fd_mb_email2;
	}
	public void setFd_mb_email2(String fd_mb_email2) {
		this.fd_mb_email2 = fd_mb_email2;
	}
	public String getParent_email1() {
		return parent_email1;
	}
	public void setParent_email1(String parent_email1) {
		this.parent_email1 = parent_email1;
	}
	public String getParent_email2() {
		return parent_email2;
	}
	public void setParent_email2(String parent_email2) {
		this.parent_email2 = parent_email2;
	}
	
	public String getFd_mb_email() {
		return fd_mb_email;
	}
	public void setFd_mb_email(String fd_mb_email) {
		this.fd_mb_email = fd_mb_email;
	}
	public String getParent_jumin1() {
		return parent_jumin1;
	}
	public void setParent_jumin1(String parent_jumin1) {
		this.parent_jumin1 = parent_jumin1;
	}
	public String getParent_jumin2() {
		return parent_jumin2;
	}
	public void setParent_jumin2(String parent_jumin2) {
		this.parent_jumin2 = parent_jumin2;
	}
	public String getParent_phone1() {
		return parent_phone1;
	}
	public void setParent_phone1(String parent_phone1) {
		this.parent_phone1 = parent_phone1;
	}
	public String getParent_phone2() {
		return parent_phone2;
	}
	public void setParent_phone2(String parent_phone2) {
		this.parent_phone2 = parent_phone2;
	}
	public String getParent_phone3() {
		return parent_phone3;
	}
	public void setParent_phone3(String parent_phone3) {
		this.parent_phone3 = parent_phone3;
	}
	public String getFd_mb_bank_gb() {
		return fd_mb_bank_gb;
	}
	public void setFd_mb_bank_gb(String fd_mb_bank_gb) {
		this.fd_mb_bank_gb = fd_mb_bank_gb;
	}
	public String getFd_event_course() {
		return fd_event_course;
	}
	public void setFd_event_course(String fd_event_course) {
		this.fd_event_course = fd_event_course;
	}
	public String getGbn() {
		return gbn;
	}
	public void setGbn(String gbn) {
		this.gbn = gbn;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getChk_foreign() {
		return chk_foreign;
	}
	public void setChk_foreign(String chk_foreign) {
		this.chk_foreign = chk_foreign;
	}
	public String getNc_url_gbn() {
		return nc_url_gbn;
	}
	public void setNc_url_gbn(String nc_url_gbn) {
		this.nc_url_gbn = nc_url_gbn;
	}
	public int getNc_result_code() {
		return nc_result_code;
	}
	public void setNc_result_code(int nc_result_code) {
		this.nc_result_code = nc_result_code;
	}
	public String getY_jumin() {
		return y_jumin;
	}
	public void setY_jumin(String y_jumin) {
		this.y_jumin = y_jumin;
	}
	public String getReg_course() {
		return reg_course;
	}
	public void setReg_course(String reg_course) {
		this.reg_course = reg_course;
	}
	public String getJijum() {
		return jijum;
	}
	public void setJijum(String jijum) {
		this.jijum = jijum;
	}
	public String getPa_memb() {
		return pa_memb;
	}
	public void setPa_memb(String pa_memb) {
		this.pa_memb = pa_memb;
	}
	public String getZip_no() {
		return zip_no;
	}
	public void setZip_no(String zip_no) {
		this.zip_no = zip_no;
	}
	public String getAddr_text() {
		return addr_text;
	}
	public void setAddr_text(String addr_text) {
		this.addr_text = addr_text;
	}
	public String getDetl_addr_name() {
		return detl_addr_name;
	}
	public void setDetl_addr_name(String detl_addr_name) {
		this.detl_addr_name = detl_addr_name;
	}
	public String getQstnr_sel_cd() {
		return qstnr_sel_cd;
	}
	public void setQstnr_sel_cd(String qstnr_sel_cd) {
		this.qstnr_sel_cd = qstnr_sel_cd;
	}
	public String getStock_seq() {
		return stock_seq;
	}
	public void setStock_seq(String stock_seq) {
		this.stock_seq = stock_seq;
	}
	public String getStock_name() {
		return stock_name;
	}
	public void setStock_name(String stock_name) {
		this.stock_name = stock_name;
	}
	public String getPa_name() {
		return pa_name;
	}
	public void setPa_name(String pa_name) {
		this.pa_name = pa_name;
	}
	public String getPa_emp_no() {
		return pa_emp_no;
	}
	public void setPa_emp_no(String pa_emp_no) {
		this.pa_emp_no = pa_emp_no;
	}
	public String getQstnr_sel_txt() {
		return qstnr_sel_txt;
	}
	public void setQstnr_sel_txt(String qstnr_sel_txt) {
		this.qstnr_sel_txt = qstnr_sel_txt;
	}
	public String getFd_mb_jumin_tmp() {
		return fd_mb_jumin_tmp;
	}
	public void setFd_mb_jumin_tmp(String fd_mb_jumin_tmp) {
		this.fd_mb_jumin_tmp = fd_mb_jumin_tmp;
	}
	public String getFd_mb_name_tmp() {
		return fd_mb_name_tmp;
	}
	public void setFd_mb_name_tmp(String fd_mb_name_tmp) {
		this.fd_mb_name_tmp = fd_mb_name_tmp;
	}
	public String getSabeon() {
		return sabeon;
	}
	public void setSabeon(String sabeon) {
		this.sabeon = sabeon;
	}
	public String getReq_cert_gbn() {
		return req_cert_gbn;
	}
	public void setReq_cert_gbn(String req_cert_gbn) {
		this.req_cert_gbn = req_cert_gbn;
	}
	public String getSsnUserJumin() {
		return ssnUserJumin;
	}
	public void setSsnUserJumin(String ssnUserJumin) {
		this.ssnUserJumin = ssnUserJumin;
	}
	public String getSsnUserName() {
		return ssnUserName;
	}
	public void setSsnUserName(String ssnUserName) {
		this.ssnUserName = ssnUserName;
	}
	public int getCntInsuTot() {
		return cntInsuTot;
	}
	public void setCntInsuTot(int cntInsuTot) {
		this.cntInsuTot = cntInsuTot;
	}
	public int getCntInsu1() {
		return cntInsu1;
	}
	public void setCntInsu1(int cntInsu1) {
		this.cntInsu1 = cntInsu1;
	}
	public int getCntInsu2() {
		return cntInsu2;
	}
	public void setCntInsu2(int cntInsu2) {
		this.cntInsu2 = cntInsu2;
	}
	public int getCntInsu3() {
		return cntInsu3;
	}
	public void setCntInsu3(int cntInsu3) {
		this.cntInsu3 = cntInsu3;
	}
	public int getCntInsu4() {
		return cntInsu4;
	}
	public void setCntInsu4(int cntInsu4) {
		this.cntInsu4 = cntInsu4;
	}
	public int getCntInsu5() {
		return cntInsu5;
	}
	public void setCntInsu5(int cntInsu5) {
		this.cntInsu5 = cntInsu5;
	}
	public int getCntInsu6() {
		return cntInsu6;
	}
	public void setCntInsu6(int cntInsu6) {
		this.cntInsu6 = cntInsu6;
	}
	public int getCntInsuNew() {
		return cntInsuNew;
	}
	public void setCntInsuNew(int cntInsuNew) {
		this.cntInsuNew = cntInsuNew;
	}
	public int getCntCarInsuDate() {
		return cntCarInsuDate;
	}
	public void setCntCarInsuDate(int cntCarInsuDate) {
		this.cntCarInsuDate = cntCarInsuDate;
	}
	public String getH_TEL1() {
		return H_TEL1;
	}
	public void setH_TEL1(String h_TEL1) {
		H_TEL1 = h_TEL1;
	}
	public String getH_TEL2() {
		return H_TEL2;
	}
	public void setH_TEL2(String h_TEL2) {
		H_TEL2 = h_TEL2;
	}
	public String getH_TEL3() {
		return H_TEL3;
	}
	public void setH_TEL3(String h_TEL3) {
		H_TEL3 = h_TEL3;
	}
	public String getHP_TEL1() {
		return HP_TEL1;
	}
	public void setHP_TEL1(String hP_TEL1) {
		HP_TEL1 = hP_TEL1;
	}
	public String getHP_TEL2() {
		return HP_TEL2;
	}
	public void setHP_TEL2(String hP_TEL2) {
		HP_TEL2 = hP_TEL2;
	}
	public String getHP_TEL3() {
		return HP_TEL3;
	}
	public void setHP_TEL3(String hP_TEL3) {
		HP_TEL3 = hP_TEL3;
	}
	public String getH_ZIP() {
		return H_ZIP;
	}
	public void setH_ZIP(String h_ZIP) {
		H_ZIP = h_ZIP;
	}
	public String getH_JUSO() {
		return H_JUSO;
	}
	public void setH_JUSO(String h_JUSO) {
		H_JUSO = h_JUSO;
	}
	public String getH_ADDR() {
		return H_ADDR;
	}
	public void setH_ADDR(String h_ADDR) {
		H_ADDR = h_ADDR;
	}
	public String getEMAIL_ID() {
		return EMAIL_ID;
	}
	public void setEMAIL_ID(String eMAIL_ID) {
		EMAIL_ID = eMAIL_ID;
	}
	public String getChkNext() {
		return chkNext;
	}
	public void setChkNext(String chkNext) {
		this.chkNext = chkNext;
	}
	public String getUD_LK_POLI_NO() {
		return UD_LK_POLI_NO;
	}
	public void setUD_LK_POLI_NO(String uD_LK_POLI_NO) {
		UD_LK_POLI_NO = uD_LK_POLI_NO;
	}
	public String getBank_gbn() {
		return bank_gbn;
	}
	public void setBank_gbn(String bank_gbn) {
		this.bank_gbn = bank_gbn;
	}
	public String getFd_mb_gbn() {
		return fd_mb_gbn;
	}
	public void setFd_mb_gbn(String fd_mb_gbn) {
		this.fd_mb_gbn = fd_mb_gbn;
	}
	public String getCert_err_no() {
		return cert_err_no;
	}
	public void setCert_err_no(String cert_err_no) {
		this.cert_err_no = cert_err_no;
	}
	public String getCert_outmsg() {
		return cert_outmsg;
	}
	public void setCert_outmsg(String cert_outmsg) {
		this.cert_outmsg = cert_outmsg;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getIPIN() {
		return IPIN;
	}
	public void setIPIN(String iPIN) {
		IPIN = iPIN;
	}
	public String getIPIN_ENC_DATA() {
		return IPIN_ENC_DATA;
	}
	public void setIPIN_ENC_DATA(String iPIN_ENC_DATA) {
		IPIN_ENC_DATA = iPIN_ENC_DATA;
	}
	public String getIPIN_CI() {
		return IPIN_CI;
	}
	public void setIPIN_CI(String iPIN_CI) {
		IPIN_CI = iPIN_CI;
	}
	public String getIPIN_DI() {
		return IPIN_DI;
	}
	public void setIPIN_DI(String iPIN_DI) {
		IPIN_DI = iPIN_DI;
	}
	public String getIPIN_VJUMIN() {
		return IPIN_VJUMIN;
	}
	public void setIPIN_VJUMIN(String iPIN_VJUMIN) {
		IPIN_VJUMIN = iPIN_VJUMIN;
	}
	public String getIPIN_CERT_DATE() {
		return IPIN_CERT_DATE;
	}
	public void setIPIN_CERT_DATE(String iPIN_CERT_DATE) {
		IPIN_CERT_DATE = iPIN_CERT_DATE;
	}
	public String getPrm_ssnMbBankGb() {
		return prm_ssnMbBankGb;
	}
	public void setPrm_ssnMbBankGb(String prm_ssnMbBankGb) {
		this.prm_ssnMbBankGb = prm_ssnMbBankGb;
	}
	public String getFd_mb_marketing_agree_gb() {
		return fd_mb_marketing_agree_gb;
	}
	public void setFd_mb_marketing_agree_gb(String fd_mb_marketing_agree_gb) {
		this.fd_mb_marketing_agree_gb = fd_mb_marketing_agree_gb;
	}
	public String getRE_CARD_NO1() {
		return RE_CARD_NO1;
	}
	public void setRE_CARD_NO1(String rE_CARD_NO1) {
		RE_CARD_NO1 = rE_CARD_NO1;
	}
	public String getRE_CARD_NO2() {
		return RE_CARD_NO2;
	}
	public void setRE_CARD_NO2(String rE_CARD_NO2) {
		RE_CARD_NO2 = rE_CARD_NO2;
	}
	public String getRE_CARD_NO3() {
		return RE_CARD_NO3;
	}
	public void setRE_CARD_NO3(String rE_CARD_NO3) {
		RE_CARD_NO3 = rE_CARD_NO3;
	}
	public String getRE_CARD_NO4() {
		return RE_CARD_NO4;
	}
	public void setRE_CARD_NO4(String rE_CARD_NO4) {
		RE_CARD_NO4 = rE_CARD_NO4;
	}
	public String getRE_YUHYO_GIGAN_MM() {
		return RE_YUHYO_GIGAN_MM;
	}
	public void setRE_YUHYO_GIGAN_MM(String rE_YUHYO_GIGAN_MM) {
		RE_YUHYO_GIGAN_MM = rE_YUHYO_GIGAN_MM;
	}
	public String getRE_YUHYO_GIGAN_YY() {
		return RE_YUHYO_GIGAN_YY;
	}
	public void setRE_YUHYO_GIGAN_YY(String rE_YUHYO_GIGAN_YY) {
		RE_YUHYO_GIGAN_YY = rE_YUHYO_GIGAN_YY;
	}
	public String getEnc_data() {
		return enc_data;
	}
	public void setEnc_data(String enc_data) {
		this.enc_data = enc_data;
	}
	public String getMember_name() {
		return member_name;
	}
	public void setMember_name(String member_name) {
		this.member_name = member_name;
	}
	public String getJumin1() {
		return jumin1;
	}
	public void setJumin1(String jumin1) {
		this.jumin1 = jumin1;
	}
	public String getJumin2() {
		return jumin2;
	}
	public void setJumin2(String jumin2) {
		this.jumin2 = jumin2;
	}
	public String getJumin() {
		return jumin;
	}
	public void setJumin(String jumin) {
		this.jumin = jumin;
	}
	public String getRetMsg() {
		return retMsg;
	}
	public void setRetMsg(String retMsg) {
		this.retMsg = retMsg;
	}
	public String getFd_mb_mphone1() {
		return fd_mb_mphone1;
	}
	public void setFd_mb_mphone1(String fd_mb_mphone1) {
		this.fd_mb_mphone1 = fd_mb_mphone1;
	}
	public String getFd_mb_mphone2() {
		return fd_mb_mphone2;
	}
	public void setFd_mb_mphone2(String fd_mb_mphone2) {
		this.fd_mb_mphone2 = fd_mb_mphone2;
	}
	public String getFd_mb_mphone3() {
		return fd_mb_mphone3;
	}
	public void setFd_mb_mphone3(String fd_mb_mphone3) {
		this.fd_mb_mphone3 = fd_mb_mphone3;
	}
	public String getFd_mb_hphone1() {
		return fd_mb_hphone1;
	}
	public void setFd_mb_hphone1(String fd_mb_hphone1) {
		this.fd_mb_hphone1 = fd_mb_hphone1;
	}
	public String getFd_mb_hphone2() {
		return fd_mb_hphone2;
	}
	public void setFd_mb_hphone2(String fd_mb_hphone2) {
		this.fd_mb_hphone2 = fd_mb_hphone2;
	}
	public String getFd_mb_hphone3() {
		return fd_mb_hphone3;
	}
	public void setFd_mb_hphone3(String fd_mb_hphone3) {
		this.fd_mb_hphone3 = fd_mb_hphone3;
	}
	public String getFd_mb_cphone1() {
		return fd_mb_cphone1;
	}
	public void setFd_mb_cphone1(String fd_mb_cphone1) {
		this.fd_mb_cphone1 = fd_mb_cphone1;
	}
	public String getFd_mb_cphone2() {
		return fd_mb_cphone2;
	}
	public void setFd_mb_cphone2(String fd_mb_cphone2) {
		this.fd_mb_cphone2 = fd_mb_cphone2;
	}
	public String getFd_mb_cphone3() {
		return fd_mb_cphone3;
	}
	public void setFd_mb_cphone3(String fd_mb_cphone3) {
		this.fd_mb_cphone3 = fd_mb_cphone3;
	}
	public String getFd_mail_permission() {
		return fd_mail_permission;
	}
	public void setFd_mail_permission(String fd_mail_permission) {
		this.fd_mail_permission = fd_mail_permission;
	}
	public String getFd_mb_name() {
		return fd_mb_name;
	}
	public void setFd_mb_name(String fd_mb_name) {
		this.fd_mb_name = fd_mb_name;
	}
	public String getFd_mb_temp_gb() {
		return fd_mb_temp_gb;
	}
	public void setFd_mb_temp_gb(String fd_mb_temp_gb) {
		this.fd_mb_temp_gb = fd_mb_temp_gb;
	}
	public String getRetCode() {
		return retCode;
	}
	public void setRetCode(String retCode) {
		this.retCode = retCode;
	}
	public String getFd_mb_no() {
		return fd_mb_no;
	}
	public void setFd_mb_no(String fd_mb_no) {
		this.fd_mb_no = fd_mb_no;
	}
	public String getFd_post_state() {
		return fd_post_state;
	}
	public void setFd_post_state(String fd_post_state) {
		this.fd_post_state = fd_post_state;
	}
	public String getFd_insu_tot() {
		return fd_insu_tot;
	}
	public void setFd_insu_tot(String fd_insu_tot) {
		this.fd_insu_tot = fd_insu_tot;
	}
	public String getIdx_max() {
		return idx_max;
	}
	public void setIdx_max(String idx_max) {
		this.idx_max = idx_max;
	}
	public String getPoint() {
		return point;
	}
	public void setPoint(String point) {
		this.point = point;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	public String getErrmsg() {
		return errmsg;
	}
	public void setErrmsg(String errmsg) {
		this.errmsg = errmsg;
	}
	public String getFd_mb_id() {
		return fd_mb_id;
	}
	public void setFd_mb_id(String fd_mb_id) {
		this.fd_mb_id = fd_mb_id;
	}
	public String getIpin_yn() {
		return ipin_yn;
	}
	public void setIpin_yn(String ipin_yn) {
		this.ipin_yn = ipin_yn;
	}
	public String getFd_business_gb() {
		return fd_business_gb;
	}
	public void setFd_business_gb(String fd_business_gb) {
		this.fd_business_gb = fd_business_gb;
	}
	public String getResult_code() {
		return result_code;
	}
	public void setResult_code(String result_code) {
		this.result_code = result_code;
	}
	public String getFd_sp_account_no() {
		return fd_sp_account_no;
	}
	public void setFd_sp_account_no(String fd_sp_account_no) {
		this.fd_sp_account_no = fd_sp_account_no;
	}
	public String getCl_cd() {
		return cl_cd;
	}
	public void setCl_cd(String cl_cd) {
		this.cl_cd = cl_cd;
	}
	public String getCd_name() {
		return cd_name;
	}
	public void setCd_name(String cd_name) {
		this.cd_name = cd_name;
	}
	public String getSi_email_susin_yn() {
		return si_email_susin_yn;
	}
	public void setSi_email_susin_yn(String si_email_susin_yn) {
		this.si_email_susin_yn = si_email_susin_yn;
	}
	public String getSi_email_id() {
		return si_email_id;
	}
	public void setSi_email_id(String si_email_id) {
		this.si_email_id = si_email_id;
	}
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	
	/**
	 * @return the certInfo
	 */
	public String getCertInfo() {
		return certInfo;
	}
	/**
	 * @param certInfo the certInfo to set
	 */
	public void setCertInfo(String certInfo) {
		this.certInfo = certInfo;
	}
	/**
	 * @return the expSdate
	 */
	public String getExpSdate() {
		return expSdate;
	}
	/**
	 * @param expSdate the expSdate to set
	 */
	public void setExpSdate(String expSdate) {
		this.expSdate = expSdate;
	}
	/**
	 * @return the expEdate
	 */
	public String getExpEdate() {
		return expEdate;
	}
	/**
	 * @param expEdate the expEdate to set
	 */
	public void setExpEdate(String expEdate) {
		this.expEdate = expEdate;
	}	
}

