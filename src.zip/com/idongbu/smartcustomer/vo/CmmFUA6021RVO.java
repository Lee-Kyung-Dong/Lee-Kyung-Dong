package com.idongbu.smartcustomer.vo;

import com.idongbu.common.vo.CMMVO;

//장기보험료납입신청
public class CmmFUA6021RVO extends CMMVO {
	
	public CmmFUA6021RVO() {
		super.setPGMID(this.proid);
		super.setTRID(this.trid);
	}
	private static final String proid		= "FUA6021R";
	private static final String trid		= "UA6L";
	private String rURL						= "";

	// 입력
	private String JJ_POLI_NO       = null; // 증권번호
	private String JJ_NAPIP_CNT  = null; // 납입할횟수
	private String JJ_BANK_CD  = null; // 은행코드
	private String HJ_BANK_NAME = null; // 은행명
	private String JJ_GYEJWA_NO = null; // 출금계좌번호
	private String JJ_HAND_PHONE = null; // 고객핸드폰
	private String HJ_YEGMJU_NAME = null; // 예금주명
	private String JJ_YEGMJU_ID   = null; // 예금주 주민번호
	private String JJ_YEGMJU_CHECK = null; // 예금주체크
	private String UU_POLI_NO  = null; // 증권번호

	// 출력
	private String CC_CHANNEL = null;
	private String CC_UKEY = null;
	private String CC_PGMID = null;
	private String CC_PROC_GB = null;
	private String CC_FUN_KEY = null;
	private String CC_USER_GB = null;
	private String CC_USER_CD = null;
	private String CC_JIJUM_CD = null;
	private String CC_JIBU_CD = null;
	private String CC_PROTOCOL = null;
	private String CC_COND_CD = null;
	private String CC_LAST_FLAG = null;
	private String CC_CURSOR_MAP = null;
	private String CC_CURSOR_IDX = null;
	private String CC_MESSAGE_CD = null;
	private String HC_MESSAGE_NM = null;
	private String CC_SYS_ERR = null;
	private String CC_FILLER = null;
//	private String JJ_POLI_NO = null;
	private String JJ_BJ_CD = null;
	private String HJ_BJ_NAME = null;
	private String HJ_GYEYAKJA_NAME = null;
	private String JJ_GYEYAKJA_ID = null;
	private String JJ_BOHUM_SYMD = null;
	private String JJ_BOHUM_EYMD = null;
	private String JJ_NAPIP_YCNT = null;
	private String JJ_GUCHI_YCNT = null;
	private String JJ_MANGI_YCNT = null;
	private String HJ_NAPBANG_NAME = null;
	private String JJ_NAPIPHAL_PRM = null;
	private String JJ_LAST_NAPIP_YM = null;
	private String JJ_TOTAL_NAPIP_CNT = null;
	private String JJ_LAST_NAPIP_CNT = null;
//	private String JJ_NAPIP_CNT = null;
	private String JJ_NAPIP_PRM = null;
	private String JJ_NAPIP_SYM = null;
	private String JJ_NAPIP_SCNT = null;
	private String JJ_NAPIP_EYM = null;
	private String JJ_NAPIP_ECNT = null;
	private String JJ_CHULGM_PRM = null;
	private String JJ_SUGUM_JIJUM_CD = null;
	private String JJ_SUGUM_JIBU_CD = null;
	private String JJ_SUGUM_SAWON_NO = null;
	private String HJ_SUGUM_JIJUM_NAME = null;
	private String HJ_SUGUM_JIBU_NAME = null;
	private String HJ_SUGUM_SAWON_NAME = null;
	private String HJ_SUGUM_BANGBUP = null;
	private String JJ_SUGUM_TEL_NO = null;
	private String JJ_YOC_NO = null;
//	private String JJ_BANK_CD = null;
//	private String HJ_BANK_NAME = null;
//	private String JJ_GYEJWA_NO = null;
//	private String JJ_HAND_PHONE = null;
//	private String HJ_YEGMJU_NAME = null;
//	private String JJ_YEGMJU_ID = null;
//	private String JJ_YEGMJU_CHECK = null;
	private String HJ_REMARK1 = null;
	private String JJ_REMARK1 = null;
	private String HJ_REMARK2 = null;
	private String JJ_REMARK2 = null;
	private String JJ_SYS_RC = null;
	private String JJ_RECI_CD = null;
	private String JJ_FILLER = null;
//	private String UU_POLI_NO = null;
	private String UU_FILLER = null;
	
	private String msg_1 = null;
	private String msg_2 = null;
	
	public String getMsg_1() {
		return msg_1;
	}
	public void setMsg_1(String msg_1) {
		this.msg_1 = msg_1;
	}
	public String getMsg_2() {
		return msg_2;
	}
	public void setMsg_2(String msg_2) {
		this.msg_2 = msg_2;
	}
	public String getrURL() {
		return rURL;
	}
	public void setrURL(String rURL) {
		this.rURL = rURL;
	}
	public String getJJ_POLI_NO() {
		return JJ_POLI_NO;
	}
	public void setJJ_POLI_NO(String jJ_POLI_NO) {
		JJ_POLI_NO = jJ_POLI_NO;
	}
	public String getJJ_NAPIP_CNT() {
		return JJ_NAPIP_CNT;
	}
	public void setJJ_NAPIP_CNT(String jJ_NAPIP_CNT) {
		JJ_NAPIP_CNT = jJ_NAPIP_CNT;
	}
	public String getJJ_BANK_CD() {
		return JJ_BANK_CD;
	}
	public void setJJ_BANK_CD(String jJ_BANK_CD) {
		JJ_BANK_CD = jJ_BANK_CD;
	}
	public String getHJ_BANK_NAME() {
		return HJ_BANK_NAME;
	}
	public void setHJ_BANK_NAME(String hJ_BANK_NAME) {
		HJ_BANK_NAME = hJ_BANK_NAME;
	}
	public String getJJ_GYEJWA_NO() {
		return JJ_GYEJWA_NO;
	}
	public void setJJ_GYEJWA_NO(String jJ_GYEJWA_NO) {
		JJ_GYEJWA_NO = jJ_GYEJWA_NO;
	}
	public String getJJ_HAND_PHONE() {
		return JJ_HAND_PHONE;
	}
	public void setJJ_HAND_PHONE(String jJ_HAND_PHONE) {
		JJ_HAND_PHONE = jJ_HAND_PHONE;
	}
	public String getHJ_YEGMJU_NAME() {
		return HJ_YEGMJU_NAME;
	}
	public void setHJ_YEGMJU_NAME(String hJ_YEGMJU_NAME) {
		HJ_YEGMJU_NAME = hJ_YEGMJU_NAME;
	}
	public String getJJ_YEGMJU_ID() {
		return JJ_YEGMJU_ID;
	}
	public void setJJ_YEGMJU_ID(String jJ_YEGMJU_ID) {
		JJ_YEGMJU_ID = jJ_YEGMJU_ID;
	}
	public String getJJ_YEGMJU_CHECK() {
		return JJ_YEGMJU_CHECK;
	}
	public void setJJ_YEGMJU_CHECK(String jJ_YEGMJU_CHECK) {
		JJ_YEGMJU_CHECK = jJ_YEGMJU_CHECK;
	}
	public String getUU_POLI_NO() {
		return UU_POLI_NO;
	}
	public void setUU_POLI_NO(String uU_POLI_NO) {
		UU_POLI_NO = uU_POLI_NO;
	}
	public String getCC_CHANNEL() {
		return CC_CHANNEL;
	}
	public void setCC_CHANNEL(String cC_CHANNEL) {
		CC_CHANNEL = cC_CHANNEL;
	}
	public String getCC_UKEY() {
		return CC_UKEY;
	}
	public void setCC_UKEY(String cC_UKEY) {
		CC_UKEY = cC_UKEY;
	}
	public String getCC_PGMID() {
		return CC_PGMID;
	}
	public void setCC_PGMID(String cC_PGMID) {
		CC_PGMID = cC_PGMID;
	}
	public String getCC_PROC_GB() {
		return CC_PROC_GB;
	}
	public void setCC_PROC_GB(String cC_PROC_GB) {
		CC_PROC_GB = cC_PROC_GB;
	}
	public String getCC_FUN_KEY() {
		return CC_FUN_KEY;
	}
	public void setCC_FUN_KEY(String cC_FUN_KEY) {
		CC_FUN_KEY = cC_FUN_KEY;
	}
	public String getCC_USER_GB() {
		return CC_USER_GB;
	}
	public void setCC_USER_GB(String cC_USER_GB) {
		CC_USER_GB = cC_USER_GB;
	}
	public String getCC_USER_CD() {
		return CC_USER_CD;
	}
	public void setCC_USER_CD(String cC_USER_CD) {
		CC_USER_CD = cC_USER_CD;
	}
	public String getCC_JIJUM_CD() {
		return CC_JIJUM_CD;
	}
	public void setCC_JIJUM_CD(String cC_JIJUM_CD) {
		CC_JIJUM_CD = cC_JIJUM_CD;
	}
	public String getCC_JIBU_CD() {
		return CC_JIBU_CD;
	}
	public void setCC_JIBU_CD(String cC_JIBU_CD) {
		CC_JIBU_CD = cC_JIBU_CD;
	}
	public String getCC_PROTOCOL() {
		return CC_PROTOCOL;
	}
	public void setCC_PROTOCOL(String cC_PROTOCOL) {
		CC_PROTOCOL = cC_PROTOCOL;
	}
	public String getCC_COND_CD() {
		return CC_COND_CD;
	}
	public void setCC_COND_CD(String cC_COND_CD) {
		CC_COND_CD = cC_COND_CD;
	}
	public String getCC_LAST_FLAG() {
		return CC_LAST_FLAG;
	}
	public void setCC_LAST_FLAG(String cC_LAST_FLAG) {
		CC_LAST_FLAG = cC_LAST_FLAG;
	}
	public String getCC_CURSOR_MAP() {
		return CC_CURSOR_MAP;
	}
	public void setCC_CURSOR_MAP(String cC_CURSOR_MAP) {
		CC_CURSOR_MAP = cC_CURSOR_MAP;
	}
	public String getCC_CURSOR_IDX() {
		return CC_CURSOR_IDX;
	}
	public void setCC_CURSOR_IDX(String cC_CURSOR_IDX) {
		CC_CURSOR_IDX = cC_CURSOR_IDX;
	}
	public String getCC_MESSAGE_CD() {
		return CC_MESSAGE_CD;
	}
	public void setCC_MESSAGE_CD(String cC_MESSAGE_CD) {
		CC_MESSAGE_CD = cC_MESSAGE_CD;
	}
	public String getHC_MESSAGE_NM() {
		return HC_MESSAGE_NM;
	}
	public void setHC_MESSAGE_NM(String hC_MESSAGE_NM) {
		HC_MESSAGE_NM = hC_MESSAGE_NM;
	}
	public String getCC_SYS_ERR() {
		return CC_SYS_ERR;
	}
	public void setCC_SYS_ERR(String cC_SYS_ERR) {
		CC_SYS_ERR = cC_SYS_ERR;
	}
	public String getCC_FILLER() {
		return CC_FILLER;
	}
	public void setCC_FILLER(String cC_FILLER) {
		CC_FILLER = cC_FILLER;
	}
	public String getJJ_BJ_CD() {
		return JJ_BJ_CD;
	}
	public void setJJ_BJ_CD(String jJ_BJ_CD) {
		JJ_BJ_CD = jJ_BJ_CD;
	}
	public String getHJ_BJ_NAME() {
		return HJ_BJ_NAME;
	}
	public void setHJ_BJ_NAME(String hJ_BJ_NAME) {
		HJ_BJ_NAME = hJ_BJ_NAME;
	}
	public String getHJ_GYEYAKJA_NAME() {
		return HJ_GYEYAKJA_NAME;
	}
	public void setHJ_GYEYAKJA_NAME(String hJ_GYEYAKJA_NAME) {
		HJ_GYEYAKJA_NAME = hJ_GYEYAKJA_NAME;
	}
	public String getJJ_GYEYAKJA_ID() {
		return JJ_GYEYAKJA_ID;
	}
	public void setJJ_GYEYAKJA_ID(String jJ_GYEYAKJA_ID) {
		JJ_GYEYAKJA_ID = jJ_GYEYAKJA_ID;
	}
	public String getJJ_BOHUM_SYMD() {
		return JJ_BOHUM_SYMD;
	}
	public void setJJ_BOHUM_SYMD(String jJ_BOHUM_SYMD) {
		JJ_BOHUM_SYMD = jJ_BOHUM_SYMD;
	}
	public String getJJ_BOHUM_EYMD() {
		return JJ_BOHUM_EYMD;
	}
	public void setJJ_BOHUM_EYMD(String jJ_BOHUM_EYMD) {
		JJ_BOHUM_EYMD = jJ_BOHUM_EYMD;
	}
	public String getJJ_NAPIP_YCNT() {
		return JJ_NAPIP_YCNT;
	}
	public void setJJ_NAPIP_YCNT(String jJ_NAPIP_YCNT) {
		JJ_NAPIP_YCNT = jJ_NAPIP_YCNT;
	}
	public String getJJ_GUCHI_YCNT() {
		return JJ_GUCHI_YCNT;
	}
	public void setJJ_GUCHI_YCNT(String jJ_GUCHI_YCNT) {
		JJ_GUCHI_YCNT = jJ_GUCHI_YCNT;
	}
	public String getJJ_MANGI_YCNT() {
		return JJ_MANGI_YCNT;
	}
	public void setJJ_MANGI_YCNT(String jJ_MANGI_YCNT) {
		JJ_MANGI_YCNT = jJ_MANGI_YCNT;
	}
	public String getHJ_NAPBANG_NAME() {
		return HJ_NAPBANG_NAME;
	}
	public void setHJ_NAPBANG_NAME(String hJ_NAPBANG_NAME) {
		HJ_NAPBANG_NAME = hJ_NAPBANG_NAME;
	}
	public String getJJ_NAPIPHAL_PRM() {
		return JJ_NAPIPHAL_PRM;
	}
	public void setJJ_NAPIPHAL_PRM(String jJ_NAPIPHAL_PRM) {
		JJ_NAPIPHAL_PRM = jJ_NAPIPHAL_PRM;
	}
	public String getJJ_LAST_NAPIP_YM() {
		return JJ_LAST_NAPIP_YM;
	}
	public void setJJ_LAST_NAPIP_YM(String jJ_LAST_NAPIP_YM) {
		JJ_LAST_NAPIP_YM = jJ_LAST_NAPIP_YM;
	}
	public String getJJ_TOTAL_NAPIP_CNT() {
		return JJ_TOTAL_NAPIP_CNT;
	}
	public void setJJ_TOTAL_NAPIP_CNT(String jJ_TOTAL_NAPIP_CNT) {
		JJ_TOTAL_NAPIP_CNT = jJ_TOTAL_NAPIP_CNT;
	}
	public String getJJ_LAST_NAPIP_CNT() {
		return JJ_LAST_NAPIP_CNT;
	}
	public void setJJ_LAST_NAPIP_CNT(String jJ_LAST_NAPIP_CNT) {
		JJ_LAST_NAPIP_CNT = jJ_LAST_NAPIP_CNT;
	}
	public String getJJ_NAPIP_PRM() {
		return JJ_NAPIP_PRM;
	}
	public void setJJ_NAPIP_PRM(String jJ_NAPIP_PRM) {
		JJ_NAPIP_PRM = jJ_NAPIP_PRM;
	}
	public String getJJ_NAPIP_SYM() {
		return JJ_NAPIP_SYM;
	}
	public void setJJ_NAPIP_SYM(String jJ_NAPIP_SYM) {
		JJ_NAPIP_SYM = jJ_NAPIP_SYM;
	}
	public String getJJ_NAPIP_SCNT() {
		return JJ_NAPIP_SCNT;
	}
	public void setJJ_NAPIP_SCNT(String jJ_NAPIP_SCNT) {
		JJ_NAPIP_SCNT = jJ_NAPIP_SCNT;
	}
	public String getJJ_NAPIP_EYM() {
		return JJ_NAPIP_EYM;
	}
	public void setJJ_NAPIP_EYM(String jJ_NAPIP_EYM) {
		JJ_NAPIP_EYM = jJ_NAPIP_EYM;
	}
	public String getJJ_NAPIP_ECNT() {
		return JJ_NAPIP_ECNT;
	}
	public void setJJ_NAPIP_ECNT(String jJ_NAPIP_ECNT) {
		JJ_NAPIP_ECNT = jJ_NAPIP_ECNT;
	}
	public String getJJ_CHULGM_PRM() {
		return JJ_CHULGM_PRM;
	}
	public void setJJ_CHULGM_PRM(String jJ_CHULGM_PRM) {
		JJ_CHULGM_PRM = jJ_CHULGM_PRM;
	}
	public String getJJ_SUGUM_JIJUM_CD() {
		return JJ_SUGUM_JIJUM_CD;
	}
	public void setJJ_SUGUM_JIJUM_CD(String jJ_SUGUM_JIJUM_CD) {
		JJ_SUGUM_JIJUM_CD = jJ_SUGUM_JIJUM_CD;
	}
	public String getJJ_SUGUM_JIBU_CD() {
		return JJ_SUGUM_JIBU_CD;
	}
	public void setJJ_SUGUM_JIBU_CD(String jJ_SUGUM_JIBU_CD) {
		JJ_SUGUM_JIBU_CD = jJ_SUGUM_JIBU_CD;
	}
	public String getJJ_SUGUM_SAWON_NO() {
		return JJ_SUGUM_SAWON_NO;
	}
	public void setJJ_SUGUM_SAWON_NO(String jJ_SUGUM_SAWON_NO) {
		JJ_SUGUM_SAWON_NO = jJ_SUGUM_SAWON_NO;
	}
	public String getHJ_SUGUM_JIJUM_NAME() {
		return HJ_SUGUM_JIJUM_NAME;
	}
	public void setHJ_SUGUM_JIJUM_NAME(String hJ_SUGUM_JIJUM_NAME) {
		HJ_SUGUM_JIJUM_NAME = hJ_SUGUM_JIJUM_NAME;
	}
	public String getHJ_SUGUM_JIBU_NAME() {
		return HJ_SUGUM_JIBU_NAME;
	}
	public void setHJ_SUGUM_JIBU_NAME(String hJ_SUGUM_JIBU_NAME) {
		HJ_SUGUM_JIBU_NAME = hJ_SUGUM_JIBU_NAME;
	}
	public String getHJ_SUGUM_SAWON_NAME() {
		return HJ_SUGUM_SAWON_NAME;
	}
	public void setHJ_SUGUM_SAWON_NAME(String hJ_SUGUM_SAWON_NAME) {
		HJ_SUGUM_SAWON_NAME = hJ_SUGUM_SAWON_NAME;
	}
	public String getHJ_SUGUM_BANGBUP() {
		return HJ_SUGUM_BANGBUP;
	}
	public void setHJ_SUGUM_BANGBUP(String hJ_SUGUM_BANGBUP) {
		HJ_SUGUM_BANGBUP = hJ_SUGUM_BANGBUP;
	}
	public String getJJ_SUGUM_TEL_NO() {
		return JJ_SUGUM_TEL_NO;
	}
	public void setJJ_SUGUM_TEL_NO(String jJ_SUGUM_TEL_NO) {
		JJ_SUGUM_TEL_NO = jJ_SUGUM_TEL_NO;
	}
	public String getJJ_YOC_NO() {
		return JJ_YOC_NO;
	}
	public void setJJ_YOC_NO(String jJ_YOC_NO) {
		JJ_YOC_NO = jJ_YOC_NO;
	}
	public String getHJ_REMARK1() {
		return HJ_REMARK1;
	}
	public void setHJ_REMARK1(String hJ_REMARK1) {
		HJ_REMARK1 = hJ_REMARK1;
	}
	public String getJJ_REMARK1() {
		return JJ_REMARK1;
	}
	public void setJJ_REMARK1(String jJ_REMARK1) {
		JJ_REMARK1 = jJ_REMARK1;
	}
	public String getHJ_REMARK2() {
		return HJ_REMARK2;
	}
	public void setHJ_REMARK2(String hJ_REMARK2) {
		HJ_REMARK2 = hJ_REMARK2;
	}
	public String getJJ_REMARK2() {
		return JJ_REMARK2;
	}
	public void setJJ_REMARK2(String jJ_REMARK2) {
		JJ_REMARK2 = jJ_REMARK2;
	}
	public String getJJ_SYS_RC() {
		return JJ_SYS_RC;
	}
	public void setJJ_SYS_RC(String jJ_SYS_RC) {
		JJ_SYS_RC = jJ_SYS_RC;
	}
	public String getJJ_RECI_CD() {
		return JJ_RECI_CD;
	}
	public void setJJ_RECI_CD(String jJ_RECI_CD) {
		JJ_RECI_CD = jJ_RECI_CD;
	}
	public String getJJ_FILLER() {
		return JJ_FILLER;
	}
	public void setJJ_FILLER(String jJ_FILLER) {
		JJ_FILLER = jJ_FILLER;
	}
	public String getUU_FILLER() {
		return UU_FILLER;
	}
	public void setUU_FILLER(String uU_FILLER) {
		UU_FILLER = uU_FILLER;
	}
	public static String getProid() {
		return proid;
	}
	public static String getTrid() {
		return trid;
	}
}
