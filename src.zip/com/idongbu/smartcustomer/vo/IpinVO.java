package com.idongbu.smartcustomer.vo;

public class IpinVO {
	//복호화 변수
	public int    iReturn          = 0;			// 인증결과
	public String strVno           = "";		// 가상주민번호
	public String strUserName      = "";		// 인증 고객실명
	public String strDupInfo       = "";		// 중복가입 확인값 (64Byte 고유값), 이값은 고유하므로 중복가입체크가 가능합니다.
	public String strAgeInfo       = "";		// 연령 코드
	public String strGender        = "";		// 성별 코드
	public String strCPReqNum      = "";		// 고객 클라이언트 요청번호 (클라이언트 요청에 의해 생성하는값입니다.)
	public String strBirthData		= "";		// 생년월일
	public String stripaddress		= "";		// 암호화 데이타 생성 IP주소
	public String strCipherDateTime= "";		// 암호화 데이타 생성 시간
	public String strAuthInfo= "";				// 본인 확인 수단 
	public String strCoInfo1= "";				// 연결정보(CI)1
	public String strCoInfo2= "";				// 연결정보(CI)2
	public String strCiUpdate= "";				// 연결정보(CI) 갱신횟수	
	//복호화 변수
	
	//주민번호로 추출시 변수
	public String IPIN_CI		= "";
	public String IPIN_DI		= "";
	//주민번호로 추출시 변수
	public int getiReturn() {
		return iReturn;
	}
	public void setiReturn(int iReturn) {
		this.iReturn = iReturn;
	}
	public String getStrVno() {
		return strVno;
	}
	public void setStrVno(String strVno) {
		this.strVno = strVno;
	}
	public String getStrUserName() {
		return strUserName;
	}
	public void setStrUserName(String strUserName) {
		this.strUserName = strUserName;
	}
	public String getStrDupInfo() {
		return strDupInfo;
	}
	public void setStrDupInfo(String strDupInfo) {
		this.strDupInfo = strDupInfo;
	}
	public String getStrAgeInfo() {
		return strAgeInfo;
	}
	public void setStrAgeInfo(String strAgeInfo) {
		this.strAgeInfo = strAgeInfo;
	}
	public String getStrGender() {
		return strGender;
	}
	public void setStrGender(String strGender) {
		this.strGender = strGender;
	}
	public String getStrCPReqNum() {
		return strCPReqNum;
	}
	public void setStrCPReqNum(String strCPReqNum) {
		this.strCPReqNum = strCPReqNum;
	}
	public String getStrBirthData() {
		return strBirthData;
	}
	public void setStrBirthData(String strBirthData) {
		this.strBirthData = strBirthData;
	}
	public String getStripaddress() {
		return stripaddress;
	}
	public void setStripaddress(String stripaddress) {
		this.stripaddress = stripaddress;
	}
	public String getStrCipherDateTime() {
		return strCipherDateTime;
	}
	public void setStrCipherDateTime(String strCipherDateTime) {
		this.strCipherDateTime = strCipherDateTime;
	}
	public String getStrAuthInfo() {
		return strAuthInfo;
	}
	public void setStrAuthInfo(String strAuthInfo) {
		this.strAuthInfo = strAuthInfo;
	}
	public String getStrCoInfo1() {
		return strCoInfo1;
	}
	public void setStrCoInfo1(String strCoInfo1) {
		this.strCoInfo1 = strCoInfo1;
	}
	public String getStrCoInfo2() {
		return strCoInfo2;
	}
	public void setStrCoInfo2(String strCoInfo2) {
		this.strCoInfo2 = strCoInfo2;
	}
	public String getStrCiUpdate() {
		return strCiUpdate;
	}
	public void setStrCiUpdate(String strCiUpdate) {
		this.strCiUpdate = strCiUpdate;
	}
	public String getIPIN_CI() {
		return IPIN_CI;
	}
	public void setIPIN_CI(String iPIN_CI) {
		IPIN_CI = iPIN_CI;
	}
	public String getIPIN_DI() {
		return IPIN_DI;
	}
	public void setIPIN_DI(String iPIN_DI) {
		IPIN_DI = iPIN_DI;
	}
}


