package com.idongbu.smartcustomer.vo;

import com.idongbu.common.vo.CMMVO;


// 국내/해외여행영수확정(카드)
public class CmmFWK0051RVO extends CMMVO {
	public CmmFWK0051RVO() {
		super.setPGMID(this.proid);
		super.setTRID(this.trid);
	}
	public static final String proid		= "FWK0051R";
	public static final String trid		= "WK51";	// WM02 ??
	public String rURL						= "";

	// 입력
	private String SD_AREA = null; // << 시스템공통 >>
	private String SD_TRID         = null; // TRANSACTION-CODE
	private String SD_FLAG         = null; // 송수신FLAG
	private String SD_NETWORK      = null; // NETWORK 응답코드
	private String SD_JUNSONG_TIME = null; // 전문전송시간
	private String SD_BOHUMSA_GB   = null; // 제휴사구분
	private String SD_BOGUMSA_CD   = null; // 제휴사코드
	private String SD_FILL         = null; // FILLER
	private String LINK_WK0051_AREA_1  = null; // << 기간계공통 >>
	private String LK_WK0051_LOGON_ID     = null; // 사용자ID
	private String LK_WK0051_PART1        = null; // 파트고유공통1(업무처리구분)
	private String LK_WK0051_PART2        = null; // 파트고유공통2(업무처리세부구분)
	private String LK_WK0051_UPMU_BUNRYU1 = null; // 업무분류1
	private String LK_WK0051_UPMU_BUNRYU2 = null; // 업무분류2
	private String LK_WK0051_UPMU_BUNRYU3 = null; // 업무분류3
	private String LK_WK0051_CON_YN       = null; // 연속거래구분
	private String LK_WK0051_FIL1         = null; // FILLER
	private String LINK_WK0051_AREA_2 = null; // << 계약일반 >>
	private String LK_WK0051_POLI_NO     = null; // 증권번호
	private String LK_WK0051_JOJIKWON_CD = null; // 취급자코드
	private String LK_WK0051_GYEYAK_TEL  = null; // 계약자전화번호
	private String LK_WK0051_PIBO_TEL    = null; // 피보험자전화번호
	private String LK_WK0051_E_MAIL      = null; // E-MAIL
	private String LK_WK0051_GMJONG_GB = null; // 금종구분
	private String LK_WK0051_FIL            = null; // FILLER
	private String LINK_WK0051_AREA_4 = null; // << 신용카드정보 >>
	private String LK_WK0051_YUNGSU_NO      = null; // 영수증번호
	private String LK_WK0051_CARDSA_GB      = null; // 카드사구분코드
	private String LK_WK0051_CARD_NO        = null; // 카드번호
	private String LK_WK0051_CARD_USER_NAME = null; // 카드명의자
	private String LK_WK0051_YUHYO_GIGAN_YM = null; // 유효기간 (YYMM)
	private String LK_WK0051_HALBU_GB       = null; // 할부구분
	private String LK_WK0051_HALBU_GIGAN    = null; // 할부기간 (2~36)
	private String LK_WK0051_GURE_AMT       = null; // 거래금액
	private String LK_WK0051_SNGIN_YMD      = null; // 카드승인일
	private String LK_WK0051_SNGIN_NO       = null; // 승인번호
	private String LK_WK0051_BALGPSA_CD     = null; // 발급사 코드
	private String LK_WK0051_VANSA_GUBUN    = null; // VAN사 구분
	private String LK_WK0051_SYSTEM_GUBUN   = null; // 시스템 구분
	private String LINK_WK0051_AREA_5 = null; // << 가상계좌신청 >>
	private String LK_WK0051_BANK_CD = null; // 은행코드
	private String LK_WK0051_SMS_NO = null; // SMS 전화번호
	private String LK_WK0051_SMS_NO1 = null; // SMS 전화번호1
	private String LK_WK0051_SMS_NO2 = null; // SMS 전화번호2
	private String LK_WK0051_SMS_NO3 = null; // SMS 전화번호3
	private String LK_WK0051_GYEJWA_NO = null; // 가상계좌번호
	private String LK_WK0051_NAPIP_PRM = null; // 납입보험료
	private String LK_WK0051_CHAEKIM_EYMD = null; // 책임종료일
	private String LK_WK0051_FILLER1 = null; // FILLER
	private String LK_WK0051_CARD_JUNPYO = null; // FILLER
	
	// 출력
//	private String SD_TRID = null;
//	private String SD_FLAG = null;
//	private String SD_NETWORK = null;
//	private String SD_JUNSONG_TIME = null;
//	private String SD_BOHUMSA_GB = null;
//	private String SD_BOGUMSA_CD = null;
//	private String SD_FILL = null;
//	private String LK_WK0051_LOGON_ID = null;
//	private String LK_WK0051_PART1 = null;
//	private String LK_WK0051_PART2 = null;
//	private String LK_WK0051_UPMU_BUNRYU1 = null;
//	private String LK_WK0051_UPMU_BUNRYU2 = null;
//	private String LK_WK0051_UPMU_BUNRYU3 = null;
//	private String LK_WK0051_CON_YN = null;
//	private String LK_WK0051_FIL1 = null;
	private String LK_WK0051_RC = null;
	private String LK_WK0051_MSG_CD1 = null;
	private String LK_WK0051_MSG_CD2 = null;
	private String LK_WK0051_MSG_ERR1 = null;
	private String LK_WK0051_MSG_ERR2 = null;
//	private String LK_WK0051_POLI_NO = null;
//	private String LK_WK0051_JOJIKWON_CD = null;
//	private String LK_WK0051_GYEYAK_TEL = null;
//	private String LK_WK0051_PIBO_TEL = null;
//	private String LK_WK0051_E_MAIL = null;
//	private String LK_WK0051_GMJONG_GB = null;
//	private String LK_WK0051_FIL = null;
//	private String LK_WK0051_YUNGSU_NO = null;
//	private String LK_WK0051_CARDSA_GB = null;
//	private String LK_WK0051_CARD_NO = null;
//	private String LK_WK0051_CARD_USER_NAME = null;
//	private String LK_WK0051_YUHYO_GIGAN_YM = null;
//	private String LK_WK0051_HALBU_GB = null;
//	private String LK_WK0051_HALBU_GIGAN = null;
//	private String LK_WK0051_GURE_AMT = null;
//	private String LK_WK0051_SNGIN_YMD = null;
//	private String LK_WK0051_SNGIN_NO = null;
//	private String LK_WK0051_BALGPSA_CD = null;
//	private String LK_WK0051_VANSA_GUBUN = null;
//	private String LK_WK0051_SYSTEM_GUBUN = null;
//	private String LK_WK0051_BANK_CD = null;
//	private String LK_WK0051_SMS_NO1 = null;
//	private String LK_WK0051_SMS_NO2 = null;
//	private String LK_WK0051_SMS_NO3 = null;
//	private String LK_WK0051_GYEJWA_NO = null;
//	private String LK_WK0051_NAPIP_PRM = null;
//	private String LK_WK0051_CHAEKIM_EYMD = null;
//	private String LK_WK0051_FILLER1 = null;
	public String getrURL() {
		return rURL;
	}
	public void setrURL(String rURL) {
		this.rURL = rURL;
	}
	public String getSD_AREA() {
		return SD_AREA;
	}
	public void setSD_AREA(String sD_AREA) {
		SD_AREA = sD_AREA;
	}
	public String getSD_TRID() {
		return SD_TRID;
	}
	public void setSD_TRID(String sD_TRID) {
		SD_TRID = sD_TRID;
	}
	public String getSD_FLAG() {
		return SD_FLAG;
	}
	public void setSD_FLAG(String sD_FLAG) {
		SD_FLAG = sD_FLAG;
	}
	public String getSD_NETWORK() {
		return SD_NETWORK;
	}
	public void setSD_NETWORK(String sD_NETWORK) {
		SD_NETWORK = sD_NETWORK;
	}
	public String getSD_JUNSONG_TIME() {
		return SD_JUNSONG_TIME;
	}
	public void setSD_JUNSONG_TIME(String sD_JUNSONG_TIME) {
		SD_JUNSONG_TIME = sD_JUNSONG_TIME;
	}
	public String getSD_BOHUMSA_GB() {
		return SD_BOHUMSA_GB;
	}
	public void setSD_BOHUMSA_GB(String sD_BOHUMSA_GB) {
		SD_BOHUMSA_GB = sD_BOHUMSA_GB;
	}
	public String getSD_BOGUMSA_CD() {
		return SD_BOGUMSA_CD;
	}
	public void setSD_BOGUMSA_CD(String sD_BOGUMSA_CD) {
		SD_BOGUMSA_CD = sD_BOGUMSA_CD;
	}
	public String getSD_FILL() {
		return SD_FILL;
	}
	public void setSD_FILL(String sD_FILL) {
		SD_FILL = sD_FILL;
	}
	public String getLINK_WK0051_AREA_1() {
		return LINK_WK0051_AREA_1;
	}
	public void setLINK_WK0051_AREA_1(String lINK_WK0051_AREA_1) {
		LINK_WK0051_AREA_1 = lINK_WK0051_AREA_1;
	}
	public String getLK_WK0051_LOGON_ID() {
		return LK_WK0051_LOGON_ID;
	}
	public void setLK_WK0051_LOGON_ID(String lK_WK0051_LOGON_ID) {
		LK_WK0051_LOGON_ID = lK_WK0051_LOGON_ID;
	}
	public String getLK_WK0051_PART1() {
		return LK_WK0051_PART1;
	}
	public void setLK_WK0051_PART1(String lK_WK0051_PART1) {
		LK_WK0051_PART1 = lK_WK0051_PART1;
	}
	public String getLK_WK0051_PART2() {
		return LK_WK0051_PART2;
	}
	public void setLK_WK0051_PART2(String lK_WK0051_PART2) {
		LK_WK0051_PART2 = lK_WK0051_PART2;
	}
	public String getLK_WK0051_UPMU_BUNRYU1() {
		return LK_WK0051_UPMU_BUNRYU1;
	}
	public void setLK_WK0051_UPMU_BUNRYU1(String lK_WK0051_UPMU_BUNRYU1) {
		LK_WK0051_UPMU_BUNRYU1 = lK_WK0051_UPMU_BUNRYU1;
	}
	public String getLK_WK0051_UPMU_BUNRYU2() {
		return LK_WK0051_UPMU_BUNRYU2;
	}
	public void setLK_WK0051_UPMU_BUNRYU2(String lK_WK0051_UPMU_BUNRYU2) {
		LK_WK0051_UPMU_BUNRYU2 = lK_WK0051_UPMU_BUNRYU2;
	}
	public String getLK_WK0051_UPMU_BUNRYU3() {
		return LK_WK0051_UPMU_BUNRYU3;
	}
	public void setLK_WK0051_UPMU_BUNRYU3(String lK_WK0051_UPMU_BUNRYU3) {
		LK_WK0051_UPMU_BUNRYU3 = lK_WK0051_UPMU_BUNRYU3;
	}
	public String getLK_WK0051_CON_YN() {
		return LK_WK0051_CON_YN;
	}
	public void setLK_WK0051_CON_YN(String lK_WK0051_CON_YN) {
		LK_WK0051_CON_YN = lK_WK0051_CON_YN;
	}
	public String getLK_WK0051_FIL1() {
		return LK_WK0051_FIL1;
	}
	public void setLK_WK0051_FIL1(String lK_WK0051_FIL1) {
		LK_WK0051_FIL1 = lK_WK0051_FIL1;
	}
	public String getLINK_WK0051_AREA_2() {
		return LINK_WK0051_AREA_2;
	}
	public void setLINK_WK0051_AREA_2(String lINK_WK0051_AREA_2) {
		LINK_WK0051_AREA_2 = lINK_WK0051_AREA_2;
	}
	public String getLK_WK0051_POLI_NO() {
		return LK_WK0051_POLI_NO;
	}
	public void setLK_WK0051_POLI_NO(String lK_WK0051_POLI_NO) {
		LK_WK0051_POLI_NO = lK_WK0051_POLI_NO;
	}
	public String getLK_WK0051_JOJIKWON_CD() {
		return LK_WK0051_JOJIKWON_CD;
	}
	public void setLK_WK0051_JOJIKWON_CD(String lK_WK0051_JOJIKWON_CD) {
		LK_WK0051_JOJIKWON_CD = lK_WK0051_JOJIKWON_CD;
	}
	public String getLK_WK0051_GYEYAK_TEL() {
		return LK_WK0051_GYEYAK_TEL;
	}
	public void setLK_WK0051_GYEYAK_TEL(String lK_WK0051_GYEYAK_TEL) {
		LK_WK0051_GYEYAK_TEL = lK_WK0051_GYEYAK_TEL;
	}
	public String getLK_WK0051_PIBO_TEL() {
		return LK_WK0051_PIBO_TEL;
	}
	public void setLK_WK0051_PIBO_TEL(String lK_WK0051_PIBO_TEL) {
		LK_WK0051_PIBO_TEL = lK_WK0051_PIBO_TEL;
	}
	public String getLK_WK0051_E_MAIL() {
		return LK_WK0051_E_MAIL;
	}
	public void setLK_WK0051_E_MAIL(String lK_WK0051_E_MAIL) {
		LK_WK0051_E_MAIL = lK_WK0051_E_MAIL;
	}
	public String getLK_WK0051_GMJONG_GB() {
		return LK_WK0051_GMJONG_GB;
	}
	public void setLK_WK0051_GMJONG_GB(String lK_WK0051_GMJONG_GB) {
		LK_WK0051_GMJONG_GB = lK_WK0051_GMJONG_GB;
	}
	public String getLK_WK0051_FIL() {
		return LK_WK0051_FIL;
	}
	public void setLK_WK0051_FIL(String lK_WK0051_FIL) {
		LK_WK0051_FIL = lK_WK0051_FIL;
	}
	public String getLINK_WK0051_AREA_4() {
		return LINK_WK0051_AREA_4;
	}
	public void setLINK_WK0051_AREA_4(String lINK_WK0051_AREA_4) {
		LINK_WK0051_AREA_4 = lINK_WK0051_AREA_4;
	}
	public String getLK_WK0051_YUNGSU_NO() {
		return LK_WK0051_YUNGSU_NO;
	}
	public void setLK_WK0051_YUNGSU_NO(String lK_WK0051_YUNGSU_NO) {
		LK_WK0051_YUNGSU_NO = lK_WK0051_YUNGSU_NO;
	}
	public String getLK_WK0051_CARDSA_GB() {
		return LK_WK0051_CARDSA_GB;
	}
	public void setLK_WK0051_CARDSA_GB(String lK_WK0051_CARDSA_GB) {
		LK_WK0051_CARDSA_GB = lK_WK0051_CARDSA_GB;
	}
	public String getLK_WK0051_CARD_NO() {
		return LK_WK0051_CARD_NO;
	}
	public void setLK_WK0051_CARD_NO(String lK_WK0051_CARD_NO) {
		LK_WK0051_CARD_NO = lK_WK0051_CARD_NO;
	}
	public String getLK_WK0051_CARD_USER_NAME() {
		return LK_WK0051_CARD_USER_NAME;
	}
	public void setLK_WK0051_CARD_USER_NAME(String lK_WK0051_CARD_USER_NAME) {
		LK_WK0051_CARD_USER_NAME = lK_WK0051_CARD_USER_NAME;
	}
	public String getLK_WK0051_YUHYO_GIGAN_YM() {
		return LK_WK0051_YUHYO_GIGAN_YM;
	}
	public void setLK_WK0051_YUHYO_GIGAN_YM(String lK_WK0051_YUHYO_GIGAN_YM) {
		LK_WK0051_YUHYO_GIGAN_YM = lK_WK0051_YUHYO_GIGAN_YM;
	}
	public String getLK_WK0051_HALBU_GB() {
		return LK_WK0051_HALBU_GB;
	}
	public void setLK_WK0051_HALBU_GB(String lK_WK0051_HALBU_GB) {
		LK_WK0051_HALBU_GB = lK_WK0051_HALBU_GB;
	}
	public String getLK_WK0051_HALBU_GIGAN() {
		return LK_WK0051_HALBU_GIGAN;
	}
	public void setLK_WK0051_HALBU_GIGAN(String lK_WK0051_HALBU_GIGAN) {
		LK_WK0051_HALBU_GIGAN = lK_WK0051_HALBU_GIGAN;
	}
	public String getLK_WK0051_GURE_AMT() {
		return LK_WK0051_GURE_AMT;
	}
	public void setLK_WK0051_GURE_AMT(String lK_WK0051_GURE_AMT) {
		LK_WK0051_GURE_AMT = lK_WK0051_GURE_AMT;
	}
	public String getLK_WK0051_SNGIN_YMD() {
		return LK_WK0051_SNGIN_YMD;
	}
	public void setLK_WK0051_SNGIN_YMD(String lK_WK0051_SNGIN_YMD) {
		LK_WK0051_SNGIN_YMD = lK_WK0051_SNGIN_YMD;
	}
	public String getLK_WK0051_SNGIN_NO() {
		return LK_WK0051_SNGIN_NO;
	}
	public void setLK_WK0051_SNGIN_NO(String lK_WK0051_SNGIN_NO) {
		LK_WK0051_SNGIN_NO = lK_WK0051_SNGIN_NO;
	}
	public String getLK_WK0051_BALGPSA_CD() {
		return LK_WK0051_BALGPSA_CD;
	}
	public void setLK_WK0051_BALGPSA_CD(String lK_WK0051_BALGPSA_CD) {
		LK_WK0051_BALGPSA_CD = lK_WK0051_BALGPSA_CD;
	}
	public String getLK_WK0051_VANSA_GUBUN() {
		return LK_WK0051_VANSA_GUBUN;
	}
	public void setLK_WK0051_VANSA_GUBUN(String lK_WK0051_VANSA_GUBUN) {
		LK_WK0051_VANSA_GUBUN = lK_WK0051_VANSA_GUBUN;
	}
	public String getLK_WK0051_SYSTEM_GUBUN() {
		return LK_WK0051_SYSTEM_GUBUN;
	}
	public void setLK_WK0051_SYSTEM_GUBUN(String lK_WK0051_SYSTEM_GUBUN) {
		LK_WK0051_SYSTEM_GUBUN = lK_WK0051_SYSTEM_GUBUN;
	}
	public String getLINK_WK0051_AREA_5() {
		return LINK_WK0051_AREA_5;
	}
	public void setLINK_WK0051_AREA_5(String lINK_WK0051_AREA_5) {
		LINK_WK0051_AREA_5 = lINK_WK0051_AREA_5;
	}
	public String getLK_WK0051_BANK_CD() {
		return LK_WK0051_BANK_CD;
	}
	public void setLK_WK0051_BANK_CD(String lK_WK0051_BANK_CD) {
		LK_WK0051_BANK_CD = lK_WK0051_BANK_CD;
	}
	public String getLK_WK0051_SMS_NO() {
		return LK_WK0051_SMS_NO;
	}
	public void setLK_WK0051_SMS_NO(String lK_WK0051_SMS_NO) {
		LK_WK0051_SMS_NO = lK_WK0051_SMS_NO;
	}
	public String getLK_WK0051_SMS_NO1() {
		return LK_WK0051_SMS_NO1;
	}
	public void setLK_WK0051_SMS_NO1(String lK_WK0051_SMS_NO1) {
		LK_WK0051_SMS_NO1 = lK_WK0051_SMS_NO1;
	}
	public String getLK_WK0051_SMS_NO2() {
		return LK_WK0051_SMS_NO2;
	}
	public void setLK_WK0051_SMS_NO2(String lK_WK0051_SMS_NO2) {
		LK_WK0051_SMS_NO2 = lK_WK0051_SMS_NO2;
	}
	public String getLK_WK0051_SMS_NO3() {
		return LK_WK0051_SMS_NO3;
	}
	public void setLK_WK0051_SMS_NO3(String lK_WK0051_SMS_NO3) {
		LK_WK0051_SMS_NO3 = lK_WK0051_SMS_NO3;
	}
	public String getLK_WK0051_GYEJWA_NO() {
		return LK_WK0051_GYEJWA_NO;
	}
	public void setLK_WK0051_GYEJWA_NO(String lK_WK0051_GYEJWA_NO) {
		LK_WK0051_GYEJWA_NO = lK_WK0051_GYEJWA_NO;
	}
	public String getLK_WK0051_NAPIP_PRM() {
		return LK_WK0051_NAPIP_PRM;
	}
	public void setLK_WK0051_NAPIP_PRM(String lK_WK0051_NAPIP_PRM) {
		LK_WK0051_NAPIP_PRM = lK_WK0051_NAPIP_PRM;
	}
	public String getLK_WK0051_CHAEKIM_EYMD() {
		return LK_WK0051_CHAEKIM_EYMD;
	}
	public void setLK_WK0051_CHAEKIM_EYMD(String lK_WK0051_CHAEKIM_EYMD) {
		LK_WK0051_CHAEKIM_EYMD = lK_WK0051_CHAEKIM_EYMD;
	}
	public String getLK_WK0051_FILLER1() {
		return LK_WK0051_FILLER1;
	}
	public void setLK_WK0051_FILLER1(String lK_WK0051_FILLER1) {
		LK_WK0051_FILLER1 = lK_WK0051_FILLER1;
	}
	public String getLK_WK0051_CARD_JUNPYO() {
		return LK_WK0051_CARD_JUNPYO;
	}
	public void setLK_WK0051_CARD_JUNPYO(String lK_WK0051_CARD_JUNPYO) {
		LK_WK0051_CARD_JUNPYO = lK_WK0051_CARD_JUNPYO;
	}
	public String getLK_WK0051_RC() {
		return LK_WK0051_RC;
	}
	public void setLK_WK0051_RC(String lK_WK0051_RC) {
		LK_WK0051_RC = lK_WK0051_RC;
	}
	public String getLK_WK0051_MSG_CD1() {
		return LK_WK0051_MSG_CD1;
	}
	public void setLK_WK0051_MSG_CD1(String lK_WK0051_MSG_CD1) {
		LK_WK0051_MSG_CD1 = lK_WK0051_MSG_CD1;
	}
	public String getLK_WK0051_MSG_CD2() {
		return LK_WK0051_MSG_CD2;
	}
	public void setLK_WK0051_MSG_CD2(String lK_WK0051_MSG_CD2) {
		LK_WK0051_MSG_CD2 = lK_WK0051_MSG_CD2;
	}
	public String getLK_WK0051_MSG_ERR1() {
		return LK_WK0051_MSG_ERR1;
	}
	public void setLK_WK0051_MSG_ERR1(String lK_WK0051_MSG_ERR1) {
		LK_WK0051_MSG_ERR1 = lK_WK0051_MSG_ERR1;
	}
	public String getLK_WK0051_MSG_ERR2() {
		return LK_WK0051_MSG_ERR2;
	}
	public void setLK_WK0051_MSG_ERR2(String lK_WK0051_MSG_ERR2) {
		LK_WK0051_MSG_ERR2 = lK_WK0051_MSG_ERR2;
	}
	
	
}
