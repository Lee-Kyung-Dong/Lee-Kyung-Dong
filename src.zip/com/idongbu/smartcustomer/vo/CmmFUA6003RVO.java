package com.idongbu.smartcustomer.vo;

import com.idongbu.common.vo.CMMVO;

// 장기계약조회
public class CmmFUA6003RVO extends CMMVO {
	
	public CmmFUA6003RVO() {
		super.setPGMID(this.proid);
		super.setTRID(this.trid);
	}	
	
	public static final String proid		= "FUA6003R";
	public static final String trid			= "UA63";
	public String rURL						= "";

	// 입력
	public String CC_SYSTEM_AREA = null; // <<시스템공통>>
	public String CC_TRAN_CD     = null; // TRANSACTION-CODE
	public String CC_TRAN_FLAG   = null; // 송수신 FLAG(K:외부에서 송신시,I:당사에서송신시)
	public String CC_NET_RC      = null; // NETWORK응답코드(00:정상,  01:장애)
	public String CC_TRAN_G_TIME = null; // 전문전송시간
	public String CC_PARTNER_GB  = null; // 제휴사(01.은행,02.기업,03.기타)
	public String CC_PARTNER_CD  = null; // 제휴사코드
	public String CC_SYSFIL      = null; // FILLER
	public String CC_GIGANGE_AREA = null; // <<기간계공통>>
	public String CC_USER_ID      = null; // 사용자 ID
	public String CC_PART_GY_COM1 = null; // 파트고유공통1
	public String CC_PART_GY_COM2 = null; // 파트고유공통2
	public String CC_UPMU_BUNRYU1 = null; // 업무분류(01.계약,02.보상,03.회계,04.영업관리,05.일반관리)
	public String CC_UPMU_BUNRYU2 = null; // 업무분류(01.공통(계약/보상),02.자동차,03.장기,04.기업연금,05.일반손보)
	public String CC_UPMU_BUNRYU3 = null; // 업무분류(일반손보인경우 사용 01:공통(일반손보),02:화재,03:특종,04.해상)
	public String CC_CONTINUE_GB  = null; // 연속거래구분(SPACE:SINGLE(3900BYTE 1 RECORD),C: 연속 (3900BYTE 초과))
	public String CC_COMFIL       = null; // FILLER
	public String JJ_JANGGI_AREA = null; // <<장기공통>>
	public String JJ_UPMU_CD       = null; // 업무기능(10.설계,20.계약,30.배서,90.약관대출)
	public String JJ_MAP_ID        = null; // 화면번호(1715)
	public String JJ_CHURI_GUBUN   = null; // 처리구분(1.입력,2.조회,3.수정,4.삭제)
	public String JJ_HWAKJUNG_YN   = null; // 확정여부코드(1. 확정)
	public String JJ_SULGYE_NO     = null; // 설계번호
	public String JJ_POLI_NO       = null; // 증권번호
	public String JJ_BESU_CNT      = null; // 배서횟수
	public String JJ_YUNGSUJNG_NO  = null; // 영수증번호
	public String JJ_JIJUM_CODE    = null; // 지점코드
	public String JJ_JIBU_CODE     = null; // 지부코드
	public String JJ_CHIGB_SABUN   = null; // 취급자
	public String JJ_GY_JUMIN_NO   = null; // 계약자주민번호
	public String JJ_PB_JUMIN_NO   = null; // 피보험자주민번호
	public String JJ_GYEJWA_NO     = null; // 계좌번호

	// 출력
	public String CC_MESSAGE2 = null;
	public String CC_MSG_CD1 = null;
	public String CC_MSG_CD2 = null;
	public String CC_RETURN_CD = null;
	public String HC_MESSAGE1 = null;
	public String JJ_DATA_FIL = null;
	public String JJ_JANGGI_FIL = null;
	public String JJ_PAGE_NO = null;
	public String JJ_PAGE_TOT_CNT = null;
	public String JJ_PAGE_TOT_NO = null;
	public String JJ_SAGO_JUBSU_NO = null;
	public String JJ_SAGO_JUBSU_NO2 = null;
	public String Length = null;
	public String RecordName = null;
	public String RecordShortDescription = null;
	public String Version = null;
	public String getrURL() {
		return rURL;
	}
	public void setrURL(String rURL) {
		this.rURL = rURL;
	}
	public String getCC_SYSTEM_AREA() {
		return CC_SYSTEM_AREA;
	}
	public void setCC_SYSTEM_AREA(String cC_SYSTEM_AREA) {
		CC_SYSTEM_AREA = cC_SYSTEM_AREA;
	}
	public String getCC_TRAN_CD() {
		return CC_TRAN_CD;
	}
	public void setCC_TRAN_CD(String cC_TRAN_CD) {
		CC_TRAN_CD = cC_TRAN_CD;
	}
	public String getCC_TRAN_FLAG() {
		return CC_TRAN_FLAG;
	}
	public void setCC_TRAN_FLAG(String cC_TRAN_FLAG) {
		CC_TRAN_FLAG = cC_TRAN_FLAG;
	}
	public String getCC_NET_RC() {
		return CC_NET_RC;
	}
	public void setCC_NET_RC(String cC_NET_RC) {
		CC_NET_RC = cC_NET_RC;
	}
	public String getCC_TRAN_G_TIME() {
		return CC_TRAN_G_TIME;
	}
	public void setCC_TRAN_G_TIME(String cC_TRAN_G_TIME) {
		CC_TRAN_G_TIME = cC_TRAN_G_TIME;
	}
	public String getCC_PARTNER_GB() {
		return CC_PARTNER_GB;
	}
	public void setCC_PARTNER_GB(String cC_PARTNER_GB) {
		CC_PARTNER_GB = cC_PARTNER_GB;
	}
	public String getCC_PARTNER_CD() {
		return CC_PARTNER_CD;
	}
	public void setCC_PARTNER_CD(String cC_PARTNER_CD) {
		CC_PARTNER_CD = cC_PARTNER_CD;
	}
	public String getCC_SYSFIL() {
		return CC_SYSFIL;
	}
	public void setCC_SYSFIL(String cC_SYSFIL) {
		CC_SYSFIL = cC_SYSFIL;
	}
	public String getCC_GIGANGE_AREA() {
		return CC_GIGANGE_AREA;
	}
	public void setCC_GIGANGE_AREA(String cC_GIGANGE_AREA) {
		CC_GIGANGE_AREA = cC_GIGANGE_AREA;
	}
	public String getCC_USER_ID() {
		return CC_USER_ID;
	}
	public void setCC_USER_ID(String cC_USER_ID) {
		CC_USER_ID = cC_USER_ID;
	}
	public String getCC_PART_GY_COM1() {
		return CC_PART_GY_COM1;
	}
	public void setCC_PART_GY_COM1(String cC_PART_GY_COM1) {
		CC_PART_GY_COM1 = cC_PART_GY_COM1;
	}
	public String getCC_PART_GY_COM2() {
		return CC_PART_GY_COM2;
	}
	public void setCC_PART_GY_COM2(String cC_PART_GY_COM2) {
		CC_PART_GY_COM2 = cC_PART_GY_COM2;
	}
	public String getCC_UPMU_BUNRYU1() {
		return CC_UPMU_BUNRYU1;
	}
	public void setCC_UPMU_BUNRYU1(String cC_UPMU_BUNRYU1) {
		CC_UPMU_BUNRYU1 = cC_UPMU_BUNRYU1;
	}
	public String getCC_UPMU_BUNRYU2() {
		return CC_UPMU_BUNRYU2;
	}
	public void setCC_UPMU_BUNRYU2(String cC_UPMU_BUNRYU2) {
		CC_UPMU_BUNRYU2 = cC_UPMU_BUNRYU2;
	}
	public String getCC_UPMU_BUNRYU3() {
		return CC_UPMU_BUNRYU3;
	}
	public void setCC_UPMU_BUNRYU3(String cC_UPMU_BUNRYU3) {
		CC_UPMU_BUNRYU3 = cC_UPMU_BUNRYU3;
	}
	public String getCC_CONTINUE_GB() {
		return CC_CONTINUE_GB;
	}
	public void setCC_CONTINUE_GB(String cC_CONTINUE_GB) {
		CC_CONTINUE_GB = cC_CONTINUE_GB;
	}
	public String getCC_COMFIL() {
		return CC_COMFIL;
	}
	public void setCC_COMFIL(String cC_COMFIL) {
		CC_COMFIL = cC_COMFIL;
	}
	public String getJJ_JANGGI_AREA() {
		return JJ_JANGGI_AREA;
	}
	public void setJJ_JANGGI_AREA(String jJ_JANGGI_AREA) {
		JJ_JANGGI_AREA = jJ_JANGGI_AREA;
	}
	public String getJJ_UPMU_CD() {
		return JJ_UPMU_CD;
	}
	public void setJJ_UPMU_CD(String jJ_UPMU_CD) {
		JJ_UPMU_CD = jJ_UPMU_CD;
	}
	public String getJJ_MAP_ID() {
		return JJ_MAP_ID;
	}
	public void setJJ_MAP_ID(String jJ_MAP_ID) {
		JJ_MAP_ID = jJ_MAP_ID;
	}
	public String getJJ_CHURI_GUBUN() {
		return JJ_CHURI_GUBUN;
	}
	public void setJJ_CHURI_GUBUN(String jJ_CHURI_GUBUN) {
		JJ_CHURI_GUBUN = jJ_CHURI_GUBUN;
	}
	public String getJJ_HWAKJUNG_YN() {
		return JJ_HWAKJUNG_YN;
	}
	public void setJJ_HWAKJUNG_YN(String jJ_HWAKJUNG_YN) {
		JJ_HWAKJUNG_YN = jJ_HWAKJUNG_YN;
	}
	public String getJJ_SULGYE_NO() {
		return JJ_SULGYE_NO;
	}
	public void setJJ_SULGYE_NO(String jJ_SULGYE_NO) {
		JJ_SULGYE_NO = jJ_SULGYE_NO;
	}
	public String getJJ_POLI_NO() {
		return JJ_POLI_NO;
	}
	public void setJJ_POLI_NO(String jJ_POLI_NO) {
		JJ_POLI_NO = jJ_POLI_NO;
	}
	public String getJJ_BESU_CNT() {
		return JJ_BESU_CNT;
	}
	public void setJJ_BESU_CNT(String jJ_BESU_CNT) {
		JJ_BESU_CNT = jJ_BESU_CNT;
	}
	public String getJJ_YUNGSUJNG_NO() {
		return JJ_YUNGSUJNG_NO;
	}
	public void setJJ_YUNGSUJNG_NO(String jJ_YUNGSUJNG_NO) {
		JJ_YUNGSUJNG_NO = jJ_YUNGSUJNG_NO;
	}
	public String getJJ_JIJUM_CODE() {
		return JJ_JIJUM_CODE;
	}
	public void setJJ_JIJUM_CODE(String jJ_JIJUM_CODE) {
		JJ_JIJUM_CODE = jJ_JIJUM_CODE;
	}
	public String getJJ_JIBU_CODE() {
		return JJ_JIBU_CODE;
	}
	public void setJJ_JIBU_CODE(String jJ_JIBU_CODE) {
		JJ_JIBU_CODE = jJ_JIBU_CODE;
	}
	public String getJJ_CHIGB_SABUN() {
		return JJ_CHIGB_SABUN;
	}
	public void setJJ_CHIGB_SABUN(String jJ_CHIGB_SABUN) {
		JJ_CHIGB_SABUN = jJ_CHIGB_SABUN;
	}
	public String getJJ_GY_JUMIN_NO() {
		return JJ_GY_JUMIN_NO;
	}
	public void setJJ_GY_JUMIN_NO(String jJ_GY_JUMIN_NO) {
		JJ_GY_JUMIN_NO = jJ_GY_JUMIN_NO;
	}
	public String getJJ_PB_JUMIN_NO() {
		return JJ_PB_JUMIN_NO;
	}
	public void setJJ_PB_JUMIN_NO(String jJ_PB_JUMIN_NO) {
		JJ_PB_JUMIN_NO = jJ_PB_JUMIN_NO;
	}
	public String getJJ_GYEJWA_NO() {
		return JJ_GYEJWA_NO;
	}
	public void setJJ_GYEJWA_NO(String jJ_GYEJWA_NO) {
		JJ_GYEJWA_NO = jJ_GYEJWA_NO;
	}
	public String getCC_MESSAGE2() {
		return CC_MESSAGE2;
	}
	public void setCC_MESSAGE2(String cC_MESSAGE2) {
		CC_MESSAGE2 = cC_MESSAGE2;
	}
	public String getCC_MSG_CD1() {
		return CC_MSG_CD1;
	}
	public void setCC_MSG_CD1(String cC_MSG_CD1) {
		CC_MSG_CD1 = cC_MSG_CD1;
	}
	public String getCC_MSG_CD2() {
		return CC_MSG_CD2;
	}
	public void setCC_MSG_CD2(String cC_MSG_CD2) {
		CC_MSG_CD2 = cC_MSG_CD2;
	}
	public String getCC_RETURN_CD() {
		return CC_RETURN_CD;
	}
	public void setCC_RETURN_CD(String cC_RETURN_CD) {
		CC_RETURN_CD = cC_RETURN_CD;
	}
	public String getHC_MESSAGE1() {
		return HC_MESSAGE1;
	}
	public void setHC_MESSAGE1(String hC_MESSAGE1) {
		HC_MESSAGE1 = hC_MESSAGE1;
	}
	public String getJJ_DATA_FIL() {
		return JJ_DATA_FIL;
	}
	public void setJJ_DATA_FIL(String jJ_DATA_FIL) {
		JJ_DATA_FIL = jJ_DATA_FIL;
	}
	public String getJJ_JANGGI_FIL() {
		return JJ_JANGGI_FIL;
	}
	public void setJJ_JANGGI_FIL(String jJ_JANGGI_FIL) {
		JJ_JANGGI_FIL = jJ_JANGGI_FIL;
	}
	public String getJJ_PAGE_NO() {
		return JJ_PAGE_NO;
	}
	public void setJJ_PAGE_NO(String jJ_PAGE_NO) {
		JJ_PAGE_NO = jJ_PAGE_NO;
	}
	public String getJJ_PAGE_TOT_CNT() {
		return JJ_PAGE_TOT_CNT;
	}
	public void setJJ_PAGE_TOT_CNT(String jJ_PAGE_TOT_CNT) {
		JJ_PAGE_TOT_CNT = jJ_PAGE_TOT_CNT;
	}
	public String getJJ_PAGE_TOT_NO() {
		return JJ_PAGE_TOT_NO;
	}
	public void setJJ_PAGE_TOT_NO(String jJ_PAGE_TOT_NO) {
		JJ_PAGE_TOT_NO = jJ_PAGE_TOT_NO;
	}
	public String getJJ_SAGO_JUBSU_NO() {
		return JJ_SAGO_JUBSU_NO;
	}
	public void setJJ_SAGO_JUBSU_NO(String jJ_SAGO_JUBSU_NO) {
		JJ_SAGO_JUBSU_NO = jJ_SAGO_JUBSU_NO;
	}
	public String getJJ_SAGO_JUBSU_NO2() {
		return JJ_SAGO_JUBSU_NO2;
	}
	public void setJJ_SAGO_JUBSU_NO2(String jJ_SAGO_JUBSU_NO2) {
		JJ_SAGO_JUBSU_NO2 = jJ_SAGO_JUBSU_NO2;
	}
	public String getLength() {
		return Length;
	}
	public void setLength(String length) {
		Length = length;
	}
	public String getRecordName() {
		return RecordName;
	}
	public void setRecordName(String recordName) {
		RecordName = recordName;
	}
	public String getRecordShortDescription() {
		return RecordShortDescription;
	}
	public void setRecordShortDescription(String recordShortDescription) {
		RecordShortDescription = recordShortDescription;
	}
	public String getVersion() {
		return Version;
	}
	public void setVersion(String version) {
		Version = version;
	}
	public static String getProid() {
		return proid;
	}
	public static String getTrid() {
		return trid;
	}
	
}
