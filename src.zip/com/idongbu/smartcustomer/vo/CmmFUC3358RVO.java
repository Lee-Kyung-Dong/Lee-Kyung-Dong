package com.idongbu.smartcustomer.vo;

import com.idongbu.common.vo.CMMVO;

public class CmmFUC3358RVO extends CMMVO {

	public CmmFUC3358RVO() {
		super.setPGMID(proid);
		super.setTRID(trid);
	}
	
	private final static String proid		= "FUC3358R";
	private final static String trid		= "UCP7";
	
	private String CC_CHANNEL;
	private String CC_UKEY;
	private String CC_PGMID;
	private String CC_PROC_GB;
	private String CC_FUN_KEY;
	
	private String CC_USER_GB;
	private String CC_USER_CD;
	
	private String CC_JIJUM_CD;
	private String CC_JIBU_CD;
	
	private String CC_PROTOCOL;
	private String CC_COND_CD;
	private String CC_LAST_FLAG;
	private String CC_CURSOR_MAP;
	private String CC_CURSOR_IDX;
	private String CC_MESSAGE_CD;
	private String HC_MESSAGE_NM;
	private String CC_SYS_ERR;
	private String CC_TS_ITEM;
	private String CC_FORM_ID;
	private String CC_PRT_GB;
	private String CC_PRINT_GB;
	private String CC_PRINT_TYPE;
	private String CC_RD_FUN_KEY;
	private String CC_FILLER;
	
	private String JJ_GUBUN;
	private String JJ_PRT_GBN;
	private String JJ_BAL_HANG_JA;
	private String JJ_BAL_YMD;
	private String JJ_JUMIN;
	private String JJ_POLI_NO;
	private String JJ_2654_SODK_YY;
	
	private String JJ_CHUL_GUBUN_O;
	private String JJ_POLI_NO_O;
	private String HJ_GYEYAKJA_O;
	private String JJ_JUMIN_O;
	private String HJ_SUGUM_O;
	private String HJ_BUN_NAME_O;
	private String JJ_NAPIP_WEL_O;
	private String HJ_SANG_NAME_O;
	private String JJ_SANG_YMD_O;
	private String JJ_POLI_NO_H;
	
	private String HJ_MOKJUK_TXT;
	
	private String UU_UDA_CUR_PAGE;
	
	private String UU_UDA1_GYEYAKJA;
	private String UU_UDA1_JUMIN;
	private String UU_UDA1_BAL_HANG_JA;
	private String UU_UDA1_BAL_YMD;
	private String UU_UDA1_SODK_YY;
	private String UU_UDA1_SANG_YMD;
	
	private String UU_UDA1_POLI_NO;
	
	private String UU_UDA2_JUMIN;
	private String UU_UDA2_BAL_HANG_JA;
	private String UU_UDA2_BAL_YMD;
	private String UU_UDA2_JIJUM_CD;
	private String UU_UDA2_JIBU_CD;
	private String UU_UDA2_GYEYAKJA;
	
	private String UU_UDA2_POLI_NO;
	
	private String UUC_C_POLI_NO;
	
	private String UUC_F_POLI_NO;
	
	private String UUC_L_POLI_NO;
	
	private String UU_FUC3358R_PRT;
	private String UU_PRT_DATA;
	
	private String RD_POLICY_YN;
	private String RD_COPY_YN;
	private String RD_GREEN_YN;
	private String RD_ENCRYPT_YN;
	private String RD_ENCRYPT_KEY;
	private String RD_UPMU_GB;
	private String RD_DOCU_GB;
	private String RD_SIGN_KEY;
	private String RD_FORM_GB;
	
	public String getCC_CHANNEL() {
		return CC_CHANNEL;
	}
	public void setCC_CHANNEL(String cC_CHANNEL) {
		CC_CHANNEL = cC_CHANNEL;
	}
	public String getCC_UKEY() {
		return CC_UKEY;
	}
	public void setCC_UKEY(String cC_UKEY) {
		CC_UKEY = cC_UKEY;
	}
	public String getCC_PGMID() {
		return CC_PGMID;
	}
	public void setCC_PGMID(String cC_PGMID) {
		CC_PGMID = cC_PGMID;
	}
	public String getCC_PROC_GB() {
		return CC_PROC_GB;
	}
	public void setCC_PROC_GB(String cC_PROC_GB) {
		CC_PROC_GB = cC_PROC_GB;
	}
	public String getCC_FUN_KEY() {
		return CC_FUN_KEY;
	}
	public void setCC_FUN_KEY(String cC_FUN_KEY) {
		CC_FUN_KEY = cC_FUN_KEY;
	}
	public String getCC_USER_GB() {
		return CC_USER_GB;
	}
	public void setCC_USER_GB(String cC_USER_GB) {
		CC_USER_GB = cC_USER_GB;
	}
	public String getCC_USER_CD() {
		return CC_USER_CD;
	}
	public void setCC_USER_CD(String cC_USER_CD) {
		CC_USER_CD = cC_USER_CD;
	}
	public String getCC_JIJUM_CD() {
		return CC_JIJUM_CD;
	}
	public void setCC_JIJUM_CD(String cC_JIJUM_CD) {
		CC_JIJUM_CD = cC_JIJUM_CD;
	}
	public String getCC_JIBU_CD() {
		return CC_JIBU_CD;
	}
	public void setCC_JIBU_CD(String cC_JIBU_CD) {
		CC_JIBU_CD = cC_JIBU_CD;
	}
	public String getCC_PROTOCOL() {
		return CC_PROTOCOL;
	}
	public void setCC_PROTOCOL(String cC_PROTOCOL) {
		CC_PROTOCOL = cC_PROTOCOL;
	}
	public String getCC_COND_CD() {
		return CC_COND_CD;
	}
	public void setCC_COND_CD(String cC_COND_CD) {
		CC_COND_CD = cC_COND_CD;
	}
	public String getCC_LAST_FLAG() {
		return CC_LAST_FLAG;
	}
	public void setCC_LAST_FLAG(String cC_LAST_FLAG) {
		CC_LAST_FLAG = cC_LAST_FLAG;
	}
	public String getCC_CURSOR_MAP() {
		return CC_CURSOR_MAP;
	}
	public void setCC_CURSOR_MAP(String cC_CURSOR_MAP) {
		CC_CURSOR_MAP = cC_CURSOR_MAP;
	}
	public String getCC_CURSOR_IDX() {
		return CC_CURSOR_IDX;
	}
	public void setCC_CURSOR_IDX(String cC_CURSOR_IDX) {
		CC_CURSOR_IDX = cC_CURSOR_IDX;
	}
	public String getCC_MESSAGE_CD() {
		return CC_MESSAGE_CD;
	}
	public void setCC_MESSAGE_CD(String cC_MESSAGE_CD) {
		CC_MESSAGE_CD = cC_MESSAGE_CD;
	}
	public String getHC_MESSAGE_NM() {
		return HC_MESSAGE_NM;
	}
	public void setHC_MESSAGE_NM(String hC_MESSAGE_NM) {
		HC_MESSAGE_NM = hC_MESSAGE_NM;
	}
	public String getCC_SYS_ERR() {
		return CC_SYS_ERR;
	}
	public void setCC_SYS_ERR(String cC_SYS_ERR) {
		CC_SYS_ERR = cC_SYS_ERR;
	}
	public String getCC_TS_ITEM() {
		return CC_TS_ITEM;
	}
	public void setCC_TS_ITEM(String cC_TS_ITEM) {
		CC_TS_ITEM = cC_TS_ITEM;
	}
	public String getCC_FORM_ID() {
		return CC_FORM_ID;
	}
	public void setCC_FORM_ID(String cC_FORM_ID) {
		CC_FORM_ID = cC_FORM_ID;
	}
	public String getCC_PRT_GB() {
		return CC_PRT_GB;
	}
	public void setCC_PRT_GB(String cC_PRT_GB) {
		CC_PRT_GB = cC_PRT_GB;
	}
	public String getCC_PRINT_GB() {
		return CC_PRINT_GB;
	}
	public void setCC_PRINT_GB(String cC_PRINT_GB) {
		CC_PRINT_GB = cC_PRINT_GB;
	}
	public String getCC_PRINT_TYPE() {
		return CC_PRINT_TYPE;
	}
	public void setCC_PRINT_TYPE(String cC_PRINT_TYPE) {
		CC_PRINT_TYPE = cC_PRINT_TYPE;
	}
	public String getCC_RD_FUN_KEY() {
		return CC_RD_FUN_KEY;
	}
	public void setCC_RD_FUN_KEY(String cC_RD_FUN_KEY) {
		CC_RD_FUN_KEY = cC_RD_FUN_KEY;
	}
	public String getCC_FILLER() {
		return CC_FILLER;
	}
	public void setCC_FILLER(String cC_FILLER) {
		CC_FILLER = cC_FILLER;
	}
	public String getJJ_GUBUN() {
		return JJ_GUBUN;
	}
	public void setJJ_GUBUN(String jJ_GUBUN) {
		JJ_GUBUN = jJ_GUBUN;
	}
	public String getJJ_PRT_GBN() {
		return JJ_PRT_GBN;
	}
	public void setJJ_PRT_GBN(String jJ_PRT_GBN) {
		JJ_PRT_GBN = jJ_PRT_GBN;
	}
	public String getJJ_BAL_HANG_JA() {
		return JJ_BAL_HANG_JA;
	}
	public void setJJ_BAL_HANG_JA(String jJ_BAL_HANG_JA) {
		JJ_BAL_HANG_JA = jJ_BAL_HANG_JA;
	}
	public String getJJ_BAL_YMD() {
		return JJ_BAL_YMD;
	}
	public void setJJ_BAL_YMD(String jJ_BAL_YMD) {
		JJ_BAL_YMD = jJ_BAL_YMD;
	}
	public String getJJ_JUMIN() {
		return JJ_JUMIN;
	}
	public void setJJ_JUMIN(String jJ_JUMIN) {
		JJ_JUMIN = jJ_JUMIN;
	}
	public String getJJ_POLI_NO() {
		return JJ_POLI_NO;
	}
	public void setJJ_POLI_NO(String jJ_POLI_NO) {
		JJ_POLI_NO = jJ_POLI_NO;
	}
	public String getJJ_2654_SODK_YY() {
		return JJ_2654_SODK_YY;
	}
	public void setJJ_2654_SODK_YY(String jJ_2654_SODK_YY) {
		JJ_2654_SODK_YY = jJ_2654_SODK_YY;
	}
	public String getJJ_CHUL_GUBUN_O() {
		return JJ_CHUL_GUBUN_O;
	}
	public void setJJ_CHUL_GUBUN_O(String jJ_CHUL_GUBUN_O) {
		JJ_CHUL_GUBUN_O = jJ_CHUL_GUBUN_O;
	}
	public String getJJ_POLI_NO_O() {
		return JJ_POLI_NO_O;
	}
	public void setJJ_POLI_NO_O(String jJ_POLI_NO_O) {
		JJ_POLI_NO_O = jJ_POLI_NO_O;
	}
	public String getHJ_GYEYAKJA_O() {
		return HJ_GYEYAKJA_O;
	}
	public void setHJ_GYEYAKJA_O(String hJ_GYEYAKJA_O) {
		HJ_GYEYAKJA_O = hJ_GYEYAKJA_O;
	}
	public String getJJ_JUMIN_O() {
		return JJ_JUMIN_O;
	}
	public void setJJ_JUMIN_O(String jJ_JUMIN_O) {
		JJ_JUMIN_O = jJ_JUMIN_O;
	}
	public String getHJ_SUGUM_O() {
		return HJ_SUGUM_O;
	}
	public void setHJ_SUGUM_O(String hJ_SUGUM_O) {
		HJ_SUGUM_O = hJ_SUGUM_O;
	}
	public String getHJ_BUN_NAME_O() {
		return HJ_BUN_NAME_O;
	}
	public void setHJ_BUN_NAME_O(String hJ_BUN_NAME_O) {
		HJ_BUN_NAME_O = hJ_BUN_NAME_O;
	}
	public String getJJ_NAPIP_WEL_O() {
		return JJ_NAPIP_WEL_O;
	}
	public void setJJ_NAPIP_WEL_O(String jJ_NAPIP_WEL_O) {
		JJ_NAPIP_WEL_O = jJ_NAPIP_WEL_O;
	}
	public String getHJ_SANG_NAME_O() {
		return HJ_SANG_NAME_O;
	}
	public void setHJ_SANG_NAME_O(String hJ_SANG_NAME_O) {
		HJ_SANG_NAME_O = hJ_SANG_NAME_O;
	}
	public String getJJ_SANG_YMD_O() {
		return JJ_SANG_YMD_O;
	}
	public void setJJ_SANG_YMD_O(String jJ_SANG_YMD_O) {
		JJ_SANG_YMD_O = jJ_SANG_YMD_O;
	}
	public String getHJ_MOKJUK_TXT() {
		return HJ_MOKJUK_TXT;
	}
	public void setHJ_MOKJUK_TXT(String hJ_MOKJUK_TXT) {
		HJ_MOKJUK_TXT = hJ_MOKJUK_TXT;
	}
	public String getUU_UDA_CUR_PAGE() {
		return UU_UDA_CUR_PAGE;
	}
	public void setUU_UDA_CUR_PAGE(String uU_UDA_CUR_PAGE) {
		UU_UDA_CUR_PAGE = uU_UDA_CUR_PAGE;
	}
	public String getUU_UDA1_GYEYAKJA() {
		return UU_UDA1_GYEYAKJA;
	}
	public void setUU_UDA1_GYEYAKJA(String uU_UDA1_GYEYAKJA) {
		UU_UDA1_GYEYAKJA = uU_UDA1_GYEYAKJA;
	}
	public String getUU_UDA1_JUMIN() {
		return UU_UDA1_JUMIN;
	}
	public void setUU_UDA1_JUMIN(String uU_UDA1_JUMIN) {
		UU_UDA1_JUMIN = uU_UDA1_JUMIN;
	}
	public String getUU_UDA1_BAL_HANG_JA() {
		return UU_UDA1_BAL_HANG_JA;
	}
	public void setUU_UDA1_BAL_HANG_JA(String uU_UDA1_BAL_HANG_JA) {
		UU_UDA1_BAL_HANG_JA = uU_UDA1_BAL_HANG_JA;
	}
	public String getUU_UDA1_BAL_YMD() {
		return UU_UDA1_BAL_YMD;
	}
	public void setUU_UDA1_BAL_YMD(String uU_UDA1_BAL_YMD) {
		UU_UDA1_BAL_YMD = uU_UDA1_BAL_YMD;
	}
	public String getUU_UDA1_SODK_YY() {
		return UU_UDA1_SODK_YY;
	}
	public void setUU_UDA1_SODK_YY(String uU_UDA1_SODK_YY) {
		UU_UDA1_SODK_YY = uU_UDA1_SODK_YY;
	}
	public String getUU_UDA1_SANG_YMD() {
		return UU_UDA1_SANG_YMD;
	}
	public void setUU_UDA1_SANG_YMD(String uU_UDA1_SANG_YMD) {
		UU_UDA1_SANG_YMD = uU_UDA1_SANG_YMD;
	}
	public String getUU_UDA1_POLI_NO() {
		return UU_UDA1_POLI_NO;
	}
	public void setUU_UDA1_POLI_NO(String uU_UDA1_POLI_NO) {
		UU_UDA1_POLI_NO = uU_UDA1_POLI_NO;
	}
	public String getUU_UDA2_JUMIN() {
		return UU_UDA2_JUMIN;
	}
	public void setUU_UDA2_JUMIN(String uU_UDA2_JUMIN) {
		UU_UDA2_JUMIN = uU_UDA2_JUMIN;
	}
	public String getUU_UDA2_BAL_HANG_JA() {
		return UU_UDA2_BAL_HANG_JA;
	}
	public void setUU_UDA2_BAL_HANG_JA(String uU_UDA2_BAL_HANG_JA) {
		UU_UDA2_BAL_HANG_JA = uU_UDA2_BAL_HANG_JA;
	}
	public String getUU_UDA2_BAL_YMD() {
		return UU_UDA2_BAL_YMD;
	}
	public void setUU_UDA2_BAL_YMD(String uU_UDA2_BAL_YMD) {
		UU_UDA2_BAL_YMD = uU_UDA2_BAL_YMD;
	}
	public String getUU_UDA2_JIJUM_CD() {
		return UU_UDA2_JIJUM_CD;
	}
	public void setUU_UDA2_JIJUM_CD(String uU_UDA2_JIJUM_CD) {
		UU_UDA2_JIJUM_CD = uU_UDA2_JIJUM_CD;
	}
	public String getUU_UDA2_JIBU_CD() {
		return UU_UDA2_JIBU_CD;
	}
	public void setUU_UDA2_JIBU_CD(String uU_UDA2_JIBU_CD) {
		UU_UDA2_JIBU_CD = uU_UDA2_JIBU_CD;
	}
	public String getUU_UDA2_GYEYAKJA() {
		return UU_UDA2_GYEYAKJA;
	}
	public void setUU_UDA2_GYEYAKJA(String uU_UDA2_GYEYAKJA) {
		UU_UDA2_GYEYAKJA = uU_UDA2_GYEYAKJA;
	}
	public String getUU_UDA2_POLI_NO() {
		return UU_UDA2_POLI_NO;
	}
	public void setUU_UDA2_POLI_NO(String uU_UDA2_POLI_NO) {
		UU_UDA2_POLI_NO = uU_UDA2_POLI_NO;
	}
	public String getUUC_C_POLI_NO() {
		return UUC_C_POLI_NO;
	}
	public void setUUC_C_POLI_NO(String uUC_C_POLI_NO) {
		UUC_C_POLI_NO = uUC_C_POLI_NO;
	}
	public String getUUC_F_POLI_NO() {
		return UUC_F_POLI_NO;
	}
	public void setUUC_F_POLI_NO(String uUC_F_POLI_NO) {
		UUC_F_POLI_NO = uUC_F_POLI_NO;
	}
	public String getUUC_L_POLI_NO() {
		return UUC_L_POLI_NO;
	}
	public void setUUC_L_POLI_NO(String uUC_L_POLI_NO) {
		UUC_L_POLI_NO = uUC_L_POLI_NO;
	}
	public String getUU_FUC3358R_PRT() {
		return UU_FUC3358R_PRT;
	}
	public void setUU_FUC3358R_PRT(String uU_FUC3358R_PRT) {
		UU_FUC3358R_PRT = uU_FUC3358R_PRT;
	}
	public String getUU_PRT_DATA() {
		return UU_PRT_DATA;
	}
	public void setUU_PRT_DATA(String uU_PRT_DATA) {
		UU_PRT_DATA = uU_PRT_DATA;
	}
	public String getRD_POLICY_YN() {
		return RD_POLICY_YN;
	}
	public void setRD_POLICY_YN(String rD_POLICY_YN) {
		RD_POLICY_YN = rD_POLICY_YN;
	}
	public String getRD_COPY_YN() {
		return RD_COPY_YN;
	}
	public void setRD_COPY_YN(String rD_COPY_YN) {
		RD_COPY_YN = rD_COPY_YN;
	}
	public String getRD_GREEN_YN() {
		return RD_GREEN_YN;
	}
	public void setRD_GREEN_YN(String rD_GREEN_YN) {
		RD_GREEN_YN = rD_GREEN_YN;
	}
	public String getRD_ENCRYPT_YN() {
		return RD_ENCRYPT_YN;
	}
	public void setRD_ENCRYPT_YN(String rD_ENCRYPT_YN) {
		RD_ENCRYPT_YN = rD_ENCRYPT_YN;
	}
	public String getRD_ENCRYPT_KEY() {
		return RD_ENCRYPT_KEY;
	}
	public void setRD_ENCRYPT_KEY(String rD_ENCRYPT_KEY) {
		RD_ENCRYPT_KEY = rD_ENCRYPT_KEY;
	}
	public String getRD_UPMU_GB() {
		return RD_UPMU_GB;
	}
	public void setRD_UPMU_GB(String rD_UPMU_GB) {
		RD_UPMU_GB = rD_UPMU_GB;
	}
	public String getRD_DOCU_GB() {
		return RD_DOCU_GB;
	}
	public void setRD_DOCU_GB(String rD_DOCU_GB) {
		RD_DOCU_GB = rD_DOCU_GB;
	}
	public String getRD_SIGN_KEY() {
		return RD_SIGN_KEY;
	}
	public void setRD_SIGN_KEY(String rD_SIGN_KEY) {
		RD_SIGN_KEY = rD_SIGN_KEY;
	}
	public String getRD_FORM_GB() {
		return RD_FORM_GB;
	}
	public void setRD_FORM_GB(String rD_FORM_GB) {
		RD_FORM_GB = rD_FORM_GB;
	}
	public String getProid() {
		return proid;
	}
	public String getTrid() {
		return trid;
	}
	public String getJJ_POLI_NO_H() {
		return JJ_POLI_NO_H;
	}
	public void setJJ_POLI_NO_H(String jJ_POLI_NO_H) {
		JJ_POLI_NO_H = jJ_POLI_NO_H;
	}
	
}
