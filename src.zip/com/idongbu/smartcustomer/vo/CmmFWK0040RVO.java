package com.idongbu.smartcustomer.vo;

import com.idongbu.common.vo.CMMVO;

// 일반보험채번 전문
public class CmmFWK0040RVO extends CMMVO {
	public CmmFWK0040RVO() {
		super.setPGMID(this.proid);
		super.setTRID(this.trid);
	}
	
	public static final String proid		= "FWK0040R";
	public static final String trid		= "WK40";
	private String rURL						= "";

	// 입력
	private String StrInputPath = null; // 입력경로
	private String COMM_CHANNEL        = null; // 채널구분
	private String COMM_UNIQUE         = null; // TSQ,VSAM FILE용 UNIQUE
	private String COMM_PROGRAM          = null; // PROGRAM-ID
	private String COMM_TRANS        = null; // 처리구분
	private String COMM_ACTION        = null; // 기능키
	private String COMM_USER_GB   = null; // 사용자구분
	private String COMM_USER_ID   = null; // 사용자ID
	private String COMM_JIJUM_CD  = null; // 사용자지점
	private String COMM_JIBU_CD   = null; // 사용자지부
	private String COMM_PROTOCOL       = null; // 전문사용구분
	private String COMM_RETN_CODE = null; // 처리결과
	private String COMM_LAST_FLAG      = null; // 마지막자료여부
	private String COMM_CUR_FLD     = null; // CURSOR  MAP  NAME
	private String COMM_CUR_POS    = null; // CURSOR  POSITION
	private String COMM_MSG_CODE     = null; // MESSAGE  CODE
	private String H_COMM_MSG_NAME = null; // MESSAGE  명
	private String COMM_SYS_ERR        = null; // 시스템 MESSAGE
	private String COMM_FIL = null; // FILLER
	private String COMM_BOJONG_CD = null; // 보종 CODE

	private String COMM_JOJIKWON_CD = null; // 처리자
	private String USER_FBRT_MAP  = null; // FIELD BRIGHT MAP

	private String[] USER_FBRT_INDEX = new String[0]; // 10
	private String[] USER_FBRT_IDX = new String[0]; // 10
	private String USER_FPRT_MAP = null;
	private String[] USER_FPRT_INDEX = new String[0]; // 5
	private String[] USER_FPRT_IDX = new String[0]; // 5
	private String USER_CHIGEUBJA_CD = null; // 취급자코드
	private String USER_BOJONG_GB = null; // 보종구분
	private String USER_UPMU_GB = null; // 업무구분
	private String USER_U_UPMU_GB = null; // 업무구분
	private String USER_U_BOJONG_CD = null; // 보종코드
	private String USER_U_SULGYE_NO = null; // 설계번호
	private String USER_U_POLI_NO = null; // 증권번호
	private String USER_U_BESU_NO = null; // 배서번호

	// 출력
//	private String COMM_CHANNEL = null;
//	private String COMM_UNIQUE = null;
//	private String COMM_PROGRAM = null;
//	private String COMM_TRANS = null;
//	private String COMM_ACTION = null;
//	private String COMM_USER_GB = null;
//	private String COMM_USER_ID = null;
//	private String COMM_JIJUM_CD = null;
//	private String COMM_JIBU_CD = null;
//	private String COMM_PROTOCOL = null;
//	private String COMM_RETN_CODE = null;
//	private String COMM_LAST_FLAG = null;
//	private String COMM_CUR_FLD = null;
//	private String COMM_CUR_POS = null;
//	private String COMM_MSG_CODE = null;
//	private String H_COMM_MSG_NAME = null;
//	private String COMM_SYS_ERR = null;
//	private String COMM_FIL = null;
//	private String COMM_BOJONG_CD = null;
	private String H_COMM_GEYAK_SANGTAE = null;
//	private String COMM_JOJIKWON_CD = null;
	private String COMM_POLI_NO1 = null;
	private String COMM_POLI_NO2 = null;
	private String COMM_BESU_NO = null;
	private String COMM_SULGYE_NO = null;
//	private String USER_FBRT_MAP = null;
//	private String[] USER_FBRT_INDEX = new String[0]; // 10
//	private String[] USER_FBRT_IDX = new String[0]; // 10
//	private String USER_FPRT_MAP = null;
//	private String[] USER_FPRT_INDEX = new String[0]; // 5
//	private String[] USER_FPRT_IDX = new String[0]; // 5
//	private String USER_CHIGEUBJA_CD = null;
//	private String USER_BOJONG_GB = null;
//	private String USER_UPMU_GB = null;
//	private String USER_U_UPMU_GB = null;
//	private String USER_U_BOJONG_CD = null;
//	private String USER_U_SULGYE_NO = null;
//	private String USER_U_POLI_NO = null;
//	private String USER_U_BESU_NO = null;
	private String Length = null;
	private String RecordName = null;
	private String RecordShortDescription = null;
	private String Version = null;
	
	public String getStrInputPath() {
		return StrInputPath;
	}
	public void setStrInputPath(String strInputPath) {
		StrInputPath = strInputPath;
	}
	public String getrURL() {
		return rURL;
	}
	public void setrURL(String rURL) {
		this.rURL = rURL;
	}
	public String getCOMM_CHANNEL() {
		return COMM_CHANNEL;
	}
	public void setCOMM_CHANNEL(String cOMM_CHANNEL) {
		COMM_CHANNEL = cOMM_CHANNEL;
	}
	public String getCOMM_UNIQUE() {
		return COMM_UNIQUE;
	}
	public void setCOMM_UNIQUE(String cOMM_UNIQUE) {
		COMM_UNIQUE = cOMM_UNIQUE;
	}
	public String getCOMM_PROGRAM() {
		return COMM_PROGRAM;
	}
	public void setCOMM_PROGRAM(String cOMM_PROGRAM) {
		COMM_PROGRAM = cOMM_PROGRAM;
	}
	public String getCOMM_TRANS() {
		return COMM_TRANS;
	}
	public void setCOMM_TRANS(String cOMM_TRANS) {
		COMM_TRANS = cOMM_TRANS;
	}
	public String getCOMM_ACTION() {
		return COMM_ACTION;
	}
	public void setCOMM_ACTION(String cOMM_ACTION) {
		COMM_ACTION = cOMM_ACTION;
	}
	public String getCOMM_USER_GB() {
		return COMM_USER_GB;
	}
	public void setCOMM_USER_GB(String cOMM_USER_GB) {
		COMM_USER_GB = cOMM_USER_GB;
	}
	public String getCOMM_USER_ID() {
		return COMM_USER_ID;
	}
	public void setCOMM_USER_ID(String cOMM_USER_ID) {
		COMM_USER_ID = cOMM_USER_ID;
	}
	public String getCOMM_JIJUM_CD() {
		return COMM_JIJUM_CD;
	}
	public void setCOMM_JIJUM_CD(String cOMM_JIJUM_CD) {
		COMM_JIJUM_CD = cOMM_JIJUM_CD;
	}
	public String getCOMM_JIBU_CD() {
		return COMM_JIBU_CD;
	}
	public void setCOMM_JIBU_CD(String cOMM_JIBU_CD) {
		COMM_JIBU_CD = cOMM_JIBU_CD;
	}
	public String getCOMM_PROTOCOL() {
		return COMM_PROTOCOL;
	}
	public void setCOMM_PROTOCOL(String cOMM_PROTOCOL) {
		COMM_PROTOCOL = cOMM_PROTOCOL;
	}
	public String getCOMM_RETN_CODE() {
		return COMM_RETN_CODE;
	}
	public void setCOMM_RETN_CODE(String cOMM_RETN_CODE) {
		COMM_RETN_CODE = cOMM_RETN_CODE;
	}
	public String getCOMM_LAST_FLAG() {
		return COMM_LAST_FLAG;
	}
	public void setCOMM_LAST_FLAG(String cOMM_LAST_FLAG) {
		COMM_LAST_FLAG = cOMM_LAST_FLAG;
	}
	public String getCOMM_CUR_FLD() {
		return COMM_CUR_FLD;
	}
	public void setCOMM_CUR_FLD(String cOMM_CUR_FLD) {
		COMM_CUR_FLD = cOMM_CUR_FLD;
	}
	public String getCOMM_CUR_POS() {
		return COMM_CUR_POS;
	}
	public void setCOMM_CUR_POS(String cOMM_CUR_POS) {
		COMM_CUR_POS = cOMM_CUR_POS;
	}
	public String getCOMM_MSG_CODE() {
		return COMM_MSG_CODE;
	}
	public void setCOMM_MSG_CODE(String cOMM_MSG_CODE) {
		COMM_MSG_CODE = cOMM_MSG_CODE;
	}
	public String getH_COMM_MSG_NAME() {
		return H_COMM_MSG_NAME;
	}
	public void setH_COMM_MSG_NAME(String h_COMM_MSG_NAME) {
		H_COMM_MSG_NAME = h_COMM_MSG_NAME;
	}
	public String getCOMM_SYS_ERR() {
		return COMM_SYS_ERR;
	}
	public void setCOMM_SYS_ERR(String cOMM_SYS_ERR) {
		COMM_SYS_ERR = cOMM_SYS_ERR;
	}
	public String getCOMM_FIL() {
		return COMM_FIL;
	}
	public void setCOMM_FIL(String cOMM_FIL) {
		COMM_FIL = cOMM_FIL;
	}
	public String getCOMM_BOJONG_CD() {
		return COMM_BOJONG_CD;
	}
	public void setCOMM_BOJONG_CD(String cOMM_BOJONG_CD) {
		COMM_BOJONG_CD = cOMM_BOJONG_CD;
	}
	public String getCOMM_JOJIKWON_CD() {
		return COMM_JOJIKWON_CD;
	}
	public void setCOMM_JOJIKWON_CD(String cOMM_JOJIKWON_CD) {
		COMM_JOJIKWON_CD = cOMM_JOJIKWON_CD;
	}
	public String getUSER_FBRT_MAP() {
		return USER_FBRT_MAP;
	}
	public void setUSER_FBRT_MAP(String uSER_FBRT_MAP) {
		USER_FBRT_MAP = uSER_FBRT_MAP;
	}
	public String[] getUSER_FBRT_INDEX() {
		return USER_FBRT_INDEX;
	}
	public void setUSER_FBRT_INDEX(String[] uSER_FBRT_INDEX) {
		USER_FBRT_INDEX = uSER_FBRT_INDEX;
	}
	public String[] getUSER_FBRT_IDX() {
		return USER_FBRT_IDX;
	}
	public void setUSER_FBRT_IDX(String[] uSER_FBRT_IDX) {
		USER_FBRT_IDX = uSER_FBRT_IDX;
	}
	public String getUSER_FPRT_MAP() {
		return USER_FPRT_MAP;
	}
	public void setUSER_FPRT_MAP(String uSER_FPRT_MAP) {
		USER_FPRT_MAP = uSER_FPRT_MAP;
	}
	public String[] getUSER_FPRT_INDEX() {
		return USER_FPRT_INDEX;
	}
	public void setUSER_FPRT_INDEX(String[] uSER_FPRT_INDEX) {
		USER_FPRT_INDEX = uSER_FPRT_INDEX;
	}
	public String[] getUSER_FPRT_IDX() {
		return USER_FPRT_IDX;
	}
	public void setUSER_FPRT_IDX(String[] uSER_FPRT_IDX) {
		USER_FPRT_IDX = uSER_FPRT_IDX;
	}
	public String getUSER_CHIGEUBJA_CD() {
		return USER_CHIGEUBJA_CD;
	}
	public void setUSER_CHIGEUBJA_CD(String uSER_CHIGEUBJA_CD) {
		USER_CHIGEUBJA_CD = uSER_CHIGEUBJA_CD;
	}
	public String getUSER_BOJONG_GB() {
		return USER_BOJONG_GB;
	}
	public void setUSER_BOJONG_GB(String uSER_BOJONG_GB) {
		USER_BOJONG_GB = uSER_BOJONG_GB;
	}
	public String getUSER_UPMU_GB() {
		return USER_UPMU_GB;
	}
	public void setUSER_UPMU_GB(String uSER_UPMU_GB) {
		USER_UPMU_GB = uSER_UPMU_GB;
	}
	public String getUSER_U_UPMU_GB() {
		return USER_U_UPMU_GB;
	}
	public void setUSER_U_UPMU_GB(String uSER_U_UPMU_GB) {
		USER_U_UPMU_GB = uSER_U_UPMU_GB;
	}
	public String getUSER_U_BOJONG_CD() {
		return USER_U_BOJONG_CD;
	}
	public void setUSER_U_BOJONG_CD(String uSER_U_BOJONG_CD) {
		USER_U_BOJONG_CD = uSER_U_BOJONG_CD;
	}
	public String getUSER_U_SULGYE_NO() {
		return USER_U_SULGYE_NO;
	}
	public void setUSER_U_SULGYE_NO(String uSER_U_SULGYE_NO) {
		USER_U_SULGYE_NO = uSER_U_SULGYE_NO;
	}
	public String getUSER_U_POLI_NO() {
		return USER_U_POLI_NO;
	}
	public void setUSER_U_POLI_NO(String uSER_U_POLI_NO) {
		USER_U_POLI_NO = uSER_U_POLI_NO;
	}
	public String getUSER_U_BESU_NO() {
		return USER_U_BESU_NO;
	}
	public void setUSER_U_BESU_NO(String uSER_U_BESU_NO) {
		USER_U_BESU_NO = uSER_U_BESU_NO;
	}
	public String getH_COMM_GEYAK_SANGTAE() {
		return H_COMM_GEYAK_SANGTAE;
	}
	public void setH_COMM_GEYAK_SANGTAE(String h_COMM_GEYAK_SANGTAE) {
		H_COMM_GEYAK_SANGTAE = h_COMM_GEYAK_SANGTAE;
	}
	public String getCOMM_POLI_NO1() {
		return COMM_POLI_NO1;
	}
	public void setCOMM_POLI_NO1(String cOMM_POLI_NO1) {
		COMM_POLI_NO1 = cOMM_POLI_NO1;
	}
	public String getCOMM_POLI_NO2() {
		return COMM_POLI_NO2;
	}
	public void setCOMM_POLI_NO2(String cOMM_POLI_NO2) {
		COMM_POLI_NO2 = cOMM_POLI_NO2;
	}
	public String getCOMM_BESU_NO() {
		return COMM_BESU_NO;
	}
	public void setCOMM_BESU_NO(String cOMM_BESU_NO) {
		COMM_BESU_NO = cOMM_BESU_NO;
	}
	public String getCOMM_SULGYE_NO() {
		return COMM_SULGYE_NO;
	}
	public void setCOMM_SULGYE_NO(String cOMM_SULGYE_NO) {
		COMM_SULGYE_NO = cOMM_SULGYE_NO;
	}
	public String getLength() {
		return Length;
	}
	public void setLength(String length) {
		Length = length;
	}
	public String getRecordName() {
		return RecordName;
	}
	public void setRecordName(String recordName) {
		RecordName = recordName;
	}
	public String getRecordShortDescription() {
		return RecordShortDescription;
	}
	public void setRecordShortDescription(String recordShortDescription) {
		RecordShortDescription = recordShortDescription;
	}
	public String getVersion() {
		return Version;
	}
	public void setVersion(String version) {
		Version = version;
	}
	
	
}