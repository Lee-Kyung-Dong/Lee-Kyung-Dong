package com.idongbu.smartcustomer.vo;


public class EtcLoginVO  {

	private String FD_MB_PWD_ENC	= "";	// 비밀번호
	private String PA_SABEON	= "";	// pa인 경우 사번
	private String FD_EVENT_COURSE = ""; // 이벤트를 통한 가입자 경로(2009.10.29. 하재원)

	// 폼변수
	private String MB_ID1		= "";
	private String MB_ID2		= "";
	private String MB_PWD		= "";

	private String GBN			= "";

	private String REGCOURSE	= "";
	private String JOINCOURSE	= "";
	private String URL			= "";	// framelocation?

	private int LOGIN_ERR_CNT	= 0;
	private String ASYNC_LOGIN	= "";
	
	private String GREET_TEXT = "";
	private String []MYMENU	= new String[0];
	
	// 2008.12.26 by hsahn 직판웹(http://www.directdongbu.com)로그인
	private String DD_MB_ID		= "";		// 직판웹 이용자 ID (시퀀스값)
	private String DD_MB_URL		= "";		// 로그인 후 이동할 페이지 URL 예) /Cycon.do
	// {2008.12.26}
	
	
	private String IDLGOIN_ID		= "";		// ID로그인 ID
	private String IDLGOIN_PWD		= "";		// ID로그인 PASSWORD
	
	private String ISHOMEPAGEMEMBER = "";
	
	private String AAPLUS_TOKEN = ""; 		// 앱위변조 방지 적용_토큰 
	private String AAPLUS_CLIENTVAL = ""; 	// 앱위변조 방지 적용_클라이언트 검증값
	
	//2차때 부모VO에 있던 필드
	private String FD_MB_NO	= "";	// 일련번호
	private String FD_MB_ID	= "";	// 회원ID
	private String FD_MB_PWD	= "";	// 비밀번호
	private String FD_MB_NAME	= "";	// 고객명
	private String FD_MB_JUMIN	= "";	// 주민번호
	private String FD_MB_BIRTHDAY	= "";	// 생일일자
	private String FD_MB_SOLAR	= "";	// 양력음력구분코드
	private String FD_MB_EMAIL	= "";	// 이메일주소명
	private String FD_MB_EMAIL_FLAG	= "";	// 이메일확인유무
	private String FD_MB_HZIP	= "";	// 집우편번호
	private String FD_MB_HADDRESS	= "";	// 집주소명
	private String FD_MB_HPHONE1	= "";	// 집지역번호
	private String FD_MB_HPHONE2	= "";	// 집앞자리번호
	private String FD_MB_HPHONE3	= "";	// 집뒷자리번호
	private String FD_MB_MPHONE1	= "";	// 핸드폰지역번호
	private String FD_MB_MPHONE2	= "";	// 핸드폰앞자리번호
	private String FD_MB_MPHONE3	= "";	// 핸드폰뒷자리번호
	private String FD_MB_JOB	= "";	// 직장코드
	private String FD_MB_COMPANY	= "";	// 회사명
	private String FD_MB_DEPT	= "";	// 부서명
	private String FD_MB_CZIP	= "";	// 직장우편번호
	private String FD_MB_CADDRESS	= "";	// 직장주소
	private String FD_MB_CPHONE1	= "";	// 직장지역번호
	private String FD_MB_CPHONE2	= "";	// 직장앞자리번호
	private String FD_MB_CPHONE3	= "";	// 직장뒷자리번호
	private String FD_MB_CFAX1	= "";	// 직장팩스지역번호
	private String FD_MB_CFAX2	= "";	// 직장팩스앞자리번호
	private String FD_MB_CFAX3	= "";	// 직장팩스뒷자리번호
	private String FD_MB_MARRIAGE	= "";	// 결혼여부
	private String FD_MB_ANNIVERSARY	= "";	// 결혼기념일자
	private String FD_MB_CAR	= "";	// 차량소유여부
	private String FD_MB_HOBBY	= "";	// 취미내용
	private String FD_MB_RECEIPT	= "";	// 기본배송지코드
	private String FD_MB_MOTIVE	= "";	// 가입동기내용
	private String FD_MB_SPOUSE_ID	= "";	// 예비1용
	private String FD_MB_SPOUSE_NAME	= "";	// 예비2용
	private String FD_MB_SPOUSE_PWD	= "";	// 예비3용
	private String FD_MB_SMS	= "";	// SMS사용여부
	private String FD_MB_HADDRESS2	= "";	// 자택상세주소
	private String FD_MB_CADDRESS2	= "";	// 직장상세주소
	private String FD_MB_RECOMMENDER	= "";	// 예배4용
	private String FD_SP_JIJUMCD	= "";	// 예배5용
	private String FD_SP_JOJIKCD	= "";	// 예배6용
	private String FD_SP_APPDATE	= "";	// 예배7용
	private String FD_SP_INPUTDATE	= "";	// 예배8용
	private String FD_SP_UPDATE_DATE	= "";	// 수정일자
	private String FD_SP_CANCEL_DATE	= "";	// 예비9용
	private String FD_SP_BANKNAME	= "";	// 사용금지사유내요
	private String FD_SP_ACCOUNT_OWNEr	= "";	// 금지해제사유내요
	private String FD_SP_ACCOUNT_NO	= "";	// 예비10용
	private String FD_SP_SAWONCD	= "";	// 불량회원담당자명
	private String FD_SP_GUBUN	= "";	// 불량회원여부
	private String FD_MB_DATE	= "";	// 등록일자
	private String FD_MB_BANK_GB	= "";	// 금융회원여부
	private String FD_MB_NETIAN_ID	= "";	// 예비11용
	private String FD_JOINT_COMPANY	= "";	// 예비12용
	private String FD_MB_JIJUM	= "";	// 사이버지점구분코드
	private String FD_MAIL_PERMISSION	= "";	// 이메일수신여부
	private String FD_PWD_STATE	= "";	// 비번암호화여부
	private String FD_POST_STATE	= "";	// 주소지구분코드
	private String FD_CAR_NO	= "";	// 차량번호
	private String FD_BANK_REGDATE	= "";	// 금융회원가입일자
	private String FD_CIRTIFICATE_GB	= "";	// 인증구분코드
	private String FD_BUSINESS_GB	= "";	// 보험약관구분동의
	private String FD_BUSINESS_REGDATe	= "";	// 전자거래전화일자
	private String FD_BUSINESS_COURSE	= "";	// 전자거래전화경로명
	private String FD_MB_PWD_TMP_CHK	= "";	// 사용체크코드
	private String PARENT_NAME	= "";	// 예비1명
	private String PARENT_JUMIN	= "";	// 예비1번호
	private String PARENT_PHONE_GBN	= "";	// 예비1코드
	private String PARENT_PHONE	= "";	// 예비2번호
	private String PARENT_EMAIL	= "";	// 예비1내용
	private String PARENT_EMAIL_PERMIssion	= "";	// 예비2코드
	private String PARENT_APPLY	= "";	// 예비3코드
	private String FD_CONTACTINFO_EMAilyn	= "";	// 예비4코드
	private String FD_PHONE_GB	= "";	// 예비5코드
	private String FD_ADDR_GB	= "";	// 예비6코드
	private String EMS_EMAIL	= "";	// 예비2명
	private String FD_ADMINS_CD	= "";		//	행정코드
	private String FD_DETL_ADMINS_CD	= "";		//	세부 행정코드
	private String FD_DRIVE_YN	= "";	// 차량운행여부
	private String FD_MB_TEMP_GB	= "";	// 임시회원여부
	
	private String GRADE_CD	= "";
	
	// {2008.12.24}
	
	private String IPIN_CI	= "";	// IPIN CI
	private String IPIN_DI	= "";	// IPIN DI
	private String IPIN_VJUMIN	= "";	// IPIN 가상주민번호
	
	
	
	public String getIPIN_CI() {
		return IPIN_CI;
	}
	public void setIPIN_CI(String iPIN_CI) {
		IPIN_CI = iPIN_CI;
	}
	public String getIPIN_DI() {
		return IPIN_DI;
	}
	public void setIPIN_DI(String iPIN_DI) {
		IPIN_DI = iPIN_DI;
	}
	public String getIPIN_VJUMIN() {
		return IPIN_VJUMIN;
	}
	public void setIPIN_VJUMIN(String iPIN_VJUMIN) {
		IPIN_VJUMIN = iPIN_VJUMIN;
	}
	public String getFD_MB_PWD_ENC() {
		return FD_MB_PWD_ENC;
	}
	public void setFD_MB_PWD_ENC(String fD_MB_PWD_ENC) {
		FD_MB_PWD_ENC = fD_MB_PWD_ENC;
	}
	public String getPA_SABEON() {
		return PA_SABEON;
	}
	public void setPA_SABEON(String pA_SABEON) {
		PA_SABEON = pA_SABEON;
	}
	public String getFD_EVENT_COURSE() {
		return FD_EVENT_COURSE;
	}
	public void setFD_EVENT_COURSE(String fD_EVENT_COURSE) {
		FD_EVENT_COURSE = fD_EVENT_COURSE;
	}
	public String getMB_ID1() {
		return MB_ID1;
	}
	public void setMB_ID1(String mB_ID1) {
		MB_ID1 = mB_ID1;
	}
	public String getMB_ID2() {
		return MB_ID2;
	}
	public void setMB_ID2(String mB_ID2) {
		MB_ID2 = mB_ID2;
	}
	public String getMB_PWD() {
		return MB_PWD;
	}
	public void setMB_PWD(String mB_PWD) {
		MB_PWD = mB_PWD;
	}
	public String getGBN() {
		return GBN;
	}
	public void setGBN(String gBN) {
		GBN = gBN;
	}
	public String getREGCOURSE() {
		return REGCOURSE;
	}
	public void setREGCOURSE(String rEGCOURSE) {
		REGCOURSE = rEGCOURSE;
	}
	public String getJOINCOURSE() {
		return JOINCOURSE;
	}
	public void setJOINCOURSE(String jOINCOURSE) {
		JOINCOURSE = jOINCOURSE;
	}
	public String getURL() {
		return URL;
	}
	public void setURL(String uRL) {
		URL = uRL;
	}
	public int getLOGIN_ERR_CNT() {
		return LOGIN_ERR_CNT;
	}
	public void setLOGIN_ERR_CNT(int lOGIN_ERR_CNT) {
		LOGIN_ERR_CNT = lOGIN_ERR_CNT;
	}
	public String getASYNC_LOGIN() {
		return ASYNC_LOGIN;
	}
	public void setASYNC_LOGIN(String aSYNC_LOGIN) {
		ASYNC_LOGIN = aSYNC_LOGIN;
	}
	public String getGREET_TEXT() {
		return GREET_TEXT;
	}
	public void setGREET_TEXT(String gREET_TEXT) {
		GREET_TEXT = gREET_TEXT;
	}
	public String[] getMYMENU() {
		return MYMENU;
	}
	public void setMYMENU(String[] mYMENU) {
		MYMENU = mYMENU;
	}
	public String getDD_MB_ID() {
		return DD_MB_ID;
	}
	public void setDD_MB_ID(String dD_MB_ID) {
		DD_MB_ID = dD_MB_ID;
	}
	public String getDD_MB_URL() {
		return DD_MB_URL;
	}
	public void setDD_MB_URL(String dD_MB_URL) {
		DD_MB_URL = dD_MB_URL;
	}
	public String getIDLGOIN_ID() {
		return IDLGOIN_ID;
	}
	public void setIDLGOIN_ID(String iDLGOIN_ID) {
		IDLGOIN_ID = iDLGOIN_ID;
	}
	public String getIDLGOIN_PWD() {
		return IDLGOIN_PWD;
	}
	public void setIDLGOIN_PWD(String iDLGOIN_PWD) {
		IDLGOIN_PWD = iDLGOIN_PWD;
	}
	public String getISHOMEPAGEMEMBER() {
		return ISHOMEPAGEMEMBER;
	}
	public void setISHOMEPAGEMEMBER(String iSHOMEPAGEMEMBER) {
		ISHOMEPAGEMEMBER = iSHOMEPAGEMEMBER;
	}
	public String getAAPLUS_TOKEN() {
		return AAPLUS_TOKEN;
	}
	public void setAAPLUS_TOKEN(String aAPLUS_TOKEN) {
		AAPLUS_TOKEN = aAPLUS_TOKEN;
	}
	public String getAAPLUS_CLIENTVAL() {
		return AAPLUS_CLIENTVAL;
	}
	public void setAAPLUS_CLIENTVAL(String aAPLUS_CLIENTVAL) {
		AAPLUS_CLIENTVAL = aAPLUS_CLIENTVAL;
	}
	public String getFD_MB_NO() {
		return FD_MB_NO;
	}
	public void setFD_MB_NO(String fD_MB_NO) {
		FD_MB_NO = fD_MB_NO;
	}
	public String getFD_MB_ID() {
		return FD_MB_ID;
	}
	public void setFD_MB_ID(String fD_MB_ID) {
		FD_MB_ID = fD_MB_ID;
	}
	public String getFD_MB_PWD() {
		return FD_MB_PWD;
	}
	public void setFD_MB_PWD(String fD_MB_PWD) {
		FD_MB_PWD = fD_MB_PWD;
	}
	public String getFD_MB_NAME() {
		return FD_MB_NAME;
	}
	public void setFD_MB_NAME(String fD_MB_NAME) {
		FD_MB_NAME = fD_MB_NAME;
	}
	public String getFD_MB_JUMIN() {
		return FD_MB_JUMIN;
	}
	public void setFD_MB_JUMIN(String fD_MB_JUMIN) {
		FD_MB_JUMIN = fD_MB_JUMIN;
	}
	public String getFD_MB_BIRTHDAY() {
		return FD_MB_BIRTHDAY;
	}
	public void setFD_MB_BIRTHDAY(String fD_MB_BIRTHDAY) {
		FD_MB_BIRTHDAY = fD_MB_BIRTHDAY;
	}
	public String getFD_MB_SOLAR() {
		return FD_MB_SOLAR;
	}
	public void setFD_MB_SOLAR(String fD_MB_SOLAR) {
		FD_MB_SOLAR = fD_MB_SOLAR;
	}
	public String getFD_MB_EMAIL() {
		return FD_MB_EMAIL;
	}
	public void setFD_MB_EMAIL(String fD_MB_EMAIL) {
		FD_MB_EMAIL = fD_MB_EMAIL;
	}
	public String getFD_MB_EMAIL_FLAG() {
		return FD_MB_EMAIL_FLAG;
	}
	public void setFD_MB_EMAIL_FLAG(String fD_MB_EMAIL_FLAG) {
		FD_MB_EMAIL_FLAG = fD_MB_EMAIL_FLAG;
	}
	public String getFD_MB_HZIP() {
		return FD_MB_HZIP;
	}
	public void setFD_MB_HZIP(String fD_MB_HZIP) {
		FD_MB_HZIP = fD_MB_HZIP;
	}
	public String getFD_MB_HADDRESS() {
		return FD_MB_HADDRESS;
	}
	public void setFD_MB_HADDRESS(String fD_MB_HADDRESS) {
		FD_MB_HADDRESS = fD_MB_HADDRESS;
	}
	public String getFD_MB_HPHONE1() {
		return FD_MB_HPHONE1;
	}
	public void setFD_MB_HPHONE1(String fD_MB_HPHONE1) {
		FD_MB_HPHONE1 = fD_MB_HPHONE1;
	}
	public String getFD_MB_HPHONE2() {
		return FD_MB_HPHONE2;
	}
	public void setFD_MB_HPHONE2(String fD_MB_HPHONE2) {
		FD_MB_HPHONE2 = fD_MB_HPHONE2;
	}
	public String getFD_MB_HPHONE3() {
		return FD_MB_HPHONE3;
	}
	public void setFD_MB_HPHONE3(String fD_MB_HPHONE3) {
		FD_MB_HPHONE3 = fD_MB_HPHONE3;
	}
	public String getFD_MB_MPHONE1() {
		return FD_MB_MPHONE1;
	}
	public void setFD_MB_MPHONE1(String fD_MB_MPHONE1) {
		FD_MB_MPHONE1 = fD_MB_MPHONE1;
	}
	public String getFD_MB_MPHONE2() {
		return FD_MB_MPHONE2;
	}
	public void setFD_MB_MPHONE2(String fD_MB_MPHONE2) {
		FD_MB_MPHONE2 = fD_MB_MPHONE2;
	}
	public String getFD_MB_MPHONE3() {
		return FD_MB_MPHONE3;
	}
	public void setFD_MB_MPHONE3(String fD_MB_MPHONE3) {
		FD_MB_MPHONE3 = fD_MB_MPHONE3;
	}
	public String getFD_MB_JOB() {
		return FD_MB_JOB;
	}
	public void setFD_MB_JOB(String fD_MB_JOB) {
		FD_MB_JOB = fD_MB_JOB;
	}
	public String getFD_MB_COMPANY() {
		return FD_MB_COMPANY;
	}
	public void setFD_MB_COMPANY(String fD_MB_COMPANY) {
		FD_MB_COMPANY = fD_MB_COMPANY;
	}
	public String getFD_MB_DEPT() {
		return FD_MB_DEPT;
	}
	public void setFD_MB_DEPT(String fD_MB_DEPT) {
		FD_MB_DEPT = fD_MB_DEPT;
	}
	public String getFD_MB_CZIP() {
		return FD_MB_CZIP;
	}
	public void setFD_MB_CZIP(String fD_MB_CZIP) {
		FD_MB_CZIP = fD_MB_CZIP;
	}
	public String getFD_MB_CADDRESS() {
		return FD_MB_CADDRESS;
	}
	public void setFD_MB_CADDRESS(String fD_MB_CADDRESS) {
		FD_MB_CADDRESS = fD_MB_CADDRESS;
	}
	public String getFD_MB_CPHONE1() {
		return FD_MB_CPHONE1;
	}
	public void setFD_MB_CPHONE1(String fD_MB_CPHONE1) {
		FD_MB_CPHONE1 = fD_MB_CPHONE1;
	}
	public String getFD_MB_CPHONE2() {
		return FD_MB_CPHONE2;
	}
	public void setFD_MB_CPHONE2(String fD_MB_CPHONE2) {
		FD_MB_CPHONE2 = fD_MB_CPHONE2;
	}
	public String getFD_MB_CPHONE3() {
		return FD_MB_CPHONE3;
	}
	public void setFD_MB_CPHONE3(String fD_MB_CPHONE3) {
		FD_MB_CPHONE3 = fD_MB_CPHONE3;
	}
	public String getFD_MB_CFAX1() {
		return FD_MB_CFAX1;
	}
	public void setFD_MB_CFAX1(String fD_MB_CFAX1) {
		FD_MB_CFAX1 = fD_MB_CFAX1;
	}
	public String getFD_MB_CFAX2() {
		return FD_MB_CFAX2;
	}
	public void setFD_MB_CFAX2(String fD_MB_CFAX2) {
		FD_MB_CFAX2 = fD_MB_CFAX2;
	}
	public String getFD_MB_CFAX3() {
		return FD_MB_CFAX3;
	}
	public void setFD_MB_CFAX3(String fD_MB_CFAX3) {
		FD_MB_CFAX3 = fD_MB_CFAX3;
	}
	public String getFD_MB_MARRIAGE() {
		return FD_MB_MARRIAGE;
	}
	public void setFD_MB_MARRIAGE(String fD_MB_MARRIAGE) {
		FD_MB_MARRIAGE = fD_MB_MARRIAGE;
	}
	public String getFD_MB_ANNIVERSARY() {
		return FD_MB_ANNIVERSARY;
	}
	public void setFD_MB_ANNIVERSARY(String fD_MB_ANNIVERSARY) {
		FD_MB_ANNIVERSARY = fD_MB_ANNIVERSARY;
	}
	public String getFD_MB_CAR() {
		return FD_MB_CAR;
	}
	public void setFD_MB_CAR(String fD_MB_CAR) {
		FD_MB_CAR = fD_MB_CAR;
	}
	public String getFD_MB_HOBBY() {
		return FD_MB_HOBBY;
	}
	public void setFD_MB_HOBBY(String fD_MB_HOBBY) {
		FD_MB_HOBBY = fD_MB_HOBBY;
	}
	public String getFD_MB_RECEIPT() {
		return FD_MB_RECEIPT;
	}
	public void setFD_MB_RECEIPT(String fD_MB_RECEIPT) {
		FD_MB_RECEIPT = fD_MB_RECEIPT;
	}
	public String getFD_MB_MOTIVE() {
		return FD_MB_MOTIVE;
	}
	public void setFD_MB_MOTIVE(String fD_MB_MOTIVE) {
		FD_MB_MOTIVE = fD_MB_MOTIVE;
	}
	public String getFD_MB_SPOUSE_ID() {
		return FD_MB_SPOUSE_ID;
	}
	public void setFD_MB_SPOUSE_ID(String fD_MB_SPOUSE_ID) {
		FD_MB_SPOUSE_ID = fD_MB_SPOUSE_ID;
	}
	public String getFD_MB_SPOUSE_NAME() {
		return FD_MB_SPOUSE_NAME;
	}
	public void setFD_MB_SPOUSE_NAME(String fD_MB_SPOUSE_NAME) {
		FD_MB_SPOUSE_NAME = fD_MB_SPOUSE_NAME;
	}
	public String getFD_MB_SPOUSE_PWD() {
		return FD_MB_SPOUSE_PWD;
	}
	public void setFD_MB_SPOUSE_PWD(String fD_MB_SPOUSE_PWD) {
		FD_MB_SPOUSE_PWD = fD_MB_SPOUSE_PWD;
	}
	public String getFD_MB_SMS() {
		return FD_MB_SMS;
	}
	public void setFD_MB_SMS(String fD_MB_SMS) {
		FD_MB_SMS = fD_MB_SMS;
	}
	public String getFD_MB_HADDRESS2() {
		return FD_MB_HADDRESS2;
	}
	public void setFD_MB_HADDRESS2(String fD_MB_HADDRESS2) {
		FD_MB_HADDRESS2 = fD_MB_HADDRESS2;
	}
	public String getFD_MB_CADDRESS2() {
		return FD_MB_CADDRESS2;
	}
	public void setFD_MB_CADDRESS2(String fD_MB_CADDRESS2) {
		FD_MB_CADDRESS2 = fD_MB_CADDRESS2;
	}
	public String getFD_MB_RECOMMENDER() {
		return FD_MB_RECOMMENDER;
	}
	public void setFD_MB_RECOMMENDER(String fD_MB_RECOMMENDER) {
		FD_MB_RECOMMENDER = fD_MB_RECOMMENDER;
	}
	public String getFD_SP_JIJUMCD() {
		return FD_SP_JIJUMCD;
	}
	public void setFD_SP_JIJUMCD(String fD_SP_JIJUMCD) {
		FD_SP_JIJUMCD = fD_SP_JIJUMCD;
	}
	public String getFD_SP_JOJIKCD() {
		return FD_SP_JOJIKCD;
	}
	public void setFD_SP_JOJIKCD(String fD_SP_JOJIKCD) {
		FD_SP_JOJIKCD = fD_SP_JOJIKCD;
	}
	public String getFD_SP_APPDATE() {
		return FD_SP_APPDATE;
	}
	public void setFD_SP_APPDATE(String fD_SP_APPDATE) {
		FD_SP_APPDATE = fD_SP_APPDATE;
	}
	public String getFD_SP_INPUTDATE() {
		return FD_SP_INPUTDATE;
	}
	public void setFD_SP_INPUTDATE(String fD_SP_INPUTDATE) {
		FD_SP_INPUTDATE = fD_SP_INPUTDATE;
	}
	public String getFD_SP_UPDATE_DATE() {
		return FD_SP_UPDATE_DATE;
	}
	public void setFD_SP_UPDATE_DATE(String fD_SP_UPDATE_DATE) {
		FD_SP_UPDATE_DATE = fD_SP_UPDATE_DATE;
	}
	public String getFD_SP_CANCEL_DATE() {
		return FD_SP_CANCEL_DATE;
	}
	public void setFD_SP_CANCEL_DATE(String fD_SP_CANCEL_DATE) {
		FD_SP_CANCEL_DATE = fD_SP_CANCEL_DATE;
	}
	public String getFD_SP_BANKNAME() {
		return FD_SP_BANKNAME;
	}
	public void setFD_SP_BANKNAME(String fD_SP_BANKNAME) {
		FD_SP_BANKNAME = fD_SP_BANKNAME;
	}
	public String getFD_SP_ACCOUNT_OWNEr() {
		return FD_SP_ACCOUNT_OWNEr;
	}
	public void setFD_SP_ACCOUNT_OWNEr(String fD_SP_ACCOUNT_OWNEr) {
		FD_SP_ACCOUNT_OWNEr = fD_SP_ACCOUNT_OWNEr;
	}
	public String getFD_SP_ACCOUNT_NO() {
		return FD_SP_ACCOUNT_NO;
	}
	public void setFD_SP_ACCOUNT_NO(String fD_SP_ACCOUNT_NO) {
		FD_SP_ACCOUNT_NO = fD_SP_ACCOUNT_NO;
	}
	public String getFD_SP_SAWONCD() {
		return FD_SP_SAWONCD;
	}
	public void setFD_SP_SAWONCD(String fD_SP_SAWONCD) {
		FD_SP_SAWONCD = fD_SP_SAWONCD;
	}
	public String getFD_SP_GUBUN() {
		return FD_SP_GUBUN;
	}
	public void setFD_SP_GUBUN(String fD_SP_GUBUN) {
		FD_SP_GUBUN = fD_SP_GUBUN;
	}
	public String getFD_MB_DATE() {
		return FD_MB_DATE;
	}
	public void setFD_MB_DATE(String fD_MB_DATE) {
		FD_MB_DATE = fD_MB_DATE;
	}
	public String getFD_MB_BANK_GB() {
		return FD_MB_BANK_GB;
	}
	public void setFD_MB_BANK_GB(String fD_MB_BANK_GB) {
		FD_MB_BANK_GB = fD_MB_BANK_GB;
	}
	public String getFD_MB_NETIAN_ID() {
		return FD_MB_NETIAN_ID;
	}
	public void setFD_MB_NETIAN_ID(String fD_MB_NETIAN_ID) {
		FD_MB_NETIAN_ID = fD_MB_NETIAN_ID;
	}
	public String getFD_JOINT_COMPANY() {
		return FD_JOINT_COMPANY;
	}
	public void setFD_JOINT_COMPANY(String fD_JOINT_COMPANY) {
		FD_JOINT_COMPANY = fD_JOINT_COMPANY;
	}
	public String getFD_MB_JIJUM() {
		return FD_MB_JIJUM;
	}
	public void setFD_MB_JIJUM(String fD_MB_JIJUM) {
		FD_MB_JIJUM = fD_MB_JIJUM;
	}
	public String getFD_MAIL_PERMISSION() {
		return FD_MAIL_PERMISSION;
	}
	public void setFD_MAIL_PERMISSION(String fD_MAIL_PERMISSION) {
		FD_MAIL_PERMISSION = fD_MAIL_PERMISSION;
	}
	public String getFD_PWD_STATE() {
		return FD_PWD_STATE;
	}
	public void setFD_PWD_STATE(String fD_PWD_STATE) {
		FD_PWD_STATE = fD_PWD_STATE;
	}
	public String getFD_POST_STATE() {
		return FD_POST_STATE;
	}
	public void setFD_POST_STATE(String fD_POST_STATE) {
		FD_POST_STATE = fD_POST_STATE;
	}
	public String getFD_CAR_NO() {
		return FD_CAR_NO;
	}
	public void setFD_CAR_NO(String fD_CAR_NO) {
		FD_CAR_NO = fD_CAR_NO;
	}
	public String getFD_BANK_REGDATE() {
		return FD_BANK_REGDATE;
	}
	public void setFD_BANK_REGDATE(String fD_BANK_REGDATE) {
		FD_BANK_REGDATE = fD_BANK_REGDATE;
	}
	public String getFD_CIRTIFICATE_GB() {
		return FD_CIRTIFICATE_GB;
	}
	public void setFD_CIRTIFICATE_GB(String fD_CIRTIFICATE_GB) {
		FD_CIRTIFICATE_GB = fD_CIRTIFICATE_GB;
	}
	public String getFD_BUSINESS_GB() {
		return FD_BUSINESS_GB;
	}
	public void setFD_BUSINESS_GB(String fD_BUSINESS_GB) {
		FD_BUSINESS_GB = fD_BUSINESS_GB;
	}
	public String getFD_BUSINESS_REGDATe() {
		return FD_BUSINESS_REGDATe;
	}
	public void setFD_BUSINESS_REGDATe(String fD_BUSINESS_REGDATe) {
		FD_BUSINESS_REGDATe = fD_BUSINESS_REGDATe;
	}
	public String getFD_BUSINESS_COURSE() {
		return FD_BUSINESS_COURSE;
	}
	public void setFD_BUSINESS_COURSE(String fD_BUSINESS_COURSE) {
		FD_BUSINESS_COURSE = fD_BUSINESS_COURSE;
	}
	public String getFD_MB_PWD_TMP_CHK() {
		return FD_MB_PWD_TMP_CHK;
	}
	public void setFD_MB_PWD_TMP_CHK(String fD_MB_PWD_TMP_CHK) {
		FD_MB_PWD_TMP_CHK = fD_MB_PWD_TMP_CHK;
	}
	public String getPARENT_NAME() {
		return PARENT_NAME;
	}
	public void setPARENT_NAME(String pARENT_NAME) {
		PARENT_NAME = pARENT_NAME;
	}
	public String getPARENT_JUMIN() {
		return PARENT_JUMIN;
	}
	public void setPARENT_JUMIN(String pARENT_JUMIN) {
		PARENT_JUMIN = pARENT_JUMIN;
	}
	public String getPARENT_PHONE_GBN() {
		return PARENT_PHONE_GBN;
	}
	public void setPARENT_PHONE_GBN(String pARENT_PHONE_GBN) {
		PARENT_PHONE_GBN = pARENT_PHONE_GBN;
	}
	public String getPARENT_PHONE() {
		return PARENT_PHONE;
	}
	public void setPARENT_PHONE(String pARENT_PHONE) {
		PARENT_PHONE = pARENT_PHONE;
	}
	public String getPARENT_EMAIL() {
		return PARENT_EMAIL;
	}
	public void setPARENT_EMAIL(String pARENT_EMAIL) {
		PARENT_EMAIL = pARENT_EMAIL;
	}
	public String getPARENT_EMAIL_PERMIssion() {
		return PARENT_EMAIL_PERMIssion;
	}
	public void setPARENT_EMAIL_PERMIssion(String pARENT_EMAIL_PERMIssion) {
		PARENT_EMAIL_PERMIssion = pARENT_EMAIL_PERMIssion;
	}
	public String getPARENT_APPLY() {
		return PARENT_APPLY;
	}
	public void setPARENT_APPLY(String pARENT_APPLY) {
		PARENT_APPLY = pARENT_APPLY;
	}
	public String getFD_CONTACTINFO_EMAilyn() {
		return FD_CONTACTINFO_EMAilyn;
	}
	public void setFD_CONTACTINFO_EMAilyn(String fD_CONTACTINFO_EMAilyn) {
		FD_CONTACTINFO_EMAilyn = fD_CONTACTINFO_EMAilyn;
	}
	public String getFD_PHONE_GB() {
		return FD_PHONE_GB;
	}
	public void setFD_PHONE_GB(String fD_PHONE_GB) {
		FD_PHONE_GB = fD_PHONE_GB;
	}
	public String getFD_ADDR_GB() {
		return FD_ADDR_GB;
	}
	public void setFD_ADDR_GB(String fD_ADDR_GB) {
		FD_ADDR_GB = fD_ADDR_GB;
	}
	public String getEMS_EMAIL() {
		return EMS_EMAIL;
	}
	public void setEMS_EMAIL(String eMS_EMAIL) {
		EMS_EMAIL = eMS_EMAIL;
	}
	public String getFD_ADMINS_CD() {
		return FD_ADMINS_CD;
	}
	public void setFD_ADMINS_CD(String fD_ADMINS_CD) {
		FD_ADMINS_CD = fD_ADMINS_CD;
	}
	public String getFD_DETL_ADMINS_CD() {
		return FD_DETL_ADMINS_CD;
	}
	public void setFD_DETL_ADMINS_CD(String fD_DETL_ADMINS_CD) {
		FD_DETL_ADMINS_CD = fD_DETL_ADMINS_CD;
	}
	public String getFD_DRIVE_YN() {
		return FD_DRIVE_YN;
	}
	public void setFD_DRIVE_YN(String fD_DRIVE_YN) {
		FD_DRIVE_YN = fD_DRIVE_YN;
	}
	public String getFD_MB_TEMP_GB() {
		return FD_MB_TEMP_GB;
	}
	public void setFD_MB_TEMP_GB(String fD_MB_TEMP_GB) {
		FD_MB_TEMP_GB = fD_MB_TEMP_GB;
	}
	public String getGRADE_CD() {
		return GRADE_CD;
	}
	public void setGRADE_CD(String gRADE_CD) {
		GRADE_CD = gRADE_CD;
	}
	
	
	
	
	
	
}
