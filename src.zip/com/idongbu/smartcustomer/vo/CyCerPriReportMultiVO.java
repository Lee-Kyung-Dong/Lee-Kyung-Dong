package com.idongbu.smartcustomer.vo;

import com.idongbu.common.vo.CMMVO;

public class CyCerPriReportMultiVO extends CMMVO {
	public String CM_LAST_FLAG="";
	public String UD_L_POLI_NO="";
	public String CM_FUNCTION_PGUD="";
	public String PRINT_DATA="";
	public String ERROR="";
	
}
