package com.idongbu.smartcustomer.vo;

public class SubFUC1511RVO {
	public String JJ_GYEYAK_JMNO	= null;
	public String HJ_GYEYAK_NM      = null;
	public String JJ_PIBO_JMNO      = null;
	public String HJ_PIBO_NM        = null;
	public String HJ_BJ_NM          = null;
	public String HJ_BJ_CD          = null;
	public String JJ_POLI_NO        = null;
	public String JJ_BOHUM_GIGAN_S  = null;
	public String JJ_BOHUM_GIGAN_E  = null;
	public String JJ_GYEYAK_SANGTE  = null;
	public String HJ_BIGO           = null;
	public String HJ_CHIGUB_NM      = null;
	public String JJ_CHIGUB_TEL     = null;
	public String JJ_CHIGUB         = null;
	public String JJ_GAIP_TYPE1     = null;
	public String JJ_BOHUM_GIGANCD  = null;
	public String JJ_NAPIP_CNT      = null;
	public String HJ_BUNNAP_NM      = null;
	public String JJ_LAST_NAPIP_YM  = null;
	public String JJ_BUNNAP_BANGCD  = null;
	public String JJ_ICHE_ILSU      = null;
	public String JJ_SU_BANGBAP     = null;
	public String HJ_SU_BANGBAP     = null;
	
	
	public String getHJ_BJ_CD() {
		return HJ_BJ_CD;
	}
	public void setHJ_BJ_CD(String hJ_BJ_CD) {
		HJ_BJ_CD = hJ_BJ_CD;
	}
	public String getJJ_GYEYAK_JMNO() {
		return JJ_GYEYAK_JMNO;
	}
	public void setJJ_GYEYAK_JMNO(String jJ_GYEYAK_JMNO) {
		JJ_GYEYAK_JMNO = jJ_GYEYAK_JMNO;
	}
	public String getHJ_GYEYAK_NM() {
		return HJ_GYEYAK_NM;
	}
	public void setHJ_GYEYAK_NM(String hJ_GYEYAK_NM) {
		HJ_GYEYAK_NM = hJ_GYEYAK_NM;
	}
	public String getJJ_PIBO_JMNO() {
		return JJ_PIBO_JMNO;
	}
	public void setJJ_PIBO_JMNO(String jJ_PIBO_JMNO) {
		JJ_PIBO_JMNO = jJ_PIBO_JMNO;
	}
	public String getHJ_PIBO_NM() {
		return HJ_PIBO_NM;
	}
	public void setHJ_PIBO_NM(String hJ_PIBO_NM) {
		HJ_PIBO_NM = hJ_PIBO_NM;
	}
	public String getHJ_BJ_NM() {
		return HJ_BJ_NM;
	}
	public void setHJ_BJ_NM(String hJ_BJ_NM) {
		HJ_BJ_NM = hJ_BJ_NM;
	}
	public String getJJ_POLI_NO() {
		return JJ_POLI_NO;
	}
	public void setJJ_POLI_NO(String jJ_POLI_NO) {
		JJ_POLI_NO = jJ_POLI_NO;
	}
	public String getJJ_BOHUM_GIGAN_S() {
		return JJ_BOHUM_GIGAN_S;
	}
	public void setJJ_BOHUM_GIGAN_S(String jJ_BOHUM_GIGAN_S) {
		JJ_BOHUM_GIGAN_S = jJ_BOHUM_GIGAN_S;
	}
	public String getJJ_BOHUM_GIGAN_E() {
		return JJ_BOHUM_GIGAN_E;
	}
	public void setJJ_BOHUM_GIGAN_E(String jJ_BOHUM_GIGAN_E) {
		JJ_BOHUM_GIGAN_E = jJ_BOHUM_GIGAN_E;
	}
	public String getJJ_GYEYAK_SANGTE() {
		return JJ_GYEYAK_SANGTE;
	}
	public void setJJ_GYEYAK_SANGTE(String jJ_GYEYAK_SANGTE) {
		JJ_GYEYAK_SANGTE = jJ_GYEYAK_SANGTE;
	}
	public String getHJ_BIGO() {
		return HJ_BIGO;
	}
	public void setHJ_BIGO(String hJ_BIGO) {
		HJ_BIGO = hJ_BIGO;
	}
	public String getHJ_CHIGUB_NM() {
		return HJ_CHIGUB_NM;
	}
	public void setHJ_CHIGUB_NM(String hJ_CHIGUB_NM) {
		HJ_CHIGUB_NM = hJ_CHIGUB_NM;
	}
	public String getJJ_CHIGUB_TEL() {
		return JJ_CHIGUB_TEL;
	}
	public void setJJ_CHIGUB_TEL(String jJ_CHIGUB_TEL) {
		JJ_CHIGUB_TEL = jJ_CHIGUB_TEL;
	}
	public String getJJ_CHIGUB() {
		return JJ_CHIGUB;
	}
	public void setJJ_CHIGUB(String jJ_CHIGUB) {
		JJ_CHIGUB = jJ_CHIGUB;
	}
	public String getJJ_GAIP_TYPE1() {
		return JJ_GAIP_TYPE1;
	}
	public void setJJ_GAIP_TYPE1(String jJ_GAIP_TYPE1) {
		JJ_GAIP_TYPE1 = jJ_GAIP_TYPE1;
	}
	public String getJJ_BOHUM_GIGANCD() {
		return JJ_BOHUM_GIGANCD;
	}
	public void setJJ_BOHUM_GIGANCD(String jJ_BOHUM_GIGANCD) {
		JJ_BOHUM_GIGANCD = jJ_BOHUM_GIGANCD;
	}
	public String getJJ_NAPIP_CNT() {
		return JJ_NAPIP_CNT;
	}
	public void setJJ_NAPIP_CNT(String jJ_NAPIP_CNT) {
		JJ_NAPIP_CNT = jJ_NAPIP_CNT;
	}
	public String getHJ_BUNNAP_NM() {
		return HJ_BUNNAP_NM;
	}
	public void setHJ_BUNNAP_NM(String hJ_BUNNAP_NM) {
		HJ_BUNNAP_NM = hJ_BUNNAP_NM;
	}
	public String getJJ_LAST_NAPIP_YM() {
		return JJ_LAST_NAPIP_YM;
	}
	public void setJJ_LAST_NAPIP_YM(String jJ_LAST_NAPIP_YM) {
		JJ_LAST_NAPIP_YM = jJ_LAST_NAPIP_YM;
	}
	public String getJJ_BUNNAP_BANGCD() {
		return JJ_BUNNAP_BANGCD;
	}
	public void setJJ_BUNNAP_BANGCD(String jJ_BUNNAP_BANGCD) {
		JJ_BUNNAP_BANGCD = jJ_BUNNAP_BANGCD;
	}
	public String getJJ_ICHE_ILSU() {
		return JJ_ICHE_ILSU;
	}
	public void setJJ_ICHE_ILSU(String jJ_ICHE_ILSU) {
		JJ_ICHE_ILSU = jJ_ICHE_ILSU;
	}
	public String getJJ_SU_BANGBAP() {
		return JJ_SU_BANGBAP;
	}
	public void setJJ_SU_BANGBAP(String jJ_SU_BANGBAP) {
		JJ_SU_BANGBAP = jJ_SU_BANGBAP;
	}
	public String getHJ_SU_BANGBAP() {
		return HJ_SU_BANGBAP;
	}
	public void setHJ_SU_BANGBAP(String hJ_SU_BANGBAP) {
		HJ_SU_BANGBAP = hJ_SU_BANGBAP;
	}
	
}
