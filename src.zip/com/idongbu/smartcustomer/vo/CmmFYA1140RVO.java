package com.idongbu.smartcustomer.vo;

import java.util.ArrayList;
import java.util.List;

import com.idongbu.common.vo.CMMVO;

// 가상계좌통합부여
public class CmmFYA1140RVO extends CMMVO {
	
	public CmmFYA1140RVO() {
		super.setPGMID(this.proid);
		super.setTRID(this.trid);
	}
	public static final String proid		= "FYA1140R";
	public static final String trid		= "YA6N";
	public String rURL						= "";

	public String CHANNEL			= "";
	public String TERM_ID           = "";
	public String PGM_ID            = "";
	public String PATH              = "";
	public String FUNCTION_KEY      = "";
	public String USER_ID_F         = "";
	public String USER_ID           = "";
	public String JIJUM_CODE        = "";
	public String JIBU_CODE         = "";
	public String PROTOCOL          = "";
	public String COND_CODE         = "";
	public String SE_LAST_FLAG      = "";
	public String CUR_POS_MAP_ID    = "";
	public String CUR_POS_INDEX     = "";
	public String SE_MSG_ID         = "";
	public String H_MESSAGE_NM      = "";
	public String SE_SM_LEVEL       = "";
	public String SE_SM_ID          = "";
	public String SE_SM_PRC         = "";
	public String SE_SM_RC          = "";
	public String COMM_FILLER       = "";
	public String RE_SELECT         = "";
	public String RE_JOJIKWON_CD    = "";
	public String RE_H_JUMIN_NO     = "";
	public String H_RE_NAME         = "";
	public String RE_BANK_CD        = "";
	public String RE_PASSWORD       = "";
	public String RE_BANK_CD_A      = "";	//통합가상은행코드
	public String H_RE_BANK_NM_A    = "";	//통합가상은행명
	public String RE_H_GYEJWA_NO    = "";	//통합가상계좌번호
	public String RE_H_ASSIGN_DATE  = "";	//통합가상계좌부여일
	public String RE_CNT            = "";	//통합가상신청건수
	public String RE_TOT            = "";	//통합가상신청보험료
	public String RE_GUBUN          = "";
	public String RE_FR_DATE        = "";
	public String RE_TO_DATE        = "";
	public String RE_TOTAL_CNT		= "";
	public String RE_TOTAL_AMT      = "";
	public String SE_DERR_FBRT_PGM  = "";
	public String SE_DERR_FLD       = "";
	public String RE_U_D_JIJUM_CD	= "";
	public String H_RE_U_D_JIJUM_NM = "";
	public String RE_U_D_BANK_CD    = "";
	public String RE_U_D_TOTAL_PAGE = "";
	public String RE_U_D_CUR_DATE   = "";
	public String RE_U_D_CUR_TIME   = "";
	public String RE_U_D_CUR_PAGE   = "";
	public String RE_U_D_TOTAL_AMT  = "";
	public ArrayList<String> arr = null;
	
	// 입력용도로 사용
	public String[] RE_PROCESS = new String[30];
	public String[] H_RE_BANK_NM = new String[30];
	public String[] RE_GYEJWA_NO = new String[30];
	public String[] RE_JUMIN_NO = new String[30];
	public String[] H_RE_GYEYAKJA_NAME = new String[30];
	public String[] RE_ASSIGN_DATE = new String[30];
	public String[] RE_SINCHUNG_AMT = new String[30];
	public String[] RE_GYEJWA_NO_SEQ = new String[30]; 
	public String[] RE_BANK_CODE = new String[30];
	
	public List<SubFYA1140RVO> LIST_DATA = null;
	public String getrURL() {
		return rURL;
	}
	public void setrURL(String rURL) {
		this.rURL = rURL;
	}
	public String getCHANNEL() {
		return CHANNEL;
	}
	public void setCHANNEL(String cHANNEL) {
		CHANNEL = cHANNEL;
	}
	public String getTERM_ID() {
		return TERM_ID;
	}
	public void setTERM_ID(String tERM_ID) {
		TERM_ID = tERM_ID;
	}
	public String getPGM_ID() {
		return PGM_ID;
	}
	public void setPGM_ID(String pGM_ID) {
		PGM_ID = pGM_ID;
	}
	public String getPATH() {
		return PATH;
	}
	public void setPATH(String pATH) {
		PATH = pATH;
	}
	public String getFUNCTION_KEY() {
		return FUNCTION_KEY;
	}
	public void setFUNCTION_KEY(String fUNCTION_KEY) {
		FUNCTION_KEY = fUNCTION_KEY;
	}
	public String getUSER_ID_F() {
		return USER_ID_F;
	}
	public void setUSER_ID_F(String uSER_ID_F) {
		USER_ID_F = uSER_ID_F;
	}
	public String getUSER_ID() {
		return USER_ID;
	}
	public void setUSER_ID(String uSER_ID) {
		USER_ID = uSER_ID;
	}
	public String getJIJUM_CODE() {
		return JIJUM_CODE;
	}
	public void setJIJUM_CODE(String jIJUM_CODE) {
		JIJUM_CODE = jIJUM_CODE;
	}
	public String getJIBU_CODE() {
		return JIBU_CODE;
	}
	public void setJIBU_CODE(String jIBU_CODE) {
		JIBU_CODE = jIBU_CODE;
	}
	public String getPROTOCOL() {
		return PROTOCOL;
	}
	public void setPROTOCOL(String pROTOCOL) {
		PROTOCOL = pROTOCOL;
	}
	public String getCOND_CODE() {
		return COND_CODE;
	}
	public void setCOND_CODE(String cOND_CODE) {
		COND_CODE = cOND_CODE;
	}
	public String getSE_LAST_FLAG() {
		return SE_LAST_FLAG;
	}
	public void setSE_LAST_FLAG(String sE_LAST_FLAG) {
		SE_LAST_FLAG = sE_LAST_FLAG;
	}
	public String getCUR_POS_MAP_ID() {
		return CUR_POS_MAP_ID;
	}
	public void setCUR_POS_MAP_ID(String cUR_POS_MAP_ID) {
		CUR_POS_MAP_ID = cUR_POS_MAP_ID;
	}
	public String getCUR_POS_INDEX() {
		return CUR_POS_INDEX;
	}
	public void setCUR_POS_INDEX(String cUR_POS_INDEX) {
		CUR_POS_INDEX = cUR_POS_INDEX;
	}
	public String getSE_MSG_ID() {
		return SE_MSG_ID;
	}
	public void setSE_MSG_ID(String sE_MSG_ID) {
		SE_MSG_ID = sE_MSG_ID;
	}
	public String getH_MESSAGE_NM() {
		return H_MESSAGE_NM;
	}
	public void setH_MESSAGE_NM(String h_MESSAGE_NM) {
		H_MESSAGE_NM = h_MESSAGE_NM;
	}
	public String getSE_SM_LEVEL() {
		return SE_SM_LEVEL;
	}
	public void setSE_SM_LEVEL(String sE_SM_LEVEL) {
		SE_SM_LEVEL = sE_SM_LEVEL;
	}
	public String getSE_SM_ID() {
		return SE_SM_ID;
	}
	public void setSE_SM_ID(String sE_SM_ID) {
		SE_SM_ID = sE_SM_ID;
	}
	public String getSE_SM_PRC() {
		return SE_SM_PRC;
	}
	public void setSE_SM_PRC(String sE_SM_PRC) {
		SE_SM_PRC = sE_SM_PRC;
	}
	public String getSE_SM_RC() {
		return SE_SM_RC;
	}
	public void setSE_SM_RC(String sE_SM_RC) {
		SE_SM_RC = sE_SM_RC;
	}
	public String getCOMM_FILLER() {
		return COMM_FILLER;
	}
	public void setCOMM_FILLER(String cOMM_FILLER) {
		COMM_FILLER = cOMM_FILLER;
	}
	public String getRE_SELECT() {
		return RE_SELECT;
	}
	public void setRE_SELECT(String rE_SELECT) {
		RE_SELECT = rE_SELECT;
	}
	public String getRE_JOJIKWON_CD() {
		return RE_JOJIKWON_CD;
	}
	public void setRE_JOJIKWON_CD(String rE_JOJIKWON_CD) {
		RE_JOJIKWON_CD = rE_JOJIKWON_CD;
	}
	public String getRE_H_JUMIN_NO() {
		return RE_H_JUMIN_NO;
	}
	public void setRE_H_JUMIN_NO(String rE_H_JUMIN_NO) {
		RE_H_JUMIN_NO = rE_H_JUMIN_NO;
	}
	public String getH_RE_NAME() {
		return H_RE_NAME;
	}
	public void setH_RE_NAME(String h_RE_NAME) {
		H_RE_NAME = h_RE_NAME;
	}
	public String getRE_BANK_CD() {
		return RE_BANK_CD;
	}
	public void setRE_BANK_CD(String rE_BANK_CD) {
		RE_BANK_CD = rE_BANK_CD;
	}
	public String getRE_PASSWORD() {
		return RE_PASSWORD;
	}
	public void setRE_PASSWORD(String rE_PASSWORD) {
		RE_PASSWORD = rE_PASSWORD;
	}
	public String getRE_BANK_CD_A() {
		return RE_BANK_CD_A;
	}
	public void setRE_BANK_CD_A(String rE_BANK_CD_A) {
		RE_BANK_CD_A = rE_BANK_CD_A;
	}
	public String getH_RE_BANK_NM_A() {
		return H_RE_BANK_NM_A;
	}
	public void setH_RE_BANK_NM_A(String h_RE_BANK_NM_A) {
		H_RE_BANK_NM_A = h_RE_BANK_NM_A;
	}
	public String getRE_H_GYEJWA_NO() {
		return RE_H_GYEJWA_NO;
	}
	public void setRE_H_GYEJWA_NO(String rE_H_GYEJWA_NO) {
		RE_H_GYEJWA_NO = rE_H_GYEJWA_NO;
	}
	public String getRE_H_ASSIGN_DATE() {
		return RE_H_ASSIGN_DATE;
	}
	public void setRE_H_ASSIGN_DATE(String rE_H_ASSIGN_DATE) {
		RE_H_ASSIGN_DATE = rE_H_ASSIGN_DATE;
	}
	public String getRE_CNT() {
		return RE_CNT;
	}
	public void setRE_CNT(String rE_CNT) {
		RE_CNT = rE_CNT;
	}
	public String getRE_TOT() {
		return RE_TOT;
	}
	public void setRE_TOT(String rE_TOT) {
		RE_TOT = rE_TOT;
	}
	public String getRE_GUBUN() {
		return RE_GUBUN;
	}
	public void setRE_GUBUN(String rE_GUBUN) {
		RE_GUBUN = rE_GUBUN;
	}
	public String getRE_FR_DATE() {
		return RE_FR_DATE;
	}
	public void setRE_FR_DATE(String rE_FR_DATE) {
		RE_FR_DATE = rE_FR_DATE;
	}
	public String getRE_TO_DATE() {
		return RE_TO_DATE;
	}
	public void setRE_TO_DATE(String rE_TO_DATE) {
		RE_TO_DATE = rE_TO_DATE;
	}
	public String getRE_TOTAL_CNT() {
		return RE_TOTAL_CNT;
	}
	public void setRE_TOTAL_CNT(String rE_TOTAL_CNT) {
		RE_TOTAL_CNT = rE_TOTAL_CNT;
	}
	public String getRE_TOTAL_AMT() {
		return RE_TOTAL_AMT;
	}
	public void setRE_TOTAL_AMT(String rE_TOTAL_AMT) {
		RE_TOTAL_AMT = rE_TOTAL_AMT;
	}
	public String getSE_DERR_FBRT_PGM() {
		return SE_DERR_FBRT_PGM;
	}
	public void setSE_DERR_FBRT_PGM(String sE_DERR_FBRT_PGM) {
		SE_DERR_FBRT_PGM = sE_DERR_FBRT_PGM;
	}
	public String getSE_DERR_FLD() {
		return SE_DERR_FLD;
	}
	public void setSE_DERR_FLD(String sE_DERR_FLD) {
		SE_DERR_FLD = sE_DERR_FLD;
	}
	public String getRE_U_D_JIJUM_CD() {
		return RE_U_D_JIJUM_CD;
	}
	public void setRE_U_D_JIJUM_CD(String rE_U_D_JIJUM_CD) {
		RE_U_D_JIJUM_CD = rE_U_D_JIJUM_CD;
	}
	public String getH_RE_U_D_JIJUM_NM() {
		return H_RE_U_D_JIJUM_NM;
	}
	public void setH_RE_U_D_JIJUM_NM(String h_RE_U_D_JIJUM_NM) {
		H_RE_U_D_JIJUM_NM = h_RE_U_D_JIJUM_NM;
	}
	public String getRE_U_D_BANK_CD() {
		return RE_U_D_BANK_CD;
	}
	public void setRE_U_D_BANK_CD(String rE_U_D_BANK_CD) {
		RE_U_D_BANK_CD = rE_U_D_BANK_CD;
	}
	public String getRE_U_D_TOTAL_PAGE() {
		return RE_U_D_TOTAL_PAGE;
	}
	public void setRE_U_D_TOTAL_PAGE(String rE_U_D_TOTAL_PAGE) {
		RE_U_D_TOTAL_PAGE = rE_U_D_TOTAL_PAGE;
	}
	public String getRE_U_D_CUR_DATE() {
		return RE_U_D_CUR_DATE;
	}
	public void setRE_U_D_CUR_DATE(String rE_U_D_CUR_DATE) {
		RE_U_D_CUR_DATE = rE_U_D_CUR_DATE;
	}
	public String getRE_U_D_CUR_TIME() {
		return RE_U_D_CUR_TIME;
	}
	public void setRE_U_D_CUR_TIME(String rE_U_D_CUR_TIME) {
		RE_U_D_CUR_TIME = rE_U_D_CUR_TIME;
	}
	public String getRE_U_D_CUR_PAGE() {
		return RE_U_D_CUR_PAGE;
	}
	public void setRE_U_D_CUR_PAGE(String rE_U_D_CUR_PAGE) {
		RE_U_D_CUR_PAGE = rE_U_D_CUR_PAGE;
	}
	public String getRE_U_D_TOTAL_AMT() {
		return RE_U_D_TOTAL_AMT;
	}
	public void setRE_U_D_TOTAL_AMT(String rE_U_D_TOTAL_AMT) {
		RE_U_D_TOTAL_AMT = rE_U_D_TOTAL_AMT;
	}
	
	// 리스트데이타는 출력용도로 사용했음
	public List<SubFYA1140RVO> getLIST_DATA() {
		return LIST_DATA;
	}
	public void setLIST_DATA(List<SubFYA1140RVO> lIST_DATA) {
		LIST_DATA = lIST_DATA;
	}
	public static String getProid() {
		return proid;
	}
	public static String getTrid() {
		return trid;
	}

	
	
	// 이하는 입력용도로 사용
	public String[] getRE_PROCESS() {
		return RE_PROCESS;
	}
	public void setRE_PROCESS(String[] rE_PROCESS) {
		RE_PROCESS = rE_PROCESS;
	}
	public String[] getH_RE_BANK_NM() {
		return H_RE_BANK_NM;
	}
	public void setH_RE_BANK_NM(String[] h_RE_BANK_NM) {
		H_RE_BANK_NM = h_RE_BANK_NM;
	}
	public String[] getRE_GYEJWA_NO() {
		return RE_GYEJWA_NO;
	}
	public void setRE_GYEJWA_NO(String[] rE_GYEJWA_NO) {
		RE_GYEJWA_NO = rE_GYEJWA_NO;
	}
	public String[] getRE_JUMIN_NO() {
		return RE_JUMIN_NO;
	}
	public void setRE_JUMIN_NO(String[] rE_JUMIN_NO) {
		RE_JUMIN_NO = rE_JUMIN_NO;
	}
	public String[] getH_RE_GYEYAKJA_NAME() {
		return H_RE_GYEYAKJA_NAME;
	}
	public void setH_RE_GYEYAKJA_NAME(String[] h_RE_GYEYAKJA_NAME) {
		H_RE_GYEYAKJA_NAME = h_RE_GYEYAKJA_NAME;
	}
	public String[] getRE_ASSIGN_DATE() {
		return RE_ASSIGN_DATE;
	}
	public void setRE_ASSIGN_DATE(String[] rE_ASSIGN_DATE) {
		RE_ASSIGN_DATE = rE_ASSIGN_DATE;
	}
	public String[] getRE_SINCHUNG_AMT() {
		return RE_SINCHUNG_AMT;
	}
	public void setRE_SINCHUNG_AMT(String[] rE_SINCHUNG_AMT) {
		RE_SINCHUNG_AMT = rE_SINCHUNG_AMT;
	}
	public String[] getRE_GYEJWA_NO_SEQ() {
		return RE_GYEJWA_NO_SEQ;
	}
	public void setRE_GYEJWA_NO_SEQ(String[] rE_GYEJWA_NO_SEQ) {
		RE_GYEJWA_NO_SEQ = rE_GYEJWA_NO_SEQ;
	}
	public String[] getRE_BANK_CODE() {
		return RE_BANK_CODE;
	}
	public void setRE_BANK_CODE(String[] rE_BANK_CODE) {
		RE_BANK_CODE = rE_BANK_CODE;
	}

	
	

}
