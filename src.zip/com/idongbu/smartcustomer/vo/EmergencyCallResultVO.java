package com.idongbu.smartcustomer.vo;

import com.idongbu.common.vo.CMMVO;

// 계약조회
public class EmergencyCallResultVO extends CMMVO {
	private String car_no = null;
	private String yochungja = null;
	private String yochung_area_addr = null;
	private String yochung_nm = null;
	private int svc_cnt = 0;
	private int t_svc_cnt = 0;
	private String jubsu_no = null;
	private String chuldong_nm = null;
	private String chuldongja_phone = null;
	private String co_nm = null;
	private String pos_x = null;
	private String pos_y = null;
	private String lbsutmx = null;
	private String lbsutmy = null;
	private String yochungja_km = null;
	
	public String getCar_no() {
		return car_no;
	}
	public void setCar_no(String car_no) {
		this.car_no = car_no;
	}
	public String getYochungja() {
		return yochungja;
	}
	public void setYochungja(String yochungja) {
		this.yochungja = yochungja;
	}
	public String getYochung_area_addr() {
		return yochung_area_addr;
	}
	public void setYochung_area_addr(String yochung_area_addr) {
		this.yochung_area_addr = yochung_area_addr;
	}
	public String getYochung_nm() {
		return yochung_nm;
	}
	public void setYochung_nm(String yochung_nm) {
		this.yochung_nm = yochung_nm;
	}
	public int getSvc_cnt() {
		return svc_cnt;
	}
	public void setSvc_cnt(int svc_cnt) {
		this.svc_cnt = svc_cnt;
	}
	public int getT_svc_cnt() {
		return t_svc_cnt;
	}
	public void setT_svc_cnt(int t_svc_cnt) {
		this.t_svc_cnt = t_svc_cnt;
	}
	public String getJubsu_no() {
		return jubsu_no;
	}
	public void setJubsu_no(String jubsu_no) {
		this.jubsu_no = jubsu_no;
	}
	public String getChuldong_nm() {
		return chuldong_nm;
	}
	public void setChuldong_nm(String chuldong_nm) {
		this.chuldong_nm = chuldong_nm;
	}
	public String getChuldongja_phone() {
		return chuldongja_phone;
	}
	public void setChuldongja_phone(String chuldongja_phone) {
		this.chuldongja_phone = chuldongja_phone;
	}
	public String getCo_nm() {
		return co_nm;
	}
	public void setCo_nm(String co_nm) {
		this.co_nm = co_nm;
	}
	public String getPos_x() {
		return pos_x;
	}
	public void setPos_x(String pos_x) {
		this.pos_x = pos_x;
	}
	public String getPos_y() {
		return pos_y;
	}
	public void setPos_y(String pos_y) {
		this.pos_y = pos_y;
	}
	public String getLbsutmx() {
		return lbsutmx;
	}
	public void setLbsutmx(String lbsutmx) {
		this.lbsutmx = lbsutmx;
	}
	public String getLbsutmy() {
		return lbsutmy;
	}
	public void setLbsutmy(String lbsutmy) {
		this.lbsutmy = lbsutmy;
	}
	public String getYochungja_km() {
		return yochungja_km;
	}
	public void setYochungja_km(String yochungja_km) {
		this.yochungja_km = yochungja_km;
	}
}