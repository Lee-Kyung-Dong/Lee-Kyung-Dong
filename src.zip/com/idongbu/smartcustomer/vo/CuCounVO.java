package com.idongbu.smartcustomer.vo;
  
import com.idongbu.common.vo.CMMVO;

public class CuCounVO extends CMMVO {
	
	public String jumin 					 = "";
	public String cust_email				 = "";
	public String FD_MB_MPHONE1				 = "";//휴대전화1
	public String FD_MB_MPHONE2				 = "";//휴대전화2
	public String FD_MB_MPHONE3				 = "";//휴대전화3 
	public String FD_MB_EMAIL				 = "";//이메일
	public String FD_MB_NAME				 = "";//사용자이름
	public String d_day						 = "";
	public String PhoneNm					 = "";//고객폰넘버
	
		
	public String region					 = "";
	public String BSTOR_BRCH_CD 			 = "";//지점코드 
	public String BSTOR_NAME    			 = "";//지점명   
	public String ADDR_TEXT     			 = "";//주소명   
	public String AREA_TEL_NO   			 = "";//전화번호1
	public String FRNT_TEL_NO   			 = "";//전화번호2
	public String AFTR_TEL_NO   			 = "";//전화번호3
	
	//PA전화번호
	public String pa_phone					 = "";
	public String pa_phone1					 = "";
	public String pa_phone2					 = "";
	public String pa_phone3					 = "";

	//상담신청
	public String cm_pa_gubun             	 = ""; //CM,PA구분
	public String sangpum_cd	             = ""; //상품코드
	public String sangpum_plan	          	 = ""; //상품플랜
	public String sangpum_nm	             = ""; //상품이름
	public String cust_jumin	             = ""; //고객주번
	public String cust_name	              	 = ""; //고객이름
	public String sangdamil_date           	 = ""; // 상담일자(yyyymmddhh24miss)
	public String upmu_desc1				 = ""; // 보험상품 or 증명서
	public String upmu_desc2				 = ""; // 상담명(컨버전스, 자동차, 아이사랑, 스마트운전자, 자동차/장기)
	public String upmu_desc3				 = ""; // 상담신청 or 증명서명
	public String status					 = ""; // 접수완료(보험신청) or 성공/실패(증명서)
	
	//Agent검색되는 고객정보
	public String phone_1	                 = ""; //전화1
	public String phone_2	                 = ""; //전화2
	public String phone_3	                 = ""; //전화3
	
	//Agent검색되지않는 고객정보
	public String phone1	                 = ""; //전화1
	public String phone2	                 = ""; //전화2
	public String phone3	                 = ""; //전화3
	
	public String jijum_cd	              	 = ""; //지점코드
	public String jijum_name              	 = ""; //지점이름
	public String pa_cd                   	 = ""; //pa코드
	public String pa_name	                 = ""; //pa이름
	public String sangdam_content         	 = ""; //상담내용
	public String visit_course 	          	 = ""; //고객센터상담하기"C"
	public String birth_year	 	         = ""; //생년
	public String birth_month		         = ""; //월
	public String birth_day	              	 = ""; //일
	public String sex_type	  	          	 = ""; //성별
	public String RCEPT_NO					 = ""; //MAX값(HAM_SDEG_MSTR)
	public String idx						 = ""; //MAX값(HAB_CONSL_APPLY)
	
	
	//CM_CUSTOMER(DSN_CM)
	public String SQL_COLUMN      			 = "";  //전화구분(핸드폰,직장,집)
	public String cust_phone      			 = "";  //고객전화번호
	public String jehusa_cd       			 = "";  //제휴사코드
	public String channel_cd      			 = "";  //WEB OR ARS
	public String bojong_cd       			 = "";  //장기
	public String req_type        			 = "";  //전화
	public String upload_yn       			 = "";  //업로드 여부
	public String customer_sex    			 = "";  //성별
	public String birthday        			 = "";  //생일
	
	//발송리스트
	public String WORKDAY                    = "";
	public String SEQNO                      = "";
	public String SN                         = "";
	public String RECIEVEREMAIL_OUT          = "";
	public String SEND_DATA                  = "";
	
	//발송정보
	public String LIST_TABLE				 = "";
	
	
	//부서수신함
	public String title             		 = "";
	public String content					 = "";
	public String userid            		 = "";
	public String username          		 = "";
	public String deptid            		 = "";
	public String deptname          		 = "";
	public String email             		 = "";
	public String JIKWI             	 	 = "";
	public String IMPORTANCE        		 = "";
	public String HASATTACHFILE     		 = "";
	public String NOWDATE					 = "";
	public String EXPIREDDATE				 = "";
	public String DRMGRADE          		 = "";
	public String CONTENTCODE       		 = "";
	public String BULLETINID        		 = "";
	public String ALLDEPT           		 = "";
	public String RECDEPTLIST       		 = "";
	public String DELIMITER         		 = "";
	public String PHONE             		 = "";
	
	
	public String jibu_cd					 = "";//지부코드
	public String jibu_name					 = "";//지부명
	
	//메일
	public String EMAIL_ADDR_NAME			 = "";//부서 이메일
	public String ms_email					 = "";//메일묶음
	public String pa_email					 = "";//PA이메일
	public String chk						 = "";
	
	//서울,광주,부산 이메일 및 전화번호 부분 (이메일 발송 및 sms 사원 이름,사원 번호)
	public String emp_phone             	 = "";
	public String log_email             	 = "";
	public String log_phone1            	 = "";
	public String log_phone2            	 = "";
	public String log_phone3            	 = "";
	public String EMP_NAME					 = "";//사원 이름
	public String EMP_NO                     = "";//사원 번호
	
	
	//카운트
	public String CN						 = "";
	
	//소지부,영업서무 전화번호
	public String FRNT_HPHON_NO				 = "";//앞자리
	public String INTMD_HPHON_NO			 = "";//가운데
	public String HPHON_AFTR_TEL_NO			 = "";//뒷자리
	
	public String radio						 = "";//내인생 필요자금 - 보험종류
	public String radio_ch					 = "";//내인생 필요자금 - 보험상품
	public String UserName					 = "";
	public String UserJumin					 = "";
	public String UserEmail					 = "";
	
	
	public int dtas_flag = 0; 				// 홈페이지 자녀사랑 실시간 상담로그 DTAS 전달여부(0: 전달하지 않음, 1: 전달)
	public String insrd_name = "";			// 피보험자 이름
	public String insrd_inhab_no = "";		// 피보험자 주민번호
	public String cm_customer_seq = "";		// CM_CUSTOMER TBL SEQ
	
	
	// TC 관련 
	public int seq_no = 0;
	public String tc_pa_id = "";
	public String tc_pa_name = "";
	public String tc_pa_hp1 = "";
	public String tc_pa_hp2 = "";
	public String tc_pa_hp3 = "";
	public String tc_pa_email = "";
	public String manag_name = "";
	public String manag_hp1 = "";
	public String manag_hp2 = "";
	public String manag_hp3 = "";
	public String manag_email = "";
	public String admin_name = "";
	public String admin_hp1 = "";
	public String admin_hp2 = "";
	public String admin_hp3 = "";
	public String admin_email = "";
	public String area1_cd = "";
	public String area2_cd = "";
	public String jumpo_cd = "";
	
	
	//TM 상담 관련 구글
	public String opms_path="";

	
	//재무상담
	public String answer1 = "";
	
	// 증명서 발급
	public String poliNo   = "";	// 증권번호
	public String sendNote = "";	// 이메일 or FAX
	
	public String getJumin() {
		return jumin;
	}
	public void setJumin(String jumin) {
		this.jumin = jumin;
	}
	public String getCust_email() {
		return cust_email;
	}
	public void setCust_email(String cust_email) {
		this.cust_email = cust_email;
	}
	public String getFD_MB_MPHONE1() {
		return FD_MB_MPHONE1;
	}
	public void setFD_MB_MPHONE1(String fD_MB_MPHONE1) {
		FD_MB_MPHONE1 = fD_MB_MPHONE1;
	}
	public String getFD_MB_MPHONE2() {
		return FD_MB_MPHONE2;
	}
	public void setFD_MB_MPHONE2(String fD_MB_MPHONE2) {
		FD_MB_MPHONE2 = fD_MB_MPHONE2;
	}
	public String getFD_MB_MPHONE3() {
		return FD_MB_MPHONE3;
	}
	public void setFD_MB_MPHONE3(String fD_MB_MPHONE3) {
		FD_MB_MPHONE3 = fD_MB_MPHONE3;
	}
	public String getFD_MB_EMAIL() {
		return FD_MB_EMAIL;
	}
	public void setFD_MB_EMAIL(String fD_MB_EMAIL) {
		FD_MB_EMAIL = fD_MB_EMAIL;
	}
	public String getFD_MB_NAME() {
		return FD_MB_NAME;
	}
	public void setFD_MB_NAME(String fD_MB_NAME) {
		FD_MB_NAME = fD_MB_NAME;
	}
	public String getD_day() {
		return d_day;
	}
	public void setD_day(String d_day) {
		this.d_day = d_day;
	}
	public String getPhoneNm() {
		return PhoneNm;
	}
	public void setPhoneNm(String phoneNm) {
		PhoneNm = phoneNm;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getBSTOR_BRCH_CD() {
		return BSTOR_BRCH_CD;
	}
	public void setBSTOR_BRCH_CD(String bSTOR_BRCH_CD) {
		BSTOR_BRCH_CD = bSTOR_BRCH_CD;
	}
	public String getBSTOR_NAME() {
		return BSTOR_NAME;
	}
	public void setBSTOR_NAME(String bSTOR_NAME) {
		BSTOR_NAME = bSTOR_NAME;
	}
	public String getADDR_TEXT() {
		return ADDR_TEXT;
	}
	public void setADDR_TEXT(String aDDR_TEXT) {
		ADDR_TEXT = aDDR_TEXT;
	}
	public String getAREA_TEL_NO() {
		return AREA_TEL_NO;
	}
	public void setAREA_TEL_NO(String aREA_TEL_NO) {
		AREA_TEL_NO = aREA_TEL_NO;
	}
	public String getFRNT_TEL_NO() {
		return FRNT_TEL_NO;
	}
	public void setFRNT_TEL_NO(String fRNT_TEL_NO) {
		FRNT_TEL_NO = fRNT_TEL_NO;
	}
	public String getAFTR_TEL_NO() {
		return AFTR_TEL_NO;
	}
	public void setAFTR_TEL_NO(String aFTR_TEL_NO) {
		AFTR_TEL_NO = aFTR_TEL_NO;
	}
	public String getPa_phone() {
		return pa_phone;
	}
	public void setPa_phone(String pa_phone) {
		this.pa_phone = pa_phone;
	}
	public String getPa_phone1() {
		return pa_phone1;
	}
	public void setPa_phone1(String pa_phone1) {
		this.pa_phone1 = pa_phone1;
	}
	public String getPa_phone2() {
		return pa_phone2;
	}
	public void setPa_phone2(String pa_phone2) {
		this.pa_phone2 = pa_phone2;
	}
	public String getPa_phone3() {
		return pa_phone3;
	}
	public void setPa_phone3(String pa_phone3) {
		this.pa_phone3 = pa_phone3;
	}
	public String getCm_pa_gubun() {
		return cm_pa_gubun;
	}
	public void setCm_pa_gubun(String cm_pa_gubun) {
		this.cm_pa_gubun = cm_pa_gubun;
	}
	public String getSangpum_cd() {
		return sangpum_cd;
	}
	public void setSangpum_cd(String sangpum_cd) {
		this.sangpum_cd = sangpum_cd;
	}
	public String getSangpum_plan() {
		return sangpum_plan;
	}
	public void setSangpum_plan(String sangpum_plan) {
		this.sangpum_plan = sangpum_plan;
	}
	public String getSangpum_nm() {
		return sangpum_nm;
	}
	public void setSangpum_nm(String sangpum_nm) {
		this.sangpum_nm = sangpum_nm;
	}
	public String getCust_jumin() {
		return cust_jumin;
	}
	public void setCust_jumin(String cust_jumin) {
		this.cust_jumin = cust_jumin;
	}
	public String getCust_name() {
		return cust_name;
	}
	public void setCust_name(String cust_name) {
		this.cust_name = cust_name;
	}
	public String getSangdamil_date() {
		return sangdamil_date;
	}
	public void setSangdamil_date(String sangdamil_date) {
		this.sangdamil_date = sangdamil_date;
	}
	public String getUpmu_desc1() {
		return upmu_desc1;
	}
	public void setUpmu_desc1(String upmu_desc1) {
		this.upmu_desc1 = upmu_desc1;
	}
	public String getUpmu_desc2() {
		return upmu_desc2;
	}
	public void setUpmu_desc2(String upmu_desc2) {
		this.upmu_desc2 = upmu_desc2;
	}
	public String getUpmu_desc3() {
		return upmu_desc3;
	}
	public void setUpmu_desc3(String upmu_desc3) {
		this.upmu_desc3 = upmu_desc3;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getPhone_1() {
		return phone_1;
	}
	public void setPhone_1(String phone_1) {
		this.phone_1 = phone_1;
	}
	public String getPhone_2() {
		return phone_2;
	}
	public void setPhone_2(String phone_2) {
		this.phone_2 = phone_2;
	}
	public String getPhone_3() {
		return phone_3;
	}
	public void setPhone_3(String phone_3) {
		this.phone_3 = phone_3;
	}
	public String getPhone1() {
		return phone1;
	}
	public void setPhone1(String phone1) {
		this.phone1 = phone1;
	}
	public String getPhone2() {
		return phone2;
	}
	public void setPhone2(String phone2) {
		this.phone2 = phone2;
	}
	public String getPhone3() {
		return phone3;
	}
	public void setPhone3(String phone3) {
		this.phone3 = phone3;
	}
	public String getJijum_cd() {
		return jijum_cd;
	}
	public void setJijum_cd(String jijum_cd) {
		this.jijum_cd = jijum_cd;
	}
	public String getJijum_name() {
		return jijum_name;
	}
	public void setJijum_name(String jijum_name) {
		this.jijum_name = jijum_name;
	}
	public String getPa_cd() {
		return pa_cd;
	}
	public void setPa_cd(String pa_cd) {
		this.pa_cd = pa_cd;
	}
	public String getPa_name() {
		return pa_name;
	}
	public void setPa_name(String pa_name) {
		this.pa_name = pa_name;
	}
	public String getSangdam_content() {
		return sangdam_content;
	}
	public void setSangdam_content(String sangdam_content) {
		this.sangdam_content = sangdam_content;
	}
	public String getVisit_course() {
		return visit_course;
	}
	public void setVisit_course(String visit_course) {
		this.visit_course = visit_course;
	}
	public String getBirth_year() {
		return birth_year;
	}
	public void setBirth_year(String birth_year) {
		this.birth_year = birth_year;
	}
	public String getBirth_month() {
		return birth_month;
	}
	public void setBirth_month(String birth_month) {
		this.birth_month = birth_month;
	}
	public String getBirth_day() {
		return birth_day;
	}
	public void setBirth_day(String birth_day) {
		this.birth_day = birth_day;
	}
	public String getSex_type() {
		return sex_type;
	}
	public void setSex_type(String sex_type) {
		this.sex_type = sex_type;
	}
	public String getRCEPT_NO() {
		return RCEPT_NO;
	}
	public void setRCEPT_NO(String rCEPT_NO) {
		RCEPT_NO = rCEPT_NO;
	}
	public String getIdx() {
		return idx;
	}
	public void setIdx(String idx) {
		this.idx = idx;
	}
	public String getSQL_COLUMN() {
		return SQL_COLUMN;
	}
	public void setSQL_COLUMN(String sQL_COLUMN) {
		SQL_COLUMN = sQL_COLUMN;
	}
	public String getCust_phone() {
		return cust_phone;
	}
	public void setCust_phone(String cust_phone) {
		this.cust_phone = cust_phone;
	}
	public String getJehusa_cd() {
		return jehusa_cd;
	}
	public void setJehusa_cd(String jehusa_cd) {
		this.jehusa_cd = jehusa_cd;
	}
	public String getChannel_cd() {
		return channel_cd;
	}
	public void setChannel_cd(String channel_cd) {
		this.channel_cd = channel_cd;
	}
	public String getBojong_cd() {
		return bojong_cd;
	}
	public void setBojong_cd(String bojong_cd) {
		this.bojong_cd = bojong_cd;
	}
	public String getReq_type() {
		return req_type;
	}
	public void setReq_type(String req_type) {
		this.req_type = req_type;
	}
	public String getUpload_yn() {
		return upload_yn;
	}
	public void setUpload_yn(String upload_yn) {
		this.upload_yn = upload_yn;
	}
	public String getCustomer_sex() {
		return customer_sex;
	}
	public void setCustomer_sex(String customer_sex) {
		this.customer_sex = customer_sex;
	}
	public String getBirthday() {
		return birthday;
	}
	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}
	public String getWORKDAY() {
		return WORKDAY;
	}
	public void setWORKDAY(String wORKDAY) {
		WORKDAY = wORKDAY;
	}
	public String getSEQNO() {
		return SEQNO;
	}
	public void setSEQNO(String sEQNO) {
		SEQNO = sEQNO;
	}
	public String getSN() {
		return SN;
	}
	public void setSN(String sN) {
		SN = sN;
	}
	public String getRECIEVEREMAIL_OUT() {
		return RECIEVEREMAIL_OUT;
	}
	public void setRECIEVEREMAIL_OUT(String rECIEVEREMAIL_OUT) {
		RECIEVEREMAIL_OUT = rECIEVEREMAIL_OUT;
	}
	public String getSEND_DATA() {
		return SEND_DATA;
	}
	public void setSEND_DATA(String sEND_DATA) {
		SEND_DATA = sEND_DATA;
	}
	public String getLIST_TABLE() {
		return LIST_TABLE;
	}
	public void setLIST_TABLE(String lIST_TABLE) {
		LIST_TABLE = lIST_TABLE;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getDeptid() {
		return deptid;
	}
	public void setDeptid(String deptid) {
		this.deptid = deptid;
	}
	public String getDeptname() {
		return deptname;
	}
	public void setDeptname(String deptname) {
		this.deptname = deptname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getJIKWI() {
		return JIKWI;
	}
	public void setJIKWI(String jIKWI) {
		JIKWI = jIKWI;
	}
	public String getIMPORTANCE() {
		return IMPORTANCE;
	}
	public void setIMPORTANCE(String iMPORTANCE) {
		IMPORTANCE = iMPORTANCE;
	}
	public String getHASATTACHFILE() {
		return HASATTACHFILE;
	}
	public void setHASATTACHFILE(String hASATTACHFILE) {
		HASATTACHFILE = hASATTACHFILE;
	}
	public String getNOWDATE() {
		return NOWDATE;
	}
	public void setNOWDATE(String nOWDATE) {
		NOWDATE = nOWDATE;
	}
	public String getEXPIREDDATE() {
		return EXPIREDDATE;
	}
	public void setEXPIREDDATE(String eXPIREDDATE) {
		EXPIREDDATE = eXPIREDDATE;
	}
	public String getDRMGRADE() {
		return DRMGRADE;
	}
	public void setDRMGRADE(String dRMGRADE) {
		DRMGRADE = dRMGRADE;
	}
	public String getCONTENTCODE() {
		return CONTENTCODE;
	}
	public void setCONTENTCODE(String cONTENTCODE) {
		CONTENTCODE = cONTENTCODE;
	}
	public String getBULLETINID() {
		return BULLETINID;
	}
	public void setBULLETINID(String bULLETINID) {
		BULLETINID = bULLETINID;
	}
	public String getALLDEPT() {
		return ALLDEPT;
	}
	public void setALLDEPT(String aLLDEPT) {
		ALLDEPT = aLLDEPT;
	}
	public String getRECDEPTLIST() {
		return RECDEPTLIST;
	}
	public void setRECDEPTLIST(String rECDEPTLIST) {
		RECDEPTLIST = rECDEPTLIST;
	}
	public String getDELIMITER() {
		return DELIMITER;
	}
	public void setDELIMITER(String dELIMITER) {
		DELIMITER = dELIMITER;
	}
	public String getPHONE() {
		return PHONE;
	}
	public void setPHONE(String pHONE) {
		PHONE = pHONE;
	}
	public String getJibu_cd() {
		return jibu_cd;
	}
	public void setJibu_cd(String jibu_cd) {
		this.jibu_cd = jibu_cd;
	}
	public String getJibu_name() {
		return jibu_name;
	}
	public void setJibu_name(String jibu_name) {
		this.jibu_name = jibu_name;
	}
	public String getEMAIL_ADDR_NAME() {
		return EMAIL_ADDR_NAME;
	}
	public void setEMAIL_ADDR_NAME(String eMAIL_ADDR_NAME) {
		EMAIL_ADDR_NAME = eMAIL_ADDR_NAME;
	}
	public String getMs_email() {
		return ms_email;
	}
	public void setMs_email(String ms_email) {
		this.ms_email = ms_email;
	}
	public String getPa_email() {
		return pa_email;
	}
	public void setPa_email(String pa_email) {
		this.pa_email = pa_email;
	}
	public String getChk() {
		return chk;
	}
	public void setChk(String chk) {
		this.chk = chk;
	}
	public String getEmp_phone() {
		return emp_phone;
	}
	public void setEmp_phone(String emp_phone) {
		this.emp_phone = emp_phone;
	}
	public String getLog_email() {
		return log_email;
	}
	public void setLog_email(String log_email) {
		this.log_email = log_email;
	}
	public String getLog_phone1() {
		return log_phone1;
	}
	public void setLog_phone1(String log_phone1) {
		this.log_phone1 = log_phone1;
	}
	public String getLog_phone2() {
		return log_phone2;
	}
	public void setLog_phone2(String log_phone2) {
		this.log_phone2 = log_phone2;
	}
	public String getLog_phone3() {
		return log_phone3;
	}
	public void setLog_phone3(String log_phone3) {
		this.log_phone3 = log_phone3;
	}
	public String getEMP_NAME() {
		return EMP_NAME;
	}
	public void setEMP_NAME(String eMP_NAME) {
		EMP_NAME = eMP_NAME;
	}
	public String getEMP_NO() {
		return EMP_NO;
	}
	public void setEMP_NO(String eMP_NO) {
		EMP_NO = eMP_NO;
	}
	public String getCN() {
		return CN;
	}
	public void setCN(String cN) {
		CN = cN;
	}
	public String getFRNT_HPHON_NO() {
		return FRNT_HPHON_NO;
	}
	public void setFRNT_HPHON_NO(String fRNT_HPHON_NO) {
		FRNT_HPHON_NO = fRNT_HPHON_NO;
	}
	public String getINTMD_HPHON_NO() {
		return INTMD_HPHON_NO;
	}
	public void setINTMD_HPHON_NO(String iNTMD_HPHON_NO) {
		INTMD_HPHON_NO = iNTMD_HPHON_NO;
	}
	public String getHPHON_AFTR_TEL_NO() {
		return HPHON_AFTR_TEL_NO;
	}
	public void setHPHON_AFTR_TEL_NO(String hPHON_AFTR_TEL_NO) {
		HPHON_AFTR_TEL_NO = hPHON_AFTR_TEL_NO;
	}
	public String getRadio() {
		return radio;
	}
	public void setRadio(String radio) {
		this.radio = radio;
	}
	public String getRadio_ch() {
		return radio_ch;
	}
	public void setRadio_ch(String radio_ch) {
		this.radio_ch = radio_ch;
	}
	public String getUserName() {
		return UserName;
	}
	public void setUserName(String userName) {
		UserName = userName;
	}
	public String getUserJumin() {
		return UserJumin;
	}
	public void setUserJumin(String userJumin) {
		UserJumin = userJumin;
	}
	public String getUserEmail() {
		return UserEmail;
	}
	public void setUserEmail(String userEmail) {
		UserEmail = userEmail;
	}
	public int getDtas_flag() {
		return dtas_flag;
	}
	public void setDtas_flag(int dtas_flag) {
		this.dtas_flag = dtas_flag;
	}
	public String getInsrd_name() {
		return insrd_name;
	}
	public void setInsrd_name(String insrd_name) {
		this.insrd_name = insrd_name;
	}
	public String getInsrd_inhab_no() {
		return insrd_inhab_no;
	}
	public void setInsrd_inhab_no(String insrd_inhab_no) {
		this.insrd_inhab_no = insrd_inhab_no;
	}
	public String getCm_customer_seq() {
		return cm_customer_seq;
	}
	public void setCm_customer_seq(String cm_customer_seq) {
		this.cm_customer_seq = cm_customer_seq;
	}
	public int getSeq_no() {
		return seq_no;
	}
	public void setSeq_no(int seq_no) {
		this.seq_no = seq_no;
	}
	public String getTc_pa_id() {
		return tc_pa_id;
	}
	public void setTc_pa_id(String tc_pa_id) {
		this.tc_pa_id = tc_pa_id;
	}
	public String getTc_pa_name() {
		return tc_pa_name;
	}
	public void setTc_pa_name(String tc_pa_name) {
		this.tc_pa_name = tc_pa_name;
	}
	public String getTc_pa_hp1() {
		return tc_pa_hp1;
	}
	public void setTc_pa_hp1(String tc_pa_hp1) {
		this.tc_pa_hp1 = tc_pa_hp1;
	}
	public String getTc_pa_hp2() {
		return tc_pa_hp2;
	}
	public void setTc_pa_hp2(String tc_pa_hp2) {
		this.tc_pa_hp2 = tc_pa_hp2;
	}
	public String getTc_pa_hp3() {
		return tc_pa_hp3;
	}
	public void setTc_pa_hp3(String tc_pa_hp3) {
		this.tc_pa_hp3 = tc_pa_hp3;
	}
	public String getTc_pa_email() {
		return tc_pa_email;
	}
	public void setTc_pa_email(String tc_pa_email) {
		this.tc_pa_email = tc_pa_email;
	}
	public String getManag_name() {
		return manag_name;
	}
	public void setManag_name(String manag_name) {
		this.manag_name = manag_name;
	}
	public String getManag_hp1() {
		return manag_hp1;
	}
	public void setManag_hp1(String manag_hp1) {
		this.manag_hp1 = manag_hp1;
	}
	public String getManag_hp2() {
		return manag_hp2;
	}
	public void setManag_hp2(String manag_hp2) {
		this.manag_hp2 = manag_hp2;
	}
	public String getManag_hp3() {
		return manag_hp3;
	}
	public void setManag_hp3(String manag_hp3) {
		this.manag_hp3 = manag_hp3;
	}
	public String getManag_email() {
		return manag_email;
	}
	public void setManag_email(String manag_email) {
		this.manag_email = manag_email;
	}
	public String getAdmin_name() {
		return admin_name;
	}
	public void setAdmin_name(String admin_name) {
		this.admin_name = admin_name;
	}
	public String getAdmin_hp1() {
		return admin_hp1;
	}
	public void setAdmin_hp1(String admin_hp1) {
		this.admin_hp1 = admin_hp1;
	}
	public String getAdmin_hp2() {
		return admin_hp2;
	}
	public void setAdmin_hp2(String admin_hp2) {
		this.admin_hp2 = admin_hp2;
	}
	public String getAdmin_hp3() {
		return admin_hp3;
	}
	public void setAdmin_hp3(String admin_hp3) {
		this.admin_hp3 = admin_hp3;
	}
	public String getAdmin_email() {
		return admin_email;
	}
	public void setAdmin_email(String admin_email) {
		this.admin_email = admin_email;
	}
	public String getArea1_cd() {
		return area1_cd;
	}
	public void setArea1_cd(String area1_cd) {
		this.area1_cd = area1_cd;
	}
	public String getArea2_cd() {
		return area2_cd;
	}
	public void setArea2_cd(String area2_cd) {
		this.area2_cd = area2_cd;
	}
	public String getJumpo_cd() {
		return jumpo_cd;
	}
	public void setJumpo_cd(String jumpo_cd) {
		this.jumpo_cd = jumpo_cd;
	}
	public String getOpms_path() {
		return opms_path;
	}
	public void setOpms_path(String opms_path) {
		this.opms_path = opms_path;
	}
	public String getAnswer1() {
		return answer1;
	}
	public void setAnswer1(String answer1) {
		this.answer1 = answer1;
	}
	public String getPoliNo() {
		return poliNo;
	}
	public void setPoliNo(String poliNo) {
		this.poliNo = poliNo;
	}
	public String getSendNote() {
		return sendNote;
	}
	public void setSendNote(String sendNote) {
		this.sendNote = sendNote;
	}
	
}
