package com.idongbu.smartcustomer.vo;                                                       

import java.util.List;
import java.util.Map;

import com.idongbu.common.vo.CMMVO;
                                                                                        
// 해외여행보험                                                                         
public class CmmFWK2822RVO extends CMMVO {     
	public CmmFWK2822RVO() {
		super.setPGMID(this.proid);
		super.setTRID(this.trid);
	}
	
	public static final String proid		= "FWK2822R";                                     
	public static final String trid		= "WV22";                                           
	public String rURL						= "";                                                   
	                                                                                      
	private String COMM_CHANNEL		= null;	// 채널구분
	private String COMM_UNIQUE		= null;	// TSQ,VSAM FILE용 UNIQUE
	private String COMM_PROGRAM		= null;	// PROGRAM_ID
	private String COMM_TRANS		= null;	// 처리구분
	private String COMM_ACTION		= null;	// 기능키
	private String COMM_USER_GB		= null;	// 사용자구분
	private String COMM_USER_ID		= null;	// 사용자ID
	private String COMM_JIJUM_CD		= null;	// 사용자지점
	private String COMM_JIBU_CD		= null;	// 사용자지부
	private String COMM_PROTOCOL		= null;	// 전문사용구분
	private String COMM_RETN_CODE		= null;	// 처리결과
	private String COMM_LAST_FLAG		= null;	// 마지막자료여부
	private String COMM_CUR_FLD		= null;	// CURSOR  MAP  NAME
	private String COMM_CUR_POS		= null;	// CURSOR  POSITION
	private String COMM_MSG_CODE		= null;	// MESSAGE  CODE
	private String H_COMM_MSG_NAME		= null;	// MESSAGE 명
	private String COMM_SYS_ERR		= null;	// 시스템 MESSAGE
	private String COMM_FIL		= null;	// FILLER

	private String H_COMM_MESSAGE_NM = null;
	private String COMM_SYS_NAME = null;
	private String COMM_SYS_CODE = null;
//	private String COMM_FIL = null;
	private String COMM_CHURI_GB = null;
	private String COMM_BJ_CD = null;
	private String COMM_SULGYE_NO = null;
	private String COMM_POLI_NO = null;
	private String COMM_BESU_SEQ = null;
	private String COMM_DANCHE_YH = null;
	private String COMM_POGWAL_YH = null;
	private String COMM_DONGIL_DAMBO = null;
	private String COMM_DAMBO_SEQ = null;
	private String COMM_PIBO_CNT = null;
	private String COMM_PANME_YH = null;
	private String COMM_GAJOK_GB = null;
	private String COMM_JOB_CD = null;
	private String COMM_PB_GBSU = null;
	private String COMM_PB_CNT = null;
	private String COMM_AMT_CODE = null;
	private String COMM_PLAN_CD = null;
	private String H_COMM_TRIP_PLACE = null;
	private String COMM_TRIP_CODE = null;
	private String H_COMM_TRIP_OBJECT = null;
	private String COMM_TRIP_OB_CD = null;
	
	// 2009.11.06 담보코드 배열로 변경, sjh
	/************************************************************************************************
	[시작] 2012차세대 시작
	
	배열크기 변경
	
	수정일      수정자      내 용
	----------  --------    -------
	2012.09.12  박형규      최초 작성
	************************************************************************************************/
	private String[] COMM_DAMBO_CD = new String[16]; 
	private String[] COMM_GAIP_AMT = new String[16]; 
	private String[] COMM_GYEJWA_CNT = new String[16];
	private String[] COMM_PRM = new String[16];
	private String[] COMM_GONGJE_GMEK = new String[16];
	/************************************************************************************************
	[종료] 2012차세대 종료
	************************************************************************************************/
	private String COMM_WON_TOT_PRM = null;
	private String COMM_BO_GIGAN_SYMD = null;
	private String COMM_BO_GIGAN_SHM = null;
	private String COMM_BO_GIGAN_EYMD = null;
	private String COMM_BO_GIGAN_EHM = null;
	private String COMM_HALIN_YUL = null;
	private String[] COMM_PIBO_MOKJUK_SEQ = new String[6]; 	// 6
	private String[] COMM_PIBO_JUMIN_NO = new String[6]; 	// 6
	private String[] H_COMM_PIBO_NM = new String[6]; 		// 6
	
    // LoopData
    public List<Map<String,Object>> LOOP_DATA1 = null; // 담보내용 
    public List<Map<String,Object>> LOOP_DATA2 = null; // 피보험자사항
	
	public String getrURL() {
		return rURL;
	}
	public void setrURL(String rURL) {
		this.rURL = rURL;
	}
	public String getCOMM_CHANNEL() {
		return COMM_CHANNEL;
	}
	public void setCOMM_CHANNEL(String cOMM_CHANNEL) {
		COMM_CHANNEL = cOMM_CHANNEL;
	}
	public String getCOMM_UNIQUE() {
		return COMM_UNIQUE;
	}
	public void setCOMM_UNIQUE(String cOMM_UNIQUE) {
		COMM_UNIQUE = cOMM_UNIQUE;
	}
	public String getCOMM_PROGRAM() {
		return COMM_PROGRAM;
	}
	public void setCOMM_PROGRAM(String cOMM_PROGRAM) {
		COMM_PROGRAM = cOMM_PROGRAM;
	}
	public String getCOMM_TRANS() {
		return COMM_TRANS;
	}
	public void setCOMM_TRANS(String cOMM_TRANS) {
		COMM_TRANS = cOMM_TRANS;
	}
	public String getCOMM_ACTION() {
		return COMM_ACTION;
	}
	public void setCOMM_ACTION(String cOMM_ACTION) {
		COMM_ACTION = cOMM_ACTION;
	}
	public String getCOMM_USER_GB() {
		return COMM_USER_GB;
	}
	public void setCOMM_USER_GB(String cOMM_USER_GB) {
		COMM_USER_GB = cOMM_USER_GB;
	}
	public String getCOMM_USER_ID() {
		return COMM_USER_ID;
	}
	public void setCOMM_USER_ID(String cOMM_USER_ID) {
		COMM_USER_ID = cOMM_USER_ID;
	}
	public String getCOMM_JIJUM_CD() {
		return COMM_JIJUM_CD;
	}
	public void setCOMM_JIJUM_CD(String cOMM_JIJUM_CD) {
		COMM_JIJUM_CD = cOMM_JIJUM_CD;
	}
	public String getCOMM_JIBU_CD() {
		return COMM_JIBU_CD;
	}
	public void setCOMM_JIBU_CD(String cOMM_JIBU_CD) {
		COMM_JIBU_CD = cOMM_JIBU_CD;
	}
	public String getCOMM_PROTOCOL() {
		return COMM_PROTOCOL;
	}
	public void setCOMM_PROTOCOL(String cOMM_PROTOCOL) {
		COMM_PROTOCOL = cOMM_PROTOCOL;
	}
	public String getCOMM_RETN_CODE() {
		return COMM_RETN_CODE;
	}
	public void setCOMM_RETN_CODE(String cOMM_RETN_CODE) {
		COMM_RETN_CODE = cOMM_RETN_CODE;
	}
	public String getCOMM_LAST_FLAG() {
		return COMM_LAST_FLAG;
	}
	public void setCOMM_LAST_FLAG(String cOMM_LAST_FLAG) {
		COMM_LAST_FLAG = cOMM_LAST_FLAG;
	}
	public String getCOMM_CUR_FLD() {
		return COMM_CUR_FLD;
	}
	public void setCOMM_CUR_FLD(String cOMM_CUR_FLD) {
		COMM_CUR_FLD = cOMM_CUR_FLD;
	}
	public String getCOMM_CUR_POS() {
		return COMM_CUR_POS;
	}
	public void setCOMM_CUR_POS(String cOMM_CUR_POS) {
		COMM_CUR_POS = cOMM_CUR_POS;
	}
	public String getCOMM_MSG_CODE() {
		return COMM_MSG_CODE;
	}
	public void setCOMM_MSG_CODE(String cOMM_MSG_CODE) {
		COMM_MSG_CODE = cOMM_MSG_CODE;
	}
	public String getH_COMM_MSG_NAME() {
		return H_COMM_MSG_NAME;
	}
	public void setH_COMM_MSG_NAME(String h_COMM_MSG_NAME) {
		H_COMM_MSG_NAME = h_COMM_MSG_NAME;
	}
	public String getCOMM_SYS_ERR() {
		return COMM_SYS_ERR;
	}
	public void setCOMM_SYS_ERR(String cOMM_SYS_ERR) {
		COMM_SYS_ERR = cOMM_SYS_ERR;
	}
	public String getCOMM_FIL() {
		return COMM_FIL;
	}
	public void setCOMM_FIL(String cOMM_FIL) {
		COMM_FIL = cOMM_FIL;
	}
	public String getH_COMM_MESSAGE_NM() {
		return H_COMM_MESSAGE_NM;
	}
	public void setH_COMM_MESSAGE_NM(String h_COMM_MESSAGE_NM) {
		H_COMM_MESSAGE_NM = h_COMM_MESSAGE_NM;
	}
	public String getCOMM_SYS_NAME() {
		return COMM_SYS_NAME;
	}
	public void setCOMM_SYS_NAME(String cOMM_SYS_NAME) {
		COMM_SYS_NAME = cOMM_SYS_NAME;
	}
	public String getCOMM_SYS_CODE() {
		return COMM_SYS_CODE;
	}
	public void setCOMM_SYS_CODE(String cOMM_SYS_CODE) {
		COMM_SYS_CODE = cOMM_SYS_CODE;
	}
	public String getCOMM_CHURI_GB() {
		return COMM_CHURI_GB;
	}
	public void setCOMM_CHURI_GB(String cOMM_CHURI_GB) {
		COMM_CHURI_GB = cOMM_CHURI_GB;
	}
	public String getCOMM_BJ_CD() {
		return COMM_BJ_CD;
	}
	public void setCOMM_BJ_CD(String cOMM_BJ_CD) {
		COMM_BJ_CD = cOMM_BJ_CD;
	}
	public String getCOMM_SULGYE_NO() {
		return COMM_SULGYE_NO;
	}
	public void setCOMM_SULGYE_NO(String cOMM_SULGYE_NO) {
		COMM_SULGYE_NO = cOMM_SULGYE_NO;
	}
	public String getCOMM_POLI_NO() {
		return COMM_POLI_NO;
	}
	public void setCOMM_POLI_NO(String cOMM_POLI_NO) {
		COMM_POLI_NO = cOMM_POLI_NO;
	}
	public String getCOMM_BESU_SEQ() {
		return COMM_BESU_SEQ;
	}
	public void setCOMM_BESU_SEQ(String cOMM_BESU_SEQ) {
		COMM_BESU_SEQ = cOMM_BESU_SEQ;
	}
	public String getCOMM_DANCHE_YH() {
		return COMM_DANCHE_YH;
	}
	public void setCOMM_DANCHE_YH(String cOMM_DANCHE_YH) {
		COMM_DANCHE_YH = cOMM_DANCHE_YH;
	}
	public String getCOMM_POGWAL_YH() {
		return COMM_POGWAL_YH;
	}
	public void setCOMM_POGWAL_YH(String cOMM_POGWAL_YH) {
		COMM_POGWAL_YH = cOMM_POGWAL_YH;
	}
	public String getCOMM_DONGIL_DAMBO() {
		return COMM_DONGIL_DAMBO;
	}
	public void setCOMM_DONGIL_DAMBO(String cOMM_DONGIL_DAMBO) {
		COMM_DONGIL_DAMBO = cOMM_DONGIL_DAMBO;
	}
	public String getCOMM_DAMBO_SEQ() {
		return COMM_DAMBO_SEQ;
	}
	public void setCOMM_DAMBO_SEQ(String cOMM_DAMBO_SEQ) {
		COMM_DAMBO_SEQ = cOMM_DAMBO_SEQ;
	}
	public String getCOMM_PIBO_CNT() {
		return COMM_PIBO_CNT;
	}
	public void setCOMM_PIBO_CNT(String cOMM_PIBO_CNT) {
		COMM_PIBO_CNT = cOMM_PIBO_CNT;
	}
	public String getCOMM_PANME_YH() {
		return COMM_PANME_YH;
	}
	public void setCOMM_PANME_YH(String cOMM_PANME_YH) {
		COMM_PANME_YH = cOMM_PANME_YH;
	}
	public String getCOMM_GAJOK_GB() {
		return COMM_GAJOK_GB;
	}
	public void setCOMM_GAJOK_GB(String cOMM_GAJOK_GB) {
		COMM_GAJOK_GB = cOMM_GAJOK_GB;
	}
	public String getCOMM_JOB_CD() {
		return COMM_JOB_CD;
	}
	public void setCOMM_JOB_CD(String cOMM_JOB_CD) {
		COMM_JOB_CD = cOMM_JOB_CD;
	}
	public String getCOMM_PB_GBSU() {
		return COMM_PB_GBSU;
	}
	public void setCOMM_PB_GBSU(String cOMM_PB_GBSU) {
		COMM_PB_GBSU = cOMM_PB_GBSU;
	}
	public String getCOMM_PB_CNT() {
		return COMM_PB_CNT;
	}
	public void setCOMM_PB_CNT(String cOMM_PB_CNT) {
		COMM_PB_CNT = cOMM_PB_CNT;
	}
	public String getCOMM_AMT_CODE() {
		return COMM_AMT_CODE;
	}
	public void setCOMM_AMT_CODE(String cOMM_AMT_CODE) {
		COMM_AMT_CODE = cOMM_AMT_CODE;
	}
	public String getCOMM_PLAN_CD() {
		return COMM_PLAN_CD;
	}
	public void setCOMM_PLAN_CD(String cOMM_PLAN_CD) {
		COMM_PLAN_CD = cOMM_PLAN_CD;
	}
	public String getH_COMM_TRIP_PLACE() {
		return H_COMM_TRIP_PLACE;
	}
	public void setH_COMM_TRIP_PLACE(String h_COMM_TRIP_PLACE) {
		H_COMM_TRIP_PLACE = h_COMM_TRIP_PLACE;
	}
	public String getCOMM_TRIP_CODE() {
		return COMM_TRIP_CODE;
	}
	public void setCOMM_TRIP_CODE(String cOMM_TRIP_CODE) {
		COMM_TRIP_CODE = cOMM_TRIP_CODE;
	}
	public String getH_COMM_TRIP_OBJECT() {
		return H_COMM_TRIP_OBJECT;
	}
	public void setH_COMM_TRIP_OBJECT(String h_COMM_TRIP_OBJECT) {
		H_COMM_TRIP_OBJECT = h_COMM_TRIP_OBJECT;
	}
	public String getCOMM_TRIP_OB_CD() {
		return COMM_TRIP_OB_CD;
	}
	public void setCOMM_TRIP_OB_CD(String cOMM_TRIP_OB_CD) {
		COMM_TRIP_OB_CD = cOMM_TRIP_OB_CD;
	}
	public String[] getCOMM_DAMBO_CD() {
		return COMM_DAMBO_CD;
	}
	public void setCOMM_DAMBO_CD(String[] cOMM_DAMBO_CD) {
		COMM_DAMBO_CD = cOMM_DAMBO_CD;
	}
	public String[] getCOMM_GAIP_AMT() {
		return COMM_GAIP_AMT;
	}
	public void setCOMM_GAIP_AMT(String[] cOMM_GAIP_AMT) {
		COMM_GAIP_AMT = cOMM_GAIP_AMT;
	}
	public String[] getCOMM_GYEJWA_CNT() {
		return COMM_GYEJWA_CNT;
	}
	public void setCOMM_GYEJWA_CNT(String[] cOMM_GYEJWA_CNT) {
		COMM_GYEJWA_CNT = cOMM_GYEJWA_CNT;
	}
	public String[] getCOMM_PRM() {
		return COMM_PRM;
	}
	public void setCOMM_PRM(String[] cOMM_PRM) {
		COMM_PRM = cOMM_PRM;
	}
	public String[] getCOMM_GONGJE_GMEK() {
		return COMM_GONGJE_GMEK;
	}
	public void setCOMM_GONGJE_GMEK(String[] cOMM_GONGJE_GMEK) {
		COMM_GONGJE_GMEK = cOMM_GONGJE_GMEK;
	}
	public String getCOMM_WON_TOT_PRM() {
		return COMM_WON_TOT_PRM;
	}
	public void setCOMM_WON_TOT_PRM(String cOMM_WON_TOT_PRM) {
		COMM_WON_TOT_PRM = cOMM_WON_TOT_PRM;
	}
	public String getCOMM_BO_GIGAN_SYMD() {
		return COMM_BO_GIGAN_SYMD;
	}
	public void setCOMM_BO_GIGAN_SYMD(String cOMM_BO_GIGAN_SYMD) {
		COMM_BO_GIGAN_SYMD = cOMM_BO_GIGAN_SYMD;
	}
	public String getCOMM_BO_GIGAN_SHM() {
		return COMM_BO_GIGAN_SHM;
	}
	public void setCOMM_BO_GIGAN_SHM(String cOMM_BO_GIGAN_SHM) {
		COMM_BO_GIGAN_SHM = cOMM_BO_GIGAN_SHM;
	}
	public String getCOMM_BO_GIGAN_EYMD() {
		return COMM_BO_GIGAN_EYMD;
	}
	public void setCOMM_BO_GIGAN_EYMD(String cOMM_BO_GIGAN_EYMD) {
		COMM_BO_GIGAN_EYMD = cOMM_BO_GIGAN_EYMD;
	}
	public String getCOMM_BO_GIGAN_EHM() {
		return COMM_BO_GIGAN_EHM;
	}
	public void setCOMM_BO_GIGAN_EHM(String cOMM_BO_GIGAN_EHM) {
		COMM_BO_GIGAN_EHM = cOMM_BO_GIGAN_EHM;
	}
	public String getCOMM_HALIN_YUL() {
		return COMM_HALIN_YUL;
	}
	public void setCOMM_HALIN_YUL(String cOMM_HALIN_YUL) {
		COMM_HALIN_YUL = cOMM_HALIN_YUL;
	}
	public String[] getCOMM_PIBO_MOKJUK_SEQ() {
		return COMM_PIBO_MOKJUK_SEQ;
	}
	public void setCOMM_PIBO_MOKJUK_SEQ(String[] cOMM_PIBO_MOKJUK_SEQ) {
		COMM_PIBO_MOKJUK_SEQ = cOMM_PIBO_MOKJUK_SEQ;
	}
	public String[] getCOMM_PIBO_JUMIN_NO() {
		return COMM_PIBO_JUMIN_NO;
	}
	public void setCOMM_PIBO_JUMIN_NO(String[] cOMM_PIBO_JUMIN_NO) {
		COMM_PIBO_JUMIN_NO = cOMM_PIBO_JUMIN_NO;
	}
	public String[] getH_COMM_PIBO_NM() {
		return H_COMM_PIBO_NM;
	}
	public void setH_COMM_PIBO_NM(String[] h_COMM_PIBO_NM) {
		H_COMM_PIBO_NM = h_COMM_PIBO_NM;
	}
	public List<Map<String, Object>> getLOOP_DATA1() {
		return LOOP_DATA1;
	}
	public void setLOOP_DATA1(List<Map<String, Object>> lOOP_DATA1) {
		LOOP_DATA1 = lOOP_DATA1;
	}
	public List<Map<String, Object>> getLOOP_DATA2() {
		return LOOP_DATA2;
	}
	public void setLOOP_DATA2(List<Map<String, Object>> lOOP_DATA2) {
		LOOP_DATA2 = lOOP_DATA2;
	}
	

}
