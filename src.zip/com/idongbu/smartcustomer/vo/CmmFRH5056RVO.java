package com.idongbu.smartcustomer.vo;

import java.util.List;
import java.util.Map;

import com.idongbu.common.vo.CMMVO;

public class CmmFRH5056RVO extends CMMVO {

	public CmmFRH5056RVO() {
		super.setPGMID(this.proid);
		super.setTRID(this.trid);
	}	
	
	private static final String proid	= "FRH5056R";        
	//private static final String trid	= "RHZ1";
	private static final String trid	= "RLA6";	
	private String rURL			        = "";
	
	private String CC_CHANNEL		    = "";
	private String CC_UKEY		        = "";
	private String CC_PGMID		        = "";
	private String CC_PROC_GB		    = "";
	private String CC_FUN_KEY		    = "";
	private String CC_USER_GB		    = "";
	private String CC_USER_CD		    = "";
	private String CC_JIJUM_CD		    = "";
	private String CC_JIBU_CD		    = "";
	private String CC_PROTOCOL		    = "";
	private String CC_COND_CD		    = "";
	private String CC_LAST_FLAG		    = "";
	private String CC_CURSOR_MAP		= "";
	private String CC_CURSOR_IDX		= "";
	private String CC_MESSAGE_CD		= "";
	private String HC_MESSAGE_NM		= "";
	private String CC_SYS_ERR		    = "";
	private String CC_FILLER		    = "";
	private String SS_SEL_GB		    = "";
	private String SS_JIJUM_CD		    = "";
	private String HS_JIJUM_NAME	    = "";
	private String SS_TEAM_CD		    = "";
	private String HS_TEAM_NAME		    = "";
	private String SS_JOJIKWON_CD		= "";
	private String HS_JOJIKWON_NAME		= "";
	private String SS_H_JU_SA_GB		= "";
	private String SS_H_JU_SA_NO		= "";
	private String HS_H_JU_SA_NM		= "";
	private String SS_H_BOHUM_GB		= "";
	private String SS_H_SANGDAM_STAT	= "";
	private String SS_H_SANGDAM_TYPE1	= "";
	private String SS_H_SUNGHYANG_GB	= "";
	private String SS_H_JUBSU_DATE_FR	= "";
	private String SS_H_JUBSU_DATE_TO	= "";
	/*
	private String[] SS_SANGDAM_NO1		= new String[0]; // 14
	private String[] SS_SANGDAM_NO2		= new String[0]; // 14
	private String[] SS_SANGDAM_SEQ		= new String[0]; // 14
	private String[] SS_SANG_JUBSU_DATE	= new String[0]; // 14
	private String[] HS_BOHUM_GB		= new String[0]; // 14
	private String[] SS_GIJUNIL_FROM	= new String[0]; // 14
	private String[] HS_SAGO_TYPE2		= new String[0]; // 14
	private String[] HS_SANGDAM_TYPE1   = new String[0]; // 14
	private String[] HS_SANGDAM_STAT    = new String[0]; // 14
	private String[] HS_SUNGHYANG_NY    = new String[0]; // 14
	private String[] HS_BALSONG_SUDAN   = new String[0]; // 14
	private String[] HS_SANGDAMJA		= new String[0]; // 14
	*/
	private List<Map<String, String>> LOOP_DATA = null;
	
	private String SS_TOT_CNT		    = "";
	private String SS_CUR_PAGE		    = "";
	private String SS_TOT_PAGE		    = "";
	private String UUC_I_JU_SA_GB		= "";
	private String UUC_I_JU_SA_NO		= "";
	private String UUC_I_BOHUM_GB		= "";
	private String UUC_I_SANGDAM_STAT	= "";
	private String UUC_I_CHANNEL		= "";
	private String UUC_I_JUBSU_DATE_FR  = "";
	private String UUC_I_JUBSU_DATE_TO  = "";
	private String UUC_I_SANGDAM_NO		= "";
	private String UUC_I_SANGDAM_SEQ	= "";
	private String UUC_F_SANGDAM_NO		= "";
	private String UUC_F_SANGDAM_SEQ	= "";
	private String UUC_L_SANGDAM_NO		= "";
	private String UUC_L_SANGDAM_SEQ	= "";
	
	public String getrURL() {
		return rURL;
	}
	public void setrURL(String rURL) {
		this.rURL = rURL;
	}
	public String getCC_CHANNEL() {
		return CC_CHANNEL;
	}
	public void setCC_CHANNEL(String cC_CHANNEL) {
		CC_CHANNEL = cC_CHANNEL;
	}
	public String getCC_UKEY() {
		return CC_UKEY;
	}
	public void setCC_UKEY(String cC_UKEY) {
		CC_UKEY = cC_UKEY;
	}
	public String getCC_PGMID() {
		return CC_PGMID;
	}
	public void setCC_PGMID(String cC_PGMID) {
		CC_PGMID = cC_PGMID;
	}
	public String getCC_PROC_GB() {
		return CC_PROC_GB;
	}
	public void setCC_PROC_GB(String cC_PROC_GB) {
		CC_PROC_GB = cC_PROC_GB;
	}
	public String getCC_FUN_KEY() {
		return CC_FUN_KEY;
	}
	public void setCC_FUN_KEY(String cC_FUN_KEY) {
		CC_FUN_KEY = cC_FUN_KEY;
	}
	public String getCC_USER_GB() {
		return CC_USER_GB;
	}
	public void setCC_USER_GB(String cC_USER_GB) {
		CC_USER_GB = cC_USER_GB;
	}
	public String getCC_USER_CD() {
		return CC_USER_CD;
	}
	public void setCC_USER_CD(String cC_USER_CD) {
		CC_USER_CD = cC_USER_CD;
	}
	public String getCC_JIJUM_CD() {
		return CC_JIJUM_CD;
	}
	public void setCC_JIJUM_CD(String cC_JIJUM_CD) {
		CC_JIJUM_CD = cC_JIJUM_CD;
	}
	public String getCC_JIBU_CD() {
		return CC_JIBU_CD;
	}
	public void setCC_JIBU_CD(String cC_JIBU_CD) {
		CC_JIBU_CD = cC_JIBU_CD;
	}
	public String getCC_PROTOCOL() {
		return CC_PROTOCOL;
	}
	public void setCC_PROTOCOL(String cC_PROTOCOL) {
		CC_PROTOCOL = cC_PROTOCOL;
	}
	public String getCC_COND_CD() {
		return CC_COND_CD;
	}
	public void setCC_COND_CD(String cC_COND_CD) {
		CC_COND_CD = cC_COND_CD;
	}
	public String getCC_LAST_FLAG() {
		return CC_LAST_FLAG;
	}
	public void setCC_LAST_FLAG(String cC_LAST_FLAG) {
		CC_LAST_FLAG = cC_LAST_FLAG;
	}
	public String getCC_CURSOR_MAP() {
		return CC_CURSOR_MAP;
	}
	public void setCC_CURSOR_MAP(String cC_CURSOR_MAP) {
		CC_CURSOR_MAP = cC_CURSOR_MAP;
	}
	public String getCC_CURSOR_IDX() {
		return CC_CURSOR_IDX;
	}
	public void setCC_CURSOR_IDX(String cC_CURSOR_IDX) {
		CC_CURSOR_IDX = cC_CURSOR_IDX;
	}
	public String getCC_MESSAGE_CD() {
		return CC_MESSAGE_CD;
	}
	public void setCC_MESSAGE_CD(String cC_MESSAGE_CD) {
		CC_MESSAGE_CD = cC_MESSAGE_CD;
	}
	public String getHC_MESSAGE_NM() {
		return HC_MESSAGE_NM;
	}
	public void setHC_MESSAGE_NM(String hC_MESSAGE_NM) {
		HC_MESSAGE_NM = hC_MESSAGE_NM;
	}
	public String getCC_SYS_ERR() {
		return CC_SYS_ERR;
	}
	public void setCC_SYS_ERR(String cC_SYS_ERR) {
		CC_SYS_ERR = cC_SYS_ERR;
	}
	public String getCC_FILLER() {
		return CC_FILLER;
	}
	public void setCC_FILLER(String cC_FILLER) {
		CC_FILLER = cC_FILLER;
	}
	public String getSS_SEL_GB() {
		return SS_SEL_GB;
	}
	public void setSS_SEL_GB(String sS_SEL_GB) {
		SS_SEL_GB = sS_SEL_GB;
	}
	public String getSS_JIJUM_CD() {
		return SS_JIJUM_CD;
	}
	public void setSS_JIJUM_CD(String sS_JIJUM_CD) {
		SS_JIJUM_CD = sS_JIJUM_CD;
	}
	public String getHS_JIJUM_NAME() {
		return HS_JIJUM_NAME;
	}
	public void setHS_JIJUM_NAME(String hS_JIJUM_NAME) {
		HS_JIJUM_NAME = hS_JIJUM_NAME;
	}
	public String getSS_TEAM_CD() {
		return SS_TEAM_CD;
	}
	public void setSS_TEAM_CD(String sS_TEAM_CD) {
		SS_TEAM_CD = sS_TEAM_CD;
	}
	public String getHS_TEAM_NAME() {
		return HS_TEAM_NAME;
	}
	public void setHS_TEAM_NAME(String hS_TEAM_NAME) {
		HS_TEAM_NAME = hS_TEAM_NAME;
	}
	public String getSS_JOJIKWON_CD() {
		return SS_JOJIKWON_CD;
	}
	public void setSS_JOJIKWON_CD(String sS_JOJIKWON_CD) {
		SS_JOJIKWON_CD = sS_JOJIKWON_CD;
	}
	public String getHS_JOJIKWON_NAME() {
		return HS_JOJIKWON_NAME;
	}
	public void setHS_JOJIKWON_NAME(String hS_JOJIKWON_NAME) {
		HS_JOJIKWON_NAME = hS_JOJIKWON_NAME;
	}
	public String getSS_H_JU_SA_GB() {
		return SS_H_JU_SA_GB;
	}
	public void setSS_H_JU_SA_GB(String sS_H_JU_SA_GB) {
		SS_H_JU_SA_GB = sS_H_JU_SA_GB;
	}
	public String getSS_H_JU_SA_NO() {
		return SS_H_JU_SA_NO;
	}
	public void setSS_H_JU_SA_NO(String sS_H_JU_SA_NO) {
		SS_H_JU_SA_NO = sS_H_JU_SA_NO;
	}
	public String getHS_H_JU_SA_NM() {
		return HS_H_JU_SA_NM;
	}
	public void setHS_H_JU_SA_NM(String hS_H_JU_SA_NM) {
		HS_H_JU_SA_NM = hS_H_JU_SA_NM;
	}
	public String getSS_H_BOHUM_GB() {
		return SS_H_BOHUM_GB;
	}
	public void setSS_H_BOHUM_GB(String sS_H_BOHUM_GB) {
		SS_H_BOHUM_GB = sS_H_BOHUM_GB;
	}
	public String getSS_H_SANGDAM_STAT() {
		return SS_H_SANGDAM_STAT;
	}
	public void setSS_H_SANGDAM_STAT(String sS_H_SANGDAM_STAT) {
		SS_H_SANGDAM_STAT = sS_H_SANGDAM_STAT;
	}
	public String getSS_H_SANGDAM_TYPE1() {
		return SS_H_SANGDAM_TYPE1;
	}
	public void setSS_H_SANGDAM_TYPE1(String sS_H_SANGDAM_TYPE1) {
		SS_H_SANGDAM_TYPE1 = sS_H_SANGDAM_TYPE1;
	}
	public String getSS_H_SUNGHYANG_GB() {
		return SS_H_SUNGHYANG_GB;
	}
	public void setSS_H_SUNGHYANG_GB(String sS_H_SUNGHYANG_GB) {
		SS_H_SUNGHYANG_GB = sS_H_SUNGHYANG_GB;
	}
	public String getSS_H_JUBSU_DATE_FR() {
		return SS_H_JUBSU_DATE_FR;
	}
	public void setSS_H_JUBSU_DATE_FR(String sS_H_JUBSU_DATE_FR) {
		SS_H_JUBSU_DATE_FR = sS_H_JUBSU_DATE_FR;
	}
	public String getSS_H_JUBSU_DATE_TO() {
		return SS_H_JUBSU_DATE_TO;
	}
	public void setSS_H_JUBSU_DATE_TO(String sS_H_JUBSU_DATE_TO) {
		SS_H_JUBSU_DATE_TO = sS_H_JUBSU_DATE_TO;
	}
	public List<Map<String, String>> getLOOP_DATA() {
		return LOOP_DATA;
	}
	public void setLOOP_DATA(List<Map<String, String>> lOOP_DATA) {
		LOOP_DATA = lOOP_DATA;
	}
	public String getSS_TOT_CNT() {
		return SS_TOT_CNT;
	}
	public void setSS_TOT_CNT(String sS_TOT_CNT) {
		SS_TOT_CNT = sS_TOT_CNT;
	}
	public String getSS_CUR_PAGE() {
		return SS_CUR_PAGE;
	}
	public void setSS_CUR_PAGE(String sS_CUR_PAGE) {
		SS_CUR_PAGE = sS_CUR_PAGE;
	}
	public String getSS_TOT_PAGE() {
		return SS_TOT_PAGE;
	}
	public void setSS_TOT_PAGE(String sS_TOT_PAGE) {
		SS_TOT_PAGE = sS_TOT_PAGE;
	}
	public String getUUC_I_JU_SA_GB() {
		return UUC_I_JU_SA_GB;
	}
	public void setUUC_I_JU_SA_GB(String uUC_I_JU_SA_GB) {
		UUC_I_JU_SA_GB = uUC_I_JU_SA_GB;
	}
	public String getUUC_I_JU_SA_NO() {
		return UUC_I_JU_SA_NO;
	}
	public void setUUC_I_JU_SA_NO(String uUC_I_JU_SA_NO) {
		UUC_I_JU_SA_NO = uUC_I_JU_SA_NO;
	}
	public String getUUC_I_BOHUM_GB() {
		return UUC_I_BOHUM_GB;
	}
	public void setUUC_I_BOHUM_GB(String uUC_I_BOHUM_GB) {
		UUC_I_BOHUM_GB = uUC_I_BOHUM_GB;
	}
	public String getUUC_I_SANGDAM_STAT() {
		return UUC_I_SANGDAM_STAT;
	}
	public void setUUC_I_SANGDAM_STAT(String uUC_I_SANGDAM_STAT) {
		UUC_I_SANGDAM_STAT = uUC_I_SANGDAM_STAT;
	}
	public String getUUC_I_CHANNEL() {
		return UUC_I_CHANNEL;
	}
	public void setUUC_I_CHANNEL(String uUC_I_CHANNEL) {
		UUC_I_CHANNEL = uUC_I_CHANNEL;
	}
	public String getUUC_I_JUBSU_DATE_FR() {
		return UUC_I_JUBSU_DATE_FR;
	}
	public void setUUC_I_JUBSU_DATE_FR(String uUC_I_JUBSU_DATE_FR) {
		UUC_I_JUBSU_DATE_FR = uUC_I_JUBSU_DATE_FR;
	}
	public String getUUC_I_JUBSU_DATE_TO() {
		return UUC_I_JUBSU_DATE_TO;
	}
	public void setUUC_I_JUBSU_DATE_TO(String uUC_I_JUBSU_DATE_TO) {
		UUC_I_JUBSU_DATE_TO = uUC_I_JUBSU_DATE_TO;
	}
	public String getUUC_I_SANGDAM_NO() {
		return UUC_I_SANGDAM_NO;
	}
	public void setUUC_I_SANGDAM_NO(String uUC_I_SANGDAM_NO) {
		UUC_I_SANGDAM_NO = uUC_I_SANGDAM_NO;
	}
	public String getUUC_I_SANGDAM_SEQ() {
		return UUC_I_SANGDAM_SEQ;
	}
	public void setUUC_I_SANGDAM_SEQ(String uUC_I_SANGDAM_SEQ) {
		UUC_I_SANGDAM_SEQ = uUC_I_SANGDAM_SEQ;
	}
	public String getUUC_F_SANGDAM_NO() {
		return UUC_F_SANGDAM_NO;
	}
	public void setUUC_F_SANGDAM_NO(String uUC_F_SANGDAM_NO) {
		UUC_F_SANGDAM_NO = uUC_F_SANGDAM_NO;
	}
	public String getUUC_F_SANGDAM_SEQ() {
		return UUC_F_SANGDAM_SEQ;
	}
	public void setUUC_F_SANGDAM_SEQ(String uUC_F_SANGDAM_SEQ) {
		UUC_F_SANGDAM_SEQ = uUC_F_SANGDAM_SEQ;
	}
	public String getUUC_L_SANGDAM_NO() {
		return UUC_L_SANGDAM_NO;
	}
	public void setUUC_L_SANGDAM_NO(String uUC_L_SANGDAM_NO) {
		UUC_L_SANGDAM_NO = uUC_L_SANGDAM_NO;
	}
	public String getUUC_L_SANGDAM_SEQ() {
		return UUC_L_SANGDAM_SEQ;
	}
	public void setUUC_L_SANGDAM_SEQ(String uUC_L_SANGDAM_SEQ) {
		UUC_L_SANGDAM_SEQ = uUC_L_SANGDAM_SEQ;
	}
	public static String getProid() {
		return proid;
	}
	public static String getTrid() {
		return trid;
	}	
}
