package com.idongbu.smartcustomer.vo;

import java.util.Arrays;

public class LoInsuAppConfirmVO {
	
	private String 	ssnUserJumin			= "";		//2차에서는 CmmVO에서 상속받은 필드
	private String 	ssnUserName			= "";		//2차에서는 CmmVO에서 상속받은 필드	고객명
	
	private String   insub_pd_name               = ""; //보험상품명
	private String   ar_sttus_name               = ""; //계약상태명
	private long     re_stplt_loan_resid_amt     = 0; //기약관대출잔액
	private String   int_pay_date			    = ""; //이자납입일자시간
	private String   inet_loan_posbl_yn		    = ""; //인터넷대출가능여부
	private long     tot						    = 0; //총 대출 신청액
	
	private String   JJ_INJNG		    		= ""; 
	private String 	daechul				    	= ""; //대출 신청 금액
	private String 	ijanapip				    = ""; //이자납입일
	private String stock_seq			   = ""; //증권번호 
	
	private String 	ins_lcpl_dvcd				    = ""; //컨버전스코드
	private String  ply_sqno			   = ""; //컨버전스코드
	
	private String[] input_stock_seqs		= new String[0]; //선택된 증권번호 집합 
	private String[] input_ins_lcpl_dvcd		= new String[0]; //선택된 컨버전스구분 집합 
	private String[] input_ply_sqno		= new String[0]; //선택된 컨버전스시퀀스 집합 
	
	//대출신청 3단계에서 보여줄 은행명//////////////////////////////////////////////
	private String new_s_bank_name =""; //(3차 신규)DB에서 조회한 고객에게 보여줄 은행명(대출지급은행)
	private String new_ij_bank_name =""; //(3차 신규)DB에서 조회한 고객에게 보여줄 은행명(이자납입은행)
	
	//대출신청 4단계에서 화면에 보여줄 데이타////////////////////////////////////////
	private String[] input_int_rate			    = new String[0]; //선택된 이율 집합
	private String ssnUserJumin_masking = "";		//주민번호 마스킹처리
	private long totLoan = 0;		//총 대출신청금액
	private long ipgum = 0;		//입금액
	private long gongje = 0;		//공제액
	//////////////////////////////////////////////////////////////////////////////////////
	
	//대출신청 5단계에 DB insert용 필드
	private String remit_seq = "";
	private String jj_napip_ija = "";	//이자	PAY_INT_AMT
	private String jj_injidae = "";	//인지대 ACK_TEXT
	private String jj_gongje_gm = "";	//공제금 SUBTR_AMT
	private String jj_chagam_gm = "";	//차감 실지급금 REAL_REMIT_AMT
	private String jj_bank_jijum = "";	//은행지점코드 BANK_BSTOR_CD
	private String hj_bank_jijum_nm = "";	//은행지점명 BANK_BSTOR_NAME
	private String hj_yegmju_nm = "";	//예금주명  DPOSR_NAME
	private String jj_yegmju_tel = "";	//예금주 전화번호  DPOSR_TEL_NO
	private String jj_yunc_iyul = "";	//?  RETURN_CD
	private String jj_napip_ymd = "";	//납입일자  INT_PAY_DATE
	private String applydate = "";	//?  STPLT_AGREE_DATE
	private String tel_no = "";	//?  고객전번인듯
	private String gyejwa_hwkin = "";	//?  ACC_CONF
	private String jj_jikwon_pa = "";	//?  JJ_JIKWON_PA
	//////////////////////////////////////////////////////////////////////////////////////
	
	
	private String int_rate			    = ""; //이율 
	private String stplt_loan_posbl_amt    	= ""; //대출 가능한 금액
	
	private String jj_s_poli_no    	= ""; //S증권번호 (사용용도는 기간계만 알고있음)
	private String jj_s_bank_cd    	= ""; //은행코드
	private String jj_s_bank_nm    	= ""; //은행명
	private String jj_s_gyejwa_no    = ""; //계좌번호
	private String jj_s_gyejwa_no_masking    = ""; //계좌번호 마스킹

	//2012.05.21 계좌구분자 추가 빈현욱 2012.05.21
	private String jj_gyejwa_yn    = ""; //1이면 창구등록계좌, 나머지 공백
	
	//이자납입계좌
	private String jj_ij_bank_cd =""; // 은행코드
	private String jj_ij_bank_nm =""; // 은행명
	private String jj_ij_gyejwa_no =""; // 계좌번호
	private String jj_ij_gyejwa_no_masking =""; // 계좌번호 마스킹
	
	private String jikwonCK          = ""; //직원여부 1=임직원 2=PA
	
	// 08.09.08 어니 추가
	private String pa_name					= ""; // 선택된 PA명
	private String pa_emp_no				= ""; // 선택된 PA 사번
	private String qstnr_sel_cd				= ""; // Agent/본인 여부
	private String tmpSeqNo					= ""; // 등록 시퀀

	
	// 2008.09.19 by hsahn
	// 휴대폰 명의확인 결과 (1: 성공, -1: 실패)
	private int mphone_chk						= 0;	
	// 휴대폰 번호 변경 여부 (통합고객에 등록된 휴대폰 번호와 다른 휴대폰으로 명의 확인했는지 여부)
	private String mphone_changed_yn				= "N";
	// {2008.09.19}
	
	
	public String getJJ_INJNG() {
		return JJ_INJNG;
	}
	public void setJJ_INJNG(String jJ_INJNG) {
		JJ_INJNG = jJ_INJNG;
	}
	public String getDaechul() {
		return daechul;
	}
	public void setDaechul(String daechul) {
		this.daechul = daechul;
	}
	public String getIjanapip() {
		return ijanapip;
	}
	public void setIjanapip(String ijanapip) {
		this.ijanapip = ijanapip;
	}
	public String getJj_s_poli_no() {
		return jj_s_poli_no;
	}
	public void setJj_s_poli_no(String jj_s_poli_no) {
		this.jj_s_poli_no = jj_s_poli_no;
	}
	public String getJj_s_bank_cd() {
		return jj_s_bank_cd;
	}
	public void setJj_s_bank_cd(String jj_s_bank_cd) {
		this.jj_s_bank_cd = jj_s_bank_cd;
	}
	public String getJj_s_gyejwa_no() {
		return jj_s_gyejwa_no;
	}
	public void setJj_s_gyejwa_no(String jj_s_gyejwa_no) {
		this.jj_s_gyejwa_no = jj_s_gyejwa_no;
	}
	public String getJj_gyejwa_yn() {
		return jj_gyejwa_yn;
	}
	public void setJj_gyejwa_yn(String jj_gyejwa_yn) {
		this.jj_gyejwa_yn = jj_gyejwa_yn;
	}
	public String getJj_ij_bank_cd() {
		return jj_ij_bank_cd;
	}
	public void setJj_ij_bank_cd(String jj_ij_bank_cd) {
		this.jj_ij_bank_cd = jj_ij_bank_cd;
	}
	public String getJj_ij_gyejwa_no() {
		return jj_ij_gyejwa_no;
	}
	public void setJj_ij_gyejwa_no(String jj_ij_gyejwa_no) {
		this.jj_ij_gyejwa_no = jj_ij_gyejwa_no;
	}
	public String getJikwonCK() {
		return jikwonCK;
	}
	public void setJikwonCK(String jikwonCK) {
		this.jikwonCK = jikwonCK;
	}
	public String getPa_name() {
		return pa_name;
	}
	public void setPa_name(String pa_name) {
		this.pa_name = pa_name;
	}
	public String getPa_emp_no() {
		return pa_emp_no;
	}
	public void setPa_emp_no(String pa_emp_no) {
		this.pa_emp_no = pa_emp_no;
	}
	public String getQstnr_sel_cd() {
		return qstnr_sel_cd;
	}
	public void setQstnr_sel_cd(String qstnr_sel_cd) {
		this.qstnr_sel_cd = qstnr_sel_cd;
	}
	public String getTmpSeqNo() {
		return tmpSeqNo;
	}
	public void setTmpSeqNo(String tmpSeqNo) {
		this.tmpSeqNo = tmpSeqNo;
	}
	public int getMphone_chk() {
		return mphone_chk;
	}
	public void setMphone_chk(int mphone_chk) {
		this.mphone_chk = mphone_chk;
	}
	public String getMphone_changed_yn() {
		return mphone_changed_yn;
	}
	public void setMphone_changed_yn(String mphone_changed_yn) {
		this.mphone_changed_yn = mphone_changed_yn;
	}
	public String[] getInput_stock_seqs() {
		return input_stock_seqs;
	}
	public void setInput_stock_seqs(String[] input_stock_seqs) {
		this.input_stock_seqs = input_stock_seqs;
	}
	public String getStplt_loan_posbl_amt() {
		return stplt_loan_posbl_amt;
	}
	public void setStplt_loan_posbl_amt(String stplt_loan_posbl_amt) {
		this.stplt_loan_posbl_amt = stplt_loan_posbl_amt;
	}
	public String getJj_s_bank_nm() {
		return jj_s_bank_nm;
	}
	public void setJj_s_bank_nm(String jj_s_bank_nm) {
		this.jj_s_bank_nm = jj_s_bank_nm;
	}
	public String getJj_ij_bank_nm() {
		return jj_ij_bank_nm;
	}
	public void setJj_ij_bank_nm(String jj_ij_bank_nm) {
		this.jj_ij_bank_nm = jj_ij_bank_nm;
	}
	public String getSsnUserJumin() {
		return ssnUserJumin;
	}
	public void setSsnUserJumin(String ssnUserJumin) {
		this.ssnUserJumin = ssnUserJumin;
	}
	public String getSsnUserName() {
		return ssnUserName;
	}
	public void setSsnUserName(String ssnUserName) {
		this.ssnUserName = ssnUserName;
	}
	public String getInsub_pd_name() {
		return insub_pd_name;
	}
	public void setInsub_pd_name(String insub_pd_name) {
		this.insub_pd_name = insub_pd_name;
	}
	public String getAr_sttus_name() {
		return ar_sttus_name;
	}
	public void setAr_sttus_name(String ar_sttus_name) {
		this.ar_sttus_name = ar_sttus_name;
	}
	public long getRe_stplt_loan_resid_amt() {
		return re_stplt_loan_resid_amt;
	}
	public void setRe_stplt_loan_resid_amt(long re_stplt_loan_resid_amt) {
		this.re_stplt_loan_resid_amt = re_stplt_loan_resid_amt;
	}
	public String getInt_pay_date() {
		return int_pay_date;
	}
	public void setInt_pay_date(String int_pay_date) {
		this.int_pay_date = int_pay_date;
	}
	public String getInet_loan_posbl_yn() {
		return inet_loan_posbl_yn;
	}
	public void setInet_loan_posbl_yn(String inet_loan_posbl_yn) {
		this.inet_loan_posbl_yn = inet_loan_posbl_yn;
	}
	public long getTot() {
		return tot;
	}
	public void setTot(long tot) {
		this.tot = tot;
	}
	public String getStock_seq() {
		return stock_seq;
	}
	public void setStock_seq(String stock_seq) {
		this.stock_seq = stock_seq;
	}
	public String getInt_rate() {
		return int_rate;
	}
	public void setInt_rate(String int_rate) {
		this.int_rate = int_rate;
	}
	public String getJj_s_gyejwa_no_masking() {
		return jj_s_gyejwa_no_masking;
	}
	public void setJj_s_gyejwa_no_masking(String jj_s_gyejwa_no_masking) {
		this.jj_s_gyejwa_no_masking = jj_s_gyejwa_no_masking;
	}
	public String getJj_ij_gyejwa_no_masking() {
		return jj_ij_gyejwa_no_masking;
	}
	public void setJj_ij_gyejwa_no_masking(String jj_ij_gyejwa_no_masking) {
		this.jj_ij_gyejwa_no_masking = jj_ij_gyejwa_no_masking;
	}
	public String[] getInput_int_rate() {
		return input_int_rate;
	}
	public void setInput_int_rate(String[] input_int_rate) {
		this.input_int_rate = input_int_rate;
	}
	public String getSsnUserJumin_masking() {
		return ssnUserJumin_masking;
	}
	public void setSsnUserJumin_masking(String ssnUserJumin_masking) {
		this.ssnUserJumin_masking = ssnUserJumin_masking;
	}
	public long getTotLoan() {
		return totLoan;
	}
	public void setTotLoan(long totLoan) {
		this.totLoan = totLoan;
	}
	public long getIpgum() {
		return ipgum;
	}
	public void setIpgum(long ipgum) {
		this.ipgum = ipgum;
	}
	public long getGongje() {
		return gongje;
	}
	public void setGongje(long gongje) {
		this.gongje = gongje;
	}
	
	public String getRemit_seq() {
		return remit_seq;
	}
	public void setRemit_seq(String remit_seq) {
		this.remit_seq = remit_seq;
	}
	public String getJj_napip_ija() {
		return jj_napip_ija;
	}
	public void setJj_napip_ija(String jj_napip_ija) {
		this.jj_napip_ija = jj_napip_ija;
	}
	public String getJj_injidae() {
		return jj_injidae;
	}
	public void setJj_injidae(String jj_injidae) {
		this.jj_injidae = jj_injidae;
	}
	public String getJj_gongje_gm() {
		return jj_gongje_gm;
	}
	public void setJj_gongje_gm(String jj_gongje_gm) {
		this.jj_gongje_gm = jj_gongje_gm;
	}
	public String getJj_chagam_gm() {
		return jj_chagam_gm;
	}
	public void setJj_chagam_gm(String jj_chagam_gm) {
		this.jj_chagam_gm = jj_chagam_gm;
	}
	public String getJj_bank_jijum() {
		return jj_bank_jijum;
	}
	public void setJj_bank_jijum(String jj_bank_jijum) {
		this.jj_bank_jijum = jj_bank_jijum;
	}
	public String getHj_bank_jijum_nm() {
		return hj_bank_jijum_nm;
	}
	public void setHj_bank_jijum_nm(String hj_bank_jijum_nm) {
		this.hj_bank_jijum_nm = hj_bank_jijum_nm;
	}
	public String getHj_yegmju_nm() {
		return hj_yegmju_nm;
	}
	public void setHj_yegmju_nm(String hj_yegmju_nm) {
		this.hj_yegmju_nm = hj_yegmju_nm;
	}
	public String getJj_yegmju_tel() {
		return jj_yegmju_tel;
	}
	public void setJj_yegmju_tel(String jj_yegmju_tel) {
		this.jj_yegmju_tel = jj_yegmju_tel;
	}
	public String getJj_yunc_iyul() {
		return jj_yunc_iyul;
	}
	public void setJj_yunc_iyul(String jj_yunc_iyul) {
		this.jj_yunc_iyul = jj_yunc_iyul;
	}
	public String getJj_napip_ymd() {
		return jj_napip_ymd;
	}
	public void setJj_napip_ymd(String jj_napip_ymd) {
		this.jj_napip_ymd = jj_napip_ymd;
	}
	public String getApplydate() {
		return applydate;
	}
	public void setApplydate(String applydate) {
		this.applydate = applydate;
	}
	public String getTel_no() {
		return tel_no;
	}
	public void setTel_no(String tel_no) {
		this.tel_no = tel_no;
	}
	public String getGyejwa_hwkin() {
		return gyejwa_hwkin;
	}
	public void setGyejwa_hwkin(String gyejwa_hwkin) {
		this.gyejwa_hwkin = gyejwa_hwkin;
	}
	public String getJj_jikwon_pa() {
		return jj_jikwon_pa;
	}
	public void setJj_jikwon_pa(String jj_jikwon_pa) {
		this.jj_jikwon_pa = jj_jikwon_pa;
	}
	
	public String getIns_lcpl_dvcd() {
		return ins_lcpl_dvcd;
	}
	public void setIns_lcpl_dvcd(String ins_lcpl_dvcd) {
		this.ins_lcpl_dvcd = ins_lcpl_dvcd;
	}
	public String getPly_sqno() {
		return ply_sqno;
	}
	public void setPly_sqno(String ply_sqno) {
		this.ply_sqno = ply_sqno;
	}
	
	public String[] getInput_ins_lcpl_dvcd() {
		return input_ins_lcpl_dvcd;
	}
	public void setInput_ins_lcpl_dvcd(String[] input_ins_lcpl_dvcd) {
		this.input_ins_lcpl_dvcd = input_ins_lcpl_dvcd;
	}
	public String[] getInput_ply_sqno() {
		return input_ply_sqno;
	}
	public void setInput_ply_sqno(String[] input_ply_sqno) {
		this.input_ply_sqno = input_ply_sqno;
	}
	@Override
	public String toString() {
		return "LoInsuAppConfirmVO [ssnUserJumin=" + ssnUserJumin
				+ ", ssnUserName=" + ssnUserName + ", insub_pd_name="
				+ insub_pd_name + ", ar_sttus_name=" + ar_sttus_name
				+ ", re_stplt_loan_resid_amt=" + re_stplt_loan_resid_amt
				+ ", int_pay_date=" + int_pay_date + ", inet_loan_posbl_yn="
				+ inet_loan_posbl_yn + ", tot=" + tot + ", JJ_INJNG="
				+ JJ_INJNG + ", daechul=" + daechul + ", ijanapip=" + ijanapip
				+ ", stock_seq=" + stock_seq + ", input_stock_seqs="
				+ Arrays.toString(input_stock_seqs) + ", input_int_rate="
				+ Arrays.toString(input_int_rate) + ", ssnUserJumin_masking="
				+ ssnUserJumin_masking + ", totLoan=" + totLoan + ", ipgum="
				+ ipgum + ", gongje=" + gongje + ", remit_seq=" + remit_seq
				+ ", jj_napip_ija=" + jj_napip_ija + ", jj_injidae="
				+ jj_injidae + ", jj_gongje_gm=" + jj_gongje_gm
				+ ", jj_chagam_gm=" + jj_chagam_gm + ", jj_bank_jijum="
				+ jj_bank_jijum + ", hj_bank_jijum_nm=" + hj_bank_jijum_nm
				+ ", hj_yegmju_nm=" + hj_yegmju_nm + ", jj_yegmju_tel="
				+ jj_yegmju_tel + ", jj_yunc_iyul=" + jj_yunc_iyul
				+ ", jj_napip_ymd=" + jj_napip_ymd + ", applydate=" + applydate
				+ ", tel_no=" + tel_no + ", gyejwa_hwkin=" + gyejwa_hwkin
				+ ", jj_jikwon_pa=" + jj_jikwon_pa + ", int_rate=" + int_rate
				+ ", stplt_loan_posbl_amt=" + stplt_loan_posbl_amt
				+ ", jj_s_poli_no=" + jj_s_poli_no + ", jj_s_bank_cd="
				+ jj_s_bank_cd + ", jj_s_bank_nm=" + jj_s_bank_nm
				+ ", jj_s_gyejwa_no=" + jj_s_gyejwa_no
				+ ", jj_s_gyejwa_no_masking=" + jj_s_gyejwa_no_masking
				+ ", jj_gyejwa_yn=" + jj_gyejwa_yn + ", jj_ij_bank_cd="
				+ jj_ij_bank_cd + ", jj_ij_bank_nm=" + jj_ij_bank_nm
				+ ", jj_ij_gyejwa_no=" + jj_ij_gyejwa_no
				+ ", jj_ij_gyejwa_no_masking=" + jj_ij_gyejwa_no_masking
				+ ", jikwonCK=" + jikwonCK + ", pa_name=" + pa_name
				+ ", pa_emp_no=" + pa_emp_no + ", qstnr_sel_cd=" + qstnr_sel_cd
				+ ", tmpSeqNo=" + tmpSeqNo + ", mphone_chk=" + mphone_chk
				+ ", mphone_changed_yn=" + mphone_changed_yn
				+ ", getJJ_INJNG()=" + getJJ_INJNG() + ", getDaechul()="
				+ getDaechul() + ", getIjanapip()=" + getIjanapip()
				+ ", getJj_s_poli_no()=" + getJj_s_poli_no()
				+ ", getJj_s_bank_cd()=" + getJj_s_bank_cd()
				+ ", getJj_s_gyejwa_no()=" + getJj_s_gyejwa_no()
				+ ", getJj_gyejwa_yn()=" + getJj_gyejwa_yn()
				+ ", getJj_ij_bank_cd()=" + getJj_ij_bank_cd()
				+ ", getJj_ij_gyejwa_no()=" + getJj_ij_gyejwa_no()
				+ ", getJikwonCK()=" + getJikwonCK() + ", getPa_name()="
				+ getPa_name() + ", getPa_emp_no()=" + getPa_emp_no()
				+ ", getQstnr_sel_cd()=" + getQstnr_sel_cd()
				+ ", getTmpSeqNo()=" + getTmpSeqNo() + ", getMphone_chk()="
				+ getMphone_chk() + ", getMphone_changed_yn()="
				+ getMphone_changed_yn() + ", getInput_stock_seqs()="
				+ Arrays.toString(getInput_stock_seqs()) + ", getInput_ins_lcpl_dvcd()="
				+ Arrays.toString(getInput_ins_lcpl_dvcd()) + ", getInput_ply_sqno()="
				+ Arrays.toString(getInput_ply_sqno())
				+ ", getStplt_loan_posbl_amt()=" + getStplt_loan_posbl_amt()
				+ ", getJj_s_bank_nm()=" + getJj_s_bank_nm()
				+ ", getJj_ij_bank_nm()=" + getJj_ij_bank_nm()
				+ ", getSsnUserJumin()=" + getSsnUserJumin()
				+ ", getSsnUserName()=" + getSsnUserName()
				+ ", getInsub_pd_name()=" + getInsub_pd_name()
				+ ", getAr_sttus_name()=" + getAr_sttus_name()
				+ ", getRe_stplt_loan_resid_amt()="
				+ getRe_stplt_loan_resid_amt() + ", getInt_pay_date()="
				+ getInt_pay_date() + ", getInet_loan_posbl_yn()="
				+ getInet_loan_posbl_yn() + ", getTot()=" + getTot()
				+ ", getStock_seq()=" + getStock_seq() + ", getInt_rate()="
				+ getInt_rate() + ", getJj_s_gyejwa_no_masking()="
				+ getJj_s_gyejwa_no_masking()
				+ ", getJj_ij_gyejwa_no_masking()="
				+ getJj_ij_gyejwa_no_masking() + ", getInput_int_rate()="
				+ Arrays.toString(getInput_int_rate())
				+ ", getSsnUserJumin_masking()=" + getSsnUserJumin_masking()
				+ ", getTotLoan()=" + getTotLoan() + ", getIpgum()="
				+ getIpgum() + ", getGongje()=" + getGongje()
				+ ", getRemit_seq()=" + getRemit_seq() + ", getJj_napip_ija()="
				+ getJj_napip_ija() + ", getJj_injidae()=" + getJj_injidae()
				+ ", getJj_gongje_gm()=" + getJj_gongje_gm()
				+ ", getJj_chagam_gm()=" + getJj_chagam_gm()
				+ ", getJj_bank_jijum()=" + getJj_bank_jijum()
				+ ", getHj_bank_jijum_nm()=" + getHj_bank_jijum_nm()
				+ ", getHj_yegmju_nm()=" + getHj_yegmju_nm()
				+ ", getJj_yegmju_tel()=" + getJj_yegmju_tel()
				+ ", getJj_yunc_iyul()=" + getJj_yunc_iyul()
				+ ", getJj_napip_ymd()=" + getJj_napip_ymd()
				+ ", getApplydate()=" + getApplydate() + ", getTel_no()="
				+ getTel_no() + ", getGyejwa_hwkin()=" + getGyejwa_hwkin()
				+ ", getJj_jikwon_pa()=" + getJj_jikwon_pa() + ", getClass()="
				+ getClass() + ", hashCode()=" + hashCode() + ", toString()="
				+ super.toString() + "]";
	}
	public String getNew_s_bank_name() {
		return new_s_bank_name;
	}
	public void setNew_s_bank_name(String new_s_bank_name) {
		this.new_s_bank_name = new_s_bank_name;
	}
	public String getNew_ij_bank_name() {
		return new_ij_bank_name;
	}
	public void setNew_ij_bank_name(String new_ij_bank_name) {
		this.new_ij_bank_name = new_ij_bank_name;
	}
	
	
}
