package com.idongbu.smartcustomer.vo;

public class SubFUB2032RVO {
	public String JJ_NO					= null;
	public String JJ_POLI_NO            = null;
	public String HJ_IPCHULGM           = null;
	public String JJ_BANK_CODE          = null;
	public String HJ_BANK_NM            = null;
	public String JJ_GYEJWA_NO1         = null;
	public String HJ_YEGMJU             = null;
	public String JJ_ICHE_DD            = null;
	public String JJ_LAST_YM            = null;
	public String HJ_SANGTE_NM          = null;
	public String HJ_DECHUL_NM          = null;
	public String HJ_BOJONG_NM          = null;
	public String JJ_BOHUM_GIGAN_SYMD   = null;
	public String JJ_BOHUM_GIGAN_EYMD   = null;
	public int MAX_SEQ   ;
	
	public String getJJ_NO() {
		return JJ_NO;
	}
	public void setJJ_NO(String jJ_NO) {
		JJ_NO = jJ_NO;
	}
	public String getJJ_POLI_NO() {
		return JJ_POLI_NO;
	}
	public void setJJ_POLI_NO(String jJ_POLI_NO) {
		JJ_POLI_NO = jJ_POLI_NO;
	}
	public String getHJ_IPCHULGM() {
		return HJ_IPCHULGM;
	}
	public void setHJ_IPCHULGM(String hJ_IPCHULGM) {
		HJ_IPCHULGM = hJ_IPCHULGM;
	}
	public String getJJ_BANK_CODE() {
		return JJ_BANK_CODE;
	}
	public void setJJ_BANK_CODE(String jJ_BANK_CODE) {
		JJ_BANK_CODE = jJ_BANK_CODE;
	}
	public String getHJ_BANK_NM() {
		return HJ_BANK_NM;
	}
	public void setHJ_BANK_NM(String hJ_BANK_NM) {
		HJ_BANK_NM = hJ_BANK_NM;
	}
	public String getJJ_GYEJWA_NO1() {
		return JJ_GYEJWA_NO1;
	}
	public void setJJ_GYEJWA_NO1(String jJ_GYEJWA_NO1) {
		JJ_GYEJWA_NO1 = jJ_GYEJWA_NO1;
	}
	public String getHJ_YEGMJU() {
		return HJ_YEGMJU;
	}
	public void setHJ_YEGMJU(String hJ_YEGMJU) {
		HJ_YEGMJU = hJ_YEGMJU;
	}
	public String getJJ_ICHE_DD() {
		return JJ_ICHE_DD;
	}
	public void setJJ_ICHE_DD(String jJ_ICHE_DD) {
		JJ_ICHE_DD = jJ_ICHE_DD;
	}
	public String getJJ_LAST_YM() {
		return JJ_LAST_YM;
	}
	public void setJJ_LAST_YM(String jJ_LAST_YM) {
		JJ_LAST_YM = jJ_LAST_YM;
	}
	public String getHJ_SANGTE_NM() {
		return HJ_SANGTE_NM;
	}
	public void setHJ_SANGTE_NM(String hJ_SANGTE_NM) {
		HJ_SANGTE_NM = hJ_SANGTE_NM;
	}
	public String getHJ_DECHUL_NM() {
		return HJ_DECHUL_NM;
	}
	public void setHJ_DECHUL_NM(String hJ_DECHUL_NM) {
		HJ_DECHUL_NM = hJ_DECHUL_NM;
	}
	public String getHJ_BOJONG_NM() {
		return HJ_BOJONG_NM;
	}
	public void setHJ_BOJONG_NM(String hJ_BOJONG_NM) {
		HJ_BOJONG_NM = hJ_BOJONG_NM;
	}
	public String getJJ_BOHUM_GIGAN_SYMD() {
		return JJ_BOHUM_GIGAN_SYMD;
	}
	public void setJJ_BOHUM_GIGAN_SYMD(String jJ_BOHUM_GIGAN_SYMD) {
		JJ_BOHUM_GIGAN_SYMD = jJ_BOHUM_GIGAN_SYMD;
	}
	public String getJJ_BOHUM_GIGAN_EYMD() {
		return JJ_BOHUM_GIGAN_EYMD;
	}
	public void setJJ_BOHUM_GIGAN_EYMD(String jJ_BOHUM_GIGAN_EYMD) {
		JJ_BOHUM_GIGAN_EYMD = jJ_BOHUM_GIGAN_EYMD;
	}
	public int getMAX_SEQ() {
		return MAX_SEQ;
	}
	public void setMAX_SEQ(int mAX_SEQ) {
		MAX_SEQ = mAX_SEQ;
	}
}
