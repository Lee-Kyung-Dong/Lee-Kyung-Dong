package com.idongbu.smartcustomer.vo;

import com.idongbu.common.vo.CMMVO;

//자동차보험증권
public class CmmFQD0059RVO extends CMMVO {
	public static final String proid		= "FQD0059R";
	public static final String trid		= "QD1N";
	public String rURL						= "";

	// 입력
	public String SCR_I_POLI_NO = null;

	// 출력
	public String COMM_CHANNEL = null;
	public String COMM_UNIQUE = null;
	public String COMM_PGMID = null;
	public String COMM_PROC_GB = null;
	public String COMM_FUN_KEY = null;
	public String COMM_USER_GB = null;
	public String COMM_USER_CD = null;
	public String COMM_JIJUM_CD = null;
	public String COMM_JIBU_CD = null;
	public String COMM_PROTOCOL = null;
	public String COMM_COND_CD = null;
	public String COMM_LAST_FLAG = null;
	public String COMM_CURSOR_MAP = null;
	public String COMM_CURSOR_IDX = null;
	public String COMM_MESSAGE_CD = null;
	public String H_COMM_MESSAGE_NM = null;
	public String COMM_SYS_ERR = null;
	public String COMM_TS_ITEM = null;
	public String COMM_FORM_ID = null;
	public String COMM_PRT_GB = null;
	public String COMM_FILLER = null;
//	public String SCR_I_POLI_NO = null;
	public String H_SCR_BJ_NAME = null;
	public String H_SCR_PIBOJA_NM = null;
	public String SCR_PIBOJA_NO = null;
	public String H_SCR_GYEYAK_NM = null;
	public String SCR_GYEYAK_NO = null;
	public String SCR_GYEYAK_YYMMDD = null;
	public String SCR_S_YYMMDD = null;
	public String SCR_S_TIME = null;
	public String SCR_E_YYMMDD = null;
	public String SCR_E_TIME = null;
	public String SCR_S_YYMMDD2 = null;
	public String SCR_S_TIME2 = null;
	public String SCR_E_YYMMDD2 = null;
	public String SCR_E_TIME2 = null;
	public String H_SCR_CAR_NO = null;
	public String SCR_BEGIRYANG = null;
	public String SCR_YUNSIK = null;
	public String H_SCR_CAR_NM = null;
	public String H_SCR_CHAJONG_NM = null;
	public String SCR_CAR_GAEK = null;
	public String SCR_BUSOK_GAEK = null;
	public String[] SCR_BUSOKPUM = new String[0]; // 2
	public String SCR_CHADE_NO = null;
	public String H_SCR_DAMBO1_DATA = null;
	public String H_SCR_DAMBO2_DATA = null;
	public String H_SCR_DAMBO3_DATA = null;
	public String H_SCR_DAMBO4_NM = null;
	public String H_SCR_DAMBO4_DATA = null;
	public String H_SCR_DAMBO5_DATA = null;
	public String H_SCR_DAMBO6_DATA = null;
	public String H_SCR_TACHA_UNJEON = null;
	public String SCR_JUKYONG_PRM = null;
	public String SCR_NAPIP_PRM = null;
	public String SCR_BUNNAP_TIT1 = null;
	public String SCR_BUNNAP_YMD1 = null;
	public String SCR_BUNNAP_TIT2 = null;
	public String SCR_BUNNAP_YMD2 = null;
	public String SCR_BUNNAP_TIT3 = null;
	public String SCR_BUNNAP_YMD3 = null;
	public String SCR_BUNNAP_TIT4 = null;
	public String SCR_BUNNAP_YMD4 = null;
	public String SCR_BUNNAP_TIT5 = null;
	public String SCR_BUNNAP_YMD5 = null;
	public String SCR_BUNNAP_TIT6 = null;
	public String SCR_BUNNAP_YMD6 = null;
	public String SCR_BUNNAP_TIT7 = null;
	public String SCR_BUNNAP_YMD7 = null;
	public String SCR_BUNNAP_TIT8 = null;
	public String SCR_BUNNAP_YMD8 = null;
	public String SCR_BUNNAP_TIT9 = null;
	public String SCR_BUNNAP_YMD9 = null;
	public String SCR_BUNNAP_TIT10 = null;
	public String SCR_BUNNAP_YMD10 = null;
	public String SCR_BUNNAP_TIT11 = null;
	public String SCR_BUNNAP_YMD11 = null;
	public String[] H_SCR_TKYAK1 = new String[0]; // 10
	public String[] H_SCR_TKYAK2 = new String[0]; // 10
	public String[] H_SCR_TKYAK3 = new String[0]; // 10
	public String H_SCR_JOJIKWON_NM = null;
	public String H_SCR_DARIJUM_TEXT = null;
	public String SCR_JOJIKWON_TEL_MK1 = null;
	public String SCR_JOJIKWON_TEL = null;
	public String SCR_JOJIKWON_TEL_MK2 = null;
	public String SCR_DAEPOU_FIL2 = null;
	public String SCR_DAEPOU_FIL3 = null;
	public String SCR_DAEPOU = null;
	public String H_SCR_JIJUM_NM = null;
	public String H_SCR_JIJUM_TEXT = null;
	public String SCR_JIJUM_TEL_MK1 = null;
	public String SCR_JIJUM_TEL = null;
	public String SCR_JIJUM_TEL_MK2 = null;
	public String H_SCR_JIBU_NM = null;
	public String H_SCR_JIBU_TEXT = null;
	public String SCR_JIBU_TEL_MK1 = null;
	public String SCR_JIBU_TEL = null;
	public String SCR_JIBU_TEL_MK2 = null;
	public String SCR_BALGP_YYMMDD = null;
	public String SCR_BALGP_PLACE = null;
	public String H_SCR_GOGEK_JUSO2 = null;
	public String H_SCR_GOGEK_JUSO3 = null;
	public String H_SCR_GOGEK_JUSO1 = null;
	public String SCR_GOGEK_ZIP = null;
	public String H_SCR_UNJUN_NM = null;
	public String SCR_UNJUN_NO = null;
	public String H_SCR_BIGO_1 = null;
	public String H_SCR_SUIK_NM = null;
	public String SCR_SUIK_NO = null;
	public String SCR_ELECTRIC_GB = null;
	public String SCR_MULSAGO_GIJUN_GMEK = null;
	

}
