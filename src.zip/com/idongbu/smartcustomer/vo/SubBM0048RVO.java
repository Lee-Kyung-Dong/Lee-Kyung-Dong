package com.idongbu.smartcustomer.vo;

public class SubBM0048RVO {
	public String SO_BJ_GB      		= null;
	public String SO_BJ_CD      		= null;
	public String SO_BJ_CD_SEBU     	= null;
	public String SO_GOGEK_GB     		= null;
	public String HO_GYE_NAME     		= null;
	public String HO_PIB_NAME     		= null;
	public String SO_POLI_NO     		= null;
	public String HO_CAR_NO     		= null;
	public String HO_BJ_NM     			= null;
	public String SO_BOHUM_SYMD     	= null;
	public String SO_BOHUM_EYMD     	= null;
	public String HO_SANGTE_NM     		= null;
	public String SO_GAIP_TYPE1     	= null;
	public String SO_GAIP_TYPE2     	= null;
	public String SO_CHUNGYAK_YMD     	= null;
	public String SO_GYE_NO     		= null;
	public String SO_PIB_NO     		= null;
	public String SO_CHIGPJA_CD     	= null;
	public String HO_PA_NAME     		= null;
	public String HO_SANGHO     		= null;
	public String SO_PA_HP     			= null;
	public String SO_PA_MAIL     		= null;
	public String SO_JIJUM_CD     		= null;
	public String HO_JIJUM     			= null;
	public String SO_JIBU_CD     		= null;
	public String HO_JIBU     			= null;
	public String SO_BONBU_TEL     		= null;
	public String SO_JIJUM_TEL     		= null;
	public String SO_JIBU_TEL     		= null;
	public String SO_CHULJANG_TEL     	= null;
	public String SO_PA_TEL     		= null;
	public String SO_IPCHULGM_CD     	= null;
	public String SO_ICHE_D     		= null;
	public String SO_LAST_NAPIP_YM     	= null;
	public String SO_LAST_NAPIP_CNT     = null;
	public String SO_NAPIP_BANG_CD     	= null;
	public String HO_NAPIP_BANG_NM     	= null;
	public String SO_PLUS2_YN     		= null;
	public String getSO_BJ_GB() {
		return SO_BJ_GB;
	}
	public void setSO_BJ_GB(String sO_BJ_GB) {
		SO_BJ_GB = sO_BJ_GB;
	}
	public String getSO_BJ_CD() {
		return SO_BJ_CD;
	}
	public void setSO_BJ_CD(String sO_BJ_CD) {
		SO_BJ_CD = sO_BJ_CD;
	}
	public String getSO_BJ_CD_SEBU() {
		return SO_BJ_CD_SEBU;
	}
	public void setSO_BJ_CD_SEBU(String sO_BJ_CD_SEBU) {
		SO_BJ_CD_SEBU = sO_BJ_CD_SEBU;
	}
	public String getSO_GOGEK_GB() {
		return SO_GOGEK_GB;
	}
	public void setSO_GOGEK_GB(String sO_GOGEK_GB) {
		SO_GOGEK_GB = sO_GOGEK_GB;
	}
	public String getHO_GYE_NAME() {
		return HO_GYE_NAME;
	}
	public void setHO_GYE_NAME(String hO_GYE_NAME) {
		HO_GYE_NAME = hO_GYE_NAME;
	}
	public String getHO_PIB_NAME() {
		return HO_PIB_NAME;
	}
	public void setHO_PIB_NAME(String hO_PIB_NAME) {
		HO_PIB_NAME = hO_PIB_NAME;
	}
	public String getSO_POLI_NO() {
		return SO_POLI_NO;
	}
	public void setSO_POLI_NO(String sO_POLI_NO) {
		SO_POLI_NO = sO_POLI_NO;
	}
	public String getHO_CAR_NO() {
		return HO_CAR_NO;
	}
	public void setHO_CAR_NO(String hO_CAR_NO) {
		HO_CAR_NO = hO_CAR_NO;
	}
	public String getHO_BJ_NM() {
		return HO_BJ_NM;
	}
	public void setHO_BJ_NM(String hO_BJ_NM) {
		HO_BJ_NM = hO_BJ_NM;
	}
	public String getSO_BOHUM_SYMD() {
		return SO_BOHUM_SYMD;
	}
	public void setSO_BOHUM_SYMD(String sO_BOHUM_SYMD) {
		SO_BOHUM_SYMD = sO_BOHUM_SYMD;
	}
	public String getSO_BOHUM_EYMD() {
		return SO_BOHUM_EYMD;
	}
	public void setSO_BOHUM_EYMD(String sO_BOHUM_EYMD) {
		SO_BOHUM_EYMD = sO_BOHUM_EYMD;
	}
	public String getHO_SANGTE_NM() {
		return HO_SANGTE_NM;
	}
	public void setHO_SANGTE_NM(String hO_SANGTE_NM) {
		HO_SANGTE_NM = hO_SANGTE_NM;
	}
	public String getSO_GAIP_TYPE1() {
		return SO_GAIP_TYPE1;
	}
	public void setSO_GAIP_TYPE1(String sO_GAIP_TYPE1) {
		SO_GAIP_TYPE1 = sO_GAIP_TYPE1;
	}
	public String getSO_GAIP_TYPE2() {
		return SO_GAIP_TYPE2;
	}
	public void setSO_GAIP_TYPE2(String sO_GAIP_TYPE2) {
		SO_GAIP_TYPE2 = sO_GAIP_TYPE2;
	}
	public String getSO_CHUNGYAK_YMD() {
		return SO_CHUNGYAK_YMD;
	}
	public void setSO_CHUNGYAK_YMD(String sO_CHUNGYAK_YMD) {
		SO_CHUNGYAK_YMD = sO_CHUNGYAK_YMD;
	}
	public String getSO_GYE_NO() {
		return SO_GYE_NO;
	}
	public void setSO_GYE_NO(String sO_GYE_NO) {
		SO_GYE_NO = sO_GYE_NO;
	}
	public String getSO_PIB_NO() {
		return SO_PIB_NO;
	}
	public void setSO_PIB_NO(String sO_PIB_NO) {
		SO_PIB_NO = sO_PIB_NO;
	}
	public String getSO_CHIGPJA_CD() {
		return SO_CHIGPJA_CD;
	}
	public void setSO_CHIGPJA_CD(String sO_CHIGPJA_CD) {
		SO_CHIGPJA_CD = sO_CHIGPJA_CD;
	}
	public String getHO_PA_NAME() {
		return HO_PA_NAME;
	}
	public void setHO_PA_NAME(String hO_PA_NAME) {
		HO_PA_NAME = hO_PA_NAME;
	}
	public String getHO_SANGHO() {
		return HO_SANGHO;
	}
	public void setHO_SANGHO(String hO_SANGHO) {
		HO_SANGHO = hO_SANGHO;
	}
	public String getSO_PA_HP() {
		return SO_PA_HP;
	}
	public void setSO_PA_HP(String sO_PA_HP) {
		SO_PA_HP = sO_PA_HP;
	}
	public String getSO_PA_MAIL() {
		return SO_PA_MAIL;
	}
	public void setSO_PA_MAIL(String sO_PA_MAIL) {
		SO_PA_MAIL = sO_PA_MAIL;
	}
	public String getSO_JIJUM_CD() {
		return SO_JIJUM_CD;
	}
	public void setSO_JIJUM_CD(String sO_JIJUM_CD) {
		SO_JIJUM_CD = sO_JIJUM_CD;
	}
	public String getHO_JIJUM() {
		return HO_JIJUM;
	}
	public void setHO_JIJUM(String hO_JIJUM) {
		HO_JIJUM = hO_JIJUM;
	}
	public String getSO_JIBU_CD() {
		return SO_JIBU_CD;
	}
	public void setSO_JIBU_CD(String sO_JIBU_CD) {
		SO_JIBU_CD = sO_JIBU_CD;
	}
	public String getHO_JIBU() {
		return HO_JIBU;
	}
	public void setHO_JIBU(String hO_JIBU) {
		HO_JIBU = hO_JIBU;
	}
	public String getSO_BONBU_TEL() {
		return SO_BONBU_TEL;
	}
	public void setSO_BONBU_TEL(String sO_BONBU_TEL) {
		SO_BONBU_TEL = sO_BONBU_TEL;
	}
	public String getSO_JIJUM_TEL() {
		return SO_JIJUM_TEL;
	}
	public void setSO_JIJUM_TEL(String sO_JIJUM_TEL) {
		SO_JIJUM_TEL = sO_JIJUM_TEL;
	}
	public String getSO_JIBU_TEL() {
		return SO_JIBU_TEL;
	}
	public void setSO_JIBU_TEL(String sO_JIBU_TEL) {
		SO_JIBU_TEL = sO_JIBU_TEL;
	}
	public String getSO_CHULJANG_TEL() {
		return SO_CHULJANG_TEL;
	}
	public void setSO_CHULJANG_TEL(String sO_CHULJANG_TEL) {
		SO_CHULJANG_TEL = sO_CHULJANG_TEL;
	}
	public String getSO_PA_TEL() {
		return SO_PA_TEL;
	}
	public void setSO_PA_TEL(String sO_PA_TEL) {
		SO_PA_TEL = sO_PA_TEL;
	}
	public String getSO_IPCHULGM_CD() {
		return SO_IPCHULGM_CD;
	}
	public void setSO_IPCHULGM_CD(String sO_IPCHULGM_CD) {
		SO_IPCHULGM_CD = sO_IPCHULGM_CD;
	}
	public String getSO_ICHE_D() {
		return SO_ICHE_D;
	}
	public void setSO_ICHE_D(String sO_ICHE_D) {
		SO_ICHE_D = sO_ICHE_D;
	}
	public String getSO_LAST_NAPIP_YM() {
		return SO_LAST_NAPIP_YM;
	}
	public void setSO_LAST_NAPIP_YM(String sO_LAST_NAPIP_YM) {
		SO_LAST_NAPIP_YM = sO_LAST_NAPIP_YM;
	}
	public String getSO_LAST_NAPIP_CNT() {
		return SO_LAST_NAPIP_CNT;
	}
	public void setSO_LAST_NAPIP_CNT(String sO_LAST_NAPIP_CNT) {
		SO_LAST_NAPIP_CNT = sO_LAST_NAPIP_CNT;
	}
	public String getSO_NAPIP_BANG_CD() {
		return SO_NAPIP_BANG_CD;
	}
	public void setSO_NAPIP_BANG_CD(String sO_NAPIP_BANG_CD) {
		SO_NAPIP_BANG_CD = sO_NAPIP_BANG_CD;
	}
	public String getHO_NAPIP_BANG_NM() {
		return HO_NAPIP_BANG_NM;
	}
	public void setHO_NAPIP_BANG_NM(String hO_NAPIP_BANG_NM) {
		HO_NAPIP_BANG_NM = hO_NAPIP_BANG_NM;
	}
	public String getSO_PLUS2_YN() {
		return SO_PLUS2_YN;
	}
	public void setSO_PLUS2_YN(String sO_PLUS2_YN) {
		SO_PLUS2_YN = sO_PLUS2_YN;
	}
}
