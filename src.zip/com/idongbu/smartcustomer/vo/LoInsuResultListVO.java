package com.idongbu.smartcustomer.vo;

public class LoInsuResultListVO {
	
	private String   flag						= "";
	private boolean  timeflag					= false;
	private String   Yayak						= "";
	private String   encrypted_amount		    = "";
	private String   encrypted_note_url		    = "";
	private String   encrypted_home_url		    = "";
	private String   encrypted_oid			    = "";
	private String   m_mid					    = "";
	private String   hashdata				    = "";
	
	private int    seq_no                           =  0 ;//Sn
	private String inhab_no                         = "" ;//주민번호
	private String stock_seq                        = "" ;//증권번호
	private String stock_seq_masking        = "" ;//증권번호
	private String remit_seq                        = "" ;//송금일련번호
	private long   re_stplt_loan_resid_amt          =  0 ;//기약관대출잔액
	private String insub_pd_name                    = "" ;//보험상품명
	private long   stplt_posbl_amt                  =  0 ;//약관가능금액
	private String loan_apply_amt                   = "" ;//대출신청액
	private String int_rate                         = "" ;//이율
	private long   pay_int_amt                      =  0 ;//납입이자금액
	private String ack_text                         = "" ;//인지대내용
	private long   subtr_amt                        =  0 ;//공제금액
	private String real_remit_amt                   = "" ;//실입금액
	private String bank_cd                          = "" ;//은행코드
	private String bank_name                        = "" ;//은행명
	private String bank_bstor_cd                    = "" ;//은행지점
	private String bank_bstor_name                  = "" ;//은행지점명
	private String acc_no                           = "" ;//계좌번호
	private String dposr_name                       = "" ;//예금주명
	private String dposr_tel_no                     = "" ;//예금주전화번호
	private String return_cd                        = "" ;//리턴코드
	private String int_pay_date                     = "" ;//이자납입일자시간
	private String stplt_agree_date                 = "" ;//약관동의일시
	private String tel_no                           = "" ;//전화번호
	private String reslt_val                        = "" ;//결과값
	private String tra_dstin_cd                     = "" ;//처리구분코드
	private String acc_conf                         = "" ;//계좌확인
	private String apply_day                        = "" ;//신청월일
	private String apply_time                       = "" ;//신청시간
	private String tra_mess_text                    = "" ;//처리메세지내용
	private String authz_yn                         = "" ;//인증여부
	private String text_snd_yn                      = "" ;//문자송신여부
	private String transfer_dd                      = "" ;//이체일
	private String insub_ar_loan_rsrv_apply_yn      = "" ;//보험계약대출예약신청여부
	private String apply_name                       = "" ;//신청자명
	private String jj_ars_rc                        = "" ;//ARS전표
	private String jj_junpyo                        = "" ;//전표번호
	
	public String getFlag() {
		return flag;
	}
	public void setFlag(String flag) {
		this.flag = flag;
	}
	public boolean isTimeflag() {
		return timeflag;
	}
	public void setTimeflag(boolean timeflag) {
		this.timeflag = timeflag;
	}
	public String getYayak() {
		return Yayak;
	}
	public void setYayak(String yayak) {
		Yayak = yayak;
	}
	public String getEncrypted_amount() {
		return encrypted_amount;
	}
	public void setEncrypted_amount(String encrypted_amount) {
		this.encrypted_amount = encrypted_amount;
	}
	public String getEncrypted_note_url() {
		return encrypted_note_url;
	}
	public void setEncrypted_note_url(String encrypted_note_url) {
		this.encrypted_note_url = encrypted_note_url;
	}
	public String getEncrypted_home_url() {
		return encrypted_home_url;
	}
	public void setEncrypted_home_url(String encrypted_home_url) {
		this.encrypted_home_url = encrypted_home_url;
	}
	public String getEncrypted_oid() {
		return encrypted_oid;
	}
	public void setEncrypted_oid(String encrypted_oid) {
		this.encrypted_oid = encrypted_oid;
	}
	public String getM_mid() {
		return m_mid;
	}
	public void setM_mid(String m_mid) {
		this.m_mid = m_mid;
	}
	public String getHashdata() {
		return hashdata;
	}
	public void setHashdata(String hashdata) {
		this.hashdata = hashdata;
	}
	public int getSeq_no() {
		return seq_no;
	}
	public void setSeq_no(int seq_no) {
		this.seq_no = seq_no;
	}
	public String getInhab_no() {
		return inhab_no;
	}
	public void setInhab_no(String inhab_no) {
		this.inhab_no = inhab_no;
	}
	public String getStock_seq() {
		return stock_seq;
	}
	public void setStock_seq(String stock_seq) {
		this.stock_seq = stock_seq;
	}
	public String getRemit_seq() {
		return remit_seq;
	}
	public void setRemit_seq(String remit_seq) {
		this.remit_seq = remit_seq;
	}
	public long getRe_stplt_loan_resid_amt() {
		return re_stplt_loan_resid_amt;
	}
	public void setRe_stplt_loan_resid_amt(long re_stplt_loan_resid_amt) {
		this.re_stplt_loan_resid_amt = re_stplt_loan_resid_amt;
	}
	public String getInsub_pd_name() {
		return insub_pd_name;
	}
	public void setInsub_pd_name(String insub_pd_name) {
		this.insub_pd_name = insub_pd_name;
	}
	public long getStplt_posbl_amt() {
		return stplt_posbl_amt;
	}
	public void setStplt_posbl_amt(long stplt_posbl_amt) {
		this.stplt_posbl_amt = stplt_posbl_amt;
	}
	public String getLoan_apply_amt() {
		return loan_apply_amt;
	}
	public void setLoan_apply_amt(String loan_apply_amt) {
		this.loan_apply_amt = loan_apply_amt;
	}
	public String getInt_rate() {
		return int_rate;
	}
	public void setInt_rate(String int_rate) {
		this.int_rate = int_rate;
	}
	public long getPay_int_amt() {
		return pay_int_amt;
	}
	public void setPay_int_amt(long pay_int_amt) {
		this.pay_int_amt = pay_int_amt;
	}
	public String getAck_text() {
		return ack_text;
	}
	public void setAck_text(String ack_text) {
		this.ack_text = ack_text;
	}
	public long getSubtr_amt() {
		return subtr_amt;
	}
	public void setSubtr_amt(long subtr_amt) {
		this.subtr_amt = subtr_amt;
	}
	public String getReal_remit_amt() {
		return real_remit_amt;
	}
	public void setReal_remit_amt(String real_remit_amt) {
		this.real_remit_amt = real_remit_amt;
	}
	public String getBank_cd() {
		return bank_cd;
	}
	public void setBank_cd(String bank_cd) {
		this.bank_cd = bank_cd;
	}
	public String getBank_name() {
		return bank_name;
	}
	public void setBank_name(String bank_name) {
		this.bank_name = bank_name;
	}
	public String getBank_bstor_cd() {
		return bank_bstor_cd;
	}
	public void setBank_bstor_cd(String bank_bstor_cd) {
		this.bank_bstor_cd = bank_bstor_cd;
	}
	public String getBank_bstor_name() {
		return bank_bstor_name;
	}
	public void setBank_bstor_name(String bank_bstor_name) {
		this.bank_bstor_name = bank_bstor_name;
	}
	public String getAcc_no() {
		return acc_no;
	}
	public void setAcc_no(String acc_no) {
		this.acc_no = acc_no;
	}
	public String getDposr_name() {
		return dposr_name;
	}
	public void setDposr_name(String dposr_name) {
		this.dposr_name = dposr_name;
	}
	public String getDposr_tel_no() {
		return dposr_tel_no;
	}
	public void setDposr_tel_no(String dposr_tel_no) {
		this.dposr_tel_no = dposr_tel_no;
	}
	public String getReturn_cd() {
		return return_cd;
	}
	public void setReturn_cd(String return_cd) {
		this.return_cd = return_cd;
	}
	public String getInt_pay_date() {
		return int_pay_date;
	}
	public void setInt_pay_date(String int_pay_date) {
		this.int_pay_date = int_pay_date;
	}
	public String getStplt_agree_date() {
		return stplt_agree_date;
	}
	public void setStplt_agree_date(String stplt_agree_date) {
		this.stplt_agree_date = stplt_agree_date;
	}
	public String getTel_no() {
		return tel_no;
	}
	public void setTel_no(String tel_no) {
		this.tel_no = tel_no;
	}
	public String getReslt_val() {
		return reslt_val;
	}
	public void setReslt_val(String reslt_val) {
		this.reslt_val = reslt_val;
	}
	public String getTra_dstin_cd() {
		return tra_dstin_cd;
	}
	public void setTra_dstin_cd(String tra_dstin_cd) {
		this.tra_dstin_cd = tra_dstin_cd;
	}
	public String getAcc_conf() {
		return acc_conf;
	}
	public void setAcc_conf(String acc_conf) {
		this.acc_conf = acc_conf;
	}
	public String getApply_day() {
		return apply_day;
	}
	public void setApply_day(String apply_day) {
		this.apply_day = apply_day;
	}
	public String getApply_time() {
		return apply_time;
	}
	public void setApply_time(String apply_time) {
		this.apply_time = apply_time;
	}
	public String getTra_mess_text() {
		return tra_mess_text;
	}
	public void setTra_mess_text(String tra_mess_text) {
		this.tra_mess_text = tra_mess_text;
	}
	public String getAuthz_yn() {
		return authz_yn;
	}
	public void setAuthz_yn(String authz_yn) {
		this.authz_yn = authz_yn;
	}
	public String getText_snd_yn() {
		return text_snd_yn;
	}
	public void setText_snd_yn(String text_snd_yn) {
		this.text_snd_yn = text_snd_yn;
	}
	public String getTransfer_dd() {
		return transfer_dd;
	}
	public void setTransfer_dd(String transfer_dd) {
		this.transfer_dd = transfer_dd;
	}
	public String getInsub_ar_loan_rsrv_apply_yn() {
		return insub_ar_loan_rsrv_apply_yn;
	}
	public void setInsub_ar_loan_rsrv_apply_yn(String insub_ar_loan_rsrv_apply_yn) {
		this.insub_ar_loan_rsrv_apply_yn = insub_ar_loan_rsrv_apply_yn;
	}
	public String getApply_name() {
		return apply_name;
	}
	public void setApply_name(String apply_name) {
		this.apply_name = apply_name;
	}
	public String getJj_ars_rc() {
		return jj_ars_rc;
	}
	public void setJj_ars_rc(String jj_ars_rc) {
		this.jj_ars_rc = jj_ars_rc;
	}
	public String getJj_junpyo() {
		return jj_junpyo;
	}
	public void setJj_junpyo(String jj_junpyo) {
		this.jj_junpyo = jj_junpyo;
	}
	public String getStock_seq_masking() {
		return stock_seq_masking;
	}
	public void setStock_seq_masking(String stock_seq_masking) {
		this.stock_seq_masking = stock_seq_masking;
	}
	
	
}
