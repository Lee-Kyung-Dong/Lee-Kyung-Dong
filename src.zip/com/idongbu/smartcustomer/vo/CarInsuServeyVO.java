package com.idongbu.smartcustomer.vo;

public class CarInsuServeyVO {
	
	private long SV_SEQ = 0;		// 시퀀스넘버
	private String SAGO_SEQ; 		// 사고접수번호
	private String ANSWER1 = null;  
	private String ANSWER2 = null; 
	private String ANSWER3 = null; 
	private String ANSWER4 = null; 
	private String ANSWER5 = null; 
	private String ANSWER6 = null; 
	private String ANSWER7 = null; 
	private String ANSWER8 = null; 
	private String ANSWER9 = null; 
	private String ANSWER10 = null; 
	private String REG_NM = null;	// 참여자명
	
	public long getSV_SEQ() {
		return SV_SEQ;
	}
	public void setSV_SEQ(long sV_SEQ) {
		SV_SEQ = sV_SEQ;
	}
	public String getSAGO_SEQ() {
		return SAGO_SEQ;
	}
	public void setSAGO_SEQ(String sAGO_SEQ) {
		SAGO_SEQ = sAGO_SEQ;
	}
	public String getANSWER1() {
		return ANSWER1;
	}
	public void setANSWER1(String aNSWER1) {
		ANSWER1 = aNSWER1;
	}
	public String getANSWER2() {
		return ANSWER2;
	}
	public void setANSWER2(String aNSWER2) {
		ANSWER2 = aNSWER2;
	}
	public String getANSWER3() {
		return ANSWER3;
	}
	public void setANSWER3(String aNSWER3) {
		ANSWER3 = aNSWER3;
	}
	public String getANSWER4() {
		return ANSWER4;
	}
	public void setANSWER4(String aNSWER4) {
		ANSWER4 = aNSWER4;
	}
	public String getANSWER5() {
		return ANSWER5;
	}
	public void setANSWER5(String aNSWER5) {
		ANSWER5 = aNSWER5;
	}
	public String getANSWER6() {
		return ANSWER6;
	}
	public void setANSWER6(String aNSWER6) {
		ANSWER6 = aNSWER6;
	}
	public String getANSWER7() {
		return ANSWER7;
	}
	public void setANSWER7(String aNSWER7) {
		ANSWER7 = aNSWER7;
	}
	public String getANSWER8() {
		return ANSWER8;
	}
	public void setANSWER8(String aNSWER8) {
		ANSWER8 = aNSWER8;
	}
	public String getANSWER9() {
		return ANSWER9;
	}
	public void setANSWER9(String aNSWER9) {
		ANSWER9 = aNSWER9;
	}
	public String getANSWER10() {
		return ANSWER10;
	}
	public void setANSWER10(String aNSWER10) {
		ANSWER10 = aNSWER10;
	}
	public String getREG_NM() {
		return REG_NM;
	}
	public void setREG_NM(String rEG_NM) {
		REG_NM = rEG_NM;
	}		
}
