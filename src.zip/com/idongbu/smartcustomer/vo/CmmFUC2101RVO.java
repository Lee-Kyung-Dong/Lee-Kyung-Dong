package com.idongbu.smartcustomer.vo;

import java.util.List;
import java.util.Map;

import com.idongbu.common.vo.CMMVO;



public class CmmFUC2101RVO extends CMMVO {
	
	public CmmFUC2101RVO() {
		super.setPGMID(proid);
		super.setTRID(trid);
	}
	
	private final static String proid		= "FUC2101R";
	private final static String trid		= "UCL1";
	private String rURL						= "";

	private String CC_CHANNEL		= null;
	private String CC_UKEY		= null;
	private String CC_PGMID		= null;
	private String CC_PROC_GB		= null;
	private String CC_FUN_KEY		= null;
	private String CC_USER_GB		= null;
	private String CC_USER_CD		= null;
	private String CC_JIJUM_CD		= null;
	private String CC_JIBU_CD		= null;
	private String CC_PROTOCOL		= null;
	private String CC_COND_CD		= null;
	private String CC_LAST_FLAG		= null;
	private String CC_CURSOR_MAP		= null;
	private String CC_CURSOR_IDX		= null;
	private String CC_MESSAGE_CD		= null;
	private String HC_MESSAGE_NM		= null;
	private String CC_SYS_ERR		= null;
	private String CC_FILLER		= null;
	private String JJ_JUMIN_NO		= null;
	private String HJ_WOOSU_GOGEK		= null;
	private String JJ_DECHUL_T_KUM		= null;
	private String JJ_HEJI_T_KUM		= null;
	private String JJ_GANUNG_T_KUM		= null;
	private String UUC_INQ_JUMI_NO		= null;
	private String UUC_INQ_POLI_NO		= null;
	private String UUC_F_JUMIN_NO		= null;
	private String UUC_F_POLI_NO		= null;
	private String UUC_L_JUMIN_NO		= null;
	private String UUC_L_POLI_NO		= null;
	
	private List<Map<String,Object>> loopData = null;	//2차때 []형태 vo을 list에 담음
	
	public String getrURL() {
		return rURL;
	}
	public void setrURL(String rURL) {
		this.rURL = rURL;
	}
	public String getCC_CHANNEL() {
		return CC_CHANNEL;
	}
	public void setCC_CHANNEL(String cC_CHANNEL) {
		CC_CHANNEL = cC_CHANNEL;
	}
	public String getCC_UKEY() {
		return CC_UKEY;
	}
	public void setCC_UKEY(String cC_UKEY) {
		CC_UKEY = cC_UKEY;
	}
	public String getCC_PGMID() {
		return CC_PGMID;
	}
	public void setCC_PGMID(String cC_PGMID) {
		CC_PGMID = cC_PGMID;
	}
	public String getCC_PROC_GB() {
		return CC_PROC_GB;
	}
	public void setCC_PROC_GB(String cC_PROC_GB) {
		CC_PROC_GB = cC_PROC_GB;
	}
	public String getCC_FUN_KEY() {
		return CC_FUN_KEY;
	}
	public void setCC_FUN_KEY(String cC_FUN_KEY) {
		CC_FUN_KEY = cC_FUN_KEY;
	}
	public String getCC_USER_GB() {
		return CC_USER_GB;
	}
	public void setCC_USER_GB(String cC_USER_GB) {
		CC_USER_GB = cC_USER_GB;
	}
	public String getCC_USER_CD() {
		return CC_USER_CD;
	}
	public void setCC_USER_CD(String cC_USER_CD) {
		CC_USER_CD = cC_USER_CD;
	}
	public String getCC_JIJUM_CD() {
		return CC_JIJUM_CD;
	}
	public void setCC_JIJUM_CD(String cC_JIJUM_CD) {
		CC_JIJUM_CD = cC_JIJUM_CD;
	}
	public String getCC_JIBU_CD() {
		return CC_JIBU_CD;
	}
	public void setCC_JIBU_CD(String cC_JIBU_CD) {
		CC_JIBU_CD = cC_JIBU_CD;
	}
	public String getCC_PROTOCOL() {
		return CC_PROTOCOL;
	}
	public void setCC_PROTOCOL(String cC_PROTOCOL) {
		CC_PROTOCOL = cC_PROTOCOL;
	}
	public String getCC_COND_CD() {
		return CC_COND_CD;
	}
	public void setCC_COND_CD(String cC_COND_CD) {
		CC_COND_CD = cC_COND_CD;
	}
	public String getCC_LAST_FLAG() {
		return CC_LAST_FLAG;
	}
	public void setCC_LAST_FLAG(String cC_LAST_FLAG) {
		CC_LAST_FLAG = cC_LAST_FLAG;
	}
	public String getCC_CURSOR_MAP() {
		return CC_CURSOR_MAP;
	}
	public void setCC_CURSOR_MAP(String cC_CURSOR_MAP) {
		CC_CURSOR_MAP = cC_CURSOR_MAP;
	}
	public String getCC_CURSOR_IDX() {
		return CC_CURSOR_IDX;
	}
	public void setCC_CURSOR_IDX(String cC_CURSOR_IDX) {
		CC_CURSOR_IDX = cC_CURSOR_IDX;
	}
	public String getCC_MESSAGE_CD() {
		return CC_MESSAGE_CD;
	}
	public void setCC_MESSAGE_CD(String cC_MESSAGE_CD) {
		CC_MESSAGE_CD = cC_MESSAGE_CD;
	}
	public String getHC_MESSAGE_NM() {
		return HC_MESSAGE_NM;
	}
	public void setHC_MESSAGE_NM(String hC_MESSAGE_NM) {
		HC_MESSAGE_NM = hC_MESSAGE_NM;
	}
	public String getCC_SYS_ERR() {
		return CC_SYS_ERR;
	}
	public void setCC_SYS_ERR(String cC_SYS_ERR) {
		CC_SYS_ERR = cC_SYS_ERR;
	}
	public String getCC_FILLER() {
		return CC_FILLER;
	}
	public void setCC_FILLER(String cC_FILLER) {
		CC_FILLER = cC_FILLER;
	}
	public String getJJ_JUMIN_NO() {
		return JJ_JUMIN_NO;
	}
	public void setJJ_JUMIN_NO(String jJ_JUMIN_NO) {
		JJ_JUMIN_NO = jJ_JUMIN_NO;
	}
	public String getHJ_WOOSU_GOGEK() {
		return HJ_WOOSU_GOGEK;
	}
	public void setHJ_WOOSU_GOGEK(String hJ_WOOSU_GOGEK) {
		HJ_WOOSU_GOGEK = hJ_WOOSU_GOGEK;
	}
	public String getJJ_DECHUL_T_KUM() {
		return JJ_DECHUL_T_KUM;
	}
	public void setJJ_DECHUL_T_KUM(String jJ_DECHUL_T_KUM) {
		JJ_DECHUL_T_KUM = jJ_DECHUL_T_KUM;
	}
	public String getJJ_HEJI_T_KUM() {
		return JJ_HEJI_T_KUM;
	}
	public void setJJ_HEJI_T_KUM(String jJ_HEJI_T_KUM) {
		JJ_HEJI_T_KUM = jJ_HEJI_T_KUM;
	}
	public String getJJ_GANUNG_T_KUM() {
		return JJ_GANUNG_T_KUM;
	}
	public void setJJ_GANUNG_T_KUM(String jJ_GANUNG_T_KUM) {
		JJ_GANUNG_T_KUM = jJ_GANUNG_T_KUM;
	}
	public String getUUC_INQ_JUMI_NO() {
		return UUC_INQ_JUMI_NO;
	}
	public void setUUC_INQ_JUMI_NO(String uUC_INQ_JUMI_NO) {
		UUC_INQ_JUMI_NO = uUC_INQ_JUMI_NO;
	}
	public String getUUC_INQ_POLI_NO() {
		return UUC_INQ_POLI_NO;
	}
	public void setUUC_INQ_POLI_NO(String uUC_INQ_POLI_NO) {
		UUC_INQ_POLI_NO = uUC_INQ_POLI_NO;
	}
	public String getUUC_F_JUMIN_NO() {
		return UUC_F_JUMIN_NO;
	}
	public void setUUC_F_JUMIN_NO(String uUC_F_JUMIN_NO) {
		UUC_F_JUMIN_NO = uUC_F_JUMIN_NO;
	}
	public String getUUC_F_POLI_NO() {
		return UUC_F_POLI_NO;
	}
	public void setUUC_F_POLI_NO(String uUC_F_POLI_NO) {
		UUC_F_POLI_NO = uUC_F_POLI_NO;
	}
	public String getUUC_L_JUMIN_NO() {
		return UUC_L_JUMIN_NO;
	}
	public void setUUC_L_JUMIN_NO(String uUC_L_JUMIN_NO) {
		UUC_L_JUMIN_NO = uUC_L_JUMIN_NO;
	}
	public String getUUC_L_POLI_NO() {
		return UUC_L_POLI_NO;
	}
	public void setUUC_L_POLI_NO(String uUC_L_POLI_NO) {
		UUC_L_POLI_NO = uUC_L_POLI_NO;
	}
	public String getProid() {
		return proid;
	}
	public String getTrid() {
		return trid;
	}
	public List<Map<String, Object>> getLoopData() {
		return loopData;
	}
	public void setLoopData(List<Map<String, Object>> loopData) {
		this.loopData = loopData;
	}
	
//	private String[] JJ_POLI_NO		= new String[0]; // 7
//	private String[] HJ_GYEYAK_NM		= new String[0]; // 7
//	private String[] JJ_BOHUM_EYMD		= new String[0]; // 7
//	private String[] HJ_SANGTE_NM		= new String[0]; // 7
//	private String[] JJ_IYUL		= new String[0]; // 7
//	private String[] JJ_CHUGPJA_CD		= new String[0]; // 7
//	private String[] HJ_JILGWUN		= new String[0]; // 7
//	private String[] HJ_SUNAP_NM		= new String[0]; // 7
//	private String[] HJ_ICHE_NM		= new String[0]; // 7
//	private String[] JJ_DECHUL_KUM		= new String[0]; // 7
//	private String[] JJ_LAST_YMD		= new String[0]; // 7
//	private String[] JJ_HEJI_KUM		= new String[0]; // 7
//	private String[] JJ_GANUNG_KUM		= new String[0]; // 7
//	private String[] HJ_BJ_NAME		= new String[0]; // 7


}
