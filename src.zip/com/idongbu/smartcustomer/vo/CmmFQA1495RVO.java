package com.idongbu.smartcustomer.vo;

import java.util.List;
import java.util.Map;

import com.idongbu.common.vo.CMMVO;


public class CmmFQA1495RVO extends CMMVO {

	public CmmFQA1495RVO() {
		super.setPGMID(this.proid);
		super.setTRID(this.trid);
	}

	// 계약조회
	private static final String proid		= "FQA1495R";
	private static final String trid		= "QAFP";
	private String rURL						= "";

	private String COMM_CHANNEL							= null;
	private String COMM_UNIQUE								= null;
	private String COMM_PGMID								= null;
	private String COMM_PROC_GB							= null;
	private String COMM_FUN_KEY							= null;
	private String COMM_USER_GB							= null;
	private String COMM_USER_CD							= null;
	private String COMM_JIJUM_CD							= null;
	private String COMM_JIBU_CD								= null;
	private String COMM_PROTOCOL						= null;
	private String COMM_COND_CD							= null;
	private String COMM_LAST_FLAG							= null;
	private String COMM_CURSOR_MAP					= null;
	private String COMM_CURSOR_IDX						= null;
	private String COMM_MESSAGE_CD					= null;
	private String H_COMM_MESSAGE_NM				= null;
	private String COMM_SYS_ERR							= null;
	private String COMM_FILLER								= null;
	private String H_SCR_MOKJUK_CD						= null;
	private String SCR_PIB_GYE_NO_GB					= null;
	private String SCR_GOGEK_NO_GB						= null;
	private String SCR_GOGEK_NO							= null;
	private String SCR_BOHUMJA_CD						= null;
	private String SCR_POLI_NO								= null;
	private String SCR_PIB_GYE_NM_GB					= null;
	private String H_SCR_GOGEK_NAME					= null;
	private String SCR_DANGSA_GB							= null;
	private String SCR_GAEIN_GB								= null;
	private String SCR_SIDO_GB								= null;
	private String SCR_CHUL_SYMD							= null;
	private String SCR_CHUL_EYMD							= null;
	private String SCR_JOJIKWON_CD						= null;
	private String H_SCR_JOJIKWON_NM					= null;
	private String SCR_YUNGSU_JONGRYU_CD			= null;
	private String SCR_YUNGSUJNG_NO					= null;
	private String SCR_CHADE_NO_GB						= null;
	private String SCR_CHADE_NO								= null;
	private String SCR_GIJUN_YMD							= null;
	private String SCR_UPMU_GB								= null;
	private String SCR_HP_N01									= null;
	private String SCR_HP_N02									= null;
	private String SCR_HP_N03									= null;
	private String SCR_JUMIN_NO								= null;
	private String SCR_GUBUN									= null;

	private List<Map<String,Object>> SCR_OUT_DATA = null;

	//private String[] SCR_OC_SELECT_GB					= new String[0]; // 6
	//private String[] H_SCR_OC_P_GOGEK_NAME		= new String[0]; // 6
	//private String[] SCR_OC_P_GOGEK_NO				= new String[0]; // 6
	//private String[] H_SCR_OC_MOKJUK_CD				= new String[0]; // 6
	//private String[] H_SCR_OC_CHAJONG_CD			= new String[0]; // 6
	//private String[] SCR_OC_GIGAN_SYMD				= new String[0]; // 6
	//private String[] SCR_OC_GIGAN_EYMD				= new String[0]; // 6
	//private String[] H_SCR_OC_BJ_CD						= new String[0]; // 6
	//private String[] SCR_OC_BOHUMJA_CD				= new String[0]; // 6
	//private String[] SCR_OC_POLI_NO						= new String[0]; // 6
	//private String[] H_SCR_OC_BESU_GB					= new String[0]; // 6
	//private String[] H_SCR_OC_SAGO_GB				= new String[0]; // 6
	//private String[] H_SCR_OC_BOHUMJA_CD			= new String[0]; // 6
	//private String[] H_SCR_OC_JIJUM_CD					= new String[0]; // 6
	//private String[] SCR_OC_GYUNGRUK_YUL			= new String[0]; // 6
	//private String[] SCR_OC_PYOJUN_YUL				= new String[0]; // 6
	//private String[] SCR_OC_PYOJUN_DUNGGUP		= new String[0]; // 6
	//private String[] SCR_OC_BUNGI_GOGEK_NO		= new String[0]; // 6
	//private String[] SCR_OC_BUNGI_BJ_CD				= new String[0]; // 6
	//private String[] SCR_OC_BUNGI_GWAN_CD		= new String[0]; // 6
	//private String[] SCR_OC_BUNGI_MOKJUK_CD		= new String[0]; // 6
	//private String[] SCR_OC_BUNGI_CHIGP_GB		= new String[0]; // 6
	private String SCR_BRIGHT_MAP							= null;
	private String SCR_BRIGHT_POS							= null;
	private String SCR_BRIGHT_FOS							= null;
	//private String[] SCR_BRIGHT_NAME					= new String[0]; // 20
	private String USER_GIJUN_YMD							= null;
	private String USER_MOKJUK_CD							= null;
	private String USER_GOGEK_NO							= null;
	private String USER_BOHUMJA_CD						= null;
	private String USER_POLI_NO								= null;
	private String USER_BOHUM_GIGAN_SYMD			= null;
	private String USER_GOGEK_NM_YMD1				= null;
	private String USER_GOGEK_NM_YMD2				= null;
	private String USER_F_BOHUMJA_CD					= null;
	private String USER_F_POLI_NO							= null;
	private String USER_F_BOHUM_GIGAN_SYMD		= null;
	private String USER_F_GOGEK_NM_YMD1			= null;
	private String USER_F_GOGEK_NM_YMD2			= null;
	private String USER_L_BOHUMJA_CD					= null;
	private String USER_L_POLI_NO							= null;
	private String USER_L_BOHUM_GIGAN_SYMD		= null;
	private String USER_L_GOGEK_NM_YMD1			= null;
	private String USER_L_GOGEK_NM_YMD2			= null;
	private String USER_CURSOR_GB						= null;
	private String USER_GOGEK_NM_GB					= null;

	private String User_count = "0";
	
	//08.10.15 전문추가 Uny
	private String H_SCR_OC_G_GOGEK_NAME			= null;			//계약자명
	private String SCR_OC_G_GOGEK_NO					= null;			//계약자코드(관리번호)
	
	public String getrURL() {
		return rURL;
	}
	public void setrURL(String rURL) {
		this.rURL = rURL;
	}
	public String getCOMM_CHANNEL() {
		return COMM_CHANNEL;
	}
	public void setCOMM_CHANNEL(String cOMM_CHANNEL) {
		COMM_CHANNEL = cOMM_CHANNEL;
	}
	public String getCOMM_UNIQUE() {
		return COMM_UNIQUE;
	}
	public void setCOMM_UNIQUE(String cOMM_UNIQUE) {
		COMM_UNIQUE = cOMM_UNIQUE;
	}
	public String getCOMM_PGMID() {
		return COMM_PGMID;
	}
	public void setCOMM_PGMID(String cOMM_PGMID) {
		COMM_PGMID = cOMM_PGMID;
	}
	public String getCOMM_PROC_GB() {
		return COMM_PROC_GB;
	}
	public void setCOMM_PROC_GB(String cOMM_PROC_GB) {
		COMM_PROC_GB = cOMM_PROC_GB;
	}
	public String getCOMM_FUN_KEY() {
		return COMM_FUN_KEY;
	}
	public void setCOMM_FUN_KEY(String cOMM_FUN_KEY) {
		COMM_FUN_KEY = cOMM_FUN_KEY;
	}
	public String getCOMM_USER_GB() {
		return COMM_USER_GB;
	}
	public void setCOMM_USER_GB(String cOMM_USER_GB) {
		COMM_USER_GB = cOMM_USER_GB;
	}
	public String getCOMM_USER_CD() {
		return COMM_USER_CD;
	}
	public void setCOMM_USER_CD(String cOMM_USER_CD) {
		COMM_USER_CD = cOMM_USER_CD;
	}
	public String getCOMM_JIJUM_CD() {
		return COMM_JIJUM_CD;
	}
	public void setCOMM_JIJUM_CD(String cOMM_JIJUM_CD) {
		COMM_JIJUM_CD = cOMM_JIJUM_CD;
	}
	public String getCOMM_JIBU_CD() {
		return COMM_JIBU_CD;
	}
	public void setCOMM_JIBU_CD(String cOMM_JIBU_CD) {
		COMM_JIBU_CD = cOMM_JIBU_CD;
	}
	public String getCOMM_PROTOCOL() {
		return COMM_PROTOCOL;
	}
	public void setCOMM_PROTOCOL(String cOMM_PROTOCOL) {
		COMM_PROTOCOL = cOMM_PROTOCOL;
	}
	public String getCOMM_COND_CD() {
		return COMM_COND_CD;
	}
	public void setCOMM_COND_CD(String cOMM_COND_CD) {
		COMM_COND_CD = cOMM_COND_CD;
	}
	public String getCOMM_LAST_FLAG() {
		return COMM_LAST_FLAG;
	}
	public void setCOMM_LAST_FLAG(String cOMM_LAST_FLAG) {
		COMM_LAST_FLAG = cOMM_LAST_FLAG;
	}
	public String getCOMM_CURSOR_MAP() {
		return COMM_CURSOR_MAP;
	}
	public void setCOMM_CURSOR_MAP(String cOMM_CURSOR_MAP) {
		COMM_CURSOR_MAP = cOMM_CURSOR_MAP;
	}
	public String getCOMM_CURSOR_IDX() {
		return COMM_CURSOR_IDX;
	}
	public void setCOMM_CURSOR_IDX(String cOMM_CURSOR_IDX) {
		COMM_CURSOR_IDX = cOMM_CURSOR_IDX;
	}
	public String getCOMM_MESSAGE_CD() {
		return COMM_MESSAGE_CD;
	}
	public void setCOMM_MESSAGE_CD(String cOMM_MESSAGE_CD) {
		COMM_MESSAGE_CD = cOMM_MESSAGE_CD;
	}
	public String getH_COMM_MESSAGE_NM() {
		return H_COMM_MESSAGE_NM;
	}
	public void setH_COMM_MESSAGE_NM(String h_COMM_MESSAGE_NM) {
		H_COMM_MESSAGE_NM = h_COMM_MESSAGE_NM;
	}
	public String getCOMM_SYS_ERR() {
		return COMM_SYS_ERR;
	}
	public void setCOMM_SYS_ERR(String cOMM_SYS_ERR) {
		COMM_SYS_ERR = cOMM_SYS_ERR;
	}
	public String getCOMM_FILLER() {
		return COMM_FILLER;
	}
	public void setCOMM_FILLER(String cOMM_FILLER) {
		COMM_FILLER = cOMM_FILLER;
	}
	public String getH_SCR_MOKJUK_CD() {
		return H_SCR_MOKJUK_CD;
	}
	public void setH_SCR_MOKJUK_CD(String h_SCR_MOKJUK_CD) {
		H_SCR_MOKJUK_CD = h_SCR_MOKJUK_CD;
	}
	public String getSCR_PIB_GYE_NO_GB() {
		return SCR_PIB_GYE_NO_GB;
	}
	public void setSCR_PIB_GYE_NO_GB(String sCR_PIB_GYE_NO_GB) {
		SCR_PIB_GYE_NO_GB = sCR_PIB_GYE_NO_GB;
	}
	public String getSCR_GOGEK_NO_GB() {
		return SCR_GOGEK_NO_GB;
	}
	public void setSCR_GOGEK_NO_GB(String sCR_GOGEK_NO_GB) {
		SCR_GOGEK_NO_GB = sCR_GOGEK_NO_GB;
	}
	public String getSCR_GOGEK_NO() {
		return SCR_GOGEK_NO;
	}
	public void setSCR_GOGEK_NO(String sCR_GOGEK_NO) {
		SCR_GOGEK_NO = sCR_GOGEK_NO;
	}
	public String getSCR_BOHUMJA_CD() {
		return SCR_BOHUMJA_CD;
	}
	public void setSCR_BOHUMJA_CD(String sCR_BOHUMJA_CD) {
		SCR_BOHUMJA_CD = sCR_BOHUMJA_CD;
	}
	public String getSCR_POLI_NO() {
		return SCR_POLI_NO;
	}
	public void setSCR_POLI_NO(String sCR_POLI_NO) {
		SCR_POLI_NO = sCR_POLI_NO;
	}
	public String getSCR_PIB_GYE_NM_GB() {
		return SCR_PIB_GYE_NM_GB;
	}
	public void setSCR_PIB_GYE_NM_GB(String sCR_PIB_GYE_NM_GB) {
		SCR_PIB_GYE_NM_GB = sCR_PIB_GYE_NM_GB;
	}
	public String getH_SCR_GOGEK_NAME() {
		return H_SCR_GOGEK_NAME;
	}
	public void setH_SCR_GOGEK_NAME(String h_SCR_GOGEK_NAME) {
		H_SCR_GOGEK_NAME = h_SCR_GOGEK_NAME;
	}
	public String getSCR_DANGSA_GB() {
		return SCR_DANGSA_GB;
	}
	public void setSCR_DANGSA_GB(String sCR_DANGSA_GB) {
		SCR_DANGSA_GB = sCR_DANGSA_GB;
	}
	public String getSCR_GAEIN_GB() {
		return SCR_GAEIN_GB;
	}
	public void setSCR_GAEIN_GB(String sCR_GAEIN_GB) {
		SCR_GAEIN_GB = sCR_GAEIN_GB;
	}
	public String getSCR_SIDO_GB() {
		return SCR_SIDO_GB;
	}
	public void setSCR_SIDO_GB(String sCR_SIDO_GB) {
		SCR_SIDO_GB = sCR_SIDO_GB;
	}
	public String getSCR_CHUL_SYMD() {
		return SCR_CHUL_SYMD;
	}
	public void setSCR_CHUL_SYMD(String sCR_CHUL_SYMD) {
		SCR_CHUL_SYMD = sCR_CHUL_SYMD;
	}
	public String getSCR_CHUL_EYMD() {
		return SCR_CHUL_EYMD;
	}
	public void setSCR_CHUL_EYMD(String sCR_CHUL_EYMD) {
		SCR_CHUL_EYMD = sCR_CHUL_EYMD;
	}
	public String getSCR_JOJIKWON_CD() {
		return SCR_JOJIKWON_CD;
	}
	public void setSCR_JOJIKWON_CD(String sCR_JOJIKWON_CD) {
		SCR_JOJIKWON_CD = sCR_JOJIKWON_CD;
	}
	public String getH_SCR_JOJIKWON_NM() {
		return H_SCR_JOJIKWON_NM;
	}
	public void setH_SCR_JOJIKWON_NM(String h_SCR_JOJIKWON_NM) {
		H_SCR_JOJIKWON_NM = h_SCR_JOJIKWON_NM;
	}
	public String getSCR_YUNGSU_JONGRYU_CD() {
		return SCR_YUNGSU_JONGRYU_CD;
	}
	public void setSCR_YUNGSU_JONGRYU_CD(String sCR_YUNGSU_JONGRYU_CD) {
		SCR_YUNGSU_JONGRYU_CD = sCR_YUNGSU_JONGRYU_CD;
	}
	public String getSCR_YUNGSUJNG_NO() {
		return SCR_YUNGSUJNG_NO;
	}
	public void setSCR_YUNGSUJNG_NO(String sCR_YUNGSUJNG_NO) {
		SCR_YUNGSUJNG_NO = sCR_YUNGSUJNG_NO;
	}
	public String getSCR_CHADE_NO_GB() {
		return SCR_CHADE_NO_GB;
	}
	public void setSCR_CHADE_NO_GB(String sCR_CHADE_NO_GB) {
		SCR_CHADE_NO_GB = sCR_CHADE_NO_GB;
	}
	public String getSCR_CHADE_NO() {
		return SCR_CHADE_NO;
	}
	public void setSCR_CHADE_NO(String sCR_CHADE_NO) {
		SCR_CHADE_NO = sCR_CHADE_NO;
	}
	public String getSCR_GIJUN_YMD() {
		return SCR_GIJUN_YMD;
	}
	public void setSCR_GIJUN_YMD(String sCR_GIJUN_YMD) {
		SCR_GIJUN_YMD = sCR_GIJUN_YMD;
	}
	public String getSCR_UPMU_GB() {
		return SCR_UPMU_GB;
	}
	public void setSCR_UPMU_GB(String sCR_UPMU_GB) {
		SCR_UPMU_GB = sCR_UPMU_GB;
	}
	public String getSCR_HP_N01() {
		return SCR_HP_N01;
	}
	public void setSCR_HP_N01(String sCR_HP_N01) {
		SCR_HP_N01 = sCR_HP_N01;
	}
	public String getSCR_HP_N02() {
		return SCR_HP_N02;
	}
	public void setSCR_HP_N02(String sCR_HP_N02) {
		SCR_HP_N02 = sCR_HP_N02;
	}
	public String getSCR_HP_N03() {
		return SCR_HP_N03;
	}
	public void setSCR_HP_N03(String sCR_HP_N03) {
		SCR_HP_N03 = sCR_HP_N03;
	}
	public String getSCR_JUMIN_NO() {
		return SCR_JUMIN_NO;
	}
	public void setSCR_JUMIN_NO(String sCR_JUMIN_NO) {
		SCR_JUMIN_NO = sCR_JUMIN_NO;
	}
	public String getSCR_GUBUN() {
		return SCR_GUBUN;
	}
	public void setSCR_GUBUN(String sCR_GUBUN) {
		SCR_GUBUN = sCR_GUBUN;
	}
	public String getSCR_BRIGHT_MAP() {
		return SCR_BRIGHT_MAP;
	}
	public void setSCR_BRIGHT_MAP(String sCR_BRIGHT_MAP) {
		SCR_BRIGHT_MAP = sCR_BRIGHT_MAP;
	}
	public String getSCR_BRIGHT_POS() {
		return SCR_BRIGHT_POS;
	}
	public void setSCR_BRIGHT_POS(String sCR_BRIGHT_POS) {
		SCR_BRIGHT_POS = sCR_BRIGHT_POS;
	}
	public String getSCR_BRIGHT_FOS() {
		return SCR_BRIGHT_FOS;
	}
	public void setSCR_BRIGHT_FOS(String sCR_BRIGHT_FOS) {
		SCR_BRIGHT_FOS = sCR_BRIGHT_FOS;
	}
	public String getUSER_GIJUN_YMD() {
		return USER_GIJUN_YMD;
	}
	public void setUSER_GIJUN_YMD(String uSER_GIJUN_YMD) {
		USER_GIJUN_YMD = uSER_GIJUN_YMD;
	}
	public String getUSER_MOKJUK_CD() {
		return USER_MOKJUK_CD;
	}
	public void setUSER_MOKJUK_CD(String uSER_MOKJUK_CD) {
		USER_MOKJUK_CD = uSER_MOKJUK_CD;
	}
	public String getUSER_GOGEK_NO() {
		return USER_GOGEK_NO;
	}
	public void setUSER_GOGEK_NO(String uSER_GOGEK_NO) {
		USER_GOGEK_NO = uSER_GOGEK_NO;
	}
	public String getUSER_BOHUMJA_CD() {
		return USER_BOHUMJA_CD;
	}
	public void setUSER_BOHUMJA_CD(String uSER_BOHUMJA_CD) {
		USER_BOHUMJA_CD = uSER_BOHUMJA_CD;
	}
	public String getUSER_POLI_NO() {
		return USER_POLI_NO;
	}
	public void setUSER_POLI_NO(String uSER_POLI_NO) {
		USER_POLI_NO = uSER_POLI_NO;
	}
	public String getUSER_BOHUM_GIGAN_SYMD() {
		return USER_BOHUM_GIGAN_SYMD;
	}
	public void setUSER_BOHUM_GIGAN_SYMD(String uSER_BOHUM_GIGAN_SYMD) {
		USER_BOHUM_GIGAN_SYMD = uSER_BOHUM_GIGAN_SYMD;
	}
	public String getUSER_GOGEK_NM_YMD1() {
		return USER_GOGEK_NM_YMD1;
	}
	public void setUSER_GOGEK_NM_YMD1(String uSER_GOGEK_NM_YMD1) {
		USER_GOGEK_NM_YMD1 = uSER_GOGEK_NM_YMD1;
	}
	public String getUSER_GOGEK_NM_YMD2() {
		return USER_GOGEK_NM_YMD2;
	}
	public void setUSER_GOGEK_NM_YMD2(String uSER_GOGEK_NM_YMD2) {
		USER_GOGEK_NM_YMD2 = uSER_GOGEK_NM_YMD2;
	}
	public String getUSER_F_BOHUMJA_CD() {
		return USER_F_BOHUMJA_CD;
	}
	public void setUSER_F_BOHUMJA_CD(String uSER_F_BOHUMJA_CD) {
		USER_F_BOHUMJA_CD = uSER_F_BOHUMJA_CD;
	}
	public String getUSER_F_POLI_NO() {
		return USER_F_POLI_NO;
	}
	public void setUSER_F_POLI_NO(String uSER_F_POLI_NO) {
		USER_F_POLI_NO = uSER_F_POLI_NO;
	}
	public String getUSER_F_BOHUM_GIGAN_SYMD() {
		return USER_F_BOHUM_GIGAN_SYMD;
	}
	public void setUSER_F_BOHUM_GIGAN_SYMD(String uSER_F_BOHUM_GIGAN_SYMD) {
		USER_F_BOHUM_GIGAN_SYMD = uSER_F_BOHUM_GIGAN_SYMD;
	}
	public String getUSER_F_GOGEK_NM_YMD1() {
		return USER_F_GOGEK_NM_YMD1;
	}
	public void setUSER_F_GOGEK_NM_YMD1(String uSER_F_GOGEK_NM_YMD1) {
		USER_F_GOGEK_NM_YMD1 = uSER_F_GOGEK_NM_YMD1;
	}
	public String getUSER_F_GOGEK_NM_YMD2() {
		return USER_F_GOGEK_NM_YMD2;
	}
	public void setUSER_F_GOGEK_NM_YMD2(String uSER_F_GOGEK_NM_YMD2) {
		USER_F_GOGEK_NM_YMD2 = uSER_F_GOGEK_NM_YMD2;
	}
	public String getUSER_L_BOHUMJA_CD() {
		return USER_L_BOHUMJA_CD;
	}
	public void setUSER_L_BOHUMJA_CD(String uSER_L_BOHUMJA_CD) {
		USER_L_BOHUMJA_CD = uSER_L_BOHUMJA_CD;
	}
	public String getUSER_L_POLI_NO() {
		return USER_L_POLI_NO;
	}
	public void setUSER_L_POLI_NO(String uSER_L_POLI_NO) {
		USER_L_POLI_NO = uSER_L_POLI_NO;
	}
	public String getUSER_L_BOHUM_GIGAN_SYMD() {
		return USER_L_BOHUM_GIGAN_SYMD;
	}
	public void setUSER_L_BOHUM_GIGAN_SYMD(String uSER_L_BOHUM_GIGAN_SYMD) {
		USER_L_BOHUM_GIGAN_SYMD = uSER_L_BOHUM_GIGAN_SYMD;
	}
	public String getUSER_L_GOGEK_NM_YMD1() {
		return USER_L_GOGEK_NM_YMD1;
	}
	public void setUSER_L_GOGEK_NM_YMD1(String uSER_L_GOGEK_NM_YMD1) {
		USER_L_GOGEK_NM_YMD1 = uSER_L_GOGEK_NM_YMD1;
	}
	public String getUSER_L_GOGEK_NM_YMD2() {
		return USER_L_GOGEK_NM_YMD2;
	}
	public void setUSER_L_GOGEK_NM_YMD2(String uSER_L_GOGEK_NM_YMD2) {
		USER_L_GOGEK_NM_YMD2 = uSER_L_GOGEK_NM_YMD2;
	}
	public String getUSER_CURSOR_GB() {
		return USER_CURSOR_GB;
	}
	public void setUSER_CURSOR_GB(String uSER_CURSOR_GB) {
		USER_CURSOR_GB = uSER_CURSOR_GB;
	}
	public String getUSER_GOGEK_NM_GB() {
		return USER_GOGEK_NM_GB;
	}
	public void setUSER_GOGEK_NM_GB(String uSER_GOGEK_NM_GB) {
		USER_GOGEK_NM_GB = uSER_GOGEK_NM_GB;
	}
	public String getH_SCR_OC_G_GOGEK_NAME() {
		return H_SCR_OC_G_GOGEK_NAME;
	}
	public void setH_SCR_OC_G_GOGEK_NAME(String h_SCR_OC_G_GOGEK_NAME) {
		H_SCR_OC_G_GOGEK_NAME = h_SCR_OC_G_GOGEK_NAME;
	}
	public String getSCR_OC_G_GOGEK_NO() {
		return SCR_OC_G_GOGEK_NO;
	}
	public void setSCR_OC_G_GOGEK_NO(String sCR_OC_G_GOGEK_NO) {
		SCR_OC_G_GOGEK_NO = sCR_OC_G_GOGEK_NO;
	}
	public static String getProid() {
		return proid;
	}
	public static String getTrid() {
		return trid;
	}
	public List<Map<String, Object>> getSCR_OUT_DATA() {
		return SCR_OUT_DATA;
	}
	public void setSCR_OUT_DATA(List<Map<String, Object>> sCR_OUT_DATA) {
		SCR_OUT_DATA = sCR_OUT_DATA;
	}
	public String getUser_count() {
		return User_count; 
	}
	public void setUser_count(String user_count) {
		User_count = user_count;
	}
	public int getUser_cnt() {
		return Integer.parseInt(User_count);
	}

}
