package com.idongbu.smartcustomer.vo;

import java.util.List;
import java.util.Map;

import com.idongbu.common.vo.CMMVO;

public class CmmFWK1074RVO extends CMMVO {
	public String proid					= "";
	public String trid					= "";
	public String rURL					= "";

	//TODO : 차세대 전환 시작 (COMM 필드 제거) (서홍민 2013.01.11)
	/*
	public String COMM_CHANNEL			= null;	//채널유형
	public String COMM_UNIQUE			= null;	//터미널ID
	public String COMM_PROGRAM			= null;	//프로그램ID
	public String COMM_TRANS			= null;	//경로
	public String COMM_ACTION			= null;	//기능키
	public String COMM_USER_GB			= null;	//사용자구분
	public String COMM_USER_ID			= null;	//사용자ID
	public String COMM_JIJUM_CD			= null;	//지점코드
	public String COMM_JIBU_CD			= null;	//지부코드
	public String COMM_PROTOCOL			= null;	//프로토콜
	public String COMM_LAST_FLAG		= null;	//마지막자료구분
	public String COMM_CUR_FLD			= null;	//현재위치맵
	public String COMM_CUR_POS			= null;	//현재위치값
	public String COMM_SYS_ERR			= null;	//시스템메시지
	*/
	//TODO : 차세대 전환 끝 (COMM 필드 제거) (서홍민 2013.01.11)
	
	public String COMM_RETN_CODE		= null;	//상태코드
	public String COMM_TS_ITEM			= null;	//TS아이템
	public String COMM_FORM_ID			= null;	//폼ID
	public String COMM_FORM_GUBUN		= null;	//폼구분
	public String COMM_FIL				= null;	//공백
	public String COMM_TOTAL_CNT		= null;	//총카운트
	public String COMM_CNT				= null;	//카운트
	public String COMM_PRINT_GB			= null;	//출력구분 (RD)
	public String COMM_PRINT_TYPE		= null;	//출력형태 (RD)
	public String COMM_FIL_1			= null;	//공백
	
	public String COMM_MSG_CODE			= null;	//메시지코드
	public String H_COMM_MSG_NAME		= null;	//메시지명
	
	public String LK_GYPRINT_SULGYE_NO	= null;	//설계번호
	public String LK_GYPRINT_POLI_NO1	= null;	//증권번호
	public String LK_GYPRINT_POLI_NO2	= null;	//증권번호
	public String LK_GYPRINT_BESU_SEQ	= null;	//배서일련번호
	public String LK_GYPRINT_GUNE_SEQ	= null;	//구내일련번호
	public String LK_GYPRINT_BUNNAP_CNT	= null;	//분납회수
	public String LK_GYPRINT_BOJONG_CD	= null;	//보종코드
	public String LK_GYPRINT_YYYYMM		= null;	//출력일
	public String LK_GYPRINT_JUMIN_NO	= null;	//주민번호
	public String LK_GYPRINT_JOJIKWON_CD= null;	//조직원코드
	public String LK_GYPRINT_H_E_GB		= null;	//에드앤드구분
	public String LK_GYPRINT_SEND_MAP	= null;	//샌드맵
	public String LK_GYPRINT_PRINT_YN	= null;	//출력유무
	public String LK_GYPRINT_TS_ITEM_X	= null;	//TS아이템
	public String LK_GYPRINT_WONBON_GB	= null;	//원본구분
	public String LK_GYPRINT_PRINT_GB	= null;	//출력구분
	public String LK_GYPRINT_RC			= null;	//컨트롤코드
	public String LK_GYPRINT_SYS_NAME	= null;	//시스템명
	public String LK_GYPRINT_SYS_CODE	= null;	//시스템코드
	public String COMM_PRINT_DATA		= null;	//출력데이타
	public String SCR_BALGUP_GB			= null;	//발급구분
	public String SCR_BOJONG_CD			= null;	//보종코드
	public String SCR_SULGYE_NO			= null;	//설계번호
	public String SCR_POLI_NO1			= null;	//증권번호
	public String SCR_POLI_NO2			= null;	//증권번호
	public String SCR_BESU_SEQ			= null;	//배서일련번호
	public String SCR_H_E_GB			= null;	//헤드앤드구분
	public String SCR_PUMI_NO			= null;	//품의번호
	public String SCR_SIMSA_GB			= null;	//심사구분
	public String SCR_G_B_GB			= null;	//증권구분
	public String SCR_G_B_NAME			= null;	//증권구분명
	public String SCR_SOJEJI_GB			= null;	//소재지구분
	public String H_SCR_SOJEJI_NAME		= null;	//소재지명
	public String SCR_WONBON_GB			= null;	//원본구분
	public String H_SCR_WONBON_NAME		= null;	//원본명
	public String SCR_P_GB				= null;	//발급구분
	public String H_SCR_P_NAME			= null;	//발급명
	public String SCR_JUMIN_NO			= null;	//주민번호
	public String SCR_JOJIKWON_CD		= null;	//조직원코드
	public String SCR_PRINT_GB			= null;	//출력구분
	public String USER_FBRT_MAP			= null;	//필드체크PGM
	public String[] USER_FBRT_INDEX		= new String[0];
	public String USER_FBRT_IDX			= null;	//입력필드체크
	public String USER_PRINT_YN			= null;	//출력유무
	public String USER_TS_ITEM			= null;	//TS아이템
	public String USER_FIL1				= null;	//바코드여부
	public String USER_FIL2				= null;	//EDMS동시출력여부
	public String USER_FIL3				= null;	//원증권발급이력
	public String USER_FIL4				= null;	//배서증권발급이력
	public String USER_FIL5				= null;	//보안메일여부
	public String USER_FIL6				= null;	//보안메일비밀번호
	public String RD_POLICY_YN			= null;	//출력부분 (RD)
	public String RD_COPY_YN			= null;	//출력부분 (RD)
	public String RD_GREEN_YN			= null;	//출력부분 (RD)
	public String RD_ENCRYPT_YN			= null;	//출력부분 (RD)
	public String RD_ENCRYPT_KEY		= null;	//출력부분 (RD)
	public String RD_UPMU_GB			= null;	//출력부분 (RD)
	public String RD_DOCU_GB			= null;	//출력부분 (RD)
	public String RD_SIGN_KEY			= null;	//출력부분 (RD)
	public String RD_NEXT_YN			= null;	//출력부분 (RD)
//차세대 2차 이슬기 추가 
	public String SCR_POLI_NO			= null;	//증권번호
	public String ctrmf_sqno		= null; //계약변경일련번호
	public String outp_opti_if__isgd_typ_ptl_cd =""; //발급물유형세부코드
	public String outp_opti_if__isgd_typ_dvcd =""; //발급물유형분류코드
	
	
}
