package com.idongbu.smartcustomer.vo;

import java.util.List;
import java.util.Map;

import com.idongbu.common.vo.CMMVO;

// 계약조회
public class CmmFBM0048RVO extends CMMVO {
	
	public CmmFBM0048RVO() {
		super.setPGMID(this.proid);
		super.setTRID(this.trid);
	}	
	
	public static final String proid		  = "FBM0048R";
	public static final String trid			  = "BM48";
	public String rURL						  = "";
	                                          
	//페이징                                  
	public int page_rowcnt 					  = 0;
	public int page_rownum	 				  = 0;
	public int page_num 					  = 1;
	public int page_size 					  = 10;
	                                          
	//페이징 Key                              
	public String PREV_UD_FK_POLI_NO 		  = "";
	                                          
	//증명서발급관련Key
	private String PAPER_GBN                  = "";
	private String ILBAN_CD                   = "";
	private String S_POLI_NO                  = "";
	
	// 입력                                   
	public String SI_K_GOGEK_NO 			  = null; // 고객번호
	///2007-11-01  전문 필드 추가 -방희문 -   
	public String SI_K_SEARCH_GB 			  = null; //1:자동차, 2:장기, 3:일반손보  1,2,3제외 :전체(" ")
 	
	// 출력
	public String COMM_CHANNEL 				  = null;
	public String COMM_COND_CD 				  = null;
	public String COMM_UNIQUE_KEY 	          = null;
	public String COMM_PGMID 		          = null;
	public String COMM_PROC_GB 		          = null;
	public String COMM_ACTION_KEY 	          = null;
	public String COMM_USER_GB 		          = null;
	public String COMM_USER_ID 		          = null;
	public String COMM_JIJUM_CD 	          = null;
	public String COMM_JIBU_CD 		          = null;
	public String COMM_PROTOCOL 	          = null;
	public String COMM_LAST_FLAG			  = null;
	public String COMM_MESSAGE_CD			  = null;									//오류메시지코드
	public String HOMM_MESSAGE_NM			  = null;									//오류메시지내용
	public String UD_FK_POLI_NO 			  = null;
	public String UD_LK_POLI_NO 			  = null;
	public List<Map<String,Object>> LOOP_DATA = null;
	public List<SubFBM0048RVO> LIST_DATA = null;
	
	public String[] SO_BJ_GB = new String[0]; // 20
	public String[] SO_POLI_NO = new String[0]; 										// 증권번호
	
	public String cust_hngl_nm = ""; // 운전자명
	public String srch_dvn = "";

	public String evt_ctc_str_dt = ""; // 이벤트계약시작일자
	public String evt_tgt_cust_yn = ""; // 이벤트대상고객여부

	public String getrURL() {
		return rURL;
	}

	public void setrURL(String rURL) {
		this.rURL = rURL;
	}

	public String getSI_K_GOGEK_NO() {
		return SI_K_GOGEK_NO;
	}

	public void setSI_K_GOGEK_NO(String sI_K_GOGEK_NO) {
		SI_K_GOGEK_NO = sI_K_GOGEK_NO;
	}

	public String getSI_K_SEARCH_GB() {
		return SI_K_SEARCH_GB;
	}

	public void setSI_K_SEARCH_GB(String sI_K_SEARCH_GB) {
		SI_K_SEARCH_GB = sI_K_SEARCH_GB;
	}

	public String getCOMM_CHANNEL() {
		return COMM_CHANNEL;
	}

	public void setCOMM_CHANNEL(String cOMM_CHANNEL) {
		COMM_CHANNEL = cOMM_CHANNEL;
	}

	public String getCOMM_COND_CD() {
		return COMM_COND_CD;
	}

	public void setCOMM_COND_CD(String cOMM_COND_CD) {
		COMM_COND_CD = cOMM_COND_CD;
	}

	public String getCOMM_UNIQUE_KEY() {
		return COMM_UNIQUE_KEY;
	}

	public void setCOMM_UNIQUE_KEY(String cOMM_UNIQUE_KEY) {
		COMM_UNIQUE_KEY = cOMM_UNIQUE_KEY;
	}

	public String getCOMM_PGMID() {
		return COMM_PGMID;
	}

	public void setCOMM_PGMID(String cOMM_PGMID) {
		COMM_PGMID = cOMM_PGMID;
	}

	public String getCOMM_PROC_GB() {
		return COMM_PROC_GB;
	}

	public void setCOMM_PROC_GB(String cOMM_PROC_GB) {
		COMM_PROC_GB = cOMM_PROC_GB;
	}

	public String getCOMM_ACTION_KEY() {
		return COMM_ACTION_KEY;
	}

	public void setCOMM_ACTION_KEY(String cOMM_ACTION_KEY) {
		COMM_ACTION_KEY = cOMM_ACTION_KEY;
	}

	public String getCOMM_USER_GB() {
		return COMM_USER_GB;
	}

	public void setCOMM_USER_GB(String cOMM_USER_GB) {
		COMM_USER_GB = cOMM_USER_GB;
	}

	public String getCOMM_USER_ID() {
		return COMM_USER_ID;
	}

	public void setCOMM_USER_ID(String cOMM_USER_ID) {
		COMM_USER_ID = cOMM_USER_ID;
	}

	public String getCOMM_JIJUM_CD() {
		return COMM_JIJUM_CD;
	}

	public void setCOMM_JIJUM_CD(String cOMM_JIJUM_CD) {
		COMM_JIJUM_CD = cOMM_JIJUM_CD;
	}

	public String getCOMM_JIBU_CD() {
		return COMM_JIBU_CD;
	}

	public void setCOMM_JIBU_CD(String cOMM_JIBU_CD) {
		COMM_JIBU_CD = cOMM_JIBU_CD;
	}

	public String getCOMM_PROTOCOL() {
		return COMM_PROTOCOL;
	}

	public void setCOMM_PROTOCOL(String cOMM_PROTOCOL) {
		COMM_PROTOCOL = cOMM_PROTOCOL;
	}

	public String getCOMM_LAST_FLAG() {
		return COMM_LAST_FLAG;
	}

	public void setCOMM_LAST_FLAG(String cOMM_LAST_FLAG) {
		COMM_LAST_FLAG = cOMM_LAST_FLAG;
	}

	public String getCOMM_MESSAGE_CD() {
		return COMM_MESSAGE_CD;
	}

	public void setCOMM_MESSAGE_CD(String cOMM_MESSAGE_CD) {
		COMM_MESSAGE_CD = cOMM_MESSAGE_CD;
	}


	public static String getProid() {
		return proid;
	}

	public static String getTrid() {
		return trid;
	}

	public List<Map<String, Object>> getLOOP_DATA() {
		return LOOP_DATA;
	}

	public void setLOOP_DATA(List<Map<String, Object>> lOOP_DATA) {
		LOOP_DATA = lOOP_DATA;
	}

	public int getPage_rowcnt() {
		return page_rowcnt;
	}

	public void setPage_rowcnt(int page_rowcnt) {
		this.page_rowcnt = page_rowcnt;
	}

	public int getPage_rownum() {
		return page_rownum;
	}

	public void setPage_rownum(int page_rownum) {
		this.page_rownum = page_rownum;
	}

	public int getPage_num() {
		return page_num;
	}

	public void setPage_num(int page_num) {
		this.page_num = page_num;
	}

	public int getPage_size() {
		return page_size;
	}

	public void setPage_size(int page_size) {
		this.page_size = page_size;
	}

	public String getUD_FK_POLI_NO() {
		return UD_FK_POLI_NO;
	}

	public void setUD_FK_POLI_NO(String uD_FK_POLI_NO) {
		UD_FK_POLI_NO = uD_FK_POLI_NO;
	}

	public String getUD_LK_POLI_NO() {
		return UD_LK_POLI_NO;
	}

	public void setUD_LK_POLI_NO(String uD_LK_POLI_NO) {
		UD_LK_POLI_NO = uD_LK_POLI_NO;
	}

	public String getPREV_UD_FK_POLI_NO() {
		return PREV_UD_FK_POLI_NO;
	}

	public void setPREV_UD_FK_POLI_NO(String pREV_UD_FK_POLI_NO) {
		PREV_UD_FK_POLI_NO = pREV_UD_FK_POLI_NO;
	}

	public String[] getSO_BJ_GB() {
		return SO_BJ_GB;
	}

	public void setSO_BJ_GB(String[] sO_BJ_GB) {
		SO_BJ_GB = sO_BJ_GB;
	}

	public String[] getSO_POLI_NO() {
		return SO_POLI_NO;
	}

	public void setSO_POLI_NO(String[] sO_POLI_NO) {
		SO_POLI_NO = sO_POLI_NO;
	}
	
	public String getPAPER_GBN() {
		return PAPER_GBN;
	}

	public void setPAPER_GBN(String pAPER_GBN) {
		PAPER_GBN = pAPER_GBN;
	}

	public String getILBAN_CD() {
		return ILBAN_CD;
	}

	public void setILBAN_CD(String iLBAN_CD) {
		ILBAN_CD = iLBAN_CD;
	}

	public String getS_POLI_NO() {
		return S_POLI_NO;
	}

	public void setS_POLI_NO(String s_POLI_NO) {
		S_POLI_NO = s_POLI_NO;
	}

	public String getHOMM_MESSAGE_NM() {
		return HOMM_MESSAGE_NM;
	}

	public void setHOMM_MESSAGE_NM(String hOMM_MESSAGE_NM) {
		HOMM_MESSAGE_NM = hOMM_MESSAGE_NM;
	}

	public List<SubFBM0048RVO> getLIST_DATA() {
		return LIST_DATA;
	}

	public void setLIST_DATA(List<SubFBM0048RVO> listData) {
		LIST_DATA = listData;
	}
	
	/**
	 * @return the cust_hngl_nm
	 */
	public String getCust_hngl_nm() {
		return cust_hngl_nm;
	}

	/**
	 * @param cust_hngl_nm the cust_hngl_nm to set
	 */
	public void setCust_hngl_nm(String cust_hngl_nm) {
		this.cust_hngl_nm = cust_hngl_nm;
	}
	
	/**
	 * @return the srch_dvn
	 */
	public String getSrch_dvn() {
		return srch_dvn;
	}

	/**
	 * @param srch_dvn the srch_dvn to set
	 */
	public void setSrch_dvn(String srch_dvn) {
		this.srch_dvn = srch_dvn;
	}

	public String getEvt_ctc_str_dt() {
		return evt_ctc_str_dt;
	}

	public void setEvt_ctc_str_dt(String evt_ctc_str_dt) {
		this.evt_ctc_str_dt = evt_ctc_str_dt;
	}

	public String getEvt_tgt_cust_yn() {
		return evt_tgt_cust_yn;
	}

	public void setEvt_tgt_cust_yn(String evt_tgt_cust_yn) {
		this.evt_tgt_cust_yn = evt_tgt_cust_yn;
	}

}
