package com.idongbu.smartcustomer.vo;

/**
 * @author F1F14A61
 *
 */
public class SubFGZ5915SVO {
	
	public String LK_BJ_NM           = null;
	public String LK_BOHUM_GIGAN_NM  = null;
	public String LK_BOHUM_SYMD      = null;
	public String LK_BOHUM_EYMD      = null;
	public String LK_GYEY_NM         = null;
	public String LK_GYEY_ADDR       = null;
	public String LK_GYEY_GITA       = null;
	public String LK_NAPIP_PRM       = null;
	public String LK_GAIP1_NM        = null;
	public String LK_BUNNAP_NM       = null;
	public String LK_L_NAPIP_YM      = null;
	public String LK_ILBAN           = null;
	public String LK_FIL             = null;
	public String LK_YAKGWAN         = null;
	public String LK_JOJIKWON_NM     = null;
	public String LK_JOJIKWON_TEL    = null;
	public String LK_SANGTE_NM       = null;
	public String LK_PIBO_NM         = null;
	public String LK_L_NAPIP_CNT     = null;
	public String LK_HEJI_YN         = null;
	public String LK_PIBO_CD         = null;
	
	public String getLK_BJ_NM() {
		return LK_BJ_NM;
	}
	public void setLK_BJ_NM(String lK_BJ_NM) {
		LK_BJ_NM = lK_BJ_NM;
	}
	public String getLK_BOHUM_GIGAN_NM() {
		return LK_BOHUM_GIGAN_NM;
	}
	public void setLK_BOHUM_GIGAN_NM(String lK_BOHUM_GIGAN_NM) {
		LK_BOHUM_GIGAN_NM = lK_BOHUM_GIGAN_NM;
	}
	public String getLK_BOHUM_SYMD() {
		return LK_BOHUM_SYMD;
	}
	public void setLK_BOHUM_SYMD(String lK_BOHUM_SYMD) {
		LK_BOHUM_SYMD = lK_BOHUM_SYMD;
	}
	public String getLK_BOHUM_EYMD() {
		return LK_BOHUM_EYMD;
	}
	public void setLK_BOHUM_EYMD(String lK_BOHUM_EYMD) {
		LK_BOHUM_EYMD = lK_BOHUM_EYMD;
	}
	public String getLK_GYEY_NM() {
		return LK_GYEY_NM;
	}
	public void setLK_GYEY_NM(String lK_GYEY_NM) {
		LK_GYEY_NM = lK_GYEY_NM;
	}
	public String getLK_GYEY_ADDR() {
		return LK_GYEY_ADDR;
	}
	public void setLK_GYEY_ADDR(String lK_GYEY_ADDR) {
		LK_GYEY_ADDR = lK_GYEY_ADDR;
	}
	public String getLK_GYEY_GITA() {
		return LK_GYEY_GITA;
	}
	public void setLK_GYEY_GITA(String lK_GYEY_GITA) {
		LK_GYEY_GITA = lK_GYEY_GITA;
	}
	public String getLK_NAPIP_PRM() {
		return LK_NAPIP_PRM;
	}
	public void setLK_NAPIP_PRM(String lK_NAPIP_PRM) {
		LK_NAPIP_PRM = lK_NAPIP_PRM;
	}
	public String getLK_GAIP1_NM() {
		return LK_GAIP1_NM;
	}
	public void setLK_GAIP1_NM(String lK_GAIP1_NM) {
		LK_GAIP1_NM = lK_GAIP1_NM;
	}
	public String getLK_BUNNAP_NM() {
		return LK_BUNNAP_NM;
	}
	public void setLK_BUNNAP_NM(String lK_BUNNAP_NM) {
		LK_BUNNAP_NM = lK_BUNNAP_NM;
	}
	public String getLK_L_NAPIP_YM() {
		return LK_L_NAPIP_YM;
	}
	public void setLK_L_NAPIP_YM(String lK_L_NAPIP_YM) {
		LK_L_NAPIP_YM = lK_L_NAPIP_YM;
	}
	public String getLK_ILBAN() {
		return LK_ILBAN;
	}
	public void setLK_ILBAN(String lK_ILBAN) {
		LK_ILBAN = lK_ILBAN;
	}
	public String getLK_FIL() {
		return LK_FIL;
	}
	public void setLK_FIL(String lK_FIL) {
		LK_FIL = lK_FIL;
	}
	public String getLK_YAKGWAN() {
		return LK_YAKGWAN;
	}
	public void setLK_YAKGWAN(String lK_YAKGWAN) {
		LK_YAKGWAN = lK_YAKGWAN;
	}
	public String getLK_JOJIKWON_NM() {
		return LK_JOJIKWON_NM;
	}
	public void setLK_JOJIKWON_NM(String lK_JOJIKWON_NM) {
		LK_JOJIKWON_NM = lK_JOJIKWON_NM;
	}
	public String getLK_JOJIKWON_TEL() {
		return LK_JOJIKWON_TEL;
	}
	public void setLK_JOJIKWON_TEL(String lK_JOJIKWON_TEL) {
		LK_JOJIKWON_TEL = lK_JOJIKWON_TEL;
	}
	public String getLK_SANGTE_NM() {
		return LK_SANGTE_NM;
	}
	public void setLK_SANGTE_NM(String lK_SANGTE_NM) {
		LK_SANGTE_NM = lK_SANGTE_NM;
	}
	public String getLK_PIBO_NM() {
		return LK_PIBO_NM;
	}
	public void setLK_PIBO_NM(String lK_PIBO_NM) {
		LK_PIBO_NM = lK_PIBO_NM;
	}
	public String getLK_L_NAPIP_CNT() {
		return LK_L_NAPIP_CNT;
	}
	public void setLK_L_NAPIP_CNT(String lK_L_NAPIP_CNT) {
		LK_L_NAPIP_CNT = lK_L_NAPIP_CNT;
	}
	public String getLK_HEJI_YN() {
		return LK_HEJI_YN;
	}
	public void setLK_HEJI_YN(String lK_HEJI_YN) {
		LK_HEJI_YN = lK_HEJI_YN;
	}
	public String getLK_PIBO_CD() {
		return LK_PIBO_CD;
	}
	public void setLK_PIBO_CD(String lK_PIBO_CD) {
		LK_PIBO_CD = lK_PIBO_CD;
	}	
}
