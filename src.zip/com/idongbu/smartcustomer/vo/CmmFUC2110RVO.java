package com.idongbu.smartcustomer.vo;

import com.idongbu.common.vo.CMMVO;

//약관대출가능조회
public class CmmFUC2110RVO  extends CMMVO{
	
	public CmmFUC2110RVO() {
		super.setPGMID(proid);
		super.setTRID(trid);
	}
	
	private final static String proid		= "FUC2110R";
	private final static String trid		= "UCLA";
	
	//CC-HEAD.
	private String CC_CHANNEL		= "";
	private String CC_UKEY		= "";
	private String CC_PGMID		= "";
	private String CC_PROC_GB		= "";
	private String CC_FUN_KEY		= "";
	
	//CC-SAWON-NO.
	private String CC_USER_GB		= "";
	private String CC_USER_CD		= "";
	
	//CC-JIJUM.
	private String CC_JIJUM_CD		= "";
	private String CC_JIBU_CD		= "";
	
	private String CC_PROTOCOL		= "";
	private String CC_COND_CD		= "";
	private String CC_LAST_FLAG		= "";
	private String CC_CURSOR_MAP		= "";
	private String CC_CURSOR_IDX		= "";
	private String CC_MESSAGE_CD		= "";
	private String HC_MESSAGE_NM		= "";
	private String CC_SYS_ERR		= "";
	private String CC_TS_ITEM		= "";
	private String CC_FORM_ID		= "";
	private String CC_PRT_GB		= "";
	private String CC_FILLER		= "";
	
	//JJ-SCREEN-DATA.
	private String JJ_POLI_NO		= "";
	private String JJ_GBN 		= "";
	
	private String JJ_SUNAP_YMD		= "";// 10
	private String HJ_GY_NM 		= "";// 10
	private String JJ_GY_JUMIN		= "";// 10
	private String JJ_GI_GISAN_GM		= "";// 10
	private String JJ_GI_GISAN_YMD		= "";// 10
	private String JJ_GI_SUNN_EYMD		= "";// 10
	private String JJ_IYUL		= "";// 10
	private String JJ_JUNG_F1		= "";// 10
	private String JJ_JUNG_T1 		= "";// 10
	private String JJ_JUNG_ILSU1		= "";// 10
	private String JJ_JUNG_IJA1		= "";// 10
	private String JJ_JUNG_F2 		= "";// 10
	private String JJ_JUNG_T2		= "";// 10
	private String JJ_JUNG_ILSU2		= "";// 10
	private String JJ_JUNG_IJA2 		= "";// 10
	private String JJ_YUNC_F1		= "";// 10
	private String JJ_YUNC_T1		= "";// 10
	private String JJ_YUNC_ILSU1		= "";// 10
	private String JJ_YUNC_IJA1 		= "";// 10
	private String JJ_YUNC_F2		= "";// 10
	private String JJ_YUNC_T2 		= "";// 10
	private String JJ_YUNC_ILSU2		= "";// 10
	private String JJ_YUNC_IJA2 		= "";// 10
	private String JJ_MIGU_F		= "";// 10
	private String JJ_MIGU_T		= "";// 10
	private String JJ_MIGU_ILSU		= "";// 10
	private String JJ_MIGU_IJA 		= "";// 10
	private String HJ_GWAO		= "";// 10
	private String JJ_GWAO		= "";// 10
	private String JJ_NAPIP_IJA 		= "";// 10
	
	private String JJ_GWAO_F		= "";//PIC  X(08).    
	private String JJ_GWAO_T		= "";//PIC  X(08).     
	private String JJ_GWAO_ILSU 		= "";//PIC  9(04).     
	
	public String getCC_CHANNEL() {
		return CC_CHANNEL;
	}
	public void setCC_CHANNEL(String cC_CHANNEL) {
		CC_CHANNEL = cC_CHANNEL;
	}
	public String getCC_UKEY() {
		return CC_UKEY;
	}
	public void setCC_UKEY(String cC_UKEY) {
		CC_UKEY = cC_UKEY;
	}
	public String getCC_PGMID() {
		return CC_PGMID;
	}
	public void setCC_PGMID(String cC_PGMID) {
		CC_PGMID = cC_PGMID;
	}
	public String getCC_PROC_GB() {
		return CC_PROC_GB;
	}
	public void setCC_PROC_GB(String cC_PROC_GB) {
		CC_PROC_GB = cC_PROC_GB;
	}
	public String getCC_FUN_KEY() {
		return CC_FUN_KEY;
	}
	public void setCC_FUN_KEY(String cC_FUN_KEY) {
		CC_FUN_KEY = cC_FUN_KEY;
	}
	public String getCC_USER_GB() {
		return CC_USER_GB;
	}
	public void setCC_USER_GB(String cC_USER_GB) {
		CC_USER_GB = cC_USER_GB;
	}
	public String getCC_USER_CD() {
		return CC_USER_CD;
	}
	public void setCC_USER_CD(String cC_USER_CD) {
		CC_USER_CD = cC_USER_CD;
	}
	public String getCC_JIJUM_CD() {
		return CC_JIJUM_CD;
	}
	public void setCC_JIJUM_CD(String cC_JIJUM_CD) {
		CC_JIJUM_CD = cC_JIJUM_CD;
	}
	public String getCC_JIBU_CD() {
		return CC_JIBU_CD;
	}
	public void setCC_JIBU_CD(String cC_JIBU_CD) {
		CC_JIBU_CD = cC_JIBU_CD;
	}
	public String getCC_PROTOCOL() {
		return CC_PROTOCOL;
	}
	public void setCC_PROTOCOL(String cC_PROTOCOL) {
		CC_PROTOCOL = cC_PROTOCOL;
	}
	public String getCC_COND_CD() {
		return CC_COND_CD;
	}
	public void setCC_COND_CD(String cC_COND_CD) {
		CC_COND_CD = cC_COND_CD;
	}
	public String getCC_LAST_FLAG() {
		return CC_LAST_FLAG;
	}
	public void setCC_LAST_FLAG(String cC_LAST_FLAG) {
		CC_LAST_FLAG = cC_LAST_FLAG;
	}
	public String getCC_CURSOR_MAP() {
		return CC_CURSOR_MAP;
	}
	public void setCC_CURSOR_MAP(String cC_CURSOR_MAP) {
		CC_CURSOR_MAP = cC_CURSOR_MAP;
	}
	public String getCC_CURSOR_IDX() {
		return CC_CURSOR_IDX;
	}
	public void setCC_CURSOR_IDX(String cC_CURSOR_IDX) {
		CC_CURSOR_IDX = cC_CURSOR_IDX;
	}
	public String getCC_MESSAGE_CD() {
		return CC_MESSAGE_CD;
	}
	public void setCC_MESSAGE_CD(String cC_MESSAGE_CD) {
		CC_MESSAGE_CD = cC_MESSAGE_CD;
	}
	public String getHC_MESSAGE_NM() {
		return HC_MESSAGE_NM;
	}
	public void setHC_MESSAGE_NM(String hC_MESSAGE_NM) {
		HC_MESSAGE_NM = hC_MESSAGE_NM;
	}
	public String getCC_SYS_ERR() {
		return CC_SYS_ERR;
	}
	public void setCC_SYS_ERR(String cC_SYS_ERR) {
		CC_SYS_ERR = cC_SYS_ERR;
	}
	public String getCC_TS_ITEM() {
		return CC_TS_ITEM;
	}
	public void setCC_TS_ITEM(String cC_TS_ITEM) {
		CC_TS_ITEM = cC_TS_ITEM;
	}
	public String getCC_FORM_ID() {
		return CC_FORM_ID;
	}
	public void setCC_FORM_ID(String cC_FORM_ID) {
		CC_FORM_ID = cC_FORM_ID;
	}
	public String getCC_PRT_GB() {
		return CC_PRT_GB;
	}
	public void setCC_PRT_GB(String cC_PRT_GB) {
		CC_PRT_GB = cC_PRT_GB;
	}
	public String getCC_FILLER() {
		return CC_FILLER;
	}
	public void setCC_FILLER(String cC_FILLER) {
		CC_FILLER = cC_FILLER;
	}
	public String getJJ_POLI_NO() {
		return JJ_POLI_NO;
	}
	public void setJJ_POLI_NO(String jJ_POLI_NO) {
		JJ_POLI_NO = jJ_POLI_NO;
	}
	public String getJJ_GBN() {
		return JJ_GBN;
	}
	public void setJJ_GBN(String jJ_GBN) {
		JJ_GBN = jJ_GBN;
	}
	public String getJJ_SUNAP_YMD() {
		return JJ_SUNAP_YMD;
	}
	public void setJJ_SUNAP_YMD(String jJ_SUNAP_YMD) {
		JJ_SUNAP_YMD = jJ_SUNAP_YMD;
	}
	public String getHJ_GY_NM() {
		return HJ_GY_NM;
	}
	public void setHJ_GY_NM(String hJ_GY_NM) {
		HJ_GY_NM = hJ_GY_NM;
	}
	public String getJJ_GY_JUMIN() {
		return JJ_GY_JUMIN;
	}
	public void setJJ_GY_JUMIN(String jJ_GY_JUMIN) {
		JJ_GY_JUMIN = jJ_GY_JUMIN;
	}
	public String getJJ_GI_GISAN_GM() {
		return JJ_GI_GISAN_GM;
	}
	public void setJJ_GI_GISAN_GM(String jJ_GI_GISAN_GM) {
		JJ_GI_GISAN_GM = jJ_GI_GISAN_GM;
	}
	public String getJJ_GI_GISAN_YMD() {
		return JJ_GI_GISAN_YMD;
	}
	public void setJJ_GI_GISAN_YMD(String jJ_GI_GISAN_YMD) {
		JJ_GI_GISAN_YMD = jJ_GI_GISAN_YMD;
	}
	public String getJJ_GI_SUNN_EYMD() {
		return JJ_GI_SUNN_EYMD;
	}
	public void setJJ_GI_SUNN_EYMD(String jJ_GI_SUNN_EYMD) {
		JJ_GI_SUNN_EYMD = jJ_GI_SUNN_EYMD;
	}
	public String getJJ_IYUL() {
		return JJ_IYUL;
	}
	public void setJJ_IYUL(String jJ_IYUL) {
		JJ_IYUL = jJ_IYUL;
	}
	public String getJJ_JUNG_F1() {
		return JJ_JUNG_F1;
	}
	public void setJJ_JUNG_F1(String jJ_JUNG_F1) {
		JJ_JUNG_F1 = jJ_JUNG_F1;
	}
	public String getJJ_JUNG_T1() {
		return JJ_JUNG_T1;
	}
	public void setJJ_JUNG_T1(String jJ_JUNG_T1) {
		JJ_JUNG_T1 = jJ_JUNG_T1;
	}
	public String getJJ_JUNG_ILSU1() {
		return JJ_JUNG_ILSU1;
	}
	public void setJJ_JUNG_ILSU1(String jJ_JUNG_ILSU1) {
		JJ_JUNG_ILSU1 = jJ_JUNG_ILSU1;
	}
	public String getJJ_JUNG_IJA1() {
		return JJ_JUNG_IJA1;
	}
	public void setJJ_JUNG_IJA1(String jJ_JUNG_IJA1) {
		JJ_JUNG_IJA1 = jJ_JUNG_IJA1;
	}
	public String getJJ_JUNG_F2() {
		return JJ_JUNG_F2;
	}
	public void setJJ_JUNG_F2(String jJ_JUNG_F2) {
		JJ_JUNG_F2 = jJ_JUNG_F2;
	}
	public String getJJ_JUNG_T2() {
		return JJ_JUNG_T2;
	}
	public void setJJ_JUNG_T2(String jJ_JUNG_T2) {
		JJ_JUNG_T2 = jJ_JUNG_T2;
	}
	public String getJJ_JUNG_ILSU2() {
		return JJ_JUNG_ILSU2;
	}
	public void setJJ_JUNG_ILSU2(String jJ_JUNG_ILSU2) {
		JJ_JUNG_ILSU2 = jJ_JUNG_ILSU2;
	}
	public String getJJ_JUNG_IJA2() {
		return JJ_JUNG_IJA2;
	}
	public void setJJ_JUNG_IJA2(String jJ_JUNG_IJA2) {
		JJ_JUNG_IJA2 = jJ_JUNG_IJA2;
	}
	public String getJJ_YUNC_F1() {
		return JJ_YUNC_F1;
	}
	public void setJJ_YUNC_F1(String jJ_YUNC_F1) {
		JJ_YUNC_F1 = jJ_YUNC_F1;
	}
	public String getJJ_YUNC_T1() {
		return JJ_YUNC_T1;
	}
	public void setJJ_YUNC_T1(String jJ_YUNC_T1) {
		JJ_YUNC_T1 = jJ_YUNC_T1;
	}
	public String getJJ_YUNC_ILSU1() {
		return JJ_YUNC_ILSU1;
	}
	public void setJJ_YUNC_ILSU1(String jJ_YUNC_ILSU1) {
		JJ_YUNC_ILSU1 = jJ_YUNC_ILSU1;
	}
	public String getJJ_YUNC_IJA1() {
		return JJ_YUNC_IJA1;
	}
	public void setJJ_YUNC_IJA1(String jJ_YUNC_IJA1) {
		JJ_YUNC_IJA1 = jJ_YUNC_IJA1;
	}
	public String getJJ_YUNC_F2() {
		return JJ_YUNC_F2;
	}
	public void setJJ_YUNC_F2(String jJ_YUNC_F2) {
		JJ_YUNC_F2 = jJ_YUNC_F2;
	}
	public String getJJ_YUNC_T2() {
		return JJ_YUNC_T2;
	}
	public void setJJ_YUNC_T2(String jJ_YUNC_T2) {
		JJ_YUNC_T2 = jJ_YUNC_T2;
	}
	public String getJJ_YUNC_ILSU2() {
		return JJ_YUNC_ILSU2;
	}
	public void setJJ_YUNC_ILSU2(String jJ_YUNC_ILSU2) {
		JJ_YUNC_ILSU2 = jJ_YUNC_ILSU2;
	}
	public String getJJ_YUNC_IJA2() {
		return JJ_YUNC_IJA2;
	}
	public void setJJ_YUNC_IJA2(String jJ_YUNC_IJA2) {
		JJ_YUNC_IJA2 = jJ_YUNC_IJA2;
	}
	public String getJJ_MIGU_F() {
		return JJ_MIGU_F;
	}
	public void setJJ_MIGU_F(String jJ_MIGU_F) {
		JJ_MIGU_F = jJ_MIGU_F;
	}
	public String getJJ_MIGU_T() {
		return JJ_MIGU_T;
	}
	public void setJJ_MIGU_T(String jJ_MIGU_T) {
		JJ_MIGU_T = jJ_MIGU_T;
	}
	public String getJJ_MIGU_ILSU() {
		return JJ_MIGU_ILSU;
	}
	public void setJJ_MIGU_ILSU(String jJ_MIGU_ILSU) {
		JJ_MIGU_ILSU = jJ_MIGU_ILSU;
	}
	public String getJJ_MIGU_IJA() {
		return JJ_MIGU_IJA;
	}
	public void setJJ_MIGU_IJA(String jJ_MIGU_IJA) {
		JJ_MIGU_IJA = jJ_MIGU_IJA;
	}
	public String getHJ_GWAO() {
		return HJ_GWAO;
	}
	public void setHJ_GWAO(String hJ_GWAO) {
		HJ_GWAO = hJ_GWAO;
	}
	public String getJJ_GWAO() {
		return JJ_GWAO;
	}
	public void setJJ_GWAO(String jJ_GWAO) {
		JJ_GWAO = jJ_GWAO;
	}
	public String getJJ_NAPIP_IJA() {
		return JJ_NAPIP_IJA;
	}
	public void setJJ_NAPIP_IJA(String jJ_NAPIP_IJA) {
		JJ_NAPIP_IJA = jJ_NAPIP_IJA;
	}
	public String getJJ_GWAO_F() {
		return JJ_GWAO_F;
	}
	public void setJJ_GWAO_F(String jJ_GWAO_F) {
		JJ_GWAO_F = jJ_GWAO_F;
	}
	public String getJJ_GWAO_T() {
		return JJ_GWAO_T;
	}
	public void setJJ_GWAO_T(String jJ_GWAO_T) {
		JJ_GWAO_T = jJ_GWAO_T;
	}
	public String getJJ_GWAO_ILSU() {
		return JJ_GWAO_ILSU;
	}
	public void setJJ_GWAO_ILSU(String jJ_GWAO_ILSU) {
		JJ_GWAO_ILSU = jJ_GWAO_ILSU;
	}
	public String getProid() {
		return proid;
	}
	public String getTrid() {
		return trid;
	}
		
	
}