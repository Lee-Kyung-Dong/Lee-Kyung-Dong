package com.idongbu.smartcustomer.vo;

import java.util.List;
import java.util.Map;

import com.idongbu.common.vo.CMMVO;

public class CmmFUC2031RVO extends CMMVO {
	
	public CmmFUC2031RVO() {
		super.setPGMID(this.proid);
		super.setTRID(this.trid);
	}
	
	public static final String proid		= "FUC2031R";
	public static final String trid		= "UC2V";
	public String rURL						= "";
	
	public String CC_CHANNEL = null;
	public String CC_UKEY = null;
	public String CC_PGMID = null;
	public String CC_PROC_GB = null;
	public String CC_FUN_KEY = null;
	public String CC_USER_GB = null;
	public String CC_USER_CD = null;
	public String CC_JIJUM_CD = null;
	public String CC_JIBU_CD = null;
	public String CC_PROTOCOL = null;
	public String CC_COND_CD = null;
	public String CC_LAST_FLAG = null;
	public String CC_CURSOR_MAP = null;
	public String CC_CURSOR_IDX = null;
	public String CC_MESSAGE_CD = null;
	public String HC_MESSAGE_NM = null;
	public String CC_SYS_ERR = null;
	public String CC_TS_ITEM = null;
	public String CC_FORM_ID = null;
	public String CC_PRT_GB = null;
	public String CC_PRINT_GB = null;
	public String CC_PRINT_TYPE = null;
	public String CC_FILLER = null;
	
	public String JJ_POLI_NO = null; //증권번호
	public String JJ_PROC_YMD = null;
	public String JJ_PROC_GUBUN = null;
	public String JJ_JIJUM_CD = null;
	public String HJ_JIJUM_NAME = null;
	public String JJ_SAWON_NO = null;
	public String HJ_SAWON_NAME = null;
	public String JJ_PASSWORD = null;
	public String JJ_SLIP_NO = null;
	public String JJ_JUPSU_JIJUM_CD = null;
	public String JJ_JUPSU_SAWON_NO = null;
	
	public String JJ_BJ_CD = null;
	public String HJ_BJ_NAME = null; //상품명
	public String HJ_BJ_TYPE = null;
	public String HJ_SANGTE_NAME = null;
	public String JJ_SANGTE_JIJUM = null;
	public String JJ_SANGTE_YMD = null;
	public String HJ_GYEYAKJA_NAME = null; //계약자명
	public String HJ_GEBUPIN_GUBUN = null;
	public String JJ_GYEYAKJA_ID = null;
	public String HJ_MANGIJA_NAME = null;
	public String JJ_MANGIJA_ID = null;
	public String HJ_PIBO_NAME = null; //피보험자명
	public String JJ_PIBO_ID = null;
	public String JJ_BOHUM_SYMD = null; //보험시기
	public String JJ_BOHUM_EYMD = null; //보험종기
	public String JJ_NAPIP_YCNT = null;
	public String JJ_GUCHI_YCNT = null;
	public String JJ_MANGI_YCNT = null;
	public String JJ_TOT_JIGPGM = null;
	public String JJ_LAST_NAPIP_YM = null;
	public String HJ_NAPBANG_NAME = null;
	public String JJ_NAPIPHAL_PRM = null;
	public String JJ_TOT_NAPIP_CNT = null;
	public String JJ_LAST_NAPIP_CNT = null;
	public String JJ_TOT_NAPIP_PRM = null;
	public String JJ_SG_JIJUM_CD = null;
	public String JJ_SG_JIBU_CD = null;
	public String JJ_SG_SAWON_NO = null;
	public String HJ_SG_JIJUM_NAME = null;
	public String HJ_SG_JIBU_NAME = null;
	public String HJ_SG_SAWON_NAME = null;
	public String HJ_SG_DERIJUMJU = null;
	public String JJ_SG_TEL_NO = null;
	public String JJ_INCHUL_SU1 = null;
	public String JJ_INCHUL_SU2 = null;
	public String JJ_INCHUL_SU3 = null;
	public String JJ_INCHUL_TOT = null;
	public String JJ_INCHUL_GUBUN = null;
	public String JJ_MANGI_GM = null;
	public String JJ_MANGI_YUL = null;
	public String JJ_JUKLIP_TOT = null;
	public String JJ_HANDO_AMT = null; //신청금액
	public String JJ_YOCHUNG_AMT = null;
	public String JJ_GASU_AMT = null;
	public String JJ_SILJIGP_AMT = null;
	public String JJ_YESU_AMT = null;
	public String JJ_GASU_JIJUM = null;
	public String JJ_GWANGE_CD = null;
	public String HJ_GWANGE_NAME = null;
	public String HJ_SURYUNG_NAME = null;
	public String JJ_SURYUNG_ID = null;
	public String JJ_WIIM_FLAG = null;
	public String HJ_WIIM_NAME = null;
	public String JJ_SANGDE_CD = null;
	public String HJ_SANGDE_NAME = null;
	public String HJ_YEGMJU_NAME = null;
	public String JJ_YEGMJU_ID = null;
	public String JJ_CHECK_FLAG = null;
	public String HJ_CHECK_NAME = null;
	public String JJ_BANK_CD = null;
	public String HJ_BANK_NAME = null;
	public String JJ_GYEJWA_NO = null;
	public String JJ_CONFIRM = null;
	public String JJ_K_YMD = null;
	public String JJ_K_HMS = null;
	public String JJ_K_JIJUM_CD = null;
	public String HJ_K_JIJUM_NAME = null;
	public String JJ_K_SAWON_NO = null;
	public String HJ_K_SAWON_NAME = null;
	public String HJ_REMARK = null;
	public String JJ_VIS_CD = null;
	public String JJ_SM_CHECK = null;
	public String JJ_FILLER = null;
	public String UU_POLI_NO = null;
	public String UU_FUC2031R_PRT = null;
	public String UU_PRT_DATA1 = null;
	public String UU_PRT_DATA2 = null;
	public String UU_PRT_DATA3 = null;
	public String RD_POLICY_YN = null;
	public String RD_COPY_YN = null;
	public String RD_GREEN_YN = null;
	public String RD_ENCRYPT_YN = null;
	public String RD_ENCRYPT_KEY = null;
	public String RD_UPMU_GB = null;
	public String RD_DOCU_GB = null;
	public String RD_SIGN_KEY = null;
	public String RD_FORM_GB = null;
	public String getrURL() {
		return rURL;
	}
	public void setrURL(String rURL) {
		this.rURL = rURL;
	}
	public String getCC_CHANNEL() {
		return CC_CHANNEL;
	}
	public void setCC_CHANNEL(String cC_CHANNEL) {
		CC_CHANNEL = cC_CHANNEL;
	}
	public String getCC_UKEY() {
		return CC_UKEY;
	}
	public void setCC_UKEY(String cC_UKEY) {
		CC_UKEY = cC_UKEY;
	}
	public String getCC_PGMID() {
		return CC_PGMID;
	}
	public void setCC_PGMID(String cC_PGMID) {
		CC_PGMID = cC_PGMID;
	}
	public String getCC_PROC_GB() {
		return CC_PROC_GB;
	}
	public void setCC_PROC_GB(String cC_PROC_GB) {
		CC_PROC_GB = cC_PROC_GB;
	}
	public String getCC_FUN_KEY() {
		return CC_FUN_KEY;
	}
	public void setCC_FUN_KEY(String cC_FUN_KEY) {
		CC_FUN_KEY = cC_FUN_KEY;
	}
	public String getCC_USER_GB() {
		return CC_USER_GB;
	}
	public void setCC_USER_GB(String cC_USER_GB) {
		CC_USER_GB = cC_USER_GB;
	}
	public String getCC_USER_CD() {
		return CC_USER_CD;
	}
	public void setCC_USER_CD(String cC_USER_CD) {
		CC_USER_CD = cC_USER_CD;
	}
	public String getCC_JIJUM_CD() {
		return CC_JIJUM_CD;
	}
	public void setCC_JIJUM_CD(String cC_JIJUM_CD) {
		CC_JIJUM_CD = cC_JIJUM_CD;
	}
	public String getCC_JIBU_CD() {
		return CC_JIBU_CD;
	}
	public void setCC_JIBU_CD(String cC_JIBU_CD) {
		CC_JIBU_CD = cC_JIBU_CD;
	}
	public String getCC_PROTOCOL() {
		return CC_PROTOCOL;
	}
	public void setCC_PROTOCOL(String cC_PROTOCOL) {
		CC_PROTOCOL = cC_PROTOCOL;
	}
	public String getCC_COND_CD() {
		return CC_COND_CD;
	}
	public void setCC_COND_CD(String cC_COND_CD) {
		CC_COND_CD = cC_COND_CD;
	}
	public String getCC_LAST_FLAG() {
		return CC_LAST_FLAG;
	}
	public void setCC_LAST_FLAG(String cC_LAST_FLAG) {
		CC_LAST_FLAG = cC_LAST_FLAG;
	}
	public String getCC_CURSOR_MAP() {
		return CC_CURSOR_MAP;
	}
	public void setCC_CURSOR_MAP(String cC_CURSOR_MAP) {
		CC_CURSOR_MAP = cC_CURSOR_MAP;
	}
	public String getCC_CURSOR_IDX() {
		return CC_CURSOR_IDX;
	}
	public void setCC_CURSOR_IDX(String cC_CURSOR_IDX) {
		CC_CURSOR_IDX = cC_CURSOR_IDX;
	}
	public String getCC_MESSAGE_CD() {
		return CC_MESSAGE_CD;
	}
	public void setCC_MESSAGE_CD(String cC_MESSAGE_CD) {
		CC_MESSAGE_CD = cC_MESSAGE_CD;
	}
	public String getHC_MESSAGE_NM() {
		return HC_MESSAGE_NM;
	}
	public void setHC_MESSAGE_NM(String hC_MESSAGE_NM) {
		HC_MESSAGE_NM = hC_MESSAGE_NM;
	}
	public String getCC_SYS_ERR() {
		return CC_SYS_ERR;
	}
	public void setCC_SYS_ERR(String cC_SYS_ERR) {
		CC_SYS_ERR = cC_SYS_ERR;
	}
	public String getCC_TS_ITEM() {
		return CC_TS_ITEM;
	}
	public void setCC_TS_ITEM(String cC_TS_ITEM) {
		CC_TS_ITEM = cC_TS_ITEM;
	}
	public String getCC_FORM_ID() {
		return CC_FORM_ID;
	}
	public void setCC_FORM_ID(String cC_FORM_ID) {
		CC_FORM_ID = cC_FORM_ID;
	}
	public String getCC_PRT_GB() {
		return CC_PRT_GB;
	}
	public void setCC_PRT_GB(String cC_PRT_GB) {
		CC_PRT_GB = cC_PRT_GB;
	}
	public String getCC_PRINT_GB() {
		return CC_PRINT_GB;
	}
	public void setCC_PRINT_GB(String cC_PRINT_GB) {
		CC_PRINT_GB = cC_PRINT_GB;
	}
	public String getCC_PRINT_TYPE() {
		return CC_PRINT_TYPE;
	}
	public void setCC_PRINT_TYPE(String cC_PRINT_TYPE) {
		CC_PRINT_TYPE = cC_PRINT_TYPE;
	}
	public String getCC_FILLER() {
		return CC_FILLER;
	}
	public void setCC_FILLER(String cC_FILLER) {
		CC_FILLER = cC_FILLER;
	}
	public String getJJ_POLI_NO() {
		return JJ_POLI_NO;
	}
	public void setJJ_POLI_NO(String jJ_POLI_NO) {
		JJ_POLI_NO = jJ_POLI_NO;
	}
	public String getJJ_PROC_YMD() {
		return JJ_PROC_YMD;
	}
	public void setJJ_PROC_YMD(String jJ_PROC_YMD) {
		JJ_PROC_YMD = jJ_PROC_YMD;
	}
	public String getJJ_PROC_GUBUN() {
		return JJ_PROC_GUBUN;
	}
	public void setJJ_PROC_GUBUN(String jJ_PROC_GUBUN) {
		JJ_PROC_GUBUN = jJ_PROC_GUBUN;
	}
	public String getJJ_JIJUM_CD() {
		return JJ_JIJUM_CD;
	}
	public void setJJ_JIJUM_CD(String jJ_JIJUM_CD) {
		JJ_JIJUM_CD = jJ_JIJUM_CD;
	}
	public String getHJ_JIJUM_NAME() {
		return HJ_JIJUM_NAME;
	}
	public void setHJ_JIJUM_NAME(String hJ_JIJUM_NAME) {
		HJ_JIJUM_NAME = hJ_JIJUM_NAME;
	}
	public String getJJ_SAWON_NO() {
		return JJ_SAWON_NO;
	}
	public void setJJ_SAWON_NO(String jJ_SAWON_NO) {
		JJ_SAWON_NO = jJ_SAWON_NO;
	}
	public String getHJ_SAWON_NAME() {
		return HJ_SAWON_NAME;
	}
	public void setHJ_SAWON_NAME(String hJ_SAWON_NAME) {
		HJ_SAWON_NAME = hJ_SAWON_NAME;
	}
	public String getJJ_PASSWORD() {
		return JJ_PASSWORD;
	}
	public void setJJ_PASSWORD(String jJ_PASSWORD) {
		JJ_PASSWORD = jJ_PASSWORD;
	}
	public String getJJ_SLIP_NO() {
		return JJ_SLIP_NO;
	}
	public void setJJ_SLIP_NO(String jJ_SLIP_NO) {
		JJ_SLIP_NO = jJ_SLIP_NO;
	}
	public String getJJ_JUPSU_JIJUM_CD() {
		return JJ_JUPSU_JIJUM_CD;
	}
	public void setJJ_JUPSU_JIJUM_CD(String jJ_JUPSU_JIJUM_CD) {
		JJ_JUPSU_JIJUM_CD = jJ_JUPSU_JIJUM_CD;
	}
	public String getJJ_JUPSU_SAWON_NO() {
		return JJ_JUPSU_SAWON_NO;
	}
	public void setJJ_JUPSU_SAWON_NO(String jJ_JUPSU_SAWON_NO) {
		JJ_JUPSU_SAWON_NO = jJ_JUPSU_SAWON_NO;
	}
	public String getJJ_BJ_CD() {
		return JJ_BJ_CD;
	}
	public void setJJ_BJ_CD(String jJ_BJ_CD) {
		JJ_BJ_CD = jJ_BJ_CD;
	}
	public String getHJ_BJ_NAME() {
		return HJ_BJ_NAME;
	}
	public void setHJ_BJ_NAME(String hJ_BJ_NAME) {
		HJ_BJ_NAME = hJ_BJ_NAME;
	}
	public String getHJ_BJ_TYPE() {
		return HJ_BJ_TYPE;
	}
	public void setHJ_BJ_TYPE(String hJ_BJ_TYPE) {
		HJ_BJ_TYPE = hJ_BJ_TYPE;
	}
	public String getHJ_SANGTE_NAME() {
		return HJ_SANGTE_NAME;
	}
	public void setHJ_SANGTE_NAME(String hJ_SANGTE_NAME) {
		HJ_SANGTE_NAME = hJ_SANGTE_NAME;
	}
	public String getJJ_SANGTE_JIJUM() {
		return JJ_SANGTE_JIJUM;
	}
	public void setJJ_SANGTE_JIJUM(String jJ_SANGTE_JIJUM) {
		JJ_SANGTE_JIJUM = jJ_SANGTE_JIJUM;
	}
	public String getJJ_SANGTE_YMD() {
		return JJ_SANGTE_YMD;
	}
	public void setJJ_SANGTE_YMD(String jJ_SANGTE_YMD) {
		JJ_SANGTE_YMD = jJ_SANGTE_YMD;
	}
	public String getHJ_GYEYAKJA_NAME() {
		return HJ_GYEYAKJA_NAME;
	}
	public void setHJ_GYEYAKJA_NAME(String hJ_GYEYAKJA_NAME) {
		HJ_GYEYAKJA_NAME = hJ_GYEYAKJA_NAME;
	}
	public String getHJ_GEBUPIN_GUBUN() {
		return HJ_GEBUPIN_GUBUN;
	}
	public void setHJ_GEBUPIN_GUBUN(String hJ_GEBUPIN_GUBUN) {
		HJ_GEBUPIN_GUBUN = hJ_GEBUPIN_GUBUN;
	}
	public String getJJ_GYEYAKJA_ID() {
		return JJ_GYEYAKJA_ID;
	}
	public void setJJ_GYEYAKJA_ID(String jJ_GYEYAKJA_ID) {
		JJ_GYEYAKJA_ID = jJ_GYEYAKJA_ID;
	}
	public String getHJ_MANGIJA_NAME() {
		return HJ_MANGIJA_NAME;
	}
	public void setHJ_MANGIJA_NAME(String hJ_MANGIJA_NAME) {
		HJ_MANGIJA_NAME = hJ_MANGIJA_NAME;
	}
	public String getJJ_MANGIJA_ID() {
		return JJ_MANGIJA_ID;
	}
	public void setJJ_MANGIJA_ID(String jJ_MANGIJA_ID) {
		JJ_MANGIJA_ID = jJ_MANGIJA_ID;
	}
	public String getHJ_PIBO_NAME() {
		return HJ_PIBO_NAME;
	}
	public void setHJ_PIBO_NAME(String hJ_PIBO_NAME) {
		HJ_PIBO_NAME = hJ_PIBO_NAME;
	}
	public String getJJ_PIBO_ID() {
		return JJ_PIBO_ID;
	}
	public void setJJ_PIBO_ID(String jJ_PIBO_ID) {
		JJ_PIBO_ID = jJ_PIBO_ID;
	}
	public String getJJ_BOHUM_SYMD() {
		return JJ_BOHUM_SYMD;
	}
	public void setJJ_BOHUM_SYMD(String jJ_BOHUM_SYMD) {
		JJ_BOHUM_SYMD = jJ_BOHUM_SYMD;
	}
	public String getJJ_BOHUM_EYMD() {
		return JJ_BOHUM_EYMD;
	}
	public void setJJ_BOHUM_EYMD(String jJ_BOHUM_EYMD) {
		JJ_BOHUM_EYMD = jJ_BOHUM_EYMD;
	}
	public String getJJ_NAPIP_YCNT() {
		return JJ_NAPIP_YCNT;
	}
	public void setJJ_NAPIP_YCNT(String jJ_NAPIP_YCNT) {
		JJ_NAPIP_YCNT = jJ_NAPIP_YCNT;
	}
	public String getJJ_GUCHI_YCNT() {
		return JJ_GUCHI_YCNT;
	}
	public void setJJ_GUCHI_YCNT(String jJ_GUCHI_YCNT) {
		JJ_GUCHI_YCNT = jJ_GUCHI_YCNT;
	}
	public String getJJ_MANGI_YCNT() {
		return JJ_MANGI_YCNT;
	}
	public void setJJ_MANGI_YCNT(String jJ_MANGI_YCNT) {
		JJ_MANGI_YCNT = jJ_MANGI_YCNT;
	}
	public String getJJ_TOT_JIGPGM() {
		return JJ_TOT_JIGPGM;
	}
	public void setJJ_TOT_JIGPGM(String jJ_TOT_JIGPGM) {
		JJ_TOT_JIGPGM = jJ_TOT_JIGPGM;
	}
	public String getJJ_LAST_NAPIP_YM() {
		return JJ_LAST_NAPIP_YM;
	}
	public void setJJ_LAST_NAPIP_YM(String jJ_LAST_NAPIP_YM) {
		JJ_LAST_NAPIP_YM = jJ_LAST_NAPIP_YM;
	}
	public String getHJ_NAPBANG_NAME() {
		return HJ_NAPBANG_NAME;
	}
	public void setHJ_NAPBANG_NAME(String hJ_NAPBANG_NAME) {
		HJ_NAPBANG_NAME = hJ_NAPBANG_NAME;
	}
	public String getJJ_NAPIPHAL_PRM() {
		return JJ_NAPIPHAL_PRM;
	}
	public void setJJ_NAPIPHAL_PRM(String jJ_NAPIPHAL_PRM) {
		JJ_NAPIPHAL_PRM = jJ_NAPIPHAL_PRM;
	}
	public String getJJ_TOT_NAPIP_CNT() {
		return JJ_TOT_NAPIP_CNT;
	}
	public void setJJ_TOT_NAPIP_CNT(String jJ_TOT_NAPIP_CNT) {
		JJ_TOT_NAPIP_CNT = jJ_TOT_NAPIP_CNT;
	}
	public String getJJ_LAST_NAPIP_CNT() {
		return JJ_LAST_NAPIP_CNT;
	}
	public void setJJ_LAST_NAPIP_CNT(String jJ_LAST_NAPIP_CNT) {
		JJ_LAST_NAPIP_CNT = jJ_LAST_NAPIP_CNT;
	}
	public String getJJ_TOT_NAPIP_PRM() {
		return JJ_TOT_NAPIP_PRM;
	}
	public void setJJ_TOT_NAPIP_PRM(String jJ_TOT_NAPIP_PRM) {
		JJ_TOT_NAPIP_PRM = jJ_TOT_NAPIP_PRM;
	}
	public String getJJ_SG_JIJUM_CD() {
		return JJ_SG_JIJUM_CD;
	}
	public void setJJ_SG_JIJUM_CD(String jJ_SG_JIJUM_CD) {
		JJ_SG_JIJUM_CD = jJ_SG_JIJUM_CD;
	}
	public String getJJ_SG_JIBU_CD() {
		return JJ_SG_JIBU_CD;
	}
	public void setJJ_SG_JIBU_CD(String jJ_SG_JIBU_CD) {
		JJ_SG_JIBU_CD = jJ_SG_JIBU_CD;
	}
	public String getJJ_SG_SAWON_NO() {
		return JJ_SG_SAWON_NO;
	}
	public void setJJ_SG_SAWON_NO(String jJ_SG_SAWON_NO) {
		JJ_SG_SAWON_NO = jJ_SG_SAWON_NO;
	}
	public String getHJ_SG_JIJUM_NAME() {
		return HJ_SG_JIJUM_NAME;
	}
	public void setHJ_SG_JIJUM_NAME(String hJ_SG_JIJUM_NAME) {
		HJ_SG_JIJUM_NAME = hJ_SG_JIJUM_NAME;
	}
	public String getHJ_SG_JIBU_NAME() {
		return HJ_SG_JIBU_NAME;
	}
	public void setHJ_SG_JIBU_NAME(String hJ_SG_JIBU_NAME) {
		HJ_SG_JIBU_NAME = hJ_SG_JIBU_NAME;
	}
	public String getHJ_SG_SAWON_NAME() {
		return HJ_SG_SAWON_NAME;
	}
	public void setHJ_SG_SAWON_NAME(String hJ_SG_SAWON_NAME) {
		HJ_SG_SAWON_NAME = hJ_SG_SAWON_NAME;
	}
	public String getHJ_SG_DERIJUMJU() {
		return HJ_SG_DERIJUMJU;
	}
	public void setHJ_SG_DERIJUMJU(String hJ_SG_DERIJUMJU) {
		HJ_SG_DERIJUMJU = hJ_SG_DERIJUMJU;
	}
	public String getJJ_SG_TEL_NO() {
		return JJ_SG_TEL_NO;
	}
	public void setJJ_SG_TEL_NO(String jJ_SG_TEL_NO) {
		JJ_SG_TEL_NO = jJ_SG_TEL_NO;
	}
	public String getJJ_INCHUL_SU1() {
		return JJ_INCHUL_SU1;
	}
	public void setJJ_INCHUL_SU1(String jJ_INCHUL_SU1) {
		JJ_INCHUL_SU1 = jJ_INCHUL_SU1;
	}
	public String getJJ_INCHUL_SU2() {
		return JJ_INCHUL_SU2;
	}
	public void setJJ_INCHUL_SU2(String jJ_INCHUL_SU2) {
		JJ_INCHUL_SU2 = jJ_INCHUL_SU2;
	}
	public String getJJ_INCHUL_SU3() {
		return JJ_INCHUL_SU3;
	}
	public void setJJ_INCHUL_SU3(String jJ_INCHUL_SU3) {
		JJ_INCHUL_SU3 = jJ_INCHUL_SU3;
	}
	public String getJJ_INCHUL_TOT() {
		return JJ_INCHUL_TOT;
	}
	public void setJJ_INCHUL_TOT(String jJ_INCHUL_TOT) {
		JJ_INCHUL_TOT = jJ_INCHUL_TOT;
	}
	public String getJJ_INCHUL_GUBUN() {
		return JJ_INCHUL_GUBUN;
	}
	public void setJJ_INCHUL_GUBUN(String jJ_INCHUL_GUBUN) {
		JJ_INCHUL_GUBUN = jJ_INCHUL_GUBUN;
	}
	public String getJJ_MANGI_GM() {
		return JJ_MANGI_GM;
	}
	public void setJJ_MANGI_GM(String jJ_MANGI_GM) {
		JJ_MANGI_GM = jJ_MANGI_GM;
	}
	public String getJJ_MANGI_YUL() {
		return JJ_MANGI_YUL;
	}
	public void setJJ_MANGI_YUL(String jJ_MANGI_YUL) {
		JJ_MANGI_YUL = jJ_MANGI_YUL;
	}
	public String getJJ_JUKLIP_TOT() {
		return JJ_JUKLIP_TOT;
	}
	public void setJJ_JUKLIP_TOT(String jJ_JUKLIP_TOT) {
		JJ_JUKLIP_TOT = jJ_JUKLIP_TOT;
	}
	public String getJJ_HANDO_AMT() {
		return JJ_HANDO_AMT;
	}
	public void setJJ_HANDO_AMT(String jJ_HANDO_AMT) {
		JJ_HANDO_AMT = jJ_HANDO_AMT;
	}
	public String getJJ_YOCHUNG_AMT() {
		return JJ_YOCHUNG_AMT;
	}
	public void setJJ_YOCHUNG_AMT(String jJ_YOCHUNG_AMT) {
		JJ_YOCHUNG_AMT = jJ_YOCHUNG_AMT;
	}
	public String getJJ_GASU_AMT() {
		return JJ_GASU_AMT;
	}
	public void setJJ_GASU_AMT(String jJ_GASU_AMT) {
		JJ_GASU_AMT = jJ_GASU_AMT;
	}
	public String getJJ_SILJIGP_AMT() {
		return JJ_SILJIGP_AMT;
	}
	public void setJJ_SILJIGP_AMT(String jJ_SILJIGP_AMT) {
		JJ_SILJIGP_AMT = jJ_SILJIGP_AMT;
	}
	public String getJJ_YESU_AMT() {
		return JJ_YESU_AMT;
	}
	public void setJJ_YESU_AMT(String jJ_YESU_AMT) {
		JJ_YESU_AMT = jJ_YESU_AMT;
	}
	public String getJJ_GASU_JIJUM() {
		return JJ_GASU_JIJUM;
	}
	public void setJJ_GASU_JIJUM(String jJ_GASU_JIJUM) {
		JJ_GASU_JIJUM = jJ_GASU_JIJUM;
	}
	public String getJJ_GWANGE_CD() {
		return JJ_GWANGE_CD;
	}
	public void setJJ_GWANGE_CD(String jJ_GWANGE_CD) {
		JJ_GWANGE_CD = jJ_GWANGE_CD;
	}
	public String getHJ_GWANGE_NAME() {
		return HJ_GWANGE_NAME;
	}
	public void setHJ_GWANGE_NAME(String hJ_GWANGE_NAME) {
		HJ_GWANGE_NAME = hJ_GWANGE_NAME;
	}
	public String getHJ_SURYUNG_NAME() {
		return HJ_SURYUNG_NAME;
	}
	public void setHJ_SURYUNG_NAME(String hJ_SURYUNG_NAME) {
		HJ_SURYUNG_NAME = hJ_SURYUNG_NAME;
	}
	public String getJJ_SURYUNG_ID() {
		return JJ_SURYUNG_ID;
	}
	public void setJJ_SURYUNG_ID(String jJ_SURYUNG_ID) {
		JJ_SURYUNG_ID = jJ_SURYUNG_ID;
	}
	public String getJJ_WIIM_FLAG() {
		return JJ_WIIM_FLAG;
	}
	public void setJJ_WIIM_FLAG(String jJ_WIIM_FLAG) {
		JJ_WIIM_FLAG = jJ_WIIM_FLAG;
	}
	public String getHJ_WIIM_NAME() {
		return HJ_WIIM_NAME;
	}
	public void setHJ_WIIM_NAME(String hJ_WIIM_NAME) {
		HJ_WIIM_NAME = hJ_WIIM_NAME;
	}
	public String getJJ_SANGDE_CD() {
		return JJ_SANGDE_CD;
	}
	public void setJJ_SANGDE_CD(String jJ_SANGDE_CD) {
		JJ_SANGDE_CD = jJ_SANGDE_CD;
	}
	public String getHJ_SANGDE_NAME() {
		return HJ_SANGDE_NAME;
	}
	public void setHJ_SANGDE_NAME(String hJ_SANGDE_NAME) {
		HJ_SANGDE_NAME = hJ_SANGDE_NAME;
	}
	public String getHJ_YEGMJU_NAME() {
		return HJ_YEGMJU_NAME;
	}
	public void setHJ_YEGMJU_NAME(String hJ_YEGMJU_NAME) {
		HJ_YEGMJU_NAME = hJ_YEGMJU_NAME;
	}
	public String getJJ_YEGMJU_ID() {
		return JJ_YEGMJU_ID;
	}
	public void setJJ_YEGMJU_ID(String jJ_YEGMJU_ID) {
		JJ_YEGMJU_ID = jJ_YEGMJU_ID;
	}
	public String getJJ_CHECK_FLAG() {
		return JJ_CHECK_FLAG;
	}
	public void setJJ_CHECK_FLAG(String jJ_CHECK_FLAG) {
		JJ_CHECK_FLAG = jJ_CHECK_FLAG;
	}
	public String getHJ_CHECK_NAME() {
		return HJ_CHECK_NAME;
	}
	public void setHJ_CHECK_NAME(String hJ_CHECK_NAME) {
		HJ_CHECK_NAME = hJ_CHECK_NAME;
	}
	public String getJJ_BANK_CD() {
		return JJ_BANK_CD;
	}
	public void setJJ_BANK_CD(String jJ_BANK_CD) {
		JJ_BANK_CD = jJ_BANK_CD;
	}
	public String getHJ_BANK_NAME() {
		return HJ_BANK_NAME;
	}
	public void setHJ_BANK_NAME(String hJ_BANK_NAME) {
		HJ_BANK_NAME = hJ_BANK_NAME;
	}
	public String getJJ_GYEJWA_NO() {
		return JJ_GYEJWA_NO;
	}
	public void setJJ_GYEJWA_NO(String jJ_GYEJWA_NO) {
		JJ_GYEJWA_NO = jJ_GYEJWA_NO;
	}
	public String getJJ_CONFIRM() {
		return JJ_CONFIRM;
	}
	public void setJJ_CONFIRM(String jJ_CONFIRM) {
		JJ_CONFIRM = jJ_CONFIRM;
	}
	public String getJJ_K_YMD() {
		return JJ_K_YMD;
	}
	public void setJJ_K_YMD(String jJ_K_YMD) {
		JJ_K_YMD = jJ_K_YMD;
	}
	public String getJJ_K_HMS() {
		return JJ_K_HMS;
	}
	public void setJJ_K_HMS(String jJ_K_HMS) {
		JJ_K_HMS = jJ_K_HMS;
	}
	public String getJJ_K_JIJUM_CD() {
		return JJ_K_JIJUM_CD;
	}
	public void setJJ_K_JIJUM_CD(String jJ_K_JIJUM_CD) {
		JJ_K_JIJUM_CD = jJ_K_JIJUM_CD;
	}
	public String getHJ_K_JIJUM_NAME() {
		return HJ_K_JIJUM_NAME;
	}
	public void setHJ_K_JIJUM_NAME(String hJ_K_JIJUM_NAME) {
		HJ_K_JIJUM_NAME = hJ_K_JIJUM_NAME;
	}
	public String getJJ_K_SAWON_NO() {
		return JJ_K_SAWON_NO;
	}
	public void setJJ_K_SAWON_NO(String jJ_K_SAWON_NO) {
		JJ_K_SAWON_NO = jJ_K_SAWON_NO;
	}
	public String getHJ_K_SAWON_NAME() {
		return HJ_K_SAWON_NAME;
	}
	public void setHJ_K_SAWON_NAME(String hJ_K_SAWON_NAME) {
		HJ_K_SAWON_NAME = hJ_K_SAWON_NAME;
	}
	public String getHJ_REMARK() {
		return HJ_REMARK;
	}
	public void setHJ_REMARK(String hJ_REMARK) {
		HJ_REMARK = hJ_REMARK;
	}
	public String getJJ_VIS_CD() {
		return JJ_VIS_CD;
	}
	public void setJJ_VIS_CD(String jJ_VIS_CD) {
		JJ_VIS_CD = jJ_VIS_CD;
	}
	public String getJJ_SM_CHECK() {
		return JJ_SM_CHECK;
	}
	public void setJJ_SM_CHECK(String jJ_SM_CHECK) {
		JJ_SM_CHECK = jJ_SM_CHECK;
	}
	public String getJJ_FILLER() {
		return JJ_FILLER;
	}
	public void setJJ_FILLER(String jJ_FILLER) {
		JJ_FILLER = jJ_FILLER;
	}
	public String getUU_POLI_NO() {
		return UU_POLI_NO;
	}
	public void setUU_POLI_NO(String uU_POLI_NO) {
		UU_POLI_NO = uU_POLI_NO;
	}
	public String getUU_FUC2031R_PRT() {
		return UU_FUC2031R_PRT;
	}
	public void setUU_FUC2031R_PRT(String uU_FUC2031R_PRT) {
		UU_FUC2031R_PRT = uU_FUC2031R_PRT;
	}
	public String getUU_PRT_DATA1() {
		return UU_PRT_DATA1;
	}
	public void setUU_PRT_DATA1(String uU_PRT_DATA1) {
		UU_PRT_DATA1 = uU_PRT_DATA1;
	}
	public String getUU_PRT_DATA2() {
		return UU_PRT_DATA2;
	}
	public void setUU_PRT_DATA2(String uU_PRT_DATA2) {
		UU_PRT_DATA2 = uU_PRT_DATA2;
	}
	public String getUU_PRT_DATA3() {
		return UU_PRT_DATA3;
	}
	public void setUU_PRT_DATA3(String uU_PRT_DATA3) {
		UU_PRT_DATA3 = uU_PRT_DATA3;
	}
	public String getRD_POLICY_YN() {
		return RD_POLICY_YN;
	}
	public void setRD_POLICY_YN(String rD_POLICY_YN) {
		RD_POLICY_YN = rD_POLICY_YN;
	}
	public String getRD_COPY_YN() {
		return RD_COPY_YN;
	}
	public void setRD_COPY_YN(String rD_COPY_YN) {
		RD_COPY_YN = rD_COPY_YN;
	}
	public String getRD_GREEN_YN() {
		return RD_GREEN_YN;
	}
	public void setRD_GREEN_YN(String rD_GREEN_YN) {
		RD_GREEN_YN = rD_GREEN_YN;
	}
	public String getRD_ENCRYPT_YN() {
		return RD_ENCRYPT_YN;
	}
	public void setRD_ENCRYPT_YN(String rD_ENCRYPT_YN) {
		RD_ENCRYPT_YN = rD_ENCRYPT_YN;
	}
	public String getRD_ENCRYPT_KEY() {
		return RD_ENCRYPT_KEY;
	}
	public void setRD_ENCRYPT_KEY(String rD_ENCRYPT_KEY) {
		RD_ENCRYPT_KEY = rD_ENCRYPT_KEY;
	}
	public String getRD_UPMU_GB() {
		return RD_UPMU_GB;
	}
	public void setRD_UPMU_GB(String rD_UPMU_GB) {
		RD_UPMU_GB = rD_UPMU_GB;
	}
	public String getRD_DOCU_GB() {
		return RD_DOCU_GB;
	}
	public void setRD_DOCU_GB(String rD_DOCU_GB) {
		RD_DOCU_GB = rD_DOCU_GB;
	}
	public String getRD_SIGN_KEY() {
		return RD_SIGN_KEY;
	}
	public void setRD_SIGN_KEY(String rD_SIGN_KEY) {
		RD_SIGN_KEY = rD_SIGN_KEY;
	}
	public String getRD_FORM_GB() {
		return RD_FORM_GB;
	}
	public void setRD_FORM_GB(String rD_FORM_GB) {
		RD_FORM_GB = rD_FORM_GB;
	}
	public static String getProid() {
		return proid;
	}
	public static String getTrid() {
		return trid;
	}
	
}
