package com.idongbu.smartcustomer.vo;

public class SubFBM0048RVO {
	public String so_bj_gb      		= null;
	public String so_bj_cd      		= null;
	public String so_bj_cd_sebu     	= null;
	public String so_gogek_gb     		= null;
	public String ho_gye_name     		= null;
	public String ho_pib_name     		= null;
	public String so_poli_no     		= null;
	public String ho_car_no     		= null;
	public String ho_bj_nm     			= null;
	public String so_bohum_symd     	= null;
	public String so_bohum_eymd     	= null;
	public String ho_sangte_nm     		= null;
	public String so_gaip_type1     	= null;
	public String so_gaip_type2     	= null;
	public String so_chungyak_ymd     	= null;
	public String so_gye_no     		= null;
	public String so_pib_no     		= null;
	public String so_chigpja_cd     	= null;
	public String ho_pa_name     		= null;
	public String ho_sangho     		= null;
	public String so_pa_hp     			= null;
	public String so_pa_mail     		= null;
	public String so_jijum_cd     		= null;
	public String ho_jijum     			= null;
	public String so_jibu_cd     		= null;
	public String ho_jibu     			= null;
	public String so_bonbu_tel     		= null;
	public String so_jijum_tel     		= null;
	public String so_jibu_tel     		= null;
	public String so_chuljang_tel     	= null;
	public String so_pa_tel     		= null;
	public String so_ipchulgm_cd     	= null;
	public String so_iche_d     		= null;
	public String so_last_napip_ym     	= null;
	public String so_last_napip_cnt     = null;
	public String so_napip_bang_cd     	= null;
	public String ho_napip_bang_nm     	= null;
	public String so_plus2_yn     		= null;
	public String ho_ipchulgm_nm     	= null;
	public String so_jumin_no     		= null;
	public String so_phone 	    		= null;
	public String hj_bj_name 	   		= null;
	public String name		 	   		= null;
	public String phone		 	   		= null;
	public String so_bj_nm	 	   		= null;
	public String url_gubun				= null;
	
	public String ins_lcpl_dvcd				= null;
	public String ply_sqno				= null;
	
	
	public String getIns_lcpl_dvcd() {
		return ins_lcpl_dvcd;
	}
	public void setIns_lcpl_dvcd(String ins_lcpl_dvcd) {
		this.ins_lcpl_dvcd = ins_lcpl_dvcd;
	}
	public String getPly_sqno() {
		return ply_sqno;
	}
	public void setPly_sqno(String ply_sqno) {
		this.ply_sqno = ply_sqno;
	}
	public String getSo_bj_gb() {
		return so_bj_gb;
	}
	public void setSo_bj_gb(String so_bj_gb) {
		this.so_bj_gb = so_bj_gb;
	}
	public String getSo_bj_cd() {
		return so_bj_cd;
	}
	public void setSo_bj_cd(String so_bj_cd) {
		this.so_bj_cd = so_bj_cd;
	}
	public String getSo_bj_cd_sebu() {
		return so_bj_cd_sebu;
	}
	public void setSo_bj_cd_sebu(String so_bj_cd_sebu) {
		this.so_bj_cd_sebu = so_bj_cd_sebu;
	}
	public String getSo_gogek_gb() {
		return so_gogek_gb;
	}
	public void setSo_gogek_gb(String so_gogek_gb) {
		this.so_gogek_gb = so_gogek_gb;
	}
	public String getHo_gye_name() {
		return ho_gye_name;
	}
	public void setHo_gye_name(String ho_gye_name) {
		this.ho_gye_name = ho_gye_name;
	}
	public String getHo_pib_name() {
		return ho_pib_name;
	}
	public void setHo_pib_name(String ho_pib_name) {
		this.ho_pib_name = ho_pib_name;
	}
	public String getSo_poli_no() {
		return so_poli_no;
	}
	public void setSo_poli_no(String so_poli_no) {
		this.so_poli_no = so_poli_no;
	}
	public String getHo_car_no() {
		return ho_car_no;
	}
	public void setHo_car_no(String ho_car_no) {
		this.ho_car_no = ho_car_no;
	}
	public String getHo_bj_nm() {
		return ho_bj_nm;
	}
	public void setHo_bj_nm(String ho_bj_nm) {
		this.ho_bj_nm = ho_bj_nm;
	}
	public String getSo_bohum_symd() {
		return so_bohum_symd;
	}
	public void setSo_bohum_symd(String so_bohum_symd) {
		this.so_bohum_symd = so_bohum_symd;
	}
	public String getSo_bohum_eymd() {
		return so_bohum_eymd;
	}
	public void setSo_bohum_eymd(String so_bohum_eymd) {
		this.so_bohum_eymd = so_bohum_eymd;
	}
	public String getHo_sangte_nm() {
		return ho_sangte_nm;
	}
	public void setHo_sangte_nm(String ho_sangte_nm) {
		this.ho_sangte_nm = ho_sangte_nm;
	}
	public String getSo_gaip_type1() {
		return so_gaip_type1;
	}
	public void setSo_gaip_type1(String so_gaip_type1) {
		this.so_gaip_type1 = so_gaip_type1;
	}
	public String getSo_gaip_type2() {
		return so_gaip_type2;
	}
	public void setSo_gaip_type2(String so_gaip_type2) {
		this.so_gaip_type2 = so_gaip_type2;
	}
	public String getSo_chungyak_ymd() {
		return so_chungyak_ymd;
	}
	public void setSo_chungyak_ymd(String so_chungyak_ymd) {
		this.so_chungyak_ymd = so_chungyak_ymd;
	}
	public String getSo_gye_no() {
		return so_gye_no;
	}
	public void setSo_gye_no(String so_gye_no) {
		this.so_gye_no = so_gye_no;
	}
	public String getSo_pib_no() {
		return so_pib_no;
	}
	public void setSo_pib_no(String so_pib_no) {
		this.so_pib_no = so_pib_no;
	}
	public String getSo_chigpja_cd() {
		return so_chigpja_cd;
	}
	public void setSo_chigpja_cd(String so_chigpja_cd) {
		this.so_chigpja_cd = so_chigpja_cd;
	}
	public String getHo_pa_name() {
		return ho_pa_name;
	}
	public void setHo_pa_name(String ho_pa_name) {
		this.ho_pa_name = ho_pa_name;
	}
	public String getHo_sangho() {
		return ho_sangho;
	}
	public void setHo_sangho(String ho_sangho) {
		this.ho_sangho = ho_sangho;
	}
	public String getSo_pa_hp() {
		return so_pa_hp;
	}
	public void setSo_pa_hp(String so_pa_hp) {
		this.so_pa_hp = so_pa_hp;
	}
	public String getSo_pa_mail() {
		return so_pa_mail;
	}
	public void setSo_pa_mail(String so_pa_mail) {
		this.so_pa_mail = so_pa_mail;
	}
	public String getSo_jijum_cd() {
		return so_jijum_cd;
	}
	public void setSo_jijum_cd(String so_jijum_cd) {
		this.so_jijum_cd = so_jijum_cd;
	}
	public String getHo_jijum() {
		return ho_jijum;
	}
	public void setHo_jijum(String ho_jijum) {
		this.ho_jijum = ho_jijum;
	}
	public String getSo_jibu_cd() {
		return so_jibu_cd;
	}
	public void setSo_jibu_cd(String so_jibu_cd) {
		this.so_jibu_cd = so_jibu_cd;
	}
	public String getHo_jibu() {
		return ho_jibu;
	}
	public void setHo_jibu(String ho_jibu) {
		this.ho_jibu = ho_jibu;
	}
	public String getSo_bonbu_tel() {
		return so_bonbu_tel;
	}
	public void setSo_bonbu_tel(String so_bonbu_tel) {
		this.so_bonbu_tel = so_bonbu_tel;
	}
	public String getSo_jijum_tel() {
		return so_jijum_tel;
	}
	public void setSo_jijum_tel(String so_jijum_tel) {
		this.so_jijum_tel = so_jijum_tel;
	}
	public String getSo_jibu_tel() {
		return so_jibu_tel;
	}
	public void setSo_jibu_tel(String so_jibu_tel) {
		this.so_jibu_tel = so_jibu_tel;
	}
	public String getSo_chuljang_tel() {
		return so_chuljang_tel;
	}
	public void setSo_chuljang_tel(String so_chuljang_tel) {
		this.so_chuljang_tel = so_chuljang_tel;
	}
	public String getSo_pa_tel() {
		return so_pa_tel;
	}
	public void setSo_pa_tel(String so_pa_tel) {
		this.so_pa_tel = so_pa_tel;
	}
	public String getSo_ipchulgm_cd() {
		return so_ipchulgm_cd;
	}
	public void setSo_ipchulgm_cd(String so_ipchulgm_cd) {
		this.so_ipchulgm_cd = so_ipchulgm_cd;
	}
	public String getSo_iche_d() {
		return so_iche_d;
	}
	public void setSo_iche_d(String so_iche_d) {
		this.so_iche_d = so_iche_d;
	}
	public String getSo_last_napip_ym() {
		return so_last_napip_ym;
	}
	public void setSo_last_napip_ym(String so_last_napip_ym) {
		this.so_last_napip_ym = so_last_napip_ym;
	}
	public String getSo_last_napip_cnt() {
		return so_last_napip_cnt;
	}
	public void setSo_last_napip_cnt(String so_last_napip_cnt) {
		this.so_last_napip_cnt = so_last_napip_cnt;
	}
	public String getSo_napip_bang_cd() {
		return so_napip_bang_cd;
	}
	public void setSo_napip_bang_cd(String so_napip_bang_cd) {
		this.so_napip_bang_cd = so_napip_bang_cd;
	}
	public String getHo_napip_bang_nm() {
		return ho_napip_bang_nm;
	}
	public void setHo_napip_bang_nm(String ho_napip_bang_nm) {
		this.ho_napip_bang_nm = ho_napip_bang_nm;
	}
	public String getSo_plus2_yn() {
		return so_plus2_yn;
	}
	public void setSo_plus2_yn(String so_plus2_yn) {
		this.so_plus2_yn = so_plus2_yn;
	}
	public String getHo_ipchulgm_nm() {
		return ho_ipchulgm_nm;
	}
	public void setHo_ipchulgm_nm(String ho_ipchulgm_nm) {
		this.ho_ipchulgm_nm = ho_ipchulgm_nm;
	}
	public String getSo_jumin_no() {
		return so_jumin_no;
	}
	public void setSo_jumin_no(String so_jumin_no) {
		this.so_jumin_no = so_jumin_no;
	}
	public String getSo_phone() {
		return so_phone;
	}
	public void setSo_phone(String so_phone) {
		this.so_phone = so_phone;
	}
	public String getHj_bj_name() {
		return hj_bj_name;
	}
	public void setHj_bj_name(String hj_bj_name) {
		this.hj_bj_name = hj_bj_name;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getSo_bj_nm() {
		return so_bj_nm;
	}
	public void setSo_bj_nm(String so_bj_nm) {
		this.so_bj_nm = so_bj_nm;
	}
	public String getUrl_gubun() {
		return url_gubun;
	}
	public void setUrl_gubun(String url_gubun) {
		this.url_gubun = url_gubun;
	}
}
