package com.idongbu.smartcustomer.vo;

import com.idongbu.common.vo.CMMVO;


public class CmmFUC2121RVO extends CMMVO {
	
	public CmmFUC2121RVO() {
		super.setPGMID(proid);
		super.setTRID(trid);
	}
	
	private final static String proid		= "FUC2121R";
	private final static String trid		= "UCLL";
	private String rURL						= "";
	
	//CC-HEAD.
	private String CC_CHANNEL		= null;
	private String CC_UKEY		= null;
	private String CC_PGMID		= "";
	private String CC_PROC_GB		= "";
	private String CC_FUN_KEY		= "";
	
	//CC-SAWON-NO.
	private String CC_USER_GB		= "";
	private String CC_USER_CD		= "";
	
	
	//CC-JIJUM.
	private String CC_JIJUM_CD		= "";
	private String CC_JIBU_CD		= "";
	
	private String CC_PROTOCOL		= "";
	private String CC_COND_CD		= "";
	private String CC_LAST_FLAG		= "";
	private String CC_CURSOR_MAP		= "";
	private String CC_CURSOR_IDX		= "";
	private String CC_MESSAGE_CD		= "";
	private String HC_MESSAGE_NM		= "";
	private String CC_SYS_ERR		= "";
	private String CC_TS_ITEM		= "";
	private String CC_FORM_ID		= "";
	private String CC_PRT_GB		= "";
	private String CC_FILLER		= "";
	
	//JJ-SCREEN-DATA.
	//05  JJ_SCR_DATA1.
	private String JJ_POLI_NO		= "";
	private String HJ_BJ_NAME 		= "";
	private String JJ_CHERI_JIJUM		= "";// 10
	private String JJ_CHERI_SAWON 		= "";// 10
	private String JJ_PASSWORD		= "";// 10
	private String HJ_GYEYAK_NM		= "";// 10
	private String JJ_GYEYAK_NO 		= "";// 10
	private String JJ_LAST_GISAN_YMD 		= "";// 10
	private String JJ_CARD_SUKUM		= "";// 10
	private String HJ_JE_CHUNGGU_NM 		= "";// 10
	
	// 05  JJ_SCR_DATA2.
	private String JJ_SUKUM_BANGCD 		= "";// 10
	private String HJ_SUKUM_BANGNM 		= "";// 10
	private String JJ_SUNTAK_CD		= "";// 10
	private String JJ_BANK_CD 		= "";// 10
	private String HJ_BANK_NM 		= "";// 10
	private String JJ_GYEJWA_NO		= "";// 10
	private String JJ_YE_GWANGE_CD 		= "";// 10
	private String HJ_YE_GWANGE_NM		= "";// 10
	private String HJ_YEGMJU_NM 		= "";// 10
	private String JJ_YE_JUMIN		= "";// 10
	private String JJ_YEGMJU_TEL  		= "";// 10
	private String JJ_ICHE_SDD		= "";// 10

	//JJ_ICHE_SYM.
	private String JJ_ICHE_SYM 		= "";
	private String JJ_ICHE_SYY 		= "";// 10
	private String JJ_ICHE_SMM		= "";// 10
	
	private String JJ_VIS_CD  		= "";// 10	

	public String getrURL() {
		return rURL;
	}

	public void setrURL(String rURL) {
		this.rURL = rURL;
	}

	public String getCC_CHANNEL() {
		return CC_CHANNEL;
	}

	public void setCC_CHANNEL(String cC_CHANNEL) {
		CC_CHANNEL = cC_CHANNEL;
	}

	public String getCC_UKEY() {
		return CC_UKEY;
	}

	public void setCC_UKEY(String cC_UKEY) {
		CC_UKEY = cC_UKEY;
	}

	public String getCC_PGMID() {
		return CC_PGMID;
	}

	public void setCC_PGMID(String cC_PGMID) {
		CC_PGMID = cC_PGMID;
	}

	public String getCC_PROC_GB() {
		return CC_PROC_GB;
	}

	public void setCC_PROC_GB(String cC_PROC_GB) {
		CC_PROC_GB = cC_PROC_GB;
	}

	public String getCC_FUN_KEY() {
		return CC_FUN_KEY;
	}

	public void setCC_FUN_KEY(String cC_FUN_KEY) {
		CC_FUN_KEY = cC_FUN_KEY;
	}

	public String getCC_USER_GB() {
		return CC_USER_GB;
	}

	public void setCC_USER_GB(String cC_USER_GB) {
		CC_USER_GB = cC_USER_GB;
	}

	public String getCC_USER_CD() {
		return CC_USER_CD;
	}

	public void setCC_USER_CD(String cC_USER_CD) {
		CC_USER_CD = cC_USER_CD;
	}

	public String getCC_JIJUM_CD() {
		return CC_JIJUM_CD;
	}

	public void setCC_JIJUM_CD(String cC_JIJUM_CD) {
		CC_JIJUM_CD = cC_JIJUM_CD;
	}

	public String getCC_JIBU_CD() {
		return CC_JIBU_CD;
	}

	public void setCC_JIBU_CD(String cC_JIBU_CD) {
		CC_JIBU_CD = cC_JIBU_CD;
	}

	public String getCC_PROTOCOL() {
		return CC_PROTOCOL;
	}

	public void setCC_PROTOCOL(String cC_PROTOCOL) {
		CC_PROTOCOL = cC_PROTOCOL;
	}

	public String getCC_COND_CD() {
		return CC_COND_CD;
	}

	public void setCC_COND_CD(String cC_COND_CD) {
		CC_COND_CD = cC_COND_CD;
	}

	public String getCC_LAST_FLAG() {
		return CC_LAST_FLAG;
	}

	public void setCC_LAST_FLAG(String cC_LAST_FLAG) {
		CC_LAST_FLAG = cC_LAST_FLAG;
	}

	public String getCC_CURSOR_MAP() {
		return CC_CURSOR_MAP;
	}

	public void setCC_CURSOR_MAP(String cC_CURSOR_MAP) {
		CC_CURSOR_MAP = cC_CURSOR_MAP;
	}

	public String getCC_CURSOR_IDX() {
		return CC_CURSOR_IDX;
	}

	public void setCC_CURSOR_IDX(String cC_CURSOR_IDX) {
		CC_CURSOR_IDX = cC_CURSOR_IDX;
	}

	public String getCC_MESSAGE_CD() {
		return CC_MESSAGE_CD;
	}

	public void setCC_MESSAGE_CD(String cC_MESSAGE_CD) {
		CC_MESSAGE_CD = cC_MESSAGE_CD;
	}

	public String getHC_MESSAGE_NM() {
		return HC_MESSAGE_NM;
	}

	public void setHC_MESSAGE_NM(String hC_MESSAGE_NM) {
		HC_MESSAGE_NM = hC_MESSAGE_NM;
	}

	public String getCC_SYS_ERR() {
		return CC_SYS_ERR;
	}

	public void setCC_SYS_ERR(String cC_SYS_ERR) {
		CC_SYS_ERR = cC_SYS_ERR;
	}

	public String getCC_TS_ITEM() {
		return CC_TS_ITEM;
	}

	public void setCC_TS_ITEM(String cC_TS_ITEM) {
		CC_TS_ITEM = cC_TS_ITEM;
	}

	public String getCC_FORM_ID() {
		return CC_FORM_ID;
	}

	public void setCC_FORM_ID(String cC_FORM_ID) {
		CC_FORM_ID = cC_FORM_ID;
	}

	public String getCC_PRT_GB() {
		return CC_PRT_GB;
	}

	public void setCC_PRT_GB(String cC_PRT_GB) {
		CC_PRT_GB = cC_PRT_GB;
	}

	public String getCC_FILLER() {
		return CC_FILLER;
	}

	public void setCC_FILLER(String cC_FILLER) {
		CC_FILLER = cC_FILLER;
	}

	public String getJJ_POLI_NO() {
		return JJ_POLI_NO;
	}

	public void setJJ_POLI_NO(String jJ_POLI_NO) {
		JJ_POLI_NO = jJ_POLI_NO;
	}

	public String getHJ_BJ_NAME() {
		return HJ_BJ_NAME;
	}

	public void setHJ_BJ_NAME(String hJ_BJ_NAME) {
		HJ_BJ_NAME = hJ_BJ_NAME;
	}

	public String getJJ_CHERI_JIJUM() {
		return JJ_CHERI_JIJUM;
	}

	public void setJJ_CHERI_JIJUM(String jJ_CHERI_JIJUM) {
		JJ_CHERI_JIJUM = jJ_CHERI_JIJUM;
	}

	public String getJJ_CHERI_SAWON() {
		return JJ_CHERI_SAWON;
	}

	public void setJJ_CHERI_SAWON(String jJ_CHERI_SAWON) {
		JJ_CHERI_SAWON = jJ_CHERI_SAWON;
	}

	public String getJJ_PASSWORD() {
		return JJ_PASSWORD;
	}

	public void setJJ_PASSWORD(String jJ_PASSWORD) {
		JJ_PASSWORD = jJ_PASSWORD;
	}

	public String getHJ_GYEYAK_NM() {
		return HJ_GYEYAK_NM;
	}

	public void setHJ_GYEYAK_NM(String hJ_GYEYAK_NM) {
		HJ_GYEYAK_NM = hJ_GYEYAK_NM;
	}

	public String getJJ_GYEYAK_NO() {
		return JJ_GYEYAK_NO;
	}

	public void setJJ_GYEYAK_NO(String jJ_GYEYAK_NO) {
		JJ_GYEYAK_NO = jJ_GYEYAK_NO;
	}

	public String getJJ_LAST_GISAN_YMD() {
		return JJ_LAST_GISAN_YMD;
	}

	public void setJJ_LAST_GISAN_YMD(String jJ_LAST_GISAN_YMD) {
		JJ_LAST_GISAN_YMD = jJ_LAST_GISAN_YMD;
	}

	public String getJJ_CARD_SUKUM() {
		return JJ_CARD_SUKUM;
	}

	public void setJJ_CARD_SUKUM(String jJ_CARD_SUKUM) {
		JJ_CARD_SUKUM = jJ_CARD_SUKUM;
	}

	public String getHJ_JE_CHUNGGU_NM() {
		return HJ_JE_CHUNGGU_NM;
	}

	public void setHJ_JE_CHUNGGU_NM(String hJ_JE_CHUNGGU_NM) {
		HJ_JE_CHUNGGU_NM = hJ_JE_CHUNGGU_NM;
	}

	public String getJJ_SUKUM_BANGCD() {
		return JJ_SUKUM_BANGCD;
	}

	public void setJJ_SUKUM_BANGCD(String jJ_SUKUM_BANGCD) {
		JJ_SUKUM_BANGCD = jJ_SUKUM_BANGCD;
	}

	public String getHJ_SUKUM_BANGNM() {
		return HJ_SUKUM_BANGNM;
	}

	public void setHJ_SUKUM_BANGNM(String hJ_SUKUM_BANGNM) {
		HJ_SUKUM_BANGNM = hJ_SUKUM_BANGNM;
	}

	public String getJJ_SUNTAK_CD() {
		return JJ_SUNTAK_CD;
	}

	public void setJJ_SUNTAK_CD(String jJ_SUNTAK_CD) {
		JJ_SUNTAK_CD = jJ_SUNTAK_CD;
	}

	public String getJJ_BANK_CD() {
		return JJ_BANK_CD;
	}

	public void setJJ_BANK_CD(String jJ_BANK_CD) {
		JJ_BANK_CD = jJ_BANK_CD;
	}

	public String getHJ_BANK_NM() {
		return HJ_BANK_NM;
	}

	public void setHJ_BANK_NM(String hJ_BANK_NM) {
		HJ_BANK_NM = hJ_BANK_NM;
	}

	public String getJJ_GYEJWA_NO() {
		return JJ_GYEJWA_NO;
	}

	public void setJJ_GYEJWA_NO(String jJ_GYEJWA_NO) {
		JJ_GYEJWA_NO = jJ_GYEJWA_NO;
	}

	public String getJJ_YE_GWANGE_CD() {
		return JJ_YE_GWANGE_CD;
	}

	public void setJJ_YE_GWANGE_CD(String jJ_YE_GWANGE_CD) {
		JJ_YE_GWANGE_CD = jJ_YE_GWANGE_CD;
	}

	public String getHJ_YE_GWANGE_NM() {
		return HJ_YE_GWANGE_NM;
	}

	public void setHJ_YE_GWANGE_NM(String hJ_YE_GWANGE_NM) {
		HJ_YE_GWANGE_NM = hJ_YE_GWANGE_NM;
	}

	public String getHJ_YEGMJU_NM() {
		return HJ_YEGMJU_NM;
	}

	public void setHJ_YEGMJU_NM(String hJ_YEGMJU_NM) {
		HJ_YEGMJU_NM = hJ_YEGMJU_NM;
	}

	public String getJJ_YE_JUMIN() {
		return JJ_YE_JUMIN;
	}

	public void setJJ_YE_JUMIN(String jJ_YE_JUMIN) {
		JJ_YE_JUMIN = jJ_YE_JUMIN;
	}

	public String getJJ_YEGMJU_TEL() {
		return JJ_YEGMJU_TEL;
	}

	public void setJJ_YEGMJU_TEL(String jJ_YEGMJU_TEL) {
		JJ_YEGMJU_TEL = jJ_YEGMJU_TEL;
	}

	public String getJJ_ICHE_SDD() {
		return JJ_ICHE_SDD;
	}

	public void setJJ_ICHE_SDD(String jJ_ICHE_SDD) {
		JJ_ICHE_SDD = jJ_ICHE_SDD;
	}

	public String getJJ_ICHE_SYM() {
		return JJ_ICHE_SYM;
	}

	public void setJJ_ICHE_SYM(String jJ_ICHE_SYM) {
		JJ_ICHE_SYM = jJ_ICHE_SYM;
	}

	public String getJJ_ICHE_SYY() {
		return JJ_ICHE_SYY;
	}

	public void setJJ_ICHE_SYY(String jJ_ICHE_SYY) {
		JJ_ICHE_SYY = jJ_ICHE_SYY;
	}

	public String getJJ_ICHE_SMM() {
		return JJ_ICHE_SMM;
	}

	public void setJJ_ICHE_SMM(String jJ_ICHE_SMM) {
		JJ_ICHE_SMM = jJ_ICHE_SMM;
	}

	public String getJJ_VIS_CD() {
		return JJ_VIS_CD;
	}

	public void setJJ_VIS_CD(String jJ_VIS_CD) {
		JJ_VIS_CD = jJ_VIS_CD;
	}

	public String getProid() {
		return proid;
	}

	public String getTrid() {
		return trid;
	}
	
}
