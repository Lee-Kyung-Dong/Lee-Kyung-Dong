package com.idongbu.smartcustomer.vo;

//전자서명 DB 저장용 VO
public class SignatureSignVO {
	public int	seq        			= 0; //일련번호
	public String user_id           = ""; //이용자 ID
	public String jumin_no          = ""; //주민등록번호
	public String sign_date         = ""; //서명일시
	//public Date	  sign_date         = null; //서명일시
	public String system_code       = ""; //업무시스템 코드
	public String page_code         = ""; //화면코드
	public String policy_no         = ""; //증권번호
	public String policy_no2       	= ""; //가입자 증권번호
	public String in_account        = ""; //입금계좌
	public String out_account       = ""; //출금계좌
	public String client_ip      	= ""; //IP주소
	public String client_mac        = ""; //PC MAC 값
	public String pkcs7sign         = ""; //전자서명값
	public String etc_data      	= ""; //기타 정보
}
