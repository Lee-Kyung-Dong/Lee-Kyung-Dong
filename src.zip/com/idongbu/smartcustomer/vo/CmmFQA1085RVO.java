package com.idongbu.smartcustomer.vo;

import java.util.List;

import com.idongbu.common.vo.CMMVO;


// 자동차산출메인프로그램
public class CmmFQA1085RVO extends CMMVO {
	
	public CmmFQA1085RVO() {
		super.setPGMID(this.proid);
		super.setTRID(this.trid);
	}
	
	public static final String proid		= "FQA1085R";
	public static final String trid			= "QAJD";
	public String rURL						= "";
	
	public String val_yunsik 				= "";//연식(TEMP 데이터)
	
	// 입력
	// 출력에 포함된 것들..
	public String LK_GA1085_HP_TEL1_NO 		= null; // 핸드폰번호
	public String LK_GA1085_HOME_TEL2_NO 	= null; // 자택전화번호

	
	// 출력
	public String LK_GA1085_TRAN_CD 		= null;
	public String LK_GA1085_FLAG 			= null;
	public String LK_GA1085_NET_RC 			= null;
	public String LK_GA1085_TRAN_G_TIME 	= null;
	public String LK_GA1085_PARTNER_GB 		= null;
	public String LK_GA1085_PARTNER_CD 		= null;
	public String FILLER 					= null;
	public String LK_GA1085_USER_JUMIN_CD 	= null;
	public String LK_GA1085_UPMU_GB 		= null;
	public String LK_GA1085_UPMU_SEBU_GB 	= null;
	public String LK_GA1085_CONTINUE_GB 	= null;
	public String FILLER_1 					= null;
	public String LK_GA1085_RETURN_CD 		= null;
	public String LK_GA1085_MSG_CD1 		= null;
	public String LK_GA1085_MSG_CD2 		= null;
	public String H_LK_GA1085_MESSAGE1 		= null;
	public String H_LK_GA1085_MESSAGE2 		= null;
	public String LK_GA1085_POLI_NO 		= null;
	public String LK_GA1085_BJ_CD 			= null;
	public String LK_GA1085_BOHUM_GIGAN_SYMD = null;
	public String LK_GA1085_BOHUM_GIGAN_EYMD = null;
	public String LK_GA1085_INSU_GB = null;
	public String LK_GA1085_JADONG_ICHE_GB = null;
	public String LK_GA1085_JIJUM_CD = null;
	public String H_LK_GA1085_JIJUM_NAME = null;
	public String LK_GA1085_JIJUM_TEL_NO = null;
	public String LK_GA1085_JIBU_CD = null;
	public String H_LK_GA1085_JIBU_NAME = null;
	public String LK_GA1085_JIBU_TEL_NO = null;
	public String LK_GA1085_JOJIKWON_CD = null;
	public String H_LK_GA1085_JOJIKWON_NAME = null;
	public String LK_GA1085_JOJIKWON_TEL_NO = null;
	public String LK_GA1085_SULGYE_NO = null;
	public String LK_GA1085_JINHANG_GUBUN = null;
	public String H_LK_GA1085_JINHANG_NAME = null;
	public String LK_GA1085_DONGIL_GB = null;
	public String LK_GA1085_DONGIL_SAGO_GB = null;
	public String LK_GA1085_FIRST_ICHE_GB = null;
	public String LK_GA1085_GENGSIN_SAVE_GB = null;
	public String LK_GA1085_GENGSIN_JARYO_GB = null;
	public String LK_GA1085_BESU_SULGYE_NO = null;
	public String LK_GA1085_BESU_NO = null;
	public String LK_GA1085_BESU_CD = null;
	public String LK_GA1085_DEPYO_BESU_CD = null;
	public String LK_GA1085_BESU_GIJUN_YMD = null;
	public String LK_GA1085_INSU_SNGIN_GB = null;
	public String H_LK_GA1085_INSU_SNGIN_NAME = null;
	public String LK_GA1085_INSU_BULGA_GB1 = null;
	public String LK_GA1085_INSU_BULGA_GB2 = null;
	public String LK_GA1085_INSU_BULGA_GB3 = null;
	public String H_LK_GA1085_INSU_BULGA_NAME1 = null;
	public String H_LK_GA1085_INSU_BULGA_NAME2 = null;
	public String H_LK_GA1085_INSU_BULGA_NAME3 = null;
	public String LK_GA1085_YUNGSUJNG_NO = null;
	public String LK_GA1085_YUNGSU_YMD = null;
	public String LK_GA1085_GMJONG_GUBUN = null;
	public String LK_GA1085_ACCT_YMD = null;
	public String LK_GA1085_YUNGSU_PRM = null;
	public String LK_GA1085_CARD_NO = null;
	public String LK_GA1085_CARD_SNGIN_NO = null;
	public String LK_GA1085_BULIP_CNT = null;
	public String LK_GA1085_CHAHWOI_BUNNAP_YMD = null;
	public String LK_GA1085_BANK_CD = null;
	public String LK_GA1085_GYEJWA_NO = null;
	public String LK_GA1085_GYEJWA_JUMIN_NO = null;
	public String LK_GA1085_IPCHULGM_BANG_CD = null;
	public String LK_GA1085_ICHE_YMD = null;
	public String LK_GA1085_BUNNAP_BANGCD = null;
	public String LK_GA1085_BUNNAP_CNT = null;
	public String LK_GA1085_BANK_JIJUM_CD = null;
	public String FILLER_2 = null;
	public String LK_GA1085_PIB_GOGEK_NO = null;
	public String LK_GA1085_PIB_GOGEK_GB = null;
	public String LK_GA1085_PIB_CONTROL_NO = null;
	public String H_LK_GA1085_PIB_GOGEK_NAME = null;
	public String LK_GA1085_PIB_JIB_TEL_NO = null;
	public String LK_GA1085_PIB_JIB_ZIP = null;
	public String H_LK_GA1085_PIB_JIB_ADDR = null;
	public String LK_GA1085_PIB_JIB_OK_GB = null;
	public String LK_GA1085_PIB_JIK_TEL_NO = null;
	public String LK_GA1085_PIB_JIK_ZIP = null;
	public String H_LK_GA1085_PIB_JIK_ADDR = null;
	public String LK_GA1085_PIB_JIK_OK_GB = null;
	public String H_LK_GA1085_PIB_GNMUCHU_NAME = null;
	public String H_LK_GA1085_PIB_JIKWI_NAME = null;
	public String LK_GA1085_PIB_HP_TEL_NO = null;
	public String LK_GA1085_PIB_E_MAIL = null;
	public String LK_GA1085_PIB_JIYUK_GB = null;
	public String LK_GA1085_PIB_JOB_TYPE = null;
	public String LK_GA1085_PIB_JOB_CD = null;
	public String LK_GA1085_PIB_PIBOHUMJA_YN = null;
	public String LK_GA1085_PIB_YUNRYUNG = null;
	public String LK_GA1085_PIB_GYEYAKJA_YN = null;
	public String LK_GA1085_PIB_UNJUNJA_YN = null;
	public String LK_GA1085_PIB_UNJUNJA_GB = null;
	public String LK_GA1085_PIB_BUPIN_NO = null;
	public String LK_GA1085_PIB_WEGUKIN_GB = null;
	public String LK_GA1085_PIB_MYUNHE_NO = null;
	public String LK_GA1085_PIB_MYUNHE_Y = null;
	public String LK_GA1085_PIB_HPYUN_GB = null;
	public String LK_GA1085_PIB_GYULHON_YN = null;
	public String LK_GA1085_PIB_JANYUUNJUN_YN = null;
	public String FILLER_3 = null;
	public String LK_GA1085_UNJ_GOGEK_NO = null;
	public String LK_GA1085_UNJ_GOGEK_GB = null;
	public String LK_GA1085_UNJ_CONTROL_NO = null;
	public String H_LK_GA1085_UNJ_GOGEK_NAME = null;
	public String LK_GA1085_UNJ_MYUNHE_NO = null;
	public String LK_GA1085_UNJ_MYUNHE_Y = null;
	public String LK_GA1085_UNJ_GYULHON_YN = null;
	public String LK_GA1085_UNJ_YUNRYUNG = null;
	public String LK_GA1085_UNJ_JOB_TYPE = null;
	public String LK_GA1085_UNJ_JOB_CD = null;
	public String LK_GA1085_UNJ_GWANGE = null;
	public String FILLER_4 = null;
	public String LK_GA1085_GYE_GOGEK_NO = null;
	public String LK_GA1085_GYE_GOGEK_GB = null;
	public String LK_GA1085_GYE_CONTROL_NO = null;
	public String H_LK_GA1085_GYE_GOGEK_NAME = null;
	public String LK_GA1085_GYE_JIB_TEL_NO = null;
	public String LK_GA1085_GYE_JIB_ZIP = null;
	public String H_LK_GA1085_GYE_JIB_ADDR = null;
	public String LK_GA1085_GYE_JIB_OK_GB = null;
	public String LK_GA1085_GYE_JIK_TEL_NO = null;
	public String LK_GA1085_GYE_JIK_ZIP = null;
	public String H_LK_GA1085_GYE_JIK_ADDR = null;
	public String LK_GA1085_GYE_JIK_OK_GB = null;
	public String LK_GA1085_GYE_HP_TEL_NO = null;
	public String LK_GA1085_GYE_E_MAIL = null;
	public String LK_GA1085_GYE_JOB_TYPE = null;
	public String LK_GA1085_GYE_JOB_CD = null;
	public String LK_GA1085_GYE_BUPIN_NO = null;
	public String LK_GA1085_GYE_WEGUKIN_GB = null;
	public String FILLER_5 = null;
	public String LK_GA1085_GWAN_CD = null;
	public String LK_GA1085_MOKJUK_CD = null;
	public String LK_GA1085_CAR_YONGDO_CD = null;
	public String LK_GA1085_CAR_HYUNGTE_CD = null;
	public String LK_GA1085_SAYONG_YONGDO_CD = null;
	public String LK_GA1085_SAYONG_SEBU_CD = null;
	public String LK_GA1085_CHAJONG_CD = null;
	public String H_LK_GA1085_CHAJONG_NAME = null;
	public String LK_GA1085_CAR_CD = null;
	public String H_LK_GA1085_CAR_NAME = null;
	public String LK_GA1085_YUNSIK = null;
	public String LK_GA1085_BEGIRYANG = null;
	public String LK_GA1085_JUKJE_TON = null;
	public String LK_GA1085_JUNGWON_CNT = null;
	public String LK_GA1085_CHADE_NO_GB = null;
	public String LK_GA1085_CHADE_NO = null;
	public String LK_GA1085_CHULGO_YMD = null;
	public String LK_GA1085_SIDO_CD = null;
	public String LK_GA1085_BUSOKPUM_GAEK = null;
	public String LK_GA1085_GIGE_BOGAEK = null;
	public String LK_GA1085_CAR_GAEK = null;
	public String LK_GA1085_DECHA_GAIP_GMEK = null;
	public String LK_GA1085_NEW_CAR_RATE = null;
	public String LK_GA1085_OLD_CAR_RATE = null;
	public String LK_GA1085_YAGAN_JUCHA_GB = null;
	public String LK_GA1085_BEDAL_SAYONG_YN = null;
	public String LK_GA1085_CAR_GUIP_YEAR = null;
	public String LK_GA1085_TOT_JUHENG_SU = null;
	public String LK_GA1085_AIR_PASON_GB = null;
	public String LK_GA1085_TKSUJANGBI_RATE = null;
	public String LK_GA1085_DAMBO_JUHENG_SU = null;
	public String LK_GA1085_CHONG_JUHENG_SU = null;
	public String LK_GA1085_JUHENG_FIX_YMD = null;
	public String FILLER_6 = null;
	public String LK_GA1085_BUDE_JANG_YN = null;
	public String[] LK_GA1085_BUDE_JANG_GB = new String[0]; // 5
	public String[] LK_GA1085_BUDE_JANG_CD = new String[0]; // 5
	public String FILLER_7 = null;
	public String LK_GA1085_GAIP_YIM_GUNGRUK = null;
	public String LK_GA1085_GAIP_YIM_BUMWI = null;
	public String LK_GA1085_GAIP_YIM_GOTONG = null;
	public String LK_GA1085_GAIP_YIM_TOT = null;
	public String LK_GA1085_GAIP_CHK_GUNGRUK = null;
	public String LK_GA1085_GAIP_CHK_BUMWI = null;
	public String LK_GA1085_GAIP_CHK_TOT = null;
	public String LK_GA1085_HAL_CHK_HALIN = null;
	public String LK_GA1085_HAL_CHK_BUMWI = null;
	public String LK_GA1085_HAL_YIM_HALIN = null;
	public String LK_GA1085_HAL_YIM_BUMWI = null;
	public String LK_GA1085_HAL_YIM_TUKBUL = null;
	public String LK_GA1085_HAL_YIM_TUKBUL_CD = null;
	public String LK_GA1085_SAYONG_CD = null;
	public String LK_GA1085_JUN_DAMBO_CD = null;
	public String LK_GA1085_JUN_DAMBO = null;
	public String LK_GA1085_GUNGRUK_YY = null;
	public String LK_GA1085_YUL_JJ_SAYU = null;
	public String LK_GA1085_DANGI_YUL = null;
	public String LK_GA1085_HAL_CHK_TUKBUL = null;
	public String FILLER_8 = null;
	public String[] LK_GA1085_TUKYAK_CD = new String[0]; // 10
	public String[] LK_GA1085_TUKYAK_RATE = new String[0]; // 10
	public String[] LK_GA1085_TUKBUL_CD = new String[0]; // 10
	public String[] LK_GA1085_TUKBUL_RATE = new String[0]; // 10
	public String LK_GA1085_DAEIN1_YN = null;
	public String LK_GA1085_DAEIN1_GIBON_PRM = null;
	public String LK_GA1085_DAEIN1_TUKYAK_YUL = null;
	public String LK_GA1085_DAEIN1_TUKBUL_YUL = null;
	public String LK_GA1085_DAEIN1_JUKYONG_PRM = null;
	public String LK_GA1085_DAEIN1_YUNGSU_PRM = null;
	public String LK_GA1085_DAEIN2_YN = null;
	public String LK_GA1085_DAEIN2_BPER = null;
	public String LK_GA1085_DAEIN2_GIBON_PRM = null;
	public String LK_GA1085_DAEIN2_TUKYAK_YUL = null;
	public String LK_GA1085_DAEIN2_TUKBUL_YUL = null;
	public String LK_GA1085_DAEIN2_JUKYONG_PRM = null;
	public String LK_GA1085_DAEIN2_YUNGSU_PRM = null;
	public String LK_GA1085_DAEMUL_YN = null;
	public String LK_GA1085_DAEMUL_APER = null;
	public String LK_GA1085_DAEMUL_GIBON_PRM = null;
	public String LK_GA1085_DAEMUL_TUKYAK_YUL = null;
	public String LK_GA1085_DAEMUL_TUKBUL_YUL = null;
	public String LK_GA1085_DAEMUL_JUKYONG_PRM = null;
	public String LK_GA1085_DAEMUL_YUNGSU_PRM = null;
	public String LK_GA1085_JASON_YN = null;
	public String LK_GA1085_JASON_APER = null;
	public String LK_GA1085_JASON_SAMANG = null;
	public String LK_GA1085_JASON_BUSANG = null;
	public String LK_GA1085_JASON_HUYU = null;
	public String LK_GA1085_JASON_GIBON_PRM = null;
	public String LK_GA1085_JASON_TUKYAK_YUL = null;
	public String LK_GA1085_JASON_TUKBUL_YUL = null;
	public String LK_GA1085_JASON_JUKYONG_PRM = null;
	public String LK_GA1085_JASON_YUNGSU_PRM = null;
	public String LK_GA1085_JACHA_YN = null;
	public String LK_GA1085_JACHA_GAIP_GMEK = null;
	public String LK_GA1085_JACHA_GIBON_PRM = null;
	public String LK_GA1085_JACHA_TUKYAK_YUL = null;
	public String LK_GA1085_JACHA_TUKBUL_YUL = null;
	public String LK_GA1085_JACHA_JUKYONG_PRM = null;
	public String LK_GA1085_JACHA_GONGJE_GMEK = null;
	public String LK_GA1085_JACHA_YUNGSU_PRM = null;
	public String LK_GA1085_GIGE_YN = null;
	public String LK_GA1085_GIGE_GAIP_GMEK = null;
	public String LK_GA1085_GIGE_GIBON_PRM = null;
	public String LK_GA1085_GIGE_TUKYAK_YUL = null;
	public String LK_GA1085_GIGE_TUKBUL_YUL = null;
	public String LK_GA1085_GIGE_JUKYONG_PRM = null;
	public String LK_GA1085_GIGE_YUNGSU_PRM = null;
	public String LK_GA1085_MUBO_YN = null;
	public String LK_GA1085_MUBO_GAIP_GMEK	= null;		//무보험가입금액 (2009-05-06)
	public String LK_GA1085_MUBO_GIBON_PRM = null;
	public String LK_GA1085_MUBO_TUKYAK_YUL = null;
	public String LK_GA1085_MUBO_TUKBUL_YUL = null;
	public String LK_GA1085_MUBO_JUKYONG_PRM = null;
	public String LK_GA1085_MUBO_YUNGSU_PRM = null;
	public String LK_GA1085_TOT_YUNGSU_PRM = null;
	public String LK_GA1085_TAPSNGJA_GB = null;
	public String LK_GA1085_SOS_YN = null;
	public String LK_GA1085_SOS_GIBON_PRM = null;
	public String LK_GA1085_SOS_JUKYONG_PRM = null;
	public String LK_GA1085_SOS_YUNGSU_PRM = null;
	public String LK_GA1085_SANGHE_YN = null;
	public String LK_GA1085_SANGHE_GAIP_GMEK = null;
	public String LK_GA1085_RN_YN = null;
	public String LK_GA1085_SI_YN = null;
	public String LK_GA1085_JUNSON_GAIP_YN = null;
	public String LK_GA1085_GOJANG_YN = null;
	public String LK_GA1085_GOJANG_GAIP_GMEK = null;
	public String LK_GA1085_GOJANG_GIBON_PRM = null;
	public String LK_GA1085_GOJANG_TUKYAK_YUL = null;
	public String LK_GA1085_GOJANG_TUKBUL_YUL = null;
	public String LK_GA1085_GOJANG_JUKYONG_PRM = null;
	public String LK_GA1085_GOJANG_GONGJE_GMEK = null;
	public String LK_GA1085_GOJANG_YUNGSU_PRM = null;
	public String LK_GA1085_IMSIBI_YN = null;
	public String LK_GA1085_IMSIBI_GAIP_GMEK = null;
	public String LK_GA1085_DEINSAGO_YN = null;
	public String LK_GA1085_DEMULSAGO_YN = null;
	public String LK_GA1085_GAJOKLOVE_YN = null;
	public String LK_GA1085_CARLOVE_YN = null;
	public String LK_GA1085_GUNGANG_YN = null;
	public String LK_GA1085_CARWNBAN_YN = null;
	public String LK_GA1085_HPSONHE_YN = null;
	public String LK_GA1085_CARSISE_YN = null;
	public String LK_GA1085_BOHENG_YN = null;
	public String LK_GA1085_BOHENG_GAIP_GMEK = null;
	public String LK_GA1085_BYUNG_SIRYO = null;
	public String LK_GA1085_RENT_UNJUN = null;
	public String LK_GA1085_HIGH_SENSE = null;
	public String LK_GA1085_ZANYE_EDU = null;
	public String LK_GA1085_TEACHER_LOVE = null;
	public String LK_GA1085_SCHOOL = null;
	public String LK_GA1085_REMOTE_SAGO = null;
	public String LK_GA1085_FAMILY_SAGO = null;
	public String LK_GA1085_WEEK_EXTEND = null;
	public String LK_GA1085_SEAT_BELT = null;
	public String LK_GA1085_CAR_DOJANG = null;
	public String LK_GA1085_CAR_GAEK_REP = null;
	public String LK_GA1085_TACHA_UNJUN = null;
	public String LK_GA1085_GAN_BYUNG_IN = null;
	public String LK_GA1085_SIN_CHE = null;
	public String LK_GA1085_HYUNGSA_HAPBI = null;
	public String LK_GA1085_PENALTY = null;
	public String LK_GA1085_SANHAL_SUPPORT = null;
	public String LK_GA1085_SANHAL_GAIP = null;
	public String LK_GA1085_LEASE_RENT = null;
	public String LK_GA1085_LEASE_SINGA = null;
	public String LK_GA1085_JUNGJNG_GMEK = null;
	public String LK_GA1085_BUPIN_SAGO = null;
	public String LK_GA1085_CAR_SONHE = null;
	public String LK_GA1085_SON_STUDY = null;
	public String LK_GA1085_SON_GAIP = null;
	public String LK_GA1085_WEEK_SAGO = null;
	public String LK_GA1085_TUNING_YN = null;
	public String LK_GA1085_TUNING_APER = null;
	public String LK_GA1085_LEASURE = null;
	public String LK_GA1085_JOOMAL_GYUTONG = null;
	public String LK_GA1085_DAEJONG_GYUTONG = null;
	public String LK_GA1085_LEASE_UNJUN = null;
	public String LK_GA1085_JUKJE = null;
	public String LK_GA1085_REMOTE_848 = null;
	public String LK_GA1085_YUNRYUNG_BESU_GB = null;
	public String LK_GA1085_YUNRYUNG_JUN = null;
	public String LK_GA1085_YUNRYUNG_JUN_YOYUL = null;
	public String LK_GA1085_YUNRYUNG_HU = null;
	public String LK_GA1085_YUNRYUNG_HU_YOYUL = null;
	public String LK_GA1085_YUNRYUNG_YMD = null;
	public String LK_GA1085_YUNRYUNG_GOGEK_GB = null;
	public String LK_GA1085_YUNRYUNG_GOGEK_NO = null;
	public String H_LK_GA1085_YUNRYUNG_GOGEK_NM = null;
	public String LK_GA1085_BESU_SULGYE_NO2 = null;
	public String LK_GA1085_IPRYUK_GB = null;
	public String FILLER_9 = null;
	public String LK_GA1085_DAEIN1_BUNNAP = null;
	public String LK_GA1085_DAEIN2_BUNNAP = null;
	public String LK_GA1085_DAEMUL_BUNNAP = null;
	public String LK_GA1085_JASON_BUNNAP = null;
	public String LK_GA1085_JACHA_BUNNAP = null;
	public String LK_GA1085_GIGE_BUNNAP = null;
	public String LK_GA1085_MUBO_BUNNAP = null;
	public String FILLER_10 = null;
	public String LK_GA1085_BUNNAP_HWOICHA = null;
	public String LK_GA1085_BUNNAP_YMD = null;
	public String LK_GA1085_BUNNAP_TOT = null;
	public String[] LK_GA1085_HWOICHA = new String[0]; // 12
	public String[] LK_GA1085_HWOICHA_PRM = new String[0]; // 12
	public String FILLER_11 = null;
	public String LK_GA1085_PYOUNG_SAGO_GUNSU = null;
	public String LK_GA1085_YIM_FIRST = null;
	public String LK_GA1085_CHK_FIRST = null;
	public String LK_GA1085_YIM_JUKYONG = null;
	public String LK_GA1085_CHK_JUKYONG = null;
	public String LK_GA1085_TOT_JUKYONG = null;
	public String LK_GA1085_GR_YEAR_CNT = null;
	public String LK_GA1085_GR_MON_CNT = null;
	public String LK_GA1085_GR_DAY_CNT = null;
	public String LK_GA1085_DANCHE_YN = null;
	public String LK_GA1085_DANCHE_YUNGSU_GB = null;
	public String LK_GA1085_BOJNG_MUL_GUBUN = null;
	public String LK_GA1085_BEJUNG_MULGUN_YN = null;
	public String LK_GA1085_PYUNG_GIGAN_SYMD = null;
	public String LK_GA1085_PYUNG_GIGAN_EYMD = null;
	public String LK_GA1085_3_YEAR_GIGAN_SYMD = null;
	public String LK_GA1085_3_YEAR_GIGAN_EYMD = null;
	public String LK_GA1085_TOT_SAGO_GUN = null;
	public String LK_GA1085_TOT_SAGO_JUMSU = null;
	public String LK_GA1085_3_YEAR_SAGO_GUN = null;
	public String LK_GA1085_JUNGDAE_SAGO_YN = null;
	public String LK_GA1085_AVE_SONHAE_YUL = null;
	public String LK_GA1085_BUBO_CNT = null;
	public String LK_GA1085_CHK_JONG_GB = null;
	public String LK_GA1085_DAEIN_SAGO_GUN = null;
	public String LK_GA1085_JASON_SAGO_GUN = null;
	public String LK_GA1085_DAEMUL_SAGO_GUN = null;
	public String LK_GA1085_JUCHI_SAGO_GUN = null;
	public String LK_GA1085_YAKMUL_SAGO_GUN = null;
	public String LK_GA1085_WIJANG_SAGO_GUN = null;
	public String LK_GA1085_DOJU_SAGO_GUN = null;
	public String LK_GA1085_BUMJOI_SAGO_GUN = null;
	public String LK_GA1085_JUNGDAE_SAGO_GUN = null;
	public String LK_GA1085_3_DAEIN_SAGO_GUN = null;
	public String LK_GA1085_JUN_INSU_GB = null;
	public String LK_GA1085_CHAJONG_SN_GB = null;
	public String LK_GA1085_JUN_BOHUMJA_CD = null;
	public String LK_GA1085_JUN_BJ_CD = null;
	public String LK_GA1085_JUN_POLI_NO = null;
	public String LK_GA1085_JUN_GIGAN_SYMD = null;
	public String LK_GA1085_JUN_GIGAN_EYMD = null;
	public String H_LK_GA1085_JUN_JOJIKWON_NAME = null;
	public String LK_GA1085_JUN_JOJIKWON_TEL_NO = null;
	public String FILLER_12 = null;
	public String LK_GA1085_JUN_HAL_YIM_HALIN = null;
	public String LK_GA1085_JUN_HAL_YIM_BUMWI = null;
	public String LK_GA1085_JUN_HAL_CHK_HALIN = null;
	public String LK_GA1085_JUN_HAL_CHK_BUMWI = null;
	public String LK_GA1085_JUN_HAL_TUKBUL = null;
	public String LK_GA1085_JUN_HAL_TUKBUL_CD = null;
	public String LK_GA1085_JUN_GAIP_CHK_GUNGRUK = null;
	public String LK_GA1085_JUN_GAIP_CHK_BUMWI = null;
	public String LK_GA1085_JUN_GAIP_CHK_TOT = null;
	public String LK_GA1085_JUN_GAIP_YIM_GUNGRUK = null;
	public String LK_GA1085_JUN_GAIP_YIM_BUMWI = null;
	public String LK_GA1085_JUN_GAIP_YIM_GOTONG = null;
	public String LK_GA1085_JUN_GAIP_YIM_TOT = null;
	public String LK_GA1085_JONGGI_ILCHI_GB = null;
	public String LK_GA1085_SIMSA_GB = null;
	public String LK_GA1085_BOHUMJA_CD = null;
	public String LK_GA1085_GYEYAK_SANGTE_CD = null;
	public String LK_GA1085_MANGI_GENGSIN_GB = null;
	public String LK_GA1085_PLAN_GB = null;
	public String LK_GA1085_DEUNGROK_YMD = null;
	public String LK_GA1085_C_UNJ_GOGEK_NO = null;
	public String LK_GA1085_C_UNJ_GOGEK_GB = null;
	public String LK_GA1085_C_UNJ_CONTROL_NO = null;
	public String H_LK_GA1085_C_UNJ_GOGEK_NAME = null;
	public String LK_GA1085_C_UNJ_MYUNHE_NO = null;
	public String LK_GA1085_C_UNJ_MYUNHE_Y = null;
	public String LK_GA1085_C_UNJ_GYULHON_YN = null;
	public String LK_GA1085_C_UNJ_YUNRYUNG = null;
	public String LK_GA1085_C_UNJ_JOB_TYPE = null;
	public String LK_GA1085_C_UNJ_JOB_CD = null;
	public String LK_GA1085_C_UNJ_GWANGE = null;
	public String LK_GA1085_DEMUL_ILHAL_GB = null;
	public String LK_GA1085_CHANNEL_CD = null;
	public String LK_GA1085_GITA_GONGJE_GMEK = null;
	public String FILLER_13 = null;
	public String LK_GA1085_SUIKJA_GOGEKNO = null;
	public String LK_GA1085_SUIKJA_GOGEKGB = null;
	public String H_LK_GA1085_SUIKJA_NAME = null;
	public String LK_GA1085_PIBO_GWANGE = null;
	public String LK_GA1085_SUIKJA_ZIP = null;
	public String H_LK_GA1085_SUIKJA_GITA_ADDR = null;
	public String LK_GA1085_HP_TEL1_NO1 = null;
	public String LK_GA1085_HP_TEL1_NO2 = null;
	public String LK_GA1085_HP_TEL1_NO3 = null;
	public String LK_GA1085_HOME_TEL2_NO1 = null;
	public String LK_GA1085_HOME_TEL2_NO2 = null;
	public String LK_GA1085_HOME_TEL2_NO3 = null;
	public String LK_GA1085_GOTONG_803 = null;
	public String LK_GA1085_GYEONIN_806 = null;
	public String LK_GA1085_FOR_RENT_YN_807 = null;
	public String LK_GA1085_FOR_UNBAN_YN_808 = null;
	public String LK_GA1085_SINGA_VIP_YN_809 = null;
	public String LK_GA1085_GANTAK_YN_810 = null;
	public String LK_GA1085_BYUNG_VIP_YN_820 = null;
	public String LK_GA1085_GOLF_YN_893 = null;
	public String LK_GA1085_BOOKING_YN_894 = null;
	public String LK_GA1085_LIFE_YN_895 = null;
	public String[] LK_GA1085_BUSOK_CD = new String[0]; // 5
	public String[] LK_GA1085_BUSOK_GAEK = new String[0]; // 5
	public String LK_GA1085_HAL_CHK_DUNGGUP = null;
	public String LK_GA1085_HAL_YIM_DUNGGUP = null;
	public String LK_GA1085_JUN_HAL_YIM_DUNGGUP = null; 
	public String LK_GA1085_JUN_HAL_CHK_DUNGGUP = null;
	public String LK_GA1085_MODEL_DUNGGUP = null;
	public String LK_GA1085_MODEL_YUL = null;
	public String FILLER_14 = null;
	//0801제도개
	public String LK_GA1085_YN_850              =null;
	public String LK_GA1085_YN_879              =null;
	public String LK_GA1085_YN_885              =null;
	public String LK_GA1085_YN_897              =null;
	public String LK_GA1085_YN_898              =null;
	public String LK_GA1085_YN_903				= null;	//법률비용지원금II(벌금포함)가입유무(2009-05-06)
	public String LK_GA1085_YN_904				= null; //법률비용지원금II(벌금제외)가입유무(2009-05-06)
	public String LK_GA1085_903_904_GAIP_GMEK	= null; //법률비용지원금II 가입금액(2009-05-06)
	public String LK_GA1085_YN_905				= null;	//법률비용지원금Ⅲ(벌금포함)가입유무(2009-10-07)
	public String LK_GA1085_YN_906				= null; //법률비용지원금Ⅲ(벌금제외)가입유무(2009-10-07)
	public String LK_GA1085_905_906_GAIP_GMEK	= null; //법률비용지원금Ⅲ 가입금액(2009-10-07)
	public String LK_GA1085_GAJOK_PACK_GB       =null;
	public String LK_GA1085_JANYEO_PACK_GB      =null;
	public String LK_GA1085_UNJUNJA_PACK_GB     =null;
	public String LK_GA1085_NAECHA_PACK_GB      =null;
	public String LK_GA1085_JUMAL_PACK_GB       =null;
	public String LK_GA1085_JIKWON_PACK_GB      =null;
	public String LK_GA1085_FREE_PACK_GB        =null;
	
	public String LK_GA1085_MULSAGO_GIJUN_GMEK  = null;//물적사고 할증기준금액
	public String LK_GA1085_CAR_CD_IMSI_GB = null;
	
	//7월 15일 개정, 차량신가보상II 가입유무 , 2010.07.12, 박형규
	public String LK_GA1085_YN_910			= null;		//1_가입
	
	public String LK_GA1085_S_WEEK_DAY = null;				//승용차 요일제
	

	// 2011.06.29 법률지원금4 추가 , sjh
	public String LK_GA1085_BUBRUL4_GB	= null;				// 법률지원금4  구분
	public String LK_GA1085_BUBRUL4_GAIP_GMEK	= null;		// 법률지원금4  가입금액
	
	// 새주소 관련
	public String LK_GA1085_PIB_JUSO_SINGU_GB = "2";		// 피보험자　주소　신구구분（신：１，구：２）  
	public String H_LK_GA1085_PIB_JIB_ZIP_NM = null;		// 피보험자 시구동（도로명포함）（집）
	public String H_LK_GA1085_PIB_JIK_ZIP_NM = null;		// 피보험자 시구동（도로명포함）（직장)
	public String LK_GA1085_GYE_JUSO_SINGU_GB = "2";		// 계약자　주소　신구구분（신：１，구：２）
	public String H_LK_GA1085_GYE_JIB_ZIP_NM = null;	    // 계약자 시구동（도로명포함）（집）                
	public String H_LK_GA1085_GYE_JIK_ZIP_NM = null;		// 계약자 시구동（도로명포함）（직장）    
	public String LK_GA1085_SUIKJA_JUSO_SINGU_GB = "2";	// 수익자　주소　신구구분（신：１，구：２)
	public String H_LK_GA1085_SUIKJA_ZIP_NM = null;			// 수익자　주소　시구동（도로명포함)
	
	// 2011.01.12, 제도개정(책임개시일:2011.02.21) , sjh
	public String LK_GA1085_JACHA_JUNGRULJE_GB	= null;		// 자차 정률제 자기부담금 가입 			
	public String LK_GA1085_JACHA_GONGJE_RATE 	= null;		// 자차 정률제 자기부담율
	public String LK_GA1085_MIN_GONGJE_GMEK   	= null;		// 자차 정률제 최소자기부담금
	public String LK_GA1085_MAX_GONGJE_GMEK   	= null;		// 자차 정률제 최대자기부담금
	
	public String LK_GA1085_TACHA_JADONG_GB = "";			// 다른자동차운전담보자동가입구분, '1' (자동가입)'N' (비대상)' ' (표기없음)
	
	public String LK_GA1085_YN_909 			= null;		// 1_가입
	
	public String LK_GA1085_ELECTRIC_GB = null;				//전기차구분
	public String LK_GA1085_CHULRYUKRYANG  = null;			//정격출력
	public String BJ_NM				=	null;		//상품명
	public String MUBO_BJ_NM		=	null;		//
	public String GYEYAK_SANGTE_NM	=	null;		//계약상태명
	public String DAMDANG_NM		=	null;		//담당자명
	public String DAMDANG_TEL		=	null;		//담당자연락처
	public String H_LK_GA1085_MOKJUK_NAME		=	null;	
	public String SO_BJ_GB			=	null;
	public String SO_BJ_CD			=	null;
	public String SO_POLI_NO		=	null;
	public String PIB_TEL_NO		=	null;
	public String CS_NM				=	null;
	public String STR_GMEK       = null;
	public String YUNRYUNG_AGE   = null;
	public String STR_SOS_NM	 = null;
	public List<SubFQA1085RVO> LK_GA1085_TUKYAK_AREA = null;
	
	// 2014. 12. 16 외제차충돌시 대물확대 특약 신설, 이다혜
	public String LK_GA1085_FOREIGN_YN = null;
	public String LK_GA1085_FOREIGN_GAIP_GMEK	= null;
	public String STR_FOREIGN_GMEK	= null;
	
	public String sbt_drvr_cust_dcmt_no = ""; // [I/O] 대리운전자고객식별번호
	public String sbt_drve_trdr_plhd_csn_yn = ""; // [O] 대리운전업자계약자동의여부
	public String sbt_drvr_apcn_prm = ""; // [O] 대리운전자적용보험료
	public String accd_mtt = ""; // [O] 사고사항
	public String ctrmf_nts = ""; // [O] 계약변경횟수
	public String funt_key = "";
	
	public String getSO_BJ_CD() {
		return SO_BJ_CD;
	}
	public void setSO_BJ_CD(String sO_BJ_CD) {
		SO_BJ_CD = sO_BJ_CD;
	}
	public String getrURL() {
		return rURL;
	}
	public void setrURL(String rURL) {
		this.rURL = rURL;
	}
	public String getVal_yunsik() {
		return val_yunsik;
	}
	public void setVal_yunsik(String val_yunsik) {
		this.val_yunsik = val_yunsik;
	}
	public String getLK_GA1085_HP_TEL1_NO() {
		return LK_GA1085_HP_TEL1_NO;
	}
	public void setLK_GA1085_HP_TEL1_NO(String lK_GA1085_HP_TEL1_NO) {
		LK_GA1085_HP_TEL1_NO = lK_GA1085_HP_TEL1_NO;
	}
	public String getLK_GA1085_HOME_TEL2_NO() {
		return LK_GA1085_HOME_TEL2_NO;
	}
	public void setLK_GA1085_HOME_TEL2_NO(String lK_GA1085_HOME_TEL2_NO) {
		LK_GA1085_HOME_TEL2_NO = lK_GA1085_HOME_TEL2_NO;
	}
	public String getLK_GA1085_TRAN_CD() {
		return LK_GA1085_TRAN_CD;
	}
	public void setLK_GA1085_TRAN_CD(String lK_GA1085_TRAN_CD) {
		LK_GA1085_TRAN_CD = lK_GA1085_TRAN_CD;
	}
	public String getLK_GA1085_FLAG() {
		return LK_GA1085_FLAG;
	}
	public void setLK_GA1085_FLAG(String lK_GA1085_FLAG) {
		LK_GA1085_FLAG = lK_GA1085_FLAG;
	}
	public String getLK_GA1085_NET_RC() {
		return LK_GA1085_NET_RC;
	}
	public void setLK_GA1085_NET_RC(String lK_GA1085_NET_RC) {
		LK_GA1085_NET_RC = lK_GA1085_NET_RC;
	}
	public String getLK_GA1085_TRAN_G_TIME() {
		return LK_GA1085_TRAN_G_TIME;
	}
	public void setLK_GA1085_TRAN_G_TIME(String lK_GA1085_TRAN_G_TIME) {
		LK_GA1085_TRAN_G_TIME = lK_GA1085_TRAN_G_TIME;
	}
	public String getLK_GA1085_PARTNER_GB() {
		return LK_GA1085_PARTNER_GB;
	}
	public void setLK_GA1085_PARTNER_GB(String lK_GA1085_PARTNER_GB) {
		LK_GA1085_PARTNER_GB = lK_GA1085_PARTNER_GB;
	}
	public String getLK_GA1085_PARTNER_CD() {
		return LK_GA1085_PARTNER_CD;
	}
	public void setLK_GA1085_PARTNER_CD(String lK_GA1085_PARTNER_CD) {
		LK_GA1085_PARTNER_CD = lK_GA1085_PARTNER_CD;
	}
	public String getFILLER() {
		return FILLER;
	}
	public void setFILLER(String fILLER) {
		FILLER = fILLER;
	}
	public String getLK_GA1085_USER_JUMIN_CD() {
		return LK_GA1085_USER_JUMIN_CD;
	}
	public void setLK_GA1085_USER_JUMIN_CD(String lK_GA1085_USER_JUMIN_CD) {
		LK_GA1085_USER_JUMIN_CD = lK_GA1085_USER_JUMIN_CD;
	}
	public String getLK_GA1085_UPMU_GB() {
		return LK_GA1085_UPMU_GB;
	}
	public void setLK_GA1085_UPMU_GB(String lK_GA1085_UPMU_GB) {
		LK_GA1085_UPMU_GB = lK_GA1085_UPMU_GB;
	}
	public String getLK_GA1085_UPMU_SEBU_GB() {
		return LK_GA1085_UPMU_SEBU_GB;
	}
	public void setLK_GA1085_UPMU_SEBU_GB(String lK_GA1085_UPMU_SEBU_GB) {
		LK_GA1085_UPMU_SEBU_GB = lK_GA1085_UPMU_SEBU_GB;
	}
	public String getLK_GA1085_CONTINUE_GB() {
		return LK_GA1085_CONTINUE_GB;
	}
	public void setLK_GA1085_CONTINUE_GB(String lK_GA1085_CONTINUE_GB) {
		LK_GA1085_CONTINUE_GB = lK_GA1085_CONTINUE_GB;
	}
	public String getFILLER_1() {
		return FILLER_1;
	}
	public void setFILLER_1(String fILLER_1) {
		FILLER_1 = fILLER_1;
	}
	public String getLK_GA1085_RETURN_CD() {
		return LK_GA1085_RETURN_CD;
	}
	public void setLK_GA1085_RETURN_CD(String lK_GA1085_RETURN_CD) {
		LK_GA1085_RETURN_CD = lK_GA1085_RETURN_CD;
	}
	public String getLK_GA1085_MSG_CD1() {
		return LK_GA1085_MSG_CD1;
	}
	public void setLK_GA1085_MSG_CD1(String lK_GA1085_MSG_CD1) {
		LK_GA1085_MSG_CD1 = lK_GA1085_MSG_CD1;
	}
	public String getLK_GA1085_MSG_CD2() {
		return LK_GA1085_MSG_CD2;
	}
	public void setLK_GA1085_MSG_CD2(String lK_GA1085_MSG_CD2) {
		LK_GA1085_MSG_CD2 = lK_GA1085_MSG_CD2;
	}
	public String getH_LK_GA1085_MESSAGE1() {
		return H_LK_GA1085_MESSAGE1;
	}
	public void setH_LK_GA1085_MESSAGE1(String h_LK_GA1085_MESSAGE1) {
		H_LK_GA1085_MESSAGE1 = h_LK_GA1085_MESSAGE1;
	}
	public String getH_LK_GA1085_MESSAGE2() {
		return H_LK_GA1085_MESSAGE2;
	}
	public void setH_LK_GA1085_MESSAGE2(String h_LK_GA1085_MESSAGE2) {
		H_LK_GA1085_MESSAGE2 = h_LK_GA1085_MESSAGE2;
	}
	public String getLK_GA1085_POLI_NO() {
		return LK_GA1085_POLI_NO;
	}
	public void setLK_GA1085_POLI_NO(String lK_GA1085_POLI_NO) {
		LK_GA1085_POLI_NO = lK_GA1085_POLI_NO;
	}
	public String getLK_GA1085_BJ_CD() {
		return LK_GA1085_BJ_CD;
	}
	public void setLK_GA1085_BJ_CD(String lK_GA1085_BJ_CD) {
		LK_GA1085_BJ_CD = lK_GA1085_BJ_CD;
	}
	public String getLK_GA1085_BOHUM_GIGAN_SYMD() {
		return LK_GA1085_BOHUM_GIGAN_SYMD;
	}
	public void setLK_GA1085_BOHUM_GIGAN_SYMD(String lK_GA1085_BOHUM_GIGAN_SYMD) {
		LK_GA1085_BOHUM_GIGAN_SYMD = lK_GA1085_BOHUM_GIGAN_SYMD;
	}
	public String getLK_GA1085_BOHUM_GIGAN_EYMD() {
		return LK_GA1085_BOHUM_GIGAN_EYMD;
	}
	public void setLK_GA1085_BOHUM_GIGAN_EYMD(String lK_GA1085_BOHUM_GIGAN_EYMD) {
		LK_GA1085_BOHUM_GIGAN_EYMD = lK_GA1085_BOHUM_GIGAN_EYMD;
	}
	public String getLK_GA1085_INSU_GB() {
		return LK_GA1085_INSU_GB;
	}
	public void setLK_GA1085_INSU_GB(String lK_GA1085_INSU_GB) {
		LK_GA1085_INSU_GB = lK_GA1085_INSU_GB;
	}
	public String getLK_GA1085_JADONG_ICHE_GB() {
		return LK_GA1085_JADONG_ICHE_GB;
	}
	public void setLK_GA1085_JADONG_ICHE_GB(String lK_GA1085_JADONG_ICHE_GB) {
		LK_GA1085_JADONG_ICHE_GB = lK_GA1085_JADONG_ICHE_GB;
	}
	public String getLK_GA1085_JIJUM_CD() {
		return LK_GA1085_JIJUM_CD;
	}
	public void setLK_GA1085_JIJUM_CD(String lK_GA1085_JIJUM_CD) {
		LK_GA1085_JIJUM_CD = lK_GA1085_JIJUM_CD;
	}
	public String getH_LK_GA1085_JIJUM_NAME() {
		return H_LK_GA1085_JIJUM_NAME;
	}
	public void setH_LK_GA1085_JIJUM_NAME(String h_LK_GA1085_JIJUM_NAME) {
		H_LK_GA1085_JIJUM_NAME = h_LK_GA1085_JIJUM_NAME;
	}
	public String getLK_GA1085_JIJUM_TEL_NO() {
		return LK_GA1085_JIJUM_TEL_NO;
	}
	public void setLK_GA1085_JIJUM_TEL_NO(String lK_GA1085_JIJUM_TEL_NO) {
		LK_GA1085_JIJUM_TEL_NO = lK_GA1085_JIJUM_TEL_NO;
	}
	public String getLK_GA1085_JIBU_CD() {
		return LK_GA1085_JIBU_CD;
	}
	public void setLK_GA1085_JIBU_CD(String lK_GA1085_JIBU_CD) {
		LK_GA1085_JIBU_CD = lK_GA1085_JIBU_CD;
	}
	public String getH_LK_GA1085_JIBU_NAME() {
		return H_LK_GA1085_JIBU_NAME;
	}
	public void setH_LK_GA1085_JIBU_NAME(String h_LK_GA1085_JIBU_NAME) {
		H_LK_GA1085_JIBU_NAME = h_LK_GA1085_JIBU_NAME;
	}
	public String getLK_GA1085_JIBU_TEL_NO() {
		return LK_GA1085_JIBU_TEL_NO;
	}
	public void setLK_GA1085_JIBU_TEL_NO(String lK_GA1085_JIBU_TEL_NO) {
		LK_GA1085_JIBU_TEL_NO = lK_GA1085_JIBU_TEL_NO;
	}
	public String getLK_GA1085_JOJIKWON_CD() {
		return LK_GA1085_JOJIKWON_CD;
	}
	public void setLK_GA1085_JOJIKWON_CD(String lK_GA1085_JOJIKWON_CD) {
		LK_GA1085_JOJIKWON_CD = lK_GA1085_JOJIKWON_CD;
	}
	public String getH_LK_GA1085_JOJIKWON_NAME() {
		return H_LK_GA1085_JOJIKWON_NAME;
	}
	public void setH_LK_GA1085_JOJIKWON_NAME(String h_LK_GA1085_JOJIKWON_NAME) {
		H_LK_GA1085_JOJIKWON_NAME = h_LK_GA1085_JOJIKWON_NAME;
	}
	public String getLK_GA1085_JOJIKWON_TEL_NO() {
		return LK_GA1085_JOJIKWON_TEL_NO;
	}
	public void setLK_GA1085_JOJIKWON_TEL_NO(String lK_GA1085_JOJIKWON_TEL_NO) {
		LK_GA1085_JOJIKWON_TEL_NO = lK_GA1085_JOJIKWON_TEL_NO;
	}
	public String getLK_GA1085_SULGYE_NO() {
		return LK_GA1085_SULGYE_NO;
	}
	public void setLK_GA1085_SULGYE_NO(String lK_GA1085_SULGYE_NO) {
		LK_GA1085_SULGYE_NO = lK_GA1085_SULGYE_NO;
	}
	public String getLK_GA1085_JINHANG_GUBUN() {
		return LK_GA1085_JINHANG_GUBUN;
	}
	public void setLK_GA1085_JINHANG_GUBUN(String lK_GA1085_JINHANG_GUBUN) {
		LK_GA1085_JINHANG_GUBUN = lK_GA1085_JINHANG_GUBUN;
	}
	public String getH_LK_GA1085_JINHANG_NAME() {
		return H_LK_GA1085_JINHANG_NAME;
	}
	public void setH_LK_GA1085_JINHANG_NAME(String h_LK_GA1085_JINHANG_NAME) {
		H_LK_GA1085_JINHANG_NAME = h_LK_GA1085_JINHANG_NAME;
	}
	public String getLK_GA1085_DONGIL_GB() {
		return LK_GA1085_DONGIL_GB;
	}
	public void setLK_GA1085_DONGIL_GB(String lK_GA1085_DONGIL_GB) {
		LK_GA1085_DONGIL_GB = lK_GA1085_DONGIL_GB;
	}
	public String getLK_GA1085_DONGIL_SAGO_GB() {
		return LK_GA1085_DONGIL_SAGO_GB;
	}
	public void setLK_GA1085_DONGIL_SAGO_GB(String lK_GA1085_DONGIL_SAGO_GB) {
		LK_GA1085_DONGIL_SAGO_GB = lK_GA1085_DONGIL_SAGO_GB;
	}
	public String getLK_GA1085_FIRST_ICHE_GB() {
		return LK_GA1085_FIRST_ICHE_GB;
	}
	public void setLK_GA1085_FIRST_ICHE_GB(String lK_GA1085_FIRST_ICHE_GB) {
		LK_GA1085_FIRST_ICHE_GB = lK_GA1085_FIRST_ICHE_GB;
	}
	public String getLK_GA1085_GENGSIN_SAVE_GB() {
		return LK_GA1085_GENGSIN_SAVE_GB;
	}
	public void setLK_GA1085_GENGSIN_SAVE_GB(String lK_GA1085_GENGSIN_SAVE_GB) {
		LK_GA1085_GENGSIN_SAVE_GB = lK_GA1085_GENGSIN_SAVE_GB;
	}
	public String getLK_GA1085_GENGSIN_JARYO_GB() {
		return LK_GA1085_GENGSIN_JARYO_GB;
	}
	public void setLK_GA1085_GENGSIN_JARYO_GB(String lK_GA1085_GENGSIN_JARYO_GB) {
		LK_GA1085_GENGSIN_JARYO_GB = lK_GA1085_GENGSIN_JARYO_GB;
	}
	public String getLK_GA1085_BESU_SULGYE_NO() {
		return LK_GA1085_BESU_SULGYE_NO;
	}
	public void setLK_GA1085_BESU_SULGYE_NO(String lK_GA1085_BESU_SULGYE_NO) {
		LK_GA1085_BESU_SULGYE_NO = lK_GA1085_BESU_SULGYE_NO;
	}
	public String getLK_GA1085_BESU_NO() {
		return LK_GA1085_BESU_NO;
	}
	public void setLK_GA1085_BESU_NO(String lK_GA1085_BESU_NO) {
		LK_GA1085_BESU_NO = lK_GA1085_BESU_NO;
	}
	public String getLK_GA1085_BESU_CD() {
		return LK_GA1085_BESU_CD;
	}
	public void setLK_GA1085_BESU_CD(String lK_GA1085_BESU_CD) {
		LK_GA1085_BESU_CD = lK_GA1085_BESU_CD;
	}
	public String getLK_GA1085_DEPYO_BESU_CD() {
		return LK_GA1085_DEPYO_BESU_CD;
	}
	public void setLK_GA1085_DEPYO_BESU_CD(String lK_GA1085_DEPYO_BESU_CD) {
		LK_GA1085_DEPYO_BESU_CD = lK_GA1085_DEPYO_BESU_CD;
	}
	public String getLK_GA1085_BESU_GIJUN_YMD() {
		return LK_GA1085_BESU_GIJUN_YMD;
	}
	public void setLK_GA1085_BESU_GIJUN_YMD(String lK_GA1085_BESU_GIJUN_YMD) {
		LK_GA1085_BESU_GIJUN_YMD = lK_GA1085_BESU_GIJUN_YMD;
	}
	public String getLK_GA1085_INSU_SNGIN_GB() {
		return LK_GA1085_INSU_SNGIN_GB;
	}
	public void setLK_GA1085_INSU_SNGIN_GB(String lK_GA1085_INSU_SNGIN_GB) {
		LK_GA1085_INSU_SNGIN_GB = lK_GA1085_INSU_SNGIN_GB;
	}
	public String getH_LK_GA1085_INSU_SNGIN_NAME() {
		return H_LK_GA1085_INSU_SNGIN_NAME;
	}
	public void setH_LK_GA1085_INSU_SNGIN_NAME(String h_LK_GA1085_INSU_SNGIN_NAME) {
		H_LK_GA1085_INSU_SNGIN_NAME = h_LK_GA1085_INSU_SNGIN_NAME;
	}
	public String getLK_GA1085_INSU_BULGA_GB1() {
		return LK_GA1085_INSU_BULGA_GB1;
	}
	public void setLK_GA1085_INSU_BULGA_GB1(String lK_GA1085_INSU_BULGA_GB1) {
		LK_GA1085_INSU_BULGA_GB1 = lK_GA1085_INSU_BULGA_GB1;
	}
	public String getLK_GA1085_INSU_BULGA_GB2() {
		return LK_GA1085_INSU_BULGA_GB2;
	}
	public void setLK_GA1085_INSU_BULGA_GB2(String lK_GA1085_INSU_BULGA_GB2) {
		LK_GA1085_INSU_BULGA_GB2 = lK_GA1085_INSU_BULGA_GB2;
	}
	public String getLK_GA1085_INSU_BULGA_GB3() {
		return LK_GA1085_INSU_BULGA_GB3;
	}
	public void setLK_GA1085_INSU_BULGA_GB3(String lK_GA1085_INSU_BULGA_GB3) {
		LK_GA1085_INSU_BULGA_GB3 = lK_GA1085_INSU_BULGA_GB3;
	}
	public String getH_LK_GA1085_INSU_BULGA_NAME1() {
		return H_LK_GA1085_INSU_BULGA_NAME1;
	}
	public void setH_LK_GA1085_INSU_BULGA_NAME1(String h_LK_GA1085_INSU_BULGA_NAME1) {
		H_LK_GA1085_INSU_BULGA_NAME1 = h_LK_GA1085_INSU_BULGA_NAME1;
	}
	public String getH_LK_GA1085_INSU_BULGA_NAME2() {
		return H_LK_GA1085_INSU_BULGA_NAME2;
	}
	public void setH_LK_GA1085_INSU_BULGA_NAME2(String h_LK_GA1085_INSU_BULGA_NAME2) {
		H_LK_GA1085_INSU_BULGA_NAME2 = h_LK_GA1085_INSU_BULGA_NAME2;
	}
	public String getH_LK_GA1085_INSU_BULGA_NAME3() {
		return H_LK_GA1085_INSU_BULGA_NAME3;
	}
	public void setH_LK_GA1085_INSU_BULGA_NAME3(String h_LK_GA1085_INSU_BULGA_NAME3) {
		H_LK_GA1085_INSU_BULGA_NAME3 = h_LK_GA1085_INSU_BULGA_NAME3;
	}
	public String getLK_GA1085_YUNGSUJNG_NO() {
		return LK_GA1085_YUNGSUJNG_NO;
	}
	public void setLK_GA1085_YUNGSUJNG_NO(String lK_GA1085_YUNGSUJNG_NO) {
		LK_GA1085_YUNGSUJNG_NO = lK_GA1085_YUNGSUJNG_NO;
	}
	public String getLK_GA1085_YUNGSU_YMD() {
		return LK_GA1085_YUNGSU_YMD;
	}
	public void setLK_GA1085_YUNGSU_YMD(String lK_GA1085_YUNGSU_YMD) {
		LK_GA1085_YUNGSU_YMD = lK_GA1085_YUNGSU_YMD;
	}
	public String getLK_GA1085_GMJONG_GUBUN() {
		return LK_GA1085_GMJONG_GUBUN;
	}
	public void setLK_GA1085_GMJONG_GUBUN(String lK_GA1085_GMJONG_GUBUN) {
		LK_GA1085_GMJONG_GUBUN = lK_GA1085_GMJONG_GUBUN;
	}
	public String getLK_GA1085_ACCT_YMD() {
		return LK_GA1085_ACCT_YMD;
	}
	public void setLK_GA1085_ACCT_YMD(String lK_GA1085_ACCT_YMD) {
		LK_GA1085_ACCT_YMD = lK_GA1085_ACCT_YMD;
	}
	public String getLK_GA1085_YUNGSU_PRM() {
		return LK_GA1085_YUNGSU_PRM;
	}
	public void setLK_GA1085_YUNGSU_PRM(String lK_GA1085_YUNGSU_PRM) {
		LK_GA1085_YUNGSU_PRM = lK_GA1085_YUNGSU_PRM;
	}
	public String getLK_GA1085_CARD_NO() {
		return LK_GA1085_CARD_NO;
	}
	public void setLK_GA1085_CARD_NO(String lK_GA1085_CARD_NO) {
		LK_GA1085_CARD_NO = lK_GA1085_CARD_NO;
	}
	public String getLK_GA1085_CARD_SNGIN_NO() {
		return LK_GA1085_CARD_SNGIN_NO;
	}
	public void setLK_GA1085_CARD_SNGIN_NO(String lK_GA1085_CARD_SNGIN_NO) {
		LK_GA1085_CARD_SNGIN_NO = lK_GA1085_CARD_SNGIN_NO;
	}
	public String getLK_GA1085_BULIP_CNT() {
		return LK_GA1085_BULIP_CNT;
	}
	public void setLK_GA1085_BULIP_CNT(String lK_GA1085_BULIP_CNT) {
		LK_GA1085_BULIP_CNT = lK_GA1085_BULIP_CNT;
	}
	public String getLK_GA1085_CHAHWOI_BUNNAP_YMD() {
		return LK_GA1085_CHAHWOI_BUNNAP_YMD;
	}
	public void setLK_GA1085_CHAHWOI_BUNNAP_YMD(String lK_GA1085_CHAHWOI_BUNNAP_YMD) {
		LK_GA1085_CHAHWOI_BUNNAP_YMD = lK_GA1085_CHAHWOI_BUNNAP_YMD;
	}
	public String getLK_GA1085_BANK_CD() {
		return LK_GA1085_BANK_CD;
	}
	public void setLK_GA1085_BANK_CD(String lK_GA1085_BANK_CD) {
		LK_GA1085_BANK_CD = lK_GA1085_BANK_CD;
	}
	public String getLK_GA1085_GYEJWA_NO() {
		return LK_GA1085_GYEJWA_NO;
	}
	public void setLK_GA1085_GYEJWA_NO(String lK_GA1085_GYEJWA_NO) {
		LK_GA1085_GYEJWA_NO = lK_GA1085_GYEJWA_NO;
	}
	public String getLK_GA1085_GYEJWA_JUMIN_NO() {
		return LK_GA1085_GYEJWA_JUMIN_NO;
	}
	public void setLK_GA1085_GYEJWA_JUMIN_NO(String lK_GA1085_GYEJWA_JUMIN_NO) {
		LK_GA1085_GYEJWA_JUMIN_NO = lK_GA1085_GYEJWA_JUMIN_NO;
	}
	public String getLK_GA1085_IPCHULGM_BANG_CD() {
		return LK_GA1085_IPCHULGM_BANG_CD;
	}
	public void setLK_GA1085_IPCHULGM_BANG_CD(String lK_GA1085_IPCHULGM_BANG_CD) {
		LK_GA1085_IPCHULGM_BANG_CD = lK_GA1085_IPCHULGM_BANG_CD;
	}
	public String getLK_GA1085_ICHE_YMD() {
		return LK_GA1085_ICHE_YMD;
	}
	public void setLK_GA1085_ICHE_YMD(String lK_GA1085_ICHE_YMD) {
		LK_GA1085_ICHE_YMD = lK_GA1085_ICHE_YMD;
	}
	public String getLK_GA1085_BUNNAP_BANGCD() {
		return LK_GA1085_BUNNAP_BANGCD;
	}
	public void setLK_GA1085_BUNNAP_BANGCD(String lK_GA1085_BUNNAP_BANGCD) {
		LK_GA1085_BUNNAP_BANGCD = lK_GA1085_BUNNAP_BANGCD;
	}
	public String getLK_GA1085_BUNNAP_CNT() {
		return LK_GA1085_BUNNAP_CNT;
	}
	public void setLK_GA1085_BUNNAP_CNT(String lK_GA1085_BUNNAP_CNT) {
		LK_GA1085_BUNNAP_CNT = lK_GA1085_BUNNAP_CNT;
	}
	public String getLK_GA1085_BANK_JIJUM_CD() {
		return LK_GA1085_BANK_JIJUM_CD;
	}
	public void setLK_GA1085_BANK_JIJUM_CD(String lK_GA1085_BANK_JIJUM_CD) {
		LK_GA1085_BANK_JIJUM_CD = lK_GA1085_BANK_JIJUM_CD;
	}
	public String getFILLER_2() {
		return FILLER_2;
	}
	public void setFILLER_2(String fILLER_2) {
		FILLER_2 = fILLER_2;
	}
	public String getLK_GA1085_PIB_GOGEK_NO() {
		return LK_GA1085_PIB_GOGEK_NO;
	}
	public void setLK_GA1085_PIB_GOGEK_NO(String lK_GA1085_PIB_GOGEK_NO) {
		LK_GA1085_PIB_GOGEK_NO = lK_GA1085_PIB_GOGEK_NO;
	}
	public String getLK_GA1085_PIB_GOGEK_GB() {
		return LK_GA1085_PIB_GOGEK_GB;
	}
	public void setLK_GA1085_PIB_GOGEK_GB(String lK_GA1085_PIB_GOGEK_GB) {
		LK_GA1085_PIB_GOGEK_GB = lK_GA1085_PIB_GOGEK_GB;
	}
	public String getLK_GA1085_PIB_CONTROL_NO() {
		return LK_GA1085_PIB_CONTROL_NO;
	}
	public void setLK_GA1085_PIB_CONTROL_NO(String lK_GA1085_PIB_CONTROL_NO) {
		LK_GA1085_PIB_CONTROL_NO = lK_GA1085_PIB_CONTROL_NO;
	}
	public String getH_LK_GA1085_PIB_GOGEK_NAME() {
		return H_LK_GA1085_PIB_GOGEK_NAME;
	}
	public void setH_LK_GA1085_PIB_GOGEK_NAME(String h_LK_GA1085_PIB_GOGEK_NAME) {
		H_LK_GA1085_PIB_GOGEK_NAME = h_LK_GA1085_PIB_GOGEK_NAME;
	}
	public String getLK_GA1085_PIB_JIB_TEL_NO() {
		return LK_GA1085_PIB_JIB_TEL_NO;
	}
	public void setLK_GA1085_PIB_JIB_TEL_NO(String lK_GA1085_PIB_JIB_TEL_NO) {
		LK_GA1085_PIB_JIB_TEL_NO = lK_GA1085_PIB_JIB_TEL_NO;
	}
	public String getLK_GA1085_PIB_JIB_ZIP() {
		return LK_GA1085_PIB_JIB_ZIP;
	}
	public void setLK_GA1085_PIB_JIB_ZIP(String lK_GA1085_PIB_JIB_ZIP) {
		LK_GA1085_PIB_JIB_ZIP = lK_GA1085_PIB_JIB_ZIP;
	}
	public String getH_LK_GA1085_PIB_JIB_ADDR() {
		return H_LK_GA1085_PIB_JIB_ADDR;
	}
	public void setH_LK_GA1085_PIB_JIB_ADDR(String h_LK_GA1085_PIB_JIB_ADDR) {
		H_LK_GA1085_PIB_JIB_ADDR = h_LK_GA1085_PIB_JIB_ADDR;
	}
	public String getLK_GA1085_PIB_JIB_OK_GB() {
		return LK_GA1085_PIB_JIB_OK_GB;
	}
	public void setLK_GA1085_PIB_JIB_OK_GB(String lK_GA1085_PIB_JIB_OK_GB) {
		LK_GA1085_PIB_JIB_OK_GB = lK_GA1085_PIB_JIB_OK_GB;
	}
	public String getLK_GA1085_PIB_JIK_TEL_NO() {
		return LK_GA1085_PIB_JIK_TEL_NO;
	}
	public void setLK_GA1085_PIB_JIK_TEL_NO(String lK_GA1085_PIB_JIK_TEL_NO) {
		LK_GA1085_PIB_JIK_TEL_NO = lK_GA1085_PIB_JIK_TEL_NO;
	}
	public String getLK_GA1085_PIB_JIK_ZIP() {
		return LK_GA1085_PIB_JIK_ZIP;
	}
	public void setLK_GA1085_PIB_JIK_ZIP(String lK_GA1085_PIB_JIK_ZIP) {
		LK_GA1085_PIB_JIK_ZIP = lK_GA1085_PIB_JIK_ZIP;
	}
	public String getH_LK_GA1085_PIB_JIK_ADDR() {
		return H_LK_GA1085_PIB_JIK_ADDR;
	}
	public void setH_LK_GA1085_PIB_JIK_ADDR(String h_LK_GA1085_PIB_JIK_ADDR) {
		H_LK_GA1085_PIB_JIK_ADDR = h_LK_GA1085_PIB_JIK_ADDR;
	}
	public String getLK_GA1085_PIB_JIK_OK_GB() {
		return LK_GA1085_PIB_JIK_OK_GB;
	}
	public void setLK_GA1085_PIB_JIK_OK_GB(String lK_GA1085_PIB_JIK_OK_GB) {
		LK_GA1085_PIB_JIK_OK_GB = lK_GA1085_PIB_JIK_OK_GB;
	}
	public String getH_LK_GA1085_PIB_GNMUCHU_NAME() {
		return H_LK_GA1085_PIB_GNMUCHU_NAME;
	}
	public void setH_LK_GA1085_PIB_GNMUCHU_NAME(String h_LK_GA1085_PIB_GNMUCHU_NAME) {
		H_LK_GA1085_PIB_GNMUCHU_NAME = h_LK_GA1085_PIB_GNMUCHU_NAME;
	}
	public String getH_LK_GA1085_PIB_JIKWI_NAME() {
		return H_LK_GA1085_PIB_JIKWI_NAME;
	}
	public void setH_LK_GA1085_PIB_JIKWI_NAME(String h_LK_GA1085_PIB_JIKWI_NAME) {
		H_LK_GA1085_PIB_JIKWI_NAME = h_LK_GA1085_PIB_JIKWI_NAME;
	}
	public String getLK_GA1085_PIB_HP_TEL_NO() {
		return LK_GA1085_PIB_HP_TEL_NO;
	}
	public void setLK_GA1085_PIB_HP_TEL_NO(String lK_GA1085_PIB_HP_TEL_NO) {
		LK_GA1085_PIB_HP_TEL_NO = lK_GA1085_PIB_HP_TEL_NO;
	}
	public String getLK_GA1085_PIB_E_MAIL() {
		return LK_GA1085_PIB_E_MAIL;
	}
	public void setLK_GA1085_PIB_E_MAIL(String lK_GA1085_PIB_E_MAIL) {
		LK_GA1085_PIB_E_MAIL = lK_GA1085_PIB_E_MAIL;
	}
	public String getLK_GA1085_PIB_JIYUK_GB() {
		return LK_GA1085_PIB_JIYUK_GB;
	}
	public void setLK_GA1085_PIB_JIYUK_GB(String lK_GA1085_PIB_JIYUK_GB) {
		LK_GA1085_PIB_JIYUK_GB = lK_GA1085_PIB_JIYUK_GB;
	}
	public String getLK_GA1085_PIB_JOB_TYPE() {
		return LK_GA1085_PIB_JOB_TYPE;
	}
	public void setLK_GA1085_PIB_JOB_TYPE(String lK_GA1085_PIB_JOB_TYPE) {
		LK_GA1085_PIB_JOB_TYPE = lK_GA1085_PIB_JOB_TYPE;
	}
	public String getLK_GA1085_PIB_JOB_CD() {
		return LK_GA1085_PIB_JOB_CD;
	}
	public void setLK_GA1085_PIB_JOB_CD(String lK_GA1085_PIB_JOB_CD) {
		LK_GA1085_PIB_JOB_CD = lK_GA1085_PIB_JOB_CD;
	}
	public String getLK_GA1085_PIB_PIBOHUMJA_YN() {
		return LK_GA1085_PIB_PIBOHUMJA_YN;
	}
	public void setLK_GA1085_PIB_PIBOHUMJA_YN(String lK_GA1085_PIB_PIBOHUMJA_YN) {
		LK_GA1085_PIB_PIBOHUMJA_YN = lK_GA1085_PIB_PIBOHUMJA_YN;
	}
	public String getLK_GA1085_PIB_YUNRYUNG() {
		return LK_GA1085_PIB_YUNRYUNG;
	}
	public void setLK_GA1085_PIB_YUNRYUNG(String lK_GA1085_PIB_YUNRYUNG) {
		LK_GA1085_PIB_YUNRYUNG = lK_GA1085_PIB_YUNRYUNG;
	}
	public String getLK_GA1085_PIB_GYEYAKJA_YN() {
		return LK_GA1085_PIB_GYEYAKJA_YN;
	}
	public void setLK_GA1085_PIB_GYEYAKJA_YN(String lK_GA1085_PIB_GYEYAKJA_YN) {
		LK_GA1085_PIB_GYEYAKJA_YN = lK_GA1085_PIB_GYEYAKJA_YN;
	}
	public String getLK_GA1085_PIB_UNJUNJA_YN() {
		return LK_GA1085_PIB_UNJUNJA_YN;
	}
	public void setLK_GA1085_PIB_UNJUNJA_YN(String lK_GA1085_PIB_UNJUNJA_YN) {
		LK_GA1085_PIB_UNJUNJA_YN = lK_GA1085_PIB_UNJUNJA_YN;
	}
	public String getLK_GA1085_PIB_UNJUNJA_GB() {
		return LK_GA1085_PIB_UNJUNJA_GB;
	}
	public void setLK_GA1085_PIB_UNJUNJA_GB(String lK_GA1085_PIB_UNJUNJA_GB) {
		LK_GA1085_PIB_UNJUNJA_GB = lK_GA1085_PIB_UNJUNJA_GB;
	}
	public String getLK_GA1085_PIB_BUPIN_NO() {
		return LK_GA1085_PIB_BUPIN_NO;
	}
	public void setLK_GA1085_PIB_BUPIN_NO(String lK_GA1085_PIB_BUPIN_NO) {
		LK_GA1085_PIB_BUPIN_NO = lK_GA1085_PIB_BUPIN_NO;
	}
	public String getLK_GA1085_PIB_WEGUKIN_GB() {
		return LK_GA1085_PIB_WEGUKIN_GB;
	}
	public void setLK_GA1085_PIB_WEGUKIN_GB(String lK_GA1085_PIB_WEGUKIN_GB) {
		LK_GA1085_PIB_WEGUKIN_GB = lK_GA1085_PIB_WEGUKIN_GB;
	}
	public String getLK_GA1085_PIB_MYUNHE_NO() {
		return LK_GA1085_PIB_MYUNHE_NO;
	}
	public void setLK_GA1085_PIB_MYUNHE_NO(String lK_GA1085_PIB_MYUNHE_NO) {
		LK_GA1085_PIB_MYUNHE_NO = lK_GA1085_PIB_MYUNHE_NO;
	}
	public String getLK_GA1085_PIB_MYUNHE_Y() {
		return LK_GA1085_PIB_MYUNHE_Y;
	}
	public void setLK_GA1085_PIB_MYUNHE_Y(String lK_GA1085_PIB_MYUNHE_Y) {
		LK_GA1085_PIB_MYUNHE_Y = lK_GA1085_PIB_MYUNHE_Y;
	}
	public String getLK_GA1085_PIB_HPYUN_GB() {
		return LK_GA1085_PIB_HPYUN_GB;
	}
	public void setLK_GA1085_PIB_HPYUN_GB(String lK_GA1085_PIB_HPYUN_GB) {
		LK_GA1085_PIB_HPYUN_GB = lK_GA1085_PIB_HPYUN_GB;
	}
	public String getLK_GA1085_PIB_GYULHON_YN() {
		return LK_GA1085_PIB_GYULHON_YN;
	}
	public void setLK_GA1085_PIB_GYULHON_YN(String lK_GA1085_PIB_GYULHON_YN) {
		LK_GA1085_PIB_GYULHON_YN = lK_GA1085_PIB_GYULHON_YN;
	}
	public String getLK_GA1085_PIB_JANYUUNJUN_YN() {
		return LK_GA1085_PIB_JANYUUNJUN_YN;
	}
	public void setLK_GA1085_PIB_JANYUUNJUN_YN(String lK_GA1085_PIB_JANYUUNJUN_YN) {
		LK_GA1085_PIB_JANYUUNJUN_YN = lK_GA1085_PIB_JANYUUNJUN_YN;
	}
	public String getFILLER_3() {
		return FILLER_3;
	}
	public void setFILLER_3(String fILLER_3) {
		FILLER_3 = fILLER_3;
	}
	public String getLK_GA1085_UNJ_GOGEK_NO() {
		return LK_GA1085_UNJ_GOGEK_NO;
	}
	public void setLK_GA1085_UNJ_GOGEK_NO(String lK_GA1085_UNJ_GOGEK_NO) {
		LK_GA1085_UNJ_GOGEK_NO = lK_GA1085_UNJ_GOGEK_NO;
	}
	public String getLK_GA1085_UNJ_GOGEK_GB() {
		return LK_GA1085_UNJ_GOGEK_GB;
	}
	public void setLK_GA1085_UNJ_GOGEK_GB(String lK_GA1085_UNJ_GOGEK_GB) {
		LK_GA1085_UNJ_GOGEK_GB = lK_GA1085_UNJ_GOGEK_GB;
	}
	public String getLK_GA1085_UNJ_CONTROL_NO() {
		return LK_GA1085_UNJ_CONTROL_NO;
	}
	public void setLK_GA1085_UNJ_CONTROL_NO(String lK_GA1085_UNJ_CONTROL_NO) {
		LK_GA1085_UNJ_CONTROL_NO = lK_GA1085_UNJ_CONTROL_NO;
	}
	public String getH_LK_GA1085_UNJ_GOGEK_NAME() {
		return H_LK_GA1085_UNJ_GOGEK_NAME;
	}
	public void setH_LK_GA1085_UNJ_GOGEK_NAME(String h_LK_GA1085_UNJ_GOGEK_NAME) {
		H_LK_GA1085_UNJ_GOGEK_NAME = h_LK_GA1085_UNJ_GOGEK_NAME;
	}
	public String getLK_GA1085_UNJ_MYUNHE_NO() {
		return LK_GA1085_UNJ_MYUNHE_NO;
	}
	public void setLK_GA1085_UNJ_MYUNHE_NO(String lK_GA1085_UNJ_MYUNHE_NO) {
		LK_GA1085_UNJ_MYUNHE_NO = lK_GA1085_UNJ_MYUNHE_NO;
	}
	public String getLK_GA1085_UNJ_MYUNHE_Y() {
		return LK_GA1085_UNJ_MYUNHE_Y;
	}
	public void setLK_GA1085_UNJ_MYUNHE_Y(String lK_GA1085_UNJ_MYUNHE_Y) {
		LK_GA1085_UNJ_MYUNHE_Y = lK_GA1085_UNJ_MYUNHE_Y;
	}
	public String getLK_GA1085_UNJ_GYULHON_YN() {
		return LK_GA1085_UNJ_GYULHON_YN;
	}
	public void setLK_GA1085_UNJ_GYULHON_YN(String lK_GA1085_UNJ_GYULHON_YN) {
		LK_GA1085_UNJ_GYULHON_YN = lK_GA1085_UNJ_GYULHON_YN;
	}
	public String getLK_GA1085_UNJ_YUNRYUNG() {
		return LK_GA1085_UNJ_YUNRYUNG;
	}
	public void setLK_GA1085_UNJ_YUNRYUNG(String lK_GA1085_UNJ_YUNRYUNG) {
		LK_GA1085_UNJ_YUNRYUNG = lK_GA1085_UNJ_YUNRYUNG;
	}
	public String getLK_GA1085_UNJ_JOB_TYPE() {
		return LK_GA1085_UNJ_JOB_TYPE;
	}
	public void setLK_GA1085_UNJ_JOB_TYPE(String lK_GA1085_UNJ_JOB_TYPE) {
		LK_GA1085_UNJ_JOB_TYPE = lK_GA1085_UNJ_JOB_TYPE;
	}
	public String getLK_GA1085_UNJ_JOB_CD() {
		return LK_GA1085_UNJ_JOB_CD;
	}
	public void setLK_GA1085_UNJ_JOB_CD(String lK_GA1085_UNJ_JOB_CD) {
		LK_GA1085_UNJ_JOB_CD = lK_GA1085_UNJ_JOB_CD;
	}
	public String getLK_GA1085_UNJ_GWANGE() {
		return LK_GA1085_UNJ_GWANGE;
	}
	public void setLK_GA1085_UNJ_GWANGE(String lK_GA1085_UNJ_GWANGE) {
		LK_GA1085_UNJ_GWANGE = lK_GA1085_UNJ_GWANGE;
	}
	public String getFILLER_4() {
		return FILLER_4;
	}
	public void setFILLER_4(String fILLER_4) {
		FILLER_4 = fILLER_4;
	}
	public String getLK_GA1085_GYE_GOGEK_NO() {
		return LK_GA1085_GYE_GOGEK_NO;
	}
	public void setLK_GA1085_GYE_GOGEK_NO(String lK_GA1085_GYE_GOGEK_NO) {
		LK_GA1085_GYE_GOGEK_NO = lK_GA1085_GYE_GOGEK_NO;
	}
	public String getLK_GA1085_GYE_GOGEK_GB() {
		return LK_GA1085_GYE_GOGEK_GB;
	}
	public void setLK_GA1085_GYE_GOGEK_GB(String lK_GA1085_GYE_GOGEK_GB) {
		LK_GA1085_GYE_GOGEK_GB = lK_GA1085_GYE_GOGEK_GB;
	}
	public String getLK_GA1085_GYE_CONTROL_NO() {
		return LK_GA1085_GYE_CONTROL_NO;
	}
	public void setLK_GA1085_GYE_CONTROL_NO(String lK_GA1085_GYE_CONTROL_NO) {
		LK_GA1085_GYE_CONTROL_NO = lK_GA1085_GYE_CONTROL_NO;
	}
	public String getH_LK_GA1085_GYE_GOGEK_NAME() {
		return H_LK_GA1085_GYE_GOGEK_NAME;
	}
	public void setH_LK_GA1085_GYE_GOGEK_NAME(String h_LK_GA1085_GYE_GOGEK_NAME) {
		H_LK_GA1085_GYE_GOGEK_NAME = h_LK_GA1085_GYE_GOGEK_NAME;
	}
	public String getLK_GA1085_GYE_JIB_TEL_NO() {
		return LK_GA1085_GYE_JIB_TEL_NO;
	}
	public void setLK_GA1085_GYE_JIB_TEL_NO(String lK_GA1085_GYE_JIB_TEL_NO) {
		LK_GA1085_GYE_JIB_TEL_NO = lK_GA1085_GYE_JIB_TEL_NO;
	}
	public String getLK_GA1085_GYE_JIB_ZIP() {
		return LK_GA1085_GYE_JIB_ZIP;
	}
	public void setLK_GA1085_GYE_JIB_ZIP(String lK_GA1085_GYE_JIB_ZIP) {
		LK_GA1085_GYE_JIB_ZIP = lK_GA1085_GYE_JIB_ZIP;
	}
	public String getH_LK_GA1085_GYE_JIB_ADDR() {
		return H_LK_GA1085_GYE_JIB_ADDR;
	}
	public void setH_LK_GA1085_GYE_JIB_ADDR(String h_LK_GA1085_GYE_JIB_ADDR) {
		H_LK_GA1085_GYE_JIB_ADDR = h_LK_GA1085_GYE_JIB_ADDR;
	}
	public String getLK_GA1085_GYE_JIB_OK_GB() {
		return LK_GA1085_GYE_JIB_OK_GB;
	}
	public void setLK_GA1085_GYE_JIB_OK_GB(String lK_GA1085_GYE_JIB_OK_GB) {
		LK_GA1085_GYE_JIB_OK_GB = lK_GA1085_GYE_JIB_OK_GB;
	}
	public String getLK_GA1085_GYE_JIK_TEL_NO() {
		return LK_GA1085_GYE_JIK_TEL_NO;
	}
	public void setLK_GA1085_GYE_JIK_TEL_NO(String lK_GA1085_GYE_JIK_TEL_NO) {
		LK_GA1085_GYE_JIK_TEL_NO = lK_GA1085_GYE_JIK_TEL_NO;
	}
	public String getLK_GA1085_GYE_JIK_ZIP() {
		return LK_GA1085_GYE_JIK_ZIP;
	}
	public void setLK_GA1085_GYE_JIK_ZIP(String lK_GA1085_GYE_JIK_ZIP) {
		LK_GA1085_GYE_JIK_ZIP = lK_GA1085_GYE_JIK_ZIP;
	}
	public String getH_LK_GA1085_GYE_JIK_ADDR() {
		return H_LK_GA1085_GYE_JIK_ADDR;
	}
	public void setH_LK_GA1085_GYE_JIK_ADDR(String h_LK_GA1085_GYE_JIK_ADDR) {
		H_LK_GA1085_GYE_JIK_ADDR = h_LK_GA1085_GYE_JIK_ADDR;
	}
	public String getLK_GA1085_GYE_JIK_OK_GB() {
		return LK_GA1085_GYE_JIK_OK_GB;
	}
	public void setLK_GA1085_GYE_JIK_OK_GB(String lK_GA1085_GYE_JIK_OK_GB) {
		LK_GA1085_GYE_JIK_OK_GB = lK_GA1085_GYE_JIK_OK_GB;
	}
	public String getLK_GA1085_GYE_HP_TEL_NO() {
		return LK_GA1085_GYE_HP_TEL_NO;
	}
	public void setLK_GA1085_GYE_HP_TEL_NO(String lK_GA1085_GYE_HP_TEL_NO) {
		LK_GA1085_GYE_HP_TEL_NO = lK_GA1085_GYE_HP_TEL_NO;
	}
	public String getLK_GA1085_GYE_E_MAIL() {
		return LK_GA1085_GYE_E_MAIL;
	}
	public void setLK_GA1085_GYE_E_MAIL(String lK_GA1085_GYE_E_MAIL) {
		LK_GA1085_GYE_E_MAIL = lK_GA1085_GYE_E_MAIL;
	}
	public String getLK_GA1085_GYE_JOB_TYPE() {
		return LK_GA1085_GYE_JOB_TYPE;
	}
	public void setLK_GA1085_GYE_JOB_TYPE(String lK_GA1085_GYE_JOB_TYPE) {
		LK_GA1085_GYE_JOB_TYPE = lK_GA1085_GYE_JOB_TYPE;
	}
	public String getLK_GA1085_GYE_JOB_CD() {
		return LK_GA1085_GYE_JOB_CD;
	}
	public void setLK_GA1085_GYE_JOB_CD(String lK_GA1085_GYE_JOB_CD) {
		LK_GA1085_GYE_JOB_CD = lK_GA1085_GYE_JOB_CD;
	}
	public String getLK_GA1085_GYE_BUPIN_NO() {
		return LK_GA1085_GYE_BUPIN_NO;
	}
	public void setLK_GA1085_GYE_BUPIN_NO(String lK_GA1085_GYE_BUPIN_NO) {
		LK_GA1085_GYE_BUPIN_NO = lK_GA1085_GYE_BUPIN_NO;
	}
	public String getLK_GA1085_GYE_WEGUKIN_GB() {
		return LK_GA1085_GYE_WEGUKIN_GB;
	}
	public void setLK_GA1085_GYE_WEGUKIN_GB(String lK_GA1085_GYE_WEGUKIN_GB) {
		LK_GA1085_GYE_WEGUKIN_GB = lK_GA1085_GYE_WEGUKIN_GB;
	}
	public String getFILLER_5() {
		return FILLER_5;
	}
	public void setFILLER_5(String fILLER_5) {
		FILLER_5 = fILLER_5;
	}
	public String getLK_GA1085_GWAN_CD() {
		return LK_GA1085_GWAN_CD;
	}
	public void setLK_GA1085_GWAN_CD(String lK_GA1085_GWAN_CD) {
		LK_GA1085_GWAN_CD = lK_GA1085_GWAN_CD;
	}
	public String getLK_GA1085_MOKJUK_CD() {
		return LK_GA1085_MOKJUK_CD;
	}
	public void setLK_GA1085_MOKJUK_CD(String lK_GA1085_MOKJUK_CD) {
		LK_GA1085_MOKJUK_CD = lK_GA1085_MOKJUK_CD;
	}
	public String getLK_GA1085_CAR_YONGDO_CD() {
		return LK_GA1085_CAR_YONGDO_CD;
	}
	public void setLK_GA1085_CAR_YONGDO_CD(String lK_GA1085_CAR_YONGDO_CD) {
		LK_GA1085_CAR_YONGDO_CD = lK_GA1085_CAR_YONGDO_CD;
	}
	public String getLK_GA1085_CAR_HYUNGTE_CD() {
		return LK_GA1085_CAR_HYUNGTE_CD;
	}
	public void setLK_GA1085_CAR_HYUNGTE_CD(String lK_GA1085_CAR_HYUNGTE_CD) {
		LK_GA1085_CAR_HYUNGTE_CD = lK_GA1085_CAR_HYUNGTE_CD;
	}
	public String getLK_GA1085_SAYONG_YONGDO_CD() {
		return LK_GA1085_SAYONG_YONGDO_CD;
	}
	public void setLK_GA1085_SAYONG_YONGDO_CD(String lK_GA1085_SAYONG_YONGDO_CD) {
		LK_GA1085_SAYONG_YONGDO_CD = lK_GA1085_SAYONG_YONGDO_CD;
	}
	public String getLK_GA1085_SAYONG_SEBU_CD() {
		return LK_GA1085_SAYONG_SEBU_CD;
	}
	public void setLK_GA1085_SAYONG_SEBU_CD(String lK_GA1085_SAYONG_SEBU_CD) {
		LK_GA1085_SAYONG_SEBU_CD = lK_GA1085_SAYONG_SEBU_CD;
	}
	public String getLK_GA1085_CHAJONG_CD() {
		return LK_GA1085_CHAJONG_CD;
	}
	public void setLK_GA1085_CHAJONG_CD(String lK_GA1085_CHAJONG_CD) {
		LK_GA1085_CHAJONG_CD = lK_GA1085_CHAJONG_CD;
	}
	public String getH_LK_GA1085_CHAJONG_NAME() {
		return H_LK_GA1085_CHAJONG_NAME;
	}
	public void setH_LK_GA1085_CHAJONG_NAME(String h_LK_GA1085_CHAJONG_NAME) {
		H_LK_GA1085_CHAJONG_NAME = h_LK_GA1085_CHAJONG_NAME;
	}
	public String getLK_GA1085_CAR_CD() {
		return LK_GA1085_CAR_CD;
	}
	public void setLK_GA1085_CAR_CD(String lK_GA1085_CAR_CD) {
		LK_GA1085_CAR_CD = lK_GA1085_CAR_CD;
	}
	public String getH_LK_GA1085_CAR_NAME() {
		return H_LK_GA1085_CAR_NAME;
	}
	public void setH_LK_GA1085_CAR_NAME(String h_LK_GA1085_CAR_NAME) {
		H_LK_GA1085_CAR_NAME = h_LK_GA1085_CAR_NAME;
	}
	public String getLK_GA1085_YUNSIK() {
		return LK_GA1085_YUNSIK;
	}
	public void setLK_GA1085_YUNSIK(String lK_GA1085_YUNSIK) {
		LK_GA1085_YUNSIK = lK_GA1085_YUNSIK;
	}
	public String getLK_GA1085_BEGIRYANG() {
		return LK_GA1085_BEGIRYANG;
	}
	public void setLK_GA1085_BEGIRYANG(String lK_GA1085_BEGIRYANG) {
		LK_GA1085_BEGIRYANG = lK_GA1085_BEGIRYANG;
	}
	public String getLK_GA1085_JUKJE_TON() {
		return LK_GA1085_JUKJE_TON;
	}
	public void setLK_GA1085_JUKJE_TON(String lK_GA1085_JUKJE_TON) {
		LK_GA1085_JUKJE_TON = lK_GA1085_JUKJE_TON;
	}
	public String getLK_GA1085_JUNGWON_CNT() {
		return LK_GA1085_JUNGWON_CNT;
	}
	public void setLK_GA1085_JUNGWON_CNT(String lK_GA1085_JUNGWON_CNT) {
		LK_GA1085_JUNGWON_CNT = lK_GA1085_JUNGWON_CNT;
	}
	public String getLK_GA1085_CHADE_NO_GB() {
		return LK_GA1085_CHADE_NO_GB;
	}
	public void setLK_GA1085_CHADE_NO_GB(String lK_GA1085_CHADE_NO_GB) {
		LK_GA1085_CHADE_NO_GB = lK_GA1085_CHADE_NO_GB;
	}
	public String getLK_GA1085_CHADE_NO() {
		return LK_GA1085_CHADE_NO;
	}
	public void setLK_GA1085_CHADE_NO(String lK_GA1085_CHADE_NO) {
		LK_GA1085_CHADE_NO = lK_GA1085_CHADE_NO;
	}
	public String getLK_GA1085_CHULGO_YMD() {
		return LK_GA1085_CHULGO_YMD;
	}
	public void setLK_GA1085_CHULGO_YMD(String lK_GA1085_CHULGO_YMD) {
		LK_GA1085_CHULGO_YMD = lK_GA1085_CHULGO_YMD;
	}
	public String getLK_GA1085_SIDO_CD() {
		return LK_GA1085_SIDO_CD;
	}
	public void setLK_GA1085_SIDO_CD(String lK_GA1085_SIDO_CD) {
		LK_GA1085_SIDO_CD = lK_GA1085_SIDO_CD;
	}
	public String getLK_GA1085_BUSOKPUM_GAEK() {
		return LK_GA1085_BUSOKPUM_GAEK;
	}
	public void setLK_GA1085_BUSOKPUM_GAEK(String lK_GA1085_BUSOKPUM_GAEK) {
		LK_GA1085_BUSOKPUM_GAEK = lK_GA1085_BUSOKPUM_GAEK;
	}
	public String getLK_GA1085_GIGE_BOGAEK() {
		return LK_GA1085_GIGE_BOGAEK;
	}
	public void setLK_GA1085_GIGE_BOGAEK(String lK_GA1085_GIGE_BOGAEK) {
		LK_GA1085_GIGE_BOGAEK = lK_GA1085_GIGE_BOGAEK;
	}
	public String getLK_GA1085_CAR_GAEK() {
		return LK_GA1085_CAR_GAEK;
	}
	public void setLK_GA1085_CAR_GAEK(String lK_GA1085_CAR_GAEK) {
		LK_GA1085_CAR_GAEK = lK_GA1085_CAR_GAEK;
	}
	public String getLK_GA1085_DECHA_GAIP_GMEK() {
		return LK_GA1085_DECHA_GAIP_GMEK;
	}
	public void setLK_GA1085_DECHA_GAIP_GMEK(String lK_GA1085_DECHA_GAIP_GMEK) {
		LK_GA1085_DECHA_GAIP_GMEK = lK_GA1085_DECHA_GAIP_GMEK;
	}
	public String getLK_GA1085_NEW_CAR_RATE() {
		return LK_GA1085_NEW_CAR_RATE;
	}
	public void setLK_GA1085_NEW_CAR_RATE(String lK_GA1085_NEW_CAR_RATE) {
		LK_GA1085_NEW_CAR_RATE = lK_GA1085_NEW_CAR_RATE;
	}
	public String getLK_GA1085_OLD_CAR_RATE() {
		return LK_GA1085_OLD_CAR_RATE;
	}
	public void setLK_GA1085_OLD_CAR_RATE(String lK_GA1085_OLD_CAR_RATE) {
		LK_GA1085_OLD_CAR_RATE = lK_GA1085_OLD_CAR_RATE;
	}
	public String getLK_GA1085_YAGAN_JUCHA_GB() {
		return LK_GA1085_YAGAN_JUCHA_GB;
	}
	public void setLK_GA1085_YAGAN_JUCHA_GB(String lK_GA1085_YAGAN_JUCHA_GB) {
		LK_GA1085_YAGAN_JUCHA_GB = lK_GA1085_YAGAN_JUCHA_GB;
	}
	public String getLK_GA1085_BEDAL_SAYONG_YN() {
		return LK_GA1085_BEDAL_SAYONG_YN;
	}
	public void setLK_GA1085_BEDAL_SAYONG_YN(String lK_GA1085_BEDAL_SAYONG_YN) {
		LK_GA1085_BEDAL_SAYONG_YN = lK_GA1085_BEDAL_SAYONG_YN;
	}
	public String getLK_GA1085_CAR_GUIP_YEAR() {
		return LK_GA1085_CAR_GUIP_YEAR;
	}
	public void setLK_GA1085_CAR_GUIP_YEAR(String lK_GA1085_CAR_GUIP_YEAR) {
		LK_GA1085_CAR_GUIP_YEAR = lK_GA1085_CAR_GUIP_YEAR;
	}
	public String getLK_GA1085_TOT_JUHENG_SU() {
		return LK_GA1085_TOT_JUHENG_SU;
	}
	public void setLK_GA1085_TOT_JUHENG_SU(String lK_GA1085_TOT_JUHENG_SU) {
		LK_GA1085_TOT_JUHENG_SU = lK_GA1085_TOT_JUHENG_SU;
	}
	public String getLK_GA1085_AIR_PASON_GB() {
		return LK_GA1085_AIR_PASON_GB;
	}
	public void setLK_GA1085_AIR_PASON_GB(String lK_GA1085_AIR_PASON_GB) {
		LK_GA1085_AIR_PASON_GB = lK_GA1085_AIR_PASON_GB;
	}
	public String getLK_GA1085_TKSUJANGBI_RATE() {
		return LK_GA1085_TKSUJANGBI_RATE;
	}
	public void setLK_GA1085_TKSUJANGBI_RATE(String lK_GA1085_TKSUJANGBI_RATE) {
		LK_GA1085_TKSUJANGBI_RATE = lK_GA1085_TKSUJANGBI_RATE;
	}
	public String getLK_GA1085_DAMBO_JUHENG_SU() {
		return LK_GA1085_DAMBO_JUHENG_SU;
	}
	public void setLK_GA1085_DAMBO_JUHENG_SU(String lK_GA1085_DAMBO_JUHENG_SU) {
		LK_GA1085_DAMBO_JUHENG_SU = lK_GA1085_DAMBO_JUHENG_SU;
	}
	public String getLK_GA1085_CHONG_JUHENG_SU() {
		return LK_GA1085_CHONG_JUHENG_SU;
	}
	public void setLK_GA1085_CHONG_JUHENG_SU(String lK_GA1085_CHONG_JUHENG_SU) {
		LK_GA1085_CHONG_JUHENG_SU = lK_GA1085_CHONG_JUHENG_SU;
	}
	public String getLK_GA1085_JUHENG_FIX_YMD() {
		return LK_GA1085_JUHENG_FIX_YMD;
	}
	public void setLK_GA1085_JUHENG_FIX_YMD(String lK_GA1085_JUHENG_FIX_YMD) {
		LK_GA1085_JUHENG_FIX_YMD = lK_GA1085_JUHENG_FIX_YMD;
	}
	public String getFILLER_6() {
		return FILLER_6;
	}
	public void setFILLER_6(String fILLER_6) {
		FILLER_6 = fILLER_6;
	}
	public String getLK_GA1085_BUDE_JANG_YN() {
		return LK_GA1085_BUDE_JANG_YN;
	}
	public void setLK_GA1085_BUDE_JANG_YN(String lK_GA1085_BUDE_JANG_YN) {
		LK_GA1085_BUDE_JANG_YN = lK_GA1085_BUDE_JANG_YN;
	}
	public String[] getLK_GA1085_BUDE_JANG_GB() {
		return LK_GA1085_BUDE_JANG_GB;
	}
	public void setLK_GA1085_BUDE_JANG_GB(String[] lK_GA1085_BUDE_JANG_GB) {
		LK_GA1085_BUDE_JANG_GB = lK_GA1085_BUDE_JANG_GB;
	}
	public String[] getLK_GA1085_BUDE_JANG_CD() {
		return LK_GA1085_BUDE_JANG_CD;
	}
	public void setLK_GA1085_BUDE_JANG_CD(String[] lK_GA1085_BUDE_JANG_CD) {
		LK_GA1085_BUDE_JANG_CD = lK_GA1085_BUDE_JANG_CD;
	}
	public String getFILLER_7() {
		return FILLER_7;
	}
	public void setFILLER_7(String fILLER_7) {
		FILLER_7 = fILLER_7;
	}
	public String getLK_GA1085_GAIP_YIM_GUNGRUK() {
		return LK_GA1085_GAIP_YIM_GUNGRUK;
	}
	public void setLK_GA1085_GAIP_YIM_GUNGRUK(String lK_GA1085_GAIP_YIM_GUNGRUK) {
		LK_GA1085_GAIP_YIM_GUNGRUK = lK_GA1085_GAIP_YIM_GUNGRUK;
	}
	public String getLK_GA1085_GAIP_YIM_BUMWI() {
		return LK_GA1085_GAIP_YIM_BUMWI;
	}
	public void setLK_GA1085_GAIP_YIM_BUMWI(String lK_GA1085_GAIP_YIM_BUMWI) {
		LK_GA1085_GAIP_YIM_BUMWI = lK_GA1085_GAIP_YIM_BUMWI;
	}
	public String getLK_GA1085_GAIP_YIM_GOTONG() {
		return LK_GA1085_GAIP_YIM_GOTONG;
	}
	public void setLK_GA1085_GAIP_YIM_GOTONG(String lK_GA1085_GAIP_YIM_GOTONG) {
		LK_GA1085_GAIP_YIM_GOTONG = lK_GA1085_GAIP_YIM_GOTONG;
	}
	public String getLK_GA1085_GAIP_YIM_TOT() {
		return LK_GA1085_GAIP_YIM_TOT;
	}
	public void setLK_GA1085_GAIP_YIM_TOT(String lK_GA1085_GAIP_YIM_TOT) {
		LK_GA1085_GAIP_YIM_TOT = lK_GA1085_GAIP_YIM_TOT;
	}
	public String getLK_GA1085_GAIP_CHK_GUNGRUK() {
		return LK_GA1085_GAIP_CHK_GUNGRUK;
	}
	public void setLK_GA1085_GAIP_CHK_GUNGRUK(String lK_GA1085_GAIP_CHK_GUNGRUK) {
		LK_GA1085_GAIP_CHK_GUNGRUK = lK_GA1085_GAIP_CHK_GUNGRUK;
	}
	public String getLK_GA1085_GAIP_CHK_BUMWI() {
		return LK_GA1085_GAIP_CHK_BUMWI;
	}
	public void setLK_GA1085_GAIP_CHK_BUMWI(String lK_GA1085_GAIP_CHK_BUMWI) {
		LK_GA1085_GAIP_CHK_BUMWI = lK_GA1085_GAIP_CHK_BUMWI;
	}
	public String getLK_GA1085_GAIP_CHK_TOT() {
		return LK_GA1085_GAIP_CHK_TOT;
	}
	public void setLK_GA1085_GAIP_CHK_TOT(String lK_GA1085_GAIP_CHK_TOT) {
		LK_GA1085_GAIP_CHK_TOT = lK_GA1085_GAIP_CHK_TOT;
	}
	public String getLK_GA1085_HAL_CHK_HALIN() {
		return LK_GA1085_HAL_CHK_HALIN;
	}
	public void setLK_GA1085_HAL_CHK_HALIN(String lK_GA1085_HAL_CHK_HALIN) {
		LK_GA1085_HAL_CHK_HALIN = lK_GA1085_HAL_CHK_HALIN;
	}
	public String getLK_GA1085_HAL_CHK_BUMWI() {
		return LK_GA1085_HAL_CHK_BUMWI;
	}
	public void setLK_GA1085_HAL_CHK_BUMWI(String lK_GA1085_HAL_CHK_BUMWI) {
		LK_GA1085_HAL_CHK_BUMWI = lK_GA1085_HAL_CHK_BUMWI;
	}
	public String getLK_GA1085_HAL_YIM_HALIN() {
		return LK_GA1085_HAL_YIM_HALIN;
	}
	public void setLK_GA1085_HAL_YIM_HALIN(String lK_GA1085_HAL_YIM_HALIN) {
		LK_GA1085_HAL_YIM_HALIN = lK_GA1085_HAL_YIM_HALIN;
	}
	public String getLK_GA1085_HAL_YIM_BUMWI() {
		return LK_GA1085_HAL_YIM_BUMWI;
	}
	public void setLK_GA1085_HAL_YIM_BUMWI(String lK_GA1085_HAL_YIM_BUMWI) {
		LK_GA1085_HAL_YIM_BUMWI = lK_GA1085_HAL_YIM_BUMWI;
	}
	public String getLK_GA1085_HAL_YIM_TUKBUL() {
		return LK_GA1085_HAL_YIM_TUKBUL;
	}
	public void setLK_GA1085_HAL_YIM_TUKBUL(String lK_GA1085_HAL_YIM_TUKBUL) {
		LK_GA1085_HAL_YIM_TUKBUL = lK_GA1085_HAL_YIM_TUKBUL;
	}
	public String getLK_GA1085_HAL_YIM_TUKBUL_CD() {
		return LK_GA1085_HAL_YIM_TUKBUL_CD;
	}
	public void setLK_GA1085_HAL_YIM_TUKBUL_CD(String lK_GA1085_HAL_YIM_TUKBUL_CD) {
		LK_GA1085_HAL_YIM_TUKBUL_CD = lK_GA1085_HAL_YIM_TUKBUL_CD;
	}
	public String getLK_GA1085_SAYONG_CD() {
		return LK_GA1085_SAYONG_CD;
	}
	public void setLK_GA1085_SAYONG_CD(String lK_GA1085_SAYONG_CD) {
		LK_GA1085_SAYONG_CD = lK_GA1085_SAYONG_CD;
	}
	public String getLK_GA1085_JUN_DAMBO_CD() {
		return LK_GA1085_JUN_DAMBO_CD;
	}
	public void setLK_GA1085_JUN_DAMBO_CD(String lK_GA1085_JUN_DAMBO_CD) {
		LK_GA1085_JUN_DAMBO_CD = lK_GA1085_JUN_DAMBO_CD;
	}
	public String getLK_GA1085_JUN_DAMBO() {
		return LK_GA1085_JUN_DAMBO;
	}
	public void setLK_GA1085_JUN_DAMBO(String lK_GA1085_JUN_DAMBO) {
		LK_GA1085_JUN_DAMBO = lK_GA1085_JUN_DAMBO;
	}
	public String getLK_GA1085_GUNGRUK_YY() {
		return LK_GA1085_GUNGRUK_YY;
	}
	public void setLK_GA1085_GUNGRUK_YY(String lK_GA1085_GUNGRUK_YY) {
		LK_GA1085_GUNGRUK_YY = lK_GA1085_GUNGRUK_YY;
	}
	public String getLK_GA1085_YUL_JJ_SAYU() {
		return LK_GA1085_YUL_JJ_SAYU;
	}
	public void setLK_GA1085_YUL_JJ_SAYU(String lK_GA1085_YUL_JJ_SAYU) {
		LK_GA1085_YUL_JJ_SAYU = lK_GA1085_YUL_JJ_SAYU;
	}
	public String getLK_GA1085_DANGI_YUL() {
		return LK_GA1085_DANGI_YUL;
	}
	public void setLK_GA1085_DANGI_YUL(String lK_GA1085_DANGI_YUL) {
		LK_GA1085_DANGI_YUL = lK_GA1085_DANGI_YUL;
	}
	public String getLK_GA1085_HAL_CHK_TUKBUL() {
		return LK_GA1085_HAL_CHK_TUKBUL;
	}
	public void setLK_GA1085_HAL_CHK_TUKBUL(String lK_GA1085_HAL_CHK_TUKBUL) {
		LK_GA1085_HAL_CHK_TUKBUL = lK_GA1085_HAL_CHK_TUKBUL;
	}
	public String getFILLER_8() {
		return FILLER_8;
	}
	public void setFILLER_8(String fILLER_8) {
		FILLER_8 = fILLER_8;
	}
	public String[] getLK_GA1085_TUKYAK_CD() {
		return LK_GA1085_TUKYAK_CD;
	}
	public void setLK_GA1085_TUKYAK_CD(String[] lK_GA1085_TUKYAK_CD) {
		LK_GA1085_TUKYAK_CD = lK_GA1085_TUKYAK_CD;
	}
	public String[] getLK_GA1085_TUKYAK_RATE() {
		return LK_GA1085_TUKYAK_RATE;
	}
	public void setLK_GA1085_TUKYAK_RATE(String[] lK_GA1085_TUKYAK_RATE) {
		LK_GA1085_TUKYAK_RATE = lK_GA1085_TUKYAK_RATE;
	}
	public String[] getLK_GA1085_TUKBUL_CD() {
		return LK_GA1085_TUKBUL_CD;
	}
	public void setLK_GA1085_TUKBUL_CD(String[] lK_GA1085_TUKBUL_CD) {
		LK_GA1085_TUKBUL_CD = lK_GA1085_TUKBUL_CD;
	}
	public String[] getLK_GA1085_TUKBUL_RATE() {
		return LK_GA1085_TUKBUL_RATE;
	}
	public void setLK_GA1085_TUKBUL_RATE(String[] lK_GA1085_TUKBUL_RATE) {
		LK_GA1085_TUKBUL_RATE = lK_GA1085_TUKBUL_RATE;
	}
	public String getLK_GA1085_DAEIN1_YN() {
		return LK_GA1085_DAEIN1_YN;
	}
	public void setLK_GA1085_DAEIN1_YN(String lK_GA1085_DAEIN1_YN) {
		LK_GA1085_DAEIN1_YN = lK_GA1085_DAEIN1_YN;
	}
	public String getLK_GA1085_DAEIN1_GIBON_PRM() {
		return LK_GA1085_DAEIN1_GIBON_PRM;
	}
	public void setLK_GA1085_DAEIN1_GIBON_PRM(String lK_GA1085_DAEIN1_GIBON_PRM) {
		LK_GA1085_DAEIN1_GIBON_PRM = lK_GA1085_DAEIN1_GIBON_PRM;
	}
	public String getLK_GA1085_DAEIN1_TUKYAK_YUL() {
		return LK_GA1085_DAEIN1_TUKYAK_YUL;
	}
	public void setLK_GA1085_DAEIN1_TUKYAK_YUL(String lK_GA1085_DAEIN1_TUKYAK_YUL) {
		LK_GA1085_DAEIN1_TUKYAK_YUL = lK_GA1085_DAEIN1_TUKYAK_YUL;
	}
	public String getLK_GA1085_DAEIN1_TUKBUL_YUL() {
		return LK_GA1085_DAEIN1_TUKBUL_YUL;
	}
	public void setLK_GA1085_DAEIN1_TUKBUL_YUL(String lK_GA1085_DAEIN1_TUKBUL_YUL) {
		LK_GA1085_DAEIN1_TUKBUL_YUL = lK_GA1085_DAEIN1_TUKBUL_YUL;
	}
	public String getLK_GA1085_DAEIN1_JUKYONG_PRM() {
		return LK_GA1085_DAEIN1_JUKYONG_PRM;
	}
	public void setLK_GA1085_DAEIN1_JUKYONG_PRM(String lK_GA1085_DAEIN1_JUKYONG_PRM) {
		LK_GA1085_DAEIN1_JUKYONG_PRM = lK_GA1085_DAEIN1_JUKYONG_PRM;
	}
	public String getLK_GA1085_DAEIN1_YUNGSU_PRM() {
		return LK_GA1085_DAEIN1_YUNGSU_PRM;
	}
	public void setLK_GA1085_DAEIN1_YUNGSU_PRM(String lK_GA1085_DAEIN1_YUNGSU_PRM) {
		LK_GA1085_DAEIN1_YUNGSU_PRM = lK_GA1085_DAEIN1_YUNGSU_PRM;
	}
	public String getLK_GA1085_DAEIN2_YN() {
		return LK_GA1085_DAEIN2_YN;
	}
	public void setLK_GA1085_DAEIN2_YN(String lK_GA1085_DAEIN2_YN) {
		LK_GA1085_DAEIN2_YN = lK_GA1085_DAEIN2_YN;
	}
	public String getLK_GA1085_DAEIN2_BPER() {
		return LK_GA1085_DAEIN2_BPER;
	}
	public void setLK_GA1085_DAEIN2_BPER(String lK_GA1085_DAEIN2_BPER) {
		LK_GA1085_DAEIN2_BPER = lK_GA1085_DAEIN2_BPER;
	}
	public String getLK_GA1085_DAEIN2_GIBON_PRM() {
		return LK_GA1085_DAEIN2_GIBON_PRM;
	}
	public void setLK_GA1085_DAEIN2_GIBON_PRM(String lK_GA1085_DAEIN2_GIBON_PRM) {
		LK_GA1085_DAEIN2_GIBON_PRM = lK_GA1085_DAEIN2_GIBON_PRM;
	}
	public String getLK_GA1085_DAEIN2_TUKYAK_YUL() {
		return LK_GA1085_DAEIN2_TUKYAK_YUL;
	}
	public void setLK_GA1085_DAEIN2_TUKYAK_YUL(String lK_GA1085_DAEIN2_TUKYAK_YUL) {
		LK_GA1085_DAEIN2_TUKYAK_YUL = lK_GA1085_DAEIN2_TUKYAK_YUL;
	}
	public String getLK_GA1085_DAEIN2_TUKBUL_YUL() {
		return LK_GA1085_DAEIN2_TUKBUL_YUL;
	}
	public void setLK_GA1085_DAEIN2_TUKBUL_YUL(String lK_GA1085_DAEIN2_TUKBUL_YUL) {
		LK_GA1085_DAEIN2_TUKBUL_YUL = lK_GA1085_DAEIN2_TUKBUL_YUL;
	}
	public String getLK_GA1085_DAEIN2_JUKYONG_PRM() {
		return LK_GA1085_DAEIN2_JUKYONG_PRM;
	}
	public void setLK_GA1085_DAEIN2_JUKYONG_PRM(String lK_GA1085_DAEIN2_JUKYONG_PRM) {
		LK_GA1085_DAEIN2_JUKYONG_PRM = lK_GA1085_DAEIN2_JUKYONG_PRM;
	}
	public String getLK_GA1085_DAEIN2_YUNGSU_PRM() {
		return LK_GA1085_DAEIN2_YUNGSU_PRM;
	}
	public void setLK_GA1085_DAEIN2_YUNGSU_PRM(String lK_GA1085_DAEIN2_YUNGSU_PRM) {
		LK_GA1085_DAEIN2_YUNGSU_PRM = lK_GA1085_DAEIN2_YUNGSU_PRM;
	}
	public String getLK_GA1085_DAEMUL_YN() {
		return LK_GA1085_DAEMUL_YN;
	}
	public void setLK_GA1085_DAEMUL_YN(String lK_GA1085_DAEMUL_YN) {
		LK_GA1085_DAEMUL_YN = lK_GA1085_DAEMUL_YN;
	}
	public String getLK_GA1085_DAEMUL_APER() {
		return LK_GA1085_DAEMUL_APER;
	}
	public void setLK_GA1085_DAEMUL_APER(String lK_GA1085_DAEMUL_APER) {
		LK_GA1085_DAEMUL_APER = lK_GA1085_DAEMUL_APER;
	}
	public String getLK_GA1085_DAEMUL_GIBON_PRM() {
		return LK_GA1085_DAEMUL_GIBON_PRM;
	}
	public void setLK_GA1085_DAEMUL_GIBON_PRM(String lK_GA1085_DAEMUL_GIBON_PRM) {
		LK_GA1085_DAEMUL_GIBON_PRM = lK_GA1085_DAEMUL_GIBON_PRM;
	}
	public String getLK_GA1085_DAEMUL_TUKYAK_YUL() {
		return LK_GA1085_DAEMUL_TUKYAK_YUL;
	}
	public void setLK_GA1085_DAEMUL_TUKYAK_YUL(String lK_GA1085_DAEMUL_TUKYAK_YUL) {
		LK_GA1085_DAEMUL_TUKYAK_YUL = lK_GA1085_DAEMUL_TUKYAK_YUL;
	}
	public String getLK_GA1085_DAEMUL_TUKBUL_YUL() {
		return LK_GA1085_DAEMUL_TUKBUL_YUL;
	}
	public void setLK_GA1085_DAEMUL_TUKBUL_YUL(String lK_GA1085_DAEMUL_TUKBUL_YUL) {
		LK_GA1085_DAEMUL_TUKBUL_YUL = lK_GA1085_DAEMUL_TUKBUL_YUL;
	}
	public String getLK_GA1085_DAEMUL_JUKYONG_PRM() {
		return LK_GA1085_DAEMUL_JUKYONG_PRM;
	}
	public void setLK_GA1085_DAEMUL_JUKYONG_PRM(String lK_GA1085_DAEMUL_JUKYONG_PRM) {
		LK_GA1085_DAEMUL_JUKYONG_PRM = lK_GA1085_DAEMUL_JUKYONG_PRM;
	}
	public String getLK_GA1085_DAEMUL_YUNGSU_PRM() {
		return LK_GA1085_DAEMUL_YUNGSU_PRM;
	}
	public void setLK_GA1085_DAEMUL_YUNGSU_PRM(String lK_GA1085_DAEMUL_YUNGSU_PRM) {
		LK_GA1085_DAEMUL_YUNGSU_PRM = lK_GA1085_DAEMUL_YUNGSU_PRM;
	}
	public String getLK_GA1085_JASON_YN() {
		return LK_GA1085_JASON_YN;
	}
	public void setLK_GA1085_JASON_YN(String lK_GA1085_JASON_YN) {
		LK_GA1085_JASON_YN = lK_GA1085_JASON_YN;
	}
	public String getLK_GA1085_JASON_APER() {
		return LK_GA1085_JASON_APER;
	}
	public void setLK_GA1085_JASON_APER(String lK_GA1085_JASON_APER) {
		LK_GA1085_JASON_APER = lK_GA1085_JASON_APER;
	}
	public String getLK_GA1085_JASON_SAMANG() {
		return LK_GA1085_JASON_SAMANG;
	}
	public void setLK_GA1085_JASON_SAMANG(String lK_GA1085_JASON_SAMANG) {
		LK_GA1085_JASON_SAMANG = lK_GA1085_JASON_SAMANG;
	}
	public String getLK_GA1085_JASON_BUSANG() {
		return LK_GA1085_JASON_BUSANG;
	}
	public void setLK_GA1085_JASON_BUSANG(String lK_GA1085_JASON_BUSANG) {
		LK_GA1085_JASON_BUSANG = lK_GA1085_JASON_BUSANG;
	}
	public String getLK_GA1085_JASON_HUYU() {
		return LK_GA1085_JASON_HUYU;
	}
	public void setLK_GA1085_JASON_HUYU(String lK_GA1085_JASON_HUYU) {
		LK_GA1085_JASON_HUYU = lK_GA1085_JASON_HUYU;
	}
	public String getLK_GA1085_JASON_GIBON_PRM() {
		return LK_GA1085_JASON_GIBON_PRM;
	}
	public void setLK_GA1085_JASON_GIBON_PRM(String lK_GA1085_JASON_GIBON_PRM) {
		LK_GA1085_JASON_GIBON_PRM = lK_GA1085_JASON_GIBON_PRM;
	}
	public String getLK_GA1085_JASON_TUKYAK_YUL() {
		return LK_GA1085_JASON_TUKYAK_YUL;
	}
	public void setLK_GA1085_JASON_TUKYAK_YUL(String lK_GA1085_JASON_TUKYAK_YUL) {
		LK_GA1085_JASON_TUKYAK_YUL = lK_GA1085_JASON_TUKYAK_YUL;
	}
	public String getLK_GA1085_JASON_TUKBUL_YUL() {
		return LK_GA1085_JASON_TUKBUL_YUL;
	}
	public void setLK_GA1085_JASON_TUKBUL_YUL(String lK_GA1085_JASON_TUKBUL_YUL) {
		LK_GA1085_JASON_TUKBUL_YUL = lK_GA1085_JASON_TUKBUL_YUL;
	}
	public String getLK_GA1085_JASON_JUKYONG_PRM() {
		return LK_GA1085_JASON_JUKYONG_PRM;
	}
	public void setLK_GA1085_JASON_JUKYONG_PRM(String lK_GA1085_JASON_JUKYONG_PRM) {
		LK_GA1085_JASON_JUKYONG_PRM = lK_GA1085_JASON_JUKYONG_PRM;
	}
	public String getLK_GA1085_JASON_YUNGSU_PRM() {
		return LK_GA1085_JASON_YUNGSU_PRM;
	}
	public void setLK_GA1085_JASON_YUNGSU_PRM(String lK_GA1085_JASON_YUNGSU_PRM) {
		LK_GA1085_JASON_YUNGSU_PRM = lK_GA1085_JASON_YUNGSU_PRM;
	}
	public String getLK_GA1085_JACHA_YN() {
		return LK_GA1085_JACHA_YN;
	}
	public void setLK_GA1085_JACHA_YN(String lK_GA1085_JACHA_YN) {
		LK_GA1085_JACHA_YN = lK_GA1085_JACHA_YN;
	}
	public String getLK_GA1085_JACHA_GAIP_GMEK() {
		return LK_GA1085_JACHA_GAIP_GMEK;
	}
	public void setLK_GA1085_JACHA_GAIP_GMEK(String lK_GA1085_JACHA_GAIP_GMEK) {
		LK_GA1085_JACHA_GAIP_GMEK = lK_GA1085_JACHA_GAIP_GMEK;
	}
	public String getLK_GA1085_JACHA_GIBON_PRM() {
		return LK_GA1085_JACHA_GIBON_PRM;
	}
	public void setLK_GA1085_JACHA_GIBON_PRM(String lK_GA1085_JACHA_GIBON_PRM) {
		LK_GA1085_JACHA_GIBON_PRM = lK_GA1085_JACHA_GIBON_PRM;
	}
	public String getLK_GA1085_JACHA_TUKYAK_YUL() {
		return LK_GA1085_JACHA_TUKYAK_YUL;
	}
	public void setLK_GA1085_JACHA_TUKYAK_YUL(String lK_GA1085_JACHA_TUKYAK_YUL) {
		LK_GA1085_JACHA_TUKYAK_YUL = lK_GA1085_JACHA_TUKYAK_YUL;
	}
	public String getLK_GA1085_JACHA_TUKBUL_YUL() {
		return LK_GA1085_JACHA_TUKBUL_YUL;
	}
	public void setLK_GA1085_JACHA_TUKBUL_YUL(String lK_GA1085_JACHA_TUKBUL_YUL) {
		LK_GA1085_JACHA_TUKBUL_YUL = lK_GA1085_JACHA_TUKBUL_YUL;
	}
	public String getLK_GA1085_JACHA_JUKYONG_PRM() {
		return LK_GA1085_JACHA_JUKYONG_PRM;
	}
	public void setLK_GA1085_JACHA_JUKYONG_PRM(String lK_GA1085_JACHA_JUKYONG_PRM) {
		LK_GA1085_JACHA_JUKYONG_PRM = lK_GA1085_JACHA_JUKYONG_PRM;
	}
	public String getLK_GA1085_JACHA_GONGJE_GMEK() {
		return LK_GA1085_JACHA_GONGJE_GMEK;
	}
	public void setLK_GA1085_JACHA_GONGJE_GMEK(String lK_GA1085_JACHA_GONGJE_GMEK) {
		LK_GA1085_JACHA_GONGJE_GMEK = lK_GA1085_JACHA_GONGJE_GMEK;
	}
	public String getLK_GA1085_JACHA_YUNGSU_PRM() {
		return LK_GA1085_JACHA_YUNGSU_PRM;
	}
	public void setLK_GA1085_JACHA_YUNGSU_PRM(String lK_GA1085_JACHA_YUNGSU_PRM) {
		LK_GA1085_JACHA_YUNGSU_PRM = lK_GA1085_JACHA_YUNGSU_PRM;
	}
	public String getLK_GA1085_GIGE_YN() {
		return LK_GA1085_GIGE_YN;
	}
	public void setLK_GA1085_GIGE_YN(String lK_GA1085_GIGE_YN) {
		LK_GA1085_GIGE_YN = lK_GA1085_GIGE_YN;
	}
	public String getLK_GA1085_GIGE_GAIP_GMEK() {
		return LK_GA1085_GIGE_GAIP_GMEK;
	}
	public void setLK_GA1085_GIGE_GAIP_GMEK(String lK_GA1085_GIGE_GAIP_GMEK) {
		LK_GA1085_GIGE_GAIP_GMEK = lK_GA1085_GIGE_GAIP_GMEK;
	}
	public String getLK_GA1085_GIGE_GIBON_PRM() {
		return LK_GA1085_GIGE_GIBON_PRM;
	}
	public void setLK_GA1085_GIGE_GIBON_PRM(String lK_GA1085_GIGE_GIBON_PRM) {
		LK_GA1085_GIGE_GIBON_PRM = lK_GA1085_GIGE_GIBON_PRM;
	}
	public String getLK_GA1085_GIGE_TUKYAK_YUL() {
		return LK_GA1085_GIGE_TUKYAK_YUL;
	}
	public void setLK_GA1085_GIGE_TUKYAK_YUL(String lK_GA1085_GIGE_TUKYAK_YUL) {
		LK_GA1085_GIGE_TUKYAK_YUL = lK_GA1085_GIGE_TUKYAK_YUL;
	}
	public String getLK_GA1085_GIGE_TUKBUL_YUL() {
		return LK_GA1085_GIGE_TUKBUL_YUL;
	}
	public void setLK_GA1085_GIGE_TUKBUL_YUL(String lK_GA1085_GIGE_TUKBUL_YUL) {
		LK_GA1085_GIGE_TUKBUL_YUL = lK_GA1085_GIGE_TUKBUL_YUL;
	}
	public String getLK_GA1085_GIGE_JUKYONG_PRM() {
		return LK_GA1085_GIGE_JUKYONG_PRM;
	}
	public void setLK_GA1085_GIGE_JUKYONG_PRM(String lK_GA1085_GIGE_JUKYONG_PRM) {
		LK_GA1085_GIGE_JUKYONG_PRM = lK_GA1085_GIGE_JUKYONG_PRM;
	}
	public String getLK_GA1085_GIGE_YUNGSU_PRM() {
		return LK_GA1085_GIGE_YUNGSU_PRM;
	}
	public void setLK_GA1085_GIGE_YUNGSU_PRM(String lK_GA1085_GIGE_YUNGSU_PRM) {
		LK_GA1085_GIGE_YUNGSU_PRM = lK_GA1085_GIGE_YUNGSU_PRM;
	}
	public String getLK_GA1085_MUBO_YN() {
		return LK_GA1085_MUBO_YN;
	}
	public void setLK_GA1085_MUBO_YN(String lK_GA1085_MUBO_YN) {
		LK_GA1085_MUBO_YN = lK_GA1085_MUBO_YN;
	}
	public String getLK_GA1085_MUBO_GAIP_GMEK() {
		return LK_GA1085_MUBO_GAIP_GMEK;
	}
	public void setLK_GA1085_MUBO_GAIP_GMEK(String lK_GA1085_MUBO_GAIP_GMEK) {
		LK_GA1085_MUBO_GAIP_GMEK = lK_GA1085_MUBO_GAIP_GMEK;
	}
	public String getLK_GA1085_MUBO_GIBON_PRM() {
		return LK_GA1085_MUBO_GIBON_PRM;
	}
	public void setLK_GA1085_MUBO_GIBON_PRM(String lK_GA1085_MUBO_GIBON_PRM) {
		LK_GA1085_MUBO_GIBON_PRM = lK_GA1085_MUBO_GIBON_PRM;
	}
	public String getLK_GA1085_MUBO_TUKYAK_YUL() {
		return LK_GA1085_MUBO_TUKYAK_YUL;
	}
	public void setLK_GA1085_MUBO_TUKYAK_YUL(String lK_GA1085_MUBO_TUKYAK_YUL) {
		LK_GA1085_MUBO_TUKYAK_YUL = lK_GA1085_MUBO_TUKYAK_YUL;
	}
	public String getLK_GA1085_MUBO_TUKBUL_YUL() {
		return LK_GA1085_MUBO_TUKBUL_YUL;
	}
	public void setLK_GA1085_MUBO_TUKBUL_YUL(String lK_GA1085_MUBO_TUKBUL_YUL) {
		LK_GA1085_MUBO_TUKBUL_YUL = lK_GA1085_MUBO_TUKBUL_YUL;
	}
	public String getLK_GA1085_MUBO_JUKYONG_PRM() {
		return LK_GA1085_MUBO_JUKYONG_PRM;
	}
	public void setLK_GA1085_MUBO_JUKYONG_PRM(String lK_GA1085_MUBO_JUKYONG_PRM) {
		LK_GA1085_MUBO_JUKYONG_PRM = lK_GA1085_MUBO_JUKYONG_PRM;
	}
	public String getLK_GA1085_MUBO_YUNGSU_PRM() {
		return LK_GA1085_MUBO_YUNGSU_PRM;
	}
	public void setLK_GA1085_MUBO_YUNGSU_PRM(String lK_GA1085_MUBO_YUNGSU_PRM) {
		LK_GA1085_MUBO_YUNGSU_PRM = lK_GA1085_MUBO_YUNGSU_PRM;
	}
	public String getLK_GA1085_TOT_YUNGSU_PRM() {
		return LK_GA1085_TOT_YUNGSU_PRM;
	}
	public void setLK_GA1085_TOT_YUNGSU_PRM(String lK_GA1085_TOT_YUNGSU_PRM) {
		LK_GA1085_TOT_YUNGSU_PRM = lK_GA1085_TOT_YUNGSU_PRM;
	}
	public String getLK_GA1085_TAPSNGJA_GB() {
		return LK_GA1085_TAPSNGJA_GB;
	}
	public void setLK_GA1085_TAPSNGJA_GB(String lK_GA1085_TAPSNGJA_GB) {
		LK_GA1085_TAPSNGJA_GB = lK_GA1085_TAPSNGJA_GB;
	}
	public String getLK_GA1085_SOS_YN() {
		return LK_GA1085_SOS_YN;
	}
	public void setLK_GA1085_SOS_YN(String lK_GA1085_SOS_YN) {
		LK_GA1085_SOS_YN = lK_GA1085_SOS_YN;
	}
	public String getLK_GA1085_SOS_GIBON_PRM() {
		return LK_GA1085_SOS_GIBON_PRM;
	}
	public void setLK_GA1085_SOS_GIBON_PRM(String lK_GA1085_SOS_GIBON_PRM) {
		LK_GA1085_SOS_GIBON_PRM = lK_GA1085_SOS_GIBON_PRM;
	}
	public String getLK_GA1085_SOS_JUKYONG_PRM() {
		return LK_GA1085_SOS_JUKYONG_PRM;
	}
	public void setLK_GA1085_SOS_JUKYONG_PRM(String lK_GA1085_SOS_JUKYONG_PRM) {
		LK_GA1085_SOS_JUKYONG_PRM = lK_GA1085_SOS_JUKYONG_PRM;
	}
	public String getLK_GA1085_SOS_YUNGSU_PRM() {
		return LK_GA1085_SOS_YUNGSU_PRM;
	}
	public void setLK_GA1085_SOS_YUNGSU_PRM(String lK_GA1085_SOS_YUNGSU_PRM) {
		LK_GA1085_SOS_YUNGSU_PRM = lK_GA1085_SOS_YUNGSU_PRM;
	}
	public String getLK_GA1085_SANGHE_YN() {
		return LK_GA1085_SANGHE_YN;
	}
	public void setLK_GA1085_SANGHE_YN(String lK_GA1085_SANGHE_YN) {
		LK_GA1085_SANGHE_YN = lK_GA1085_SANGHE_YN;
	}
	public String getLK_GA1085_SANGHE_GAIP_GMEK() {
		return LK_GA1085_SANGHE_GAIP_GMEK;
	}
	public void setLK_GA1085_SANGHE_GAIP_GMEK(String lK_GA1085_SANGHE_GAIP_GMEK) {
		LK_GA1085_SANGHE_GAIP_GMEK = lK_GA1085_SANGHE_GAIP_GMEK;
	}
	public String getLK_GA1085_RN_YN() {
		return LK_GA1085_RN_YN;
	}
	public void setLK_GA1085_RN_YN(String lK_GA1085_RN_YN) {
		LK_GA1085_RN_YN = lK_GA1085_RN_YN;
	}
	public String getLK_GA1085_SI_YN() {
		return LK_GA1085_SI_YN;
	}
	public void setLK_GA1085_SI_YN(String lK_GA1085_SI_YN) {
		LK_GA1085_SI_YN = lK_GA1085_SI_YN;
	}
	public String getLK_GA1085_JUNSON_GAIP_YN() {
		return LK_GA1085_JUNSON_GAIP_YN;
	}
	public void setLK_GA1085_JUNSON_GAIP_YN(String lK_GA1085_JUNSON_GAIP_YN) {
		LK_GA1085_JUNSON_GAIP_YN = lK_GA1085_JUNSON_GAIP_YN;
	}
	public String getLK_GA1085_GOJANG_YN() {
		return LK_GA1085_GOJANG_YN;
	}
	public void setLK_GA1085_GOJANG_YN(String lK_GA1085_GOJANG_YN) {
		LK_GA1085_GOJANG_YN = lK_GA1085_GOJANG_YN;
	}
	public String getLK_GA1085_GOJANG_GAIP_GMEK() {
		return LK_GA1085_GOJANG_GAIP_GMEK;
	}
	public void setLK_GA1085_GOJANG_GAIP_GMEK(String lK_GA1085_GOJANG_GAIP_GMEK) {
		LK_GA1085_GOJANG_GAIP_GMEK = lK_GA1085_GOJANG_GAIP_GMEK;
	}
	public String getLK_GA1085_GOJANG_GIBON_PRM() {
		return LK_GA1085_GOJANG_GIBON_PRM;
	}
	public void setLK_GA1085_GOJANG_GIBON_PRM(String lK_GA1085_GOJANG_GIBON_PRM) {
		LK_GA1085_GOJANG_GIBON_PRM = lK_GA1085_GOJANG_GIBON_PRM;
	}
	public String getLK_GA1085_GOJANG_TUKYAK_YUL() {
		return LK_GA1085_GOJANG_TUKYAK_YUL;
	}
	public void setLK_GA1085_GOJANG_TUKYAK_YUL(String lK_GA1085_GOJANG_TUKYAK_YUL) {
		LK_GA1085_GOJANG_TUKYAK_YUL = lK_GA1085_GOJANG_TUKYAK_YUL;
	}
	public String getLK_GA1085_GOJANG_TUKBUL_YUL() {
		return LK_GA1085_GOJANG_TUKBUL_YUL;
	}
	public void setLK_GA1085_GOJANG_TUKBUL_YUL(String lK_GA1085_GOJANG_TUKBUL_YUL) {
		LK_GA1085_GOJANG_TUKBUL_YUL = lK_GA1085_GOJANG_TUKBUL_YUL;
	}
	public String getLK_GA1085_GOJANG_JUKYONG_PRM() {
		return LK_GA1085_GOJANG_JUKYONG_PRM;
	}
	public void setLK_GA1085_GOJANG_JUKYONG_PRM(String lK_GA1085_GOJANG_JUKYONG_PRM) {
		LK_GA1085_GOJANG_JUKYONG_PRM = lK_GA1085_GOJANG_JUKYONG_PRM;
	}
	public String getLK_GA1085_GOJANG_GONGJE_GMEK() {
		return LK_GA1085_GOJANG_GONGJE_GMEK;
	}
	public void setLK_GA1085_GOJANG_GONGJE_GMEK(String lK_GA1085_GOJANG_GONGJE_GMEK) {
		LK_GA1085_GOJANG_GONGJE_GMEK = lK_GA1085_GOJANG_GONGJE_GMEK;
	}
	public String getLK_GA1085_GOJANG_YUNGSU_PRM() {
		return LK_GA1085_GOJANG_YUNGSU_PRM;
	}
	public void setLK_GA1085_GOJANG_YUNGSU_PRM(String lK_GA1085_GOJANG_YUNGSU_PRM) {
		LK_GA1085_GOJANG_YUNGSU_PRM = lK_GA1085_GOJANG_YUNGSU_PRM;
	}
	public String getLK_GA1085_IMSIBI_YN() {
		return LK_GA1085_IMSIBI_YN;
	}
	public void setLK_GA1085_IMSIBI_YN(String lK_GA1085_IMSIBI_YN) {
		LK_GA1085_IMSIBI_YN = lK_GA1085_IMSIBI_YN;
	}
	public String getLK_GA1085_IMSIBI_GAIP_GMEK() {
		return LK_GA1085_IMSIBI_GAIP_GMEK;
	}
	public void setLK_GA1085_IMSIBI_GAIP_GMEK(String lK_GA1085_IMSIBI_GAIP_GMEK) {
		LK_GA1085_IMSIBI_GAIP_GMEK = lK_GA1085_IMSIBI_GAIP_GMEK;
	}
	public String getLK_GA1085_DEINSAGO_YN() {
		return LK_GA1085_DEINSAGO_YN;
	}
	public void setLK_GA1085_DEINSAGO_YN(String lK_GA1085_DEINSAGO_YN) {
		LK_GA1085_DEINSAGO_YN = lK_GA1085_DEINSAGO_YN;
	}
	public String getLK_GA1085_DEMULSAGO_YN() {
		return LK_GA1085_DEMULSAGO_YN;
	}
	public void setLK_GA1085_DEMULSAGO_YN(String lK_GA1085_DEMULSAGO_YN) {
		LK_GA1085_DEMULSAGO_YN = lK_GA1085_DEMULSAGO_YN;
	}
	public String getLK_GA1085_GAJOKLOVE_YN() {
		return LK_GA1085_GAJOKLOVE_YN;
	}
	public void setLK_GA1085_GAJOKLOVE_YN(String lK_GA1085_GAJOKLOVE_YN) {
		LK_GA1085_GAJOKLOVE_YN = lK_GA1085_GAJOKLOVE_YN;
	}
	public String getLK_GA1085_CARLOVE_YN() {
		return LK_GA1085_CARLOVE_YN;
	}
	public void setLK_GA1085_CARLOVE_YN(String lK_GA1085_CARLOVE_YN) {
		LK_GA1085_CARLOVE_YN = lK_GA1085_CARLOVE_YN;
	}
	public String getLK_GA1085_GUNGANG_YN() {
		return LK_GA1085_GUNGANG_YN;
	}
	public void setLK_GA1085_GUNGANG_YN(String lK_GA1085_GUNGANG_YN) {
		LK_GA1085_GUNGANG_YN = lK_GA1085_GUNGANG_YN;
	}
	public String getLK_GA1085_CARWNBAN_YN() {
		return LK_GA1085_CARWNBAN_YN;
	}
	public void setLK_GA1085_CARWNBAN_YN(String lK_GA1085_CARWNBAN_YN) {
		LK_GA1085_CARWNBAN_YN = lK_GA1085_CARWNBAN_YN;
	}
	public String getLK_GA1085_HPSONHE_YN() {
		return LK_GA1085_HPSONHE_YN;
	}
	public void setLK_GA1085_HPSONHE_YN(String lK_GA1085_HPSONHE_YN) {
		LK_GA1085_HPSONHE_YN = lK_GA1085_HPSONHE_YN;
	}
	public String getLK_GA1085_CARSISE_YN() {
		return LK_GA1085_CARSISE_YN;
	}
	public void setLK_GA1085_CARSISE_YN(String lK_GA1085_CARSISE_YN) {
		LK_GA1085_CARSISE_YN = lK_GA1085_CARSISE_YN;
	}
	public String getLK_GA1085_BOHENG_YN() {
		return LK_GA1085_BOHENG_YN;
	}
	public void setLK_GA1085_BOHENG_YN(String lK_GA1085_BOHENG_YN) {
		LK_GA1085_BOHENG_YN = lK_GA1085_BOHENG_YN;
	}
	public String getLK_GA1085_BOHENG_GAIP_GMEK() {
		return LK_GA1085_BOHENG_GAIP_GMEK;
	}
	public void setLK_GA1085_BOHENG_GAIP_GMEK(String lK_GA1085_BOHENG_GAIP_GMEK) {
		LK_GA1085_BOHENG_GAIP_GMEK = lK_GA1085_BOHENG_GAIP_GMEK;
	}
	public String getLK_GA1085_BYUNG_SIRYO() {
		return LK_GA1085_BYUNG_SIRYO;
	}
	public void setLK_GA1085_BYUNG_SIRYO(String lK_GA1085_BYUNG_SIRYO) {
		LK_GA1085_BYUNG_SIRYO = lK_GA1085_BYUNG_SIRYO;
	}
	public String getLK_GA1085_RENT_UNJUN() {
		return LK_GA1085_RENT_UNJUN;
	}
	public void setLK_GA1085_RENT_UNJUN(String lK_GA1085_RENT_UNJUN) {
		LK_GA1085_RENT_UNJUN = lK_GA1085_RENT_UNJUN;
	}
	public String getLK_GA1085_HIGH_SENSE() {
		return LK_GA1085_HIGH_SENSE;
	}
	public void setLK_GA1085_HIGH_SENSE(String lK_GA1085_HIGH_SENSE) {
		LK_GA1085_HIGH_SENSE = lK_GA1085_HIGH_SENSE;
	}
	public String getLK_GA1085_ZANYE_EDU() {
		return LK_GA1085_ZANYE_EDU;
	}
	public void setLK_GA1085_ZANYE_EDU(String lK_GA1085_ZANYE_EDU) {
		LK_GA1085_ZANYE_EDU = lK_GA1085_ZANYE_EDU;
	}
	public String getLK_GA1085_TEACHER_LOVE() {
		return LK_GA1085_TEACHER_LOVE;
	}
	public void setLK_GA1085_TEACHER_LOVE(String lK_GA1085_TEACHER_LOVE) {
		LK_GA1085_TEACHER_LOVE = lK_GA1085_TEACHER_LOVE;
	}
	public String getLK_GA1085_SCHOOL() {
		return LK_GA1085_SCHOOL;
	}
	public void setLK_GA1085_SCHOOL(String lK_GA1085_SCHOOL) {
		LK_GA1085_SCHOOL = lK_GA1085_SCHOOL;
	}
	public String getLK_GA1085_REMOTE_SAGO() {
		return LK_GA1085_REMOTE_SAGO;
	}
	public void setLK_GA1085_REMOTE_SAGO(String lK_GA1085_REMOTE_SAGO) {
		LK_GA1085_REMOTE_SAGO = lK_GA1085_REMOTE_SAGO;
	}
	public String getLK_GA1085_FAMILY_SAGO() {
		return LK_GA1085_FAMILY_SAGO;
	}
	public void setLK_GA1085_FAMILY_SAGO(String lK_GA1085_FAMILY_SAGO) {
		LK_GA1085_FAMILY_SAGO = lK_GA1085_FAMILY_SAGO;
	}
	public String getLK_GA1085_WEEK_EXTEND() {
		return LK_GA1085_WEEK_EXTEND;
	}
	public void setLK_GA1085_WEEK_EXTEND(String lK_GA1085_WEEK_EXTEND) {
		LK_GA1085_WEEK_EXTEND = lK_GA1085_WEEK_EXTEND;
	}
	public String getLK_GA1085_SEAT_BELT() {
		return LK_GA1085_SEAT_BELT;
	}
	public void setLK_GA1085_SEAT_BELT(String lK_GA1085_SEAT_BELT) {
		LK_GA1085_SEAT_BELT = lK_GA1085_SEAT_BELT;
	}
	public String getLK_GA1085_CAR_DOJANG() {
		return LK_GA1085_CAR_DOJANG;
	}
	public void setLK_GA1085_CAR_DOJANG(String lK_GA1085_CAR_DOJANG) {
		LK_GA1085_CAR_DOJANG = lK_GA1085_CAR_DOJANG;
	}
	public String getLK_GA1085_CAR_GAEK_REP() {
		return LK_GA1085_CAR_GAEK_REP;
	}
	public void setLK_GA1085_CAR_GAEK_REP(String lK_GA1085_CAR_GAEK_REP) {
		LK_GA1085_CAR_GAEK_REP = lK_GA1085_CAR_GAEK_REP;
	}
	public String getLK_GA1085_TACHA_UNJUN() {
		return LK_GA1085_TACHA_UNJUN;
	}
	public void setLK_GA1085_TACHA_UNJUN(String lK_GA1085_TACHA_UNJUN) {
		LK_GA1085_TACHA_UNJUN = lK_GA1085_TACHA_UNJUN;
	}
	public String getLK_GA1085_GAN_BYUNG_IN() {
		return LK_GA1085_GAN_BYUNG_IN;
	}
	public void setLK_GA1085_GAN_BYUNG_IN(String lK_GA1085_GAN_BYUNG_IN) {
		LK_GA1085_GAN_BYUNG_IN = lK_GA1085_GAN_BYUNG_IN;
	}
	public String getLK_GA1085_SIN_CHE() {
		return LK_GA1085_SIN_CHE;
	}
	public void setLK_GA1085_SIN_CHE(String lK_GA1085_SIN_CHE) {
		LK_GA1085_SIN_CHE = lK_GA1085_SIN_CHE;
	}
	public String getLK_GA1085_HYUNGSA_HAPBI() {
		return LK_GA1085_HYUNGSA_HAPBI;
	}
	public void setLK_GA1085_HYUNGSA_HAPBI(String lK_GA1085_HYUNGSA_HAPBI) {
		LK_GA1085_HYUNGSA_HAPBI = lK_GA1085_HYUNGSA_HAPBI;
	}
	public String getLK_GA1085_PENALTY() {
		return LK_GA1085_PENALTY;
	}
	public void setLK_GA1085_PENALTY(String lK_GA1085_PENALTY) {
		LK_GA1085_PENALTY = lK_GA1085_PENALTY;
	}
	public String getLK_GA1085_SANHAL_SUPPORT() {
		return LK_GA1085_SANHAL_SUPPORT;
	}
	public void setLK_GA1085_SANHAL_SUPPORT(String lK_GA1085_SANHAL_SUPPORT) {
		LK_GA1085_SANHAL_SUPPORT = lK_GA1085_SANHAL_SUPPORT;
	}
	public String getLK_GA1085_SANHAL_GAIP() {
		return LK_GA1085_SANHAL_GAIP;
	}
	public void setLK_GA1085_SANHAL_GAIP(String lK_GA1085_SANHAL_GAIP) {
		LK_GA1085_SANHAL_GAIP = lK_GA1085_SANHAL_GAIP;
	}
	public String getLK_GA1085_LEASE_RENT() {
		return LK_GA1085_LEASE_RENT;
	}
	public void setLK_GA1085_LEASE_RENT(String lK_GA1085_LEASE_RENT) {
		LK_GA1085_LEASE_RENT = lK_GA1085_LEASE_RENT;
	}
	public String getLK_GA1085_LEASE_SINGA() {
		return LK_GA1085_LEASE_SINGA;
	}
	public void setLK_GA1085_LEASE_SINGA(String lK_GA1085_LEASE_SINGA) {
		LK_GA1085_LEASE_SINGA = lK_GA1085_LEASE_SINGA;
	}
	public String getLK_GA1085_JUNGJNG_GMEK() {
		return LK_GA1085_JUNGJNG_GMEK;
	}
	public void setLK_GA1085_JUNGJNG_GMEK(String lK_GA1085_JUNGJNG_GMEK) {
		LK_GA1085_JUNGJNG_GMEK = lK_GA1085_JUNGJNG_GMEK;
	}
	public String getLK_GA1085_BUPIN_SAGO() {
		return LK_GA1085_BUPIN_SAGO;
	}
	public void setLK_GA1085_BUPIN_SAGO(String lK_GA1085_BUPIN_SAGO) {
		LK_GA1085_BUPIN_SAGO = lK_GA1085_BUPIN_SAGO;
	}
	public String getLK_GA1085_CAR_SONHE() {
		return LK_GA1085_CAR_SONHE;
	}
	public void setLK_GA1085_CAR_SONHE(String lK_GA1085_CAR_SONHE) {
		LK_GA1085_CAR_SONHE = lK_GA1085_CAR_SONHE;
	}
	public String getLK_GA1085_SON_STUDY() {
		return LK_GA1085_SON_STUDY;
	}
	public void setLK_GA1085_SON_STUDY(String lK_GA1085_SON_STUDY) {
		LK_GA1085_SON_STUDY = lK_GA1085_SON_STUDY;
	}
	public String getLK_GA1085_SON_GAIP() {
		return LK_GA1085_SON_GAIP;
	}
	public void setLK_GA1085_SON_GAIP(String lK_GA1085_SON_GAIP) {
		LK_GA1085_SON_GAIP = lK_GA1085_SON_GAIP;
	}
	public String getLK_GA1085_WEEK_SAGO() {
		return LK_GA1085_WEEK_SAGO;
	}
	public void setLK_GA1085_WEEK_SAGO(String lK_GA1085_WEEK_SAGO) {
		LK_GA1085_WEEK_SAGO = lK_GA1085_WEEK_SAGO;
	}
	public String getLK_GA1085_TUNING_YN() {
		return LK_GA1085_TUNING_YN;
	}
	public void setLK_GA1085_TUNING_YN(String lK_GA1085_TUNING_YN) {
		LK_GA1085_TUNING_YN = lK_GA1085_TUNING_YN;
	}
	public String getLK_GA1085_TUNING_APER() {
		return LK_GA1085_TUNING_APER;
	}
	public void setLK_GA1085_TUNING_APER(String lK_GA1085_TUNING_APER) {
		LK_GA1085_TUNING_APER = lK_GA1085_TUNING_APER;
	}
	public String getLK_GA1085_LEASURE() {
		return LK_GA1085_LEASURE;
	}
	public void setLK_GA1085_LEASURE(String lK_GA1085_LEASURE) {
		LK_GA1085_LEASURE = lK_GA1085_LEASURE;
	}
	public String getLK_GA1085_JOOMAL_GYUTONG() {
		return LK_GA1085_JOOMAL_GYUTONG;
	}
	public void setLK_GA1085_JOOMAL_GYUTONG(String lK_GA1085_JOOMAL_GYUTONG) {
		LK_GA1085_JOOMAL_GYUTONG = lK_GA1085_JOOMAL_GYUTONG;
	}
	public String getLK_GA1085_DAEJONG_GYUTONG() {
		return LK_GA1085_DAEJONG_GYUTONG;
	}
	public void setLK_GA1085_DAEJONG_GYUTONG(String lK_GA1085_DAEJONG_GYUTONG) {
		LK_GA1085_DAEJONG_GYUTONG = lK_GA1085_DAEJONG_GYUTONG;
	}
	public String getLK_GA1085_LEASE_UNJUN() {
		return LK_GA1085_LEASE_UNJUN;
	}
	public void setLK_GA1085_LEASE_UNJUN(String lK_GA1085_LEASE_UNJUN) {
		LK_GA1085_LEASE_UNJUN = lK_GA1085_LEASE_UNJUN;
	}
	public String getLK_GA1085_JUKJE() {
		return LK_GA1085_JUKJE;
	}
	public void setLK_GA1085_JUKJE(String lK_GA1085_JUKJE) {
		LK_GA1085_JUKJE = lK_GA1085_JUKJE;
	}
	public String getLK_GA1085_REMOTE_848() {
		return LK_GA1085_REMOTE_848;
	}
	public void setLK_GA1085_REMOTE_848(String lK_GA1085_REMOTE_848) {
		LK_GA1085_REMOTE_848 = lK_GA1085_REMOTE_848;
	}
	public String getLK_GA1085_YUNRYUNG_BESU_GB() {
		return LK_GA1085_YUNRYUNG_BESU_GB;
	}
	public void setLK_GA1085_YUNRYUNG_BESU_GB(String lK_GA1085_YUNRYUNG_BESU_GB) {
		LK_GA1085_YUNRYUNG_BESU_GB = lK_GA1085_YUNRYUNG_BESU_GB;
	}
	public String getLK_GA1085_YUNRYUNG_JUN() {
		return LK_GA1085_YUNRYUNG_JUN;
	}
	public void setLK_GA1085_YUNRYUNG_JUN(String lK_GA1085_YUNRYUNG_JUN) {
		LK_GA1085_YUNRYUNG_JUN = lK_GA1085_YUNRYUNG_JUN;
	}
	public String getLK_GA1085_YUNRYUNG_JUN_YOYUL() {
		return LK_GA1085_YUNRYUNG_JUN_YOYUL;
	}
	public void setLK_GA1085_YUNRYUNG_JUN_YOYUL(String lK_GA1085_YUNRYUNG_JUN_YOYUL) {
		LK_GA1085_YUNRYUNG_JUN_YOYUL = lK_GA1085_YUNRYUNG_JUN_YOYUL;
	}
	public String getLK_GA1085_YUNRYUNG_HU() {
		return LK_GA1085_YUNRYUNG_HU;
	}
	public void setLK_GA1085_YUNRYUNG_HU(String lK_GA1085_YUNRYUNG_HU) {
		LK_GA1085_YUNRYUNG_HU = lK_GA1085_YUNRYUNG_HU;
	}
	public String getLK_GA1085_YUNRYUNG_HU_YOYUL() {
		return LK_GA1085_YUNRYUNG_HU_YOYUL;
	}
	public void setLK_GA1085_YUNRYUNG_HU_YOYUL(String lK_GA1085_YUNRYUNG_HU_YOYUL) {
		LK_GA1085_YUNRYUNG_HU_YOYUL = lK_GA1085_YUNRYUNG_HU_YOYUL;
	}
	public String getLK_GA1085_YUNRYUNG_YMD() {
		return LK_GA1085_YUNRYUNG_YMD;
	}
	public void setLK_GA1085_YUNRYUNG_YMD(String lK_GA1085_YUNRYUNG_YMD) {
		LK_GA1085_YUNRYUNG_YMD = lK_GA1085_YUNRYUNG_YMD;
	}
	public String getLK_GA1085_YUNRYUNG_GOGEK_GB() {
		return LK_GA1085_YUNRYUNG_GOGEK_GB;
	}
	public void setLK_GA1085_YUNRYUNG_GOGEK_GB(String lK_GA1085_YUNRYUNG_GOGEK_GB) {
		LK_GA1085_YUNRYUNG_GOGEK_GB = lK_GA1085_YUNRYUNG_GOGEK_GB;
	}
	public String getLK_GA1085_YUNRYUNG_GOGEK_NO() {
		return LK_GA1085_YUNRYUNG_GOGEK_NO;
	}
	public void setLK_GA1085_YUNRYUNG_GOGEK_NO(String lK_GA1085_YUNRYUNG_GOGEK_NO) {
		LK_GA1085_YUNRYUNG_GOGEK_NO = lK_GA1085_YUNRYUNG_GOGEK_NO;
	}
	public String getH_LK_GA1085_YUNRYUNG_GOGEK_NM() {
		return H_LK_GA1085_YUNRYUNG_GOGEK_NM;
	}
	public void setH_LK_GA1085_YUNRYUNG_GOGEK_NM(
			String h_LK_GA1085_YUNRYUNG_GOGEK_NM) {
		H_LK_GA1085_YUNRYUNG_GOGEK_NM = h_LK_GA1085_YUNRYUNG_GOGEK_NM;
	}
	public String getLK_GA1085_BESU_SULGYE_NO2() {
		return LK_GA1085_BESU_SULGYE_NO2;
	}
	public void setLK_GA1085_BESU_SULGYE_NO2(String lK_GA1085_BESU_SULGYE_NO2) {
		LK_GA1085_BESU_SULGYE_NO2 = lK_GA1085_BESU_SULGYE_NO2;
	}
	public String getLK_GA1085_IPRYUK_GB() {
		return LK_GA1085_IPRYUK_GB;
	}
	public void setLK_GA1085_IPRYUK_GB(String lK_GA1085_IPRYUK_GB) {
		LK_GA1085_IPRYUK_GB = lK_GA1085_IPRYUK_GB;
	}
	public String getFILLER_9() {
		return FILLER_9;
	}
	public void setFILLER_9(String fILLER_9) {
		FILLER_9 = fILLER_9;
	}
	public String getLK_GA1085_DAEIN1_BUNNAP() {
		return LK_GA1085_DAEIN1_BUNNAP;
	}
	public void setLK_GA1085_DAEIN1_BUNNAP(String lK_GA1085_DAEIN1_BUNNAP) {
		LK_GA1085_DAEIN1_BUNNAP = lK_GA1085_DAEIN1_BUNNAP;
	}
	public String getLK_GA1085_DAEIN2_BUNNAP() {
		return LK_GA1085_DAEIN2_BUNNAP;
	}
	public void setLK_GA1085_DAEIN2_BUNNAP(String lK_GA1085_DAEIN2_BUNNAP) {
		LK_GA1085_DAEIN2_BUNNAP = lK_GA1085_DAEIN2_BUNNAP;
	}
	public String getLK_GA1085_DAEMUL_BUNNAP() {
		return LK_GA1085_DAEMUL_BUNNAP;
	}
	public void setLK_GA1085_DAEMUL_BUNNAP(String lK_GA1085_DAEMUL_BUNNAP) {
		LK_GA1085_DAEMUL_BUNNAP = lK_GA1085_DAEMUL_BUNNAP;
	}
	public String getLK_GA1085_JASON_BUNNAP() {
		return LK_GA1085_JASON_BUNNAP;
	}
	public void setLK_GA1085_JASON_BUNNAP(String lK_GA1085_JASON_BUNNAP) {
		LK_GA1085_JASON_BUNNAP = lK_GA1085_JASON_BUNNAP;
	}
	public String getLK_GA1085_JACHA_BUNNAP() {
		return LK_GA1085_JACHA_BUNNAP;
	}
	public void setLK_GA1085_JACHA_BUNNAP(String lK_GA1085_JACHA_BUNNAP) {
		LK_GA1085_JACHA_BUNNAP = lK_GA1085_JACHA_BUNNAP;
	}
	public String getLK_GA1085_GIGE_BUNNAP() {
		return LK_GA1085_GIGE_BUNNAP;
	}
	public void setLK_GA1085_GIGE_BUNNAP(String lK_GA1085_GIGE_BUNNAP) {
		LK_GA1085_GIGE_BUNNAP = lK_GA1085_GIGE_BUNNAP;
	}
	public String getLK_GA1085_MUBO_BUNNAP() {
		return LK_GA1085_MUBO_BUNNAP;
	}
	public void setLK_GA1085_MUBO_BUNNAP(String lK_GA1085_MUBO_BUNNAP) {
		LK_GA1085_MUBO_BUNNAP = lK_GA1085_MUBO_BUNNAP;
	}
	public String getFILLER_10() {
		return FILLER_10;
	}
	public void setFILLER_10(String fILLER_10) {
		FILLER_10 = fILLER_10;
	}
	public String getLK_GA1085_BUNNAP_HWOICHA() {
		return LK_GA1085_BUNNAP_HWOICHA;
	}
	public void setLK_GA1085_BUNNAP_HWOICHA(String lK_GA1085_BUNNAP_HWOICHA) {
		LK_GA1085_BUNNAP_HWOICHA = lK_GA1085_BUNNAP_HWOICHA;
	}
	public String getLK_GA1085_BUNNAP_YMD() {
		return LK_GA1085_BUNNAP_YMD;
	}
	public void setLK_GA1085_BUNNAP_YMD(String lK_GA1085_BUNNAP_YMD) {
		LK_GA1085_BUNNAP_YMD = lK_GA1085_BUNNAP_YMD;
	}
	public String getLK_GA1085_BUNNAP_TOT() {
		return LK_GA1085_BUNNAP_TOT;
	}
	public void setLK_GA1085_BUNNAP_TOT(String lK_GA1085_BUNNAP_TOT) {
		LK_GA1085_BUNNAP_TOT = lK_GA1085_BUNNAP_TOT;
	}
	public String[] getLK_GA1085_HWOICHA() {
		return LK_GA1085_HWOICHA;
	}
	public void setLK_GA1085_HWOICHA(String[] lK_GA1085_HWOICHA) {
		LK_GA1085_HWOICHA = lK_GA1085_HWOICHA;
	}
	public String[] getLK_GA1085_HWOICHA_PRM() {
		return LK_GA1085_HWOICHA_PRM;
	}
	public void setLK_GA1085_HWOICHA_PRM(String[] lK_GA1085_HWOICHA_PRM) {
		LK_GA1085_HWOICHA_PRM = lK_GA1085_HWOICHA_PRM;
	}
	public String getFILLER_11() {
		return FILLER_11;
	}
	public void setFILLER_11(String fILLER_11) {
		FILLER_11 = fILLER_11;
	}
	public String getLK_GA1085_PYOUNG_SAGO_GUNSU() {
		return LK_GA1085_PYOUNG_SAGO_GUNSU;
	}
	public void setLK_GA1085_PYOUNG_SAGO_GUNSU(String lK_GA1085_PYOUNG_SAGO_GUNSU) {
		LK_GA1085_PYOUNG_SAGO_GUNSU = lK_GA1085_PYOUNG_SAGO_GUNSU;
	}
	public String getLK_GA1085_YIM_FIRST() {
		return LK_GA1085_YIM_FIRST;
	}
	public void setLK_GA1085_YIM_FIRST(String lK_GA1085_YIM_FIRST) {
		LK_GA1085_YIM_FIRST = lK_GA1085_YIM_FIRST;
	}
	public String getLK_GA1085_CHK_FIRST() {
		return LK_GA1085_CHK_FIRST;
	}
	public void setLK_GA1085_CHK_FIRST(String lK_GA1085_CHK_FIRST) {
		LK_GA1085_CHK_FIRST = lK_GA1085_CHK_FIRST;
	}
	public String getLK_GA1085_YIM_JUKYONG() {
		return LK_GA1085_YIM_JUKYONG;
	}
	public void setLK_GA1085_YIM_JUKYONG(String lK_GA1085_YIM_JUKYONG) {
		LK_GA1085_YIM_JUKYONG = lK_GA1085_YIM_JUKYONG;
	}
	public String getLK_GA1085_CHK_JUKYONG() {
		return LK_GA1085_CHK_JUKYONG;
	}
	public void setLK_GA1085_CHK_JUKYONG(String lK_GA1085_CHK_JUKYONG) {
		LK_GA1085_CHK_JUKYONG = lK_GA1085_CHK_JUKYONG;
	}
	public String getLK_GA1085_TOT_JUKYONG() {
		return LK_GA1085_TOT_JUKYONG;
	}
	public void setLK_GA1085_TOT_JUKYONG(String lK_GA1085_TOT_JUKYONG) {
		LK_GA1085_TOT_JUKYONG = lK_GA1085_TOT_JUKYONG;
	}
	public String getLK_GA1085_GR_YEAR_CNT() {
		return LK_GA1085_GR_YEAR_CNT;
	}
	public void setLK_GA1085_GR_YEAR_CNT(String lK_GA1085_GR_YEAR_CNT) {
		LK_GA1085_GR_YEAR_CNT = lK_GA1085_GR_YEAR_CNT;
	}
	public String getLK_GA1085_GR_MON_CNT() {
		return LK_GA1085_GR_MON_CNT;
	}
	public void setLK_GA1085_GR_MON_CNT(String lK_GA1085_GR_MON_CNT) {
		LK_GA1085_GR_MON_CNT = lK_GA1085_GR_MON_CNT;
	}
	public String getLK_GA1085_GR_DAY_CNT() {
		return LK_GA1085_GR_DAY_CNT;
	}
	public void setLK_GA1085_GR_DAY_CNT(String lK_GA1085_GR_DAY_CNT) {
		LK_GA1085_GR_DAY_CNT = lK_GA1085_GR_DAY_CNT;
	}
	public String getLK_GA1085_DANCHE_YN() {
		return LK_GA1085_DANCHE_YN;
	}
	public void setLK_GA1085_DANCHE_YN(String lK_GA1085_DANCHE_YN) {
		LK_GA1085_DANCHE_YN = lK_GA1085_DANCHE_YN;
	}
	public String getLK_GA1085_DANCHE_YUNGSU_GB() {
		return LK_GA1085_DANCHE_YUNGSU_GB;
	}
	public void setLK_GA1085_DANCHE_YUNGSU_GB(String lK_GA1085_DANCHE_YUNGSU_GB) {
		LK_GA1085_DANCHE_YUNGSU_GB = lK_GA1085_DANCHE_YUNGSU_GB;
	}
	public String getLK_GA1085_BOJNG_MUL_GUBUN() {
		return LK_GA1085_BOJNG_MUL_GUBUN;
	}
	public void setLK_GA1085_BOJNG_MUL_GUBUN(String lK_GA1085_BOJNG_MUL_GUBUN) {
		LK_GA1085_BOJNG_MUL_GUBUN = lK_GA1085_BOJNG_MUL_GUBUN;
	}
	public String getLK_GA1085_BEJUNG_MULGUN_YN() {
		return LK_GA1085_BEJUNG_MULGUN_YN;
	}
	public void setLK_GA1085_BEJUNG_MULGUN_YN(String lK_GA1085_BEJUNG_MULGUN_YN) {
		LK_GA1085_BEJUNG_MULGUN_YN = lK_GA1085_BEJUNG_MULGUN_YN;
	}
	public String getLK_GA1085_PYUNG_GIGAN_SYMD() {
		return LK_GA1085_PYUNG_GIGAN_SYMD;
	}
	public void setLK_GA1085_PYUNG_GIGAN_SYMD(String lK_GA1085_PYUNG_GIGAN_SYMD) {
		LK_GA1085_PYUNG_GIGAN_SYMD = lK_GA1085_PYUNG_GIGAN_SYMD;
	}
	public String getLK_GA1085_PYUNG_GIGAN_EYMD() {
		return LK_GA1085_PYUNG_GIGAN_EYMD;
	}
	public void setLK_GA1085_PYUNG_GIGAN_EYMD(String lK_GA1085_PYUNG_GIGAN_EYMD) {
		LK_GA1085_PYUNG_GIGAN_EYMD = lK_GA1085_PYUNG_GIGAN_EYMD;
	}
	public String getLK_GA1085_3_YEAR_GIGAN_SYMD() {
		return LK_GA1085_3_YEAR_GIGAN_SYMD;
	}
	public void setLK_GA1085_3_YEAR_GIGAN_SYMD(String lK_GA1085_3_YEAR_GIGAN_SYMD) {
		LK_GA1085_3_YEAR_GIGAN_SYMD = lK_GA1085_3_YEAR_GIGAN_SYMD;
	}
	public String getLK_GA1085_3_YEAR_GIGAN_EYMD() {
		return LK_GA1085_3_YEAR_GIGAN_EYMD;
	}
	public void setLK_GA1085_3_YEAR_GIGAN_EYMD(String lK_GA1085_3_YEAR_GIGAN_EYMD) {
		LK_GA1085_3_YEAR_GIGAN_EYMD = lK_GA1085_3_YEAR_GIGAN_EYMD;
	}
	public String getLK_GA1085_TOT_SAGO_GUN() {
		return LK_GA1085_TOT_SAGO_GUN;
	}
	public void setLK_GA1085_TOT_SAGO_GUN(String lK_GA1085_TOT_SAGO_GUN) {
		LK_GA1085_TOT_SAGO_GUN = lK_GA1085_TOT_SAGO_GUN;
	}
	public String getLK_GA1085_TOT_SAGO_JUMSU() {
		return LK_GA1085_TOT_SAGO_JUMSU;
	}
	public void setLK_GA1085_TOT_SAGO_JUMSU(String lK_GA1085_TOT_SAGO_JUMSU) {
		LK_GA1085_TOT_SAGO_JUMSU = lK_GA1085_TOT_SAGO_JUMSU;
	}
	public String getLK_GA1085_3_YEAR_SAGO_GUN() {
		return LK_GA1085_3_YEAR_SAGO_GUN;
	}
	public void setLK_GA1085_3_YEAR_SAGO_GUN(String lK_GA1085_3_YEAR_SAGO_GUN) {
		LK_GA1085_3_YEAR_SAGO_GUN = lK_GA1085_3_YEAR_SAGO_GUN;
	}
	public String getLK_GA1085_JUNGDAE_SAGO_YN() {
		return LK_GA1085_JUNGDAE_SAGO_YN;
	}
	public void setLK_GA1085_JUNGDAE_SAGO_YN(String lK_GA1085_JUNGDAE_SAGO_YN) {
		LK_GA1085_JUNGDAE_SAGO_YN = lK_GA1085_JUNGDAE_SAGO_YN;
	}
	public String getLK_GA1085_AVE_SONHAE_YUL() {
		return LK_GA1085_AVE_SONHAE_YUL;
	}
	public void setLK_GA1085_AVE_SONHAE_YUL(String lK_GA1085_AVE_SONHAE_YUL) {
		LK_GA1085_AVE_SONHAE_YUL = lK_GA1085_AVE_SONHAE_YUL;
	}
	public String getLK_GA1085_BUBO_CNT() {
		return LK_GA1085_BUBO_CNT;
	}
	public void setLK_GA1085_BUBO_CNT(String lK_GA1085_BUBO_CNT) {
		LK_GA1085_BUBO_CNT = lK_GA1085_BUBO_CNT;
	}
	public String getLK_GA1085_CHK_JONG_GB() {
		return LK_GA1085_CHK_JONG_GB;
	}
	public void setLK_GA1085_CHK_JONG_GB(String lK_GA1085_CHK_JONG_GB) {
		LK_GA1085_CHK_JONG_GB = lK_GA1085_CHK_JONG_GB;
	}
	public String getLK_GA1085_DAEIN_SAGO_GUN() {
		return LK_GA1085_DAEIN_SAGO_GUN;
	}
	public void setLK_GA1085_DAEIN_SAGO_GUN(String lK_GA1085_DAEIN_SAGO_GUN) {
		LK_GA1085_DAEIN_SAGO_GUN = lK_GA1085_DAEIN_SAGO_GUN;
	}
	public String getLK_GA1085_JASON_SAGO_GUN() {
		return LK_GA1085_JASON_SAGO_GUN;
	}
	public void setLK_GA1085_JASON_SAGO_GUN(String lK_GA1085_JASON_SAGO_GUN) {
		LK_GA1085_JASON_SAGO_GUN = lK_GA1085_JASON_SAGO_GUN;
	}
	public String getLK_GA1085_DAEMUL_SAGO_GUN() {
		return LK_GA1085_DAEMUL_SAGO_GUN;
	}
	public void setLK_GA1085_DAEMUL_SAGO_GUN(String lK_GA1085_DAEMUL_SAGO_GUN) {
		LK_GA1085_DAEMUL_SAGO_GUN = lK_GA1085_DAEMUL_SAGO_GUN;
	}
	public String getLK_GA1085_JUCHI_SAGO_GUN() {
		return LK_GA1085_JUCHI_SAGO_GUN;
	}
	public void setLK_GA1085_JUCHI_SAGO_GUN(String lK_GA1085_JUCHI_SAGO_GUN) {
		LK_GA1085_JUCHI_SAGO_GUN = lK_GA1085_JUCHI_SAGO_GUN;
	}
	public String getLK_GA1085_YAKMUL_SAGO_GUN() {
		return LK_GA1085_YAKMUL_SAGO_GUN;
	}
	public void setLK_GA1085_YAKMUL_SAGO_GUN(String lK_GA1085_YAKMUL_SAGO_GUN) {
		LK_GA1085_YAKMUL_SAGO_GUN = lK_GA1085_YAKMUL_SAGO_GUN;
	}
	public String getLK_GA1085_WIJANG_SAGO_GUN() {
		return LK_GA1085_WIJANG_SAGO_GUN;
	}
	public void setLK_GA1085_WIJANG_SAGO_GUN(String lK_GA1085_WIJANG_SAGO_GUN) {
		LK_GA1085_WIJANG_SAGO_GUN = lK_GA1085_WIJANG_SAGO_GUN;
	}
	public String getLK_GA1085_DOJU_SAGO_GUN() {
		return LK_GA1085_DOJU_SAGO_GUN;
	}
	public void setLK_GA1085_DOJU_SAGO_GUN(String lK_GA1085_DOJU_SAGO_GUN) {
		LK_GA1085_DOJU_SAGO_GUN = lK_GA1085_DOJU_SAGO_GUN;
	}
	public String getLK_GA1085_BUMJOI_SAGO_GUN() {
		return LK_GA1085_BUMJOI_SAGO_GUN;
	}
	public void setLK_GA1085_BUMJOI_SAGO_GUN(String lK_GA1085_BUMJOI_SAGO_GUN) {
		LK_GA1085_BUMJOI_SAGO_GUN = lK_GA1085_BUMJOI_SAGO_GUN;
	}
	public String getLK_GA1085_JUNGDAE_SAGO_GUN() {
		return LK_GA1085_JUNGDAE_SAGO_GUN;
	}
	public void setLK_GA1085_JUNGDAE_SAGO_GUN(String lK_GA1085_JUNGDAE_SAGO_GUN) {
		LK_GA1085_JUNGDAE_SAGO_GUN = lK_GA1085_JUNGDAE_SAGO_GUN;
	}
	public String getLK_GA1085_3_DAEIN_SAGO_GUN() {
		return LK_GA1085_3_DAEIN_SAGO_GUN;
	}
	public void setLK_GA1085_3_DAEIN_SAGO_GUN(String lK_GA1085_3_DAEIN_SAGO_GUN) {
		LK_GA1085_3_DAEIN_SAGO_GUN = lK_GA1085_3_DAEIN_SAGO_GUN;
	}
	public String getLK_GA1085_JUN_INSU_GB() {
		return LK_GA1085_JUN_INSU_GB;
	}
	public void setLK_GA1085_JUN_INSU_GB(String lK_GA1085_JUN_INSU_GB) {
		LK_GA1085_JUN_INSU_GB = lK_GA1085_JUN_INSU_GB;
	}
	public String getLK_GA1085_CHAJONG_SN_GB() {
		return LK_GA1085_CHAJONG_SN_GB;
	}
	public void setLK_GA1085_CHAJONG_SN_GB(String lK_GA1085_CHAJONG_SN_GB) {
		LK_GA1085_CHAJONG_SN_GB = lK_GA1085_CHAJONG_SN_GB;
	}
	public String getLK_GA1085_JUN_BOHUMJA_CD() {
		return LK_GA1085_JUN_BOHUMJA_CD;
	}
	public void setLK_GA1085_JUN_BOHUMJA_CD(String lK_GA1085_JUN_BOHUMJA_CD) {
		LK_GA1085_JUN_BOHUMJA_CD = lK_GA1085_JUN_BOHUMJA_CD;
	}
	public String getLK_GA1085_JUN_BJ_CD() {
		return LK_GA1085_JUN_BJ_CD;
	}
	public void setLK_GA1085_JUN_BJ_CD(String lK_GA1085_JUN_BJ_CD) {
		LK_GA1085_JUN_BJ_CD = lK_GA1085_JUN_BJ_CD;
	}
	public String getLK_GA1085_JUN_POLI_NO() {
		return LK_GA1085_JUN_POLI_NO;
	}
	public void setLK_GA1085_JUN_POLI_NO(String lK_GA1085_JUN_POLI_NO) {
		LK_GA1085_JUN_POLI_NO = lK_GA1085_JUN_POLI_NO;
	}
	public String getLK_GA1085_JUN_GIGAN_SYMD() {
		return LK_GA1085_JUN_GIGAN_SYMD;
	}
	public void setLK_GA1085_JUN_GIGAN_SYMD(String lK_GA1085_JUN_GIGAN_SYMD) {
		LK_GA1085_JUN_GIGAN_SYMD = lK_GA1085_JUN_GIGAN_SYMD;
	}
	public String getLK_GA1085_JUN_GIGAN_EYMD() {
		return LK_GA1085_JUN_GIGAN_EYMD;
	}
	public void setLK_GA1085_JUN_GIGAN_EYMD(String lK_GA1085_JUN_GIGAN_EYMD) {
		LK_GA1085_JUN_GIGAN_EYMD = lK_GA1085_JUN_GIGAN_EYMD;
	}
	public String getH_LK_GA1085_JUN_JOJIKWON_NAME() {
		return H_LK_GA1085_JUN_JOJIKWON_NAME;
	}
	public void setH_LK_GA1085_JUN_JOJIKWON_NAME(
			String h_LK_GA1085_JUN_JOJIKWON_NAME) {
		H_LK_GA1085_JUN_JOJIKWON_NAME = h_LK_GA1085_JUN_JOJIKWON_NAME;
	}
	public String getLK_GA1085_JUN_JOJIKWON_TEL_NO() {
		return LK_GA1085_JUN_JOJIKWON_TEL_NO;
	}
	public void setLK_GA1085_JUN_JOJIKWON_TEL_NO(
			String lK_GA1085_JUN_JOJIKWON_TEL_NO) {
		LK_GA1085_JUN_JOJIKWON_TEL_NO = lK_GA1085_JUN_JOJIKWON_TEL_NO;
	}
	public String getFILLER_12() {
		return FILLER_12;
	}
	public void setFILLER_12(String fILLER_12) {
		FILLER_12 = fILLER_12;
	}
	public String getLK_GA1085_JUN_HAL_YIM_HALIN() {
		return LK_GA1085_JUN_HAL_YIM_HALIN;
	}
	public void setLK_GA1085_JUN_HAL_YIM_HALIN(String lK_GA1085_JUN_HAL_YIM_HALIN) {
		LK_GA1085_JUN_HAL_YIM_HALIN = lK_GA1085_JUN_HAL_YIM_HALIN;
	}
	public String getLK_GA1085_JUN_HAL_YIM_BUMWI() {
		return LK_GA1085_JUN_HAL_YIM_BUMWI;
	}
	public void setLK_GA1085_JUN_HAL_YIM_BUMWI(String lK_GA1085_JUN_HAL_YIM_BUMWI) {
		LK_GA1085_JUN_HAL_YIM_BUMWI = lK_GA1085_JUN_HAL_YIM_BUMWI;
	}
	public String getLK_GA1085_JUN_HAL_CHK_HALIN() {
		return LK_GA1085_JUN_HAL_CHK_HALIN;
	}
	public void setLK_GA1085_JUN_HAL_CHK_HALIN(String lK_GA1085_JUN_HAL_CHK_HALIN) {
		LK_GA1085_JUN_HAL_CHK_HALIN = lK_GA1085_JUN_HAL_CHK_HALIN;
	}
	public String getLK_GA1085_JUN_HAL_CHK_BUMWI() {
		return LK_GA1085_JUN_HAL_CHK_BUMWI;
	}
	public void setLK_GA1085_JUN_HAL_CHK_BUMWI(String lK_GA1085_JUN_HAL_CHK_BUMWI) {
		LK_GA1085_JUN_HAL_CHK_BUMWI = lK_GA1085_JUN_HAL_CHK_BUMWI;
	}
	public String getLK_GA1085_JUN_HAL_TUKBUL() {
		return LK_GA1085_JUN_HAL_TUKBUL;
	}
	public void setLK_GA1085_JUN_HAL_TUKBUL(String lK_GA1085_JUN_HAL_TUKBUL) {
		LK_GA1085_JUN_HAL_TUKBUL = lK_GA1085_JUN_HAL_TUKBUL;
	}
	public String getLK_GA1085_JUN_HAL_TUKBUL_CD() {
		return LK_GA1085_JUN_HAL_TUKBUL_CD;
	}
	public void setLK_GA1085_JUN_HAL_TUKBUL_CD(String lK_GA1085_JUN_HAL_TUKBUL_CD) {
		LK_GA1085_JUN_HAL_TUKBUL_CD = lK_GA1085_JUN_HAL_TUKBUL_CD;
	}
	public String getLK_GA1085_JUN_GAIP_CHK_GUNGRUK() {
		return LK_GA1085_JUN_GAIP_CHK_GUNGRUK;
	}
	public void setLK_GA1085_JUN_GAIP_CHK_GUNGRUK(
			String lK_GA1085_JUN_GAIP_CHK_GUNGRUK) {
		LK_GA1085_JUN_GAIP_CHK_GUNGRUK = lK_GA1085_JUN_GAIP_CHK_GUNGRUK;
	}
	public String getLK_GA1085_JUN_GAIP_CHK_BUMWI() {
		return LK_GA1085_JUN_GAIP_CHK_BUMWI;
	}
	public void setLK_GA1085_JUN_GAIP_CHK_BUMWI(String lK_GA1085_JUN_GAIP_CHK_BUMWI) {
		LK_GA1085_JUN_GAIP_CHK_BUMWI = lK_GA1085_JUN_GAIP_CHK_BUMWI;
	}
	public String getLK_GA1085_JUN_GAIP_CHK_TOT() {
		return LK_GA1085_JUN_GAIP_CHK_TOT;
	}
	public void setLK_GA1085_JUN_GAIP_CHK_TOT(String lK_GA1085_JUN_GAIP_CHK_TOT) {
		LK_GA1085_JUN_GAIP_CHK_TOT = lK_GA1085_JUN_GAIP_CHK_TOT;
	}
	public String getLK_GA1085_JUN_GAIP_YIM_GUNGRUK() {
		return LK_GA1085_JUN_GAIP_YIM_GUNGRUK;
	}
	public void setLK_GA1085_JUN_GAIP_YIM_GUNGRUK(
			String lK_GA1085_JUN_GAIP_YIM_GUNGRUK) {
		LK_GA1085_JUN_GAIP_YIM_GUNGRUK = lK_GA1085_JUN_GAIP_YIM_GUNGRUK;
	}
	public String getLK_GA1085_JUN_GAIP_YIM_BUMWI() {
		return LK_GA1085_JUN_GAIP_YIM_BUMWI;
	}
	public void setLK_GA1085_JUN_GAIP_YIM_BUMWI(String lK_GA1085_JUN_GAIP_YIM_BUMWI) {
		LK_GA1085_JUN_GAIP_YIM_BUMWI = lK_GA1085_JUN_GAIP_YIM_BUMWI;
	}
	public String getLK_GA1085_JUN_GAIP_YIM_GOTONG() {
		return LK_GA1085_JUN_GAIP_YIM_GOTONG;
	}
	public void setLK_GA1085_JUN_GAIP_YIM_GOTONG(
			String lK_GA1085_JUN_GAIP_YIM_GOTONG) {
		LK_GA1085_JUN_GAIP_YIM_GOTONG = lK_GA1085_JUN_GAIP_YIM_GOTONG;
	}
	public String getLK_GA1085_JUN_GAIP_YIM_TOT() {
		return LK_GA1085_JUN_GAIP_YIM_TOT;
	}
	public void setLK_GA1085_JUN_GAIP_YIM_TOT(String lK_GA1085_JUN_GAIP_YIM_TOT) {
		LK_GA1085_JUN_GAIP_YIM_TOT = lK_GA1085_JUN_GAIP_YIM_TOT;
	}
	public String getLK_GA1085_JONGGI_ILCHI_GB() {
		return LK_GA1085_JONGGI_ILCHI_GB;
	}
	public void setLK_GA1085_JONGGI_ILCHI_GB(String lK_GA1085_JONGGI_ILCHI_GB) {
		LK_GA1085_JONGGI_ILCHI_GB = lK_GA1085_JONGGI_ILCHI_GB;
	}
	public String getLK_GA1085_SIMSA_GB() {
		return LK_GA1085_SIMSA_GB;
	}
	public void setLK_GA1085_SIMSA_GB(String lK_GA1085_SIMSA_GB) {
		LK_GA1085_SIMSA_GB = lK_GA1085_SIMSA_GB;
	}
	public String getLK_GA1085_BOHUMJA_CD() {
		return LK_GA1085_BOHUMJA_CD;
	}
	public void setLK_GA1085_BOHUMJA_CD(String lK_GA1085_BOHUMJA_CD) {
		LK_GA1085_BOHUMJA_CD = lK_GA1085_BOHUMJA_CD;
	}
	public String getLK_GA1085_GYEYAK_SANGTE_CD() {
		return LK_GA1085_GYEYAK_SANGTE_CD;
	}
	public void setLK_GA1085_GYEYAK_SANGTE_CD(String lK_GA1085_GYEYAK_SANGTE_CD) {
		LK_GA1085_GYEYAK_SANGTE_CD = lK_GA1085_GYEYAK_SANGTE_CD;
	}
	public String getLK_GA1085_MANGI_GENGSIN_GB() {
		return LK_GA1085_MANGI_GENGSIN_GB;
	}
	public void setLK_GA1085_MANGI_GENGSIN_GB(String lK_GA1085_MANGI_GENGSIN_GB) {
		LK_GA1085_MANGI_GENGSIN_GB = lK_GA1085_MANGI_GENGSIN_GB;
	}
	public String getLK_GA1085_PLAN_GB() {
		return LK_GA1085_PLAN_GB;
	}
	public void setLK_GA1085_PLAN_GB(String lK_GA1085_PLAN_GB) {
		LK_GA1085_PLAN_GB = lK_GA1085_PLAN_GB;
	}
	public String getLK_GA1085_DEUNGROK_YMD() {
		return LK_GA1085_DEUNGROK_YMD;
	}
	public void setLK_GA1085_DEUNGROK_YMD(String lK_GA1085_DEUNGROK_YMD) {
		LK_GA1085_DEUNGROK_YMD = lK_GA1085_DEUNGROK_YMD;
	}
	public String getLK_GA1085_C_UNJ_GOGEK_NO() {
		return LK_GA1085_C_UNJ_GOGEK_NO;
	}
	public void setLK_GA1085_C_UNJ_GOGEK_NO(String lK_GA1085_C_UNJ_GOGEK_NO) {
		LK_GA1085_C_UNJ_GOGEK_NO = lK_GA1085_C_UNJ_GOGEK_NO;
	}
	public String getLK_GA1085_C_UNJ_GOGEK_GB() {
		return LK_GA1085_C_UNJ_GOGEK_GB;
	}
	public void setLK_GA1085_C_UNJ_GOGEK_GB(String lK_GA1085_C_UNJ_GOGEK_GB) {
		LK_GA1085_C_UNJ_GOGEK_GB = lK_GA1085_C_UNJ_GOGEK_GB;
	}
	public String getLK_GA1085_C_UNJ_CONTROL_NO() {
		return LK_GA1085_C_UNJ_CONTROL_NO;
	}
	public void setLK_GA1085_C_UNJ_CONTROL_NO(String lK_GA1085_C_UNJ_CONTROL_NO) {
		LK_GA1085_C_UNJ_CONTROL_NO = lK_GA1085_C_UNJ_CONTROL_NO;
	}
	public String getH_LK_GA1085_C_UNJ_GOGEK_NAME() {
		return H_LK_GA1085_C_UNJ_GOGEK_NAME;
	}
	public void setH_LK_GA1085_C_UNJ_GOGEK_NAME(String h_LK_GA1085_C_UNJ_GOGEK_NAME) {
		H_LK_GA1085_C_UNJ_GOGEK_NAME = h_LK_GA1085_C_UNJ_GOGEK_NAME;
	}
	public String getLK_GA1085_C_UNJ_MYUNHE_NO() {
		return LK_GA1085_C_UNJ_MYUNHE_NO;
	}
	public void setLK_GA1085_C_UNJ_MYUNHE_NO(String lK_GA1085_C_UNJ_MYUNHE_NO) {
		LK_GA1085_C_UNJ_MYUNHE_NO = lK_GA1085_C_UNJ_MYUNHE_NO;
	}
	public String getLK_GA1085_C_UNJ_MYUNHE_Y() {
		return LK_GA1085_C_UNJ_MYUNHE_Y;
	}
	public void setLK_GA1085_C_UNJ_MYUNHE_Y(String lK_GA1085_C_UNJ_MYUNHE_Y) {
		LK_GA1085_C_UNJ_MYUNHE_Y = lK_GA1085_C_UNJ_MYUNHE_Y;
	}
	public String getLK_GA1085_C_UNJ_GYULHON_YN() {
		return LK_GA1085_C_UNJ_GYULHON_YN;
	}
	public void setLK_GA1085_C_UNJ_GYULHON_YN(String lK_GA1085_C_UNJ_GYULHON_YN) {
		LK_GA1085_C_UNJ_GYULHON_YN = lK_GA1085_C_UNJ_GYULHON_YN;
	}
	public String getLK_GA1085_C_UNJ_YUNRYUNG() {
		return LK_GA1085_C_UNJ_YUNRYUNG;
	}
	public void setLK_GA1085_C_UNJ_YUNRYUNG(String lK_GA1085_C_UNJ_YUNRYUNG) {
		LK_GA1085_C_UNJ_YUNRYUNG = lK_GA1085_C_UNJ_YUNRYUNG;
	}
	public String getLK_GA1085_C_UNJ_JOB_TYPE() {
		return LK_GA1085_C_UNJ_JOB_TYPE;
	}
	public void setLK_GA1085_C_UNJ_JOB_TYPE(String lK_GA1085_C_UNJ_JOB_TYPE) {
		LK_GA1085_C_UNJ_JOB_TYPE = lK_GA1085_C_UNJ_JOB_TYPE;
	}
	public String getLK_GA1085_C_UNJ_JOB_CD() {
		return LK_GA1085_C_UNJ_JOB_CD;
	}
	public void setLK_GA1085_C_UNJ_JOB_CD(String lK_GA1085_C_UNJ_JOB_CD) {
		LK_GA1085_C_UNJ_JOB_CD = lK_GA1085_C_UNJ_JOB_CD;
	}
	public String getLK_GA1085_C_UNJ_GWANGE() {
		return LK_GA1085_C_UNJ_GWANGE;
	}
	public void setLK_GA1085_C_UNJ_GWANGE(String lK_GA1085_C_UNJ_GWANGE) {
		LK_GA1085_C_UNJ_GWANGE = lK_GA1085_C_UNJ_GWANGE;
	}
	public String getLK_GA1085_DEMUL_ILHAL_GB() {
		return LK_GA1085_DEMUL_ILHAL_GB;
	}
	public void setLK_GA1085_DEMUL_ILHAL_GB(String lK_GA1085_DEMUL_ILHAL_GB) {
		LK_GA1085_DEMUL_ILHAL_GB = lK_GA1085_DEMUL_ILHAL_GB;
	}
	public String getLK_GA1085_CHANNEL_CD() {
		return LK_GA1085_CHANNEL_CD;
	}
	public void setLK_GA1085_CHANNEL_CD(String lK_GA1085_CHANNEL_CD) {
		LK_GA1085_CHANNEL_CD = lK_GA1085_CHANNEL_CD;
	}
	public String getLK_GA1085_GITA_GONGJE_GMEK() {
		return LK_GA1085_GITA_GONGJE_GMEK;
	}
	public void setLK_GA1085_GITA_GONGJE_GMEK(String lK_GA1085_GITA_GONGJE_GMEK) {
		LK_GA1085_GITA_GONGJE_GMEK = lK_GA1085_GITA_GONGJE_GMEK;
	}
	public String getFILLER_13() {
		return FILLER_13;
	}
	public void setFILLER_13(String fILLER_13) {
		FILLER_13 = fILLER_13;
	}
	public String getLK_GA1085_SUIKJA_GOGEKNO() {
		return LK_GA1085_SUIKJA_GOGEKNO;
	}
	public void setLK_GA1085_SUIKJA_GOGEKNO(String lK_GA1085_SUIKJA_GOGEKNO) {
		LK_GA1085_SUIKJA_GOGEKNO = lK_GA1085_SUIKJA_GOGEKNO;
	}
	public String getLK_GA1085_SUIKJA_GOGEKGB() {
		return LK_GA1085_SUIKJA_GOGEKGB;
	}
	public void setLK_GA1085_SUIKJA_GOGEKGB(String lK_GA1085_SUIKJA_GOGEKGB) {
		LK_GA1085_SUIKJA_GOGEKGB = lK_GA1085_SUIKJA_GOGEKGB;
	}
	public String getH_LK_GA1085_SUIKJA_NAME() {
		return H_LK_GA1085_SUIKJA_NAME;
	}
	public void setH_LK_GA1085_SUIKJA_NAME(String h_LK_GA1085_SUIKJA_NAME) {
		H_LK_GA1085_SUIKJA_NAME = h_LK_GA1085_SUIKJA_NAME;
	}
	public String getLK_GA1085_PIBO_GWANGE() {
		return LK_GA1085_PIBO_GWANGE;
	}
	public void setLK_GA1085_PIBO_GWANGE(String lK_GA1085_PIBO_GWANGE) {
		LK_GA1085_PIBO_GWANGE = lK_GA1085_PIBO_GWANGE;
	}
	public String getLK_GA1085_SUIKJA_ZIP() {
		return LK_GA1085_SUIKJA_ZIP;
	}
	public void setLK_GA1085_SUIKJA_ZIP(String lK_GA1085_SUIKJA_ZIP) {
		LK_GA1085_SUIKJA_ZIP = lK_GA1085_SUIKJA_ZIP;
	}
	public String getH_LK_GA1085_SUIKJA_GITA_ADDR() {
		return H_LK_GA1085_SUIKJA_GITA_ADDR;
	}
	public void setH_LK_GA1085_SUIKJA_GITA_ADDR(String h_LK_GA1085_SUIKJA_GITA_ADDR) {
		H_LK_GA1085_SUIKJA_GITA_ADDR = h_LK_GA1085_SUIKJA_GITA_ADDR;
	}
	public String getLK_GA1085_HP_TEL1_NO1() {
		return LK_GA1085_HP_TEL1_NO1;
	}
	public void setLK_GA1085_HP_TEL1_NO1(String lK_GA1085_HP_TEL1_NO1) {
		LK_GA1085_HP_TEL1_NO1 = lK_GA1085_HP_TEL1_NO1;
	}
	public String getLK_GA1085_HP_TEL1_NO2() {
		return LK_GA1085_HP_TEL1_NO2;
	}
	public void setLK_GA1085_HP_TEL1_NO2(String lK_GA1085_HP_TEL1_NO2) {
		LK_GA1085_HP_TEL1_NO2 = lK_GA1085_HP_TEL1_NO2;
	}
	public String getLK_GA1085_HP_TEL1_NO3() {
		return LK_GA1085_HP_TEL1_NO3;
	}
	public void setLK_GA1085_HP_TEL1_NO3(String lK_GA1085_HP_TEL1_NO3) {
		LK_GA1085_HP_TEL1_NO3 = lK_GA1085_HP_TEL1_NO3;
	}
	public String getLK_GA1085_HOME_TEL2_NO1() {
		return LK_GA1085_HOME_TEL2_NO1;
	}
	public void setLK_GA1085_HOME_TEL2_NO1(String lK_GA1085_HOME_TEL2_NO1) {
		LK_GA1085_HOME_TEL2_NO1 = lK_GA1085_HOME_TEL2_NO1;
	}
	public String getLK_GA1085_HOME_TEL2_NO2() {
		return LK_GA1085_HOME_TEL2_NO2;
	}
	public void setLK_GA1085_HOME_TEL2_NO2(String lK_GA1085_HOME_TEL2_NO2) {
		LK_GA1085_HOME_TEL2_NO2 = lK_GA1085_HOME_TEL2_NO2;
	}
	public String getLK_GA1085_HOME_TEL2_NO3() {
		return LK_GA1085_HOME_TEL2_NO3;
	}
	public void setLK_GA1085_HOME_TEL2_NO3(String lK_GA1085_HOME_TEL2_NO3) {
		LK_GA1085_HOME_TEL2_NO3 = lK_GA1085_HOME_TEL2_NO3;
	}
	public String getLK_GA1085_GOTONG_803() {
		return LK_GA1085_GOTONG_803;
	}
	public void setLK_GA1085_GOTONG_803(String lK_GA1085_GOTONG_803) {
		LK_GA1085_GOTONG_803 = lK_GA1085_GOTONG_803;
	}
	public String getLK_GA1085_GYEONIN_806() {
		return LK_GA1085_GYEONIN_806;
	}
	public void setLK_GA1085_GYEONIN_806(String lK_GA1085_GYEONIN_806) {
		LK_GA1085_GYEONIN_806 = lK_GA1085_GYEONIN_806;
	}
	public String getLK_GA1085_FOR_RENT_YN_807() {
		return LK_GA1085_FOR_RENT_YN_807;
	}
	public void setLK_GA1085_FOR_RENT_YN_807(String lK_GA1085_FOR_RENT_YN_807) {
		LK_GA1085_FOR_RENT_YN_807 = lK_GA1085_FOR_RENT_YN_807;
	}
	public String getLK_GA1085_FOR_UNBAN_YN_808() {
		return LK_GA1085_FOR_UNBAN_YN_808;
	}
	public void setLK_GA1085_FOR_UNBAN_YN_808(String lK_GA1085_FOR_UNBAN_YN_808) {
		LK_GA1085_FOR_UNBAN_YN_808 = lK_GA1085_FOR_UNBAN_YN_808;
	}
	public String getLK_GA1085_SINGA_VIP_YN_809() {
		return LK_GA1085_SINGA_VIP_YN_809;
	}
	public void setLK_GA1085_SINGA_VIP_YN_809(String lK_GA1085_SINGA_VIP_YN_809) {
		LK_GA1085_SINGA_VIP_YN_809 = lK_GA1085_SINGA_VIP_YN_809;
	}
	public String getLK_GA1085_GANTAK_YN_810() {
		return LK_GA1085_GANTAK_YN_810;
	}
	public void setLK_GA1085_GANTAK_YN_810(String lK_GA1085_GANTAK_YN_810) {
		LK_GA1085_GANTAK_YN_810 = lK_GA1085_GANTAK_YN_810;
	}
	public String getLK_GA1085_BYUNG_VIP_YN_820() {
		return LK_GA1085_BYUNG_VIP_YN_820;
	}
	public void setLK_GA1085_BYUNG_VIP_YN_820(String lK_GA1085_BYUNG_VIP_YN_820) {
		LK_GA1085_BYUNG_VIP_YN_820 = lK_GA1085_BYUNG_VIP_YN_820;
	}
	public String getLK_GA1085_GOLF_YN_893() {
		return LK_GA1085_GOLF_YN_893;
	}
	public void setLK_GA1085_GOLF_YN_893(String lK_GA1085_GOLF_YN_893) {
		LK_GA1085_GOLF_YN_893 = lK_GA1085_GOLF_YN_893;
	}
	public String getLK_GA1085_BOOKING_YN_894() {
		return LK_GA1085_BOOKING_YN_894;
	}
	public void setLK_GA1085_BOOKING_YN_894(String lK_GA1085_BOOKING_YN_894) {
		LK_GA1085_BOOKING_YN_894 = lK_GA1085_BOOKING_YN_894;
	}
	public String getLK_GA1085_LIFE_YN_895() {
		return LK_GA1085_LIFE_YN_895;
	}
	public void setLK_GA1085_LIFE_YN_895(String lK_GA1085_LIFE_YN_895) {
		LK_GA1085_LIFE_YN_895 = lK_GA1085_LIFE_YN_895;
	}
	public String[] getLK_GA1085_BUSOK_CD() {
		return LK_GA1085_BUSOK_CD;
	}
	public void setLK_GA1085_BUSOK_CD(String[] lK_GA1085_BUSOK_CD) {
		LK_GA1085_BUSOK_CD = lK_GA1085_BUSOK_CD;
	}
	public String[] getLK_GA1085_BUSOK_GAEK() {
		return LK_GA1085_BUSOK_GAEK;
	}
	public void setLK_GA1085_BUSOK_GAEK(String[] lK_GA1085_BUSOK_GAEK) {
		LK_GA1085_BUSOK_GAEK = lK_GA1085_BUSOK_GAEK;
	}
	public String getLK_GA1085_HAL_CHK_DUNGGUP() {
		return LK_GA1085_HAL_CHK_DUNGGUP;
	}
	public void setLK_GA1085_HAL_CHK_DUNGGUP(String lK_GA1085_HAL_CHK_DUNGGUP) {
		LK_GA1085_HAL_CHK_DUNGGUP = lK_GA1085_HAL_CHK_DUNGGUP;
	}
	public String getLK_GA1085_HAL_YIM_DUNGGUP() {
		return LK_GA1085_HAL_YIM_DUNGGUP;
	}
	public void setLK_GA1085_HAL_YIM_DUNGGUP(String lK_GA1085_HAL_YIM_DUNGGUP) {
		LK_GA1085_HAL_YIM_DUNGGUP = lK_GA1085_HAL_YIM_DUNGGUP;
	}
	public String getLK_GA1085_JUN_HAL_YIM_DUNGGUP() {
		return LK_GA1085_JUN_HAL_YIM_DUNGGUP;
	}
	public void setLK_GA1085_JUN_HAL_YIM_DUNGGUP(
			String lK_GA1085_JUN_HAL_YIM_DUNGGUP) {
		LK_GA1085_JUN_HAL_YIM_DUNGGUP = lK_GA1085_JUN_HAL_YIM_DUNGGUP;
	}
	public String getLK_GA1085_JUN_HAL_CHK_DUNGGUP() {
		return LK_GA1085_JUN_HAL_CHK_DUNGGUP;
	}
	public void setLK_GA1085_JUN_HAL_CHK_DUNGGUP(
			String lK_GA1085_JUN_HAL_CHK_DUNGGUP) {
		LK_GA1085_JUN_HAL_CHK_DUNGGUP = lK_GA1085_JUN_HAL_CHK_DUNGGUP;
	}
	public String getLK_GA1085_MODEL_DUNGGUP() {
		return LK_GA1085_MODEL_DUNGGUP;
	}
	public void setLK_GA1085_MODEL_DUNGGUP(String lK_GA1085_MODEL_DUNGGUP) {
		LK_GA1085_MODEL_DUNGGUP = lK_GA1085_MODEL_DUNGGUP;
	}
	public String getLK_GA1085_MODEL_YUL() {
		return LK_GA1085_MODEL_YUL;
	}
	public void setLK_GA1085_MODEL_YUL(String lK_GA1085_MODEL_YUL) {
		LK_GA1085_MODEL_YUL = lK_GA1085_MODEL_YUL;
	}
	public String getFILLER_14() {
		return FILLER_14;
	}
	public void setFILLER_14(String fILLER_14) {
		FILLER_14 = fILLER_14;
	}
	public String getLK_GA1085_YN_850() {
		return LK_GA1085_YN_850;
	}
	public void setLK_GA1085_YN_850(String lK_GA1085_YN_850) {
		LK_GA1085_YN_850 = lK_GA1085_YN_850;
	}
	public String getLK_GA1085_YN_879() {
		return LK_GA1085_YN_879;
	}
	public void setLK_GA1085_YN_879(String lK_GA1085_YN_879) {
		LK_GA1085_YN_879 = lK_GA1085_YN_879;
	}
	public String getLK_GA1085_YN_885() {
		return LK_GA1085_YN_885;
	}
	public void setLK_GA1085_YN_885(String lK_GA1085_YN_885) {
		LK_GA1085_YN_885 = lK_GA1085_YN_885;
	}
	public String getLK_GA1085_YN_897() {
		return LK_GA1085_YN_897;
	}
	public void setLK_GA1085_YN_897(String lK_GA1085_YN_897) {
		LK_GA1085_YN_897 = lK_GA1085_YN_897;
	}
	public String getLK_GA1085_YN_898() {
		return LK_GA1085_YN_898;
	}
	public void setLK_GA1085_YN_898(String lK_GA1085_YN_898) {
		LK_GA1085_YN_898 = lK_GA1085_YN_898;
	}
	public String getLK_GA1085_YN_903() {
		return LK_GA1085_YN_903;
	}
	public void setLK_GA1085_YN_903(String lK_GA1085_YN_903) {
		LK_GA1085_YN_903 = lK_GA1085_YN_903;
	}
	public String getLK_GA1085_YN_904() {
		return LK_GA1085_YN_904;
	}
	public void setLK_GA1085_YN_904(String lK_GA1085_YN_904) {
		LK_GA1085_YN_904 = lK_GA1085_YN_904;
	}
	public String getLK_GA1085_903_904_GAIP_GMEK() {
		return LK_GA1085_903_904_GAIP_GMEK;
	}
	public void setLK_GA1085_903_904_GAIP_GMEK(String lK_GA1085_903_904_GAIP_GMEK) {
		LK_GA1085_903_904_GAIP_GMEK = lK_GA1085_903_904_GAIP_GMEK;
	}
	public String getLK_GA1085_YN_905() {
		return LK_GA1085_YN_905;
	}
	public void setLK_GA1085_YN_905(String lK_GA1085_YN_905) {
		LK_GA1085_YN_905 = lK_GA1085_YN_905;
	}
	public String getLK_GA1085_YN_906() {
		return LK_GA1085_YN_906;
	}
	public void setLK_GA1085_YN_906(String lK_GA1085_YN_906) {
		LK_GA1085_YN_906 = lK_GA1085_YN_906;
	}
	public String getLK_GA1085_905_906_GAIP_GMEK() {
		return LK_GA1085_905_906_GAIP_GMEK;
	}
	public void setLK_GA1085_905_906_GAIP_GMEK(String lK_GA1085_905_906_GAIP_GMEK) {
		LK_GA1085_905_906_GAIP_GMEK = lK_GA1085_905_906_GAIP_GMEK;
	}
	public String getLK_GA1085_GAJOK_PACK_GB() {
		return LK_GA1085_GAJOK_PACK_GB;
	}
	public void setLK_GA1085_GAJOK_PACK_GB(String lK_GA1085_GAJOK_PACK_GB) {
		LK_GA1085_GAJOK_PACK_GB = lK_GA1085_GAJOK_PACK_GB;
	}
	public String getLK_GA1085_JANYEO_PACK_GB() {
		return LK_GA1085_JANYEO_PACK_GB;
	}
	public void setLK_GA1085_JANYEO_PACK_GB(String lK_GA1085_JANYEO_PACK_GB) {
		LK_GA1085_JANYEO_PACK_GB = lK_GA1085_JANYEO_PACK_GB;
	}
	public String getLK_GA1085_UNJUNJA_PACK_GB() {
		return LK_GA1085_UNJUNJA_PACK_GB;
	}
	public void setLK_GA1085_UNJUNJA_PACK_GB(String lK_GA1085_UNJUNJA_PACK_GB) {
		LK_GA1085_UNJUNJA_PACK_GB = lK_GA1085_UNJUNJA_PACK_GB;
	}
	public String getLK_GA1085_NAECHA_PACK_GB() {
		return LK_GA1085_NAECHA_PACK_GB;
	}
	public void setLK_GA1085_NAECHA_PACK_GB(String lK_GA1085_NAECHA_PACK_GB) {
		LK_GA1085_NAECHA_PACK_GB = lK_GA1085_NAECHA_PACK_GB;
	}
	public String getLK_GA1085_JUMAL_PACK_GB() {
		return LK_GA1085_JUMAL_PACK_GB;
	}
	public void setLK_GA1085_JUMAL_PACK_GB(String lK_GA1085_JUMAL_PACK_GB) {
		LK_GA1085_JUMAL_PACK_GB = lK_GA1085_JUMAL_PACK_GB;
	}
	public String getLK_GA1085_JIKWON_PACK_GB() {
		return LK_GA1085_JIKWON_PACK_GB;
	}
	public void setLK_GA1085_JIKWON_PACK_GB(String lK_GA1085_JIKWON_PACK_GB) {
		LK_GA1085_JIKWON_PACK_GB = lK_GA1085_JIKWON_PACK_GB;
	}
	public String getLK_GA1085_FREE_PACK_GB() {
		return LK_GA1085_FREE_PACK_GB;
	}
	public void setLK_GA1085_FREE_PACK_GB(String lK_GA1085_FREE_PACK_GB) {
		LK_GA1085_FREE_PACK_GB = lK_GA1085_FREE_PACK_GB;
	}
	public String getLK_GA1085_CAR_CD_IMSI_GB() {
		return LK_GA1085_CAR_CD_IMSI_GB;
	}
	public void setLK_GA1085_CAR_CD_IMSI_GB(String lK_GA1085_CAR_CD_IMSI_GB) {
		LK_GA1085_CAR_CD_IMSI_GB = lK_GA1085_CAR_CD_IMSI_GB;
	}
	public String getLK_GA1085_YN_910() {
		return LK_GA1085_YN_910;
	}
	public void setLK_GA1085_YN_910(String lK_GA1085_YN_910) {
		LK_GA1085_YN_910 = lK_GA1085_YN_910;
	}
	public String getLK_GA1085_S_WEEK_DAY() {
		return LK_GA1085_S_WEEK_DAY;
	}
	public void setLK_GA1085_S_WEEK_DAY(String lK_GA1085_S_WEEK_DAY) {
		LK_GA1085_S_WEEK_DAY = lK_GA1085_S_WEEK_DAY;
	}
	public String getLK_GA1085_BUBRUL4_GB() {
		return LK_GA1085_BUBRUL4_GB;
	}
	public void setLK_GA1085_BUBRUL4_GB(String lK_GA1085_BUBRUL4_GB) {
		LK_GA1085_BUBRUL4_GB = lK_GA1085_BUBRUL4_GB;
	}
	public String getLK_GA1085_BUBRUL4_GAIP_GMEK() {
		return LK_GA1085_BUBRUL4_GAIP_GMEK;
	}
	public void setLK_GA1085_BUBRUL4_GAIP_GMEK(String lK_GA1085_BUBRUL4_GAIP_GMEK) {
		LK_GA1085_BUBRUL4_GAIP_GMEK = lK_GA1085_BUBRUL4_GAIP_GMEK;
	}
	public String getLK_GA1085_PIB_JUSO_SINGU_GB() {
		return LK_GA1085_PIB_JUSO_SINGU_GB;
	}
	public void setLK_GA1085_PIB_JUSO_SINGU_GB(String lK_GA1085_PIB_JUSO_SINGU_GB) {
		LK_GA1085_PIB_JUSO_SINGU_GB = lK_GA1085_PIB_JUSO_SINGU_GB;
	}
	public String getH_LK_GA1085_PIB_JIB_ZIP_NM() {
		return H_LK_GA1085_PIB_JIB_ZIP_NM;
	}
	public void setH_LK_GA1085_PIB_JIB_ZIP_NM(String h_LK_GA1085_PIB_JIB_ZIP_NM) {
		H_LK_GA1085_PIB_JIB_ZIP_NM = h_LK_GA1085_PIB_JIB_ZIP_NM;
	}
	public String getH_LK_GA1085_PIB_JIK_ZIP_NM() {
		return H_LK_GA1085_PIB_JIK_ZIP_NM;
	}
	public void setH_LK_GA1085_PIB_JIK_ZIP_NM(String h_LK_GA1085_PIB_JIK_ZIP_NM) {
		H_LK_GA1085_PIB_JIK_ZIP_NM = h_LK_GA1085_PIB_JIK_ZIP_NM;
	}
	public String getLK_GA1085_GYE_JUSO_SINGU_GB() {
		return LK_GA1085_GYE_JUSO_SINGU_GB;
	}
	public void setLK_GA1085_GYE_JUSO_SINGU_GB(String lK_GA1085_GYE_JUSO_SINGU_GB) {
		LK_GA1085_GYE_JUSO_SINGU_GB = lK_GA1085_GYE_JUSO_SINGU_GB;
	}
	public String getH_LK_GA1085_GYE_JIB_ZIP_NM() {
		return H_LK_GA1085_GYE_JIB_ZIP_NM;
	}
	public void setH_LK_GA1085_GYE_JIB_ZIP_NM(String h_LK_GA1085_GYE_JIB_ZIP_NM) {
		H_LK_GA1085_GYE_JIB_ZIP_NM = h_LK_GA1085_GYE_JIB_ZIP_NM;
	}
	public String getH_LK_GA1085_GYE_JIK_ZIP_NM() {
		return H_LK_GA1085_GYE_JIK_ZIP_NM;
	}
	public void setH_LK_GA1085_GYE_JIK_ZIP_NM(String h_LK_GA1085_GYE_JIK_ZIP_NM) {
		H_LK_GA1085_GYE_JIK_ZIP_NM = h_LK_GA1085_GYE_JIK_ZIP_NM;
	}
	public String getLK_GA1085_SUIKJA_JUSO_SINGU_GB() {
		return LK_GA1085_SUIKJA_JUSO_SINGU_GB;
	}
	public void setLK_GA1085_SUIKJA_JUSO_SINGU_GB(
			String lK_GA1085_SUIKJA_JUSO_SINGU_GB) {
		LK_GA1085_SUIKJA_JUSO_SINGU_GB = lK_GA1085_SUIKJA_JUSO_SINGU_GB;
	}
	public String getH_LK_GA1085_SUIKJA_ZIP_NM() {
		return H_LK_GA1085_SUIKJA_ZIP_NM;
	}
	public void setH_LK_GA1085_SUIKJA_ZIP_NM(String h_LK_GA1085_SUIKJA_ZIP_NM) {
		H_LK_GA1085_SUIKJA_ZIP_NM = h_LK_GA1085_SUIKJA_ZIP_NM;
	}
	public String getLK_GA1085_JACHA_JUNGRULJE_GB() {
		return LK_GA1085_JACHA_JUNGRULJE_GB;
	}
	public void setLK_GA1085_JACHA_JUNGRULJE_GB(String lK_GA1085_JACHA_JUNGRULJE_GB) {
		LK_GA1085_JACHA_JUNGRULJE_GB = lK_GA1085_JACHA_JUNGRULJE_GB;
	}
	public String getLK_GA1085_JACHA_GONGJE_RATE() {
		return LK_GA1085_JACHA_GONGJE_RATE;
	}
	public void setLK_GA1085_JACHA_GONGJE_RATE(String lK_GA1085_JACHA_GONGJE_RATE) {
		LK_GA1085_JACHA_GONGJE_RATE = lK_GA1085_JACHA_GONGJE_RATE;
	}
	public String getLK_GA1085_MIN_GONGJE_GMEK() {
		return LK_GA1085_MIN_GONGJE_GMEK;
	}
	public void setLK_GA1085_MIN_GONGJE_GMEK(String lK_GA1085_MIN_GONGJE_GMEK) {
		LK_GA1085_MIN_GONGJE_GMEK = lK_GA1085_MIN_GONGJE_GMEK;
	}
	public String getLK_GA1085_MAX_GONGJE_GMEK() {
		return LK_GA1085_MAX_GONGJE_GMEK;
	}
	public void setLK_GA1085_MAX_GONGJE_GMEK(String lK_GA1085_MAX_GONGJE_GMEK) {
		LK_GA1085_MAX_GONGJE_GMEK = lK_GA1085_MAX_GONGJE_GMEK;
	}
	public String getLK_GA1085_TACHA_JADONG_GB() {
		return LK_GA1085_TACHA_JADONG_GB;
	}
	public void setLK_GA1085_TACHA_JADONG_GB(String lK_GA1085_TACHA_JADONG_GB) {
		LK_GA1085_TACHA_JADONG_GB = lK_GA1085_TACHA_JADONG_GB;
	}
	public String getLK_GA1085_YN_909() {
		return LK_GA1085_YN_909;
	}
	public void setLK_GA1085_YN_909(String lK_GA1085_YN_909) {
		LK_GA1085_YN_909 = lK_GA1085_YN_909;
	}
	public String getLK_GA1085_ELECTRIC_GB() {
		return LK_GA1085_ELECTRIC_GB;
	}
	public void setLK_GA1085_ELECTRIC_GB(String lK_GA1085_ELECTRIC_GB) {
		LK_GA1085_ELECTRIC_GB = lK_GA1085_ELECTRIC_GB;
	}
	public String getLK_GA1085_CHULRYUKRYANG() {
		return LK_GA1085_CHULRYUKRYANG;
	}
	public void setLK_GA1085_CHULRYUKRYANG(String lK_GA1085_CHULRYUKRYANG) {
		LK_GA1085_CHULRYUKRYANG = lK_GA1085_CHULRYUKRYANG;
	}
	public static String getProid() {
		return proid;
	}
	public static String getTrid() {
		return trid;
	}
	public String getBJ_NM() {
		return BJ_NM;
	}
	public void setBJ_NM(String bJ_NM) {
		BJ_NM = bJ_NM;
	}
	public String getGYEYAK_SANGTE_NM() {
		return GYEYAK_SANGTE_NM;
	}
	public void setGYEYAK_SANGTE_NM(String gYEYAK_SANGTE_NM) {
		GYEYAK_SANGTE_NM = gYEYAK_SANGTE_NM;
	}
	public String getDAMDANG_NM() {
		return DAMDANG_NM;
	}
	public void setDAMDANG_NM(String dAMDANG_NM) {
		DAMDANG_NM = dAMDANG_NM;
	}
	public String getDAMDANG_TEL() {
		return DAMDANG_TEL;
	}
	public void setDAMDANG_TEL(String dAMDANG_TEL) {
		DAMDANG_TEL = dAMDANG_TEL;
	}
	public String getH_LK_GA1085_MOKJUK_NAME() {
		return H_LK_GA1085_MOKJUK_NAME;
	}
	public void setH_LK_GA1085_MOKJUK_NAME(String h_LK_GA1085_MOKJUK_NAME) {
		H_LK_GA1085_MOKJUK_NAME = h_LK_GA1085_MOKJUK_NAME;
	}
	public String getSO_BJ_GB() {
		return SO_BJ_GB;
	}
	public void setSO_BJ_GB(String sO_BJ_GB) {
		SO_BJ_GB = sO_BJ_GB;
	}
	public String getSO_POLI_NO() {
		return SO_POLI_NO;
	}
	public void setSO_POLI_NO(String sO_POLI_NO) {
		SO_POLI_NO = sO_POLI_NO;
	}
	public String getPIB_TEL_NO() {
		return PIB_TEL_NO;
	}
	public void setPIB_TEL_NO(String pIB_TEL_NO) {
		PIB_TEL_NO = pIB_TEL_NO;
	}
	public String getCS_NM() {
		return CS_NM;
	}
	public void setCS_NM(String cS_NM) {
		CS_NM = cS_NM;
	}
	public String getSTR_GMEK() {
		return STR_GMEK;
	}
	public void setSTR_GMEK(String sTR_GMEK) {
		STR_GMEK = sTR_GMEK;
	}
	public String getYUNRYUNG_AGE() {
		return YUNRYUNG_AGE;
	}
	public void setYUNRYUNG_AGE(String yUNRYUNG_AGE) {
		YUNRYUNG_AGE = yUNRYUNG_AGE;
	}
	public String getSTR_SOS_NM() {
		return STR_SOS_NM;
	}
	public void setSTR_SOS_NM(String sTR_SOS_NM) {
		STR_SOS_NM = sTR_SOS_NM;
	}
	public String getLK_GA1085_MULSAGO_GIJUN_GMEK() {
		return LK_GA1085_MULSAGO_GIJUN_GMEK;
	}
	public void setLK_GA1085_MULSAGO_GIJUN_GMEK(String lK_GA1085_MULSAGO_GIJUN_GMEK) {
		LK_GA1085_MULSAGO_GIJUN_GMEK = lK_GA1085_MULSAGO_GIJUN_GMEK;
	}
	public String getMUBO_BJ_NM() {
		return MUBO_BJ_NM;
	}
	public void setMUBO_BJ_NM(String mUBO_BJ_NM) {
		MUBO_BJ_NM = mUBO_BJ_NM;
	}
	public List<SubFQA1085RVO> getLK_GA1085_TUKYAK_AREA() {
		return LK_GA1085_TUKYAK_AREA;
	}
	public void setLK_GA1085_TUKYAK_AREA(List<SubFQA1085RVO> lK_GA1085_TUKYAK_AREA) {
		LK_GA1085_TUKYAK_AREA = lK_GA1085_TUKYAK_AREA;
	}
	public String getLK_GA1085_FOREIGN_YN() {
		return LK_GA1085_FOREIGN_YN;
	}
	public void setLK_GA1085_FOREIGN_YN(String lK_GA1085_FOREIGN_YN) {
		LK_GA1085_FOREIGN_YN = lK_GA1085_FOREIGN_YN;
	}
	public String getLK_GA1085_FOREIGN_GAIP_GMEK() {
		return LK_GA1085_FOREIGN_GAIP_GMEK;
	}
	public void setLK_GA1085_FOREIGN_GAIP_GMEK(String lK_GA1085_FOREIGN_GAIP_GMEK) {
		LK_GA1085_FOREIGN_GAIP_GMEK = lK_GA1085_FOREIGN_GAIP_GMEK;
	}
	public String getSTR_FOREIGN_GMEK() {
		return STR_FOREIGN_GMEK;
	}
	public void setSTR_FOREIGN_GMEK(String sTR_FOREIGN_GMEK) {
		STR_FOREIGN_GMEK = sTR_FOREIGN_GMEK;
	}

	/**
	 * @return the sbt_drvr_cust_dcmt_no
	 */
	public String getSbt_drvr_cust_dcmt_no() {
		return sbt_drvr_cust_dcmt_no;
	}
	/**
	 * @param sbt_drvr_cust_dcmt_no the sbt_drvr_cust_dcmt_no to set
	 */
	public void setSbt_drvr_cust_dcmt_no(String sbt_drvr_cust_dcmt_no) {
		this.sbt_drvr_cust_dcmt_no = sbt_drvr_cust_dcmt_no;
	}

	/**
	 * @return the funt_key
	 */
	public String getFunt_key() {
		return funt_key;
	}
	/**
	 * @param funt_key the funt_key to set
	 */
	public void setFunt_key(String funt_key) {
		this.funt_key = funt_key;
	}

	/**
	 * @return the sbt_drve_trdr_plhd_csn_yn
	 */
	public String getSbt_drve_trdr_plhd_csn_yn() {
		return sbt_drve_trdr_plhd_csn_yn;
	}
	/**
	 * @param sbt_drve_trdr_plhd_csn_yn the sbt_drve_trdr_plhd_csn_yn to set
	 */
	public void setSbt_drve_trdr_plhd_csn_yn(String sbt_drve_trdr_plhd_csn_yn) {
		this.sbt_drve_trdr_plhd_csn_yn = sbt_drve_trdr_plhd_csn_yn;
	}
	/**
	 * @return the sbt_drvr_apcn_prm
	 */
	public String getSbt_drvr_apcn_prm() {
		return sbt_drvr_apcn_prm;
	}
	/**
	 * @param sbt_drvr_apcn_prm the sbt_drvr_apcn_prm to set
	 */
	public void setSbt_drvr_apcn_prm(String sbt_drvr_apcn_prm) {
		this.sbt_drvr_apcn_prm = sbt_drvr_apcn_prm;
	}
	/**
	 * @return the accd_mtt
	 */
	public String getAccd_mtt() {
		return accd_mtt;
	}
	/**
	 * @param accd_mtt the accd_mtt to set
	 */
	public void setAccd_mtt(String accd_mtt) {
		this.accd_mtt = accd_mtt;
	}
	/**
	 * @return the ctrmf_nts
	 */
	public String getCtrmf_nts() {
		return ctrmf_nts;
	}
	/**
	 * @param ctrmf_nts the ctrmf_nts to set
	 */
	public void setCtrmf_nts(String ctrmf_nts) {
		this.ctrmf_nts = ctrmf_nts;
	}

}
