package com.idongbu.smartcustomer.vo;

/**
 * @info 공인인증 전자서명에 사용하는 vo
 * @author F1F13H26
 *
 */
public class CertVO {
	
	private String signData;
	private String vidData;
	private String realName;
	private int resultCode;
	private String resultMsg;
	
	private String certInfo;
	private String expSdate;
	private String expEdate;
	private String fd_mb_jumin;
	private String ipin_ci;
	private String ipin_di;
	private String fd_mb_id;
	
	public String getSignData() {
		return signData;
	}
	public void setSignData(String signData) {
		this.signData = signData;
	}
	public String getVidData() {
		return vidData;
	}
	public void setVidData(String vidData) {
		this.vidData = vidData;
	}
	public String getRealName() {
		return realName;
	}
	public void setRealName(String realName) {
		this.realName = realName;
	}
	public int getResultCode() {
		return resultCode;
	}
	public void setResultCode(int resultCode) {
		this.resultCode = resultCode;
	}
	public String getResultMsg() {
		return resultMsg;
	}
	public void setResultMsg(String resultMsg) {
		this.resultMsg = resultMsg;
	}

	/**
	 * @return the certInfo
	 */
	public String getCertInfo() {
		return certInfo;
	}
	/**
	 * @param certInfo the certInfo to set
	 */
	public void setCertInfo(String certInfo) {
		this.certInfo = certInfo;
	}
	/**
	 * @return the expSdata
	 */
	public String getExpSdate() {
		return expSdate;
	}
	/**
	 * @param expSdata the expSdata to set
	 */
	public void setExpSdate(String expSdate) {
		this.expSdate = expSdate;
	}
	/**
	 * @return the expEdata
	 */
	public String getExpEdate() {
		return expEdate;
	}
	/**
	 * @param expEdata the expEdata to set
	 */
	public void setExpEdate(String expEdate) {
		this.expEdate = expEdate;
	}

	/**
	 * @return the fd_mb_jumin
	 */
	public String getFd_mb_jumin() {
		return fd_mb_jumin;
	}
	/**
	 * @param fd_mb_jumin the fd_mb_jumin to set
	 */
	public void setFd_mb_jumin(String fd_mb_jumin) {
		this.fd_mb_jumin = fd_mb_jumin;
	}

	/**
	 * @return the ipin_ci
	 */
	public String getIpin_ci() {
		return ipin_ci;
	}
	/**
	 * @param ipin_ci the ipin_ci to set
	 */
	public void setIpin_ci(String ipin_ci) {
		this.ipin_ci = ipin_ci;
	}
	/**
	 * @return the ipin_di
	 */
	public String getIpin_di() {
		return ipin_di;
	}
	/**
	 * @param ipin_di the ipin_di to set
	 */
	public void setIpin_di(String ipin_di) {
		this.ipin_di = ipin_di;
	}
	/**
	 * @return the fd_mb_id
	 */
	public String getFd_mb_id() {
		return fd_mb_id;
	}
	/**
	 * @param fd_mb_id the fd_mb_id to set
	 */
	public void setFd_mb_id(String fd_mb_id) {
		this.fd_mb_id = fd_mb_id;
	}
	
	@Override
	public String toString() {
		return "CertVO [signData=" + signData + ", vidData=" + vidData
				+ ", resultCode=" + resultCode + ", resultMsg=" + resultMsg
				+ ", certInfo=" + certInfo + ", expSdate=" + expSdate + ", expEdate=" + expEdate
				+ ", fd_mb_jumin=" + fd_mb_jumin + ", ipin_ci=" + ipin_ci + ", ipin_di=" + ipin_di + ", fd_mb_id=" + fd_mb_id
				+ "]";
	}
}
