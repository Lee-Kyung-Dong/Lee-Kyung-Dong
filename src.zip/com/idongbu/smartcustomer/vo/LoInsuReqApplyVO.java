package com.idongbu.smartcustomer.vo;

public class LoInsuReqApplyVO {
	
	private String 	ssnUserJumin			= "";		//2차에서는 CmmVO에서 상속받은 필드
	private String 	ssnUserName			= "";		//2차에서는 CmmVO에서 상속받은 필드	고객명	
	
	private String name                    = ""; //성명
	private String inhab_no                = ""; //주민번호
	private String cust_name               = ""; //고객명
	private String stock_seq               = ""; //증권번호
	private String stock_seq_masking	= ""; //증권번호 마스킹
	private String pd_cd                   = ""; //상품코드
	private String pd_name                 = ""; //상품명
	private String expec_loan_resid_amt    = ""; //기대출잔금액
	private String npay_day_int_amt        = ""; //미납입이자금액
	private long   prncint_sum             =  0; //원리금합계
	private String last_int_pay_day        = ""; //최종이자납입일자
	private String int_rate                = ""; //이율
	private String pamet_acc_no            = ""; //출금계좌번호
	private String dposr_inhab_no          = ""; //예금주 주민번호
	private String dposr_name              = ""; //예금주명
	private String dposr_reltn_name        = ""; //예금주관계명
	private String bank_cd                 = ""; //은행코드
	private String bank_name               = ""; //은행명
	private String apply_reslt_cd          = ""; //신청결과코드
	private String inq_nhab_no             = ""; //INQ-주민번호
	private String inq_stck_no             = ""; //INQ-증권번호
	private String first_key_inhno         = ""; //FIRST KEY-주민번호
	private String first_key_istck_no      = ""; //FIRST KEY-증권번호
	private String last_key_inhno          = ""; //LAST KEY-주민번호
	private String last_key_istck_no       = ""; //LAST KEY-증권번호
	private String ins_lcpl_dvcd       = ""; //dvcd
	private String ply_sqno       = ""; //sqno
	
	//2015.06.09 상환프로세스 제어 추가 박형규
	private String ctc_stat_cd			   = ""; //계약상태코드
	private String arc_trm_str_dt		   = ""; //보험기간시작일자
	private String silhoy_control		   = ""; //실효건제어
	
	private boolean holyday       = false; //휴일 체크


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getInhab_no() {
		return inhab_no;
	}


	public void setInhab_no(String inhab_no) {
		this.inhab_no = inhab_no;
	}


	public String getCust_name() {
		return cust_name;
	}


	public void setCust_name(String cust_name) {
		this.cust_name = cust_name;
	}


	public String getStock_seq() {
		return stock_seq;
	}


	public void setStock_seq(String stock_seq) {
		this.stock_seq = stock_seq;
	}


	public String getPd_cd() {
		return pd_cd;
	}


	public void setPd_cd(String pd_cd) {
		this.pd_cd = pd_cd;
	}


	public String getPd_name() {
		return pd_name;
	}


	public void setPd_name(String pd_name) {
		this.pd_name = pd_name;
	}


	public String getExpec_loan_resid_amt() {
		return expec_loan_resid_amt;
	}


	public void setExpec_loan_resid_amt(String expec_loan_resid_amt) {
		this.expec_loan_resid_amt = expec_loan_resid_amt;
	}


	public String getNpay_day_int_amt() {
		return npay_day_int_amt;
	}


	public void setNpay_day_int_amt(String npay_day_int_amt) {
		this.npay_day_int_amt = npay_day_int_amt;
	}


	public long getPrncint_sum() {
		return prncint_sum;
	}


	public void setPrncint_sum(long prncint_sum) {
		this.prncint_sum = prncint_sum;
	}


	public String getLast_int_pay_day() {
		return last_int_pay_day;
	}


	public void setLast_int_pay_day(String last_int_pay_day) {
		this.last_int_pay_day = last_int_pay_day;
	}


	public String getInt_rate() {
		return int_rate;
	}


	public void setInt_rate(String int_rate) {
		this.int_rate = int_rate;
	}


	public String getPamet_acc_no() {
		return pamet_acc_no;
	}


	public void setPamet_acc_no(String pamet_acc_no) {
		this.pamet_acc_no = pamet_acc_no;
	}


	public String getDposr_inhab_no() {
		return dposr_inhab_no;
	}


	public void setDposr_inhab_no(String dposr_inhab_no) {
		this.dposr_inhab_no = dposr_inhab_no;
	}


	public String getDposr_name() {
		return dposr_name;
	}


	public void setDposr_name(String dposr_name) {
		this.dposr_name = dposr_name;
	}


	public String getDposr_reltn_name() {
		return dposr_reltn_name;
	}


	public void setDposr_reltn_name(String dposr_reltn_name) {
		this.dposr_reltn_name = dposr_reltn_name;
	}


	public String getBank_cd() {
		return bank_cd;
	}


	public void setBank_cd(String bank_cd) {
		this.bank_cd = bank_cd;
	}


	public String getBank_name() {
		return bank_name;
	}


	public void setBank_name(String bank_name) {
		this.bank_name = bank_name;
	}


	public String getApply_reslt_cd() {
		return apply_reslt_cd;
	}


	public void setApply_reslt_cd(String apply_reslt_cd) {
		this.apply_reslt_cd = apply_reslt_cd;
	}


	public String getInq_nhab_no() {
		return inq_nhab_no;
	}


	public void setInq_nhab_no(String inq_nhab_no) {
		this.inq_nhab_no = inq_nhab_no;
	}


	public String getInq_stck_no() {
		return inq_stck_no;
	}


	public void setInq_stck_no(String inq_stck_no) {
		this.inq_stck_no = inq_stck_no;
	}


	public String getFirst_key_inhno() {
		return first_key_inhno;
	}


	public void setFirst_key_inhno(String first_key_inhno) {
		this.first_key_inhno = first_key_inhno;
	}


	public String getFirst_key_istck_no() {
		return first_key_istck_no;
	}


	public void setFirst_key_istck_no(String first_key_istck_no) {
		this.first_key_istck_no = first_key_istck_no;
	}


	public String getLast_key_inhno() {
		return last_key_inhno;
	}


	public void setLast_key_inhno(String last_key_inhno) {
		this.last_key_inhno = last_key_inhno;
	}


	public String getLast_key_istck_no() {
		return last_key_istck_no;
	}


	public void setLast_key_istck_no(String last_key_istck_no) {
		this.last_key_istck_no = last_key_istck_no;
	}


	public boolean isHolyday() {
		return holyday;
	}


	public void setHolyday(boolean holyday) {
		this.holyday = holyday;
	}


	public String getSsnUserJumin() {
		return ssnUserJumin;
	}


	public void setSsnUserJumin(String ssnUserJumin) {
		this.ssnUserJumin = ssnUserJumin;
	}


	public String getSsnUserName() {
		return ssnUserName;
	}


	public void setSsnUserName(String ssnUserName) {
		this.ssnUserName = ssnUserName;
	}


	public String getStock_seq_masking() {
		return stock_seq_masking;
	}


	public void setStock_seq_masking(String stock_seq_masking) {
		this.stock_seq_masking = stock_seq_masking;
	}


	public String getIns_lcpl_dvcd() {
		return ins_lcpl_dvcd;
	}


	public void setIns_lcpl_dvcd(String ins_lcpl_dvcd) {
		this.ins_lcpl_dvcd = ins_lcpl_dvcd;
	}


	public String getPly_sqno() {
		return ply_sqno;
	}


	public void setPly_sqno(String ply_sqno) {
		this.ply_sqno = ply_sqno;
	}	
	public String getCtc_stat_cd() {
		return ctc_stat_cd;
	}
	public void setCtc_stat_cd(String ctc_stat_cd) {
		this.ctc_stat_cd = ctc_stat_cd;
	}
	public String getArc_trm_str_dt() {
		return arc_trm_str_dt;
	}
	public void setArc_trm_str_dt(String arc_trm_str_dt) {
		this.arc_trm_str_dt = arc_trm_str_dt;
	}
	public String getSilhoy_control() {
		return silhoy_control;
	}
	public void setSilhoy_control(String silhoy_control) {
		this.silhoy_control = silhoy_control;
	}
	
}
