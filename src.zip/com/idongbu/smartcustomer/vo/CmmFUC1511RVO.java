package com.idongbu.smartcustomer.vo;

import java.util.List;
import java.util.Map;

import com.idongbu.common.vo.CMMVO;

public class CmmFUC1511RVO extends CMMVO {
	
	public CmmFUC1511RVO() {
		super.setPGMID(this.proid);
		super.setTRID(this.trid);
	}		
	
	private static final String proid = "FUC1511R";
	private static final String trid  = "UCAB";
	private String rURL				  = "";

	// 입력
	private String JJ_YEGMJU_JUMINNO  = ""; // 예금주 주민번호
	private String UU_YEGMJU_JUMINNO  = "";

	// 출력
	private String CC_CHANNEL         = "";
	private String CC_UKEY            = "";
	private String CC_PGMID           = "";
	private String CC_PROC_GB         = "";
	private String CC_FUN_KEY         = "";
	private String CC_USER_GB         = "";
	private String CC_USER_CD         = "";
	private String CC_JIJUM_CD        = "";
	private String CC_JIBU_CD         = "";
	private String CC_PROTOCOL        = "";
	private String CC_COND_CD         = "";
	private String CC_LAST_FLAG       = "";
	private String CC_CURSOR_MAP      = "";
	private String CC_CURSOR_IDX      = "";
	private String CC_MESSAGE_CD      = "";
	private String HC_MESSAGE_NM      = "";
	private String CC_SYS_ERR         = "";
	private String CC_FILLER          = "";
	private String JJ_BJ_CD           = "";
	
//	private String[] JJ_GYEYAK_JMNO   = new String[0]; // 10
//	private String[] HJ_GYEYAK_NM     = new String[0]; // 10
//	private String[] JJ_PIBO_JMNO     = new String[0]; // 10
//	private String[] HJ_PIBO_NM       = new String[0]; // 10
//	private String[] HJ_BJ_NM         = new String[0]; // 10
//	private String[] JJ_POLI_NO       = new String[0]; // 10
//	private String[] JJ_BOHUM_GIGAN_S = new String[0]; // 10
//	private String[] JJ_BOHUM_GIGAN_E = new String[0]; // 10
//	private String[] JJ_GYEYAK_SANGTE = new String[0]; // 10
//	private String[] HJ_BIGO          = new String[0]; // 10
//	private String[] HJ_CHIGUB_NM     = new String[0]; // 10
//	private String[] JJ_CHIGUB_TEL    = new String[0]; // 10
//	private String[] JJ_CHIGUB        = new String[0]; // 10
//	private String[] JJ_GAIP_TYPE1    = new String[0]; // 10
//	private String[] JJ_BOHUM_GIGANCD = new String[0]; // 10	
//	//방희문
//	private String[] JJ_NAPIP_CNT     = new String[0];
//	private String[] HJ_BUNNAP_NM     = new String[0];
//	private String[] JJ_LAST_NAPIP_YM = new String[0];
//	private String[] JJ_BUNNAP_BANGCD = new String[0];
//	private String[] JJ_ICHE_ILSU     = new String[0];
//	private String[] JJ_SU_BANGBAP    = new String[0];
//	private String[] HJ_SU_BANGBAP    = new String[0];	
	private List<Map<String, String>> LOOP_DATA = null;	
	private String UU_INQ_BJ          = "";
	private String UU_INQ_POLI_NO     = "";
	private String UU_F_BJ            = "";
	private String UU_F_POLI_NO       = "";
	private String UU_L_BJ            = "";
	private String UU_L_POLI_NO       = "";
	private String FILLER             = "";
	private List<SubFUC1511RVO> LIST_DATA = null;
	private List<CyConVO>	CHILD_LSIT	  = null;
	
	public String getrURL() {
		return rURL;
	}
	public void setrURL(String rURL) {
		this.rURL = rURL;
	}
	public String getJJ_YEGMJU_JUMINNO() {
		return JJ_YEGMJU_JUMINNO;
	}
	public void setJJ_YEGMJU_JUMINNO(String jJ_YEGMJU_JUMINNO) {
		JJ_YEGMJU_JUMINNO = jJ_YEGMJU_JUMINNO;
	}
	public String getUU_YEGMJU_JUMINNO() {
		return UU_YEGMJU_JUMINNO;
	}
	public void setUU_YEGMJU_JUMINNO(String uU_YEGMJU_JUMINNO) {
		UU_YEGMJU_JUMINNO = uU_YEGMJU_JUMINNO;
	}
	public String getCC_CHANNEL() {
		return CC_CHANNEL;
	}
	public void setCC_CHANNEL(String cC_CHANNEL) {
		CC_CHANNEL = cC_CHANNEL;
	}
	public String getCC_UKEY() {
		return CC_UKEY;
	}
	public void setCC_UKEY(String cC_UKEY) {
		CC_UKEY = cC_UKEY;
	}
	public String getCC_PGMID() {
		return CC_PGMID;
	}
	public void setCC_PGMID(String cC_PGMID) {
		CC_PGMID = cC_PGMID;
	}
	public String getCC_PROC_GB() {
		return CC_PROC_GB;
	}
	public void setCC_PROC_GB(String cC_PROC_GB) {
		CC_PROC_GB = cC_PROC_GB;
	}
	public String getCC_FUN_KEY() {
		return CC_FUN_KEY;
	}
	public void setCC_FUN_KEY(String cC_FUN_KEY) {
		CC_FUN_KEY = cC_FUN_KEY;
	}
	public String getCC_USER_GB() {
		return CC_USER_GB;
	}
	public void setCC_USER_GB(String cC_USER_GB) {
		CC_USER_GB = cC_USER_GB;
	}
	public String getCC_USER_CD() {
		return CC_USER_CD;
	}
	public void setCC_USER_CD(String cC_USER_CD) {
		CC_USER_CD = cC_USER_CD;
	}
	public String getCC_JIJUM_CD() {
		return CC_JIJUM_CD;
	}
	public void setCC_JIJUM_CD(String cC_JIJUM_CD) {
		CC_JIJUM_CD = cC_JIJUM_CD;
	}
	public String getCC_JIBU_CD() {
		return CC_JIBU_CD;
	}
	public void setCC_JIBU_CD(String cC_JIBU_CD) {
		CC_JIBU_CD = cC_JIBU_CD;
	}
	public String getCC_PROTOCOL() {
		return CC_PROTOCOL;
	}
	public void setCC_PROTOCOL(String cC_PROTOCOL) {
		CC_PROTOCOL = cC_PROTOCOL;
	}
	public String getCC_COND_CD() {
		return CC_COND_CD;
	}
	public void setCC_COND_CD(String cC_COND_CD) {
		CC_COND_CD = cC_COND_CD;
	}
	public String getCC_LAST_FLAG() {
		return CC_LAST_FLAG;
	}
	public void setCC_LAST_FLAG(String cC_LAST_FLAG) {
		CC_LAST_FLAG = cC_LAST_FLAG;
	}
	public String getCC_CURSOR_MAP() {
		return CC_CURSOR_MAP;
	}
	public void setCC_CURSOR_MAP(String cC_CURSOR_MAP) {
		CC_CURSOR_MAP = cC_CURSOR_MAP;
	}
	public String getCC_CURSOR_IDX() {
		return CC_CURSOR_IDX;
	}
	public void setCC_CURSOR_IDX(String cC_CURSOR_IDX) {
		CC_CURSOR_IDX = cC_CURSOR_IDX;
	}
	public String getCC_MESSAGE_CD() {
		return CC_MESSAGE_CD;
	}
	public void setCC_MESSAGE_CD(String cC_MESSAGE_CD) {
		CC_MESSAGE_CD = cC_MESSAGE_CD;
	}
	public String getHC_MESSAGE_NM() {
		return HC_MESSAGE_NM;
	}
	public void setHC_MESSAGE_NM(String hC_MESSAGE_NM) {
		HC_MESSAGE_NM = hC_MESSAGE_NM;
	}
	public String getCC_SYS_ERR() {
		return CC_SYS_ERR;
	}
	public void setCC_SYS_ERR(String cC_SYS_ERR) {
		CC_SYS_ERR = cC_SYS_ERR;
	}
	public String getCC_FILLER() {
		return CC_FILLER;
	}
	public void setCC_FILLER(String cC_FILLER) {
		CC_FILLER = cC_FILLER;
	}
	public String getJJ_BJ_CD() {
		return JJ_BJ_CD;
	}
	public void setJJ_BJ_CD(String jJ_BJ_CD) {
		JJ_BJ_CD = jJ_BJ_CD;
	}	
	public List<Map<String, String>> getLOOP_DATA() {
		return LOOP_DATA;
	}
	public void setLOOP_DATA(List<Map<String, String>> lOOP_DATA) {
		LOOP_DATA = lOOP_DATA;
	}
	public String getUU_INQ_BJ() {
		return UU_INQ_BJ;
	}
	public void setUU_INQ_BJ(String uU_INQ_BJ) {
		UU_INQ_BJ = uU_INQ_BJ;
	}
	public String getUU_INQ_POLI_NO() {
		return UU_INQ_POLI_NO;
	}
	public void setUU_INQ_POLI_NO(String uU_INQ_POLI_NO) {
		UU_INQ_POLI_NO = uU_INQ_POLI_NO;
	}
	public String getUU_F_BJ() {
		return UU_F_BJ;
	}
	public void setUU_F_BJ(String uU_F_BJ) {
		UU_F_BJ = uU_F_BJ;
	}
	public String getUU_F_POLI_NO() {
		return UU_F_POLI_NO;
	}
	public void setUU_F_POLI_NO(String uU_F_POLI_NO) {
		UU_F_POLI_NO = uU_F_POLI_NO;
	}
	public String getUU_L_BJ() {
		return UU_L_BJ;
	}
	public void setUU_L_BJ(String uU_L_BJ) {
		UU_L_BJ = uU_L_BJ;
	}
	public String getUU_L_POLI_NO() {
		return UU_L_POLI_NO;
	}
	public void setUU_L_POLI_NO(String uU_L_POLI_NO) {
		UU_L_POLI_NO = uU_L_POLI_NO;
	}
	public String getFILLER() {
		return FILLER;
	}
	public void setFILLER(String fILLER) {
		FILLER = fILLER;
	}
	public static String getProid() {
		return proid;
	}
	public static String getTrid() {
		return trid;
	}
	public List<SubFUC1511RVO> getLIST_DATA() {
		return LIST_DATA;
	}
	public void setLIST_DATA(List<SubFUC1511RVO> lIST_DATA) {
		LIST_DATA = lIST_DATA;
	}
	public List<CyConVO> getCHILD_LSIT() {
		return CHILD_LSIT;
	}
	public void setCHILD_LSIT(List<CyConVO> cHILD_LSIT) {
		CHILD_LSIT = cHILD_LSIT;
	}
}
