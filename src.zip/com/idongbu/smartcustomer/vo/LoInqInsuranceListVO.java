package com.idongbu.smartcustomer.vo;

/************************************************************************************************
기능명 : 보험계약대출 현황조회 목록
설  명 :

수정일		수정자		내 용
----------	--------	-------
2007.11.06  김태화		최초 작성
************************************************************************************************/


public class LoInqInsuranceListVO  {
	
	private String   ssnUserName = "";								//고객명(2차에서는 cmmvo에서 상속)
	private String   ssnUserJumin = "";								//주민번호(2차에서는 cmmvo에서 상속)
	
	private String   INSUB_PD_NAME               = "";				 //보험상품명
	private String   STOCK_SEQ                   = "";					 //증권번호
	private String   STOCK_SEQ_MASKING      = "";			 //증권번호 마스킹
	private String   AR_STTUS_NAME               = ""; 			//계약상태명
	private long     RE_STPLT_LOAN_RESID_AMT     = 0;	 //기약관대출잔액
	private String   INT_PAY_DATE			    = ""; 				//이자납입일자시간
	private String   INT_RATE				    = ""; 						//이율
	private String   INET_LOAN_POSBL_YN		    = ""; 		//인터넷대출가능여부
	private long     STPLT_LOAN_POSBL_AMT	    = 0; 		//약관대출가능금액
	private String   JJ_ICHE_D	    			= ""; 						//jj_iche_d
	private String   JJ_NAPIP_IJA	    			= ""; 				//납입이자
	private String   INS_LCPL_DVCD	    			= ""; 						//컨버전스 sqno
	private String   PLY_SQNO	    			= ""; 				//컨버전스 sqno
	
	public String getINSUB_PD_NAME() {
		return INSUB_PD_NAME;
	}
	public void setINSUB_PD_NAME(String iNSUB_PD_NAME) {
		INSUB_PD_NAME = iNSUB_PD_NAME;
	}
	public String getSTOCK_SEQ() {
		return STOCK_SEQ;
	}
	public void setSTOCK_SEQ(String sTOCK_SEQ) {
		STOCK_SEQ = sTOCK_SEQ;
	}
	public String getAR_STTUS_NAME() {
		return AR_STTUS_NAME;
	}
	public void setAR_STTUS_NAME(String aR_STTUS_NAME) {
		AR_STTUS_NAME = aR_STTUS_NAME;
	}
	public long getRE_STPLT_LOAN_RESID_AMT() {
		return RE_STPLT_LOAN_RESID_AMT;
	}
	public void setRE_STPLT_LOAN_RESID_AMT(long rE_STPLT_LOAN_RESID_AMT) {
		RE_STPLT_LOAN_RESID_AMT = rE_STPLT_LOAN_RESID_AMT;
	}
	public String getINT_PAY_DATE() {
		return INT_PAY_DATE;
	}
	public void setINT_PAY_DATE(String iNT_PAY_DATE) {
		INT_PAY_DATE = iNT_PAY_DATE;
	}
	public String getINT_RATE() {
		return INT_RATE;
	}
	public void setINT_RATE(String iNT_RATE) {
		INT_RATE = iNT_RATE;
	}
	public String getINET_LOAN_POSBL_YN() {
		return INET_LOAN_POSBL_YN;
	}
	public void setINET_LOAN_POSBL_YN(String iNET_LOAN_POSBL_YN) {
		INET_LOAN_POSBL_YN = iNET_LOAN_POSBL_YN;
	}
	public long getSTPLT_LOAN_POSBL_AMT() {
		return STPLT_LOAN_POSBL_AMT;
	}
	public void setSTPLT_LOAN_POSBL_AMT(long sTPLT_LOAN_POSBL_AMT) {
		STPLT_LOAN_POSBL_AMT = sTPLT_LOAN_POSBL_AMT;
	}
	public String getJJ_ICHE_D() {
		return JJ_ICHE_D;
	}
	public void setJJ_ICHE_D(String jJ_ICHE_D) {
		JJ_ICHE_D = jJ_ICHE_D;
	}
	public String getJJ_NAPIP_IJA() {
		return JJ_NAPIP_IJA;
	}
	public void setJJ_NAPIP_IJA(String jJ_NAPIP_IJA) {
		JJ_NAPIP_IJA = jJ_NAPIP_IJA;
	}
	public String getSsnUserName() {
		return ssnUserName;
	}
	public void setSsnUserName(String ssnUserName) {
		this.ssnUserName = ssnUserName;
	}
	public String getSsnUserJumin() {
		return ssnUserJumin;
	}
	public void setSsnUserJumin(String ssnUserJumin) {
		this.ssnUserJumin = ssnUserJumin;
	}
	public String getINS_LCPL_DVCD() {
		return INS_LCPL_DVCD;
	}
	public void setINS_LCPL_DVCD(String iNS_LCPL_DVCD) {
		INS_LCPL_DVCD = iNS_LCPL_DVCD;
	}
	public String getPLY_SQNO() {
		return PLY_SQNO;
	}
	public void setPLY_SQNO(String pLY_SQNO) {
		PLY_SQNO = pLY_SQNO;
	}
	@Override
	public String toString() {
		return "LoInqInsuranceListVO [ssnUserName=" + ssnUserName
				+ ", ssnUserJumin=" + ssnUserJumin + ", INSUB_PD_NAME="
				+ INSUB_PD_NAME + ", STOCK_SEQ=" + STOCK_SEQ
				+ ", AR_STTUS_NAME=" + AR_STTUS_NAME
				+ ", RE_STPLT_LOAN_RESID_AMT=" + RE_STPLT_LOAN_RESID_AMT
				+ ", INT_PAY_DATE=" + INT_PAY_DATE + ", INT_RATE=" + INT_RATE
				+ ", INET_LOAN_POSBL_YN=" + INET_LOAN_POSBL_YN
				+ ", STPLT_LOAN_POSBL_AMT=" + STPLT_LOAN_POSBL_AMT
				+ ", JJ_ICHE_D=" + JJ_ICHE_D + ", JJ_NAPIP_IJA=" + JJ_NAPIP_IJA
				+ ", INS_LCPL_DVCD=" + INS_LCPL_DVCD + ", PLY_SQNO=" + PLY_SQNO
				+ "]";
	}
	public String getSTOCK_SEQ_MASKING() {
		return STOCK_SEQ_MASKING;
	}
	public void setSTOCK_SEQ_MASKING(String sTOCK_SEQ_MASKING) {
		STOCK_SEQ_MASKING = sTOCK_SEQ_MASKING;
	}
	
	
}