package com.idongbu.smartcustomer.vo;

import java.util.List;
import java.util.Map;

import com.idongbu.common.vo.CMMVO;

// 연말정산용 납입증명서 발급
public class CmmFBM0044RVO extends CMMVO {
	
	public CmmFBM0044RVO() {
		super.setPGMID(this.proid);
		super.setTRID(this.trid);
	}	
	
	public static final String proid		= "FBM0044R";
	public static final String trid		= "BM44";
	public String rURL						= "";

	// 입력
	public String LK_BM0044_NET_RC = null;
	public String LK_BM0044_UPMU_GB = null;
	public String LK_BM0044_UPMU_SEBU_GB = null;
	public String LK_BM0044_CONTINUE_GB = null;
	public String LK_BM0044_KEY_GOGEK_NO = null; // 고객번호
	public String LK_BM0044_KEY_GIJUN_YY = null; // 연말정산 출력년도
	public String LK_BM0044_KEY_JABO_GB = null;
	public String LK_BM0044_KEY_POLI_NO1 = null;
	public String LK_BM0044_KEY_JANG_GB = null;
	public String LK_BM0044_KEY_POLI_NO2 = null;
	public String LK_BM0044_KEY_ILBAN_GB = null;
	public String LK_BM0044_KEY_POLI_NO3 = null;

	// 출력
	public String H_LK_BM0044_GOGEK_GITA = null;
	public String H_LK_BM0044_GOGEK_NAME = null;
	public String H_LK_BM0044_GOGEK_ZIP_NAME = null;
	public String[] H_LK_BM0044_ILBA_BJ_NM = new String[0]; // 8
	public String[] H_LK_BM0044_ILBA_CAR_NO = new String[0]; // 8
	public String[] H_LK_BM0044_ILBA_GWANGYE = new String[0]; // 8
	public String[] H_LK_BM0044_ILBA_NAPBANG_NM = new String[0]; // 8
	public String[] H_LK_BM0044_ILBA_PIBO_NM = new String[0]; // 8
	public String[] H_LK_BM0044_JABO_BJ_NM = new String[0]; // 8
	public String[] H_LK_BM0044_JABO_CAR_NO = new String[0]; // 8
	public String[] H_LK_BM0044_JABO_GWANGYE = new String[0]; // 8
	public String[] H_LK_BM0044_JABO_NAPBANG_NM = new String[0]; // 8
	public String[] H_LK_BM0044_JABO_PIBO_NM = new String[0]; // 8
	public String[] H_LK_BM0044_JANG_BJ_NM = new String[0]; // 8
	public String[] H_LK_BM0044_JANG_CAR_NO = new String[0]; // 8
	public String[] H_LK_BM0044_JANG_GWANGYE = new String[0]; // 8
	public String[] H_LK_BM0044_JANG_NAPBANG_NM = new String[0]; // 8
	public String[] H_LK_BM0044_JANG_PIBO_NM = new String[0]; // 8
	public String H_LK_BM0044_MESSAGE1 = null;
	public String H_LK_BM0044_MESSAGE2 = null;
	//public String LK_BM0044_CONTINUE_GB = null;
	public String LK_BM0044_FLAG = null;
	public String LK_BM0044_GOGEK_JUMIN_NO = null;
	public String LK_BM0044_GOGEK_ZIP = null;
	public String[] LK_BM0044_ILBA_BJ_CD = new String[0]; // 8
	public String[] LK_BM0044_ILBA_GONG_PRM = new String[0]; // 8
	public String[] LK_BM0044_ILBA_LAST_YM = new String[0]; // 8
	public String[] LK_BM0044_ILBA_NAPBANG = new String[0]; // 8
	public String[] LK_BM0044_ILBA_NAPIP_CNT = new String[0]; // 8
	public String[] LK_BM0044_ILBA_POLI_NO = new String[0]; // 8
	public String[] LK_BM0044_ILBA_REC = new String[0]; // 8
	public String[] LK_BM0044_JABO_BJ_CD = new String[0]; // 8
	public String[] LK_BM0044_JABO_GONG_PRM = new String[0]; // 8
	public String[] LK_BM0044_JABO_JANG_PRM = new String[0]; // 8
	public String[] LK_BM0044_JABO_LAST_YM = new String[0]; // 8
	public String[] LK_BM0044_JABO_NAPBANG = new String[0]; // 8
	public String[] LK_BM0044_JABO_NAPIP_CNT = new String[0]; // 8
	public String[] LK_BM0044_JABO_POLI_NO = new String[0]; // 8
	public String[] LK_BM0044_JABO_REC = new String[0]; // 8
	public String[] LK_BM0044_JANG_BJ_CD = new String[0]; // 8
	public String[] LK_BM0044_JANG_BORYO = new String[0]; // 8
	public String[] LK_BM0044_JANG_GONG_PRM = new String[0]; // 8
	public String[] LK_BM0044_JANG_JUTEK = new String[0]; // 8
	public String[] LK_BM0044_JANG_LAST_YM = new String[0]; // 8
	public String[] LK_BM0044_JANG_NAPBANG = new String[0]; // 8
	public String[] LK_BM0044_JANG_NAPIP_CNT = new String[0]; // 8
	public String[] LK_BM0044_JANG_POLI_NO = new String[0]; // 8
	public String[] LK_BM0044_JANG_REC = new String[0]; // 8
	public String[] LK_BM0044_JANG_YUN_PRM = new String[0]; // 8
	public String[] LK_BM0044_JANG_YUN_SAVE = new String[0]; // 8
	//public String LK_BM0044_KEY_GIJUN_YY = null;
	//public String LK_BM0044_KEY_GOGEK_NO = null;
	//public String LK_BM0044_KEY_ILBAN_GB = null;
	//public String LK_BM0044_KEY_JABO_GB = null;
	//public String LK_BM0044_KEY_JANG_GB = null;
	//public String LK_BM0044_KEY_POLI_NO1 = null;
	//public String LK_BM0044_KEY_POLI_NO2 = null;
	//public String LK_BM0044_KEY_POLI_NO3 = null;
	public String LK_BM0044_MESSAGE = null;
	public String LK_BM0044_MESSAGE_CODE = null;
	public String LK_BM0044_MSG_CD1 = null;
	public String LK_BM0044_MSG_CD2 = null;
	//public String LK_BM0044_NET_RC = null;
	public String LK_BM0044_PARTNER_CD = null;
	public String LK_BM0044_PARTNER_GB = null;
	public String LK_BM0044_RETURN_CD = null;
	public String LK_BM0044_TRAN_CD = null;
	public String LK_BM0044_TRAN_G_TIME = null;
	public String LK_BM0044_UPBU_BUNRYU1 = null;
	public String LK_BM0044_UPBU_BUNRYU2 = null;
	public String LK_BM0044_UPBU_BUNRYU3 = null;
	//public String LK_BM0044_UPMU_GB = null;
	//public String LK_BM0044_UPMU_SEBU_GB = null;
	public String LK_BM0044_USER_ID = null;
	public String Length = null;
	public String RecordName = null;
	public String RecordShortDescription = null;
	public String Version = null;
	
	// 변경전문 (2011.9.29)
	// 키정보
	public String SCR_BM0044_KEY_GOGEK_NO			= "";				// 고객번호 
	public String SCR_BM0044_KEY_GIJUN_YY			= "";				// 기준년도
	public String SCR_BM0044_KEY_JABO_GB			= "";				// 자동차증권연속여부
	public String SCR_BM0044_KEY_POLI_NO1			= "";				// 자동차연속증권번호
	public String SCR_BM0044_KEY_JANG_GB			= "";				// 장기증권연속여부
	public String SCR_BM0044_KEY_POLI_NO2			= "";				// 장기연속증권번호
	public String SCR_BM0044_KEY_ILBAN_GB			= "";				// 일반증권연속여부
	public String SCR_BM0044_KEY_POLI_NO3			= "";				// 일반연속증권번호
	// 고객사항
	public String H_SCR_BM0044_GOGEK_NAME			= "";				// 고객명   
	public String SCR_BM0044_GOGEK_JUMIN_NO			= "";				// 주민번호  
	public String SCR_BM0044_GOGEK_ZIP				= "";				// 우편번호       
	public String H_SCR_BM0044_GOGEK_ZIP_NAME		= "";				// 우편번호명
	public String H_SCR_BM0044_GOGEK_GITA			= "";				// 기타번지
	// 자동차 보험료정보
	public String[] SCR_BM0044_JABO_POLI_NO			= new String[0];	// 증권번호    
	public String[] H_SCR_BM0044_JABO_PIBO_NM		= new String[0];	// 피보험자명   
	public String[] H_SCR_BM0044_JABO_GWANGYE		= new String[0];	// 피보험자관계   
	public String[] SCR_BM0044_JABO_BJ_CD			= new String[0];	// 보종코드       
	public String[] H_SCR_BM0044_JABO_BJ_NM			= new String[0];	// 상품명     
	public String[] SCR_BM0044_JABO_NAPBANG			= new String[0];	// 납입방법코드     
	public String[] H_SCR_BM0044_JABO_NAPBANG_NM	= new String[0];	// 납입방법명
	public String[] SCR_BM0044_JABO_LAST_YM			= new String[0];	// 최종납입년월    
	public String[] SCR_BM0044_JABO_NAPIP_CNT		= new String[0];	// 납입횟수
	public String[] H_SCR_BM0044_JABO_CAR_NO		= new String[0];	// 차량번호    
	public String[] SCR_BM0044_JABO_GONG_PRM		= new String[0];	// 소득공제대상보험료（보장성）    
	public String[] SCR_BM0044_JABO_JANG_PRM		= new String[0];	// 소득공제대상보험료（장애인보장성－곰두리
	// 장기 보험료정보
	public String[] SCR_BM0044_JANG_POLI_NO			= new String[0];	// 증권번호     
	public String[] H_SCR_BM0044_JANG_PIBO_NM		= new String[0];	// 피보험자명   
	public String[] H_SCR_BM0044_JANG_GWANGYE		= new String[0];	// 피보험자관계   
	public String[] SCR_BM0044_JANG_BJ_CD			= new String[0];	// 보종코드
	public String[] H_SCR_BM0044_JANG_BJ_NM			= new String[0];	// 상품명     
	public String[] SCR_BM0044_JANG_NAPBANG			= new String[0];	// 납입방법코드   
	public String[] H_SCR_BM0044_JANG_NAPBANG_NM	= new String[0];	// 납입방법명
	public String[] SCR_BM0044_JANG_LAST_YM			= new String[0];	// 최종납입년월     
	public String[] SCR_BM0044_JANG_NAPIP_CNT		= new String[0];	// 납입횟수   
	public String[] H_SCR_BM0044_JANG_CAR_NO		= new String[0];	// 차량번호    
	public String[] SCR_BM0044_JANG_GONG_PRM		= new String[0];	// 소득공제대상보험료（보장성）    
	public String[] SCR_BM0044_JANG_YUN_PRM			= new String[0];	// 소득공제대상보험료（개인연금）     
	public String[] SCR_BM0044_JANG_YUN_SAVE		= new String[0];	// 소득공제대상보험료（연금저축）    
	public String[] SCR_BM0044_JANG_JUTEK			= new String[0];	// 소득공제대상보험료（주택마련）
	public String[] SCR_BM0044_JANG_BORYO			= new String[0];	// 1회분 보험료	
	// 일반 보험료정보
	public String[] SCR_BM0044_ILBA_POLI_NO			= new String[0];	// 증권번호     
	public String[] H_SCR_BM0044_ILBA_PIBO_NM		= new String[0];	// 피보험자명   
	public String[] H_SCR_BM0044_ILBA_GWANGYE		= new String[0];	// 피보험자관계   
	public String[] SCR_BM0044_ILBA_BJ_CD			= new String[0];	// 보종코드       
	public String[] H_SCR_BM0044_ILBA_BJ_NM			= new String[0];	// 상품명     
	public String[] SCR_BM0044_ILBA_NAPBANG			= new String[0];	// 납입방법코드     
	public String[] H_SCR_BM0044_ILBA_NAPBANG_NM	= new String[0];	// 납입방법명
	public String[] SCR_BM0044_ILBA_LAST_YM			= new String[0];	// 최종납입년월     
	public String[] SCR_BM0044_ILBA_NAPIP_CNT		= new String[0];	// 납입횟수   
	public String[] H_SCR_BM0044_ILBA_CAR_NO		= new String[0];	// 차량번호    
	public String[] SCR_BM0044_ILBA_GONG_PRM		= new String[0];	// 소득공제대상보험료（보장성）    
	public String SCR_BM0044_FILLER					= "";
	public String USER_LAST_FLAG = "";
	public String USER_COND_CD = "";
	
	public List<Map<String,Object>> LOOP_JABO = null;
	public List<Map<String,Object>> LOOP_JANG = null;
	public List<Map<String,Object>> LOOP_ILBA = null;
	
	public String getrURL() {
		return rURL;
	}
	public void setrURL(String rURL) {
		this.rURL = rURL;
	}
	public String getLK_BM0044_NET_RC() {
		return LK_BM0044_NET_RC;
	}
	public void setLK_BM0044_NET_RC(String lK_BM0044_NET_RC) {
		LK_BM0044_NET_RC = lK_BM0044_NET_RC;
	}
	public String getLK_BM0044_UPMU_GB() {
		return LK_BM0044_UPMU_GB;
	}
	public void setLK_BM0044_UPMU_GB(String lK_BM0044_UPMU_GB) {
		LK_BM0044_UPMU_GB = lK_BM0044_UPMU_GB;
	}
	public String getLK_BM0044_UPMU_SEBU_GB() {
		return LK_BM0044_UPMU_SEBU_GB;
	}
	public void setLK_BM0044_UPMU_SEBU_GB(String lK_BM0044_UPMU_SEBU_GB) {
		LK_BM0044_UPMU_SEBU_GB = lK_BM0044_UPMU_SEBU_GB;
	}
	public String getLK_BM0044_CONTINUE_GB() {
		return LK_BM0044_CONTINUE_GB;
	}
	public void setLK_BM0044_CONTINUE_GB(String lK_BM0044_CONTINUE_GB) {
		LK_BM0044_CONTINUE_GB = lK_BM0044_CONTINUE_GB;
	}
	public String getLK_BM0044_KEY_GOGEK_NO() {
		return LK_BM0044_KEY_GOGEK_NO;
	}
	public void setLK_BM0044_KEY_GOGEK_NO(String lK_BM0044_KEY_GOGEK_NO) {
		LK_BM0044_KEY_GOGEK_NO = lK_BM0044_KEY_GOGEK_NO;
	}
	public String getLK_BM0044_KEY_GIJUN_YY() {
		return LK_BM0044_KEY_GIJUN_YY;
	}
	public void setLK_BM0044_KEY_GIJUN_YY(String lK_BM0044_KEY_GIJUN_YY) {
		LK_BM0044_KEY_GIJUN_YY = lK_BM0044_KEY_GIJUN_YY;
	}
	public String getLK_BM0044_KEY_JABO_GB() {
		return LK_BM0044_KEY_JABO_GB;
	}
	public void setLK_BM0044_KEY_JABO_GB(String lK_BM0044_KEY_JABO_GB) {
		LK_BM0044_KEY_JABO_GB = lK_BM0044_KEY_JABO_GB;
	}
	public String getLK_BM0044_KEY_POLI_NO1() {
		return LK_BM0044_KEY_POLI_NO1;
	}
	public void setLK_BM0044_KEY_POLI_NO1(String lK_BM0044_KEY_POLI_NO1) {
		LK_BM0044_KEY_POLI_NO1 = lK_BM0044_KEY_POLI_NO1;
	}
	public String getLK_BM0044_KEY_JANG_GB() {
		return LK_BM0044_KEY_JANG_GB;
	}
	public void setLK_BM0044_KEY_JANG_GB(String lK_BM0044_KEY_JANG_GB) {
		LK_BM0044_KEY_JANG_GB = lK_BM0044_KEY_JANG_GB;
	}
	public String getLK_BM0044_KEY_POLI_NO2() {
		return LK_BM0044_KEY_POLI_NO2;
	}
	public void setLK_BM0044_KEY_POLI_NO2(String lK_BM0044_KEY_POLI_NO2) {
		LK_BM0044_KEY_POLI_NO2 = lK_BM0044_KEY_POLI_NO2;
	}
	public String getLK_BM0044_KEY_ILBAN_GB() {
		return LK_BM0044_KEY_ILBAN_GB;
	}
	public void setLK_BM0044_KEY_ILBAN_GB(String lK_BM0044_KEY_ILBAN_GB) {
		LK_BM0044_KEY_ILBAN_GB = lK_BM0044_KEY_ILBAN_GB;
	}
	public String getLK_BM0044_KEY_POLI_NO3() {
		return LK_BM0044_KEY_POLI_NO3;
	}
	public void setLK_BM0044_KEY_POLI_NO3(String lK_BM0044_KEY_POLI_NO3) {
		LK_BM0044_KEY_POLI_NO3 = lK_BM0044_KEY_POLI_NO3;
	}
	public String getH_LK_BM0044_GOGEK_GITA() {
		return H_LK_BM0044_GOGEK_GITA;
	}
	public void setH_LK_BM0044_GOGEK_GITA(String h_LK_BM0044_GOGEK_GITA) {
		H_LK_BM0044_GOGEK_GITA = h_LK_BM0044_GOGEK_GITA;
	}
	public String getH_LK_BM0044_GOGEK_NAME() {
		return H_LK_BM0044_GOGEK_NAME;
	}
	public void setH_LK_BM0044_GOGEK_NAME(String h_LK_BM0044_GOGEK_NAME) {
		H_LK_BM0044_GOGEK_NAME = h_LK_BM0044_GOGEK_NAME;
	}
	public String getH_LK_BM0044_GOGEK_ZIP_NAME() {
		return H_LK_BM0044_GOGEK_ZIP_NAME;
	}
	public void setH_LK_BM0044_GOGEK_ZIP_NAME(String h_LK_BM0044_GOGEK_ZIP_NAME) {
		H_LK_BM0044_GOGEK_ZIP_NAME = h_LK_BM0044_GOGEK_ZIP_NAME;
	}
	public String[] getH_LK_BM0044_ILBA_BJ_NM() {
		return H_LK_BM0044_ILBA_BJ_NM;
	}
	public void setH_LK_BM0044_ILBA_BJ_NM(String[] h_LK_BM0044_ILBA_BJ_NM) {
		H_LK_BM0044_ILBA_BJ_NM = h_LK_BM0044_ILBA_BJ_NM;
	}
	public String[] getH_LK_BM0044_ILBA_CAR_NO() {
		return H_LK_BM0044_ILBA_CAR_NO;
	}
	public void setH_LK_BM0044_ILBA_CAR_NO(String[] h_LK_BM0044_ILBA_CAR_NO) {
		H_LK_BM0044_ILBA_CAR_NO = h_LK_BM0044_ILBA_CAR_NO;
	}
	public String[] getH_LK_BM0044_ILBA_GWANGYE() {
		return H_LK_BM0044_ILBA_GWANGYE;
	}
	public void setH_LK_BM0044_ILBA_GWANGYE(String[] h_LK_BM0044_ILBA_GWANGYE) {
		H_LK_BM0044_ILBA_GWANGYE = h_LK_BM0044_ILBA_GWANGYE;
	}
	public String[] getH_LK_BM0044_ILBA_NAPBANG_NM() {
		return H_LK_BM0044_ILBA_NAPBANG_NM;
	}
	public void setH_LK_BM0044_ILBA_NAPBANG_NM(String[] h_LK_BM0044_ILBA_NAPBANG_NM) {
		H_LK_BM0044_ILBA_NAPBANG_NM = h_LK_BM0044_ILBA_NAPBANG_NM;
	}
	public String[] getH_LK_BM0044_ILBA_PIBO_NM() {
		return H_LK_BM0044_ILBA_PIBO_NM;
	}
	public void setH_LK_BM0044_ILBA_PIBO_NM(String[] h_LK_BM0044_ILBA_PIBO_NM) {
		H_LK_BM0044_ILBA_PIBO_NM = h_LK_BM0044_ILBA_PIBO_NM;
	}
	public String[] getH_LK_BM0044_JABO_BJ_NM() {
		return H_LK_BM0044_JABO_BJ_NM;
	}
	public void setH_LK_BM0044_JABO_BJ_NM(String[] h_LK_BM0044_JABO_BJ_NM) {
		H_LK_BM0044_JABO_BJ_NM = h_LK_BM0044_JABO_BJ_NM;
	}
	public String[] getH_LK_BM0044_JABO_CAR_NO() {
		return H_LK_BM0044_JABO_CAR_NO;
	}
	public void setH_LK_BM0044_JABO_CAR_NO(String[] h_LK_BM0044_JABO_CAR_NO) {
		H_LK_BM0044_JABO_CAR_NO = h_LK_BM0044_JABO_CAR_NO;
	}
	public String[] getH_LK_BM0044_JABO_GWANGYE() {
		return H_LK_BM0044_JABO_GWANGYE;
	}
	public void setH_LK_BM0044_JABO_GWANGYE(String[] h_LK_BM0044_JABO_GWANGYE) {
		H_LK_BM0044_JABO_GWANGYE = h_LK_BM0044_JABO_GWANGYE;
	}
	public String[] getH_LK_BM0044_JABO_NAPBANG_NM() {
		return H_LK_BM0044_JABO_NAPBANG_NM;
	}
	public void setH_LK_BM0044_JABO_NAPBANG_NM(String[] h_LK_BM0044_JABO_NAPBANG_NM) {
		H_LK_BM0044_JABO_NAPBANG_NM = h_LK_BM0044_JABO_NAPBANG_NM;
	}
	public String[] getH_LK_BM0044_JABO_PIBO_NM() {
		return H_LK_BM0044_JABO_PIBO_NM;
	}
	public void setH_LK_BM0044_JABO_PIBO_NM(String[] h_LK_BM0044_JABO_PIBO_NM) {
		H_LK_BM0044_JABO_PIBO_NM = h_LK_BM0044_JABO_PIBO_NM;
	}
	public String[] getH_LK_BM0044_JANG_BJ_NM() {
		return H_LK_BM0044_JANG_BJ_NM;
	}
	public void setH_LK_BM0044_JANG_BJ_NM(String[] h_LK_BM0044_JANG_BJ_NM) {
		H_LK_BM0044_JANG_BJ_NM = h_LK_BM0044_JANG_BJ_NM;
	}
	public String[] getH_LK_BM0044_JANG_CAR_NO() {
		return H_LK_BM0044_JANG_CAR_NO;
	}
	public void setH_LK_BM0044_JANG_CAR_NO(String[] h_LK_BM0044_JANG_CAR_NO) {
		H_LK_BM0044_JANG_CAR_NO = h_LK_BM0044_JANG_CAR_NO;
	}
	public String[] getH_LK_BM0044_JANG_GWANGYE() {
		return H_LK_BM0044_JANG_GWANGYE;
	}
	public void setH_LK_BM0044_JANG_GWANGYE(String[] h_LK_BM0044_JANG_GWANGYE) {
		H_LK_BM0044_JANG_GWANGYE = h_LK_BM0044_JANG_GWANGYE;
	}
	public String[] getH_LK_BM0044_JANG_NAPBANG_NM() {
		return H_LK_BM0044_JANG_NAPBANG_NM;
	}
	public void setH_LK_BM0044_JANG_NAPBANG_NM(String[] h_LK_BM0044_JANG_NAPBANG_NM) {
		H_LK_BM0044_JANG_NAPBANG_NM = h_LK_BM0044_JANG_NAPBANG_NM;
	}
	public String[] getH_LK_BM0044_JANG_PIBO_NM() {
		return H_LK_BM0044_JANG_PIBO_NM;
	}
	public void setH_LK_BM0044_JANG_PIBO_NM(String[] h_LK_BM0044_JANG_PIBO_NM) {
		H_LK_BM0044_JANG_PIBO_NM = h_LK_BM0044_JANG_PIBO_NM;
	}
	public String getH_LK_BM0044_MESSAGE1() {
		return H_LK_BM0044_MESSAGE1;
	}
	public void setH_LK_BM0044_MESSAGE1(String h_LK_BM0044_MESSAGE1) {
		H_LK_BM0044_MESSAGE1 = h_LK_BM0044_MESSAGE1;
	}
	public String getH_LK_BM0044_MESSAGE2() {
		return H_LK_BM0044_MESSAGE2;
	}
	public void setH_LK_BM0044_MESSAGE2(String h_LK_BM0044_MESSAGE2) {
		H_LK_BM0044_MESSAGE2 = h_LK_BM0044_MESSAGE2;
	}
	public String getLK_BM0044_FLAG() {
		return LK_BM0044_FLAG;
	}
	public void setLK_BM0044_FLAG(String lK_BM0044_FLAG) {
		LK_BM0044_FLAG = lK_BM0044_FLAG;
	}
	public String getLK_BM0044_GOGEK_JUMIN_NO() {
		return LK_BM0044_GOGEK_JUMIN_NO;
	}
	public void setLK_BM0044_GOGEK_JUMIN_NO(String lK_BM0044_GOGEK_JUMIN_NO) {
		LK_BM0044_GOGEK_JUMIN_NO = lK_BM0044_GOGEK_JUMIN_NO;
	}
	public String getLK_BM0044_GOGEK_ZIP() {
		return LK_BM0044_GOGEK_ZIP;
	}
	public void setLK_BM0044_GOGEK_ZIP(String lK_BM0044_GOGEK_ZIP) {
		LK_BM0044_GOGEK_ZIP = lK_BM0044_GOGEK_ZIP;
	}
	public String[] getLK_BM0044_ILBA_BJ_CD() {
		return LK_BM0044_ILBA_BJ_CD;
	}
	public void setLK_BM0044_ILBA_BJ_CD(String[] lK_BM0044_ILBA_BJ_CD) {
		LK_BM0044_ILBA_BJ_CD = lK_BM0044_ILBA_BJ_CD;
	}
	public String[] getLK_BM0044_ILBA_GONG_PRM() {
		return LK_BM0044_ILBA_GONG_PRM;
	}
	public void setLK_BM0044_ILBA_GONG_PRM(String[] lK_BM0044_ILBA_GONG_PRM) {
		LK_BM0044_ILBA_GONG_PRM = lK_BM0044_ILBA_GONG_PRM;
	}
	public String[] getLK_BM0044_ILBA_LAST_YM() {
		return LK_BM0044_ILBA_LAST_YM;
	}
	public void setLK_BM0044_ILBA_LAST_YM(String[] lK_BM0044_ILBA_LAST_YM) {
		LK_BM0044_ILBA_LAST_YM = lK_BM0044_ILBA_LAST_YM;
	}
	public String[] getLK_BM0044_ILBA_NAPBANG() {
		return LK_BM0044_ILBA_NAPBANG;
	}
	public void setLK_BM0044_ILBA_NAPBANG(String[] lK_BM0044_ILBA_NAPBANG) {
		LK_BM0044_ILBA_NAPBANG = lK_BM0044_ILBA_NAPBANG;
	}
	public String[] getLK_BM0044_ILBA_NAPIP_CNT() {
		return LK_BM0044_ILBA_NAPIP_CNT;
	}
	public void setLK_BM0044_ILBA_NAPIP_CNT(String[] lK_BM0044_ILBA_NAPIP_CNT) {
		LK_BM0044_ILBA_NAPIP_CNT = lK_BM0044_ILBA_NAPIP_CNT;
	}
	public String[] getLK_BM0044_ILBA_POLI_NO() {
		return LK_BM0044_ILBA_POLI_NO;
	}
	public void setLK_BM0044_ILBA_POLI_NO(String[] lK_BM0044_ILBA_POLI_NO) {
		LK_BM0044_ILBA_POLI_NO = lK_BM0044_ILBA_POLI_NO;
	}
	public String[] getLK_BM0044_ILBA_REC() {
		return LK_BM0044_ILBA_REC;
	}
	public void setLK_BM0044_ILBA_REC(String[] lK_BM0044_ILBA_REC) {
		LK_BM0044_ILBA_REC = lK_BM0044_ILBA_REC;
	}
	public String[] getLK_BM0044_JABO_BJ_CD() {
		return LK_BM0044_JABO_BJ_CD;
	}
	public void setLK_BM0044_JABO_BJ_CD(String[] lK_BM0044_JABO_BJ_CD) {
		LK_BM0044_JABO_BJ_CD = lK_BM0044_JABO_BJ_CD;
	}
	public String[] getLK_BM0044_JABO_GONG_PRM() {
		return LK_BM0044_JABO_GONG_PRM;
	}
	public void setLK_BM0044_JABO_GONG_PRM(String[] lK_BM0044_JABO_GONG_PRM) {
		LK_BM0044_JABO_GONG_PRM = lK_BM0044_JABO_GONG_PRM;
	}
	public String[] getLK_BM0044_JABO_JANG_PRM() {
		return LK_BM0044_JABO_JANG_PRM;
	}
	public void setLK_BM0044_JABO_JANG_PRM(String[] lK_BM0044_JABO_JANG_PRM) {
		LK_BM0044_JABO_JANG_PRM = lK_BM0044_JABO_JANG_PRM;
	}
	public String[] getLK_BM0044_JABO_LAST_YM() {
		return LK_BM0044_JABO_LAST_YM;
	}
	public void setLK_BM0044_JABO_LAST_YM(String[] lK_BM0044_JABO_LAST_YM) {
		LK_BM0044_JABO_LAST_YM = lK_BM0044_JABO_LAST_YM;
	}
	public String[] getLK_BM0044_JABO_NAPBANG() {
		return LK_BM0044_JABO_NAPBANG;
	}
	public void setLK_BM0044_JABO_NAPBANG(String[] lK_BM0044_JABO_NAPBANG) {
		LK_BM0044_JABO_NAPBANG = lK_BM0044_JABO_NAPBANG;
	}
	public String[] getLK_BM0044_JABO_NAPIP_CNT() {
		return LK_BM0044_JABO_NAPIP_CNT;
	}
	public void setLK_BM0044_JABO_NAPIP_CNT(String[] lK_BM0044_JABO_NAPIP_CNT) {
		LK_BM0044_JABO_NAPIP_CNT = lK_BM0044_JABO_NAPIP_CNT;
	}
	public String[] getLK_BM0044_JABO_POLI_NO() {
		return LK_BM0044_JABO_POLI_NO;
	}
	public void setLK_BM0044_JABO_POLI_NO(String[] lK_BM0044_JABO_POLI_NO) {
		LK_BM0044_JABO_POLI_NO = lK_BM0044_JABO_POLI_NO;
	}
	public String[] getLK_BM0044_JABO_REC() {
		return LK_BM0044_JABO_REC;
	}
	public void setLK_BM0044_JABO_REC(String[] lK_BM0044_JABO_REC) {
		LK_BM0044_JABO_REC = lK_BM0044_JABO_REC;
	}
	public String[] getLK_BM0044_JANG_BJ_CD() {
		return LK_BM0044_JANG_BJ_CD;
	}
	public void setLK_BM0044_JANG_BJ_CD(String[] lK_BM0044_JANG_BJ_CD) {
		LK_BM0044_JANG_BJ_CD = lK_BM0044_JANG_BJ_CD;
	}
	public String[] getLK_BM0044_JANG_BORYO() {
		return LK_BM0044_JANG_BORYO;
	}
	public void setLK_BM0044_JANG_BORYO(String[] lK_BM0044_JANG_BORYO) {
		LK_BM0044_JANG_BORYO = lK_BM0044_JANG_BORYO;
	}
	public String[] getLK_BM0044_JANG_GONG_PRM() {
		return LK_BM0044_JANG_GONG_PRM;
	}
	public void setLK_BM0044_JANG_GONG_PRM(String[] lK_BM0044_JANG_GONG_PRM) {
		LK_BM0044_JANG_GONG_PRM = lK_BM0044_JANG_GONG_PRM;
	}
	public String[] getLK_BM0044_JANG_JUTEK() {
		return LK_BM0044_JANG_JUTEK;
	}
	public void setLK_BM0044_JANG_JUTEK(String[] lK_BM0044_JANG_JUTEK) {
		LK_BM0044_JANG_JUTEK = lK_BM0044_JANG_JUTEK;
	}
	public String[] getLK_BM0044_JANG_LAST_YM() {
		return LK_BM0044_JANG_LAST_YM;
	}
	public void setLK_BM0044_JANG_LAST_YM(String[] lK_BM0044_JANG_LAST_YM) {
		LK_BM0044_JANG_LAST_YM = lK_BM0044_JANG_LAST_YM;
	}
	public String[] getLK_BM0044_JANG_NAPBANG() {
		return LK_BM0044_JANG_NAPBANG;
	}
	public void setLK_BM0044_JANG_NAPBANG(String[] lK_BM0044_JANG_NAPBANG) {
		LK_BM0044_JANG_NAPBANG = lK_BM0044_JANG_NAPBANG;
	}
	public String[] getLK_BM0044_JANG_NAPIP_CNT() {
		return LK_BM0044_JANG_NAPIP_CNT;
	}
	public void setLK_BM0044_JANG_NAPIP_CNT(String[] lK_BM0044_JANG_NAPIP_CNT) {
		LK_BM0044_JANG_NAPIP_CNT = lK_BM0044_JANG_NAPIP_CNT;
	}
	public String[] getLK_BM0044_JANG_POLI_NO() {
		return LK_BM0044_JANG_POLI_NO;
	}
	public void setLK_BM0044_JANG_POLI_NO(String[] lK_BM0044_JANG_POLI_NO) {
		LK_BM0044_JANG_POLI_NO = lK_BM0044_JANG_POLI_NO;
	}
	public String[] getLK_BM0044_JANG_REC() {
		return LK_BM0044_JANG_REC;
	}
	public void setLK_BM0044_JANG_REC(String[] lK_BM0044_JANG_REC) {
		LK_BM0044_JANG_REC = lK_BM0044_JANG_REC;
	}
	public String[] getLK_BM0044_JANG_YUN_PRM() {
		return LK_BM0044_JANG_YUN_PRM;
	}
	public void setLK_BM0044_JANG_YUN_PRM(String[] lK_BM0044_JANG_YUN_PRM) {
		LK_BM0044_JANG_YUN_PRM = lK_BM0044_JANG_YUN_PRM;
	}
	public String[] getLK_BM0044_JANG_YUN_SAVE() {
		return LK_BM0044_JANG_YUN_SAVE;
	}
	public void setLK_BM0044_JANG_YUN_SAVE(String[] lK_BM0044_JANG_YUN_SAVE) {
		LK_BM0044_JANG_YUN_SAVE = lK_BM0044_JANG_YUN_SAVE;
	}
	public String getLK_BM0044_MESSAGE() {
		return LK_BM0044_MESSAGE;
	}
	public void setLK_BM0044_MESSAGE(String lK_BM0044_MESSAGE) {
		LK_BM0044_MESSAGE = lK_BM0044_MESSAGE;
	}
	public String getLK_BM0044_MESSAGE_CODE() {
		return LK_BM0044_MESSAGE_CODE;
	}
	public void setLK_BM0044_MESSAGE_CODE(String lK_BM0044_MESSAGE_CODE) {
		LK_BM0044_MESSAGE_CODE = lK_BM0044_MESSAGE_CODE;
	}
	public String getLK_BM0044_MSG_CD1() {
		return LK_BM0044_MSG_CD1;
	}
	public void setLK_BM0044_MSG_CD1(String lK_BM0044_MSG_CD1) {
		LK_BM0044_MSG_CD1 = lK_BM0044_MSG_CD1;
	}
	public String getLK_BM0044_MSG_CD2() {
		return LK_BM0044_MSG_CD2;
	}
	public void setLK_BM0044_MSG_CD2(String lK_BM0044_MSG_CD2) {
		LK_BM0044_MSG_CD2 = lK_BM0044_MSG_CD2;
	}
	public String getLK_BM0044_PARTNER_CD() {
		return LK_BM0044_PARTNER_CD;
	}
	public void setLK_BM0044_PARTNER_CD(String lK_BM0044_PARTNER_CD) {
		LK_BM0044_PARTNER_CD = lK_BM0044_PARTNER_CD;
	}
	public String getLK_BM0044_PARTNER_GB() {
		return LK_BM0044_PARTNER_GB;
	}
	public void setLK_BM0044_PARTNER_GB(String lK_BM0044_PARTNER_GB) {
		LK_BM0044_PARTNER_GB = lK_BM0044_PARTNER_GB;
	}
	public String getLK_BM0044_RETURN_CD() {
		return LK_BM0044_RETURN_CD;
	}
	public void setLK_BM0044_RETURN_CD(String lK_BM0044_RETURN_CD) {
		LK_BM0044_RETURN_CD = lK_BM0044_RETURN_CD;
	}
	public String getLK_BM0044_TRAN_CD() {
		return LK_BM0044_TRAN_CD;
	}
	public void setLK_BM0044_TRAN_CD(String lK_BM0044_TRAN_CD) {
		LK_BM0044_TRAN_CD = lK_BM0044_TRAN_CD;
	}
	public String getLK_BM0044_TRAN_G_TIME() {
		return LK_BM0044_TRAN_G_TIME;
	}
	public void setLK_BM0044_TRAN_G_TIME(String lK_BM0044_TRAN_G_TIME) {
		LK_BM0044_TRAN_G_TIME = lK_BM0044_TRAN_G_TIME;
	}
	public String getLK_BM0044_UPBU_BUNRYU1() {
		return LK_BM0044_UPBU_BUNRYU1;
	}
	public void setLK_BM0044_UPBU_BUNRYU1(String lK_BM0044_UPBU_BUNRYU1) {
		LK_BM0044_UPBU_BUNRYU1 = lK_BM0044_UPBU_BUNRYU1;
	}
	public String getLK_BM0044_UPBU_BUNRYU2() {
		return LK_BM0044_UPBU_BUNRYU2;
	}
	public void setLK_BM0044_UPBU_BUNRYU2(String lK_BM0044_UPBU_BUNRYU2) {
		LK_BM0044_UPBU_BUNRYU2 = lK_BM0044_UPBU_BUNRYU2;
	}
	public String getLK_BM0044_UPBU_BUNRYU3() {
		return LK_BM0044_UPBU_BUNRYU3;
	}
	public void setLK_BM0044_UPBU_BUNRYU3(String lK_BM0044_UPBU_BUNRYU3) {
		LK_BM0044_UPBU_BUNRYU3 = lK_BM0044_UPBU_BUNRYU3;
	}
	public String getLK_BM0044_USER_ID() {
		return LK_BM0044_USER_ID;
	}
	public void setLK_BM0044_USER_ID(String lK_BM0044_USER_ID) {
		LK_BM0044_USER_ID = lK_BM0044_USER_ID;
	}
	public String getLength() {
		return Length;
	}
	public void setLength(String length) {
		Length = length;
	}
	public String getRecordName() {
		return RecordName;
	}
	public void setRecordName(String recordName) {
		RecordName = recordName;
	}
	public String getRecordShortDescription() {
		return RecordShortDescription;
	}
	public void setRecordShortDescription(String recordShortDescription) {
		RecordShortDescription = recordShortDescription;
	}
	public String getVersion() {
		return Version;
	}
	public void setVersion(String version) {
		Version = version;
	}
	public String getSCR_BM0044_KEY_GOGEK_NO() {
		return SCR_BM0044_KEY_GOGEK_NO;
	}
	public void setSCR_BM0044_KEY_GOGEK_NO(String sCR_BM0044_KEY_GOGEK_NO) {
		SCR_BM0044_KEY_GOGEK_NO = sCR_BM0044_KEY_GOGEK_NO;
	}
	public String getSCR_BM0044_KEY_GIJUN_YY() {
		return SCR_BM0044_KEY_GIJUN_YY;
	}
	public void setSCR_BM0044_KEY_GIJUN_YY(String sCR_BM0044_KEY_GIJUN_YY) {
		SCR_BM0044_KEY_GIJUN_YY = sCR_BM0044_KEY_GIJUN_YY;
	}
	public String getSCR_BM0044_KEY_JABO_GB() {
		return SCR_BM0044_KEY_JABO_GB;
	}
	public void setSCR_BM0044_KEY_JABO_GB(String sCR_BM0044_KEY_JABO_GB) {
		SCR_BM0044_KEY_JABO_GB = sCR_BM0044_KEY_JABO_GB;
	}
	public String getSCR_BM0044_KEY_POLI_NO1() {
		return SCR_BM0044_KEY_POLI_NO1;
	}
	public void setSCR_BM0044_KEY_POLI_NO1(String sCR_BM0044_KEY_POLI_NO1) {
		SCR_BM0044_KEY_POLI_NO1 = sCR_BM0044_KEY_POLI_NO1;
	}
	public String getSCR_BM0044_KEY_JANG_GB() {
		return SCR_BM0044_KEY_JANG_GB;
	}
	public void setSCR_BM0044_KEY_JANG_GB(String sCR_BM0044_KEY_JANG_GB) {
		SCR_BM0044_KEY_JANG_GB = sCR_BM0044_KEY_JANG_GB;
	}
	public String getSCR_BM0044_KEY_POLI_NO2() {
		return SCR_BM0044_KEY_POLI_NO2;
	}
	public void setSCR_BM0044_KEY_POLI_NO2(String sCR_BM0044_KEY_POLI_NO2) {
		SCR_BM0044_KEY_POLI_NO2 = sCR_BM0044_KEY_POLI_NO2;
	}
	public String getSCR_BM0044_KEY_ILBAN_GB() {
		return SCR_BM0044_KEY_ILBAN_GB;
	}
	public void setSCR_BM0044_KEY_ILBAN_GB(String sCR_BM0044_KEY_ILBAN_GB) {
		SCR_BM0044_KEY_ILBAN_GB = sCR_BM0044_KEY_ILBAN_GB;
	}
	public String getSCR_BM0044_KEY_POLI_NO3() {
		return SCR_BM0044_KEY_POLI_NO3;
	}
	public void setSCR_BM0044_KEY_POLI_NO3(String sCR_BM0044_KEY_POLI_NO3) {
		SCR_BM0044_KEY_POLI_NO3 = sCR_BM0044_KEY_POLI_NO3;
	}
	public String getH_SCR_BM0044_GOGEK_NAME() {
		return H_SCR_BM0044_GOGEK_NAME;
	}
	public void setH_SCR_BM0044_GOGEK_NAME(String h_SCR_BM0044_GOGEK_NAME) {
		H_SCR_BM0044_GOGEK_NAME = h_SCR_BM0044_GOGEK_NAME;
	}
	public String getSCR_BM0044_GOGEK_JUMIN_NO() {
		return SCR_BM0044_GOGEK_JUMIN_NO;
	}
	public void setSCR_BM0044_GOGEK_JUMIN_NO(String sCR_BM0044_GOGEK_JUMIN_NO) {
		SCR_BM0044_GOGEK_JUMIN_NO = sCR_BM0044_GOGEK_JUMIN_NO;
	}
	public String getSCR_BM0044_GOGEK_ZIP() {
		return SCR_BM0044_GOGEK_ZIP;
	}
	public void setSCR_BM0044_GOGEK_ZIP(String sCR_BM0044_GOGEK_ZIP) {
		SCR_BM0044_GOGEK_ZIP = sCR_BM0044_GOGEK_ZIP;
	}
	public String getH_SCR_BM0044_GOGEK_ZIP_NAME() {
		return H_SCR_BM0044_GOGEK_ZIP_NAME;
	}
	public void setH_SCR_BM0044_GOGEK_ZIP_NAME(String h_SCR_BM0044_GOGEK_ZIP_NAME) {
		H_SCR_BM0044_GOGEK_ZIP_NAME = h_SCR_BM0044_GOGEK_ZIP_NAME;
	}
	public String getH_SCR_BM0044_GOGEK_GITA() {
		return H_SCR_BM0044_GOGEK_GITA;
	}
	public void setH_SCR_BM0044_GOGEK_GITA(String h_SCR_BM0044_GOGEK_GITA) {
		H_SCR_BM0044_GOGEK_GITA = h_SCR_BM0044_GOGEK_GITA;
	}
	public String[] getSCR_BM0044_JABO_POLI_NO() {
		return SCR_BM0044_JABO_POLI_NO;
	}
	public void setSCR_BM0044_JABO_POLI_NO(String[] sCR_BM0044_JABO_POLI_NO) {
		SCR_BM0044_JABO_POLI_NO = sCR_BM0044_JABO_POLI_NO;
	}
	public String[] getH_SCR_BM0044_JABO_PIBO_NM() {
		return H_SCR_BM0044_JABO_PIBO_NM;
	}
	public void setH_SCR_BM0044_JABO_PIBO_NM(String[] h_SCR_BM0044_JABO_PIBO_NM) {
		H_SCR_BM0044_JABO_PIBO_NM = h_SCR_BM0044_JABO_PIBO_NM;
	}
	public String[] getH_SCR_BM0044_JABO_GWANGYE() {
		return H_SCR_BM0044_JABO_GWANGYE;
	}
	public void setH_SCR_BM0044_JABO_GWANGYE(String[] h_SCR_BM0044_JABO_GWANGYE) {
		H_SCR_BM0044_JABO_GWANGYE = h_SCR_BM0044_JABO_GWANGYE;
	}
	public String[] getSCR_BM0044_JABO_BJ_CD() {
		return SCR_BM0044_JABO_BJ_CD;
	}
	public void setSCR_BM0044_JABO_BJ_CD(String[] sCR_BM0044_JABO_BJ_CD) {
		SCR_BM0044_JABO_BJ_CD = sCR_BM0044_JABO_BJ_CD;
	}
	public String[] getH_SCR_BM0044_JABO_BJ_NM() {
		return H_SCR_BM0044_JABO_BJ_NM;
	}
	public void setH_SCR_BM0044_JABO_BJ_NM(String[] h_SCR_BM0044_JABO_BJ_NM) {
		H_SCR_BM0044_JABO_BJ_NM = h_SCR_BM0044_JABO_BJ_NM;
	}
	public String[] getSCR_BM0044_JABO_NAPBANG() {
		return SCR_BM0044_JABO_NAPBANG;
	}
	public void setSCR_BM0044_JABO_NAPBANG(String[] sCR_BM0044_JABO_NAPBANG) {
		SCR_BM0044_JABO_NAPBANG = sCR_BM0044_JABO_NAPBANG;
	}
	public String[] getH_SCR_BM0044_JABO_NAPBANG_NM() {
		return H_SCR_BM0044_JABO_NAPBANG_NM;
	}
	public void setH_SCR_BM0044_JABO_NAPBANG_NM(
			String[] h_SCR_BM0044_JABO_NAPBANG_NM) {
		H_SCR_BM0044_JABO_NAPBANG_NM = h_SCR_BM0044_JABO_NAPBANG_NM;
	}
	public String[] getSCR_BM0044_JABO_LAST_YM() {
		return SCR_BM0044_JABO_LAST_YM;
	}
	public void setSCR_BM0044_JABO_LAST_YM(String[] sCR_BM0044_JABO_LAST_YM) {
		SCR_BM0044_JABO_LAST_YM = sCR_BM0044_JABO_LAST_YM;
	}
	public String[] getSCR_BM0044_JABO_NAPIP_CNT() {
		return SCR_BM0044_JABO_NAPIP_CNT;
	}
	public void setSCR_BM0044_JABO_NAPIP_CNT(String[] sCR_BM0044_JABO_NAPIP_CNT) {
		SCR_BM0044_JABO_NAPIP_CNT = sCR_BM0044_JABO_NAPIP_CNT;
	}
	public String[] getH_SCR_BM0044_JABO_CAR_NO() {
		return H_SCR_BM0044_JABO_CAR_NO;
	}
	public void setH_SCR_BM0044_JABO_CAR_NO(String[] h_SCR_BM0044_JABO_CAR_NO) {
		H_SCR_BM0044_JABO_CAR_NO = h_SCR_BM0044_JABO_CAR_NO;
	}
	public String[] getSCR_BM0044_JABO_GONG_PRM() {
		return SCR_BM0044_JABO_GONG_PRM;
	}
	public void setSCR_BM0044_JABO_GONG_PRM(String[] sCR_BM0044_JABO_GONG_PRM) {
		SCR_BM0044_JABO_GONG_PRM = sCR_BM0044_JABO_GONG_PRM;
	}
	public String[] getSCR_BM0044_JABO_JANG_PRM() {
		return SCR_BM0044_JABO_JANG_PRM;
	}
	public void setSCR_BM0044_JABO_JANG_PRM(String[] sCR_BM0044_JABO_JANG_PRM) {
		SCR_BM0044_JABO_JANG_PRM = sCR_BM0044_JABO_JANG_PRM;
	}
	public String[] getSCR_BM0044_JANG_POLI_NO() {
		return SCR_BM0044_JANG_POLI_NO;
	}
	public void setSCR_BM0044_JANG_POLI_NO(String[] sCR_BM0044_JANG_POLI_NO) {
		SCR_BM0044_JANG_POLI_NO = sCR_BM0044_JANG_POLI_NO;
	}
	public String[] getH_SCR_BM0044_JANG_PIBO_NM() {
		return H_SCR_BM0044_JANG_PIBO_NM;
	}
	public void setH_SCR_BM0044_JANG_PIBO_NM(String[] h_SCR_BM0044_JANG_PIBO_NM) {
		H_SCR_BM0044_JANG_PIBO_NM = h_SCR_BM0044_JANG_PIBO_NM;
	}
	public String[] getH_SCR_BM0044_JANG_GWANGYE() {
		return H_SCR_BM0044_JANG_GWANGYE;
	}
	public void setH_SCR_BM0044_JANG_GWANGYE(String[] h_SCR_BM0044_JANG_GWANGYE) {
		H_SCR_BM0044_JANG_GWANGYE = h_SCR_BM0044_JANG_GWANGYE;
	}
	public String[] getSCR_BM0044_JANG_BJ_CD() {
		return SCR_BM0044_JANG_BJ_CD;
	}
	public void setSCR_BM0044_JANG_BJ_CD(String[] sCR_BM0044_JANG_BJ_CD) {
		SCR_BM0044_JANG_BJ_CD = sCR_BM0044_JANG_BJ_CD;
	}
	public String[] getH_SCR_BM0044_JANG_BJ_NM() {
		return H_SCR_BM0044_JANG_BJ_NM;
	}
	public void setH_SCR_BM0044_JANG_BJ_NM(String[] h_SCR_BM0044_JANG_BJ_NM) {
		H_SCR_BM0044_JANG_BJ_NM = h_SCR_BM0044_JANG_BJ_NM;
	}
	public String[] getSCR_BM0044_JANG_NAPBANG() {
		return SCR_BM0044_JANG_NAPBANG;
	}
	public void setSCR_BM0044_JANG_NAPBANG(String[] sCR_BM0044_JANG_NAPBANG) {
		SCR_BM0044_JANG_NAPBANG = sCR_BM0044_JANG_NAPBANG;
	}
	public String[] getH_SCR_BM0044_JANG_NAPBANG_NM() {
		return H_SCR_BM0044_JANG_NAPBANG_NM;
	}
	public void setH_SCR_BM0044_JANG_NAPBANG_NM(
			String[] h_SCR_BM0044_JANG_NAPBANG_NM) {
		H_SCR_BM0044_JANG_NAPBANG_NM = h_SCR_BM0044_JANG_NAPBANG_NM;
	}
	public String[] getSCR_BM0044_JANG_LAST_YM() {
		return SCR_BM0044_JANG_LAST_YM;
	}
	public void setSCR_BM0044_JANG_LAST_YM(String[] sCR_BM0044_JANG_LAST_YM) {
		SCR_BM0044_JANG_LAST_YM = sCR_BM0044_JANG_LAST_YM;
	}
	public String[] getSCR_BM0044_JANG_NAPIP_CNT() {
		return SCR_BM0044_JANG_NAPIP_CNT;
	}
	public void setSCR_BM0044_JANG_NAPIP_CNT(String[] sCR_BM0044_JANG_NAPIP_CNT) {
		SCR_BM0044_JANG_NAPIP_CNT = sCR_BM0044_JANG_NAPIP_CNT;
	}
	public String[] getH_SCR_BM0044_JANG_CAR_NO() {
		return H_SCR_BM0044_JANG_CAR_NO;
	}
	public void setH_SCR_BM0044_JANG_CAR_NO(String[] h_SCR_BM0044_JANG_CAR_NO) {
		H_SCR_BM0044_JANG_CAR_NO = h_SCR_BM0044_JANG_CAR_NO;
	}
	public String[] getSCR_BM0044_JANG_GONG_PRM() {
		return SCR_BM0044_JANG_GONG_PRM;
	}
	public void setSCR_BM0044_JANG_GONG_PRM(String[] sCR_BM0044_JANG_GONG_PRM) {
		SCR_BM0044_JANG_GONG_PRM = sCR_BM0044_JANG_GONG_PRM;
	}
	public String[] getSCR_BM0044_JANG_YUN_PRM() {
		return SCR_BM0044_JANG_YUN_PRM;
	}
	public void setSCR_BM0044_JANG_YUN_PRM(String[] sCR_BM0044_JANG_YUN_PRM) {
		SCR_BM0044_JANG_YUN_PRM = sCR_BM0044_JANG_YUN_PRM;
	}
	public String[] getSCR_BM0044_JANG_YUN_SAVE() {
		return SCR_BM0044_JANG_YUN_SAVE;
	}
	public void setSCR_BM0044_JANG_YUN_SAVE(String[] sCR_BM0044_JANG_YUN_SAVE) {
		SCR_BM0044_JANG_YUN_SAVE = sCR_BM0044_JANG_YUN_SAVE;
	}
	public String[] getSCR_BM0044_JANG_JUTEK() {
		return SCR_BM0044_JANG_JUTEK;
	}
	public void setSCR_BM0044_JANG_JUTEK(String[] sCR_BM0044_JANG_JUTEK) {
		SCR_BM0044_JANG_JUTEK = sCR_BM0044_JANG_JUTEK;
	}
	public String[] getSCR_BM0044_JANG_BORYO() {
		return SCR_BM0044_JANG_BORYO;
	}
	public void setSCR_BM0044_JANG_BORYO(String[] sCR_BM0044_JANG_BORYO) {
		SCR_BM0044_JANG_BORYO = sCR_BM0044_JANG_BORYO;
	}
	public String[] getSCR_BM0044_ILBA_POLI_NO() {
		return SCR_BM0044_ILBA_POLI_NO;
	}
	public void setSCR_BM0044_ILBA_POLI_NO(String[] sCR_BM0044_ILBA_POLI_NO) {
		SCR_BM0044_ILBA_POLI_NO = sCR_BM0044_ILBA_POLI_NO;
	}
	public String[] getH_SCR_BM0044_ILBA_PIBO_NM() {
		return H_SCR_BM0044_ILBA_PIBO_NM;
	}
	public void setH_SCR_BM0044_ILBA_PIBO_NM(String[] h_SCR_BM0044_ILBA_PIBO_NM) {
		H_SCR_BM0044_ILBA_PIBO_NM = h_SCR_BM0044_ILBA_PIBO_NM;
	}
	public String[] getH_SCR_BM0044_ILBA_GWANGYE() {
		return H_SCR_BM0044_ILBA_GWANGYE;
	}
	public void setH_SCR_BM0044_ILBA_GWANGYE(String[] h_SCR_BM0044_ILBA_GWANGYE) {
		H_SCR_BM0044_ILBA_GWANGYE = h_SCR_BM0044_ILBA_GWANGYE;
	}
	public String[] getSCR_BM0044_ILBA_BJ_CD() {
		return SCR_BM0044_ILBA_BJ_CD;
	}
	public void setSCR_BM0044_ILBA_BJ_CD(String[] sCR_BM0044_ILBA_BJ_CD) {
		SCR_BM0044_ILBA_BJ_CD = sCR_BM0044_ILBA_BJ_CD;
	}
	public String[] getH_SCR_BM0044_ILBA_BJ_NM() {
		return H_SCR_BM0044_ILBA_BJ_NM;
	}
	public void setH_SCR_BM0044_ILBA_BJ_NM(String[] h_SCR_BM0044_ILBA_BJ_NM) {
		H_SCR_BM0044_ILBA_BJ_NM = h_SCR_BM0044_ILBA_BJ_NM;
	}
	public String[] getSCR_BM0044_ILBA_NAPBANG() {
		return SCR_BM0044_ILBA_NAPBANG;
	}
	public void setSCR_BM0044_ILBA_NAPBANG(String[] sCR_BM0044_ILBA_NAPBANG) {
		SCR_BM0044_ILBA_NAPBANG = sCR_BM0044_ILBA_NAPBANG;
	}
	public String[] getH_SCR_BM0044_ILBA_NAPBANG_NM() {
		return H_SCR_BM0044_ILBA_NAPBANG_NM;
	}
	public void setH_SCR_BM0044_ILBA_NAPBANG_NM(
			String[] h_SCR_BM0044_ILBA_NAPBANG_NM) {
		H_SCR_BM0044_ILBA_NAPBANG_NM = h_SCR_BM0044_ILBA_NAPBANG_NM;
	}
	public String[] getSCR_BM0044_ILBA_LAST_YM() {
		return SCR_BM0044_ILBA_LAST_YM;
	}
	public void setSCR_BM0044_ILBA_LAST_YM(String[] sCR_BM0044_ILBA_LAST_YM) {
		SCR_BM0044_ILBA_LAST_YM = sCR_BM0044_ILBA_LAST_YM;
	}
	public String[] getSCR_BM0044_ILBA_NAPIP_CNT() {
		return SCR_BM0044_ILBA_NAPIP_CNT;
	}
	public void setSCR_BM0044_ILBA_NAPIP_CNT(String[] sCR_BM0044_ILBA_NAPIP_CNT) {
		SCR_BM0044_ILBA_NAPIP_CNT = sCR_BM0044_ILBA_NAPIP_CNT;
	}
	public String[] getH_SCR_BM0044_ILBA_CAR_NO() {
		return H_SCR_BM0044_ILBA_CAR_NO;
	}
	public void setH_SCR_BM0044_ILBA_CAR_NO(String[] h_SCR_BM0044_ILBA_CAR_NO) {
		H_SCR_BM0044_ILBA_CAR_NO = h_SCR_BM0044_ILBA_CAR_NO;
	}
	public String[] getSCR_BM0044_ILBA_GONG_PRM() {
		return SCR_BM0044_ILBA_GONG_PRM;
	}
	public void setSCR_BM0044_ILBA_GONG_PRM(String[] sCR_BM0044_ILBA_GONG_PRM) {
		SCR_BM0044_ILBA_GONG_PRM = sCR_BM0044_ILBA_GONG_PRM;
	}
	public String getSCR_BM0044_FILLER() {
		return SCR_BM0044_FILLER;
	}
	public void setSCR_BM0044_FILLER(String sCR_BM0044_FILLER) {
		SCR_BM0044_FILLER = sCR_BM0044_FILLER;
	}
	public static String getProid() {
		return proid;
	}
	public static String getTrid() {
		return trid;
	}
	public List<Map<String, Object>> getLOOP_JABO() {
		return LOOP_JABO;
	}
	public void setLOOP_JABO(List<Map<String, Object>> lOOP_JABO) {
		LOOP_JABO = lOOP_JABO;
	}
	public List<Map<String, Object>> getLOOP_JANG() {
		return LOOP_JANG;
	}
	public void setLOOP_JANG(List<Map<String, Object>> lOOP_JANG) {
		LOOP_JANG = lOOP_JANG;
	}
	public List<Map<String, Object>> getLOOP_ILBA() {
		return LOOP_ILBA;
	}
	public void setLOOP_ILBA(List<Map<String, Object>> lOOP_ILBA) {
		LOOP_ILBA = lOOP_ILBA;
	}
	public String getUSER_LAST_FLAG() {
		return USER_LAST_FLAG;
	}
	public void setUSER_LAST_FLAG(String uSER_LAST_FLAG) {
		USER_LAST_FLAG = uSER_LAST_FLAG;
	}
	public String getUSER_COND_CD() {
		return USER_COND_CD;
	}
	public void setUSER_COND_CD(String uSER_COND_CD) {
		USER_COND_CD = uSER_COND_CD;
	}

}
