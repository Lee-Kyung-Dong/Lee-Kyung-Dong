package com.idongbu.smartcustomer.vo;

import com.idongbu.common.vo.CMMVO;

public class CmmPostSearchVO extends CMMVO {

	private String zip	            = "";
	private String dong_name	    = "";
	private String gbn	            = "";
                                    
	private String brsido_name	    = "";
	private String sgg_name	        = "";
	private String place_um_name    = "";
	private String place_aft_text   = "";
	private String zip_no 	        = ""; 
	private String begin_bj_name    = "";
	private String detl_addr_name   = "";
                                    
	private String sido_cd          = "";
	private String sido_name        = "";
	private String sigungu_cd       = "";
	private String sigungu_name     = "";
	private String zip_cd           = "";
	private String zip_seq          = "";
	private String st_addr          = "";
	private String eupmyun_name     = "";
	private String st_name          = "";
	private String st_cd            = "";
	private String st_addr2         = "";
	private String bd_name          = "";
	private String bd_no            = "";
	private String zip_eupmyun_name = "";
	
	private String zipcode          = "";
	private String address1         = "";
	private String address2         = "";
	private String address3         = "";
	private String address4         = "";
	private String radio1           = "";
	
	private String bd_bon_from      = "";
	private String bd_bon_to        = "";
	
	private String singu            = "";
	
	private String HO_H_JUSO        = "";
	private String HI_H_ADDR        = "";
	private String HO_J_JUSO        = "";
	private String HI_J_ADDR        = "";
	private String HO_G_JUSO        = "";
	private String HI_G_ADDR        = "";
	
	public String getZip() {
		return zip;
	}
	public void setZip(String zip) {
		this.zip = zip;
	}
	public String getDong_name() {
		return dong_name;
	}
	public void setDong_name(String dong_name) {
		this.dong_name = dong_name;
	}
	public String getGbn() {
		return gbn;
	}
	public void setGbn(String gbn) {
		this.gbn = gbn;
	}
	public String getBrsido_name() {
		return brsido_name;
	}
	public void setBrsido_name(String brsido_name) {
		this.brsido_name = brsido_name;
	}
	public String getSgg_name() {
		return sgg_name;
	}
	public void setSgg_name(String sgg_name) {
		this.sgg_name = sgg_name;
	}
	public String getPlace_um_name() {
		return place_um_name;
	}
	public void setPlace_um_name(String place_um_name) {
		this.place_um_name = place_um_name;
	}
	public String getPlace_aft_text() {
		return place_aft_text;
	}
	public void setPlace_aft_text(String place_aft_text) {
		this.place_aft_text = place_aft_text;
	}
	public String getZip_no() {
		return zip_no;
	}
	public void setZip_no(String zip_no) {
		this.zip_no = zip_no;
	}
	public String getBegin_bj_name() {
		return begin_bj_name;
	}
	public void setBegin_bj_name(String begin_bj_name) {
		this.begin_bj_name = begin_bj_name;
	}
	public String getDetl_addr_name() {
		return detl_addr_name;
	}
	public void setDetl_addr_name(String detl_addr_name) {
		this.detl_addr_name = detl_addr_name;
	}
	public String getSido_cd() {
		return sido_cd;
	}
	public void setSido_cd(String sido_cd) {
		this.sido_cd = sido_cd;
	}
	public String getSido_name() {
		return sido_name;
	}
	public void setSido_name(String sido_name) {
		this.sido_name = sido_name;
	}
	public String getSigungu_cd() {
		return sigungu_cd;
	}
	public void setSigungu_cd(String sigungu_cd) {
		this.sigungu_cd = sigungu_cd;
	}
	public String getSigungu_name() {
		return sigungu_name;
	}
	public void setSigungu_name(String sigungu_name) {
		this.sigungu_name = sigungu_name;
	}
	public String getZip_cd() {
		return zip_cd;
	}
	public void setZip_cd(String zip_cd) {
		this.zip_cd = zip_cd;
	}
	public String getZip_seq() {
		return zip_seq;
	}
	public void setZip_seq(String zip_seq) {
		this.zip_seq = zip_seq;
	}
	public String getSt_addr() {
		return st_addr;
	}
	public void setSt_addr(String st_addr) {
		this.st_addr = st_addr;
	}
	public String getEupmyun_name() {
		return eupmyun_name;
	}
	public void setEupmyun_name(String eupmyun_name) {
		this.eupmyun_name = eupmyun_name;
	}
	public String getSt_name() {
		return st_name;
	}
	public void setSt_name(String st_name) {
		this.st_name = st_name;
	}
	public String getSt_cd() {
		return st_cd;
	}
	public void setSt_cd(String st_cd) {
		this.st_cd = st_cd;
	}
	public String getSt_addr2() {
		return st_addr2;
	}
	public void setSt_addr2(String st_addr2) {
		this.st_addr2 = st_addr2;
	}
	public String getBd_name() {
		return bd_name;
	}
	public void setBd_name(String bd_name) {
		this.bd_name = bd_name;
	}
	public String getBd_no() {
		return bd_no;
	}
	public void setBd_no(String bd_no) {
		this.bd_no = bd_no;
	}
	public String getZip_eupmyun_name() {
		return zip_eupmyun_name;
	}
	public void setZip_eupmyun_name(String zip_eupmyun_name) {
		this.zip_eupmyun_name = zip_eupmyun_name;
	}
	public String getZipcode() {
		return zipcode;
	}
	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}
	public String getAddress1() {
		return address1;
	}
	public void setAddress1(String address1) {
		this.address1 = address1;
	}
	public String getAddress2() {
		return address2;
	}
	public void setAddress2(String address2) {
		this.address2 = address2;
	}
	public String getAddress3() {
		return address3;
	}
	public void setAddress3(String address3) {
		this.address3 = address3;
	}
	public String getAddress4() {
		return address4;
	}
	public void setAddress4(String address4) {
		this.address4 = address4;
	}
	public String getRadio1() {
		return radio1;
	}
	public void setRadio1(String radio1) {
		this.radio1 = radio1;
	}
	public String getBd_bon_from() {
		return bd_bon_from;
	}
	public void setBd_bon_from(String bd_bon_from) {
		this.bd_bon_from = bd_bon_from;
	}
	public String getBd_bon_to() {
		return bd_bon_to;
	}
	public void setBd_bon_to(String bd_bon_to) {
		this.bd_bon_to = bd_bon_to;
	}
	public String getSingu() {
		return singu;
	}
	public void setSingu(String singu) {
		this.singu = singu;
	}
	public String getHO_H_JUSO() {
		return HO_H_JUSO;
	}
	public void setHO_H_JUSO(String hO_H_JUSO) {
		HO_H_JUSO = hO_H_JUSO;
	}
	public String getHI_H_ADDR() {
		return HI_H_ADDR;
	}
	public void setHI_H_ADDR(String hI_H_ADDR) {
		HI_H_ADDR = hI_H_ADDR;
	}
	public String getHO_J_JUSO() {
		return HO_J_JUSO;
	}
	public void setHO_J_JUSO(String hO_J_JUSO) {
		HO_J_JUSO = hO_J_JUSO;
	}
	public String getHI_J_ADDR() {
		return HI_J_ADDR;
	}
	public void setHI_J_ADDR(String hI_J_ADDR) {
		HI_J_ADDR = hI_J_ADDR;
	}
	public String getHO_G_JUSO() {
		return HO_G_JUSO;
	}
	public void setHO_G_JUSO(String hO_G_JUSO) {
		HO_G_JUSO = hO_G_JUSO;
	}
	public String getHI_G_ADDR() {
		return HI_G_ADDR;
	}
	public void setHI_G_ADDR(String hI_G_ADDR) {
		HI_G_ADDR = hI_G_ADDR;
	}	
}
