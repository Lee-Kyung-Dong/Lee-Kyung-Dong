package com.idongbu.smartcustomer.vo;

import com.idongbu.common.vo.CMMVO;


// 고객정보등록전문
public class CmmFWK0109RVO extends CMMVO {
	public CmmFWK0109RVO() {
		super.setPGMID(this.proid);
		super.setTRID(this.trid);
	}
	public static final String proid		= "FWK0109R";
	public static final String trid		= "WKA9";
	private String rURL						= "";
	
	private String mode = null; // 모드
	
	// 공통
	private String COMM_CHANNEL = null; // 채널유형
	private String COMM_UNIQUE = null; // 	터미널ID
	private String COMM_PROGRAM = null; // 	프로그램ID
	private String COMM_TRANS = null; // 	경로
	private String COMM_ACTION = null; // 	기능키
	private String COMM_USER_GB = null; // 	사용자구분
	private String COMM_USER_ID = null; // 	사용자ID
	private String COMM_JIJUM_CD = null; // 	지점코드
	private String COMM_JIBU_CD = null; // 	지부코드
	private String COMM_PROTOCOL = null; // 	프로토콜
	private String COMM_RETN_CODE = null; // 	상태코드
	private String COMM_LAST_FLAG = null; // 	마지막자료구분
	private String COMM_CUR_FLD = null; // 	현재위치맵
	private String COMM_CUR_POS = null; // 	현재위치값
	private String COMM_MSG_CODE = null; // 	메시지코드
	private String H_COMM_MSG_NAME = null; // 	메시지명
	private String COMM_SYS_ERR = null; // 	시스템메시지
	private String COMM_FIL = null; // 	공백
	
	// I/O
	private String COMM_CHURI_GB = null; // 	처리구분
	private String COMM_V_R_GB = null; // 	V_R구분
	private String COMM_BOJONG_CD = null; // 	보종코드
	private String COMM_SULGYE_NO = null; // 	설계번호
	private String COMM_POLI_NO = null; // 	증권번호 
	private String COMM_BESU_SEQ = null; // 	배서일련번호
	private String COMM_CHUNGYAK_YMD = null; // 	청약일
	private String COMM_BO_GIGAN_SYMD = null; // 	보험시기
	private String COMM_BO_GIGAN_EYMD = null; // 	보험종기
	private String COMM_PIBO_GB = null; // 	피보험자구분
	private String COMM_PIBO_NO = null; // 	피보험자번호
	private String H_COMM_PIBO_NM = null; // 	피보험자명
	private String COMM_PIBO_GOOK_JUK = null; // 	피보험자국적
	private String COMM_PIBO_GWANGE = null; // 	피보험자관계
	private String COMM_PIBO_ZIP = null; // 	우편번호
	private String H_COMM_PIBO_GITA_BUNJI = null; // 	기타번지
	private String COMM_PIBO_ST_ZIP = null; // 	우편번호(신주소)
	private String H_COMM_PIBO_ST_ADDR = null; // 	주소(신주소)
	private String H_COMM_PIBO_ST_GITA = null; // 	기타번지(신주소
	private String H_COMM_PIBO_JIKJANG_NM = null; // 	직장명
	private String H_COMM_PIBO_BUSU_NM = null; // 	부서명
	private String COMM_PIBO_HOME_TEL = null; // 	피보험자전화번호
	private String COMM_PIBO_HP_TEL = null; // 	피보험자휴대번호
	private String COMM_PIBO_OFFICE_TEL = null; // 	피보험자사무실번호
	private String COMM_PIBO_FAX_TEL = null; // 	피보험자팩스번호
	private String COMM_PIBO_EMAIL = null; // 	피보험자이메일
	private String COMM_GUNGANG_SANGTE = null; // 	건강상태
	private String COMM_GING_JANGHE_YN = null; // 	기능장애
	private String COMM_SANGBYUNG_YN = null; // 	상병유무
	private String COMM_YUJUNSUNG_YN = null; // 	유전성질환유무
	private String COMM_JUNGSIN_YN = null; // 	정신질환유뮤
	private String H_COMM_SUIKJA_NM = null; // 	수익자명
	private String COMM_SUIKJA_JUMIN_NO = null; // 	수익자주민번호
	private String COMM_SUIKJA_GWANGE = null; // 	수익자관계
	private String COMM_USONGCHU_GB = null; // 	우송처구분
	private String COMM_USONGCHU_ST_GB  = null; // 	신주소구분
	private String COMM_GEYAK_GB = null; // 	계약자구분
	private String COMM_GEYAK_NO = null; // 	계약자번호
	private String H_COMM_GEYAK_NM = null; // 	계약자명
	private String COMM_GEYAK_ZIP = null; // 	계약자우편번호
	private String COMM_GEYAK_GOOK_JUK = null; // 	계약자국적
	private String H_COMM_GEYAK_GITA_BUNJI = null; // 	계약자기타번지
	private String COMM_GEYAK_ST_ZIP = null; //    	우편번호(신주소)
	private String H_COMM_GEYAK_ST_ADDR = null; // 	주소(신주소)
	private String H_COMM_GEYAK_ST_GITA = null; // 	기타번지(신주소
	private String COMM_GEYAK_HOME_TEL = null; // 	계약자전화번호
	private String COMM_GEYAK_HP_TEL = null; // 	계약자휴대번호
	private String COMM_GEYAK_OFFICE_TEL = null; // 	계약자사무실번호
	private String COMM_GEYAK_FAX_TEL = null; // 	계약자팩스번호
	private String COMM_GEYAK_EMAIL = null; // 	계약자이메일
	private String COMM_GAGYE_GB = null; // 	가계구분
	
	public String getrURL() {
		return rURL;
	}
	public void setrURL(String rURL) {
		this.rURL = rURL;
	}
	public String getMode() {
		return mode;
	}
	public void setMode(String mode) {
		this.mode = mode;
	}
	public String getCOMM_CHANNEL() {
		return COMM_CHANNEL;
	}
	public void setCOMM_CHANNEL(String cOMM_CHANNEL) {
		COMM_CHANNEL = cOMM_CHANNEL;
	}
	public String getCOMM_UNIQUE() {
		return COMM_UNIQUE;
	}
	public void setCOMM_UNIQUE(String cOMM_UNIQUE) {
		COMM_UNIQUE = cOMM_UNIQUE;
	}
	public String getCOMM_PROGRAM() {
		return COMM_PROGRAM;
	}
	public void setCOMM_PROGRAM(String cOMM_PROGRAM) {
		COMM_PROGRAM = cOMM_PROGRAM;
	}
	public String getCOMM_TRANS() {
		return COMM_TRANS;
	}
	public void setCOMM_TRANS(String cOMM_TRANS) {
		COMM_TRANS = cOMM_TRANS;
	}
	public String getCOMM_ACTION() {
		return COMM_ACTION;
	}
	public void setCOMM_ACTION(String cOMM_ACTION) {
		COMM_ACTION = cOMM_ACTION;
	}
	public String getCOMM_USER_GB() {
		return COMM_USER_GB;
	}
	public void setCOMM_USER_GB(String cOMM_USER_GB) {
		COMM_USER_GB = cOMM_USER_GB;
	}
	public String getCOMM_USER_ID() {
		return COMM_USER_ID;
	}
	public void setCOMM_USER_ID(String cOMM_USER_ID) {
		COMM_USER_ID = cOMM_USER_ID;
	}
	public String getCOMM_JIJUM_CD() {
		return COMM_JIJUM_CD;
	}
	public void setCOMM_JIJUM_CD(String cOMM_JIJUM_CD) {
		COMM_JIJUM_CD = cOMM_JIJUM_CD;
	}
	public String getCOMM_JIBU_CD() {
		return COMM_JIBU_CD;
	}
	public void setCOMM_JIBU_CD(String cOMM_JIBU_CD) {
		COMM_JIBU_CD = cOMM_JIBU_CD;
	}
	public String getCOMM_PROTOCOL() {
		return COMM_PROTOCOL;
	}
	public void setCOMM_PROTOCOL(String cOMM_PROTOCOL) {
		COMM_PROTOCOL = cOMM_PROTOCOL;
	}
	public String getCOMM_RETN_CODE() {
		return COMM_RETN_CODE;
	}
	public void setCOMM_RETN_CODE(String cOMM_RETN_CODE) {
		COMM_RETN_CODE = cOMM_RETN_CODE;
	}
	public String getCOMM_LAST_FLAG() {
		return COMM_LAST_FLAG;
	}
	public void setCOMM_LAST_FLAG(String cOMM_LAST_FLAG) {
		COMM_LAST_FLAG = cOMM_LAST_FLAG;
	}
	public String getCOMM_CUR_FLD() {
		return COMM_CUR_FLD;
	}
	public void setCOMM_CUR_FLD(String cOMM_CUR_FLD) {
		COMM_CUR_FLD = cOMM_CUR_FLD;
	}
	public String getCOMM_CUR_POS() {
		return COMM_CUR_POS;
	}
	public void setCOMM_CUR_POS(String cOMM_CUR_POS) {
		COMM_CUR_POS = cOMM_CUR_POS;
	}
	public String getCOMM_MSG_CODE() {
		return COMM_MSG_CODE;
	}
	public void setCOMM_MSG_CODE(String cOMM_MSG_CODE) {
		COMM_MSG_CODE = cOMM_MSG_CODE;
	}
	public String getH_COMM_MSG_NAME() {
		return H_COMM_MSG_NAME;
	}
	public void setH_COMM_MSG_NAME(String h_COMM_MSG_NAME) {
		H_COMM_MSG_NAME = h_COMM_MSG_NAME;
	}
	public String getCOMM_SYS_ERR() {
		return COMM_SYS_ERR;
	}
	public void setCOMM_SYS_ERR(String cOMM_SYS_ERR) {
		COMM_SYS_ERR = cOMM_SYS_ERR;
	}
	public String getCOMM_FIL() {
		return COMM_FIL;
	}
	public void setCOMM_FIL(String cOMM_FIL) {
		COMM_FIL = cOMM_FIL;
	}
	public String getCOMM_CHURI_GB() {
		return COMM_CHURI_GB;
	}
	public void setCOMM_CHURI_GB(String cOMM_CHURI_GB) {
		COMM_CHURI_GB = cOMM_CHURI_GB;
	}
	public String getCOMM_V_R_GB() {
		return COMM_V_R_GB;
	}
	public void setCOMM_V_R_GB(String cOMM_V_R_GB) {
		COMM_V_R_GB = cOMM_V_R_GB;
	}
	public String getCOMM_BOJONG_CD() {
		return COMM_BOJONG_CD;
	}
	public void setCOMM_BOJONG_CD(String cOMM_BOJONG_CD) {
		COMM_BOJONG_CD = cOMM_BOJONG_CD;
	}
	public String getCOMM_SULGYE_NO() {
		return COMM_SULGYE_NO;
	}
	public void setCOMM_SULGYE_NO(String cOMM_SULGYE_NO) {
		COMM_SULGYE_NO = cOMM_SULGYE_NO;
	}
	public String getCOMM_POLI_NO() {
		return COMM_POLI_NO;
	}
	public void setCOMM_POLI_NO(String cOMM_POLI_NO) {
		COMM_POLI_NO = cOMM_POLI_NO;
	}
	public String getCOMM_BESU_SEQ() {
		return COMM_BESU_SEQ;
	}
	public void setCOMM_BESU_SEQ(String cOMM_BESU_SEQ) {
		COMM_BESU_SEQ = cOMM_BESU_SEQ;
	}
	public String getCOMM_CHUNGYAK_YMD() {
		return COMM_CHUNGYAK_YMD;
	}
	public void setCOMM_CHUNGYAK_YMD(String cOMM_CHUNGYAK_YMD) {
		COMM_CHUNGYAK_YMD = cOMM_CHUNGYAK_YMD;
	}
	public String getCOMM_BO_GIGAN_SYMD() {
		return COMM_BO_GIGAN_SYMD;
	}
	public void setCOMM_BO_GIGAN_SYMD(String cOMM_BO_GIGAN_SYMD) {
		COMM_BO_GIGAN_SYMD = cOMM_BO_GIGAN_SYMD;
	}
	public String getCOMM_BO_GIGAN_EYMD() {
		return COMM_BO_GIGAN_EYMD;
	}
	public void setCOMM_BO_GIGAN_EYMD(String cOMM_BO_GIGAN_EYMD) {
		COMM_BO_GIGAN_EYMD = cOMM_BO_GIGAN_EYMD;
	}
	public String getCOMM_PIBO_GB() {
		return COMM_PIBO_GB;
	}
	public void setCOMM_PIBO_GB(String cOMM_PIBO_GB) {
		COMM_PIBO_GB = cOMM_PIBO_GB;
	}
	public String getCOMM_PIBO_NO() {
		return COMM_PIBO_NO;
	}
	public void setCOMM_PIBO_NO(String cOMM_PIBO_NO) {
		COMM_PIBO_NO = cOMM_PIBO_NO;
	}
	public String getH_COMM_PIBO_NM() {
		return H_COMM_PIBO_NM;
	}
	public void setH_COMM_PIBO_NM(String h_COMM_PIBO_NM) {
		H_COMM_PIBO_NM = h_COMM_PIBO_NM;
	}
	public String getCOMM_PIBO_GOOK_JUK() {
		return COMM_PIBO_GOOK_JUK;
	}
	public void setCOMM_PIBO_GOOK_JUK(String cOMM_PIBO_GOOK_JUK) {
		COMM_PIBO_GOOK_JUK = cOMM_PIBO_GOOK_JUK;
	}
	public String getCOMM_PIBO_GWANGE() {
		return COMM_PIBO_GWANGE;
	}
	public void setCOMM_PIBO_GWANGE(String cOMM_PIBO_GWANGE) {
		COMM_PIBO_GWANGE = cOMM_PIBO_GWANGE;
	}
	public String getCOMM_PIBO_ZIP() {
		return COMM_PIBO_ZIP;
	}
	public void setCOMM_PIBO_ZIP(String cOMM_PIBO_ZIP) {
		COMM_PIBO_ZIP = cOMM_PIBO_ZIP;
	}
	public String getH_COMM_PIBO_GITA_BUNJI() {
		return H_COMM_PIBO_GITA_BUNJI;
	}
	public void setH_COMM_PIBO_GITA_BUNJI(String h_COMM_PIBO_GITA_BUNJI) {
		H_COMM_PIBO_GITA_BUNJI = h_COMM_PIBO_GITA_BUNJI;
	}
	public String getCOMM_PIBO_ST_ZIP() {
		return COMM_PIBO_ST_ZIP;
	}
	public void setCOMM_PIBO_ST_ZIP(String cOMM_PIBO_ST_ZIP) {
		COMM_PIBO_ST_ZIP = cOMM_PIBO_ST_ZIP;
	}
	public String getH_COMM_PIBO_ST_ADDR() {
		return H_COMM_PIBO_ST_ADDR;
	}
	public void setH_COMM_PIBO_ST_ADDR(String h_COMM_PIBO_ST_ADDR) {
		H_COMM_PIBO_ST_ADDR = h_COMM_PIBO_ST_ADDR;
	}
	public String getH_COMM_PIBO_ST_GITA() {
		return H_COMM_PIBO_ST_GITA;
	}
	public void setH_COMM_PIBO_ST_GITA(String h_COMM_PIBO_ST_GITA) {
		H_COMM_PIBO_ST_GITA = h_COMM_PIBO_ST_GITA;
	}
	public String getH_COMM_PIBO_JIKJANG_NM() {
		return H_COMM_PIBO_JIKJANG_NM;
	}
	public void setH_COMM_PIBO_JIKJANG_NM(String h_COMM_PIBO_JIKJANG_NM) {
		H_COMM_PIBO_JIKJANG_NM = h_COMM_PIBO_JIKJANG_NM;
	}
	public String getH_COMM_PIBO_BUSU_NM() {
		return H_COMM_PIBO_BUSU_NM;
	}
	public void setH_COMM_PIBO_BUSU_NM(String h_COMM_PIBO_BUSU_NM) {
		H_COMM_PIBO_BUSU_NM = h_COMM_PIBO_BUSU_NM;
	}
	public String getCOMM_PIBO_HOME_TEL() {
		return COMM_PIBO_HOME_TEL;
	}
	public void setCOMM_PIBO_HOME_TEL(String cOMM_PIBO_HOME_TEL) {
		COMM_PIBO_HOME_TEL = cOMM_PIBO_HOME_TEL;
	}
	public String getCOMM_PIBO_HP_TEL() {
		return COMM_PIBO_HP_TEL;
	}
	public void setCOMM_PIBO_HP_TEL(String cOMM_PIBO_HP_TEL) {
		COMM_PIBO_HP_TEL = cOMM_PIBO_HP_TEL;
	}
	public String getCOMM_PIBO_OFFICE_TEL() {
		return COMM_PIBO_OFFICE_TEL;
	}
	public void setCOMM_PIBO_OFFICE_TEL(String cOMM_PIBO_OFFICE_TEL) {
		COMM_PIBO_OFFICE_TEL = cOMM_PIBO_OFFICE_TEL;
	}
	public String getCOMM_PIBO_FAX_TEL() {
		return COMM_PIBO_FAX_TEL;
	}
	public void setCOMM_PIBO_FAX_TEL(String cOMM_PIBO_FAX_TEL) {
		COMM_PIBO_FAX_TEL = cOMM_PIBO_FAX_TEL;
	}
	public String getCOMM_PIBO_EMAIL() {
		return COMM_PIBO_EMAIL;
	}
	public void setCOMM_PIBO_EMAIL(String cOMM_PIBO_EMAIL) {
		COMM_PIBO_EMAIL = cOMM_PIBO_EMAIL;
	}
	public String getCOMM_GUNGANG_SANGTE() {
		return COMM_GUNGANG_SANGTE;
	}
	public void setCOMM_GUNGANG_SANGTE(String cOMM_GUNGANG_SANGTE) {
		COMM_GUNGANG_SANGTE = cOMM_GUNGANG_SANGTE;
	}
	public String getCOMM_GING_JANGHE_YN() {
		return COMM_GING_JANGHE_YN;
	}
	public void setCOMM_GING_JANGHE_YN(String cOMM_GING_JANGHE_YN) {
		COMM_GING_JANGHE_YN = cOMM_GING_JANGHE_YN;
	}
	public String getCOMM_SANGBYUNG_YN() {
		return COMM_SANGBYUNG_YN;
	}
	public void setCOMM_SANGBYUNG_YN(String cOMM_SANGBYUNG_YN) {
		COMM_SANGBYUNG_YN = cOMM_SANGBYUNG_YN;
	}
	public String getCOMM_YUJUNSUNG_YN() {
		return COMM_YUJUNSUNG_YN;
	}
	public void setCOMM_YUJUNSUNG_YN(String cOMM_YUJUNSUNG_YN) {
		COMM_YUJUNSUNG_YN = cOMM_YUJUNSUNG_YN;
	}
	public String getCOMM_JUNGSIN_YN() {
		return COMM_JUNGSIN_YN;
	}
	public void setCOMM_JUNGSIN_YN(String cOMM_JUNGSIN_YN) {
		COMM_JUNGSIN_YN = cOMM_JUNGSIN_YN;
	}
	public String getH_COMM_SUIKJA_NM() {
		return H_COMM_SUIKJA_NM;
	}
	public void setH_COMM_SUIKJA_NM(String h_COMM_SUIKJA_NM) {
		H_COMM_SUIKJA_NM = h_COMM_SUIKJA_NM;
	}
	public String getCOMM_SUIKJA_JUMIN_NO() {
		return COMM_SUIKJA_JUMIN_NO;
	}
	public void setCOMM_SUIKJA_JUMIN_NO(String cOMM_SUIKJA_JUMIN_NO) {
		COMM_SUIKJA_JUMIN_NO = cOMM_SUIKJA_JUMIN_NO;
	}
	public String getCOMM_SUIKJA_GWANGE() {
		return COMM_SUIKJA_GWANGE;
	}
	public void setCOMM_SUIKJA_GWANGE(String cOMM_SUIKJA_GWANGE) {
		COMM_SUIKJA_GWANGE = cOMM_SUIKJA_GWANGE;
	}
	public String getCOMM_USONGCHU_GB() {
		return COMM_USONGCHU_GB;
	}
	public void setCOMM_USONGCHU_GB(String cOMM_USONGCHU_GB) {
		COMM_USONGCHU_GB = cOMM_USONGCHU_GB;
	}
	public String getCOMM_USONGCHU_ST_GB() {
		return COMM_USONGCHU_ST_GB;
	}
	public void setCOMM_USONGCHU_ST_GB(String cOMM_USONGCHU_ST_GB) {
		COMM_USONGCHU_ST_GB = cOMM_USONGCHU_ST_GB;
	}
	public String getCOMM_GEYAK_GB() {
		return COMM_GEYAK_GB;
	}
	public void setCOMM_GEYAK_GB(String cOMM_GEYAK_GB) {
		COMM_GEYAK_GB = cOMM_GEYAK_GB;
	}
	public String getCOMM_GEYAK_NO() {
		return COMM_GEYAK_NO;
	}
	public void setCOMM_GEYAK_NO(String cOMM_GEYAK_NO) {
		COMM_GEYAK_NO = cOMM_GEYAK_NO;
	}
	public String getH_COMM_GEYAK_NM() {
		return H_COMM_GEYAK_NM;
	}
	public void setH_COMM_GEYAK_NM(String h_COMM_GEYAK_NM) {
		H_COMM_GEYAK_NM = h_COMM_GEYAK_NM;
	}
	public String getCOMM_GEYAK_ZIP() {
		return COMM_GEYAK_ZIP;
	}
	public void setCOMM_GEYAK_ZIP(String cOMM_GEYAK_ZIP) {
		COMM_GEYAK_ZIP = cOMM_GEYAK_ZIP;
	}
	public String getCOMM_GEYAK_GOOK_JUK() {
		return COMM_GEYAK_GOOK_JUK;
	}
	public void setCOMM_GEYAK_GOOK_JUK(String cOMM_GEYAK_GOOK_JUK) {
		COMM_GEYAK_GOOK_JUK = cOMM_GEYAK_GOOK_JUK;
	}
	public String getH_COMM_GEYAK_GITA_BUNJI() {
		return H_COMM_GEYAK_GITA_BUNJI;
	}
	public void setH_COMM_GEYAK_GITA_BUNJI(String h_COMM_GEYAK_GITA_BUNJI) {
		H_COMM_GEYAK_GITA_BUNJI = h_COMM_GEYAK_GITA_BUNJI;
	}
	public String getCOMM_GEYAK_ST_ZIP() {
		return COMM_GEYAK_ST_ZIP;
	}
	public void setCOMM_GEYAK_ST_ZIP(String cOMM_GEYAK_ST_ZIP) {
		COMM_GEYAK_ST_ZIP = cOMM_GEYAK_ST_ZIP;
	}
	public String getH_COMM_GEYAK_ST_ADDR() {
		return H_COMM_GEYAK_ST_ADDR;
	}
	public void setH_COMM_GEYAK_ST_ADDR(String h_COMM_GEYAK_ST_ADDR) {
		H_COMM_GEYAK_ST_ADDR = h_COMM_GEYAK_ST_ADDR;
	}
	public String getH_COMM_GEYAK_ST_GITA() {
		return H_COMM_GEYAK_ST_GITA;
	}
	public void setH_COMM_GEYAK_ST_GITA(String h_COMM_GEYAK_ST_GITA) {
		H_COMM_GEYAK_ST_GITA = h_COMM_GEYAK_ST_GITA;
	}
	public String getCOMM_GEYAK_HOME_TEL() {
		return COMM_GEYAK_HOME_TEL;
	}
	public void setCOMM_GEYAK_HOME_TEL(String cOMM_GEYAK_HOME_TEL) {
		COMM_GEYAK_HOME_TEL = cOMM_GEYAK_HOME_TEL;
	}
	public String getCOMM_GEYAK_HP_TEL() {
		return COMM_GEYAK_HP_TEL;
	}
	public void setCOMM_GEYAK_HP_TEL(String cOMM_GEYAK_HP_TEL) {
		COMM_GEYAK_HP_TEL = cOMM_GEYAK_HP_TEL;
	}
	public String getCOMM_GEYAK_OFFICE_TEL() {
		return COMM_GEYAK_OFFICE_TEL;
	}
	public void setCOMM_GEYAK_OFFICE_TEL(String cOMM_GEYAK_OFFICE_TEL) {
		COMM_GEYAK_OFFICE_TEL = cOMM_GEYAK_OFFICE_TEL;
	}
	public String getCOMM_GEYAK_FAX_TEL() {
		return COMM_GEYAK_FAX_TEL;
	}
	public void setCOMM_GEYAK_FAX_TEL(String cOMM_GEYAK_FAX_TEL) {
		COMM_GEYAK_FAX_TEL = cOMM_GEYAK_FAX_TEL;
	}
	public String getCOMM_GEYAK_EMAIL() {
		return COMM_GEYAK_EMAIL;
	}
	public void setCOMM_GEYAK_EMAIL(String cOMM_GEYAK_EMAIL) {
		COMM_GEYAK_EMAIL = cOMM_GEYAK_EMAIL;
	}
	public String getCOMM_GAGYE_GB() {
		return COMM_GAGYE_GB;
	}
	public void setCOMM_GAGYE_GB(String cOMM_GAGYE_GB) {
		COMM_GAGYE_GB = cOMM_GAGYE_GB;
	}

}
