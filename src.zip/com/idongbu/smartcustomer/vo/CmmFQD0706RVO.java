package com.idongbu.smartcustomer.vo;

import com.idongbu.common.vo.CMMVO;

// 자동차 계약 - 자동차보험 주행거리 입력
public class CmmFQD0706RVO extends CMMVO {
	
	public CmmFQD0706RVO() {
		super.setPGMID(this.proid);
		super.setTRID(this.trid);
	}		
	
	private static final String proid  = "FQD0706R";
	private static final String trid   = "QDJM";
	private String rURL				   = "";
                                       
	private String COMM_CHANNEL        = ""; // 채널구분
	private String COMM_UNIQUE         = ""; // TSQ,VSAM FILE용 UNIQUE
	private String COMM_PGMID          = ""; // PROGRAM-ID
	private String COMM_PROC_GB        = ""; // 처리구분
	private String COMM_FUN_KEY        = ""; // 기능키
	private String COMM_USER_GB        = ""; // 사용자구분
	private String COMM_USER_CD        = ""; // 사용자ID
	private String COMM_JIJUM_CD       = ""; // 사용자지점
	private String COMM_JIBU_CD        = ""; // 사용자지부
	private String COMM_PROTOCOL       = ""; // 전문사용구분
	private String COMM_COND_CD        = ""; // 처리결과
	private String COMM_LAST_FLAG      = ""; // 마지막자료여부
	private String COMM_CURSOR_MAP     = ""; // CURSOR POINT - MAP
	private String COMM_CURSOR_IDX     = ""; // CURSOR POINT - FIELD INDEX
	private String COMM_MESSAGE_CD     = ""; // 화면 출력 MESSAGE - CODE
	private String H_COMM_MESSAGE_NM   = ""; // 화면 출력 MESSAGE
	private String COMM_SYS_ERR        = ""; // 시스템 MESSAGE
	private String COMM_FILLER         = ""; // 여분
	
	private String SCR_SASEOHAM_INFO   = ""; // 사서함정보
	private String SCR_SASEOHAM_GB     = ""; // 사서함 사용유무 (사서함 사용시 '1')
	private String SCR_CHABUN_NO       = ""; // SMS 전송용 채번 ( 사서함을 통한 INPUT일 경우에만 입력 )
	private String SCR_DRIVE_SAJIN_YMD = ""; // 사진확인일 ( 사서함을 통한 INPUT일 경우에만 입력 )
	private String SCR_DRIVE_SAJIN_GB  = ""; // 사진유무 ( 사서함을 통한 INPUT일 경우에만 입력 )
	private String SCR_DRIVE_HP        = ""; // 사서함문자 발송자 ( 사서함을 통한 INPUT일 경우에만 입력 )
	private String SCR_DRIVE_TEXT      = ""; // 사서함문자 ( 사서함을 통한 INPUT일 경우에만 입력 )
	private String SCR_UPMU_GB         = ""; // 업무구분
	private String SCR_PROCESS_GB      = ""; // 처리구분
	private String SCR_SULGYE_NO       = ""; // 설계번호
	private String SCR_POLI_NO         = ""; // 증권번호
	private String SCR_BESU_SULGYE_NO  = ""; // 배서설계번호
	private String SCR_DRIVE_YMD       = ""; // 주행거리확인일
	private String SCR_DRIVE_KM        = ""; // 주행거리 
	private String SCR_HWAKINJA_INFO   = ""; // 주행거리확인자 정보
	private String H_SCR_W_SOSOK       = ""; // 주행거리확인자소속
	private String H_SCR_W_NAME        = ""; // 주행거리확인자성명
	private String SCR_W_SABUN         = ""; // 주행거리확인자사번
	private String H_SCR_W_JIKCHEK     = ""; // 주행거리확인자직책
	private String SCR_W_OFFICE_TEL    = ""; // 주행거리확인자사무실
	private String SCR_W_HP_TEL        = ""; // 주행거리확인자핸드폰
	private String SCR_W_FAX           = ""; // 주행거리확인자팩스
	private String SCR_JUPSU_NO        = ""; // 접수번호
	private String SCR_SAJIN_AGREE_GB  = ""; // 사진동의구분 ( '1' = 사진정보 수집 및 이용에 관한 동의(고객용앱 만기정산시 사용) )
	
	public String getrURL() {
		return rURL;
	}
	public void setrURL(String rURL) {
		this.rURL = rURL;
	}
	public String getCOMM_CHANNEL() {
		return COMM_CHANNEL;
	}
	public void setCOMM_CHANNEL(String cOMM_CHANNEL) {
		COMM_CHANNEL = cOMM_CHANNEL;
	}
	public String getCOMM_UNIQUE() {
		return COMM_UNIQUE;
	}
	public void setCOMM_UNIQUE(String cOMM_UNIQUE) {
		COMM_UNIQUE = cOMM_UNIQUE;
	}
	public String getCOMM_PGMID() {
		return COMM_PGMID;
	}
	public void setCOMM_PGMID(String cOMM_PGMID) {
		COMM_PGMID = cOMM_PGMID;
	}
	public String getCOMM_PROC_GB() {
		return COMM_PROC_GB;
	}
	public void setCOMM_PROC_GB(String cOMM_PROC_GB) {
		COMM_PROC_GB = cOMM_PROC_GB;
	}
	public String getCOMM_FUN_KEY() {
		return COMM_FUN_KEY;
	}
	public void setCOMM_FUN_KEY(String cOMM_FUN_KEY) {
		COMM_FUN_KEY = cOMM_FUN_KEY;
	}
	public String getCOMM_USER_GB() {
		return COMM_USER_GB;
	}
	public void setCOMM_USER_GB(String cOMM_USER_GB) {
		COMM_USER_GB = cOMM_USER_GB;
	}
	public String getCOMM_USER_CD() {
		return COMM_USER_CD;
	}
	public void setCOMM_USER_CD(String cOMM_USER_CD) {
		COMM_USER_CD = cOMM_USER_CD;
	}
	public String getCOMM_JIJUM_CD() {
		return COMM_JIJUM_CD;
	}
	public void setCOMM_JIJUM_CD(String cOMM_JIJUM_CD) {
		COMM_JIJUM_CD = cOMM_JIJUM_CD;
	}
	public String getCOMM_JIBU_CD() {
		return COMM_JIBU_CD;
	}
	public void setCOMM_JIBU_CD(String cOMM_JIBU_CD) {
		COMM_JIBU_CD = cOMM_JIBU_CD;
	}
	public String getCOMM_PROTOCOL() {
		return COMM_PROTOCOL;
	}
	public void setCOMM_PROTOCOL(String cOMM_PROTOCOL) {
		COMM_PROTOCOL = cOMM_PROTOCOL;
	}
	public String getCOMM_COND_CD() {
		return COMM_COND_CD;
	}
	public void setCOMM_COND_CD(String cOMM_COND_CD) {
		COMM_COND_CD = cOMM_COND_CD;
	}
	public String getCOMM_LAST_FLAG() {
		return COMM_LAST_FLAG;
	}
	public void setCOMM_LAST_FLAG(String cOMM_LAST_FLAG) {
		COMM_LAST_FLAG = cOMM_LAST_FLAG;
	}
	public String getCOMM_CURSOR_MAP() {
		return COMM_CURSOR_MAP;
	}
	public void setCOMM_CURSOR_MAP(String cOMM_CURSOR_MAP) {
		COMM_CURSOR_MAP = cOMM_CURSOR_MAP;
	}
	public String getCOMM_CURSOR_IDX() {
		return COMM_CURSOR_IDX;
	}
	public void setCOMM_CURSOR_IDX(String cOMM_CURSOR_IDX) {
		COMM_CURSOR_IDX = cOMM_CURSOR_IDX;
	}
	public String getCOMM_MESSAGE_CD() {
		return COMM_MESSAGE_CD;
	}
	public void setCOMM_MESSAGE_CD(String cOMM_MESSAGE_CD) {
		COMM_MESSAGE_CD = cOMM_MESSAGE_CD;
	}
	public String getH_COMM_MESSAGE_NM() {
		return H_COMM_MESSAGE_NM;
	}
	public void setH_COMM_MESSAGE_NM(String h_COMM_MESSAGE_NM) {
		H_COMM_MESSAGE_NM = h_COMM_MESSAGE_NM;
	}
	public String getCOMM_SYS_ERR() {
		return COMM_SYS_ERR;
	}
	public void setCOMM_SYS_ERR(String cOMM_SYS_ERR) {
		COMM_SYS_ERR = cOMM_SYS_ERR;
	}
	public String getCOMM_FILLER() {
		return COMM_FILLER;
	}
	public void setCOMM_FILLER(String cOMM_FILLER) {
		COMM_FILLER = cOMM_FILLER;
	}
	public String getSCR_SASEOHAM_INFO() {
		return SCR_SASEOHAM_INFO;
	}
	public void setSCR_SASEOHAM_INFO(String sCR_SASEOHAM_INFO) {
		SCR_SASEOHAM_INFO = sCR_SASEOHAM_INFO;
	}
	public String getSCR_SASEOHAM_GB() {
		return SCR_SASEOHAM_GB;
	}
	public void setSCR_SASEOHAM_GB(String sCR_SASEOHAM_GB) {
		SCR_SASEOHAM_GB = sCR_SASEOHAM_GB;
	}
	public String getSCR_CHABUN_NO() {
		return SCR_CHABUN_NO;
	}
	public void setSCR_CHABUN_NO(String sCR_CHABUN_NO) {
		SCR_CHABUN_NO = sCR_CHABUN_NO;
	}
	public String getSCR_DRIVE_SAJIN_YMD() {
		return SCR_DRIVE_SAJIN_YMD;
	}
	public void setSCR_DRIVE_SAJIN_YMD(String sCR_DRIVE_SAJIN_YMD) {
		SCR_DRIVE_SAJIN_YMD = sCR_DRIVE_SAJIN_YMD;
	}
	public String getSCR_DRIVE_SAJIN_GB() {
		return SCR_DRIVE_SAJIN_GB;
	}
	public void setSCR_DRIVE_SAJIN_GB(String sCR_DRIVE_SAJIN_GB) {
		SCR_DRIVE_SAJIN_GB = sCR_DRIVE_SAJIN_GB;
	}
	public String getSCR_DRIVE_HP() {
		return SCR_DRIVE_HP;
	}
	public void setSCR_DRIVE_HP(String sCR_DRIVE_HP) {
		SCR_DRIVE_HP = sCR_DRIVE_HP;
	}
	public String getSCR_DRIVE_TEXT() {
		return SCR_DRIVE_TEXT;
	}
	public void setSCR_DRIVE_TEXT(String sCR_DRIVE_TEXT) {
		SCR_DRIVE_TEXT = sCR_DRIVE_TEXT;
	}
	public String getSCR_UPMU_GB() {
		return SCR_UPMU_GB;
	}
	public void setSCR_UPMU_GB(String sCR_UPMU_GB) {
		SCR_UPMU_GB = sCR_UPMU_GB;
	}
	public String getSCR_PROCESS_GB() {
		return SCR_PROCESS_GB;
	}
	public void setSCR_PROCESS_GB(String sCR_PROCESS_GB) {
		SCR_PROCESS_GB = sCR_PROCESS_GB;
	}
	public String getSCR_SULGYE_NO() {
		return SCR_SULGYE_NO;
	}
	public void setSCR_SULGYE_NO(String sCR_SULGYE_NO) {
		SCR_SULGYE_NO = sCR_SULGYE_NO;
	}
	public String getSCR_POLI_NO() {
		return SCR_POLI_NO;
	}
	public void setSCR_POLI_NO(String sCR_POLI_NO) {
		SCR_POLI_NO = sCR_POLI_NO;
	}
	public String getSCR_BESU_SULGYE_NO() {
		return SCR_BESU_SULGYE_NO;
	}
	public void setSCR_BESU_SULGYE_NO(String sCR_BESU_SULGYE_NO) {
		SCR_BESU_SULGYE_NO = sCR_BESU_SULGYE_NO;
	}
	public String getSCR_DRIVE_YMD() {
		return SCR_DRIVE_YMD;
	}
	public void setSCR_DRIVE_YMD(String sCR_DRIVE_YMD) {
		SCR_DRIVE_YMD = sCR_DRIVE_YMD;
	}
	public String getSCR_DRIVE_KM() {
		return SCR_DRIVE_KM;
	}
	public void setSCR_DRIVE_KM(String sCR_DRIVE_KM) {
		SCR_DRIVE_KM = sCR_DRIVE_KM;
	}
	public String getSCR_HWAKINJA_INFO() {
		return SCR_HWAKINJA_INFO;
	}
	public void setSCR_HWAKINJA_INFO(String sCR_HWAKINJA_INFO) {
		SCR_HWAKINJA_INFO = sCR_HWAKINJA_INFO;
	}
	public String getH_SCR_W_SOSOK() {
		return H_SCR_W_SOSOK;
	}
	public void setH_SCR_W_SOSOK(String h_SCR_W_SOSOK) {
		H_SCR_W_SOSOK = h_SCR_W_SOSOK;
	}
	public String getH_SCR_W_NAME() {
		return H_SCR_W_NAME;
	}
	public void setH_SCR_W_NAME(String h_SCR_W_NAME) {
		H_SCR_W_NAME = h_SCR_W_NAME;
	}
	public String getSCR_W_SABUN() {
		return SCR_W_SABUN;
	}
	public void setSCR_W_SABUN(String sCR_W_SABUN) {
		SCR_W_SABUN = sCR_W_SABUN;
	}
	public String getH_SCR_W_JIKCHEK() {
		return H_SCR_W_JIKCHEK;
	}
	public void setH_SCR_W_JIKCHEK(String h_SCR_W_JIKCHEK) {
		H_SCR_W_JIKCHEK = h_SCR_W_JIKCHEK;
	}
	public String getSCR_W_OFFICE_TEL() {
		return SCR_W_OFFICE_TEL;
	}
	public void setSCR_W_OFFICE_TEL(String sCR_W_OFFICE_TEL) {
		SCR_W_OFFICE_TEL = sCR_W_OFFICE_TEL;
	}
	public String getSCR_W_HP_TEL() {
		return SCR_W_HP_TEL;
	}
	public void setSCR_W_HP_TEL(String sCR_W_HP_TEL) {
		SCR_W_HP_TEL = sCR_W_HP_TEL;
	}
	public String getSCR_W_FAX() {
		return SCR_W_FAX;
	}
	public void setSCR_W_FAX(String sCR_W_FAX) {
		SCR_W_FAX = sCR_W_FAX;
	}
	public String getSCR_JUPSU_NO() {
		return SCR_JUPSU_NO;
	}
	public void setSCR_JUPSU_NO(String sCR_JUPSU_NO) {
		SCR_JUPSU_NO = sCR_JUPSU_NO;
	}
	public String getSCR_SAJIN_AGREE_GB() {
		return SCR_SAJIN_AGREE_GB;
	}
	public void setSCR_SAJIN_AGREE_GB(String sCR_SAJIN_AGREE_GB) {
		SCR_SAJIN_AGREE_GB = sCR_SAJIN_AGREE_GB;
	}
	public static String getProid() {
		return proid;
	}
	public static String getTrid() {
		return trid;
	}	
}
