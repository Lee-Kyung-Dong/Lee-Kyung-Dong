package com.idongbu.smartcustomer.vo;


//장기보험료납입조회
public class SubFUA6020RVO  {

	
	private String JJ_POLI_NO = null; // 10
	private String JJ_BJ_CD = null; // 10
	private String HJ_BJ_NM = null; // 10
	private String JJ_GIGAN_SYMD = null; // 10
	private String JJ_GIGAN_EYMD = null; // 10
	private String JJ_GIGAN_CD = null; // 10
	private String HJ_GIGAN_NM = null; // 10
	private String JJ_LAST_NAPIP_YM = null; // 10
	private String JJ_LAST_NAPIP_CNT = null; // 10
	private String JJ_NAPBANG_CD = null; // 10
	private String HJ_NAPBANG_NM = null; // 10
	private String JJ_SANGTE_CD = null; // 10
	private String HJ_GYE_SANGTE = null; // 10
	private String JJ_GYEJWA_NO = null; // 10
	private String JJ_YEGMJU_JUMINNO = null; // 10
	private String HJ_YEGMJU_NAME = null; // 10
	private String JJ_ICHE_GWANCD = null; // 10
	private String JJ_BANK_CD = null; // 10
	private String HJ_BANK_NAME = null; // 10
	private String HJ_SUGUMJA_NAME = null; // 10	//수금조직원
	private String JJ_SUGUMJA_CD = null; // 10	//수금조직원코드
	private String JJ_SINCHERNG_RST = null; // 10
	private String JJ_SUGUM_JIJUM_CD = null; // 10	//수금지점코드
	private String JJ_SUGUM_JIBU_CD = null; // 10		//수금지부코드
	
	
	
	public String getJJ_POLI_NO() {
		return JJ_POLI_NO;
	}
	public void setJJ_POLI_NO(String jJ_POLI_NO) {
		JJ_POLI_NO = jJ_POLI_NO;
	}
	public String getJJ_BJ_CD() {
		return JJ_BJ_CD;
	}
	public void setJJ_BJ_CD(String jJ_BJ_CD) {
		JJ_BJ_CD = jJ_BJ_CD;
	}
	public String getHJ_BJ_NM() {
		return HJ_BJ_NM;
	}
	public void setHJ_BJ_NM(String hJ_BJ_NM) {
		HJ_BJ_NM = hJ_BJ_NM;
	}
	public String getJJ_GIGAN_SYMD() {
		return JJ_GIGAN_SYMD;
	}
	public void setJJ_GIGAN_SYMD(String jJ_GIGAN_SYMD) {
		JJ_GIGAN_SYMD = jJ_GIGAN_SYMD;
	}
	public String getJJ_GIGAN_EYMD() {
		return JJ_GIGAN_EYMD;
	}
	public void setJJ_GIGAN_EYMD(String jJ_GIGAN_EYMD) {
		JJ_GIGAN_EYMD = jJ_GIGAN_EYMD;
	}
	public String getJJ_GIGAN_CD() {
		return JJ_GIGAN_CD;
	}
	public void setJJ_GIGAN_CD(String jJ_GIGAN_CD) {
		JJ_GIGAN_CD = jJ_GIGAN_CD;
	}
	public String getHJ_GIGAN_NM() {
		return HJ_GIGAN_NM;
	}
	public void setHJ_GIGAN_NM(String hJ_GIGAN_NM) {
		HJ_GIGAN_NM = hJ_GIGAN_NM;
	}
	public String getJJ_LAST_NAPIP_YM() {
		return JJ_LAST_NAPIP_YM;
	}
	public void setJJ_LAST_NAPIP_YM(String jJ_LAST_NAPIP_YM) {
		JJ_LAST_NAPIP_YM = jJ_LAST_NAPIP_YM;
	}
	public String getJJ_LAST_NAPIP_CNT() {
		return JJ_LAST_NAPIP_CNT;
	}
	public void setJJ_LAST_NAPIP_CNT(String jJ_LAST_NAPIP_CNT) {
		JJ_LAST_NAPIP_CNT = jJ_LAST_NAPIP_CNT;
	}
	public String getJJ_NAPBANG_CD() {
		return JJ_NAPBANG_CD;
	}
	public void setJJ_NAPBANG_CD(String jJ_NAPBANG_CD) {
		JJ_NAPBANG_CD = jJ_NAPBANG_CD;
	}
	public String getHJ_NAPBANG_NM() {
		return HJ_NAPBANG_NM;
	}
	public void setHJ_NAPBANG_NM(String hJ_NAPBANG_NM) {
		HJ_NAPBANG_NM = hJ_NAPBANG_NM;
	}
	public String getJJ_SANGTE_CD() {
		return JJ_SANGTE_CD;
	}
	public void setJJ_SANGTE_CD(String jJ_SANGTE_CD) {
		JJ_SANGTE_CD = jJ_SANGTE_CD;
	}
	public String getHJ_GYE_SANGTE() {
		return HJ_GYE_SANGTE;
	}
	public void setHJ_GYE_SANGTE(String hJ_GYE_SANGTE) {
		HJ_GYE_SANGTE = hJ_GYE_SANGTE;
	}
	public String getJJ_GYEJWA_NO() {
		return JJ_GYEJWA_NO;
	}
	public void setJJ_GYEJWA_NO(String jJ_GYEJWA_NO) {
		JJ_GYEJWA_NO = jJ_GYEJWA_NO;
	}
	public String getJJ_YEGMJU_JUMINNO() {
		return JJ_YEGMJU_JUMINNO;
	}
	public void setJJ_YEGMJU_JUMINNO(String jJ_YEGMJU_JUMINNO) {
		JJ_YEGMJU_JUMINNO = jJ_YEGMJU_JUMINNO;
	}
	public String getHJ_YEGMJU_NAME() {
		return HJ_YEGMJU_NAME;
	}
	public void setHJ_YEGMJU_NAME(String hJ_YEGMJU_NAME) {
		HJ_YEGMJU_NAME = hJ_YEGMJU_NAME;
	}
	public String getJJ_ICHE_GWANCD() {
		return JJ_ICHE_GWANCD;
	}
	public void setJJ_ICHE_GWANCD(String jJ_ICHE_GWANCD) {
		JJ_ICHE_GWANCD = jJ_ICHE_GWANCD;
	}
	public String getJJ_BANK_CD() {
		return JJ_BANK_CD;
	}
	public void setJJ_BANK_CD(String jJ_BANK_CD) {
		JJ_BANK_CD = jJ_BANK_CD;
	}
	public String getHJ_BANK_NAME() {
		return HJ_BANK_NAME;
	}
	public void setHJ_BANK_NAME(String hJ_BANK_NAME) {
		HJ_BANK_NAME = hJ_BANK_NAME;
	}
	public String getHJ_SUGUMJA_NAME() {
		return HJ_SUGUMJA_NAME;
	}
	public void setHJ_SUGUMJA_NAME(String hJ_SUGUMJA_NAME) {
		HJ_SUGUMJA_NAME = hJ_SUGUMJA_NAME;
	}
	public String getJJ_SUGUMJA_CD() {
		return JJ_SUGUMJA_CD;
	}
	public void setJJ_SUGUMJA_CD(String jJ_SUGUMJA_CD) {
		JJ_SUGUMJA_CD = jJ_SUGUMJA_CD;
	}
	public String getJJ_SINCHERNG_RST() {
		return JJ_SINCHERNG_RST;
	}
	public void setJJ_SINCHERNG_RST(String jJ_SINCHERNG_RST) {
		JJ_SINCHERNG_RST = jJ_SINCHERNG_RST;
	}
	public String getJJ_SUGUM_JIJUM_CD() {
		return JJ_SUGUM_JIJUM_CD;
	}
	public void setJJ_SUGUM_JIJUM_CD(String jJ_SUGUM_JIJUM_CD) {
		JJ_SUGUM_JIJUM_CD = jJ_SUGUM_JIJUM_CD;
	}
	public String getJJ_SUGUM_JIBU_CD() {
		return JJ_SUGUM_JIBU_CD;
	}
	public void setJJ_SUGUM_JIBU_CD(String jJ_SUGUM_JIBU_CD) {
		JJ_SUGUM_JIBU_CD = jJ_SUGUM_JIBU_CD;
	}
	

	



}
