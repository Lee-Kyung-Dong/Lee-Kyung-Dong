package com.idongbu.smartcustomer.vo;


//장기보험료납입(가상계좌)
public class SubFUC3266RVO  {



	public String HJ_ITEM_GUBUN;
	public String JJ_HOICHA;
	public String JJ_NAPIP_WOLDO;
	public String JJ_BATUL_GMEK;
	public String JJ_JUNGSANG_PRM;
	public String JJ_SUNNAP_HALIN;
	
	
	public String getHJ_ITEM_GUBUN() {
		return HJ_ITEM_GUBUN;
	}
	public void setHJ_ITEM_GUBUN(String hJ_ITEM_GUBUN) {
		HJ_ITEM_GUBUN = hJ_ITEM_GUBUN;
	}
	public String getJJ_HOICHA() {
		return JJ_HOICHA;
	}
	public void setJJ_HOICHA(String jJ_HOICHA) {
		JJ_HOICHA = jJ_HOICHA;
	}
	public String getJJ_NAPIP_WOLDO() {
		return JJ_NAPIP_WOLDO;
	}
	public void setJJ_NAPIP_WOLDO(String jJ_NAPIP_WOLDO) {
		JJ_NAPIP_WOLDO = jJ_NAPIP_WOLDO;
	}
	public String getJJ_BATUL_GMEK() {
		return JJ_BATUL_GMEK;
	}
	public void setJJ_BATUL_GMEK(String jJ_BATUL_GMEK) {
		JJ_BATUL_GMEK = jJ_BATUL_GMEK;
	}
	public String getJJ_JUNGSANG_PRM() {
		return JJ_JUNGSANG_PRM;
	}
	public void setJJ_JUNGSANG_PRM(String jJ_JUNGSANG_PRM) {
		JJ_JUNGSANG_PRM = jJ_JUNGSANG_PRM;
	}
	public String getJJ_SUNNAP_HALIN() {
		return JJ_SUNNAP_HALIN;
	}
	public void setJJ_SUNNAP_HALIN(String jJ_SUNNAP_HALIN) {
		JJ_SUNNAP_HALIN = jJ_SUNNAP_HALIN;
	}
	
	
	
}