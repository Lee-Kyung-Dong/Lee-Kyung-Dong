package com.idongbu.smartcustomer.vo;

import java.util.HashMap;

import com.idongbu.common.vo.CMMVO;

public class ReOneCareVO extends CMMVO {

	private String ssnUserName          = ""; // 2차에서는 CmmVO에서 상속받은 필드
	private String ssnTermId			= ""; // 2차에서는 CmmVO에서 상속받은 필드
	private String ssnUserJumin	        = ""; // 2차에서는 CmmVO에서 상속받은 필드
	
	private String mode			        = "";	
                                        
	private String use_jumin            = "";
	                                    
	private String fd_mb_jumin          = "";
	                                    
	private String fd_mb_name           = "";
	private String fd_mb_mphone1        = "";
	private String fd_mb_mphone2        = "";
	private String fd_mb_mphone3        = "";
	private String fd_mb_hphone1        = "";
	private String fd_mb_hphone2        = "";
	private String fd_mb_hphone3        = "";
	                                    
	private String gb_chg               = ""; 
	private String gb_phone             = "";
	                                    
	private String phone1               = "";
	private String phone2               = "";
	private String phone3               = "";
	                                    
	private String PREV_UD_FK_POLI_NO   = "";
	                                    
	private String idx                  = "";
	                                    
	private String[] SS_IN_PIHE_NYG     = new String[30]; // 20
	private String[] SS_MUL_PIHE_NYG    = new String[30]; // 20
	private String SS_BOHUM_CHURI_CD    = "";
	                                    
	private String SS_PIHE_GWANGE       = ""; // 관계 
	private String HS_PIHE_GWANGE       = ""; // 피보험자
	private String SS_SONHE_CD1         = ""; // 손해정도
	private String SS_SONHEAK_GB        = ""; // 예상손해액
	private String SS_SERYU_YMD         = ""; // 서류송부일
	                                    
	private String sangdam_no1          = "";
	private String sangdam_no2          = "";
	                                    
	private String SS_SAGO_YMD	        = ""; // 사고년월일           
	private String SS_SAGO_HM 	        = ""; // 사고일시분      
	private String HS_TONGBOJA_NM       = "";
	private String SS_GOGEK_TEL         = "";
    private String SS_TYPE_CD           = "";
    private String SS_WONIN_CD          = "";
    private String SS_SAGO_JUBSU_NO     = "";
                                        
    private String accidentCityCode     = "";
    private String accidentCity         = "";
    private String accidentPlace        = "";
                                        
    private String HS_SAGO_NEYONG_1     = "";
    private String SS_H_GIJUN_T_DATE    = "";
                                        
    private String[] rel                = new String[0];
    private String[] pibo               = new String[0];
    private String[] sonhe              = new String[0];
    private String[] yesang             = new String[0];
    private String yyyymmdd0            = "";
    private String yyyymmdd1            = "";
    private String yyyymmdd2            = "";
    private String yyyymmdd3            = "";
    private String yyyymmdd4            = "";
    private String yyyymmdd5            = "";
    private String yyyymmdd6            = "";
    private String yyyymmdd7            = "";
    private String yyyymmdd8            = "";
    private String yyyymmdd9            = "";
                                        
    private String SS_SERYU_CD          = "";
    private String SS_SERYU_GB          = "";
                                        
    private String[] test               = new String[0];
                                        
    private String miwhakin_cd          = ""; 
                                        
    private String jubsu_no             = "";
                                        
    private String damdang_tel  	    = "";
    private String gogek_tel 		    = "";
    private String s_msg                = "";
    private String SS_GOGEK_AGE         = "";
    private String HS_GOGEK_NM          = "";
                                        
    private String SS_GOGEK_JOB_CD      = "";
    private String HS_GOGEK_JOB_NM      = "";
                                        
    private String SS_PIBO_EMAIL        = "";
    private String BB_DAMDANGJA         = "";
                                        
    private String BB_JOGUN_NO          = "";
    private String SS_GOGEK_NO		    = "";
                                        
    private String page_gb              = "";
    private String DSTIN_CD             = "";
    private String STTUS_CD             = "";
    private String ETC_TEXT             = "";
                                        
    private String RCEPT_NO  		    = "";
    private String STOCK_SEQ 		    = "";
    private String INSRD_NAME		    = "";
    private String COFFR_NAME		    = "";
                                        
    private String BB_SAGO_JUBSU_NO     = "";
    private String BB_SAGO_JUBSU_GB     = "";
                                        
    private String imc_gb               = "";
    private String SS_SAGO_JUBSU_SEQ    = "";
                                        
    private String SS_TONGBOJA_TEL      = "";
    private String SS_SAGO_JANGSO_GB    = "";
                                        
    private String BB_GOGEK_TEL         = "";
    private String HS_PIHE_NM           = "";
    private String BB_SAGO_JUBSU_SEQ    = "";
    private String BB_LAST_JUBSU_SEQ    = "";
    private String CC_CURSOR_IDX        = "";
    private String SS_SANGDAM_CNT       = "";
                                        
    private String mokjuk_gb            = "";
    private String mokjuk_seq           = "";
                                        
    private String ss_sangdam_seq       = "";
    private String ss_sangdam_no1       = "";
    private String ss_sangdam_no2       = "";
    private String ss_gijunil_from      = "";
                                        
    private String SS_H_GIJUNSI         = "";
    private String SS_SAGO_TYPE_1       = "";
    private String SS_SAGO_TYPE_2       = "";
    private String SS_H_SANGDAM_NO1     = "";
    private String SS_H_SANGDAM_NO2     = "";
                                        
    private String SS_SAGO_MOKJUK_GB    = "";
    private String SS_SAGO_MOKJUK_SEQ   = "";
    
    private String SS_SAGO_MOKJUK_GB_U  = "";
    private String SS_SAGO_MOKJUK_SEQ_U = "";
    
    private String SS_H_SANGDAM_SEQ     = "";
    private String SS_H_MAX_SEQ         = "";
                                        
    private String BB_SANGDAM_NO        = "";
    private String BB_SANGDAM_GB        = "";
    
    private String yuhyung              = "";
    private String wonin                = "";
    private String sago_yuhyung         = "";
 
    private String jinhang              = ""; // 질병상해&재물배상 1:청구서류확인, 2:사고조사, 3:보상진행, 4:보상종결
    private String jinhang_gb           = ""; // 질병상해&재물배상 1:청구서류확인, 2:사고조사, 3:보상진행, 4:보상종결
    private String sangdam_no           = "";
    
    private String SS_JOGUN             = ""; // 접수자, 계약자(1) or 피보험자.(2)
    
    private String GOGEK_JUMIN          = "";
    private String SS_CHUNGGU_GB        = "";
    private String SS_JUBSU_UPMU        = "";
    private String HS_YOCHUNG_CONT      = ""; // 요청내용
    private String BB_ST_PATH           = ""; // 1- 입력 , 0-조회
    private String SS_MAX_TONGBO_SEQ    = ""; // 일련번호
    private String SS_TONGBO_SEQ        = ""; // 일련번호
    private String ACCID_TYPE_CD        = ""; // 사고원인 ( DB 에서 검색)
    
    private String SS_SAGO_JANGSO_SP    = ""; // 특정사고
    private String SS_SAGO_JUNGBO       = ""; // 특정사고
    private String HS_SAGO_NEYONG_2     = ""; // 특정사고내용
    
    private String singu_gb             = ""; // 신구주소 구분
	//개인정보보호 동의용
	private String next_mode            = "";
	private String next_action          = "";   
	
	private String BOSANG_SANGDAM	    = "";
	private String BANK_CD			    = "";
	private String BANK_ACCOUNT		    = "";
	private String TXT_BANK_ACCOUNT		= "";
	private String BANK_ACCOUNT_TYPE	= "";
	
	private HashMap pMap                = null;
	private String jubsuNo              = ""; // 보상 접수번호
	private String damdangjaNm          = ""; // 담당자명
	private String damdangjaTel         = ""; // 담당자 전화번호
	private String fileIndex            = ""; // 서류 제출 업로드 파일 인덱스
	private String[] file               = new String[0];

	private String f_id                 = "";
	private String f_seq                = "";
	private String f_grup               = "";
	private String f_name               = "";
	private String f_path               = "";
	private String f_mime               = "";
	private String f_length             = "";
	private String reg_date             = "";
	private String del_date             = "";

	private String rank                 = "";
	private String flag                 = "";
	
	private String fId                  = "";
    private String applyJuminNo         = "";
    private String applyName            = "";
    private String successYn            = "";
    private String errMsg               = "";
    
    private String GYEJWA_NM            = "";
    private String GYEJWA_JUMIN         = "";
    
    private String log                  = "";
    
    private String CP_TYPE              = ""; // 1 : 질병/상해, 2 : 자녀           
        
	public String getSsnUserName() {
		return ssnUserName;
	}

	public void setSsnUserName(String ssnUserName) {
		this.ssnUserName = ssnUserName;
	}

	public String getSsnTermId() {
		return ssnTermId;
	}

	public void setSsnTermId(String ssnTermId) {
		this.ssnTermId = ssnTermId;
	}

	public String getSsnUserJumin() {
		return ssnUserJumin;
	}

	public void setSsnUserJumin(String ssnUserJumin) {
		this.ssnUserJumin = ssnUserJumin;
	}

	public String getMode() {
		return mode;
	}

	public void setMode(String mode) {
		this.mode = mode;
	}

	public String getUse_jumin() {
		return use_jumin;
	}

	public void setUse_jumin(String use_jumin) {
		this.use_jumin = use_jumin;
	}

	public String getFd_mb_jumin() {
		return fd_mb_jumin;
	}

	public void setFd_mb_jumin(String fd_mb_jumin) {
		this.fd_mb_jumin = fd_mb_jumin;
	}

	public String getFd_mb_name() {
		return fd_mb_name;
	}

	public void setFd_mb_name(String fd_mb_name) {
		this.fd_mb_name = fd_mb_name;
	}

	public String getFd_mb_mphone1() {
		return fd_mb_mphone1;
	}

	public void setFd_mb_mphone1(String fd_mb_mphone1) {
		this.fd_mb_mphone1 = fd_mb_mphone1;
	}

	public String getFd_mb_mphone2() {
		return fd_mb_mphone2;
	}

	public void setFd_mb_mphone2(String fd_mb_mphone2) {
		this.fd_mb_mphone2 = fd_mb_mphone2;
	}

	public String getFd_mb_mphone3() {
		return fd_mb_mphone3;
	}

	public void setFd_mb_mphone3(String fd_mb_mphone3) {
		this.fd_mb_mphone3 = fd_mb_mphone3;
	}

	public String getFd_mb_hphone1() {
		return fd_mb_hphone1;
	}

	public void setFd_mb_hphone1(String fd_mb_hphone1) {
		this.fd_mb_hphone1 = fd_mb_hphone1;
	}

	public String getFd_mb_hphone2() {
		return fd_mb_hphone2;
	}

	public void setFd_mb_hphone2(String fd_mb_hphone2) {
		this.fd_mb_hphone2 = fd_mb_hphone2;
	}

	public String getFd_mb_hphone3() {
		return fd_mb_hphone3;
	}

	public void setFd_mb_hphone3(String fd_mb_hphone3) {
		this.fd_mb_hphone3 = fd_mb_hphone3;
	}

	public String getGb_chg() {
		return gb_chg;
	}

	public void setGb_chg(String gb_chg) {
		this.gb_chg = gb_chg;
	}

	public String getGb_phone() {
		return gb_phone;
	}

	public void setGb_phone(String gb_phone) {
		this.gb_phone = gb_phone;
	}

	public String getPhone1() {
		return phone1;
	}

	public void setPhone1(String phone1) {
		this.phone1 = phone1;
	}

	public String getPhone2() {
		return phone2;
	}

	public void setPhone2(String phone2) {
		this.phone2 = phone2;
	}

	public String getPhone3() {
		return phone3;
	}

	public void setPhone3(String phone3) {
		this.phone3 = phone3;
	}

	public String getPREV_UD_FK_POLI_NO() {
		return PREV_UD_FK_POLI_NO;
	}

	public void setPREV_UD_FK_POLI_NO(String pREV_UD_FK_POLI_NO) {
		PREV_UD_FK_POLI_NO = pREV_UD_FK_POLI_NO;
	}

	public String getIdx() {
		return idx;
	}

	public void setIdx(String idx) {
		this.idx = idx;
	}

	public String[] getSS_IN_PIHE_NYG() {
		return SS_IN_PIHE_NYG;
	}

	public void setSS_IN_PIHE_NYG(String[] sS_IN_PIHE_NYG) {
		SS_IN_PIHE_NYG = sS_IN_PIHE_NYG;
	}

	public String[] getSS_MUL_PIHE_NYG() {
		return SS_MUL_PIHE_NYG;
	}

	public void setSS_MUL_PIHE_NYG(String[] sS_MUL_PIHE_NYG) {
		SS_MUL_PIHE_NYG = sS_MUL_PIHE_NYG;
	}

	public String getSS_BOHUM_CHURI_CD() {
		return SS_BOHUM_CHURI_CD;
	}

	public void setSS_BOHUM_CHURI_CD(String sS_BOHUM_CHURI_CD) {
		SS_BOHUM_CHURI_CD = sS_BOHUM_CHURI_CD;
	}

	public String getSS_PIHE_GWANGE() {
		return SS_PIHE_GWANGE;
	}

	public void setSS_PIHE_GWANGE(String sS_PIHE_GWANGE) {
		SS_PIHE_GWANGE = sS_PIHE_GWANGE;
	}

	public String getHS_PIHE_GWANGE() {
		return HS_PIHE_GWANGE;
	}

	public void setHS_PIHE_GWANGE(String hS_PIHE_GWANGE) {
		HS_PIHE_GWANGE = hS_PIHE_GWANGE;
	}

	public String getSS_SONHE_CD1() {
		return SS_SONHE_CD1;
	}

	public void setSS_SONHE_CD1(String sS_SONHE_CD1) {
		SS_SONHE_CD1 = sS_SONHE_CD1;
	}

	public String getSS_SONHEAK_GB() {
		return SS_SONHEAK_GB;
	}

	public void setSS_SONHEAK_GB(String sS_SONHEAK_GB) {
		SS_SONHEAK_GB = sS_SONHEAK_GB;
	}

	public String getSS_SERYU_YMD() {
		return SS_SERYU_YMD;
	}

	public void setSS_SERYU_YMD(String sS_SERYU_YMD) {
		SS_SERYU_YMD = sS_SERYU_YMD;
	}

	public String getSangdam_no1() {
		return sangdam_no1;
	}

	public void setSangdam_no1(String sangdam_no1) {
		this.sangdam_no1 = sangdam_no1;
	}

	public String getSangdam_no2() {
		return sangdam_no2;
	}

	public void setSangdam_no2(String sangdam_no2) {
		this.sangdam_no2 = sangdam_no2;
	}

	public String getSS_SAGO_YMD() {
		return SS_SAGO_YMD;
	}

	public void setSS_SAGO_YMD(String sS_SAGO_YMD) {
		SS_SAGO_YMD = sS_SAGO_YMD;
	}

	public String getSS_SAGO_HM() {
		return SS_SAGO_HM;
	}

	public void setSS_SAGO_HM(String sS_SAGO_HM) {
		SS_SAGO_HM = sS_SAGO_HM;
	}

	public String getHS_TONGBOJA_NM() {
		return HS_TONGBOJA_NM;
	}

	public void setHS_TONGBOJA_NM(String hS_TONGBOJA_NM) {
		HS_TONGBOJA_NM = hS_TONGBOJA_NM;
	}

	public String getSS_GOGEK_TEL() {
		return SS_GOGEK_TEL;
	}

	public void setSS_GOGEK_TEL(String sS_GOGEK_TEL) {
		SS_GOGEK_TEL = sS_GOGEK_TEL;
	}

	public String getSS_TYPE_CD() {
		return SS_TYPE_CD;
	}

	public void setSS_TYPE_CD(String sS_TYPE_CD) {
		SS_TYPE_CD = sS_TYPE_CD;
	}

	public String getSS_WONIN_CD() {
		return SS_WONIN_CD;
	}

	public void setSS_WONIN_CD(String sS_WONIN_CD) {
		SS_WONIN_CD = sS_WONIN_CD;
	}

	public String getSS_SAGO_JUBSU_NO() {
		return SS_SAGO_JUBSU_NO;
	}

	public void setSS_SAGO_JUBSU_NO(String sS_SAGO_JUBSU_NO) {
		SS_SAGO_JUBSU_NO = sS_SAGO_JUBSU_NO;
	}

	public String getAccidentCityCode() {
		return accidentCityCode;
	}

	public void setAccidentCityCode(String accidentCityCode) {
		this.accidentCityCode = accidentCityCode;
	}

	public String getAccidentCity() {
		return accidentCity;
	}

	public void setAccidentCity(String accidentCity) {
		this.accidentCity = accidentCity;
	}

	public String getAccidentPlace() {
		return accidentPlace;
	}

	public void setAccidentPlace(String accidentPlace) {
		this.accidentPlace = accidentPlace;
	}

	public String getHS_SAGO_NEYONG_1() {
		return HS_SAGO_NEYONG_1;
	}

	public void setHS_SAGO_NEYONG_1(String hS_SAGO_NEYONG_1) {
		HS_SAGO_NEYONG_1 = hS_SAGO_NEYONG_1;
	}

	public String getSS_H_GIJUN_T_DATE() {
		return SS_H_GIJUN_T_DATE;
	}

	public void setSS_H_GIJUN_T_DATE(String sS_H_GIJUN_T_DATE) {
		SS_H_GIJUN_T_DATE = sS_H_GIJUN_T_DATE;
	}

	public String[] getRel() {
		return rel;
	}

	public void setRel(String[] rel) {
		this.rel = rel;
	}

	public String[] getPibo() {
		return pibo;
	}

	public void setPibo(String[] pibo) {
		this.pibo = pibo;
	}

	public String[] getSonhe() {
		return sonhe;
	}

	public void setSonhe(String[] sonhe) {
		this.sonhe = sonhe;
	}

	public String[] getYesang() {
		return yesang;
	}

	public void setYesang(String[] yesang) {
		this.yesang = yesang;
	}

	public String getYyyymmdd0() {
		return yyyymmdd0;
	}

	public void setYyyymmdd0(String yyyymmdd0) {
		this.yyyymmdd0 = yyyymmdd0;
	}

	public String getYyyymmdd1() {
		return yyyymmdd1;
	}

	public void setYyyymmdd1(String yyyymmdd1) {
		this.yyyymmdd1 = yyyymmdd1;
	}

	public String getYyyymmdd2() {
		return yyyymmdd2;
	}

	public void setYyyymmdd2(String yyyymmdd2) {
		this.yyyymmdd2 = yyyymmdd2;
	}

	public String getYyyymmdd3() {
		return yyyymmdd3;
	}

	public void setYyyymmdd3(String yyyymmdd3) {
		this.yyyymmdd3 = yyyymmdd3;
	}

	public String getYyyymmdd4() {
		return yyyymmdd4;
	}

	public void setYyyymmdd4(String yyyymmdd4) {
		this.yyyymmdd4 = yyyymmdd4;
	}

	public String getYyyymmdd5() {
		return yyyymmdd5;
	}

	public void setYyyymmdd5(String yyyymmdd5) {
		this.yyyymmdd5 = yyyymmdd5;
	}

	public String getYyyymmdd6() {
		return yyyymmdd6;
	}

	public void setYyyymmdd6(String yyyymmdd6) {
		this.yyyymmdd6 = yyyymmdd6;
	}

	public String getYyyymmdd7() {
		return yyyymmdd7;
	}

	public void setYyyymmdd7(String yyyymmdd7) {
		this.yyyymmdd7 = yyyymmdd7;
	}

	public String getYyyymmdd8() {
		return yyyymmdd8;
	}

	public void setYyyymmdd8(String yyyymmdd8) {
		this.yyyymmdd8 = yyyymmdd8;
	}

	public String getYyyymmdd9() {
		return yyyymmdd9;
	}

	public void setYyyymmdd9(String yyyymmdd9) {
		this.yyyymmdd9 = yyyymmdd9;
	}

	public String getSS_SERYU_CD() {
		return SS_SERYU_CD;
	}

	public void setSS_SERYU_CD(String sS_SERYU_CD) {
		SS_SERYU_CD = sS_SERYU_CD;
	}

	public String getSS_SERYU_GB() {
		return SS_SERYU_GB;
	}

	public void setSS_SERYU_GB(String sS_SERYU_GB) {
		SS_SERYU_GB = sS_SERYU_GB;
	}

	public String[] getTest() {
		return test;
	}

	public void setTest(String[] test) {
		this.test = test;
	}

	public String getMiwhakin_cd() {
		return miwhakin_cd;
	}

	public void setMiwhakin_cd(String miwhakin_cd) {
		this.miwhakin_cd = miwhakin_cd;
	}

	public String getJubsu_no() {
		return jubsu_no;
	}

	public void setJubsu_no(String jubsu_no) {
		this.jubsu_no = jubsu_no;
	}

	public String getDamdang_tel() {
		return damdang_tel;
	}

	public void setDamdang_tel(String damdang_tel) {
		this.damdang_tel = damdang_tel;
	}

	public String getGogek_tel() {
		return gogek_tel;
	}

	public void setGogek_tel(String gogek_tel) {
		this.gogek_tel = gogek_tel;
	}

	public String getS_msg() {
		return s_msg;
	}

	public void setS_msg(String s_msg) {
		this.s_msg = s_msg;
	}

	public String getSS_GOGEK_AGE() {
		return SS_GOGEK_AGE;
	}

	public void setSS_GOGEK_AGE(String sS_GOGEK_AGE) {
		SS_GOGEK_AGE = sS_GOGEK_AGE;
	}

	public String getHS_GOGEK_NM() {
		return HS_GOGEK_NM;
	}

	public void setHS_GOGEK_NM(String hS_GOGEK_NM) {
		HS_GOGEK_NM = hS_GOGEK_NM;
	}

	public String getSS_GOGEK_JOB_CD() {
		return SS_GOGEK_JOB_CD;
	}

	public void setSS_GOGEK_JOB_CD(String sS_GOGEK_JOB_CD) {
		SS_GOGEK_JOB_CD = sS_GOGEK_JOB_CD;
	}

	public String getHS_GOGEK_JOB_NM() {
		return HS_GOGEK_JOB_NM;
	}

	public void setHS_GOGEK_JOB_NM(String hS_GOGEK_JOB_NM) {
		HS_GOGEK_JOB_NM = hS_GOGEK_JOB_NM;
	}

	public String getSS_PIBO_EMAIL() {
		return SS_PIBO_EMAIL;
	}

	public void setSS_PIBO_EMAIL(String sS_PIBO_EMAIL) {
		SS_PIBO_EMAIL = sS_PIBO_EMAIL;
	}

	public String getBB_DAMDANGJA() {
		return BB_DAMDANGJA;
	}

	public void setBB_DAMDANGJA(String bB_DAMDANGJA) {
		BB_DAMDANGJA = bB_DAMDANGJA;
	}

	public String getBB_JOGUN_NO() {
		return BB_JOGUN_NO;
	}

	public void setBB_JOGUN_NO(String bB_JOGUN_NO) {
		BB_JOGUN_NO = bB_JOGUN_NO;
	}

	public String getSS_GOGEK_NO() {
		return SS_GOGEK_NO;
	}

	public void setSS_GOGEK_NO(String sS_GOGEK_NO) {
		SS_GOGEK_NO = sS_GOGEK_NO;
	}

	public String getPage_gb() {
		return page_gb;
	}

	public void setPage_gb(String page_gb) {
		this.page_gb = page_gb;
	}

	public String getDSTIN_CD() {
		return DSTIN_CD;
	}

	public void setDSTIN_CD(String dSTIN_CD) {
		DSTIN_CD = dSTIN_CD;
	}

	public String getSTTUS_CD() {
		return STTUS_CD;
	}

	public void setSTTUS_CD(String sTTUS_CD) {
		STTUS_CD = sTTUS_CD;
	}

	public String getETC_TEXT() {
		return ETC_TEXT;
	}

	public void setETC_TEXT(String eTC_TEXT) {
		ETC_TEXT = eTC_TEXT;
	}

	public String getRCEPT_NO() {
		return RCEPT_NO;
	}

	public void setRCEPT_NO(String rCEPT_NO) {
		RCEPT_NO = rCEPT_NO;
	}

	public String getSTOCK_SEQ() {
		return STOCK_SEQ;
	}

	public void setSTOCK_SEQ(String sTOCK_SEQ) {
		STOCK_SEQ = sTOCK_SEQ;
	}

	public String getINSRD_NAME() {
		return INSRD_NAME;
	}

	public void setINSRD_NAME(String iNSRD_NAME) {
		INSRD_NAME = iNSRD_NAME;
	}

	public String getCOFFR_NAME() {
		return COFFR_NAME;
	}

	public void setCOFFR_NAME(String cOFFR_NAME) {
		COFFR_NAME = cOFFR_NAME;
	}

	public String getBB_SAGO_JUBSU_NO() {
		return BB_SAGO_JUBSU_NO;
	}

	public void setBB_SAGO_JUBSU_NO(String bB_SAGO_JUBSU_NO) {
		BB_SAGO_JUBSU_NO = bB_SAGO_JUBSU_NO;
	}

	public String getBB_SAGO_JUBSU_GB() {
		return BB_SAGO_JUBSU_GB;
	}

	public void setBB_SAGO_JUBSU_GB(String bB_SAGO_JUBSU_GB) {
		BB_SAGO_JUBSU_GB = bB_SAGO_JUBSU_GB;
	}

	public String getImc_gb() {
		return imc_gb;
	}

	public void setImc_gb(String imc_gb) {
		this.imc_gb = imc_gb;
	}

	public String getSS_SAGO_JUBSU_SEQ() {
		return SS_SAGO_JUBSU_SEQ;
	}

	public void setSS_SAGO_JUBSU_SEQ(String sS_SAGO_JUBSU_SEQ) {
		SS_SAGO_JUBSU_SEQ = sS_SAGO_JUBSU_SEQ;
	}

	public String getSS_TONGBOJA_TEL() {
		return SS_TONGBOJA_TEL;
	}

	public void setSS_TONGBOJA_TEL(String sS_TONGBOJA_TEL) {
		SS_TONGBOJA_TEL = sS_TONGBOJA_TEL;
	}

	public String getSS_SAGO_JANGSO_GB() {
		return SS_SAGO_JANGSO_GB;
	}

	public void setSS_SAGO_JANGSO_GB(String sS_SAGO_JANGSO_GB) {
		SS_SAGO_JANGSO_GB = sS_SAGO_JANGSO_GB;
	}

	public String getBB_GOGEK_TEL() {
		return BB_GOGEK_TEL;
	}

	public void setBB_GOGEK_TEL(String bB_GOGEK_TEL) {
		BB_GOGEK_TEL = bB_GOGEK_TEL;
	}

	public String getHS_PIHE_NM() {
		return HS_PIHE_NM;
	}

	public void setHS_PIHE_NM(String hS_PIHE_NM) {
		HS_PIHE_NM = hS_PIHE_NM;
	}

	public String getBB_SAGO_JUBSU_SEQ() {
		return BB_SAGO_JUBSU_SEQ;
	}

	public void setBB_SAGO_JUBSU_SEQ(String bB_SAGO_JUBSU_SEQ) {
		BB_SAGO_JUBSU_SEQ = bB_SAGO_JUBSU_SEQ;
	}

	public String getBB_LAST_JUBSU_SEQ() {
		return BB_LAST_JUBSU_SEQ;
	}

	public void setBB_LAST_JUBSU_SEQ(String bB_LAST_JUBSU_SEQ) {
		BB_LAST_JUBSU_SEQ = bB_LAST_JUBSU_SEQ;
	}

	public String getCC_CURSOR_IDX() {
		return CC_CURSOR_IDX;
	}

	public void setCC_CURSOR_IDX(String cC_CURSOR_IDX) {
		CC_CURSOR_IDX = cC_CURSOR_IDX;
	}

	public String getSS_SANGDAM_CNT() {
		return SS_SANGDAM_CNT;
	}

	public void setSS_SANGDAM_CNT(String sS_SANGDAM_CNT) {
		SS_SANGDAM_CNT = sS_SANGDAM_CNT;
	}

	public String getMokjuk_gb() {
		return mokjuk_gb;
	}

	public void setMokjuk_gb(String mokjuk_gb) {
		this.mokjuk_gb = mokjuk_gb;
	}

	public String getMokjuk_seq() {
		return mokjuk_seq;
	}

	public void setMokjuk_seq(String mokjuk_seq) {
		this.mokjuk_seq = mokjuk_seq;
	}

	public String getSs_sangdam_seq() {
		return ss_sangdam_seq;
	}

	public void setSs_sangdam_seq(String ss_sangdam_seq) {
		this.ss_sangdam_seq = ss_sangdam_seq;
	}

	public String getSs_sangdam_no1() {
		return ss_sangdam_no1;
	}

	public void setSs_sangdam_no1(String ss_sangdam_no1) {
		this.ss_sangdam_no1 = ss_sangdam_no1;
	}

	public String getSs_sangdam_no2() {
		return ss_sangdam_no2;
	}

	public void setSs_sangdam_no2(String ss_sangdam_no2) {
		this.ss_sangdam_no2 = ss_sangdam_no2;
	}

	public String getSs_gijunil_from() {
		return ss_gijunil_from;
	}

	public void setSs_gijunil_from(String ss_gijunil_from) {
		this.ss_gijunil_from = ss_gijunil_from;
	}

	public String getSS_H_GIJUNSI() {
		return SS_H_GIJUNSI;
	}

	public void setSS_H_GIJUNSI(String sS_H_GIJUNSI) {
		SS_H_GIJUNSI = sS_H_GIJUNSI;
	}

	public String getSS_SAGO_TYPE_1() {
		return SS_SAGO_TYPE_1;
	}

	public void setSS_SAGO_TYPE_1(String sS_SAGO_TYPE_1) {
		SS_SAGO_TYPE_1 = sS_SAGO_TYPE_1;
	}

	public String getSS_SAGO_TYPE_2() {
		return SS_SAGO_TYPE_2;
	}

	public void setSS_SAGO_TYPE_2(String sS_SAGO_TYPE_2) {
		SS_SAGO_TYPE_2 = sS_SAGO_TYPE_2;
	}

	public String getSS_H_SANGDAM_NO1() {
		return SS_H_SANGDAM_NO1;
	}

	public void setSS_H_SANGDAM_NO1(String sS_H_SANGDAM_NO1) {
		SS_H_SANGDAM_NO1 = sS_H_SANGDAM_NO1;
	}

	public String getSS_H_SANGDAM_NO2() {
		return SS_H_SANGDAM_NO2;
	}

	public void setSS_H_SANGDAM_NO2(String sS_H_SANGDAM_NO2) {
		SS_H_SANGDAM_NO2 = sS_H_SANGDAM_NO2;
	}

	public String getSS_SAGO_MOKJUK_GB() {
		return SS_SAGO_MOKJUK_GB;
	}

	public void setSS_SAGO_MOKJUK_GB(String sS_SAGO_MOKJUK_GB) {
		SS_SAGO_MOKJUK_GB = sS_SAGO_MOKJUK_GB;
	}

	public String getSS_SAGO_MOKJUK_SEQ() {
		return SS_SAGO_MOKJUK_SEQ;
	}

	public void setSS_SAGO_MOKJUK_SEQ(String sS_SAGO_MOKJUK_SEQ) {
		SS_SAGO_MOKJUK_SEQ = sS_SAGO_MOKJUK_SEQ;
	}

	public String getSS_SAGO_MOKJUK_GB_U() {
		return SS_SAGO_MOKJUK_GB_U;
	}

	public void setSS_SAGO_MOKJUK_GB_U(String sS_SAGO_MOKJUK_GB_U) {
		SS_SAGO_MOKJUK_GB_U = sS_SAGO_MOKJUK_GB_U;
	}

	public String getSS_SAGO_MOKJUK_SEQ_U() {
		return SS_SAGO_MOKJUK_SEQ_U;
	}

	public void setSS_SAGO_MOKJUK_SEQ_U(String sS_SAGO_MOKJUK_SEQ_U) {
		SS_SAGO_MOKJUK_SEQ_U = sS_SAGO_MOKJUK_SEQ_U;
	}

	public String getSS_H_SANGDAM_SEQ() {
		return SS_H_SANGDAM_SEQ;
	}

	public void setSS_H_SANGDAM_SEQ(String sS_H_SANGDAM_SEQ) {
		SS_H_SANGDAM_SEQ = sS_H_SANGDAM_SEQ;
	}

	public String getSS_H_MAX_SEQ() {
		return SS_H_MAX_SEQ;
	}

	public void setSS_H_MAX_SEQ(String sS_H_MAX_SEQ) {
		SS_H_MAX_SEQ = sS_H_MAX_SEQ;
	}

	public String getBB_SANGDAM_NO() {
		return BB_SANGDAM_NO;
	}

	public void setBB_SANGDAM_NO(String bB_SANGDAM_NO) {
		BB_SANGDAM_NO = bB_SANGDAM_NO;
	}

	public String getBB_SANGDAM_GB() {
		return BB_SANGDAM_GB;
	}

	public void setBB_SANGDAM_GB(String bB_SANGDAM_GB) {
		BB_SANGDAM_GB = bB_SANGDAM_GB;
	}

	public String getYuhyung() {
		return yuhyung;
	}

	public void setYuhyung(String yuhyung) {
		this.yuhyung = yuhyung;
	}

	public String getWonin() {
		return wonin;
	}

	public void setWonin(String wonin) {
		this.wonin = wonin;
	}

	public String getSago_yuhyung() {
		return sago_yuhyung;
	}

	public void setSago_yuhyung(String sago_yuhyung) {
		this.sago_yuhyung = sago_yuhyung;
	}

	public String getJinhang() {
		return jinhang;
	}

	public void setJinhang(String jinhang) {
		this.jinhang = jinhang;
	}

	public String getJinhang_gb() {
		return jinhang_gb;
	}

	public void setJinhang_gb(String jinhang_gb) {
		this.jinhang_gb = jinhang_gb;
	}

	public String getSangdam_no() {
		return sangdam_no;
	}

	public void setSangdam_no(String sangdam_no) {
		this.sangdam_no = sangdam_no;
	}

	public String getSS_JOGUN() {
		return SS_JOGUN;
	}

	public void setSS_JOGUN(String sS_JOGUN) {
		SS_JOGUN = sS_JOGUN;
	}

	public String getGOGEK_JUMIN() {
		return GOGEK_JUMIN;
	}

	public void setGOGEK_JUMIN(String gOGEK_JUMIN) {
		GOGEK_JUMIN = gOGEK_JUMIN;
	}

	public String getSS_CHUNGGU_GB() {
		return SS_CHUNGGU_GB;
	}

	public void setSS_CHUNGGU_GB(String sS_CHUNGGU_GB) {
		SS_CHUNGGU_GB = sS_CHUNGGU_GB;
	}

	public String getSS_JUBSU_UPMU() {
		return SS_JUBSU_UPMU;
	}

	public void setSS_JUBSU_UPMU(String sS_JUBSU_UPMU) {
		SS_JUBSU_UPMU = sS_JUBSU_UPMU;
	}

	public String getHS_YOCHUNG_CONT() {
		return HS_YOCHUNG_CONT;
	}

	public void setHS_YOCHUNG_CONT(String hS_YOCHUNG_CONT) {
		HS_YOCHUNG_CONT = hS_YOCHUNG_CONT;
	}

	public String getBB_ST_PATH() {
		return BB_ST_PATH;
	}

	public void setBB_ST_PATH(String bB_ST_PATH) {
		BB_ST_PATH = bB_ST_PATH;
	}

	public String getSS_MAX_TONGBO_SEQ() {
		return SS_MAX_TONGBO_SEQ;
	}

	public void setSS_MAX_TONGBO_SEQ(String sS_MAX_TONGBO_SEQ) {
		SS_MAX_TONGBO_SEQ = sS_MAX_TONGBO_SEQ;
	}

	public String getSS_TONGBO_SEQ() {
		return SS_TONGBO_SEQ;
	}

	public void setSS_TONGBO_SEQ(String sS_TONGBO_SEQ) {
		SS_TONGBO_SEQ = sS_TONGBO_SEQ;
	}

	public String getACCID_TYPE_CD() {
		return ACCID_TYPE_CD;
	}

	public void setACCID_TYPE_CD(String aCCID_TYPE_CD) {
		ACCID_TYPE_CD = aCCID_TYPE_CD;
	}

	public String getSS_SAGO_JANGSO_SP() {
		return SS_SAGO_JANGSO_SP;
	}

	public void setSS_SAGO_JANGSO_SP(String sS_SAGO_JANGSO_SP) {
		SS_SAGO_JANGSO_SP = sS_SAGO_JANGSO_SP;
	}

	public String getSS_SAGO_JUNGBO() {
		return SS_SAGO_JUNGBO;
	}

	public void setSS_SAGO_JUNGBO(String sS_SAGO_JUNGBO) {
		SS_SAGO_JUNGBO = sS_SAGO_JUNGBO;
	}

	public String getHS_SAGO_NEYONG_2() {
		return HS_SAGO_NEYONG_2;
	}

	public void setHS_SAGO_NEYONG_2(String hS_SAGO_NEYONG_2) {
		HS_SAGO_NEYONG_2 = hS_SAGO_NEYONG_2;
	}

	public String getSingu_gb() {
		return singu_gb;
	}

	public void setSingu_gb(String singu_gb) {
		this.singu_gb = singu_gb;
	}

	public String getNext_mode() {
		return next_mode;
	}

	public void setNext_mode(String next_mode) {
		this.next_mode = next_mode;
	}

	public String getNext_action() {
		return next_action;
	}

	public void setNext_action(String next_action) {
		this.next_action = next_action;
	}

	public String getBOSANG_SANGDAM() {
		return BOSANG_SANGDAM;
	}

	public void setBOSANG_SANGDAM(String bOSANG_SANGDAM) {
		BOSANG_SANGDAM = bOSANG_SANGDAM;
	}

	public String getBANK_CD() {
		return BANK_CD;
	}

	public void setBANK_CD(String bANK_CD) {
		BANK_CD = bANK_CD;
	}

	public String getBANK_ACCOUNT() {
		return BANK_ACCOUNT;
	}

	public void setBANK_ACCOUNT(String bANK_ACCOUNT) {
		BANK_ACCOUNT = bANK_ACCOUNT;
	}
	
	public String getTXT_BANK_ACCOUNT() {
		return TXT_BANK_ACCOUNT;
	}

	public void setTXT_BANK_ACCOUNT(String tXT_BANK_ACCOUNT) {
		TXT_BANK_ACCOUNT = tXT_BANK_ACCOUNT;
	}

	public String getBANK_ACCOUNT_TYPE() {
		return BANK_ACCOUNT_TYPE;
	}

	public void setBANK_ACCOUNT_TYPE(String bANK_ACCOUNT_TYPE) {
		BANK_ACCOUNT_TYPE = bANK_ACCOUNT_TYPE;
	}

	public HashMap getpMap() {
		return pMap;
	}

	public void setpMap(HashMap pMap) {
		this.pMap = pMap;
	}

	public String getJubsuNo() {
		return jubsuNo;
	}

	public void setJubsuNo(String jubsuNo) {
		this.jubsuNo = jubsuNo;
	}

	public String getDamdangjaNm() {
		return damdangjaNm;
	}

	public void setDamdangjaNm(String damdangjaNm) {
		this.damdangjaNm = damdangjaNm;
	}

	public String getDamdangjaTel() {
		return damdangjaTel;
	}

	public void setDamdangjaTel(String damdangjaTel) {
		this.damdangjaTel = damdangjaTel;
	}

	public String getFileIndex() {
		return fileIndex;
	}

	public void setFileIndex(String fileIndex) {
		this.fileIndex = fileIndex;
	}

	public String[] getFile() {
		return file;
	}

	public void setFile(String[] file) {
		this.file = file;
	}

	public String getF_id() {
		return f_id;
	}

	public void setF_id(String f_id) {
		this.f_id = f_id;
	}

	public String getF_seq() {
		return f_seq;
	}

	public void setF_seq(String f_seq) {
		this.f_seq = f_seq;
	}

	public String getF_grup() {
		return f_grup;
	}

	public void setF_grup(String f_grup) {
		this.f_grup = f_grup;
	}

	public String getF_name() {
		return f_name;
	}

	public void setF_name(String f_name) {
		this.f_name = f_name;
	}

	public String getF_path() {
		return f_path;
	}

	public void setF_path(String f_path) {
		this.f_path = f_path;
	}

	public String getF_mime() {
		return f_mime;
	}

	public void setF_mime(String f_mime) {
		this.f_mime = f_mime;
	}

	public String getF_length() {
		return f_length;
	}

	public void setF_length(String f_length) {
		this.f_length = f_length;
	}

	public String getReg_date() {
		return reg_date;
	}

	public void setReg_date(String reg_date) {
		this.reg_date = reg_date;
	}

	public String getDel_date() {
		return del_date;
	}

	public void setDel_date(String del_date) {
		this.del_date = del_date;
	}

	public String getRank() {
		return rank;
	}

	public void setRank(String rank) {
		this.rank = rank;
	}

	public String getFlag() {
		return flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}

	public String getfId() {
		return fId;
	}

	public void setfId(String fId) {
		this.fId = fId;
	}

	public String getApplyJuminNo() {
		return applyJuminNo;
	}

	public void setApplyJuminNo(String applyJuminNo) {
		this.applyJuminNo = applyJuminNo;
	}

	public String getApplyName() {
		return applyName;
	}

	public void setApplyName(String applyName) {
		this.applyName = applyName;
	}

	public String getSuccessYn() {
		return successYn;
	}

	public void setSuccessYn(String successYn) {
		this.successYn = successYn;
	}

	public String getErrMsg() {
		return errMsg;
	}

	public void setErrMsg(String errMsg) {
		this.errMsg = errMsg;
	}

	public String getGYEJWA_NM() {
		return GYEJWA_NM;
	}

	public void setGYEJWA_NM(String gYEJWA_NM) {
		GYEJWA_NM = gYEJWA_NM;
	}

	public String getGYEJWA_JUMIN() {
		return GYEJWA_JUMIN;
	}

	public void setGYEJWA_JUMIN(String gYEJWA_JUMIN) {
		GYEJWA_JUMIN = gYEJWA_JUMIN;
	}

	public String getLog() {
		return log;
	}

	public void setLog(String log) {
		this.log = log;
	}

	public String getCP_TYPE() {
		return CP_TYPE;
	}

	public void setCP_TYPE(String cP_TYPE) {
		CP_TYPE = cP_TYPE;
	}
	
	private String contact1               = "";
	private String contact2               = "";
	private String contact3               = "";
	public String getContact1() {
		return contact1;
	}

	public void setContact1(String contact1) {
		this.contact1 = contact1;
	}

	public String getContact2() {
		return contact2;
	}

	public void setContact2(String contact2) {
		this.contact2 = contact2;
	}

	public String getContact3() {
		return contact3;
	}

	public void setContact3(String contact3) {
		this.contact3 = contact3;
	}
}
