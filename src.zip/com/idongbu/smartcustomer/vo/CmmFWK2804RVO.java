package com.idongbu.smartcustomer.vo;

import java.util.List;
import java.util.Map;

import com.idongbu.common.vo.CMMVO;

/**
 * title : FWK2804R 인라인보험 영수확정
 */
public class CmmFWK2804RVO extends CMMVO {
	public CmmFWK2804RVO() {
		super.setPGMID(this.proid);
		super.setTRID(this.trid);
	}
	public static final String proid		= "FWK2804R";
	public static final String trid		= "WV04";
	private String rURL						= "";
	
	// 동부 기업보험 파트 구자은 과장의 요청사항 : 2011.03.03
	private String GOGAEK_NO      = ""; // 고객번호 (-) 제외
	private String SANGDAMIL_DATE = ""; // 상담일자 (yyyymmddhh24miss)
	private String BALSHINJA_NO   = ""; // 발신자 번호 (-) 제외
	private String STATUS         = ""; // 접수, 완료
	private String UPMU_DESC1     = ""; // 상담업무 대분류 : 메뉴 레벨1
	private String UPMU_DESC2     = ""; // 상담업무 대분류 : 메뉴 레벨2
	private String UPMU_DESC3     = ""; // 상담업무 대분류 : 메뉴 레벨3
	private String POLI_NO        = ""; // 증권번호
    private String JUBSU_NO       = ""; // 접수번호
    private String SULGYE_NO      = ""; // 설계번호
    private String NOTE           = ""; // 비고		

    // 공통
 	private String COMM_CHANNEL = null; // 채널유형
 	private String COMM_UNIQUE = null; // 	터미널ID
 	private String COMM_PROGRAM = null; // 	프로그램ID
 	private String COMM_TRANS = null; // 	경로
 	private String COMM_ACTION = null; // 	기능키
 	private String COMM_USER_GB = null; // 	사용자구분
 	private String COMM_USER_ID = null; // 	사용자ID
 	private String COMM_JIJUM_CD = null; // 	지점코드
 	private String COMM_JIBU_CD = null; // 	지부코드
 	private String COMM_PROTOCOL = null; // 	프로토콜
 	private String COMM_RETN_CODE = null; // 	상태코드
 	private String COMM_LAST_FLAG = null; // 	마지막자료구분
 	private String COMM_CUR_FLD = null; // 	현재위치맵
 	private String COMM_CUR_POS = null; // 	현재위치값
 	private String COMM_MSG_CODE = null; // 	메시지코드
 	private String H_COMM_MSG_NAME = null; // 	메시지명
 	private String COMM_SYS_ERR = null; // 	시스템메시지
 	private String COMM_FIL = null; // 	공백
 	
 	// I
    private String COMM_CHURI_GB  = null; //	처리구분
    private String COMM_BJ_CD  = null; // 	보종코드
    private String COMM_SULGYE_NO  = null; //	설계번호
    private String COMM_POLI_NO  = null; // 	증권번호
    private String COMM_BESU_SEQ  = null; // 	배서SEQ
    private String COMM_DANCHE_YH	 = null; //단체유형
    private String COMM_PIBO_CNT   = null; //	피보험자수1
    private String COMM_PANME_YH  = null; //	판매유형
    private String COMM_GAJOK_GB  = null; //  	부부가족구분
    private String COMM_JOB_CD  = null; //  	직업코드
    private String COMM_PB_GBSU  = null; //	피보험자급수
    private String COMM_PB_CNT  = null; //	피보험자수2
    private String COMM_AMT_CODE  = null; //	화폐코드
    private String H_COMM_TRIP_PLACE  = null; //	여행지
    private String COMM_TRIP_CODE   = null; // 	여행국가코드
    private String H_COMM_TRIP_OBJECT  = null; //	여행목적명
    private String COMM_BO_GIGAN_SYMD  = null; //	보험기간시기
    private String COMM_BO_GIGAN_SHM   = null; //	보험기간시기시분
    private String COMM_BO_GIGAN_EYMD   = null; //	보험기간종기
    private String COMM_BO_GIGAN_EHM  = null; //	보험기간종기시분
    private String COMM_HALIN_YUL   = null; // 	할인율
    private String COMM_OUT_FILLER = null; // 여유분 
	/***********************************************
	 *      
	 * loopData1 에 포함되는 필드
	 * 
	 * COMM_PIBO_JUMIN_NO // 피보험자주민번호
	 * H_COMM_PIBO_NM // 피보험자명
	 * 
	 ***********************************************/
	//private List<Map<String,Object>> loopData_1 = null;
    
	// I/O 
	/***********************************************
	 *      
	 * loopData1 에 포함되는 필드
	 * 
	 * COMM_PLAN_CD // 플랜코드
	 * COMM_PLAN_PRM // 플랜보험료
	 * 
	 ***********************************************/
	//private List<Map<String,Object>> loopData_2 = null;    
    
//    private String[] COMM_PIBO_JUMIN_NO = new String[20]; // 피보험자주민번호 (동행자가입불가 본인만 가능)
//    private String[] H_COMM_PIBO_NM = new String[20]; // 피보험자 성명 (동행자가입불가 본인만 가능)

    private String COMM_PIBO_JUMIN_NO = null; // 피보험자주민번호
    private String H_COMM_PIBO_NM = null; // 피보험자성명

    private String[] COMM_PLAN_CD = new String[20]; // 플랜코드(배열)
    private String[] COMM_PLAN_PRM = new String[20]; // 플랜보험료(배열)
    
    private String[] COMM_DAMBO_CD = new String[20]; // 담보코드(배열)
    private String[] COMM_GONGJE_GMEK = new String[20]; // 공제금액(배열)
    
    // LoopData
    public List<Map<String,Object>> LOOP_DATA1 = null; // 플랜사항 
    public List<Map<String,Object>> LOOP_DATA2 = null; // 담보사항
    
	public String getrURL() {
		return rURL;
	}
	public void setrURL(String rURL) {
		this.rURL = rURL;
	}
	public String getGOGAEK_NO() {
		return GOGAEK_NO;
	}
	public void setGOGAEK_NO(String gOGAEK_NO) {
		GOGAEK_NO = gOGAEK_NO;
	}
	public String getSANGDAMIL_DATE() {
		return SANGDAMIL_DATE;
	}
	public void setSANGDAMIL_DATE(String sANGDAMIL_DATE) {
		SANGDAMIL_DATE = sANGDAMIL_DATE;
	}
	public String getBALSHINJA_NO() {
		return BALSHINJA_NO;
	}
	public void setBALSHINJA_NO(String bALSHINJA_NO) {
		BALSHINJA_NO = bALSHINJA_NO;
	}
	public String getSTATUS() {
		return STATUS;
	}
	public void setSTATUS(String sTATUS) {
		STATUS = sTATUS;
	}
	public String getUPMU_DESC1() {
		return UPMU_DESC1;
	}
	public void setUPMU_DESC1(String uPMU_DESC1) {
		UPMU_DESC1 = uPMU_DESC1;
	}
	public String getUPMU_DESC2() {
		return UPMU_DESC2;
	}
	public void setUPMU_DESC2(String uPMU_DESC2) {
		UPMU_DESC2 = uPMU_DESC2;
	}
	public String getUPMU_DESC3() {
		return UPMU_DESC3;
	}
	public void setUPMU_DESC3(String uPMU_DESC3) {
		UPMU_DESC3 = uPMU_DESC3;
	}
	public String getPOLI_NO() {
		return POLI_NO;
	}
	public void setPOLI_NO(String pOLI_NO) {
		POLI_NO = pOLI_NO;
	}
	public String getJUBSU_NO() {
		return JUBSU_NO;
	}
	public void setJUBSU_NO(String jUBSU_NO) {
		JUBSU_NO = jUBSU_NO;
	}
	public String getSULGYE_NO() {
		return SULGYE_NO;
	}
	public void setSULGYE_NO(String sULGYE_NO) {
		SULGYE_NO = sULGYE_NO;
	}
	public String getNOTE() {
		return NOTE;
	}
	public void setNOTE(String nOTE) {
		NOTE = nOTE;
	}
	public String getCOMM_CHANNEL() {
		return COMM_CHANNEL;
	}
	public void setCOMM_CHANNEL(String cOMM_CHANNEL) {
		COMM_CHANNEL = cOMM_CHANNEL;
	}
	public String getCOMM_UNIQUE() {
		return COMM_UNIQUE;
	}
	public void setCOMM_UNIQUE(String cOMM_UNIQUE) {
		COMM_UNIQUE = cOMM_UNIQUE;
	}
	public String getCOMM_PROGRAM() {
		return COMM_PROGRAM;
	}
	public void setCOMM_PROGRAM(String cOMM_PROGRAM) {
		COMM_PROGRAM = cOMM_PROGRAM;
	}
	public String getCOMM_TRANS() {
		return COMM_TRANS;
	}
	public void setCOMM_TRANS(String cOMM_TRANS) {
		COMM_TRANS = cOMM_TRANS;
	}
	public String getCOMM_ACTION() {
		return COMM_ACTION;
	}
	public void setCOMM_ACTION(String cOMM_ACTION) {
		COMM_ACTION = cOMM_ACTION;
	}
	public String getCOMM_USER_GB() {
		return COMM_USER_GB;
	}
	public void setCOMM_USER_GB(String cOMM_USER_GB) {
		COMM_USER_GB = cOMM_USER_GB;
	}
	public String getCOMM_USER_ID() {
		return COMM_USER_ID;
	}
	public void setCOMM_USER_ID(String cOMM_USER_ID) {
		COMM_USER_ID = cOMM_USER_ID;
	}
	public String getCOMM_JIJUM_CD() {
		return COMM_JIJUM_CD;
	}
	public void setCOMM_JIJUM_CD(String cOMM_JIJUM_CD) {
		COMM_JIJUM_CD = cOMM_JIJUM_CD;
	}
	public String getCOMM_JIBU_CD() {
		return COMM_JIBU_CD;
	}
	public void setCOMM_JIBU_CD(String cOMM_JIBU_CD) {
		COMM_JIBU_CD = cOMM_JIBU_CD;
	}
	public String getCOMM_PROTOCOL() {
		return COMM_PROTOCOL;
	}
	public void setCOMM_PROTOCOL(String cOMM_PROTOCOL) {
		COMM_PROTOCOL = cOMM_PROTOCOL;
	}
	public String getCOMM_RETN_CODE() {
		return COMM_RETN_CODE;
	}
	public void setCOMM_RETN_CODE(String cOMM_RETN_CODE) {
		COMM_RETN_CODE = cOMM_RETN_CODE;
	}
	public String getCOMM_LAST_FLAG() {
		return COMM_LAST_FLAG;
	}
	public void setCOMM_LAST_FLAG(String cOMM_LAST_FLAG) {
		COMM_LAST_FLAG = cOMM_LAST_FLAG;
	}
	public String getCOMM_CUR_FLD() {
		return COMM_CUR_FLD;
	}
	public void setCOMM_CUR_FLD(String cOMM_CUR_FLD) {
		COMM_CUR_FLD = cOMM_CUR_FLD;
	}
	public String getCOMM_CUR_POS() {
		return COMM_CUR_POS;
	}
	public void setCOMM_CUR_POS(String cOMM_CUR_POS) {
		COMM_CUR_POS = cOMM_CUR_POS;
	}
	public String getCOMM_MSG_CODE() {
		return COMM_MSG_CODE;
	}
	public void setCOMM_MSG_CODE(String cOMM_MSG_CODE) {
		COMM_MSG_CODE = cOMM_MSG_CODE;
	}
	public String getH_COMM_MSG_NAME() {
		return H_COMM_MSG_NAME;
	}
	public void setH_COMM_MSG_NAME(String h_COMM_MSG_NAME) {
		H_COMM_MSG_NAME = h_COMM_MSG_NAME;
	}
	public String getCOMM_SYS_ERR() {
		return COMM_SYS_ERR;
	}
	public void setCOMM_SYS_ERR(String cOMM_SYS_ERR) {
		COMM_SYS_ERR = cOMM_SYS_ERR;
	}
	public String getCOMM_FIL() {
		return COMM_FIL;
	}
	public void setCOMM_FIL(String cOMM_FIL) {
		COMM_FIL = cOMM_FIL;
	}
	public String getCOMM_CHURI_GB() {
		return COMM_CHURI_GB;
	}
	public void setCOMM_CHURI_GB(String cOMM_CHURI_GB) {
		COMM_CHURI_GB = cOMM_CHURI_GB;
	}
	public String getCOMM_BJ_CD() {
		return COMM_BJ_CD;
	}
	public void setCOMM_BJ_CD(String cOMM_BJ_CD) {
		COMM_BJ_CD = cOMM_BJ_CD;
	}
	public String getCOMM_SULGYE_NO() {
		return COMM_SULGYE_NO;
	}
	public void setCOMM_SULGYE_NO(String cOMM_SULGYE_NO) {
		COMM_SULGYE_NO = cOMM_SULGYE_NO;
	}
	public String getCOMM_POLI_NO() {
		return COMM_POLI_NO;
	}
	public void setCOMM_POLI_NO(String cOMM_POLI_NO) {
		COMM_POLI_NO = cOMM_POLI_NO;
	}
	public String getCOMM_BESU_SEQ() {
		return COMM_BESU_SEQ;
	}
	public void setCOMM_BESU_SEQ(String cOMM_BESU_SEQ) {
		COMM_BESU_SEQ = cOMM_BESU_SEQ;
	}
	public String getCOMM_DANCHE_YH() {
		return COMM_DANCHE_YH;
	}
	public void setCOMM_DANCHE_YH(String cOMM_DANCHE_YH) {
		COMM_DANCHE_YH = cOMM_DANCHE_YH;
	}
	public String getCOMM_PIBO_CNT() {
		return COMM_PIBO_CNT;
	}
	public void setCOMM_PIBO_CNT(String cOMM_PIBO_CNT) {
		COMM_PIBO_CNT = cOMM_PIBO_CNT;
	}
	public String getCOMM_PANME_YH() {
		return COMM_PANME_YH;
	}
	public void setCOMM_PANME_YH(String cOMM_PANME_YH) {
		COMM_PANME_YH = cOMM_PANME_YH;
	}
	public String getCOMM_GAJOK_GB() {
		return COMM_GAJOK_GB;
	}
	public void setCOMM_GAJOK_GB(String cOMM_GAJOK_GB) {
		COMM_GAJOK_GB = cOMM_GAJOK_GB;
	}
	public String getCOMM_JOB_CD() {
		return COMM_JOB_CD;
	}
	public void setCOMM_JOB_CD(String cOMM_JOB_CD) {
		COMM_JOB_CD = cOMM_JOB_CD;
	}
	public String getCOMM_PB_GBSU() {
		return COMM_PB_GBSU;
	}
	public void setCOMM_PB_GBSU(String cOMM_PB_GBSU) {
		COMM_PB_GBSU = cOMM_PB_GBSU;
	}
	public String getCOMM_PB_CNT() {
		return COMM_PB_CNT;
	}
	public void setCOMM_PB_CNT(String cOMM_PB_CNT) {
		COMM_PB_CNT = cOMM_PB_CNT;
	}
	public String getCOMM_AMT_CODE() {
		return COMM_AMT_CODE;
	}
	public void setCOMM_AMT_CODE(String cOMM_AMT_CODE) {
		COMM_AMT_CODE = cOMM_AMT_CODE;
	}
	public String getH_COMM_TRIP_PLACE() {
		return H_COMM_TRIP_PLACE;
	}
	public void setH_COMM_TRIP_PLACE(String h_COMM_TRIP_PLACE) {
		H_COMM_TRIP_PLACE = h_COMM_TRIP_PLACE;
	}
	public String getCOMM_TRIP_CODE() {
		return COMM_TRIP_CODE;
	}
	public void setCOMM_TRIP_CODE(String cOMM_TRIP_CODE) {
		COMM_TRIP_CODE = cOMM_TRIP_CODE;
	}
	public String getH_COMM_TRIP_OBJECT() {
		return H_COMM_TRIP_OBJECT;
	}
	public void setH_COMM_TRIP_OBJECT(String h_COMM_TRIP_OBJECT) {
		H_COMM_TRIP_OBJECT = h_COMM_TRIP_OBJECT;
	}
	public String getCOMM_BO_GIGAN_SYMD() {
		return COMM_BO_GIGAN_SYMD;
	}
	public void setCOMM_BO_GIGAN_SYMD(String cOMM_BO_GIGAN_SYMD) {
		COMM_BO_GIGAN_SYMD = cOMM_BO_GIGAN_SYMD;
	}
	public String getCOMM_BO_GIGAN_SHM() {
		return COMM_BO_GIGAN_SHM;
	}
	public void setCOMM_BO_GIGAN_SHM(String cOMM_BO_GIGAN_SHM) {
		COMM_BO_GIGAN_SHM = cOMM_BO_GIGAN_SHM;
	}
	public String getCOMM_BO_GIGAN_EYMD() {
		return COMM_BO_GIGAN_EYMD;
	}
	public void setCOMM_BO_GIGAN_EYMD(String cOMM_BO_GIGAN_EYMD) {
		COMM_BO_GIGAN_EYMD = cOMM_BO_GIGAN_EYMD;
	}
	public String getCOMM_BO_GIGAN_EHM() {
		return COMM_BO_GIGAN_EHM;
	}
	public void setCOMM_BO_GIGAN_EHM(String cOMM_BO_GIGAN_EHM) {
		COMM_BO_GIGAN_EHM = cOMM_BO_GIGAN_EHM;
	}
	public String getCOMM_HALIN_YUL() {
		return COMM_HALIN_YUL;
	}
	public void setCOMM_HALIN_YUL(String cOMM_HALIN_YUL) {
		COMM_HALIN_YUL = cOMM_HALIN_YUL;
	}
	public String getCOMM_OUT_FILLER() {
		return COMM_OUT_FILLER;
	}
	public void setCOMM_OUT_FILLER(String cOMM_OUT_FILLER) {
		COMM_OUT_FILLER = cOMM_OUT_FILLER;
	}
//	public String[] getCOMM_PIBO_JUMIN_NO() {
//		return COMM_PIBO_JUMIN_NO;
//	}
//	public void setCOMM_PIBO_JUMIN_NO(String[] cOMM_PIBO_JUMIN_NO) {
//		COMM_PIBO_JUMIN_NO = cOMM_PIBO_JUMIN_NO;
//	}
//	public String[] getH_COMM_PIBO_NM() {
//		return H_COMM_PIBO_NM;
//	}
//	public void setH_COMM_PIBO_NM(String[] h_COMM_PIBO_NM) {
//		H_COMM_PIBO_NM = h_COMM_PIBO_NM;
//	}
	public String[] getCOMM_PLAN_CD() {
		return COMM_PLAN_CD;
	}
	public void setCOMM_PLAN_CD(String[] cOMM_PLAN_CD) {
		COMM_PLAN_CD = cOMM_PLAN_CD;
	}
	public String[] getCOMM_PLAN_PRM() {
		return COMM_PLAN_PRM;
	}
	public void setCOMM_PLAN_PRM(String[] cOMM_PLAN_PRM) {
		COMM_PLAN_PRM = cOMM_PLAN_PRM;
	}
	public String getCOMM_PIBO_JUMIN_NO() {
		return COMM_PIBO_JUMIN_NO;
	}
	public void setCOMM_PIBO_JUMIN_NO(String cOMM_PIBO_JUMIN_NO) {
		COMM_PIBO_JUMIN_NO = cOMM_PIBO_JUMIN_NO;
	}
	public String getH_COMM_PIBO_NM() {
		return H_COMM_PIBO_NM;
	}
	public void setH_COMM_PIBO_NM(String h_COMM_PIBO_NM) {
		H_COMM_PIBO_NM = h_COMM_PIBO_NM;
	}
	public String[] getCOMM_DAMBO_CD() {
		return COMM_DAMBO_CD;
	}
	public void setCOMM_DAMBO_CD(String[] cOMM_DAMBO_CD) {
		COMM_DAMBO_CD = cOMM_DAMBO_CD;
	}
	public String[] getCOMM_GONGJE_GMEK() {
		return COMM_GONGJE_GMEK;
	}
	public void setCOMM_GONGJE_GMEK(String[] cOMM_GONGJE_GMEK) {
		COMM_GONGJE_GMEK = cOMM_GONGJE_GMEK;
	}
	public List<Map<String, Object>> getLOOP_DATA1() {
		return LOOP_DATA1;
	}
	public void setLOOP_DATA1(List<Map<String, Object>> lOOP_DATA1) {
		LOOP_DATA1 = lOOP_DATA1;
	}
	public List<Map<String, Object>> getLOOP_DATA2() {
		return LOOP_DATA2;
	}
	public void setLOOP_DATA2(List<Map<String, Object>> lOOP_DATA2) {
		LOOP_DATA2 = lOOP_DATA2;
	}
	
	
}
