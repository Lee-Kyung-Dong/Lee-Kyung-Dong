package com.idongbu.smartcustomer.vo;

public class SubFUA6010RVO {
	public String HJ_BJ_NM			= null;		
	public String JJ_POLI_NO        = null;
	public String HJ_SANGTE_NM      = null;
	public String JJ_GISAN_GM       = null;
	public String JJ_NAPIP_YMD      = null;
	public String JJ_IYUL           = null;
	public String JJ_GANUNG_GB      = null;
	public String JJ_GANUNG_GM      = null;
	public String JJ_ICHE_D         = null;
	public String JJ_BANK_CD        = null;
	public String JJ_GYEJWA_NO      = null;
	public String JJ_S_GANUNG_GB    = null;
	public String HJ_BANK_NM        = null;
	public String JJ_IJ_BANK_CD     = null;
	public String JJ_IJ_GYEJWA_NO   = null;
	public String HJ_IJ_BANK_NM     = null;
	public String JJ_S_BANK_CD      = null;
	public String JJ_S_GYEJWA_NO    = null;
	public String HJ_S_BANK_NM      = null;
	public String getHJ_BJ_NM() {
		return HJ_BJ_NM;
	}
	public void setHJ_BJ_NM(String hJ_BJ_NM) {
		HJ_BJ_NM = hJ_BJ_NM;
	}
	public String getJJ_POLI_NO() {
		return JJ_POLI_NO;
	}
	public void setJJ_POLI_NO(String jJ_POLI_NO) {
		JJ_POLI_NO = jJ_POLI_NO;
	}
	public String getHJ_SANGTE_NM() {
		return HJ_SANGTE_NM;
	}
	public void setHJ_SANGTE_NM(String hJ_SANGTE_NM) {
		HJ_SANGTE_NM = hJ_SANGTE_NM;
	}
	public String getJJ_GISAN_GM() {
		return JJ_GISAN_GM;
	}
	public void setJJ_GISAN_GM(String jJ_GISAN_GM) {
		JJ_GISAN_GM = jJ_GISAN_GM;
	}
	public String getJJ_NAPIP_YMD() {
		return JJ_NAPIP_YMD;
	}
	public void setJJ_NAPIP_YMD(String jJ_NAPIP_YMD) {
		JJ_NAPIP_YMD = jJ_NAPIP_YMD;
	}
	public String getJJ_IYUL() {
		return JJ_IYUL;
	}
	public void setJJ_IYUL(String jJ_IYUL) {
		JJ_IYUL = jJ_IYUL;
	}
	public String getJJ_GANUNG_GB() {
		return JJ_GANUNG_GB;
	}
	public void setJJ_GANUNG_GB(String jJ_GANUNG_GB) {
		JJ_GANUNG_GB = jJ_GANUNG_GB;
	}
	public String getJJ_GANUNG_GM() {
		return JJ_GANUNG_GM;
	}
	public void setJJ_GANUNG_GM(String jJ_GANUNG_GM) {
		JJ_GANUNG_GM = jJ_GANUNG_GM;
	}
	public String getJJ_ICHE_D() {
		return JJ_ICHE_D;
	}
	public void setJJ_ICHE_D(String jJ_ICHE_D) {
		JJ_ICHE_D = jJ_ICHE_D;
	}
	public String getJJ_BANK_CD() {
		return JJ_BANK_CD;
	}
	public void setJJ_BANK_CD(String jJ_BANK_CD) {
		JJ_BANK_CD = jJ_BANK_CD;
	}
	public String getJJ_GYEJWA_NO() {
		return JJ_GYEJWA_NO;
	}
	public void setJJ_GYEJWA_NO(String jJ_GYEJWA_NO) {
		JJ_GYEJWA_NO = jJ_GYEJWA_NO;
	}
	public String getJJ_S_GANUNG_GB() {
		return JJ_S_GANUNG_GB;
	}
	public void setJJ_S_GANUNG_GB(String jJ_S_GANUNG_GB) {
		JJ_S_GANUNG_GB = jJ_S_GANUNG_GB;
	}
	public String getHJ_BANK_NM() {
		return HJ_BANK_NM;
	}
	public void setHJ_BANK_NM(String hJ_BANK_NM) {
		HJ_BANK_NM = hJ_BANK_NM;
	}
	public String getJJ_IJ_BANK_CD() {
		return JJ_IJ_BANK_CD;
	}
	public void setJJ_IJ_BANK_CD(String jJ_IJ_BANK_CD) {
		JJ_IJ_BANK_CD = jJ_IJ_BANK_CD;
	}
	public String getJJ_IJ_GYEJWA_NO() {
		return JJ_IJ_GYEJWA_NO;
	}
	public void setJJ_IJ_GYEJWA_NO(String jJ_IJ_GYEJWA_NO) {
		JJ_IJ_GYEJWA_NO = jJ_IJ_GYEJWA_NO;
	}
	public String getHJ_IJ_BANK_NM() {
		return HJ_IJ_BANK_NM;
	}
	public void setHJ_IJ_BANK_NM(String hJ_IJ_BANK_NM) {
		HJ_IJ_BANK_NM = hJ_IJ_BANK_NM;
	}
	public String getJJ_S_BANK_CD() {
		return JJ_S_BANK_CD;
	}
	public void setJJ_S_BANK_CD(String jJ_S_BANK_CD) {
		JJ_S_BANK_CD = jJ_S_BANK_CD;
	}
	public String getJJ_S_GYEJWA_NO() {
		return JJ_S_GYEJWA_NO;
	}
	public void setJJ_S_GYEJWA_NO(String jJ_S_GYEJWA_NO) {
		JJ_S_GYEJWA_NO = jJ_S_GYEJWA_NO;
	}
	public String getHJ_S_BANK_NM() {
		return HJ_S_BANK_NM;
	}
	public void setHJ_S_BANK_NM(String hJ_S_BANK_NM) {
		HJ_S_BANK_NM = hJ_S_BANK_NM;
	}
}
