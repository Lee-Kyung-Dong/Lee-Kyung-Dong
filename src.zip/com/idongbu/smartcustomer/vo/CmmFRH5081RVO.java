package com.idongbu.smartcustomer.vo;

import java.util.List;
import java.util.Map;

import com.idongbu.common.vo.CMMVO;

public class CmmFRH5081RVO extends CMMVO {

	public CmmFRH5081RVO() {
		super.setPGMID(this.proid);
		super.setTRID(this.trid);
	}		
	
	private static final String proid	= "FRH5081R";        
	private static final String trid	= "RHVB";                    
	private String rURL			        = "";
                                       
	private String LK_TRID		        = "";
	private String LK_FLAG		        = "";
	private String LK_NT_CD		        = "";
	private String LK_RSP_TIME		    = "";
	private String LK_COMP_GB		    = "";
	private String LK_COMP_CD		    = "";
	private String LK_FILLER		    = "";
	private String LK_USER_ID		    = "";
	private String LK_PART_GB1		    = "";
	private String LK_PART_GB2		    = "";
	private String LK_UPMU_CD1		    = "";
	private String LK_UPMU_CD2		    = "";
	private String LK_UPMU_CD3		    = "";
	private String LK_GULK_GB		    = "";
	private String LK_CM_FILLER		    = "";
	private String LK_RETURN_CD		    = "";
	private String LK_MSG_CD1		    = "";
	private String LK_MSG_CD2		    = "";
	private String H_LK_MESSAGE1	    = "";
	private String H_LK_MESSAGE2	    = "";
	private String LK_SAGO_NO		    = "";
	/*
	private String[] LK_MOKJUK_GB	    = new String[0]; // 20
	private String[] LK_MOKJUK_SEQ	    = new String[0]; // 20
	private String[] LK_PIBO_NM		    = new String[0]; // 20
	private String[] LK_PIBO_JUMIN_NO   = new String[0]; // 20
	private String[] LK_JINHENG_GUAJUNG = new String[0]; // 20
	private String[] LK_JINHENG_STAT 	= new String[0]; // 20
	private String[] LK_JOJIKWON_CD		= new String[0]; // 20
	private String[] LK_DAMDANGJA		= new String[0]; // 20
	private String[] LK_TEL_NO		    = new String[0]; // 20
	private String[] LK_OFF_TEL_NO		= new String[0]; // 20
	*/
	private String FILLER		        = "";
	private List<Map<String, String>> LOOP_DATA  = null;
	
	public String getrURL() {
		return rURL;
	}
	public void setrURL(String rURL) {
		this.rURL = rURL;
	}
	public String getLK_TRID() {
		return LK_TRID;
	}
	public void setLK_TRID(String lK_TRID) {
		LK_TRID = lK_TRID;
	}
	public String getLK_FLAG() {
		return LK_FLAG;
	}
	public void setLK_FLAG(String lK_FLAG) {
		LK_FLAG = lK_FLAG;
	}
	public String getLK_NT_CD() {
		return LK_NT_CD;
	}
	public void setLK_NT_CD(String lK_NT_CD) {
		LK_NT_CD = lK_NT_CD;
	}
	public String getLK_RSP_TIME() {
		return LK_RSP_TIME;
	}
	public void setLK_RSP_TIME(String lK_RSP_TIME) {
		LK_RSP_TIME = lK_RSP_TIME;
	}
	public String getLK_COMP_GB() {
		return LK_COMP_GB;
	}
	public void setLK_COMP_GB(String lK_COMP_GB) {
		LK_COMP_GB = lK_COMP_GB;
	}
	public String getLK_COMP_CD() {
		return LK_COMP_CD;
	}
	public void setLK_COMP_CD(String lK_COMP_CD) {
		LK_COMP_CD = lK_COMP_CD;
	}
	public String getLK_FILLER() {
		return LK_FILLER;
	}
	public void setLK_FILLER(String lK_FILLER) {
		LK_FILLER = lK_FILLER;
	}
	public String getLK_USER_ID() {
		return LK_USER_ID;
	}
	public void setLK_USER_ID(String lK_USER_ID) {
		LK_USER_ID = lK_USER_ID;
	}
	public String getLK_PART_GB1() {
		return LK_PART_GB1;
	}
	public void setLK_PART_GB1(String lK_PART_GB1) {
		LK_PART_GB1 = lK_PART_GB1;
	}
	public String getLK_PART_GB2() {
		return LK_PART_GB2;
	}
	public void setLK_PART_GB2(String lK_PART_GB2) {
		LK_PART_GB2 = lK_PART_GB2;
	}
	public String getLK_UPMU_CD1() {
		return LK_UPMU_CD1;
	}
	public void setLK_UPMU_CD1(String lK_UPMU_CD1) {
		LK_UPMU_CD1 = lK_UPMU_CD1;
	}
	public String getLK_UPMU_CD2() {
		return LK_UPMU_CD2;
	}
	public void setLK_UPMU_CD2(String lK_UPMU_CD2) {
		LK_UPMU_CD2 = lK_UPMU_CD2;
	}
	public String getLK_UPMU_CD3() {
		return LK_UPMU_CD3;
	}
	public void setLK_UPMU_CD3(String lK_UPMU_CD3) {
		LK_UPMU_CD3 = lK_UPMU_CD3;
	}
	public String getLK_GULK_GB() {
		return LK_GULK_GB;
	}
	public void setLK_GULK_GB(String lK_GULK_GB) {
		LK_GULK_GB = lK_GULK_GB;
	}
	public String getLK_CM_FILLER() {
		return LK_CM_FILLER;
	}
	public void setLK_CM_FILLER(String lK_CM_FILLER) {
		LK_CM_FILLER = lK_CM_FILLER;
	}
	public String getLK_RETURN_CD() {
		return LK_RETURN_CD;
	}
	public void setLK_RETURN_CD(String lK_RETURN_CD) {
		LK_RETURN_CD = lK_RETURN_CD;
	}
	public String getLK_MSG_CD1() {
		return LK_MSG_CD1;
	}
	public void setLK_MSG_CD1(String lK_MSG_CD1) {
		LK_MSG_CD1 = lK_MSG_CD1;
	}
	public String getLK_MSG_CD2() {
		return LK_MSG_CD2;
	}
	public void setLK_MSG_CD2(String lK_MSG_CD2) {
		LK_MSG_CD2 = lK_MSG_CD2;
	}
	public String getH_LK_MESSAGE1() {
		return H_LK_MESSAGE1;
	}
	public void setH_LK_MESSAGE1(String h_LK_MESSAGE1) {
		H_LK_MESSAGE1 = h_LK_MESSAGE1;
	}
	public String getH_LK_MESSAGE2() {
		return H_LK_MESSAGE2;
	}
	public void setH_LK_MESSAGE2(String h_LK_MESSAGE2) {
		H_LK_MESSAGE2 = h_LK_MESSAGE2;
	}
	public String getLK_SAGO_NO() {
		return LK_SAGO_NO;
	}
	public void setLK_SAGO_NO(String lK_SAGO_NO) {
		LK_SAGO_NO = lK_SAGO_NO;
	}
	public String getFILLER() {
		return FILLER;
	}
	public void setFILLER(String fILLER) {
		FILLER = fILLER;
	}
	public List<Map<String, String>> getLOOP_DATA() {
		return LOOP_DATA;
	}
	public void setLOOP_DATA(List<Map<String, String>> lOOP_DATA) {
		LOOP_DATA = lOOP_DATA;
	}
	public static String getProid() {
		return proid;
	}
	public static String getTrid() {
		return trid;
	}	
}
