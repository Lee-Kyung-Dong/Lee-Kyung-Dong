/**
 * 우편물수령처변경전문
 */
package com.idongbu.smartcustomer.vo;
import java.util.List;

import com.idongbu.common.vo.CMMVO;

public class CmmFBM0300RVO extends CMMVO {
	
	public CmmFBM0300RVO() {
		super.setPGMID(proid);
		super.setTRID(trid);
	}	
	
	public final static String proid			= "FBM0300R";
	public final static String trid			= "BMY6";
	
	//COMMON-AREA	<< 시스템공통 >>
	public String COMM_CHANNEL          = "";	//입력채널구분				1.영업포탈 2.콜센타 3.홈페이지 4.제휴사 
	public String COMM_UNIQUE_KEY       = "";   //TSO,VSAMFILE사용키        SERVER에서 SEQUENTIAL하게 부여
	public String COMM_PGMID            = "";   //PROGRAM-ID                0Q를 사용하는경우사용 (생략가능)
	public String COMM_PROC_GB          = "";   //처리구분                  0. 0Q사용 1.정상거래
	public String COMM_ACTION_KEY       = "";   //기능키                    PU:Up,PD:Down,01~xx:Function Key
	public String COMM_USER_GB          = "";   //사용자ID구분              사용자구분
	public String COMM_USER_ID          = "";   //사용자ID                  사용자ID
	public String COMM_JIJUM_CD         = "";   //사용자지점                사용자지점코드
	public String COMM_JIBU_CD          = "";   //사용자지부                사용자지부코드
	public String COMM_PROTOCOL         = "";   //출력구분                  S.SCREEN  P.PRINTER
	public String COMM_COND_CD          = "";   //처리결과                  01.정상
	public String COMM_LAST_FLAG        = "";   //마지막자료여부            `
	public String COMM_CURSOR_MAP       = "";   //CURSOR POINT - MAP        커서위치화면
	public String COMM_CURSOR_IDX       = "";   //CURSOR POINT - INDEX      커서위치INDEX
	public String COMM_MESSAGE_CD       = "";   //화면 출력 MESSAGE-CD      출력메세지코드
	public String H_COMM_MESSAGE_NM     = "";   //화면 출력 MESSAGE         출력메세지
	public String COMM_ERR_NAME         = "";   //SYSTEM ERROR              SYSTEM ERROR
	public String COMM_ERR_TEXT         = "";   //SYSTEM ERROR              SYSTEM ERROR
	public String COMM_SYS_CODE         = "";   //SYSTEM ERROR              SQLCODE
	public String FILLER      = "";      		//공백
	
	//SCREEN-DATA-AREA	<< 화면데이타부 >>
	//KEY-DATA
	public String SI_GUBUN               = "";  //구분
	public String SI_GOGEK_NO            = "";  //고객명
	
	//SCREEN-DATA
	public String HO_GOGEK_NM            = "";  //고객명
	public String SO_H_ZIP               = "";  //집우편번호
	public String HO_H_JUSO              = "";  //집우편번호주소
	public String HO_H_ADDR              = "";  //집기타주소
	public String SO_J_ZIP               = "";  //직장우편번호
	public String HO_J_JUSO              = "";  //직장우편번호주소
	public String HO_J_ADDR              = "";  //직장기타주소
	public String SO_G_ZIP               = "";  //기타우편번호
	public String HO_G_JUSO              = "";  //기타우편번호주소
	public String HO_G_ADDR              = "";  //기타기타주소
	public String SO_ST_H_ZIP            = "";  //새주소 집우편번호
	public String HO_ST_H_ADDR           = "";  //새주소 집우편번호주소
	public String HO_ST_H_GITA           = "";  //새주소 집기타주소
	public String SO_ST_J_ZIP            = "";  //새주소 직장우편번호
	public String HO_ST_J_ADDR           = "";  //새주소 직장우편번호주소
	public String HO_ST_J_GITA           = "";  //새주소 직장기타주소
	public String SO_ST_G_ZIP            = "";  //새주소 기타우편번호
	public String HO_ST_G_ADDR           = "";  //새주소 기타우편번호주소
	public String HO_ST_G_GITA           = "";  //새주소 기타기타주소

	public List<SubFBM0300RVO> LIST_DATA = null;
	public List<SubFBM0300RVO> LOOP_DATA = null;
	
	public String[] SI_L_SELECT_FLAG = new String[0]; // 10
	public String[] SO_L_POLI_NO = new String[0]; // 10
	public String[] HO_L_CAR_NO = new String[0]; // 10
	public String[] SO_L_BOJONG_CD = new String[0]; // 10
	public String[] HO_L_BOJONG_NM = new String[0]; // 10
	public String[] SO_L_GOGEK_GB = new String[0]; // 10
	public String[] HO_L_GOGEK_GB_NM = new String[0]; // 10
	public String[] SO_L_BOHUM_SYMD = new String[0]; // 10
	public String[] SO_L_BOHUM_EYMD = new String[0]; // 10
	public String[] SO_L_GEYAK_SANGTE = new String[0]; // 10
	public String[] HO_L_GEYAK_SANGTE_NM = new String[0]; // 10
	public String[] SI_L_SURYUNG_GB = new String[0]; // 10
	public String[] SI_L_SINGU_GB = new String[0]; // 10

	public String[] inpd_dvcd = new String[0]; // 10
	public String[] eta_dpp_mngt_no = new String[0]; // 10
	
	//USER-DATA-AREA	<< 사용자데이타부 >>
	public String UD_FK_POLI_NO          = "";  //
	public String UD_LK_POLI_NO          = "";  //
	public String UD_UK_POLI_NO          = "";  //
	public String resultmsg          	 = "";  //
	public String HOMM_MESSAGE_NM		 = "";
	
	public String getCOMM_CHANNEL() {
		return COMM_CHANNEL;
	}
	public void setCOMM_CHANNEL(String cOMM_CHANNEL) {
		COMM_CHANNEL = cOMM_CHANNEL;
	}
	public String getCOMM_UNIQUE_KEY() {
		return COMM_UNIQUE_KEY;
	}
	public void setCOMM_UNIQUE_KEY(String cOMM_UNIQUE_KEY) {
		COMM_UNIQUE_KEY = cOMM_UNIQUE_KEY;
	}
	public String getCOMM_PGMID() {
		return COMM_PGMID;
	}
	public void setCOMM_PGMID(String cOMM_PGMID) {
		COMM_PGMID = cOMM_PGMID;
	}
	public String getCOMM_PROC_GB() {
		return COMM_PROC_GB;
	}
	public void setCOMM_PROC_GB(String cOMM_PROC_GB) {
		COMM_PROC_GB = cOMM_PROC_GB;
	}
	public String getCOMM_ACTION_KEY() {
		return COMM_ACTION_KEY;
	}
	public void setCOMM_ACTION_KEY(String cOMM_ACTION_KEY) {
		COMM_ACTION_KEY = cOMM_ACTION_KEY;
	}
	public String getCOMM_USER_GB() {
		return COMM_USER_GB;
	}
	public void setCOMM_USER_GB(String cOMM_USER_GB) {
		COMM_USER_GB = cOMM_USER_GB;
	}
	public String getCOMM_USER_ID() {
		return COMM_USER_ID;
	}
	public void setCOMM_USER_ID(String cOMM_USER_ID) {
		COMM_USER_ID = cOMM_USER_ID;
	}
	public String getCOMM_JIJUM_CD() {
		return COMM_JIJUM_CD;
	}
	public void setCOMM_JIJUM_CD(String cOMM_JIJUM_CD) {
		COMM_JIJUM_CD = cOMM_JIJUM_CD;
	}
	public String getCOMM_JIBU_CD() {
		return COMM_JIBU_CD;
	}
	public void setCOMM_JIBU_CD(String cOMM_JIBU_CD) {
		COMM_JIBU_CD = cOMM_JIBU_CD;
	}
	public String getCOMM_PROTOCOL() {
		return COMM_PROTOCOL;
	}
	public void setCOMM_PROTOCOL(String cOMM_PROTOCOL) {
		COMM_PROTOCOL = cOMM_PROTOCOL;
	}
	public String getCOMM_COND_CD() {
		return COMM_COND_CD;
	}
	public void setCOMM_COND_CD(String cOMM_COND_CD) {
		COMM_COND_CD = cOMM_COND_CD;
	}
	public String getCOMM_LAST_FLAG() {
		return COMM_LAST_FLAG;
	}
	public void setCOMM_LAST_FLAG(String cOMM_LAST_FLAG) {
		COMM_LAST_FLAG = cOMM_LAST_FLAG;
	}
	public String getCOMM_CURSOR_MAP() {
		return COMM_CURSOR_MAP;
	}
	public void setCOMM_CURSOR_MAP(String cOMM_CURSOR_MAP) {
		COMM_CURSOR_MAP = cOMM_CURSOR_MAP;
	}
	public String getCOMM_CURSOR_IDX() {
		return COMM_CURSOR_IDX;
	}
	public void setCOMM_CURSOR_IDX(String cOMM_CURSOR_IDX) {
		COMM_CURSOR_IDX = cOMM_CURSOR_IDX;
	}
	public String getCOMM_MESSAGE_CD() {
		return COMM_MESSAGE_CD;
	}
	public void setCOMM_MESSAGE_CD(String cOMM_MESSAGE_CD) {
		COMM_MESSAGE_CD = cOMM_MESSAGE_CD;
	}
	public String getH_COMM_MESSAGE_NM() {
		return H_COMM_MESSAGE_NM;
	}
	public void setH_COMM_MESSAGE_NM(String h_COMM_MESSAGE_NM) {
		H_COMM_MESSAGE_NM = h_COMM_MESSAGE_NM;
	}
	public String getCOMM_ERR_NAME() {
		return COMM_ERR_NAME;
	}
	public void setCOMM_ERR_NAME(String cOMM_ERR_NAME) {
		COMM_ERR_NAME = cOMM_ERR_NAME;
	}
	public String getCOMM_ERR_TEXT() {
		return COMM_ERR_TEXT;
	}
	public void setCOMM_ERR_TEXT(String cOMM_ERR_TEXT) {
		COMM_ERR_TEXT = cOMM_ERR_TEXT;
	}
	public String getCOMM_SYS_CODE() {
		return COMM_SYS_CODE;
	}
	public void setCOMM_SYS_CODE(String cOMM_SYS_CODE) {
		COMM_SYS_CODE = cOMM_SYS_CODE;
	}
	public String getFILLER() {
		return FILLER;
	}
	public void setFILLER(String fILLER) {
		FILLER = fILLER;
	}
	public String getSI_GUBUN() {
		return SI_GUBUN;
	}
	public void setSI_GUBUN(String sI_GUBUN) {
		SI_GUBUN = sI_GUBUN;
	}
	public String getSI_GOGEK_NO() {
		return SI_GOGEK_NO;
	}
	public void setSI_GOGEK_NO(String sI_GOGEK_NO) {
		SI_GOGEK_NO = sI_GOGEK_NO;
	}
	public String getHO_GOGEK_NM() {
		return HO_GOGEK_NM;
	}
	public void setHO_GOGEK_NM(String hO_GOGEK_NM) {
		HO_GOGEK_NM = hO_GOGEK_NM;
	}
	public String getSO_H_ZIP() {
		return SO_H_ZIP;
	}
	public void setSO_H_ZIP(String sO_H_ZIP) {
		SO_H_ZIP = sO_H_ZIP;
	}
	public String getHO_H_JUSO() {
		return HO_H_JUSO;
	}
	public void setHO_H_JUSO(String hO_H_JUSO) {
		HO_H_JUSO = hO_H_JUSO;
	}
	public String getHO_H_ADDR() {
		return HO_H_ADDR;
	}
	public void setHO_H_ADDR(String hO_H_ADDR) {
		HO_H_ADDR = hO_H_ADDR;
	}
	public String getSO_J_ZIP() {
		return SO_J_ZIP;
	}
	public void setSO_J_ZIP(String sO_J_ZIP) {
		SO_J_ZIP = sO_J_ZIP;
	}
	public String getHO_J_JUSO() {
		return HO_J_JUSO;
	}
	public void setHO_J_JUSO(String hO_J_JUSO) {
		HO_J_JUSO = hO_J_JUSO;
	}
	public String getHO_J_ADDR() {
		return HO_J_ADDR;
	}
	public void setHO_J_ADDR(String hO_J_ADDR) {
		HO_J_ADDR = hO_J_ADDR;
	}
	public String getSO_G_ZIP() {
		return SO_G_ZIP;
	}
	public void setSO_G_ZIP(String sO_G_ZIP) {
		SO_G_ZIP = sO_G_ZIP;
	}
	public String getHO_G_JUSO() {
		return HO_G_JUSO;
	}
	public void setHO_G_JUSO(String hO_G_JUSO) {
		HO_G_JUSO = hO_G_JUSO;
	}
	public String getHO_G_ADDR() {
		return HO_G_ADDR;
	}
	public void setHO_G_ADDR(String hO_G_ADDR) {
		HO_G_ADDR = hO_G_ADDR;
	}
	public String getSO_ST_H_ZIP() {
		return SO_ST_H_ZIP;
	}
	public void setSO_ST_H_ZIP(String sO_ST_H_ZIP) {
		SO_ST_H_ZIP = sO_ST_H_ZIP;
	}
	public String getHO_ST_H_ADDR() {
		return HO_ST_H_ADDR;
	}
	public void setHO_ST_H_ADDR(String hO_ST_H_ADDR) {
		HO_ST_H_ADDR = hO_ST_H_ADDR;
	}
	public String getHO_ST_H_GITA() {
		return HO_ST_H_GITA;
	}
	public void setHO_ST_H_GITA(String hO_ST_H_GITA) {
		HO_ST_H_GITA = hO_ST_H_GITA;
	}
	public String getSO_ST_J_ZIP() {
		return SO_ST_J_ZIP;
	}
	public void setSO_ST_J_ZIP(String sO_ST_J_ZIP) {
		SO_ST_J_ZIP = sO_ST_J_ZIP;
	}
	public String getHO_ST_J_ADDR() {
		return HO_ST_J_ADDR;
	}
	public void setHO_ST_J_ADDR(String hO_ST_J_ADDR) {
		HO_ST_J_ADDR = hO_ST_J_ADDR;
	}
	public String getHO_ST_J_GITA() {
		return HO_ST_J_GITA;
	}
	public void setHO_ST_J_GITA(String hO_ST_J_GITA) {
		HO_ST_J_GITA = hO_ST_J_GITA;
	}
	public String getSO_ST_G_ZIP() {
		return SO_ST_G_ZIP;
	}
	public void setSO_ST_G_ZIP(String sO_ST_G_ZIP) {
		SO_ST_G_ZIP = sO_ST_G_ZIP;
	}
	public String getHO_ST_G_ADDR() {
		return HO_ST_G_ADDR;
	}
	public void setHO_ST_G_ADDR(String hO_ST_G_ADDR) {
		HO_ST_G_ADDR = hO_ST_G_ADDR;
	}
	public String getHO_ST_G_GITA() {
		return HO_ST_G_GITA;
	}
	public void setHO_ST_G_GITA(String hO_ST_G_GITA) {
		HO_ST_G_GITA = hO_ST_G_GITA;
	}
	public String getUD_FK_POLI_NO() {
		return UD_FK_POLI_NO;
	}
	public void setUD_FK_POLI_NO(String uD_FK_POLI_NO) {
		UD_FK_POLI_NO = uD_FK_POLI_NO;
	}
	public String getUD_LK_POLI_NO() {
		return UD_LK_POLI_NO;
	}
	public void setUD_LK_POLI_NO(String uD_LK_POLI_NO) {
		UD_LK_POLI_NO = uD_LK_POLI_NO;
	}
	public String getUD_UK_POLI_NO() {
		return UD_UK_POLI_NO;
	}
	public void setUD_UK_POLI_NO(String uD_UK_POLI_NO) {
		UD_UK_POLI_NO = uD_UK_POLI_NO;
	}
	public List<SubFBM0300RVO> getLIST_DATA() {
		return LIST_DATA;
	}
	public void setLIST_DATA(List<SubFBM0300RVO> lIST_DATA) {
		LIST_DATA = lIST_DATA;
	}
	public String getResultmsg() {
		return resultmsg;
	}
	public void setResultmsg(String resultmsg) {
		this.resultmsg = resultmsg;
	}
	public List<SubFBM0300RVO> getLOOP_DATA() {
		return LOOP_DATA;
	}
	public void setLOOP_DATA(List<SubFBM0300RVO> lOOP_DATA) {
		LOOP_DATA = lOOP_DATA;
	}
	public String[] getSI_L_SELECT_FLAG() {
		return SI_L_SELECT_FLAG;
	}
	public void setSI_L_SELECT_FLAG(String[] sI_L_SELECT_FLAG) {
		SI_L_SELECT_FLAG = sI_L_SELECT_FLAG;
	}
	public String[] getSO_L_POLI_NO() {
		return SO_L_POLI_NO;
	}
	public void setSO_L_POLI_NO(String[] sO_L_POLI_NO) {
		SO_L_POLI_NO = sO_L_POLI_NO;
	}
	public String[] getHO_L_CAR_NO() {
		return HO_L_CAR_NO;
	}
	public void setHO_L_CAR_NO(String[] hO_L_CAR_NO) {
		HO_L_CAR_NO = hO_L_CAR_NO;
	}
	public String[] getSO_L_BOJONG_CD() {
		return SO_L_BOJONG_CD;
	}
	public void setSO_L_BOJONG_CD(String[] sO_L_BOJONG_CD) {
		SO_L_BOJONG_CD = sO_L_BOJONG_CD;
	}
	public String[] getHO_L_BOJONG_NM() {
		return HO_L_BOJONG_NM;
	}
	public void setHO_L_BOJONG_NM(String[] hO_L_BOJONG_NM) {
		HO_L_BOJONG_NM = hO_L_BOJONG_NM;
	}
	public String[] getSO_L_GOGEK_GB() {
		return SO_L_GOGEK_GB;
	}
	public void setSO_L_GOGEK_GB(String[] sO_L_GOGEK_GB) {
		SO_L_GOGEK_GB = sO_L_GOGEK_GB;
	}
	public String[] getHO_L_GOGEK_GB_NM() {
		return HO_L_GOGEK_GB_NM;
	}
	public void setHO_L_GOGEK_GB_NM(String[] hO_L_GOGEK_GB_NM) {
		HO_L_GOGEK_GB_NM = hO_L_GOGEK_GB_NM;
	}
	public String[] getSO_L_BOHUM_SYMD() {
		return SO_L_BOHUM_SYMD;
	}
	public void setSO_L_BOHUM_SYMD(String[] sO_L_BOHUM_SYMD) {
		SO_L_BOHUM_SYMD = sO_L_BOHUM_SYMD;
	}
	public String[] getSO_L_BOHUM_EYMD() {
		return SO_L_BOHUM_EYMD;
	}
	public void setSO_L_BOHUM_EYMD(String[] sO_L_BOHUM_EYMD) {
		SO_L_BOHUM_EYMD = sO_L_BOHUM_EYMD;
	}
	public String[] getSO_L_GEYAK_SANGTE() {
		return SO_L_GEYAK_SANGTE;
	}
	public void setSO_L_GEYAK_SANGTE(String[] sO_L_GEYAK_SANGTE) {
		SO_L_GEYAK_SANGTE = sO_L_GEYAK_SANGTE;
	}
	public String[] getHO_L_GEYAK_SANGTE_NM() {
		return HO_L_GEYAK_SANGTE_NM;
	}
	public void setHO_L_GEYAK_SANGTE_NM(String[] hO_L_GEYAK_SANGTE_NM) {
		HO_L_GEYAK_SANGTE_NM = hO_L_GEYAK_SANGTE_NM;
	}
	public String[] getSI_L_SURYUNG_GB() {
		return SI_L_SURYUNG_GB;
	}
	public void setSI_L_SURYUNG_GB(String[] sI_L_SURYUNG_GB) {
		SI_L_SURYUNG_GB = sI_L_SURYUNG_GB;
	}
	public String[] getSI_L_SINGU_GB() {
		return SI_L_SINGU_GB;
	}
	public void setSI_L_SINGU_GB(String[] sI_L_SINGU_GB) {
		SI_L_SINGU_GB = sI_L_SINGU_GB;
	}
	public String getHOMM_MESSAGE_NM() {
		return HOMM_MESSAGE_NM;
	}
	public void setHOMM_MESSAGE_NM(String hOMM_MESSAGE_NM) {
		HOMM_MESSAGE_NM = hOMM_MESSAGE_NM;
	}
	public String[] getInpd_dvcd() {
		return inpd_dvcd;
	}
	public void setInpd_dvcd(String[] inpd_dvcd) {
		this.inpd_dvcd = inpd_dvcd;
	}
	public String[] getEta_dpp_mngt_no() {
		return eta_dpp_mngt_no;
	}
	public void setEta_dpp_mngt_no(String[] eta_dpp_mngt_no) {
		this.eta_dpp_mngt_no = eta_dpp_mngt_no;
	}
}
