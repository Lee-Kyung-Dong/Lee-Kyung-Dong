package com.idongbu.smartcustomer.vo;

import com.idongbu.common.vo.CMMVO;

public class CmmFRZ1183RVO extends CMMVO {

	public CmmFRZ1183RVO() {
		super.setPGMID(this.proid);
		super.setTRID(this.trid);
	}
	
	private static final String proid = "FRZ1183R";
	private static final String trid  = "RZF3";
	private String rURL				  = "";

	// 입력
	private String LK_I_SAGO_JUBSU_NO = ""; // 사고접수번호

	// 출력
	private String LK_TRID            = "";
	private String LK_FLAG            = "";
	private String LK_NT_CD           = "";
	private String LK_RSP_TIME        = "";
	private String LK_COMP_GB         = "";
	private String LK_COMP_CD         = "";
	private String LK_FILLER          = "";
	private String LK_USER_ID         = "";
	private String LK_PART_GB1        = "";
	private String LK_PART_GB2        = "";
	private String LK_UPMU_CD1        = "";
	private String LK_UPMU_CD2        = "";
	private String LK_UPMU_CD3        = "";
	private String LK_GULK_GB         = "";
	private String LK_CM_FILLER       = "";
	private String LK_RETURN_CD       = "";
	private String LK_MSG_CD1         = "";
	private String LK_MSG_CD2         = "";
	private String H_LK_MESSAGE1      = "";
	private String H_LK_MESSAGE2      = "";
	private String LK_SAGO_TYPE_NAME  = "";
	private String LK_SAGO_TYPE_NAME2 = "";
	private String LK_GWASIL_GB       = "";
	private String LK_GWASIL_NAME     = "";
	private String LK_POLICE_SINGO    = "";
	private String LK_SAGO_CONT       = "";
	private String LK_BR_NAME         = "";
	private String LK_TEAM_NAME       = "";
	private String LK_DAMDANGJA       = "";
	private String LK_DAMDANG_TEL     = "";
	private String FILLER             = "";
	
	public String getrURL() {
		return rURL;
	}
	public void setrURL(String rURL) {
		this.rURL = rURL;
	}
	public String getLK_I_SAGO_JUBSU_NO() {
		return LK_I_SAGO_JUBSU_NO;
	}
	public void setLK_I_SAGO_JUBSU_NO(String lK_I_SAGO_JUBSU_NO) {
		LK_I_SAGO_JUBSU_NO = lK_I_SAGO_JUBSU_NO;
	}
	public String getLK_TRID() {
		return LK_TRID;
	}
	public void setLK_TRID(String lK_TRID) {
		LK_TRID = lK_TRID;
	}
	public String getLK_FLAG() {
		return LK_FLAG;
	}
	public void setLK_FLAG(String lK_FLAG) {
		LK_FLAG = lK_FLAG;
	}
	public String getLK_NT_CD() {
		return LK_NT_CD;
	}
	public void setLK_NT_CD(String lK_NT_CD) {
		LK_NT_CD = lK_NT_CD;
	}
	public String getLK_RSP_TIME() {
		return LK_RSP_TIME;
	}
	public void setLK_RSP_TIME(String lK_RSP_TIME) {
		LK_RSP_TIME = lK_RSP_TIME;
	}
	public String getLK_COMP_GB() {
		return LK_COMP_GB;
	}
	public void setLK_COMP_GB(String lK_COMP_GB) {
		LK_COMP_GB = lK_COMP_GB;
	}
	public String getLK_COMP_CD() {
		return LK_COMP_CD;
	}
	public void setLK_COMP_CD(String lK_COMP_CD) {
		LK_COMP_CD = lK_COMP_CD;
	}
	public String getLK_FILLER() {
		return LK_FILLER;
	}
	public void setLK_FILLER(String lK_FILLER) {
		LK_FILLER = lK_FILLER;
	}
	public String getLK_USER_ID() {
		return LK_USER_ID;
	}
	public void setLK_USER_ID(String lK_USER_ID) {
		LK_USER_ID = lK_USER_ID;
	}
	public String getLK_PART_GB1() {
		return LK_PART_GB1;
	}
	public void setLK_PART_GB1(String lK_PART_GB1) {
		LK_PART_GB1 = lK_PART_GB1;
	}
	public String getLK_PART_GB2() {
		return LK_PART_GB2;
	}
	public void setLK_PART_GB2(String lK_PART_GB2) {
		LK_PART_GB2 = lK_PART_GB2;
	}
	public String getLK_UPMU_CD1() {
		return LK_UPMU_CD1;
	}
	public void setLK_UPMU_CD1(String lK_UPMU_CD1) {
		LK_UPMU_CD1 = lK_UPMU_CD1;
	}
	public String getLK_UPMU_CD2() {
		return LK_UPMU_CD2;
	}
	public void setLK_UPMU_CD2(String lK_UPMU_CD2) {
		LK_UPMU_CD2 = lK_UPMU_CD2;
	}
	public String getLK_UPMU_CD3() {
		return LK_UPMU_CD3;
	}
	public void setLK_UPMU_CD3(String lK_UPMU_CD3) {
		LK_UPMU_CD3 = lK_UPMU_CD3;
	}
	public String getLK_GULK_GB() {
		return LK_GULK_GB;
	}
	public void setLK_GULK_GB(String lK_GULK_GB) {
		LK_GULK_GB = lK_GULK_GB;
	}
	public String getLK_CM_FILLER() {
		return LK_CM_FILLER;
	}
	public void setLK_CM_FILLER(String lK_CM_FILLER) {
		LK_CM_FILLER = lK_CM_FILLER;
	}
	public String getLK_RETURN_CD() {
		return LK_RETURN_CD;
	}
	public void setLK_RETURN_CD(String lK_RETURN_CD) {
		LK_RETURN_CD = lK_RETURN_CD;
	}
	public String getLK_MSG_CD1() {
		return LK_MSG_CD1;
	}
	public void setLK_MSG_CD1(String lK_MSG_CD1) {
		LK_MSG_CD1 = lK_MSG_CD1;
	}
	public String getLK_MSG_CD2() {
		return LK_MSG_CD2;
	}
	public void setLK_MSG_CD2(String lK_MSG_CD2) {
		LK_MSG_CD2 = lK_MSG_CD2;
	}
	public String getH_LK_MESSAGE1() {
		return H_LK_MESSAGE1;
	}
	public void setH_LK_MESSAGE1(String h_LK_MESSAGE1) {
		H_LK_MESSAGE1 = h_LK_MESSAGE1;
	}
	public String getH_LK_MESSAGE2() {
		return H_LK_MESSAGE2;
	}
	public void setH_LK_MESSAGE2(String h_LK_MESSAGE2) {
		H_LK_MESSAGE2 = h_LK_MESSAGE2;
	}
	public String getLK_SAGO_TYPE_NAME() {
		return LK_SAGO_TYPE_NAME;
	}
	public void setLK_SAGO_TYPE_NAME(String lK_SAGO_TYPE_NAME) {
		LK_SAGO_TYPE_NAME = lK_SAGO_TYPE_NAME;
	}
	public String getLK_SAGO_TYPE_NAME2() {
		return LK_SAGO_TYPE_NAME2;
	}
	public void setLK_SAGO_TYPE_NAME2(String lK_SAGO_TYPE_NAME2) {
		LK_SAGO_TYPE_NAME2 = lK_SAGO_TYPE_NAME2;
	}
	public String getLK_GWASIL_GB() {
		return LK_GWASIL_GB;
	}
	public void setLK_GWASIL_GB(String lK_GWASIL_GB) {
		LK_GWASIL_GB = lK_GWASIL_GB;
	}
	public String getLK_GWASIL_NAME() {
		return LK_GWASIL_NAME;
	}
	public void setLK_GWASIL_NAME(String lK_GWASIL_NAME) {
		LK_GWASIL_NAME = lK_GWASIL_NAME;
	}
	public String getLK_POLICE_SINGO() {
		return LK_POLICE_SINGO;
	}
	public void setLK_POLICE_SINGO(String lK_POLICE_SINGO) {
		LK_POLICE_SINGO = lK_POLICE_SINGO;
	}
	public String getLK_SAGO_CONT() {
		return LK_SAGO_CONT;
	}
	public void setLK_SAGO_CONT(String lK_SAGO_CONT) {
		LK_SAGO_CONT = lK_SAGO_CONT;
	}
	public String getLK_BR_NAME() {
		return LK_BR_NAME;
	}
	public void setLK_BR_NAME(String lK_BR_NAME) {
		LK_BR_NAME = lK_BR_NAME;
	}
	public String getLK_TEAM_NAME() {
		return LK_TEAM_NAME;
	}
	public void setLK_TEAM_NAME(String lK_TEAM_NAME) {
		LK_TEAM_NAME = lK_TEAM_NAME;
	}
	public String getLK_DAMDANGJA() {
		return LK_DAMDANGJA;
	}
	public void setLK_DAMDANGJA(String lK_DAMDANGJA) {
		LK_DAMDANGJA = lK_DAMDANGJA;
	}
	public String getLK_DAMDANG_TEL() {
		return LK_DAMDANG_TEL;
	}
	public void setLK_DAMDANG_TEL(String lK_DAMDANG_TEL) {
		LK_DAMDANG_TEL = lK_DAMDANG_TEL;
	}
	public String getFILLER() {
		return FILLER;
	}
	public void setFILLER(String fILLER) {
		FILLER = fILLER;
	}
	public static String getProid() {
		return proid;
	}
	public static String getTrid() {
		return trid;
	}	
}
