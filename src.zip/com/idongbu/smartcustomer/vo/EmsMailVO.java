package com.idongbu.smartcustomer.vo;

import java.util.List;

public class EmsMailVO {
	public String mail_form_type	= "";	// 1:URL, 2:HAA_MAIL_FORM, 3:
	public long mail_seq			= 0;	// mail_form_type=1:ǮURL, 2:HAA_MAIL_FORM�� KEY, 3:
	public String mail_form_id		= "";
	public String mail_form_name	= "";
	public String mail_form_text	= "";
	public String workday		= "";
	public String seqno		= "";
	public String content		= "";
	public String mail_type		= "";
	public String mail_type_seq	= "";
	public String channel_code	= "";
	public String from_name	= "";
	public String from_mail	= "";
	public String subject		= "";
	public String[] member_id	= new String[0];
	public String[] to_name	= new String[0];
	public String[] to_mail	= new String[0];
	public String[] mapping	= new String[0];
	public String list_table	= "";
	public int target_cnt	= 0;
	public List<ListEmsVo> LIST_DATA = null;
	
	public String getMail_form_type() {
		return mail_form_type;
	}
	public void setMail_form_type(String mail_form_type) {
		this.mail_form_type = mail_form_type;
	}
	public String getMail_form_id() {
		return mail_form_id;
	}
	public void setMail_form_id(String mail_form_id) {
		this.mail_form_id = mail_form_id;
	}
	public long getMail_seq() {
		return mail_seq;
	}
	public void setMail_seq(long mail_seq) {
		this.mail_seq = mail_seq;
	}
	public String getWorkday() {
		return workday;
	}
	public void setWorkday(String workday) {
		this.workday = workday;
	}
	public String getSeqno() {
		return seqno;
	}
	public void setSeqno(String seqno) {
		this.seqno = seqno;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getMail_type() {
		return mail_type;
	}
	public void setMail_type(String mail_type) {
		this.mail_type = mail_type;
	}
	public String getMail_type_seq() {
		return mail_type_seq;
	}
	public void setMail_type_seq(String mail_type_seq) {
		this.mail_type_seq = mail_type_seq;
	}
	public String getChannel_code() {
		return channel_code;
	}
	public void setChannel_code(String channel_code) {
		this.channel_code = channel_code;
	}
	public String getFrom_name() {
		return from_name;
	}
	public void setFrom_name(String from_name) {
		this.from_name = from_name;
	}
	public String getFrom_mail() {
		return from_mail;
	}
	public void setFrom_mail(String from_mail) {
		this.from_mail = from_mail;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String[] getMember_id() {
		return member_id;
	}
	public void setMember_id(String[] member_id) {
		this.member_id = member_id;
	}
	public String[] getTo_name() {
		return to_name;
	}
	public void setTo_name(String[] to_name) {
		this.to_name = to_name;
	}
	public String[] getTo_mail() {
		return to_mail;
	}
	public void setTo_mail(String[] to_mail) {
		this.to_mail = to_mail;
	}
	public String[] getMapping() {
		return mapping;
	}
	public void setMapping(String[] mapping) {
		this.mapping = mapping;
	}
	public String getList_table() {
		return list_table;
	}
	public void setList_table(String list_table) {
		this.list_table = list_table;
	}
	public List<ListEmsVo> getLIST_DATA() {
		return LIST_DATA;
	}
	public void setLIST_DATA(List<ListEmsVo> lIST_DATA) {
		LIST_DATA = lIST_DATA;
	}
	public int getTarget_cnt() {
		return target_cnt;
	}
	public void setTarget_cnt(int target_cnt) {
		this.target_cnt = target_cnt;
	}
	public String getMail_form_name() {
		return mail_form_name;
	}
	public void setMail_form_name(String mail_form_name) {
		this.mail_form_name = mail_form_name;
	}
	public String getMail_form_text() {
		return mail_form_text;
	}
	public void setMail_form_text(String mail_form_text) {
		this.mail_form_text = mail_form_text;
	}
}
