package com.idongbu.smartcustomer.vo;
import com.idongbu.common.vo.CMMVO;

// 통고 홈페이지 상품소개 동의/거부 여부
public class CmmFBM0484RVO extends CMMVO {
	public CmmFBM0484RVO() {
		super.setPGMID(this.proid);
		super.setTRID(this.trid);
	}
	public static final String proid		= "FBM0484R";
	public static final String trid		= "BMIO";
	public String rURL						= "";

	public String COMM_CHANNEL      = "";
	public String COMM_UNIQUE_KEY   = "";
	public String COMM_PGMID        = "";
	public String COMM_PROC_GB      = "";
	public String COMM_ACTION_KEY   = "";
	public String COMM_USER_GB      = "";
	public String COMM_USER_ID      = "";
	public String COMM_JIJUM_CD     = "";
	public String COMM_JIBU_CD      = "";
	public String COMM_PROTOCOL     = "";
	public String COMM_COND_CD      = "";
	public String COMM_LAST_FLAG    = "";
	public String COMM_CURSOR_MAP   = "";
	public String COMM_CURSOR_IDX   = "";
	public String COMM_MESSAGE_CD   = "";
	public String HOMM_MESSAGE_NM   = "";
	public String COMM_SYS_ERR      = "";
	public String COMM_FILLER       = "";
	
	public String KEY_DATA          = "";
	public String SI_K_GUBUN        = "";
	public String SI_K_GOGEK_NO     = "";
	public String SI_K_SEQ          = "";
	public String HI_K_GOGEK_NAME   = "";
	public String SCREEN_DATA       = "";
	public String SI_INFO_USE_YN    = "";
	public String SI_CALL_YN        = "";
	public String SI_INFO_CUT       = "";
	public String SI_CHULCHU_GB     = "";
	public String SI_CALL_GOGEK_NO  = "";
	public String SI_JUPSU_SAWON_NO = "";
	public String HI_JUPSU_SAWON_NM = "";
	public String SI_CALL_GWAN_GB   = "";
	public String HI_SAYU_01        = "";
	public String HI_SAYU_02        = "";
	public String HI_SAYU_03        = "";
	public String HI_SAYU_04        = "";
	public String HI_SAYU_05        = "";
	public String SI_SAWON_NO       = "";
	public String HI_SAWON_NM       = "";
	public String HI_SAWON_JIJUM    = "";
	public String HI_SAWON_JIBU     = "";
	public String SI_PASSWORD       = "";
	public String SI_TM_CALL_GB     = "";
	public String SI_TM_JUP_YMD     = "";
	
	public void setrURL(String rURL) {
		this.rURL = rURL;
	}
	public String getCOMM_CHANNEL() {
		return COMM_CHANNEL;
	}
	public void setCOMM_CHANNEL(String cOMM_CHANNEL) {
		COMM_CHANNEL = cOMM_CHANNEL;
	}
	public String getCOMM_UNIQUE_KEY() {
		return COMM_UNIQUE_KEY;
	}
	public void setCOMM_UNIQUE_KEY(String cOMM_UNIQUE_KEY) {
		COMM_UNIQUE_KEY = cOMM_UNIQUE_KEY;
	}
	public String getCOMM_PGMID() {
		return COMM_PGMID;
	}
	public void setCOMM_PGMID(String cOMM_PGMID) {
		COMM_PGMID = cOMM_PGMID;
	}
	public String getCOMM_PROC_GB() {
		return COMM_PROC_GB;
	}
	public void setCOMM_PROC_GB(String cOMM_PROC_GB) {
		COMM_PROC_GB = cOMM_PROC_GB;
	}
	public String getCOMM_ACTION_KEY() {
		return COMM_ACTION_KEY;
	}
	public void setCOMM_ACTION_KEY(String cOMM_ACTION_KEY) {
		COMM_ACTION_KEY = cOMM_ACTION_KEY;
	}
	public String getCOMM_USER_GB() {
		return COMM_USER_GB;
	}
	public void setCOMM_USER_GB(String cOMM_USER_GB) {
		COMM_USER_GB = cOMM_USER_GB;
	}
	public String getCOMM_USER_ID() {
		return COMM_USER_ID;
	}
	public void setCOMM_USER_ID(String cOMM_USER_ID) {
		COMM_USER_ID = cOMM_USER_ID;
	}
	public String getCOMM_JIJUM_CD() {
		return COMM_JIJUM_CD;
	}
	public void setCOMM_JIJUM_CD(String cOMM_JIJUM_CD) {
		COMM_JIJUM_CD = cOMM_JIJUM_CD;
	}
	public String getCOMM_JIBU_CD() {
		return COMM_JIBU_CD;
	}
	public void setCOMM_JIBU_CD(String cOMM_JIBU_CD) {
		COMM_JIBU_CD = cOMM_JIBU_CD;
	}
	public String getCOMM_PROTOCOL() {
		return COMM_PROTOCOL;
	}
	public void setCOMM_PROTOCOL(String cOMM_PROTOCOL) {
		COMM_PROTOCOL = cOMM_PROTOCOL;
	}
	public String getCOMM_COND_CD() {
		return COMM_COND_CD;
	}
	public void setCOMM_COND_CD(String cOMM_COND_CD) {
		COMM_COND_CD = cOMM_COND_CD;
	}
	public String getCOMM_LAST_FLAG() {
		return COMM_LAST_FLAG;
	}
	public void setCOMM_LAST_FLAG(String cOMM_LAST_FLAG) {
		COMM_LAST_FLAG = cOMM_LAST_FLAG;
	}
	public String getCOMM_CURSOR_MAP() {
		return COMM_CURSOR_MAP;
	}
	public void setCOMM_CURSOR_MAP(String cOMM_CURSOR_MAP) {
		COMM_CURSOR_MAP = cOMM_CURSOR_MAP;
	}
	public String getCOMM_CURSOR_IDX() {
		return COMM_CURSOR_IDX;
	}
	public void setCOMM_CURSOR_IDX(String cOMM_CURSOR_IDX) {
		COMM_CURSOR_IDX = cOMM_CURSOR_IDX;
	}
	public String getCOMM_MESSAGE_CD() {
		return COMM_MESSAGE_CD;
	}
	public void setCOMM_MESSAGE_CD(String cOMM_MESSAGE_CD) {
		COMM_MESSAGE_CD = cOMM_MESSAGE_CD;
	}
	public String getHOMM_MESSAGE_NM() {
		return HOMM_MESSAGE_NM;
	}
	public void setHOMM_MESSAGE_NM(String hOMM_MESSAGE_NM) {
		HOMM_MESSAGE_NM = hOMM_MESSAGE_NM;
	}
	public String getCOMM_SYS_ERR() {
		return COMM_SYS_ERR;
	}
	public void setCOMM_SYS_ERR(String cOMM_SYS_ERR) {
		COMM_SYS_ERR = cOMM_SYS_ERR;
	}
	public String getCOMM_FILLER() {
		return COMM_FILLER;
	}
	public void setCOMM_FILLER(String cOMM_FILLER) {
		COMM_FILLER = cOMM_FILLER;
	}
	public String getKEY_DATA() {
		return KEY_DATA;
	}
	public void setKEY_DATA(String kEY_DATA) {
		KEY_DATA = kEY_DATA;
	}
	public String getSI_K_GUBUN() {
		return SI_K_GUBUN;
	}
	public void setSI_K_GUBUN(String sI_K_GUBUN) {
		SI_K_GUBUN = sI_K_GUBUN;
	}
	public String getSI_K_GOGEK_NO() {
		return SI_K_GOGEK_NO;
	}
	public void setSI_K_GOGEK_NO(String sI_K_GOGEK_NO) {
		SI_K_GOGEK_NO = sI_K_GOGEK_NO;
	}
	public String getSI_K_SEQ() {
		return SI_K_SEQ;
	}
	public void setSI_K_SEQ(String sI_K_SEQ) {
		SI_K_SEQ = sI_K_SEQ;
	}
	public String getHI_K_GOGEK_NAME() {
		return HI_K_GOGEK_NAME;
	}
	public void setHI_K_GOGEK_NAME(String hI_K_GOGEK_NAME) {
		HI_K_GOGEK_NAME = hI_K_GOGEK_NAME;
	}
	public String getSCREEN_DATA() {
		return SCREEN_DATA;
	}
	public void setSCREEN_DATA(String sCREEN_DATA) {
		SCREEN_DATA = sCREEN_DATA;
	}
	public String getSI_INFO_USE_YN() {
		return SI_INFO_USE_YN;
	}
	public void setSI_INFO_USE_YN(String sI_INFO_USE_YN) {
		SI_INFO_USE_YN = sI_INFO_USE_YN;
	}
	public String getSI_CALL_YN() {
		return SI_CALL_YN;
	}
	public void setSI_CALL_YN(String sI_CALL_YN) {
		SI_CALL_YN = sI_CALL_YN;
	}
	public String getSI_INFO_CUT() {
		return SI_INFO_CUT;
	}
	public void setSI_INFO_CUT(String sI_INFO_CUT) {
		SI_INFO_CUT = sI_INFO_CUT;
	}
	public String getSI_CHULCHU_GB() {
		return SI_CHULCHU_GB;
	}
	public void setSI_CHULCHU_GB(String sI_CHULCHU_GB) {
		SI_CHULCHU_GB = sI_CHULCHU_GB;
	}
	public String getSI_CALL_GOGEK_NO() {
		return SI_CALL_GOGEK_NO;
	}
	public void setSI_CALL_GOGEK_NO(String sI_CALL_GOGEK_NO) {
		SI_CALL_GOGEK_NO = sI_CALL_GOGEK_NO;
	}
	public String getSI_JUPSU_SAWON_NO() {
		return SI_JUPSU_SAWON_NO;
	}
	public void setSI_JUPSU_SAWON_NO(String sI_JUPSU_SAWON_NO) {
		SI_JUPSU_SAWON_NO = sI_JUPSU_SAWON_NO;
	}
	public String getHI_JUPSU_SAWON_NM() {
		return HI_JUPSU_SAWON_NM;
	}
	public void setHI_JUPSU_SAWON_NM(String hI_JUPSU_SAWON_NM) {
		HI_JUPSU_SAWON_NM = hI_JUPSU_SAWON_NM;
	}
	public String getSI_CALL_GWAN_GB() {
		return SI_CALL_GWAN_GB;
	}
	public void setSI_CALL_GWAN_GB(String sI_CALL_GWAN_GB) {
		SI_CALL_GWAN_GB = sI_CALL_GWAN_GB;
	}
	public String getHI_SAYU_01() {
		return HI_SAYU_01;
	}
	public void setHI_SAYU_01(String hI_SAYU_01) {
		HI_SAYU_01 = hI_SAYU_01;
	}
	public String getHI_SAYU_02() {
		return HI_SAYU_02;
	}
	public void setHI_SAYU_02(String hI_SAYU_02) {
		HI_SAYU_02 = hI_SAYU_02;
	}
	public String getHI_SAYU_03() {
		return HI_SAYU_03;
	}
	public void setHI_SAYU_03(String hI_SAYU_03) {
		HI_SAYU_03 = hI_SAYU_03;
	}
	public String getHI_SAYU_04() {
		return HI_SAYU_04;
	}
	public void setHI_SAYU_04(String hI_SAYU_04) {
		HI_SAYU_04 = hI_SAYU_04;
	}
	public String getHI_SAYU_05() {
		return HI_SAYU_05;
	}
	public void setHI_SAYU_05(String hI_SAYU_05) {
		HI_SAYU_05 = hI_SAYU_05;
	}
	public String getSI_SAWON_NO() {
		return SI_SAWON_NO;
	}
	public void setSI_SAWON_NO(String sI_SAWON_NO) {
		SI_SAWON_NO = sI_SAWON_NO;
	}
	public String getHI_SAWON_NM() {
		return HI_SAWON_NM;
	}
	public void setHI_SAWON_NM(String hI_SAWON_NM) {
		HI_SAWON_NM = hI_SAWON_NM;
	}
	public String getHI_SAWON_JIJUM() {
		return HI_SAWON_JIJUM;
	}
	public void setHI_SAWON_JIJUM(String hI_SAWON_JIJUM) {
		HI_SAWON_JIJUM = hI_SAWON_JIJUM;
	}
	public String getHI_SAWON_JIBU() {
		return HI_SAWON_JIBU;
	}
	public void setHI_SAWON_JIBU(String hI_SAWON_JIBU) {
		HI_SAWON_JIBU = hI_SAWON_JIBU;
	}
	public String getSI_PASSWORD() {
		return SI_PASSWORD;
	}
	public void setSI_PASSWORD(String sI_PASSWORD) {
		SI_PASSWORD = sI_PASSWORD;
	}
	public String getSI_TM_CALL_GB() {
		return SI_TM_CALL_GB;
	}
	public void setSI_TM_CALL_GB(String sI_TM_CALL_GB) {
		SI_TM_CALL_GB = sI_TM_CALL_GB;
	}
	public String getSI_TM_JUP_YMD() {
		return SI_TM_JUP_YMD;
	}
	public void setSI_TM_JUP_YMD(String sI_TM_JUP_YMD) {
		SI_TM_JUP_YMD = sI_TM_JUP_YMD;
	}

	
	
}
