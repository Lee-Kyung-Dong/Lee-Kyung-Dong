package com.idongbu.smartcustomer.vo;

import com.idongbu.common.vo.CMMVO;

public class CmmFQD0708RVO extends CMMVO {

	public CmmFQD0708RVO() {
		super.setPGMID(this.proid);
		super.setTRID(this.trid);
	}		
	
	private static final String proid = "FQD0708R";
	private static final String trid  = "QDJO";
	private String rURL				  = "";

	private String COMM_CHANNEL       = "";
	private String COMM_UNIQUE        = "";
	private String COMM_PGMID         = "";
	private String COMM_PROC_GB       = "";
	private String COMM_FUN_KEY       = "";
	private String COMM_USER_GB       = "";
	private String COMM_USER_CD       = "";
	private String COMM_JIJUM_CD      = "";
	private String COMM_JIBU_CD       = "";
	private String COMM_PROTOCOL      = "";
	private String COMM_COND_CD       = "";
	private String COMM_LAST_FLAG     = "";
	private String COMM_CURSOR_MAP    = "";
	private String COMM_CURSOR_IDX    = "";
	private String COMM_MESSAGE_CD    = "";
	private String H_COMM_MESSAGE_NM  = "";
	private String COMM_SYS_ERR       = "";
	private String COMM_FILLER        = "";

	// INPUT
	/***************************************************************************
	 * SCR_PROCESS_GB
	 * 1 = 고객용앱 신규, 
	 * 3 = 고객용앱 차량대체 
	 * 6 = 고객용앱 만기정산 
	 * F = 스마트패드 신규
	 * G = 보상앱 만기정산
	 * 
	 * SCR_SULGYE_NO : SCR_PROCESS_GB = 1 or F 일때 입력
	 * SCR_BESU_SULGYE_NO : SCR_PROCESS_GB = 3 일때 입력
	 * SCR_GOGEK_NO : 피보험자 생년월일 6자리
	 * SCR_POLI_NO : SCR_PROCESS_GB = 6 or G 일때 입력
	 **************************************************************************/
	private String SCR_PROCESS_GB     = ""; // 처리구분
	private String SCR_SULGYE_NO      = ""; // 설계번호
	private String SCR_BESU_SULGYE_NO = ""; // 배서설계번호
	private String SCR_GOGEK_NO		  = ""; // 고객번호
	private String SCR_POLI_NO 		  = ""; // 증권번호
	
	// OUTPUT
	private String SCR_CHABUN_NO      = ""; // 채번번호

	public String getrURL() {
		return rURL;
	}

	public void setrURL(String rURL) {
		this.rURL = rURL;
	}

	public String getCOMM_CHANNEL() {
		return COMM_CHANNEL;
	}

	public void setCOMM_CHANNEL(String cOMM_CHANNEL) {
		COMM_CHANNEL = cOMM_CHANNEL;
	}

	public String getCOMM_UNIQUE() {
		return COMM_UNIQUE;
	}

	public void setCOMM_UNIQUE(String cOMM_UNIQUE) {
		COMM_UNIQUE = cOMM_UNIQUE;
	}

	public String getCOMM_PGMID() {
		return COMM_PGMID;
	}

	public void setCOMM_PGMID(String cOMM_PGMID) {
		COMM_PGMID = cOMM_PGMID;
	}

	public String getCOMM_PROC_GB() {
		return COMM_PROC_GB;
	}

	public void setCOMM_PROC_GB(String cOMM_PROC_GB) {
		COMM_PROC_GB = cOMM_PROC_GB;
	}

	public String getCOMM_FUN_KEY() {
		return COMM_FUN_KEY;
	}

	public void setCOMM_FUN_KEY(String cOMM_FUN_KEY) {
		COMM_FUN_KEY = cOMM_FUN_KEY;
	}

	public String getCOMM_USER_GB() {
		return COMM_USER_GB;
	}

	public void setCOMM_USER_GB(String cOMM_USER_GB) {
		COMM_USER_GB = cOMM_USER_GB;
	}

	public String getCOMM_USER_CD() {
		return COMM_USER_CD;
	}

	public void setCOMM_USER_CD(String cOMM_USER_CD) {
		COMM_USER_CD = cOMM_USER_CD;
	}

	public String getCOMM_JIJUM_CD() {
		return COMM_JIJUM_CD;
	}

	public void setCOMM_JIJUM_CD(String cOMM_JIJUM_CD) {
		COMM_JIJUM_CD = cOMM_JIJUM_CD;
	}

	public String getCOMM_JIBU_CD() {
		return COMM_JIBU_CD;
	}

	public void setCOMM_JIBU_CD(String cOMM_JIBU_CD) {
		COMM_JIBU_CD = cOMM_JIBU_CD;
	}

	public String getCOMM_PROTOCOL() {
		return COMM_PROTOCOL;
	}

	public void setCOMM_PROTOCOL(String cOMM_PROTOCOL) {
		COMM_PROTOCOL = cOMM_PROTOCOL;
	}

	public String getCOMM_COND_CD() {
		return COMM_COND_CD;
	}

	public void setCOMM_COND_CD(String cOMM_COND_CD) {
		COMM_COND_CD = cOMM_COND_CD;
	}

	public String getCOMM_LAST_FLAG() {
		return COMM_LAST_FLAG;
	}

	public void setCOMM_LAST_FLAG(String cOMM_LAST_FLAG) {
		COMM_LAST_FLAG = cOMM_LAST_FLAG;
	}

	public String getCOMM_CURSOR_MAP() {
		return COMM_CURSOR_MAP;
	}

	public void setCOMM_CURSOR_MAP(String cOMM_CURSOR_MAP) {
		COMM_CURSOR_MAP = cOMM_CURSOR_MAP;
	}

	public String getCOMM_CURSOR_IDX() {
		return COMM_CURSOR_IDX;
	}

	public void setCOMM_CURSOR_IDX(String cOMM_CURSOR_IDX) {
		COMM_CURSOR_IDX = cOMM_CURSOR_IDX;
	}

	public String getCOMM_MESSAGE_CD() {
		return COMM_MESSAGE_CD;
	}

	public void setCOMM_MESSAGE_CD(String cOMM_MESSAGE_CD) {
		COMM_MESSAGE_CD = cOMM_MESSAGE_CD;
	}

	public String getH_COMM_MESSAGE_NM() {
		return H_COMM_MESSAGE_NM;
	}

	public void setH_COMM_MESSAGE_NM(String h_COMM_MESSAGE_NM) {
		H_COMM_MESSAGE_NM = h_COMM_MESSAGE_NM;
	}

	public String getCOMM_SYS_ERR() {
		return COMM_SYS_ERR;
	}

	public void setCOMM_SYS_ERR(String cOMM_SYS_ERR) {
		COMM_SYS_ERR = cOMM_SYS_ERR;
	}

	public String getCOMM_FILLER() {
		return COMM_FILLER;
	}

	public void setCOMM_FILLER(String cOMM_FILLER) {
		COMM_FILLER = cOMM_FILLER;
	}

	public String getSCR_PROCESS_GB() {
		return SCR_PROCESS_GB;
	}

	public void setSCR_PROCESS_GB(String sCR_PROCESS_GB) {
		SCR_PROCESS_GB = sCR_PROCESS_GB;
	}

	public String getSCR_SULGYE_NO() {
		return SCR_SULGYE_NO;
	}

	public void setSCR_SULGYE_NO(String sCR_SULGYE_NO) {
		SCR_SULGYE_NO = sCR_SULGYE_NO;
	}

	public String getSCR_BESU_SULGYE_NO() {
		return SCR_BESU_SULGYE_NO;
	}

	public void setSCR_BESU_SULGYE_NO(String sCR_BESU_SULGYE_NO) {
		SCR_BESU_SULGYE_NO = sCR_BESU_SULGYE_NO;
	}

	public String getSCR_GOGEK_NO() {
		return SCR_GOGEK_NO;
	}

	public void setSCR_GOGEK_NO(String sCR_GOGEK_NO) {
		SCR_GOGEK_NO = sCR_GOGEK_NO;
	}

	public String getSCR_POLI_NO() {
		return SCR_POLI_NO;
	}

	public void setSCR_POLI_NO(String sCR_POLI_NO) {
		SCR_POLI_NO = sCR_POLI_NO;
	}

	public String getSCR_CHABUN_NO() {
		return SCR_CHABUN_NO;
	}

	public void setSCR_CHABUN_NO(String sCR_CHABUN_NO) {
		SCR_CHABUN_NO = sCR_CHABUN_NO;
	}

	public static String getProid() {
		return proid;
	}

	public static String getTrid() {
		return trid;
	}	
}
