package com.idongbu.smartcustomer.vo;

import com.idongbu.common.vo.CMMVO;

public class CyCerPriVO extends CMMVO { 
	public String PAPER_GBN ="";

	public int VIEW_COUNT	   = 0;
	public boolean VIEW_SELECT = false;
	public String VIEW_NAME    = "";
	public String VIEW_PIBONM  = "";
	public String VIEW_CARNO   = "";
	public String VIEW_POLINO  = "";
	public String VIEW_BJCD    = "";
	public String VIEW_BJNM    = "";
	public String VIEW_SYMD    = "";
	public String VIEW_EYMD    = "";
	public String VIEW_STATUS  = "";
	
	
	public String JJ_P_NAPIP_PRM = "";  //총납입보험료
	public String JJ_P_LAST_NAP_YM = "";  //최종납입월분
	public String JJ_P_GYEYAK_YMD = "";  //계약일자
	public String JJ_P_NAPIP_YMD  ="";   //최종납입일
	public String JJ_P_YAKGWAN_GM = "";  //약관대출금
	
	public String S_YEAR       = ""; //공직자용보험료납입증명서용 년도 
	public String ILBAN_CD     = ""; //일반보험증권용 코드
	
	public String S_POLI_NO = "";

	public String arg1  = "";
	public String arg2  = "";
	public String arg3  = "";
	public String arg4  = "";
	public String arg5  = "";
	public String arg6  = "";
	public String arg7  = "";
	public String arg8  = "";
	public String arg9  = "";
	public String arg9_1  = "";
	public String arg10 = "";
	public String arg11 = "";
	public String arg12 = "";
	public String arg13 = "";
	public String arg14 = "";
	public String arg15 = "";
	public String arg16 = "";
	public String arg17 = "";
	public String arg18 = "";
	public String arg19 = "";
	public String arg20 = "";
	public String arg20_tmp = "";
	public String arg21 = "";
	public String arg22 = "";
	public String arg23 = "";
	public String arg24 = "";
	public String arg25 = "";
	public String arg26 = "";
	public String arg27 = "";
	public String arg28 = "";
	public String arg29 = "";
	public String arg30 = "";
	public String arg31 = "";
	public String arg32 = "";
	public String arg33 = "";
	public String arg34 = "";
	public String arg35 = "";
	public String arg36 = "";
	public String arg37 = "";
	public String arg38 = "";
	public String arg39 = "";
	public String arg40 = "";
	public String arg41 = "";
	public String arg42 = "";
	public String arg43 = "";
	public String arg44 = "";
	public String arg45 = "";	
	public String arg46 = "";
	public String arg47 = "";
	
	public String val_arg2 = "";
	public String arg10_1 = "";    
	public String arg14_1 = "";          
	public String arg14_2 = "";
	
	public String JJ_POLINO = "";
	public String CC_FUN_KEY = "";
	
	public String BJ_NM = "";
	public String SD_TRID = "";
	
	
	
	public String DB_JOGUN_NO 		="";
	public String GB_CONTENT 		="";
	public String LK_RC 		="";
	public String go_url = "";
	public String POLI_NO = "";

	public String COUNT_ID = ""; 
	public String CHECK_DAY = "";

//공직자용프린트 리턴 변수
	public String[] arr_arg4 = new String[0]; // 10
	public String[] arr_arg5 = new String[0]; // 10
	public String[] arr_arg6 = new String[0]; // 10
	public String[] arr_arg7 = new String[0]; // 10
	public String[] arr_arg8 = new String[0]; // 10	
	public String[] arr_arg9 = new String[0]; // 10	
	public String[] arr_arg10 = new String[0]; // 10	
	public String[] arr_arg11 = new String[0]; // 10		

	
	public String cbchk_out  = "";
	public String cbchk = "";
	
	//연말정산 관련
	
	// 0048 전문 관련 
	public String SO_BJ_CD		     = "";     //보종코드     
	public String HO_GYE_NAME 	   = "";     //계약자명     
	public String HO_PIB_NAME 	   = "";     //피보험자명   
	public String SO_BJ_GB 		     = "";     //보종구분     
	public String SO_POLI_NO 		   = "";     //증권번호     
	public String HO_CAR_NO 		   = "";     //차량번호     
	public String HO_BJ_NM 		     = "";     //보종이름     
	public String SO_BOHUM_SYMD 	 = "";     //보험시기     
	public String SO_BOHUM_EYMD 	 = "";     //보험종기     
	public String HO_SANGTE_NM 	   = "";     //계약상태     
	public String HO_PA_NAME		   = "";     //PA명         
	public String SO_PA_HP		     = "";     //PA핸드폰     
	public String SO_JIBU_TEL		   = "";     //PA전화       
	public String SO_PA_MAIL		   = "";     //PA이메일     
	public String SO_CHUNGYAK_YMD	 = "";     //청약일       
	public String SO_GYE_NO		     = "";     //계약자코드   
	public String SO_PIB_NO		     = "";     //피보험자코드 
	public String SO_CHIGPJA_CD	   = "";     //취급사번     
	public String SO_JIJUM_TEL	   = "";     //지점전화번호 
	public String SO_JIJUM_CD		   = "";     //지점코드     
	public String SO_JIBU_CD		   = "";     //지부코드     
	public String SERIAL_NUM1 = "";

	public String SI_K_GOGEK_NO = "";
	
	
	
	//0044 전문관련
	public String LK_BM0044_CONTINUE_GB     = "";
	public String LK_BM0044_KEY_JABO_GB     = "";
	public String LK_BM0044_KEY_POLI_NO1    = "";
	public String LK_BM0044_KEY_JANG_GB     = "";
	public String LK_BM0044_KEY_POLI_NO2    = "";
	public String LK_BM0044_KEY_ILBAN_GB    = "";
	public String LK_BM0044_KEY_POLI_NO3  	= "";
	public int SERIAL_NUM = 0;
	public int LIST_ID = 0;
	public String Certify_type = "";
	
	public String LK_BM0044_JABO_POLI_NO        = "";	
	public String LK_BM0044_JABO_GONG_PRM       = ""; 
	public String LK_BM0044_JABO_JANG_PRM       = ""; 
	public String H_LK_BM0044_JABO_BJ_NM        = ""; 
	public String H_LK_BM0044_JABO_CAR_NO       = "";
	public String H_LK_BM0044_JABO_PIBO_NM      = ""; 
	public String H_LK_BM0044_JABO_GWANGYE      = ""; 
	public String H_LK_BM0044_JABO_NAPBANG_NM   = ""; 
	public String LK_BM0044_JABO_LAST_YM        = ""; 
	public String JABO_GONG_PRM = "";                     
	public String JABO_JANG_PRM = "";                     
	public String JABO_POLI_NO = "";     
	
	public String H_LK_BM0044_JANG_BJ_NM  = "";
	public String LK_BM0044_JANG_GONG_PRM  = "";
	public String LK_BM0044_JANG_YUN_PRM   = "";
	public String LK_BM0044_JANG_YUN_SAVE  = "";
	public String LK_BM0044_JANG_JUTEK     = "";
	public String LK_BM0044_JANG_BORYO	  = ""; 
	public String LK_BM0044_JANG_POLI_NO   = "";
	public String H_LK_BM0044_JANG_CAR_NO    		= "";	     
	public String H_LK_BM0044_JANG_PIBO_NM    		= "";
	public String H_LK_BM0044_JANG_GWANGYE       = "";     
	public String H_LK_BM0044_JANG_NAPBANG_NM    = "";
	public String LK_BM0044_JANG_LAST_YM         = "";    
	
	public String JANG_GONG_PRM = "";                           
	public String JANG_YUN_PRM = "";                            
	public String JANG_YUN_SAVE = "";                           
	public String JANG_JUTEK = "";                              
	public String MONEY = "";                                   
	public String JANG_POLI_NO = "";    		                    


	public String LK_BM0044_ILBA_POLI_NO        = ""; 
	public String H_LK_BM0044_ILBA_PIBO_NM      = ""; 
	public String H_LK_BM0044_ILBA_GWANGYE      = ""; 
	public String LK_BM0044_ILBA_BJ_CD          = ""; 
	public String H_LK_BM0044_ILBA_BJ_NM        = ""; 
	public String LK_BM0044_ILBA_NAPBANG        = ""; 
	public String H_LK_BM0044_ILBA_NAPBANG_NM   = ""; 
	public String LK_BM0044_ILBA_LAST_YM        = ""; 
	public String LK_BM0044_ILBA_NAPIP_CNT      = ""; 
	public String H_LK_BM0044_ILBA_CAR_NO       = ""; 
	public String LK_BM0044_ILBA_GONG_PRM       = ""; 
        
	                                                                       
	public String ILBA_GONG_PRM = "";                                      
	public String ILBA_POLI_NO = "";   
	
	
	public String LK_BM0044_GOGEK_ZIP = "";
	public String LK_BM0044_KEY_GOGEK_NO = "";
	public String LK_BM0044_KEY_GIJUN_YY = "";
	public String H_LK_BM0044_GOGEK_NAME = "";
	public String H_LK_BM0044_GOGEK_ZIP_NAME = "";
	public String H_LK_BM0044_GOGEK_GITA  = "" ;
	public String LK_BM0044_RETURN_CD = "";
	public String LK_BM0044_MSG_CD1 = "";
	public String LK_BM0044_MSG_CD2 = "";
	
	
	public long TOT_SUM1 = 0;
	public long TOT_SUM2 = 0;
	public long TOT_SUM3 = 0;
	public long TOT_SUM4 = 0;
	public long TOT_SUM5 = 0;
	
	public String s_TOT_SUM1 = "";
	public String s_TOT_SUM2 = "";
	public String s_TOT_SUM3 = "";
	public String s_TOT_SUM4 = "";
	public String s_TOT_SUM5 = "";
	
	


	public String SERIAL_GBN = "";
	
	
	
	//자녀보험 관련
	
	
	
	public String JJ_GYEYAK_JMNO   = "";  
	public String HJ_GYEYAK_NM     = "";  
	public String JJ_PIBO_JMNO     = "";  
	public String HJ_PIBO_NM       = "";  
	public String HJ_BJ_NM         = "";  
	public String JJ_POLI_NO       = "";  
	public String JJ_BOHUM_GIGAN_S = "";  
	public String JJ_BOHUM_GIGAN_E = "";  
	public String JJ_GYEYAK_SANGTE = "";  
	public String HJ_BIGO          = "";  
	public String HJ_CHIGUB_NM     = "";  
	public String JJ_CHIGUB_TEL    = "";  
	public String JJ_CHIGUB        = "";  
	public String JJ_GAIP_TYPE1    = "";  
	public String JJ_BOHUM_GIGANCD = "";  

//list
	public String CTR_NAME      = "";
	public String INSRD_NAME    = "";
	public String SECU_NAME     = "";
	public String STOCK_SEQ     = "";
	public String INSUB_ERA_DAY = "";
	public String INSUB_END_DAY = "";
	public String CTR_INHAB_NO  = "";
	public String GONGJE_CD  = "";
	
	
	public String GUBUN = "";//연말정산 관련 1: 본인 2: 자녀

	public String UU_INQ_BJ  = "";
	public String UU_INQ_POLI_NO  = "";
	
	
//연말정산 서류 우편 및 Fax 신청	
	
	public String SI_GUBUN       ="";                
	public String SI_GOGEK_NO    ="";            
	public String HO_GOGEK_NM    ="";            
	public String SI_H_ZIP       ="";            
	public String H_ZIP	         ="";
	public String HO_H_JUSO      ="";             
	public String HI_H_ADDR      ="";             
	public String H_ADDR         ="";                             
	public String SI_J_ZIP       ="";               
	public String J_ZIP          ="";        
	public String HO_J_JUSO      ="";              
	public String HI_J_ADDR      ="";              
	public String J_ADDR         ="";                           
	public String SI_G_ZIP       ="";                
	public String G_ZIP          ="";         
	public String HO_G_JUSO      ="";               
	public String HI_G_ADDR      ="";               
	public String G_ADDR         ="";                           
	public String SI_HP_TEL1     ="";              
	public String SI_HP_TEL2     ="";              
	public String SI_HP_TEL3     ="";              
	public String HP_TEL         ="";                    
	public String SI_H_TEL1      ="";             
	public String SI_H_TEL2      ="";             
	public String SI_H_TEL3      ="";             
	public String H_TEL          ="";                        
	public String SI_J_TEL1      ="";              
	public String SI_J_TEL2      ="";              
	public String SI_J_TEL3      ="";              
	public String J_TEL          ="";                        
	public String SI_EMAIL_ID    ="";            
	public String EMAIL_ID       ="";                                       
	public String receive	     ="";		 
	public String SO_HP_GBN      ="";  
	public String SO_HT_GBN      ="";  
	public String SO_JT_GBN      ="";  
	public String SO_E_GBN       ="";  
	                                               
	public String SI_H_ZIP1      ="";
	public String SI_H_ZIP2      ="";                        
	public String JUSO           ="";                               
	public String ADDR           ="";                             
	public String zipcode        ="";                       
	public String address        ="";                    
	                                      
	public String fax_phone1     ="";                           
	public String fax_phone2     ="";                         
	public String fax_phone3     ="";                         
	                                               
	public String 	N_J_TEL      ="";                 
	                                             
	public String 	SO_H_GBN     ="";                                
	public String 	N_H_ZIP      ="";                                         
	public String 	N_H_ADDR     ="";                                        
                                  
	public String 	SO_J_GBN     ="";                               
	public String 	N_J_ZIP      ="";                                       
	public String 	N_J_ADDR     ="";                                        
                                   
	public String 	SO_G_GBN     ="";                                 
	public String 	N_G_ZIP      ="";                                        
	public String 	N_G_ADDR     =""; 
	public String sin_gubun ="";
	public String N_HP_TEL = "";
	public String N_H_TEL = "";
	public String N_EMAIL_ID = "";

	// 계약조회
	public String UD_FK_POLI_NO = "";
	public String UD_LK_POLI_NO = "";
	public String PREV_UD_FK_POLI_NO = "";

	public String page = "";
	
	
	//대출관련
	public String O_LN_NO = "";		//대출번호
	public String chkCer = "";		//증명서 선택
	public String USE_INFO = "";	//사용용도
	public String I_EXH_AMT = "";	//12월분(예상)상환금액
	public String I_STD_YYYY = "";	//기준년
	
	// 자동차 견적서 출력
	public String CAR3SEQ = "";		// CAR_INS3 테이블 seq
	public String CAR4SEQ = "";		// CAR_INS4 테이블 seq
	public String BOHUM_GIGAN_SYMD = "";		// CAR_INS4 테이블 BOHUM_GIGAN_SYMD
	public String BOHUM_GIGAN_EYMD = "";		// CAR_INS4 테이블 BOHUM_GIGAN_EYMD
	public String PIB_GOGEK_NO = "";			// CAR_INS4 테이블 PIB_GOGEK_NO
	public String LK_GA1085_MUBO_GAIP_GMEK = "";			// CAR_INS4 테이블 LK_GA1085_MUBO_GAIP_GMEK
	public String MUBO_YN = "";			// CAR_INS4 테이블 MUBO_YN
	public String JACHA_GAIP_GMEK = "";			// CAR_INS4 테이블 JACHA_GAIP_GMEK
	public String LK_GA1085_CAR_CD_IMSI_GB = "";			// CAR_INS4 테이블 LK_GA1085_CAR_CD_IMSI_GB
	public String LK_GA1085_JACHA_JUNGRULJE_GB = "";			// CAR_INS4 테이블 LK_GA1085_JACHA_JUNGRULJE_GB
	public String LK_GA1085_S_WEEK_DAY = "";			// CAR_INS4 테이블 LK_GA1085_S_WEEK_DAY
	public String BUNNAP_BANGCD = "";			// CAR_INS4 테이블 BUNNAP_BANGCD
	public String JASON_YN = "";			// CAR_INS4 테이블 JASON_YN
	public String LK_GA1085_JASON_SAMANG = "";			// CAR_INS4 테이블 LK_GA1085_JASON_SAMANG
	public String LK_GA1085_JASON_BUSANG = "";			// CAR_INS4 테이블 LK_GA1085_JASON_BUSANG
	public String JASON_JUKYONG_PRM = "";			// CAR_INS4 테이블 JASON_JUKYONG_PRM
	public String TUKYAK_CD = "";			// CAR_INS4 테이블 TUKYAK_CD1
	
	
	//장기증권출력
	public int page_no=0;

	public String key_idx = "";

	public String CC_FILLER = "";
	
	public String DSTIN_CD = "";
	
	public String DUPE_YN = "";
	
	
}