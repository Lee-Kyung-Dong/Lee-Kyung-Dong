package com.idongbu.smartcustomer.vo;

import java.util.List;
import java.util.Map;

import com.idongbu.common.vo.CMMVO;

// 자동차 계약 - 고객용 앱 신규대상 가입유무(주행거리,블랙박스)			
public class CmmFQD0659RVO extends CMMVO {

	public CmmFQD0659RVO() {
		super.setPGMID(this.proid);
		super.setTRID(this.trid);
	}
	
	private static final String proid  = "FQD0659R";
	private static final String trid   = "QDIB";
                                       
	// 공통                            
	private String COMM_CHANNEL        = ""; // 채널구분 ( 1:영업포탈, 2:CALL, 3:홈페이지, 6:직판, 8:WAP )
	private String COMM_UNIQUE         = ""; // TSQ,VSAM FILE용 UNIQUE
	private String COMM_PGMID          = ""; // PROGRAM-ID
	private String COMM_PROC_GB        = ""; // 처리구분
	private String COMM_FUN_KEY        = ""; // 기능키
	private String COMM_LOGON_AREA     = ""; // 
	private String COMM_USER_GB        = ""; // 사용자구분
	private String COMM_USER_CD        = ""; // 사용자ID
	private String COMM_JIJUM_CD       = ""; // 사용자지점
	private String COMM_JIBU_CD        = ""; // 사용자지부
	private String COMM_PROTOCOL       = ""; // 전문사용구분
	private String COMM_COND_CD        = ""; // 처리결과
	private String COMM_LAST_FLAG      = ""; // 마지막자료여부
	private String COMM_CURSOR_MAP     = ""; // CURSOR POINT - MAP
	private String COMM_CURSOR_IDX     = ""; // CURSOR POINT - FIELD INDEX
	private String COMM_MESSAGE_CD     = ""; // 화면 출력 MESSAGE - CODE
	private String H_COMM_MESSAGE_NM   = ""; // 화면 출력 MESSAGE
	private String COMM_SYS_ERR        = ""; // 시스템 MESSAGE
	private String COMM_FILLER         = ""; // 여분
	                                   
	// INPUT                           
	private String SCR_GOGEK_NO        = ""; // 고객번호(생년월일)
	private String H_SCR_CAR_NO        = ""; // 차량번호
	private String SCR_GUBUN           = ""; // 구분 ('1' = 주행거리, '2' = 블랙박스)
	private String SCR_PROCESS_GB      = "";
	private String SCR_AUTHORITY_GB    = ""; // 조직원권한 CHECK (EDMS에서 조직원 권한확인시 사용 'Y')
	private String SCR_JOJIKWON_CD     = ""; // 조직원코드 (EDMS에서 조직원 권한확인시 사용)
	private String SCR_IN_FIL          = ""; // 여분
	
	// OUTPUT
	private String SCR_SULGYE_CNT      = ""; // 설계번호 COUNT ('0' 보다 클때만 가입대상 있음)
	/*
	private String SCR_SULGYE_NO       = ""; // 설계번호
	private String SCR_GAIP_SULGYE_YMD = ""; // 설계일자
	private String SCR_BOHUM_SYMD      = ""; // 보험시기
	private String SCR_BOHUM_EYMD      = ""; // 보험종기
	*/
	private List<Map<String, String>> LOOP_DATA = null;
	private String SCR_OUT_FIL         = ""; // 여분
	
	public String getCOMM_CHANNEL() {
		return COMM_CHANNEL;
	}
	public void setCOMM_CHANNEL(String cOMM_CHANNEL) {
		COMM_CHANNEL = cOMM_CHANNEL;
	}
	public String getCOMM_UNIQUE() {
		return COMM_UNIQUE;
	}
	public void setCOMM_UNIQUE(String cOMM_UNIQUE) {
		COMM_UNIQUE = cOMM_UNIQUE;
	}
	public String getCOMM_PGMID() {
		return COMM_PGMID;
	}
	public void setCOMM_PGMID(String cOMM_PGMID) {
		COMM_PGMID = cOMM_PGMID;
	}
	public String getCOMM_PROC_GB() {
		return COMM_PROC_GB;
	}
	public void setCOMM_PROC_GB(String cOMM_PROC_GB) {
		COMM_PROC_GB = cOMM_PROC_GB;
	}
	public String getCOMM_FUN_KEY() {
		return COMM_FUN_KEY;
	}
	public void setCOMM_FUN_KEY(String cOMM_FUN_KEY) {
		COMM_FUN_KEY = cOMM_FUN_KEY;
	}
	public String getCOMM_LOGON_AREA() {
		return COMM_LOGON_AREA;
	}
	public void setCOMM_LOGON_AREA(String cOMM_LOGON_AREA) {
		COMM_LOGON_AREA = cOMM_LOGON_AREA;
	}
	public String getCOMM_USER_GB() {
		return COMM_USER_GB;
	}
	public void setCOMM_USER_GB(String cOMM_USER_GB) {
		COMM_USER_GB = cOMM_USER_GB;
	}
	public String getCOMM_USER_CD() {
		return COMM_USER_CD;
	}
	public void setCOMM_USER_CD(String cOMM_USER_CD) {
		COMM_USER_CD = cOMM_USER_CD;
	}
	public String getCOMM_JIJUM_CD() {
		return COMM_JIJUM_CD;
	}
	public void setCOMM_JIJUM_CD(String cOMM_JIJUM_CD) {
		COMM_JIJUM_CD = cOMM_JIJUM_CD;
	}
	public String getCOMM_JIBU_CD() {
		return COMM_JIBU_CD;
	}
	public void setCOMM_JIBU_CD(String cOMM_JIBU_CD) {
		COMM_JIBU_CD = cOMM_JIBU_CD;
	}
	public String getCOMM_PROTOCOL() {
		return COMM_PROTOCOL;
	}
	public void setCOMM_PROTOCOL(String cOMM_PROTOCOL) {
		COMM_PROTOCOL = cOMM_PROTOCOL;
	}
	public String getCOMM_COND_CD() {
		return COMM_COND_CD;
	}
	public void setCOMM_COND_CD(String cOMM_COND_CD) {
		COMM_COND_CD = cOMM_COND_CD;
	}
	public String getCOMM_LAST_FLAG() {
		return COMM_LAST_FLAG;
	}
	public void setCOMM_LAST_FLAG(String cOMM_LAST_FLAG) {
		COMM_LAST_FLAG = cOMM_LAST_FLAG;
	}
	public String getCOMM_CURSOR_MAP() {
		return COMM_CURSOR_MAP;
	}
	public void setCOMM_CURSOR_MAP(String cOMM_CURSOR_MAP) {
		COMM_CURSOR_MAP = cOMM_CURSOR_MAP;
	}
	public String getCOMM_CURSOR_IDX() {
		return COMM_CURSOR_IDX;
	}
	public void setCOMM_CURSOR_IDX(String cOMM_CURSOR_IDX) {
		COMM_CURSOR_IDX = cOMM_CURSOR_IDX;
	}
	public String getCOMM_MESSAGE_CD() {
		return COMM_MESSAGE_CD;
	}
	public void setCOMM_MESSAGE_CD(String cOMM_MESSAGE_CD) {
		COMM_MESSAGE_CD = cOMM_MESSAGE_CD;
	}
	public String getH_COMM_MESSAGE_NM() {
		return H_COMM_MESSAGE_NM;
	}
	public void setH_COMM_MESSAGE_NM(String h_COMM_MESSAGE_NM) {
		H_COMM_MESSAGE_NM = h_COMM_MESSAGE_NM;
	}
	public String getCOMM_SYS_ERR() {
		return COMM_SYS_ERR;
	}
	public void setCOMM_SYS_ERR(String cOMM_SYS_ERR) {
		COMM_SYS_ERR = cOMM_SYS_ERR;
	}
	public String getCOMM_FILLER() {
		return COMM_FILLER;
	}
	public void setCOMM_FILLER(String cOMM_FILLER) {
		COMM_FILLER = cOMM_FILLER;
	}
	public String getSCR_GOGEK_NO() {
		return SCR_GOGEK_NO;
	}
	public void setSCR_GOGEK_NO(String sCR_GOGEK_NO) {
		SCR_GOGEK_NO = sCR_GOGEK_NO;
	}
	public String getH_SCR_CAR_NO() {
		return H_SCR_CAR_NO;
	}
	public void setH_SCR_CAR_NO(String h_SCR_CAR_NO) {
		H_SCR_CAR_NO = h_SCR_CAR_NO;
	}
	public String getSCR_GUBUN() {
		return SCR_GUBUN;
	}
	public void setSCR_GUBUN(String sCR_GUBUN) {
		SCR_GUBUN = sCR_GUBUN;
	}	
	public String getSCR_PROCESS_GB() {
		return SCR_PROCESS_GB;
	}
	public void setSCR_PROCESS_GB(String sCR_PROCESS_GB) {
		SCR_PROCESS_GB = sCR_PROCESS_GB;
	}
	public String getSCR_AUTHORITY_GB() {
		return SCR_AUTHORITY_GB;
	}
	public void setSCR_AUTHORITY_GB(String sCR_AUTHORITY_GB) {
		SCR_AUTHORITY_GB = sCR_AUTHORITY_GB;
	}
	public String getSCR_JOJIKWON_CD() {
		return SCR_JOJIKWON_CD;
	}
	public void setSCR_JOJIKWON_CD(String sCR_JOJIKWON_CD) {
		SCR_JOJIKWON_CD = sCR_JOJIKWON_CD;
	}
	public String getSCR_IN_FIL() {
		return SCR_IN_FIL;
	}
	public void setSCR_IN_FIL(String sCR_IN_FIL) {
		SCR_IN_FIL = sCR_IN_FIL;
	}
	public String getSCR_SULGYE_CNT() {
		return SCR_SULGYE_CNT;
	}
	public void setSCR_SULGYE_CNT(String sCR_SULGYE_CNT) {
		SCR_SULGYE_CNT = sCR_SULGYE_CNT;
	}	
	public List<Map<String, String>> getLOOP_DATA() {
		return LOOP_DATA;
	}
	public void setLOOP_DATA(List<Map<String, String>> lOOP_DATA) {
		LOOP_DATA = lOOP_DATA;
	}
	public String getSCR_OUT_FIL() {
		return SCR_OUT_FIL;
	}
	public void setSCR_OUT_FIL(String sCR_OUT_FIL) {
		SCR_OUT_FIL = sCR_OUT_FIL;
	}
	public static String getProid() {
		return proid;
	}
	public static String getTrid() {
		return trid;
	}	
}
