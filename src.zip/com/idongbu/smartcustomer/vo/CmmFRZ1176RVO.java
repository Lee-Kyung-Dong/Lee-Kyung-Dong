package com.idongbu.smartcustomer.vo;

import com.idongbu.common.vo.CMMVO;

public class CmmFRZ1176RVO extends CMMVO {

	public CmmFRZ1176RVO() {
		super.setPGMID(this.proid);
		super.setTRID(this.trid);
	}		
	
	private static final String proid	 = "FRZ1176R";
	private static final String trid	 = "RZ05";
	private String rURL					 = "";

	// 입력
	private String LK_I_SAGO_NO          = ""; // 사고접수번호
	private String LK_I_SAGO_GB          = ""; // 사고목적구분
	private String LK_I_SAGO_SEQ         = ""; // 사고목적일련번호
	private String LK_I_GUBUN            = ""; // 프로드／테스트구분

	// 출력
	private String LK_TRID               = "";
	private String LK_FLAG               = "";
	private String LK_NT_CD              = "";
	private String LK_RSP_TIME           = "";
	private String LK_COMP_GB            = "";
	private String LK_COMP_CD            = "";
	private String LK_FILLER             = "";
	private String LK_USER_ID            = "";
	private String LK_PART_GB1           = "";
	private String LK_PART_GB2           = "";
	private String LK_UPMU_CD1           = "";
	private String LK_UPMU_CD2           = "";
	private String LK_UPMU_CD3           = "";
	private String LK_GULK_GB            = "";
	private String LK_CM_FILLER          = "";
	private String LK_RETURN_CD          = "";
	private String LK_MSG_CD1            = "";
	private String LK_MSG_CD2            = "";
	private String H_LK_MESSAGE1         = "";
	private String H_LK_MESSAGE2         = "";
//	private String LK_I_SAGO_NO          = "";
//	private String LK_I_SAGO_GB          = "";
//	private String LK_I_SAGO_SEQ         = "";
//	private String LK_I_GUBUN            = "";
	private String LK_SAGO_NO            = "";
	private String LK_CAR_NO             = "";
	private String LK_CAR_NAME           = "";
	private String LK_BUPUM_GMEK         = "";
	private String LK_GONGIM_GMEK        = "";
	private String LK_TKYAK_NAME1        = "";
	private String LK_TKYAK_PL_CMT1      = "";
	private String LK_TKYAK_NAME2        = "";
	private String LK_TKYAK_PL_CMT2      = "";
	private String LK_TKYAK_NAME3        = "";
	private String LK_TKYAK_PL_CMT3      = "";
	private String LK_TKYAK_NAME4        = "";
	private String LK_TKYAK_PL_CMT4      = "";
	private String LK_TKYAK_NAME5        = "";
	private String LK_TKYAK_PL_CMT5      = "";
	private String LK_TKYAK_NAME6        = "";
	private String LK_TKYAK_PL_CMT6      = "";
	private String LK_TKYAK_CNT          = "";
	private String LK_TKYAK_TOT_PL_CMT   = "";
	private String LK_PL_CMT             = "";
	private String LK_PASON_BUWIE_NAME1  = "";
	private String LK_PASON_BUWIE_NAME2  = "";
	private String LK_PASON_BUWIE_NAME3  = "";
	private String LK_PASON_BUWIE_NAME4  = "";
	private String LK_PASON_BUWIE_NAME5  = "";
	private String LK_PASON_BUWIE_NAME6  = "";
	private String LK_PASON_BUWIE_NAME7  = "";
	private String LK_PASON_BUWIE_NAME8  = "";
	private String LK_PASON_BUWIE_NAME9  = "";
	private String LK_PASON_BUWIE_NAME10 = "";
	private String LK_PASON_BUWIE_NAME11 = "";
	private String LK_PASON_BUWIE_NAME12 = "";
	private String LK_SURICHEO_NAME      = "";
	private String LK_DAMDANGJA_NAME     = "";
	private String LK_DAMDANGJA_TEL      = "";
	private String LK_IMAGE_PATH1        = "";
	private String LK_IMAGE_PATH2        = "";
	private String FILLER                = "";
	
	public String getrURL() {
		return rURL;
	}
	public void setrURL(String rURL) {
		this.rURL = rURL;
	}
	public String getLK_I_SAGO_NO() {
		return LK_I_SAGO_NO;
	}
	public void setLK_I_SAGO_NO(String lK_I_SAGO_NO) {
		LK_I_SAGO_NO = lK_I_SAGO_NO;
	}
	public String getLK_I_SAGO_GB() {
		return LK_I_SAGO_GB;
	}
	public void setLK_I_SAGO_GB(String lK_I_SAGO_GB) {
		LK_I_SAGO_GB = lK_I_SAGO_GB;
	}
	public String getLK_I_SAGO_SEQ() {
		return LK_I_SAGO_SEQ;
	}
	public void setLK_I_SAGO_SEQ(String lK_I_SAGO_SEQ) {
		LK_I_SAGO_SEQ = lK_I_SAGO_SEQ;
	}
	public String getLK_I_GUBUN() {
		return LK_I_GUBUN;
	}
	public void setLK_I_GUBUN(String lK_I_GUBUN) {
		LK_I_GUBUN = lK_I_GUBUN;
	}
	public String getLK_TRID() {
		return LK_TRID;
	}
	public void setLK_TRID(String lK_TRID) {
		LK_TRID = lK_TRID;
	}
	public String getLK_FLAG() {
		return LK_FLAG;
	}
	public void setLK_FLAG(String lK_FLAG) {
		LK_FLAG = lK_FLAG;
	}
	public String getLK_NT_CD() {
		return LK_NT_CD;
	}
	public void setLK_NT_CD(String lK_NT_CD) {
		LK_NT_CD = lK_NT_CD;
	}
	public String getLK_RSP_TIME() {
		return LK_RSP_TIME;
	}
	public void setLK_RSP_TIME(String lK_RSP_TIME) {
		LK_RSP_TIME = lK_RSP_TIME;
	}
	public String getLK_COMP_GB() {
		return LK_COMP_GB;
	}
	public void setLK_COMP_GB(String lK_COMP_GB) {
		LK_COMP_GB = lK_COMP_GB;
	}
	public String getLK_COMP_CD() {
		return LK_COMP_CD;
	}
	public void setLK_COMP_CD(String lK_COMP_CD) {
		LK_COMP_CD = lK_COMP_CD;
	}
	public String getLK_FILLER() {
		return LK_FILLER;
	}
	public void setLK_FILLER(String lK_FILLER) {
		LK_FILLER = lK_FILLER;
	}
	public String getLK_USER_ID() {
		return LK_USER_ID;
	}
	public void setLK_USER_ID(String lK_USER_ID) {
		LK_USER_ID = lK_USER_ID;
	}
	public String getLK_PART_GB1() {
		return LK_PART_GB1;
	}
	public void setLK_PART_GB1(String lK_PART_GB1) {
		LK_PART_GB1 = lK_PART_GB1;
	}
	public String getLK_PART_GB2() {
		return LK_PART_GB2;
	}
	public void setLK_PART_GB2(String lK_PART_GB2) {
		LK_PART_GB2 = lK_PART_GB2;
	}
	public String getLK_UPMU_CD1() {
		return LK_UPMU_CD1;
	}
	public void setLK_UPMU_CD1(String lK_UPMU_CD1) {
		LK_UPMU_CD1 = lK_UPMU_CD1;
	}
	public String getLK_UPMU_CD2() {
		return LK_UPMU_CD2;
	}
	public void setLK_UPMU_CD2(String lK_UPMU_CD2) {
		LK_UPMU_CD2 = lK_UPMU_CD2;
	}
	public String getLK_UPMU_CD3() {
		return LK_UPMU_CD3;
	}
	public void setLK_UPMU_CD3(String lK_UPMU_CD3) {
		LK_UPMU_CD3 = lK_UPMU_CD3;
	}
	public String getLK_GULK_GB() {
		return LK_GULK_GB;
	}
	public void setLK_GULK_GB(String lK_GULK_GB) {
		LK_GULK_GB = lK_GULK_GB;
	}
	public String getLK_CM_FILLER() {
		return LK_CM_FILLER;
	}
	public void setLK_CM_FILLER(String lK_CM_FILLER) {
		LK_CM_FILLER = lK_CM_FILLER;
	}
	public String getLK_RETURN_CD() {
		return LK_RETURN_CD;
	}
	public void setLK_RETURN_CD(String lK_RETURN_CD) {
		LK_RETURN_CD = lK_RETURN_CD;
	}
	public String getLK_MSG_CD1() {
		return LK_MSG_CD1;
	}
	public void setLK_MSG_CD1(String lK_MSG_CD1) {
		LK_MSG_CD1 = lK_MSG_CD1;
	}
	public String getLK_MSG_CD2() {
		return LK_MSG_CD2;
	}
	public void setLK_MSG_CD2(String lK_MSG_CD2) {
		LK_MSG_CD2 = lK_MSG_CD2;
	}
	public String getH_LK_MESSAGE1() {
		return H_LK_MESSAGE1;
	}
	public void setH_LK_MESSAGE1(String h_LK_MESSAGE1) {
		H_LK_MESSAGE1 = h_LK_MESSAGE1;
	}
	public String getH_LK_MESSAGE2() {
		return H_LK_MESSAGE2;
	}
	public void setH_LK_MESSAGE2(String h_LK_MESSAGE2) {
		H_LK_MESSAGE2 = h_LK_MESSAGE2;
	}
	public String getLK_SAGO_NO() {
		return LK_SAGO_NO;
	}
	public void setLK_SAGO_NO(String lK_SAGO_NO) {
		LK_SAGO_NO = lK_SAGO_NO;
	}
	public String getLK_CAR_NO() {
		return LK_CAR_NO;
	}
	public void setLK_CAR_NO(String lK_CAR_NO) {
		LK_CAR_NO = lK_CAR_NO;
	}
	public String getLK_CAR_NAME() {
		return LK_CAR_NAME;
	}
	public void setLK_CAR_NAME(String lK_CAR_NAME) {
		LK_CAR_NAME = lK_CAR_NAME;
	}
	public String getLK_BUPUM_GMEK() {
		return LK_BUPUM_GMEK;
	}
	public void setLK_BUPUM_GMEK(String lK_BUPUM_GMEK) {
		LK_BUPUM_GMEK = lK_BUPUM_GMEK;
	}
	public String getLK_GONGIM_GMEK() {
		return LK_GONGIM_GMEK;
	}
	public void setLK_GONGIM_GMEK(String lK_GONGIM_GMEK) {
		LK_GONGIM_GMEK = lK_GONGIM_GMEK;
	}
	public String getLK_TKYAK_NAME1() {
		return LK_TKYAK_NAME1;
	}
	public void setLK_TKYAK_NAME1(String lK_TKYAK_NAME1) {
		LK_TKYAK_NAME1 = lK_TKYAK_NAME1;
	}
	public String getLK_TKYAK_PL_CMT1() {
		return LK_TKYAK_PL_CMT1;
	}
	public void setLK_TKYAK_PL_CMT1(String lK_TKYAK_PL_CMT1) {
		LK_TKYAK_PL_CMT1 = lK_TKYAK_PL_CMT1;
	}
	public String getLK_TKYAK_NAME2() {
		return LK_TKYAK_NAME2;
	}
	public void setLK_TKYAK_NAME2(String lK_TKYAK_NAME2) {
		LK_TKYAK_NAME2 = lK_TKYAK_NAME2;
	}
	public String getLK_TKYAK_PL_CMT2() {
		return LK_TKYAK_PL_CMT2;
	}
	public void setLK_TKYAK_PL_CMT2(String lK_TKYAK_PL_CMT2) {
		LK_TKYAK_PL_CMT2 = lK_TKYAK_PL_CMT2;
	}
	public String getLK_TKYAK_NAME3() {
		return LK_TKYAK_NAME3;
	}
	public void setLK_TKYAK_NAME3(String lK_TKYAK_NAME3) {
		LK_TKYAK_NAME3 = lK_TKYAK_NAME3;
	}
	public String getLK_TKYAK_PL_CMT3() {
		return LK_TKYAK_PL_CMT3;
	}
	public void setLK_TKYAK_PL_CMT3(String lK_TKYAK_PL_CMT3) {
		LK_TKYAK_PL_CMT3 = lK_TKYAK_PL_CMT3;
	}
	public String getLK_TKYAK_NAME4() {
		return LK_TKYAK_NAME4;
	}
	public void setLK_TKYAK_NAME4(String lK_TKYAK_NAME4) {
		LK_TKYAK_NAME4 = lK_TKYAK_NAME4;
	}
	public String getLK_TKYAK_PL_CMT4() {
		return LK_TKYAK_PL_CMT4;
	}
	public void setLK_TKYAK_PL_CMT4(String lK_TKYAK_PL_CMT4) {
		LK_TKYAK_PL_CMT4 = lK_TKYAK_PL_CMT4;
	}
	public String getLK_TKYAK_NAME5() {
		return LK_TKYAK_NAME5;
	}
	public void setLK_TKYAK_NAME5(String lK_TKYAK_NAME5) {
		LK_TKYAK_NAME5 = lK_TKYAK_NAME5;
	}
	public String getLK_TKYAK_PL_CMT5() {
		return LK_TKYAK_PL_CMT5;
	}
	public void setLK_TKYAK_PL_CMT5(String lK_TKYAK_PL_CMT5) {
		LK_TKYAK_PL_CMT5 = lK_TKYAK_PL_CMT5;
	}
	public String getLK_TKYAK_NAME6() {
		return LK_TKYAK_NAME6;
	}
	public void setLK_TKYAK_NAME6(String lK_TKYAK_NAME6) {
		LK_TKYAK_NAME6 = lK_TKYAK_NAME6;
	}
	public String getLK_TKYAK_PL_CMT6() {
		return LK_TKYAK_PL_CMT6;
	}
	public void setLK_TKYAK_PL_CMT6(String lK_TKYAK_PL_CMT6) {
		LK_TKYAK_PL_CMT6 = lK_TKYAK_PL_CMT6;
	}
	public String getLK_TKYAK_CNT() {
		return LK_TKYAK_CNT;
	}
	public void setLK_TKYAK_CNT(String lK_TKYAK_CNT) {
		LK_TKYAK_CNT = lK_TKYAK_CNT;
	}
	public String getLK_TKYAK_TOT_PL_CMT() {
		return LK_TKYAK_TOT_PL_CMT;
	}
	public void setLK_TKYAK_TOT_PL_CMT(String lK_TKYAK_TOT_PL_CMT) {
		LK_TKYAK_TOT_PL_CMT = lK_TKYAK_TOT_PL_CMT;
	}
	public String getLK_PL_CMT() {
		return LK_PL_CMT;
	}
	public void setLK_PL_CMT(String lK_PL_CMT) {
		LK_PL_CMT = lK_PL_CMT;
	}
	public String getLK_PASON_BUWIE_NAME1() {
		return LK_PASON_BUWIE_NAME1;
	}
	public void setLK_PASON_BUWIE_NAME1(String lK_PASON_BUWIE_NAME1) {
		LK_PASON_BUWIE_NAME1 = lK_PASON_BUWIE_NAME1;
	}
	public String getLK_PASON_BUWIE_NAME2() {
		return LK_PASON_BUWIE_NAME2;
	}
	public void setLK_PASON_BUWIE_NAME2(String lK_PASON_BUWIE_NAME2) {
		LK_PASON_BUWIE_NAME2 = lK_PASON_BUWIE_NAME2;
	}
	public String getLK_PASON_BUWIE_NAME3() {
		return LK_PASON_BUWIE_NAME3;
	}
	public void setLK_PASON_BUWIE_NAME3(String lK_PASON_BUWIE_NAME3) {
		LK_PASON_BUWIE_NAME3 = lK_PASON_BUWIE_NAME3;
	}
	public String getLK_PASON_BUWIE_NAME4() {
		return LK_PASON_BUWIE_NAME4;
	}
	public void setLK_PASON_BUWIE_NAME4(String lK_PASON_BUWIE_NAME4) {
		LK_PASON_BUWIE_NAME4 = lK_PASON_BUWIE_NAME4;
	}
	public String getLK_PASON_BUWIE_NAME5() {
		return LK_PASON_BUWIE_NAME5;
	}
	public void setLK_PASON_BUWIE_NAME5(String lK_PASON_BUWIE_NAME5) {
		LK_PASON_BUWIE_NAME5 = lK_PASON_BUWIE_NAME5;
	}
	public String getLK_PASON_BUWIE_NAME6() {
		return LK_PASON_BUWIE_NAME6;
	}
	public void setLK_PASON_BUWIE_NAME6(String lK_PASON_BUWIE_NAME6) {
		LK_PASON_BUWIE_NAME6 = lK_PASON_BUWIE_NAME6;
	}
	public String getLK_PASON_BUWIE_NAME7() {
		return LK_PASON_BUWIE_NAME7;
	}
	public void setLK_PASON_BUWIE_NAME7(String lK_PASON_BUWIE_NAME7) {
		LK_PASON_BUWIE_NAME7 = lK_PASON_BUWIE_NAME7;
	}
	public String getLK_PASON_BUWIE_NAME8() {
		return LK_PASON_BUWIE_NAME8;
	}
	public void setLK_PASON_BUWIE_NAME8(String lK_PASON_BUWIE_NAME8) {
		LK_PASON_BUWIE_NAME8 = lK_PASON_BUWIE_NAME8;
	}
	public String getLK_PASON_BUWIE_NAME9() {
		return LK_PASON_BUWIE_NAME9;
	}
	public void setLK_PASON_BUWIE_NAME9(String lK_PASON_BUWIE_NAME9) {
		LK_PASON_BUWIE_NAME9 = lK_PASON_BUWIE_NAME9;
	}
	public String getLK_PASON_BUWIE_NAME10() {
		return LK_PASON_BUWIE_NAME10;
	}
	public void setLK_PASON_BUWIE_NAME10(String lK_PASON_BUWIE_NAME10) {
		LK_PASON_BUWIE_NAME10 = lK_PASON_BUWIE_NAME10;
	}
	public String getLK_PASON_BUWIE_NAME11() {
		return LK_PASON_BUWIE_NAME11;
	}
	public void setLK_PASON_BUWIE_NAME11(String lK_PASON_BUWIE_NAME11) {
		LK_PASON_BUWIE_NAME11 = lK_PASON_BUWIE_NAME11;
	}
	public String getLK_PASON_BUWIE_NAME12() {
		return LK_PASON_BUWIE_NAME12;
	}
	public void setLK_PASON_BUWIE_NAME12(String lK_PASON_BUWIE_NAME12) {
		LK_PASON_BUWIE_NAME12 = lK_PASON_BUWIE_NAME12;
	}
	public String getLK_SURICHEO_NAME() {
		return LK_SURICHEO_NAME;
	}
	public void setLK_SURICHEO_NAME(String lK_SURICHEO_NAME) {
		LK_SURICHEO_NAME = lK_SURICHEO_NAME;
	}
	public String getLK_DAMDANGJA_NAME() {
		return LK_DAMDANGJA_NAME;
	}
	public void setLK_DAMDANGJA_NAME(String lK_DAMDANGJA_NAME) {
		LK_DAMDANGJA_NAME = lK_DAMDANGJA_NAME;
	}
	public String getLK_DAMDANGJA_TEL() {
		return LK_DAMDANGJA_TEL;
	}
	public void setLK_DAMDANGJA_TEL(String lK_DAMDANGJA_TEL) {
		LK_DAMDANGJA_TEL = lK_DAMDANGJA_TEL;
	}
	public String getLK_IMAGE_PATH1() {
		return LK_IMAGE_PATH1;
	}
	public void setLK_IMAGE_PATH1(String lK_IMAGE_PATH1) {
		LK_IMAGE_PATH1 = lK_IMAGE_PATH1;
	}
	public String getLK_IMAGE_PATH2() {
		return LK_IMAGE_PATH2;
	}
	public void setLK_IMAGE_PATH2(String lK_IMAGE_PATH2) {
		LK_IMAGE_PATH2 = lK_IMAGE_PATH2;
	}
	public String getFILLER() {
		return FILLER;
	}
	public void setFILLER(String fILLER) {
		FILLER = fILLER;
	}
	public static String getProid() {
		return proid;
	}
	public static String getTrid() {
		return trid;
	}	
}
