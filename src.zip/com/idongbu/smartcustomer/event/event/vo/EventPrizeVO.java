package com.idongbu.smartcustomer.event.event.vo;

public class EventPrizeVO {
	private int 	eventNo;	//이벤트번호
	private String 	pTel;		//연락처
	private String 	pBirth;		//생년월일
	private String 	pName;		//성명
	
	public int getEventNo() {
		return eventNo;
	}
	public void setEventNo(int eventNo) {
		this.eventNo = eventNo;
	}
	public String getpTel() {
		return pTel;
	}
	public void setpTel(String pTel) {
		this.pTel = pTel;
	}
	public String getpBirth() {
		return pBirth;
	}
	public void setpBirth(String pBirth) {
		this.pBirth = pBirth;
	}
	public String getpName() {
		return pName;
	}
	public void setpName(String pName) {
		this.pName = pName;
	}

}
