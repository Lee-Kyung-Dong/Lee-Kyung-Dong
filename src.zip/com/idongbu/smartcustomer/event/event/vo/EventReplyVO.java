package com.idongbu.smartcustomer.event.event.vo;

public class EventReplyVO {

	private int eventNum  = 0; // 이벤트번호 
	private String snsId     = ""; // SNSID
	private String snsType   = ""; // SNSTYPE
	private String reText    = ""; // 댓글내용
	private String snsNm     = ""; // SNS NAME
	private String regDt     = ""; // 작성일
	private int eventSeq  = 0; // 이벤트댓글SEQ
	private int startNum = 0; // 댓글 시작번호
	private int endNum = 0; // 댓글 시작번호
	
	public int getEventNum() {
		return eventNum;
	}
	public void setEventNum(int eventNum) {
		this.eventNum = eventNum;
	}
	public String getSnsId() {
		return snsId;
	}
	public void setSnsId(String snsId) {
		this.snsId = snsId;
	}
	public String getSnsType() {
		return snsType;
	}
	public void setSnsType(String snsType) {
		this.snsType = snsType;
	}
	public String getReText() {
		return reText;
	}
	public void setReText(String reText) {
		this.reText = reText;
	}	
	public String getSnsNm() {
		return snsNm;
	}
	public void setSnsNm(String snsNm) {
		this.snsNm = snsNm;
	}
	public String getRegDt() {
		return regDt;
	}
	public void setRegDt(String regDt) {
		this.regDt = regDt;
	}
	public int getEventSeq() {
		return eventSeq;
	}
	public void setEventSeq(int eventSeq) {
		this.eventSeq = eventSeq;
	}
	public int getStartNum() {
		return startNum;
	}
	public void setStartNum(int startNum) {
		this.startNum = startNum;
	}
	public int getEndNum() {
		return endNum;
	}
	public void setEndNum(int endNum) {
		this.endNum = endNum;
	}
	
	
}
