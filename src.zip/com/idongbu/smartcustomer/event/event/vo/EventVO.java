package com.idongbu.smartcustomer.event.event.vo;

public class EventVO {

	private int 	eventNo;	//이벤트번호
	private String 	ingCd;		//진행코드(0:예정, 1:진행중, 2:종료)
	private String 	staDt;		//시작일
	private String 	staTm;		//시작시간
	private String 	endDt;		//종료일
	private String 	endTm;		//종료시간
	private String 	eventName;	//이벤트명
	private String 	eventURL;	//상세url
	private String 	bnrImgUrl;	//목록배너이미지url
	private String 	mainImgUrl;	//메인화면이미지url
	private String 	mainTabletImgUrl;	//메인화면태블릿이미지url
	private String 	eventDesc;	//이벤트설명
	private int 	sortNum;	//정렬순서
	private String 	strStaDt;	//시작일(뷰출력용)
	private String 	strEndDt;	//종료일(뷰출력용)

	public int getEventNo() {
		return eventNo;
	}
	public void setEventNo(int eventNo) {
		this.eventNo = eventNo;
	}
	public String getIngCd() {
		return ingCd;
	}
	public void setIngCd(String ingCd) {
		this.ingCd = ingCd;
	}
	public String getStaDt() {
		return staDt;
	}
	public void setStaDt(String staDt) {
		this.staDt = staDt;
	}
	public String getStaTm() {
		return staTm;
	}
	public void setStaTm(String staTm) {
		this.staTm = staTm;
	}
	public String getEndDt() {
		return endDt;
	}
	public void setEndDt(String endDt) {
		this.endDt = endDt;
	}
	public String getEndTm() {
		return endTm;
	}
	public void setEndTm(String endTm) {
		this.endTm = endTm;
	}
	public String getEventName() {
		return eventName;
	}
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
	public String getEventURL() {
		return eventURL;
	}
	public void setEventURL(String eventURL) {
		this.eventURL = eventURL;
	}
	public String getBnrImgUrl() {
		return bnrImgUrl;
	}
	public void setBnrImgUrl(String bnrImgUrl) {
		this.bnrImgUrl = bnrImgUrl;
	}
	public String getMainImgUrl() {
		return mainImgUrl;
	}
	public void setMainImgUrl(String mainImgUrl) {
		this.mainImgUrl = mainImgUrl;
	}
	public String getmainTabletImgUrl() {
		return mainTabletImgUrl;
	}
	public void setmainTabletImgUrl(String mainTabletImgUrl) {
		this.mainTabletImgUrl = mainTabletImgUrl;
	}	
	public int getSortNum() {
		return sortNum;
	}
	public void setSortNum(int sortNum) {
		this.sortNum = sortNum;
	}
	public String getEventDesc() {
		return eventDesc;
	}
	public void setEventDesc(String eventDesc) {
		this.eventDesc = eventDesc;
	}
	public String getStrStaDt() {
		return strStaDt;
	}
	public void setStrStaDt(String strStaDt) {
		this.strStaDt = strStaDt;
	}
	public String getStrEndDt() {
		return strEndDt;
	}
	public void setStrEndDt(String strEndDt) {
		this.strEndDt = strEndDt;
	}
	
}
