package com.idongbu.smartcustomer.event.event.mapper;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.idongbu.smartcustomer.event.event.vo.EventPrizeVO;
import com.idongbu.smartcustomer.event.event.vo.EventVO;

public interface EventDao {
	// 이벤트 목록
	List<EventVO> selectEventList(String ingCd);
	
	// 종료이벤트 목록
	List<EventVO> selectEndEventList(String ingCd);
	
	// 이벤트진행중여부 얻기
	int selectEventIngYn(int eventNo);
	
	// 이벤트 상세
	EventVO selectEventDetail(int eventNo);
	
	// 이벤트 참여
	int insertEventJoin(HashMap hm);
	
	// 홈페이지 이벤트 메인 참여
	int insertHomeMainEventJoin(HashMap hm);
	
	// 홈페이지 이벤트 상세 참여
	int insertHomeDetailEventJoin(HashMap hm);	

	// 홈페이지 이벤트 중복참여 검사
	int selectHomeEventAlreadyJoin(HashMap hm);	
	
	// 당첨자 목록
	List<EventPrizeVO> selectEventPrizeList(int eventNo);

	// 이벤트 중복참여 검사
	int selectEventAlreadyJoin(HashMap hm);
	
	// etc1 값을 키로 etc 데이터 업데이트
	int updateEtc1Key(HashMap hm);
	
	// 이벤트 SNS 댓글목록 가져오기
	List<Object> getReplyList(Map<String, Object> map);
	
	// 이벤트 SNS 댓글목록 카운트 조회
	int getReplyCnt(int eventNum);
	
	// 이벤트 SNS 댓글 등록
	int replyWrite(Map<String, Object> map);
	
	//이벤트 당일 당첨자수
	int getPrizeWinnerCurCnt(int eventNo);
	
	//이벤트 최근 한시간 당첨자수
	int getPrizeWinnerCurHourCnt(int eventNo);

	// 이벤트 즉석당첨자 등록
	int insertPrizeWinner(HashMap hm);	
	
	//기부이벤트 idongbu기부카운트
	int getDonationCnt(String evCd);
	
	//기부이벤트 idongbu 이벤트 메인 참여
	int insertHomeMainEventDonation(HashMap hm);
	
	//기부이벤트 idongbu 이벤트 상세 참여
	int insertHomeDetailEventDonation(HashMap hm);	
	
	//공인인증 어제까지 로그인 카운트
	int selectloginCnt(HashMap hm);
}
