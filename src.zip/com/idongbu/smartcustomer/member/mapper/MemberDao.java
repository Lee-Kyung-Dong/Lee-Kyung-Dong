package com.idongbu.smartcustomer.member.mapper;

import java.util.HashMap;

import com.idongbu.smartcustomer.vo.CertVO;
import com.idongbu.smartcustomer.vo.ConfirmMbrInfoVO;
import com.idongbu.smartcustomer.vo.CustomerInfoVO;
import com.idongbu.smartcustomer.vo.ExceMemberVO;
import com.idongbu.smartcustomer.vo.MemJoinVO;

public interface MemberDao {
	
	MemJoinVO selectMember(MemJoinVO vo);
	
	int insertNewMember(MemJoinVO vo);
	
	int updateMember(MemJoinVO vo);
	
	String selectFD_MB_NO_MAX();
	
	int insertCustomerChangeLog(CustomerInfoVO vo);
	
	int updateCustomerChangeLog(CustomerInfoVO vo);
	
	MemJoinVO selectIpinMember(String ipin_di);
	   
	String selectSMS_POINT_IDX_max();
	
	int insertSMS_POINT(MemJoinVO vo);
	
	int insertSMS_POINT_LOG(MemJoinVO vo);
	
	void GradeInsert(MemJoinVO vo);
	
	int insertM_CMA_CNTR_CHNG_CSINFO(CustomerInfoVO vo);
	
	String selectM_CMA_CNTR_CHNG_CSINFO(CustomerInfoVO vo);
	
	int updateM_CMA_CNTR_CHNG_CSINFO(CustomerInfoVO vo);
	
	String selectGrade(MemJoinVO vo);
	
	/**
	 * 예외고객 확인
	 * 예외고객이면 true, 예외고객이 아니면 false
	 * @param jumin
	 * @param code
	 * @return
	 */
	int isExceptionMember(ExceMemberVO exceMemberVO);
	
	CertVO getCurrCert(CertVO vo);
	
	int insertCert(CertVO vo);
	
	int updateCert(CertVO vo);
	
	int deleteCert(CertVO vo);
	
	String getIdByCert(CertVO vo);
	
	String getJuminById(CertVO vo);
	
	String getDormancyJuminById(CertVO vo);

	String getIdByIpinDi(CertVO vo);
	
	int insertCertLog(HashMap<String, String> map);
}