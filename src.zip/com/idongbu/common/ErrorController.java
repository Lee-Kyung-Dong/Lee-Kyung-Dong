package com.idongbu.common;



import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class ErrorController {

	//404,500등 에러페이지 처리 
	@RequestMapping(value = "/page/error")
	public String errorPageProcess(Model model , @ModelAttribute("ERROR") String ERROR) {
		
		return "/error/errorPage";
	}
	
}
