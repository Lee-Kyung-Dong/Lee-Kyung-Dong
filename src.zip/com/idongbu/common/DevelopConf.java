package com.idongbu.common;

public class DevelopConf {
	//개발 테스트용 true:웹브라우저로 가능 false:앱만 가능
	public static boolean IS_DEVELOP = false;
	
}
