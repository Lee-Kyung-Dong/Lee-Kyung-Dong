package com.idongbu.common;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MailFormDown {

	//메일발송용 폼다운로드 
	@RequestMapping(value = "/mailFormDown")
	public String mailFormDown(String mailFormID, String param) {
		
		return "준비중";
	}
}
