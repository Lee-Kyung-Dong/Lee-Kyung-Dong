package com.idongbu.common;

public class ESBBizHeader {
	
	private String z_chn_cd;
	private String z_user_id; //사용자 ID
	private String z_mac_adr;//Mac Address
	private String z_afcp_dvcd; //자회사구분코드
	private String z_orn_dvcd;//조직구분코드
	private String z_orn_no; //조직번호(로그인한 사용자의 소속 조직번호)
	private String z_stcn_no; //부문번호

	private String z_hdqt_no;//본부번호
	private String z_bzlv_no;//사업단번호
	private String z_bh_no;//지점번호
	private String z_brc_no;//출장소번호
	private String z_cnof_yn; //겸직여부
	private String z_ormm_no; //조직원번호
	private String z_ormm_dvcd;//조직원구분코드
	private String z_ormm_tpcd;//조직원유형코드
	private String z_ormm_ptl_tpcd;//조직원세부유형코드

	private String z_auth_grp_cd;//(업무)권한그룹코드(Role ID)
	private String z_comm_auth_grp_cd; //공통권한그룹코드(Role ID)

	private String errorCode;//에러코드
	private String z_msg_cd;//메시지 코드
	private String returnMessage;//메시지 내용
	private String z_err_cpn_id;//에러컴포넌트ID
	private String z_page_if_key; //페이징 처리 - vo명

	private String z_next_page_exis_yn;//페이징 처리 - 다음 페이지 존재 여부(존재 : 1, 존재 안함 :0)
	private String z_row_cnt_per_page;//페이징 처리 - 페이지 당 Row 수
	private String z_rqst_page_no;//페이징 처리 - 현재 페이지
	private String z_wh_cnum;//페이징 처리 - 전체 건 수
	private String z_wh_page_cnt;//페이징 처리 - 총 페이지

	private String z_user_page_key_set;
	private String prev_z_user_page_key_set;
	private String page_action_type;
	
	private String traceFlag; // 트레이스 로그 On/Off
	
	
	
	public String getZ_chn_cd() {
		return z_chn_cd;
	}
	public void setZ_chn_cd(String z_chn_cd) {
		this.z_chn_cd = z_chn_cd;
	}
	public String getZ_user_id() {
		return z_user_id;
	}
	public void setZ_user_id(String z_user_id) {
		this.z_user_id = z_user_id;
	}
	public String getZ_mac_adr() {
		return z_mac_adr;
	}
	public void setZ_mac_adr(String z_mac_adr) {
		this.z_mac_adr = z_mac_adr;
	}
	public String getZ_afcp_dvcd() {
		return z_afcp_dvcd;
	}
	public void setZ_afcp_dvcd(String z_afcp_dvcd) {
		this.z_afcp_dvcd = z_afcp_dvcd;
	}
	public String getZ_orn_dvcd() {
		return z_orn_dvcd;
	}
	public void setZ_orn_dvcd(String z_orn_dvcd) {
		this.z_orn_dvcd = z_orn_dvcd;
	}
	public String getZ_orn_no() {
		return z_orn_no;
	}
	public void setZ_orn_no(String z_orn_no) {
		this.z_orn_no = z_orn_no;
	}
	public String getZ_stcn_no() {
		return z_stcn_no;
	}
	public void setZ_stcn_no(String z_stcn_no) {
		this.z_stcn_no = z_stcn_no;
	}
	public String getZ_hdqt_no() {
		return z_hdqt_no;
	}
	public void setZ_hdqt_no(String z_hdqt_no) {
		this.z_hdqt_no = z_hdqt_no;
	}
	public String getZ_bzlv_no() {
		return z_bzlv_no;
	}
	public void setZ_bzlv_no(String z_bzlv_no) {
		this.z_bzlv_no = z_bzlv_no;
	}
	public String getZ_bh_no() {
		return z_bh_no;
	}
	public void setZ_bh_no(String z_bh_no) {
		this.z_bh_no = z_bh_no;
	}
	public String getZ_brc_no() {
		return z_brc_no;
	}
	public void setZ_brc_no(String z_brc_no) {
		this.z_brc_no = z_brc_no;
	}
	public String getZ_cnof_yn() {
		return z_cnof_yn;
	}
	public void setZ_cnof_yn(String z_cnof_yn) {
		this.z_cnof_yn = z_cnof_yn;
	}
	public String getZ_ormm_no() {
		return z_ormm_no;
	}
	public void setZ_ormm_no(String z_ormm_no) {
		this.z_ormm_no = z_ormm_no;
	}
	public String getZ_ormm_dvcd() {
		return z_ormm_dvcd;
	}
	public void setZ_ormm_dvcd(String z_ormm_dvcd) {
		this.z_ormm_dvcd = z_ormm_dvcd;
	}
	public String getZ_ormm_tpcd() {
		return z_ormm_tpcd;
	}
	public void setZ_ormm_tpcd(String z_ormm_tpcd) {
		this.z_ormm_tpcd = z_ormm_tpcd;
	}
	public String getZ_ormm_ptl_tpcd() {
		return z_ormm_ptl_tpcd;
	}
	public void setZ_ormm_ptl_tpcd(String z_ormm_ptl_tpcd) {
		this.z_ormm_ptl_tpcd = z_ormm_ptl_tpcd;
	}
	public String getZ_auth_grp_cd() {
		return z_auth_grp_cd;
	}
	public void setZ_auth_grp_cd(String z_auth_grp_cd) {
		this.z_auth_grp_cd = z_auth_grp_cd;
	}
	public String getZ_comm_auth_grp_cd() {
		return z_comm_auth_grp_cd;
	}
	public void setZ_comm_auth_grp_cd(String z_comm_auth_grp_cd) {
		this.z_comm_auth_grp_cd = z_comm_auth_grp_cd;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getZ_msg_cd() {
		return z_msg_cd;
	}
	public void setZ_msg_cd(String z_msg_cd) {
		this.z_msg_cd = z_msg_cd;
	}
	public String getReturnMessage() {
		return returnMessage;
	}
	public void setReturnMessage(String returnMessage) {
		this.returnMessage = returnMessage;
	}
	public String getZ_err_cpn_id() {
		return z_err_cpn_id;
	}
	public void setZ_err_cpn_id(String z_err_cpn_id) {
		this.z_err_cpn_id = z_err_cpn_id;
	}
	public String getZ_page_if_key() {
		return z_page_if_key;
	}
	public void setZ_page_if_key(String z_page_if_key) {
		this.z_page_if_key = z_page_if_key;
	}
	public String getZ_next_page_exis_yn() {
		return z_next_page_exis_yn;
	}
	public void setZ_next_page_exis_yn(String z_next_page_exis_yn) {
		this.z_next_page_exis_yn = z_next_page_exis_yn;
	}
	public String getZ_row_cnt_per_page() {
		return z_row_cnt_per_page;
	}
	public void setZ_row_cnt_per_page(String z_row_cnt_per_page) {
		this.z_row_cnt_per_page = z_row_cnt_per_page;
	}
	public String getZ_rqst_page_no() {
		return z_rqst_page_no;
	}
	public void setZ_rqst_page_no(String z_rqst_page_no) {
		this.z_rqst_page_no = z_rqst_page_no;
	}
	public String getZ_wh_cnum() {
		return z_wh_cnum;
	}
	public void setZ_wh_cnum(String z_wh_cnum) {
		this.z_wh_cnum = z_wh_cnum;
	}
	public String getZ_wh_page_cnt() {
		return z_wh_page_cnt;
	}
	public void setZ_wh_page_cnt(String z_wh_page_cnt) {
		this.z_wh_page_cnt = z_wh_page_cnt;
	}
	public String getZ_user_page_key_set() {
		return z_user_page_key_set;
	}
	public void setZ_user_page_key_set(String z_user_page_key_set) {
		this.z_user_page_key_set = z_user_page_key_set;
	}
	public String getTraceFlag() {
		return traceFlag;
	}
	public void setTraceFlag(String traceFlag) {
		this.traceFlag = traceFlag;
	}
	public String getPrev_z_user_page_key_set() {
		return prev_z_user_page_key_set;
	}
	public void setPrev_z_user_page_key_set(String prev_z_user_page_key_set) {
		this.prev_z_user_page_key_set = prev_z_user_page_key_set;
	}
	public String getPage_action_type() {
		return page_action_type;
	}
	public void setPage_action_type(String page_action_type) {
		this.page_action_type = page_action_type;
	}
	
	
	

}
