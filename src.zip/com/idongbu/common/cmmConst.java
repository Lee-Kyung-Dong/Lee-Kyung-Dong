package com.idongbu.common;

public class cmmConst {

	//세션 타임아웃 시간  10분 
	public static final long SESSION_TIMEOUT_SEC = 10;
	
	//보안키패드용 키
	public static final byte[] MTRANS_KEY = { 'M', 'o', 'b', 'i', 'l', 'e', 'T', 'r' , 'a', 'n', 's', 'K', 'e', 'y', '1', '0' };
	
	/* 개인정보보호 데이터 마스킹 */
	public static final int JUMIN_MASKING_LEN 	= 6;	//주민번호 마스킹 문자수
	public static final int EMAIL_MASKING_LEN 	= 3;	//이메일id 마스킹 문자수
	public static final int CARD_MASKING_START 	= 7;	//카드번호 마스킹 시작자리수
	public static final int CARD_MASKING_LEN 	= 5;	//카드번호 마스킹 문자수
	public static final int ACCOUNT_MASKING_LEN = 4;	//계좌번호 마스킹 문자수
	
	
	/* 무결성 검증할 항목 */
	//자동이체 계좌변경
	public static final String[] veriChAcc = {"JJ_BANK_CD", "JJ_ICHE_D",
												"JJ_YEGMJU_TEL1", "JJ_YEGMJU_TEL2", "JJ_YEGMJU_TEL3"};
	//고객정보변경
	public static final String[] veriCustInfo = {"si_hp_tel1", "si_hp_tel2", "si_hp_tel3", "bf_si_h_tel1",
												"bf_si_h_tel2", "bf_si_h_tel3", "bf_si_h_tel3", "si_h_tel2",
												"si_h_tel3", "frnt_email", "aftr_email"};
	//레인보우
	public static final String[] veriRainBow = {"SEND_HP1", "SEND_HP2", "SEND_HP3"};
	//대출
	public static final String[] veriLoan = {"reqLoanMoneyWon"};
	//보험금청구:상해/질병보험금청구
	public static final String[] veriDesease = {"SS_SAGO_YMD", "SS_SAGO_HM", "SS_GOGEK_TEL", "SS_WONIN_CD",
												"SS_TYPE_CD", "BB_SANGDAM_GB", "CP_TYPE",
												"_BANK_CD", "_BANK_ACCOUNT", "singu_gb" };                
	
    
	
	
	//CMS 게시판 테이블
	public static final String CMS_TABLE_WEEKLY = "WCM_BOARD_B0004";	//weekly focus
	public static final String CMS_TABLE_BEAUTY = "WCM_BOARD_B0005";	//뷰티라이프
	public static final String CMS_TABLE_HEALTH = "WCM_BOARD_B0006";	//헬스라이프
	
	
	//메인화면 공지사항제목 출력되는 길이
	public static final int MAIN_NOTICE_LEN 		= 24;
	//태블릿 메인화면 공지사항제목 출력되는 길이
	public static final int MAIN_TABLET_NOTICE_LEN 	= 24;

	
	//페이지뷰 쌓을 메뉴 ID별 번호 /idongbu/info/product/healchil/firstbaySpecial
	public static final String[] PAGEVIEW_DATA = {
												 "/idongbu/contract/directDebitList", "33",  					//자동이체계좌변경
												 "/idongbu/customer/selectCustomerInfo", "28",  				//고객정보변경
												 "/idongbu/info/counter/carrider/mileage01", "26",  			//주행거리특약 특약안내
												 "/idongbu/info/counter/carrider/blackBox01", "27",  			//블랙박스특약 특약안내
												 "/idongbu/service/rainbow/rainbow01", "45",  					//레인보우서비스
												 "/idongbu/counter/payment/payment01", "58", 					//실시간출금
												 "/idongbu/counter/payment/payment03", "60",					//가상계좌납입
												 "/idongbu/counter/widthdrawel/widthdrawel01", "62",			//중도금인출
												 "/idongbu/contractLoan/step1", "29",							//보험계약대출
												 "/idongbu/contractLoan/returnStep1", "31",  					//대출상환
												 "/idongbu/contractLoan/loanLiveStatus", "09",  				//대출현황
												 "/idongbu/contractLoan/changeAccountStep1", "32",				//이자납입
												 "/idongbu/reward/care/agree", "39",  							//장기사고접수
												 "/idongbu/reward/care/docSelectJm?targetPage=2", "40",  		//장기보상처리내용조회
												 "/idongbu/reward/car/docSelectJm?targetPage=1", "38", 			//자동차 보험금 청구서류 제출
												 "/idongbu/reward/car/docSelectJm?targetPage=2", "16",			//자동차 보상처리 내용조회
												 "/idongbu/emergency/emergencyCertCar?t_gb=1", "05",  			//긴급출동모바일신청
												 "/idongbu/emergency/emergencyCertCar?t_gb=2", "06", 			//긴급출동모바일이용내역
												 "/idongbu/info/product/travel/outdoor", "21",  				//Outdoor 레저보험
												 "/idongbu/info/product/cardrive/carInsuSpecial", "20",			//자동차보험
												 "/idongbu/info/product/cardrive/cardriveSpecial", "10",		//가족사랑운전자보험
												 "/idongbu/info/product/healchil/firstbaySpecial", "11", 		//우리아이 첫보험
												 "/idongbu/info/product/healchil/lifeFirstSpecial", "12",  		//내생에 첫 건강보험
												 "/idongbu/info/product/healchil/stepCancer", "13",  			//단계별로 더 받는 암보험
												 "/idongbu/info/product/healchil/lifeReliableSpecial", "14",  	//내생애 든든 종합
												 "/idongbu/info/product/pension/pensionSpecial", "15",			//스마트 연금보험
												 "/idongbu/service/consult/lifeHappy/lifeHappy01", "41",		//내인생행복진단
												 "/idongbu/info/service/consult/guarantee", "55",				//간편보장분석
												 "/idongbu/info/service/consult/myFina01", "42",				//나의재무상태분석
												 "/idongbu/info/loan/creditLo/creditLo01", "07",				//신용대출콜센터
												 "/idongbu/info/loan/estateLo/estateLo01", "08",				//부동산담보대출콜센터
												 "/idongbu/info/service/carSer/promyCarMain", "46",				//프로미카서비스
												 "/idongbu/search/search01", "22",								//서비스망 찾기(메인)
												 "/idongbu/info/service/search/search01", "22",					//서비스망 찾기
												 "/idongbu/info/service/arsservice/arsServiceMain", "44",		//고객상담센터 ARS 서비스
												 "/idongbu/info/service/vipcus/vipCus01", "43", 				//우수고객서비스
												 "/idongbu/event/notice/noticeList", "54", 						//공지사항
												 "/idongbu/info/reward/accicom/acciMain", "03",  				//사고접수콜 - 메인
												 "/idongbu/info/reward/accicom/acciHow01", "03",  				//사고접수콜 - 차량의 정지
												 "/idongbu/info/reward/accicom/acciHow02", "03",  				//사고접수콜 - 사상자 구호
												 "/idongbu/info/reward/accicom/acciHow03", "03",  				//사고접수콜 - 사고현장 보존
												 "/idongbu/info/reward/accicom/acciHow04", "03",  				//사고접수콜 - 경찰서 신고
												 "/idongbu/info/reward/accicom/acciHow05", "03",  				//사고접수콜 - 보험사 접수
												 "/idongbu/info/reward/accicom/acciHow06", "03",  				//사고접수콜 - 사고내용 메모
												 "/idongbu/info/reward/accicom/acciStep", "03",  				//사고접수콜 - 사고처리 절차
												 "/idongbu/info/service/carSer/emergencyMain", "04",  			//긴급출동 콜 - 메인 
												 "/idongbu/service/carSer/emergency12", "04",  					//긴급출동 콜 - 안내
												 "/idongbu/emergency/emergencyCarList", "04",  					//긴급출동 콜 - 계약확인
												 "/idongbu/emergency/emergencyTkyakList", "04",  				//긴급출동 콜 - 특약선택
												 "/idongbu/info/service/carSer/emergency12", "04",  			//긴급출동 콜 - 안내(메인)
												 "/idongbu/contract/contractDetailLongNapList", "24",  			//계약 조회 - 장기보험료납입조회
												 "/idongbu/contract/contractDetailNormalDambo", "24",  			//계약 조회 - 일반보험 가입담보
												 "/idongbu/contract/contractDetail", "24",  					//계약 조회 - 계약사항상세
												 "/idongbu/contract/joinList", "24",  							//계약 조회 - 계약목록
												 "/idongbu/contract/contractDetailCarInfo", "24",  				//계약 조회 - 자동차정보
												 "/idongbu/contract/contractDetailCarRegInfo", "24",  			//계약 조회 - 자동차 가입자정보
												 "/idongbu/contract/contractDetailConNapList", "24",  			//계약 조회 - 컨버전스 보험료납입조회 
												 "/idongbu/contract/contractDetailConInsurant", "24",  			//계약 조회 - 컨버전스 피보험자사항
												 "/idongbu/contract/contractDetailNotConDambo", "24",  			//계약 조회 - 비컨버전스 가입담보
												 "/idongbu/contract/contractDetailLongDambo", "24",  			//계약 조회 - 장기보험 가입담보
												 ""	};

	
}
