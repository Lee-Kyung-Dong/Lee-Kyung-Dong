package com.idongbu.common;

import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.StringReader;
import java.lang.reflect.Field;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import net.sf.json.JSONObject;
import net.sf.json.xml.XMLSerializer;

import org.apache.commons.lang.ArrayUtils;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.input.SAXBuilder;
import org.jdom.output.XMLOutputter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.idongbu.common.vo.CMMVO;
import com.thoughtworks.xstream.XStream;

@Service
public class XmlUtil {
	//private final static Logger logger = LoggerFactory.getLogger(XmlUtil.class);

//	private @Value("${server.mode}") static String SERVER_MODE;
	/**
	 * callESB
	 * CreateXml을 통해 생성된 String을 ESBCallImpl를 통해 통신한 내용을 JSON 객체에 담는다.
	 * @author	F1F13B22
	 * @since	2013.3.21
	 * @param	Object ChannelHeaderVO
	 * @param	Object bizHeaderVO
	 * @param	Object body (각각 전문VO)
	 * @param	String callUrl
	 * @return	Object
	 * @throws	ClassNotFoundException
	 * @throws	SAXException
	 * @throws	IOException
	 * @throws	ParserConfigurationException
	 */ 
	public static Object callESB(
			Object channel, Object biz, Object body, String callUrl, String code
			) throws ClassNotFoundException, SAXException, IOException, ParserConfigurationException {
		System.out.println("start");
		//XML을 생성한다.
		String xml = createXml(channel, biz, body);
		System.out.println("xml --> " + xml);
		//ESB 통신을 한다.
		String returnXml = callESBImpl(xml, callUrl + code);
		//json 객체에 담는다.
		Object result = fromXml(returnXml);
		System.out.println("JSONObject --> " + result);
		return result;

	}


	/**
	 * callESBToString
	 * CreateXml을 통해 생성된 String을 ESBCallImpl를 통해 통신한 내용을 String 객체에 담는다.
	 * @author	F1F13B22
	 * @since	2013.3.21
	 * @param	Object ChannelHeaderVO
	 * @param	Object BizHeaderVO
	 * @param	Object body (각각 전문VO)
	 * @param	String callUrl
	 * @return	String
	 * @throws	ClassNotFoundException
	 * @throws	SAXException
	 * @throws	IOException
	 * @throws	ParserConfigurationException
	 */
	public static String callESBToString(
			Object channel, Object biz, Object body, String callUrl, String code
			) throws ClassNotFoundException, SAXException, IOException, ParserConfigurationException {
//System.out.println("start");
		//XML을 생성한다.
		String xml = createXml(channel, biz, body);
		//System.out.println("xml --> " + xml);
//		System.out.println("REQUEST xml S ============================================================\n" + xml + "\nREQUEST xml E ============================================================");
		System.out.println("callUrl + code --> " + callUrl + code);
		//EBS 통신을 한다.
		String returnXml = callESBImpl(xml, callUrl + code);
		//System.out.println("returnXml --> " + returnXml);
//		String returnXmlTemp = returnXml.replaceAll("><",">\n<");
//		returnXmlTemp = returnXmlTemp.replaceAll(">\n</", "></");
//		System.out.println("RESPONSE Xml S ============================================================\n" + returnXmlTemp + "\nRESPONSE Xml E ============================================================");
		//특수문자를 치환한다.
		returnXml = replaceXmlByFaxEmail(returnXml);

		return returnXml;

	}

	public static String callESBToString(
			Object channel, Object biz, String body, String callUrl, String code
			) throws ClassNotFoundException, SAXException, IOException, ParserConfigurationException {
//System.out.println("start");
		//XML을 생성한다.
		String xml = createXml(channel, biz, body);
//		System.out.println("xml --> " + xml);
//		System.out.println("callUrl + code --> " + callUrl + code);
		//EBS 통신을 한다.
		String returnXml = callESBImpl(xml, callUrl + code);
//		System.out.println("returnXml --> " + returnXml);
		//특수문자를 치환한다.
		returnXml = replaceXmlByFaxEmail(returnXml);

		return returnXml;

	}
	public static String callLoanESBToString(
			Object channel, Object biz, String sb, String callUrl, String code
			) throws ClassNotFoundException, SAXException, IOException, ParserConfigurationException {
//System.out.println("start");
		//XML을 생성한다.
		String xml = createLoanXml(channel, biz, sb);
//		System.out.println("xml --> " + xml);
//		System.out.println("callUrl + code --> " + callUrl + code);
		//EBS 통신을 한다.
		String returnXml = callESBImpl(xml, callUrl + code);
		System.out.println(returnXml.replaceAll("><",">\n<"));
		//특수문자를 치환한다.
		returnXml = replaceXmlByFaxEmail(returnXml);

		return returnXml;

	}

public static String createLoanXml(
			Object channel, Object biz, String sb
			) throws ClassNotFoundException, SAXException, IOException, ParserConfigurationException {

		StringBuffer hxml = new StringBuffer();

		//hxml.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
		hxml.append("<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\">\n");
		hxml.append("	<soapenv:Header>\n");
		hxml.append("	</soapenv:Header>\n");
		hxml.append("	<soapenv:Body>\n");
		//hxml.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
		hxml.append("		<request>\n");

		XStream xstream = new XStream();
		xstream.alias("channelHeader", channel.getClass());
		String xml = xstream.toXML(channel);
		hxml.append(xml);
		hxml.append("\n");			
		
		xstream = new XStream();
		xstream.alias("bizHeader", biz.getClass());
		xml = xstream.toXML(biz);
		hxml.append(xml);
		hxml.append("\n");			
		
		hxml.append(sb);
		hxml.append("\n");		

		/*xstream = new XStream();
		xstream.alias("bizBody", body.getClass());
		xml = xstream.toXML(body);
		hxml.append(xml + "\n");*/

		hxml.append("		</request>\n");
		hxml.append("	</soapenv:Body>\n");
		hxml.append("</soapenv:Envelope>\n");
//		System.out.println(hxml.toString());

		return hxml.toString().replaceAll("__", "_");

	}
	/**
	 * replaceXmlByFaxEmail
	 * 팩스 이메일 관련 특수문자 치환 메소드 ('\0'인 경우 치환)
	 * @author	F1F13B22
	 * @since	2013.3.21
	 * @param	String xml
	 * @return	String
	 */
	public static String replaceXmlByFaxEmail(String xml) {

		Pattern p = Pattern.compile("\0");
		Matcher m = p.matcher(xml);

		StringBuffer sb = new StringBuffer();
		boolean rst = m.find();

		// 새로운 문자열을 만든다.
		while(rst){

			m.appendReplacement(sb, "");
			rst = m.find();

		}

		// 나머지 부분을 새로운 문자열 끝에 덫붙인다.
		m.appendTail(sb);
		//String returnStr = m.toString();
		//returnStr = returnStr.replace('\"', '`' );
		//returnStr = returnStr.replace('\'', '`' );

		return sb.toString();

	}


	/**
	 * callESBImpl
	 * ESB 통신시 bizBody의 내용을 추출한다.
	 * @author	F1F13B22
	 * @since	2013.3.21
	 * @param	String xml
	 * @param	String callUrl
	 * @return	String
	 *
	 * channelHeader 및 bizHeader의 메세지를 추가로 가져온다.
	 * @author	F1F13B22
	 * @since	2013.4.17
	 */
	public static String callESBImpl(
			String xml, String callUrl) {

//		URL url = null;
//		HttpURLConnection httpUrlConnection = null;
//		InputStream inStream = null;
		String reXml = null;
//		StringBuffer sb = new StringBuffer();

		try {
//			if(!"REAL".equalsIgnoreCase(SERVER_MODE)){
			//if ( DevelopConf.IS_DEVELOP ) {
				reXml = ESBManager.sendSoap(xml, callUrl);
//			}else{
//				
//				System.out.println("callUrl --> " + callUrl);
//				url = new URL(callUrl);
//				
//				httpUrlConnection = (HttpURLConnection)url.openConnection();
//				
//				httpUrlConnection.setRequestMethod("POST");
//				httpUrlConnection.setRequestProperty("Content-type", "text/xml; charset=UTF-8");
//				
//				httpUrlConnection.setDoInput(true);
//				httpUrlConnection.setDoOutput(true);
//				httpUrlConnection.setInstanceFollowRedirects(false);
//				System.out.println("겟 아웃풋 스트림 전입니다. --> " + httpUrlConnection);
//				OutputStream raw = httpUrlConnection.getOutputStream();
//				System.out.println("겟 아웃풋 스트림 후입니다. --> " + reXml);
//				OutputStream buffered = new BufferedOutputStream(raw);
//				OutputStreamWriter out = new OutputStreamWriter(buffered, "UTF-8");
//				
//				out.write(xml);
//				out.flush();
//				out.close();
//				
//				System.out.println("HttpUrlConnection(callESBImpl) --> " + httpUrlConnection.getResponseCode());
//				
//				if(HttpURLConnection.HTTP_OK == httpUrlConnection.getResponseCode()){//200
//					
//					inStream = httpUrlConnection.getInputStream();
//					ByteArrayOutputStream bos = new ByteArrayOutputStream();
//					byte[] buf = new byte[2048];
//					
//					try {
//						
//						int k = 0;
//						
//						while(true){
//							
//							int readlen = inStream.read(buf);
//							
//							if(readlen < 1){
//								break;
//							}
//							
//							k += readlen;
//							bos.write(buf, 0, readlen);
//							
//						}
//						reXml = new String(bos.toByteArray(), "UTF-8");
//						System.out.println("reXml --> " + reXml);
//						int beginIndex = reXml.indexOf("<response>");
//						int endIndex = reXml.indexOf("</response>");
//						int add = "</response>".length();//10
//						String response = reXml.substring(beginIndex, endIndex + add);
//						
//						sb.append(response);
//						
//						reXml = sb.toString();
//						
//						//서브루트 태그 삭제
//						reXml = reXml.replaceAll("<channelHeader>", "");
//						reXml = reXml.replaceAll("</channelHeader>", "");
//						reXml = reXml.replaceAll("<bizHeader>", "");
//						reXml = reXml.replaceAll("</bizHeader>", "");
//						reXml = reXml.replaceAll("<bizBody>", "");
//						reXml = reXml.replaceAll("</bizBody>", "");
//						
//						System.out.println("reXml1(callESBImpl) --> " + reXml);
//						
//					} catch(Exception e) {
//						e.printStackTrace();
//					}
//					
//				}
//				
//			}

		} catch(Exception e) {
			// [200617] 취약점 수정
			System.err.println("[XmlUtil.callESBImpl()] Exception 발생");
			// e.printStackTrace();
		}

		return reXml;

	}


	/**
	 * createXml
	 * 전문 XML 생성
	 * @author	F1F13B22
	 * @since	2013.3.21
	 * @param	Object ChannelHeaderVO
	 * @param	Object BizHeaderVO
	 * @param	Object body (각각 전문VO)
	 * @return	String
	 * @throws	ClassNotFoundException
	 * @throws	SAXException
	 * @throws	IOException
	 * @throws	ParserConfigurationException
	 */
	public static String createXml(
			Object channel, Object biz, Object body
			) throws ClassNotFoundException, SAXException, IOException, ParserConfigurationException {

		StringBuffer hxml = new StringBuffer();

		//hxml.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
		hxml.append("<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\">\n");
		hxml.append("	<soapenv:Header>\n");
		hxml.append("	</soapenv:Header>\n");
		hxml.append("	<soapenv:Body>\n");
		//hxml.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
		hxml.append("		<request>\n");

		XStream xstream = new XStream();
		xstream.alias("channelHeader", channel.getClass());
		String xml = xstream.toXML(channel);
		hxml.append(xml);
		hxml.append("\n");			

		xstream = new XStream();
		xstream.alias("bizHeader", biz.getClass());
		xml = xstream.toXML(biz);
		hxml.append(xml);
		hxml.append("\n");			

		xstream = new XStream();
		xstream.alias("bizBody", body.getClass());
		xml = xstream.toXML(body);
		xml = xml.replaceAll("trv_dstc_exca_mtt_", "trv_dstc_exca_mtt__");
		xml = xml.replaceAll("srch_cnd_", "srch_cnd__");
		xml = xml.replaceAll("srch_rsl_", "srch_rsl__");
		// 200923 추가
		xml = xml.replaceAll("plhd_cust_dcmt_no", "plhd__cust_dcmt_no");
		xml = xml.replaceAll("plhd_cust_no", "plhd__cust_no");
		xml = xml.replaceAll("plhd_cust_nm", "plhd__cust_nm");
		xml = xml.replaceAll("plhd_eml", "plhd__eml");
		xml = xml.replaceAll("plhd_cntp_if_", "plhd_cntp_if__");

		hxml.append(xml);
		hxml.append("\n");			

		hxml.append("		</request>\n");
		hxml.append("	</soapenv:Body>\n");
		hxml.append("</soapenv:Envelope>\n");
		//System.out.println(hxml.toString());

		return hxml.toString().replaceAll("__", "_");

	}
	
	public static String createXml(
			Object channel, Object biz, String body
			) throws ClassNotFoundException, SAXException, IOException, ParserConfigurationException {

		StringBuffer hxml = new StringBuffer();

		//hxml.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
		hxml.append("<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\">\n");
		hxml.append("	<soapenv:Header>\n");
		hxml.append("	</soapenv:Header>\n");
		hxml.append("	<soapenv:Body>\n");
		//hxml.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
		hxml.append("		<request>\n");

		XStream xstream = new XStream();
		xstream.alias("channelHeader", channel.getClass());
		String xml = xstream.toXML(channel);
		hxml.append(xml);
		hxml.append("\n");			

		xstream = new XStream();
		xstream.alias("bizHeader", biz.getClass());
		xml = xstream.toXML(biz);
		hxml.append(xml);
		hxml.append("\n");			

		xml = "<bizBody>";
		xml += body;
		xml += "</bizBody>";
		hxml.append(xml);
		hxml.append("\n");			

		hxml.append("		</request>\n");
		hxml.append("	</soapenv:Body>\n");
		hxml.append("</soapenv:Envelope>\n");
//		System.out.println(hxml.toString());

		return hxml.toString();

	}


	/**
	 * fromXml
	 * XML 객체를 JSON 객체에 담는다.
	 * @author	F1F13B22
	 * @since	2013.3.21
	 * @param	String xml
	 * @return	JSONObject
	 * @throws	ClassNotFoundException
	 * @throws	SAXException
	 * @throws	IOException
	 * @throws	ParserConfigurationException
	 */
	public static JSONObject fromXml(String xml) {

		XMLSerializer xmlSerializer = new XMLSerializer();
		JSONObject json = (JSONObject)xmlSerializer.read(xml);

		return json;

	}


	/**
	 * uniqKey
	 * 통신이 가능한 경우만 URL 값을 return 한다.
	 * @author	F1F13B22
	 * @since	2013.3.21
	 * @param	String callUrl
	 * @return	String
	 */
	public static String uniqKey(String callUrl) {

		URL url = null;
		HttpURLConnection httpUrlConnection = null;
		InputStream inStream = null;
		String uniq_Key = null;
		// [200617] 취약점 수정
		OutputStreamWriter out = null;

		try {

			url = new URL(callUrl);

			httpUrlConnection = (HttpURLConnection)url.openConnection();

			httpUrlConnection.setRequestMethod("POST");
			httpUrlConnection.setRequestProperty("Content-type", "text/xml; charset=utf-8");

			httpUrlConnection.setDoInput(true);
			httpUrlConnection.setDoOutput(true);
			httpUrlConnection.setInstanceFollowRedirects(false);

			OutputStream raw = httpUrlConnection.getOutputStream();
			OutputStream buffered = new BufferedOutputStream(raw);
			// [200617] 취약점 수정
			out = new OutputStreamWriter(buffered, "UTF-8");

			out.flush();
			out.close();
			// [200617] 취약점 수정
			out = null; 

			if(200 == httpUrlConnection.getResponseCode()){

				inStream = httpUrlConnection.getInputStream();
				ByteArrayOutputStream bos = new ByteArrayOutputStream( );
				byte[] buf = new byte[2048];

				try {

					int k = 0;

					while(true){

						int readlen = inStream.read(buf);

						if(readlen < 1){
							break;
						}

						k += readlen;
						bos.write(buf, 0, readlen);

					}

					uniq_Key = new String(bos.toByteArray(), "UTF-8");

					return uniq_Key;

				} catch(Exception e) {
					// [200617] 취약점 수정
					// e.printStackTrace();
					// e.getMessage();
					System.err.println("[XmlUtil.uniqKey()] Exception 1 발생");
				}

			}

		} catch(Exception e) {
			// [200617] 취약점 수정
//			e.printStackTrace();
			System.err.println("[XmlUtil.uniqKey()] Exception 2 발생");
		}
		// [200617] 취약점 수정
		finally {
			try{
				if(out!=null){
					out.close();
				}
			}
			catch(IOException ee){
				System.err.println("[XmlUtil.uniqKey()] IOException 발생");
		    	// ee.getMessage();
		    }
		}
		return null;

	}


	/**
	 * getNodeValue
	 * XML 노드의 value를 return 한다.
	 * @author	F1F13B22
	 * @since	2013.3.21
	 * @param	String xml
	 * @param	String exprStr
	 * @param	String name
	 * @return	String
	 */
	public static String getNodeValue(
			String xml, String exprStr, String name) {

		HashMap resultMap = getNode(xml, exprStr);

		return (String)resultMap.get(name);

	}


	/**
	 * getNode
	 * XML node와 value를 Map으로 return 한다.
	 * ex : exprStr => FWL1074R_DATA_AREA/COMM_UD_AREA/USER_UD_AREA
	 * @author	F1F13B22
	 * @since	2013.3.21
	 * @param	String xml
	 * @param	String exprStr
	 * @return	HashMap
	 */
	public static HashMap getNode(
			String xml, String exprStr) {

		HashMap resultMap = new HashMap();

		//표현식 빈값 체크
		if(exprStr == null || exprStr.trim().length() <= 0){

			System.out.println("표현식 없음");

			return resultMap;

		}

		try {

			SAXBuilder builder = new SAXBuilder();

			Document xmlDoc = (Document)builder.build(new StringReader(xml));
			Element el = xmlDoc.getRootElement();

			if (el == null){

				System.out.println("get Element 도중 오류(expr 체크바람) ");

				return resultMap;

			}

			Element tempEl = null;

			//구분자로 분기
			String expr[] = exprStr.split("/");

			//표현식으로 Element 얻어오기
			for(int i = 0; i < expr.length; i++){
				el = getElement(el, expr[i]);
			}

			List elList = el.getChildren();
			//System.out.println("########xml parsing###########");
			//System.out.println("parent element : " + el);
			//System.out.println("child element : " + elList);

			//Map 세팅
			if(elList.size() > 0){

				Iterator it = elList.iterator();

				while(it.hasNext()){

					tempEl = (Element)it.next();

					if (tempEl.getChildren().size() == 0){
						//resultMap.put(tempEl.getName(), tempEl.getValue());
						//System.out.println("["+tempEl.getName()+"] === ["+tempEl.getValue()+"]");

						resultMap.put(tempEl.getName(), tempEl.getText());
						//System.out.println("["+tempEl.getName()+"] === ["+tempEl.getText()+"]");
					}

				}

			}

			//System.out.println("map : " + resultMap);
			//System.out.println("########xml parsing###########");

		} catch(Exception e) {
			// [200617] 취약점 수정
			System.err.println("[XmlUtil.getNode()] Exception 발생");
			// System.out.println(e.getMessage());
		}

		return resultMap;

	}


	/**
	 * getNodeList
	 * XML에 같은 Element name의 하위 값들을 맵에 담아 List<Map>로 return 한다.
	 * ex : exprStr => FWL1074R_DATA_AREA/COMM_UD_AREA, USER_UD_AREA
	 * @author	F1F13B22
	 * @since	2013.3.21
	 * @param	String xml
	 * @param	String exprStr
	 * @param	String element
	 * @return	ArrayList
	 */
	public static ArrayList getNodeList(
			String xml, String exprStr, String element) {

		HashMap resultMap = null;
		ArrayList resultList = new ArrayList();

		//표현식 빈값 체크
		if(exprStr == null || exprStr.trim().length() <= 0){

			System.out.println("표현식 없음");

			return resultList;

		}

		try {

			SAXBuilder builder = new SAXBuilder();
			Document xmlDoc = (Document)builder.build(new StringReader(xml));
			Element el = xmlDoc.getRootElement();

			//구분자로 분기
			String expr[] = exprStr.split("/");

			//표현식으로 Element 얻어오기
			for(int i = 0; i < expr.length; i++){

				if (el == null){

					System.out.println("get Element 도중 오류(expr 체크바람) ");

					return resultList;

				}

				el = getElement(el, expr[i]);

			}

			List elList = el.getChildren();
			List childList = null;
			Element subEl = null;
			Element childEl = null;
			Iterator childIt = null;
			Iterator it = null;
			//System.out.println("########xml parsing###########");
			//System.out.println("parent element : " + el);
			//System.out.println("child element : " + elList);

			//Map 세팅
			if(elList.size() > 0){

				it = elList.iterator();

				while(it.hasNext()){

					subEl = (Element)it.next();

					if(element.equals(subEl.getName())){

						childList = subEl.getChildren();
						childIt = childList.iterator();
						resultMap = new HashMap();

						while(childIt.hasNext()){

							childEl = (Element)childIt.next();

							if(childEl.getChildren().size() == 0){
								resultMap.put(childEl.getName(), childEl.getValue());
							}

						}

						resultList.add(resultMap);

					}

				}

			}

		} catch(Exception e) {
			// [200617] 취약점 수정
			System.err.println("[XmlUtil.getNode()] Exception 발생");
			// System.out.println(e.getMessage());
		}

		return resultList;

	}


	/**
	 * getElement
	 * XML 속성에 하위 값이 있는 경우만 return 한다.
	 * @author	F1F13B22
	 * @since	2013.3.21
	 * @param	Element e1
	 * @param	String name
	 * @return	Element
	 */
	public static Element getElement(
			Element el, String name) {

		List list = el.getChildren();
		Element tempEl = null;

		if(list.size() > 0){

			Iterator it = list.iterator();

			while(it.hasNext()){

				tempEl = (Element)it.next();

				if(name.equals(tempEl.getName())){
					return tempEl;
				}

			}

		}

		return null;

	}

	public static String[] arrayToString(Object obj){

		String tt = obj.toString();
		tt = tt.replace('[', ' ');
		tt = tt.replace(']', ' ');
		tt = tt.replace('"', ' ');
		tt = tt.trim();
		String[] exp = tt.split(",");	//배열을 스트링으로

		return exp;

	}

	/**
	 * getNodeXml
	 * 전달받은 XML에서 name에 해당하는 노드의 xml string을 리턴함.
	 * @author	F1F14B81
	 * @since	2013.3.21
	 * @param	String xml
	 * @param	String name
	 * @return	String
	 */
	public static String getNodeXml(String xml, String name) {

		String resultMap = getNodeXmlString(xml, name);

		return resultMap;

	}

	public static String getNodeXmlString(String xml, String name) {

		String xmlOutStr = null;

		try {

			SAXBuilder builder = new SAXBuilder();

			Document xmlDoc = (Document)builder.build(new StringReader(xml));
			Element el = xmlDoc.getRootElement();

			if (el == null){

				System.out.println("get Element 도중 오류(expr 체크바람) ");

				return "";

			}

			Element childEl = el.getChild(name);

			XMLOutputter xmlOutputter = new XMLOutputter();

			xmlOutStr = xmlOutputter.outputString(childEl);

		} catch(Exception e) {
			// [200617] 취약점 수정
			System.err.println("[XmlUtil.getNodeXmlString()] Exception 발생");
			// System.out.println(e.getMessage());
		}

		return xmlOutStr;

	}

	//문자열 xml parsing 한다.
	public static org.w3c.dom.Document getDocument(String strXml) throws Exception{
		StringReader srReader = new StringReader(strXml);
		InputSource isInput = new InputSource(srReader);
		
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		DocumentBuilder db = dbf.newDocumentBuilder();
		org.w3c.dom.Document doc = db.parse(isInput);
		
		return doc;
	}
	
	//특정 태그이하의 모든 정보를 LIST 형식으로  넘겨준다.
	public static NodeList getNodeList(org.w3c.dom.Document doc, String tagName) throws Exception{
		return doc.getElementsByTagName(tagName);
	}

	//xml to vo 변환
	public static CMMVO getXmlToVo(NodeList nodeLst, CMMVO vo) throws Exception{
		for (int s = 0; s < nodeLst.getLength(); s++) {
			org.w3c.dom.Element el = (org.w3c.dom.Element)nodeLst.item(s);
			
			for (int i = 0; i < el.getChildNodes().getLength(); i++) {
				if (el.getChildNodes().item(i).getNodeType() == Node.TEXT_NODE) getTextValue(el.getNodeName(), el, vo);
				else getTextValue(el.getChildNodes().item(i).getNodeName(), (org.w3c.dom.Element)el.getChildNodes().item(i), vo);
			}
		}
		
		return vo;
	}

	//특정 태그 정보를 vo에 세팅한다.
	public static void getTextValue(String tagName, org.w3c.dom.Element el, CMMVO vo) throws Exception{
		String textVal = "";
		
		//태그에 정보가 없을때.. NullPointerException 발생. 
		try {
			textVal = el.getFirstChild().getNodeValue();
		} catch(NullPointerException nullEx) {
			// nullEx.printStackTrace();
			// [200617] 취약점 수정
			System.err.println("[XmlUtil.getTextValue()] NullPointerException 발생");
		}
		
		Field field = null;
		try {
			field = vo.getClass().getDeclaredField(tagName);
			
			if(field.getType().isArray()) {
				String[] val2 = (String[]) field.get(vo);
				val2 = (String[]) ArrayUtils.add(val2, textVal);
				field.set(vo, val2);
			} else {
				field.set(vo, textVal);
			}
		} catch(NoSuchFieldException e) {
			//field = vo.getClass().getField(tagName);
			// [200617] 취약점 수정
			System.err.println("[XmlUtil.getTextValue()] NoSuchFieldException 발생");
			// e.printStackTrace();
		}
	}
	
}
