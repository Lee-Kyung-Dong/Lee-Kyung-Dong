package com.idongbu.common.service;

import java.util.HashMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import com.idongbu.common.vo.LogAccessVO;
import com.idongbu.common.vo.MenuInfoVO;


/**
 * @info 공통부 서비스
 * @author F1F14A23
 * @since 2014. 3. 7.
 */
@Service
public class CommonService {
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	// 모바일 DB사용하는 sqlsession
/*	@Autowired(required=true)
	@Qualifier("sqlSession")
	protected SqlSessionTemplate sqlSession;*/

	// 모바일 DB사용하는 transaction
/*	@Autowired(required=true)
	@Qualifier("transactionManager")
	protected DataSourceTransactionManager transactionManager;*/
	
	public MenuInfoVO getMenuInfo(String menuid){
/*		CommonDao mapper = sqlSession.getMapper(CommonDao.class);
		return mapper.menuInfoSelect(menuid);*/
		return new MenuInfoVO();
	}
	
	public int insertAccessLog(LogAccessVO insertvo){
/*		CommonDao mapper = sqlSession.getMapper(CommonDao.class);
		return mapper.insertAccessLog(insertvo);*/
		return 1;
	}

	@SuppressWarnings("rawtypes")
	public int insertResultLog(HashMap hm){
/*		CommonDao mapper = sqlSession.getMapper(CommonDao.class);
		return mapper.insertResultLog(hm);*/
		return 1;
	}

}
