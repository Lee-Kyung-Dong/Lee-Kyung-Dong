package com.idongbu.common;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;


@Component
public class DBConnBean {
	
	private static SqlSession sqlSession;
	
	
	@Autowired
	@Qualifier("dbSqlSession")
	public void setSqlSesion(SqlSession dbSqlSession) {
		sqlSession  = dbSqlSession;
	}
	
	public static SqlSession getSqlSession() {
		return sqlSession;
	}
	

}
