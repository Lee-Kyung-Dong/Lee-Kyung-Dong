package com.idongbu.common;

public class ESBChannelHeader {
	
	private String z_rqst_dvcd; //요청 구분코드 'A' - Request(Async), 'S' - Request/reply(Sync)
	private String z_trns_org_dvcd; //송신기관구분코드(ESB : 업무구분코드, 'F' - PF, 'V' - 상품, 'X' - 경계 시스템)
	private String z_trns_org_cd;//송신기관코드(ESB : Level 1 업무구분 코드 'PDF' - PF, 'PWM' - 상품, 'ERP' - ERP)
	private String z_rc_org_dvcd;//수신기관구분코드(ESB : 업무구분코드, 'F' - PF, 'V' - 상품, 'X' - 경계 시스템)
	private String z_rc_org_cd;//수신기관코드(ESB : Level 1 업무구분 코드 'PDF' - PF, 'PWM' - 상품, 'ERP' - ERP)
	private String z_tlg_sp_cd;//전문 종별 코드 '0100' - 관리전문, '0200'-업무전문(ESB는 '0200' -업무전문 고정)
	private String z_dgs_dvcd;//거래 구분코드 - 전문별 Unique한 전문번호(ESB : 인터페이스 ID)
	private String z_resp_cd;//응답코드(ex:'0~100' - 시스템, '101~'-비즈니스)
	private String z_resp_msg;//응답메시지
	private String z_trsc_id;//트랜잭션 ID(TIMESTAMP(20)_USERID_RANDOM(4)_SERVERNAME	- TIMESTAMP(23) : 'yyyy-MM-dd HH:mm:ss.SSS')
	private String z_clt_srv_nm;//Client 서비스명 (요청하는 클라이언트 프로그램명(ex:***Servlet))
	private String z_clt_ip;//Client IP (채널/ESB/대외계/MF  서버/클라이언트 IP)
	private String traceFlag;//Client IP (채널/ESB/대외계/MF  서버/클라이언트 IP)
	
	
	public String getTraceFlag() {
		return traceFlag;
	}
	public void setTraceFlag(String traceFlag) {
		this.traceFlag = traceFlag;
	}
	public String getZ_rqst_dvcd() {
		return z_rqst_dvcd;
	}
	public void setZ_rqst_dvcd(String z_rqst_dvcd) {
		this.z_rqst_dvcd = z_rqst_dvcd;
	}
	public String getZ_trns_org_dvcd() {
		return z_trns_org_dvcd;
	}
	public void setZ_trns_org_dvcd(String z_trns_org_dvcd) {
		this.z_trns_org_dvcd = z_trns_org_dvcd;
	}
	public String getZ_trns_org_cd() {
		return z_trns_org_cd;
	}
	public void setZ_trns_org_cd(String z_trns_org_cd) {
		this.z_trns_org_cd = z_trns_org_cd;
	}
	public String getZ_rc_org_dvcd() {
		return z_rc_org_dvcd;
	}
	public void setZ_rc_org_dvcd(String z_rc_org_dvcd) {
		this.z_rc_org_dvcd = z_rc_org_dvcd;
	}
	public String getZ_rc_org_cd() {
		return z_rc_org_cd;
	}
	public void setZ_rc_org_cd(String z_rc_org_cd) {
		this.z_rc_org_cd = z_rc_org_cd;
	}
	public String getZ_tlg_sp_cd() {
		return z_tlg_sp_cd;
	}
	public void setZ_tlg_sp_cd(String z_tlg_sp_cd) {
		this.z_tlg_sp_cd = z_tlg_sp_cd;
	}
	public String getZ_dgs_dvcd() {
		return z_dgs_dvcd;
	}
	public void setZ_dgs_dvcd(String z_dgs_dvcd) {
		this.z_dgs_dvcd = z_dgs_dvcd;
	}
	public String getZ_resp_cd() {
		return z_resp_cd;
	}
	public void setZ_resp_cd(String z_resp_cd) {
		this.z_resp_cd = z_resp_cd;
	}
	public String getZ_resp_msg() {
		return z_resp_msg;
	}
	public void setZ_resp_msg(String z_resp_msg) {
		this.z_resp_msg = z_resp_msg;
	}
	public String getZ_trsc_id() {
		return z_trsc_id;
	}
	public void setZ_trsc_id(String z_trsc_id) {
		this.z_trsc_id = z_trsc_id;
	}
	public String getZ_clt_srv_nm() {
		return z_clt_srv_nm;
	}
	public void setZ_clt_srv_nm(String z_clt_srv_nm) {
		this.z_clt_srv_nm = z_clt_srv_nm;
	}
	public String getZ_clt_ip() {
		return z_clt_ip;
	}
	public void setZ_clt_ip(String z_clt_ip) {
		this.z_clt_ip = z_clt_ip;
	}
}
