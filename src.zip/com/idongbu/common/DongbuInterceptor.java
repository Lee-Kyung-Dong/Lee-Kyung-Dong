package com.idongbu.common;


import java.util.Enumeration;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.mybatis.spring.SqlSessionTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.ModelAndViewDefiningException;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.idongbu.common.service.CommonService;
import com.idongbu.common.vo.LogAccessVO;
import com.idongbu.common.vo.MenuInfoVO;
import com.idongbu.util.AppUtil;
import com.idongbu.util.StatUtil;
import com.idongbu.util.StringUtil;


	/**<pre>
	 * dongbu fire mobile web interceptor
	 * </pre>
	 * @author moongyu
	 * @since 2014. 2. 3.
	 */
	public class DongbuInterceptor extends HandlerInterceptorAdapter {
		private final Logger logger = LoggerFactory.getLogger(this.getClass());
		
		//모바일 DB사용하는 sqlsession
		@Autowired(required=true)
		@Qualifier("sqlSession")
		private SqlSessionTemplate sqlSession;
		
		@Autowired(required=true)
		private CommonService commonService;

		@Autowired(required=true)
		private StatUtil statutil;
		
		private @Value("${server.mode}") String SERVER_MODE;	//운영모드 test/real
		private @Value("${cms.domain}") String CMS_DOMAIN;
		private @Value("${cm.url}") String CM_URL;
		
		
		public boolean preHandle(HttpServletRequest request,HttpServletResponse response, Object handler) throws Exception {
			logger.debug("[ # START preHandle # ]");
			
			boolean isNoSvcTime = false;
			
			try {
				String tp = request.getParameter("targetPage");
				if(tp != null && tp.equals("SYSTEMCHECK"))
				{
					response.sendRedirect("/resources/errorpage/errorPage.html");
					return false;
				}
				/** 세션체크 **/
				HttpSession session = request.getSession();
				logger.debug("session id : " + session.getId());
				logger.debug("session LastAccessedTime : " + session.getLastAccessedTime());
				logger.debug("session CreationTime : " + session.getCreationTime());
				
				LoginManager loginManager = LoginManager.getInstance();
				
				logger.debug("###############User-Agent################");
				logger.debug((String)request.getHeader("User-Agent"));

				//로그인 풀렸을 경우 세션 남아있으면 삭제(이중화 서버 중복로그인 체크 (DB체크))
				if ( session != null && session.getAttribute("ssno") != null && session.getId() != null ) {
					if ( !loginManager.isLogin((String)session.getAttribute("ssno"), session.getId(),sqlSession) ) {
						session.invalidate();
						session = null;
					}
				}
				

				// 앱으로 실행중인지 여부
				boolean isNativeApp = AppUtil.isAppExecute(request);
				if ( isNativeApp ) request.setAttribute("isApp", "1");
				else request.setAttribute("isApp", "0");

				// OS 구분
				String mobileOsType = AppUtil.getOS(request);
				request.setAttribute("osType", mobileOsType);
				
				// 안드로이드 킷캣 여부
				if ( "A".equals(mobileOsType) ) {
					boolean isKitKat = AppUtil.getIsKitKat(request);
					if (isKitKat) {
						request.setAttribute("kitkat", "1");
					}
				}
				
			
				/** 메뉴정보 읽기 **/
				String strUriPath = (String)request.getRequestURI();
				String menuId = strUriPath;
				
				logger.debug("strUriPath : " + strUriPath);
				
				if ( request.getParameter("targetPage") != null ) {
					menuId = strUriPath + "?targetPage=" + request.getParameter("targetPage");
				} else if ( request.getParameter("t_gb") != null ) {
					menuId = strUriPath + "?t_gb=" + request.getParameter("t_gb");
				}
				strUriPath = menuId;
				
				logger.debug("menuId : " + menuId);

				MenuInfoVO menuvo = commonService.getMenuInfo(menuId);
				boolean flagMenuvo = true;
				if ( menuvo == null ) {
					menuvo = new MenuInfoVO();
					menuvo.setUseYn("1");
					menuvo.setNeedAppYn("0");
					menuvo.setLoginYn("0");
					menuvo.setCloseYn("0");
					menuvo.setMenuNm(menuId);
					menuvo.setMenuNo(1);
					flagMenuvo = false;
				}
				

				//http/https 프로토콜 도메인 설정
				String rUrl = request.getRequestURL().toString();
				rUrl = rUrl.replace("https://", "");
				rUrl = rUrl.replace("http://", "");
				String[] arrUrl1 = rUrl.split("/");
				
				String[] arrUrl2 = arrUrl1[0].split(":");
				String domain = "/";
				if ( arrUrl2.length == 1 ) {
					domain = arrUrl2[0];
					if ( isReal() ) {
						request.setAttribute("HTTP_DOMAIN", "http://" + domain);
						request.setAttribute("HTTPS_DOMAIN", "https://" + domain + ":2443");
					} else {
						request.setAttribute("HTTP_DOMAIN", "http://" + domain);
						request.setAttribute("HTTPS_DOMAIN", "http://" + domain);
					}
				} else if ( arrUrl2.length > 1 ) {
					domain = arrUrl2[0];
					if ( isReal() ) {
						request.setAttribute("HTTP_DOMAIN", "http://" + domain);
						request.setAttribute("HTTPS_DOMAIN", "https://" + domain + ":2443");
					} else {
						request.setAttribute("HTTP_DOMAIN", "http://" + domain + ":8080");
						request.setAttribute("HTTPS_DOMAIN", "http://" + domain + ":8080");
					}
				} else {
					request.setAttribute("HTTP_DOMAIN", "");
					request.setAttribute("HTTPS_DOMAIN", "");
				}
				
				request.setAttribute("CM_URL", CM_URL);
				
				
				
				
				/** 화면사용 여부 체크 **/
/*				logger.debug("화면 사용 여부 : " + menuvo.getUseYn());
				if ( !"1".equals( menuvo.getUseYn() ) ) {
					throw new Exception( "사용하지 않는 화면으로 접근하였습니다." );
				}
				
				if ( request.getParameter("photocode") == null || !"kitkatphoto".equals((String)request.getParameter("photocode")) ) {
					*//** 앱실행 필요한 화면이면 **//*
					logger.debug("앱 실행 필요서비스 여부 : " + menuvo.getNeedAppYn());
					logger.debug("앱 실행중인지 여부 : " + isNativeApp);
					if ( !isNativeApp && "1".equals( menuvo.getNeedAppYn() ) ) {
						if ( !DevelopConf.IS_DEVELOP ) {
							//앱 다운로드jsp로 이동
							response.sendRedirect("/idongbu/info/main/appDownload");
							return false;
						}
					}
					
					
					*//** 로그인 필요한 화면이면 **//*
					logger.debug("로그인 필요서비스 여부 : " + menuvo.getLoginYn());
					if ( "1".equals( menuvo.getLoginYn() ) ) {
	
						String strRefer = "/idongbu/login/loginMain?goto=" + strUriPath;

						//xecure 암호화에서 요청이면
						if ( request.getParameter("q") != null ) {
							strRefer += "&xecure=1";
						}

						//비로그인 상태면 로그인으로 이동
						if ( !DevelopConf.IS_DEVELOP ) {
							if ( !loginManager.isLogin((String)session.getAttribute("ssno"), (String)session.getId()) ) {
								// 로그인화면으로 redirect!!
								response.sendRedirect(strRefer);
								return false;
							}
						}
						
						//세션시간 지나면 로그인으로 이동
						if( ((System.currentTimeMillis() - session.getLastAccessedTime()) > (cmmConst.SESSION_TIMEOUT_SEC *60*1000) )){
							response.sendRedirect(strRefer);
							return false;
						}
					}
	
					
					*//** 전자금융회원만 가능한 화면이면 **//*
					logger.debug("전자금융회원 전용 서비스 여부 : " + menuvo.getBizMemberYn());
					if ( "1".equals( menuvo.getBizMemberYn() ) ) {
						//전자금융회원이 아니면 뒤로 이동
						if ( !"1".equals( (String)session.getAttribute("bizmember") ) ) {
	
							logger.debug("전자금융회원 아님! back!!");
							throw new Exception( "전자금융거래회원만 이용 가능한 서비스입니다. "
									+ "<br/><br/>우측 상단의 '회원가입'메뉴를 통해 전자금융거래회원 가입이 가능합니다."
									+ "<br/><br/>공인인증서 인증 상태에서는 회원가입이 불가하오니 로그아웃 버튼을 누른 후 회원가입 버튼을 눌러 주시기 바랍니다" );
						}
					}
				}*/
				
				
				/** 보안처리 **/
				// 파라미터에서 특수문자 있는지 체크
				String pName = null;
				String pValue = null;
				Enumeration<?> eParam = request.getParameterNames();
				while (eParam.hasMoreElements()) {
					pName = (String)eParam.nextElement();
					pValue = request.getParameter(pName);
					logger.debug("pName : " + pName+ "pValue : " + pValue);
					//보안키패드 데이터는 특수문자 체크 안함
					if ( "HID_JJ_GYEJWA_NO".equalsIgnoreCase(pName) ) continue;
					if ( "f_accountno".equalsIgnoreCase(pName) ) continue;
					if ( "bank_num".equalsIgnoreCase(pName) ) continue;
					if ( "RE_GYEJWA_NO".equalsIgnoreCase(pName) ) continue;
					if ( "ssno".equalsIgnoreCase(pName) ) continue;
					if ( "enc_f_card2".equalsIgnoreCase(pName) ) continue;
					if ( "enc_f_card4".equalsIgnoreCase(pName) ) continue;
					if ( "BANK_ACCOUNT".equalsIgnoreCase(pName) ) continue;
					if ( "svName".equalsIgnoreCase(pName) ) continue;	//서비스망 찾기 지도 보기시 허용되지 않는 문자열 예외처리
					if ( pName.startsWith("transkey") ) continue;
					if ( !StringUtil.strChkImpossibleChar(pValue) ) {
						throw new Exception( "허용되지 않는 문자가 포함되어 있습니다." );
					}
				}
				
				//브라우져진입체크
				System.out.println("\n -------------------------------------- ");
				Enumeration<?> e = request.getHeaderNames();
				while(e.hasMoreElements()){
					String key = e.nextElement().toString();
					System.out.println(key + " : " + request.getHeader(key));
					
				}
				
			
				//브라우저 타이틀명
				String browserTitle = flagMenuvo ? menuvo.getMenuNm() + " | DB손해보험 모바일" : "DB손해보험 모바일";
				request.setAttribute("brw_title", browserTitle);

				//CMS 도메인 설정
				request.setAttribute("CMS_DOMAIN", CMS_DOMAIN);

				//화면접속 기본로그
				String juminNo = "";
				String csnm = "";
				if ( session != null && session.getAttribute("ssno") != null ) {
					juminNo = (String)session.getAttribute("ssno");
				}
				if ( session != null && session.getAttribute("csnm") != null ) {
					csnm = (String)session.getAttribute("csnm");
				}
					
				String csIp = (String)request.getRemoteAddr();
				if ( juminNo == null ) juminNo = "";
				if ( csnm == null ) csnm = "";
				if ( csIp == null ) csIp = "";

				LogAccessVO logvo = new LogAccessVO();
				logvo.setJuminNo(juminNo);
				logvo.setCsNm(csnm);			//고객명
				logvo.setMenuNo(menuvo.getMenuNo());	//화면번호
				if ( isNativeApp ) {
					logvo.setAppType("A");				//웹앱구분
				} else {
					logvo.setAppType("W");				//웹앱구분
				}
				logvo.setDeviceOs(mobileOsType);		//OS
				logvo.setDeviceIp(csIp);				//IP
				int insertLog = commonService.insertAccessLog(logvo);
				logger.debug("insertAccessLog result : " + insertLog);
				
//				//pageview counting
				statutil.inputPageviewURI(menuId);
				
				
			} catch (Exception e) {
				e.printStackTrace();

				//오류 알림 뷰로 이동
				logger.error("" + e);
				ModelAndView modelAndView = null;
				
				if ( isNoSvcTime ) {
					modelAndView = new ModelAndView("/error/noSvcTime");
					modelAndView.addObject("rtnMsg", e.getMessage());
				} else {
					modelAndView = new ModelAndView("/main/ErrorView");
					modelAndView.addObject("rtnTitle", "알림");
					modelAndView.addObject("rtnCd", "");
					modelAndView.addObject("rtnMsg", e.getMessage());
				}
				
				throw new ModelAndViewDefiningException(modelAndView);
//				return false;
			}
			logger.debug("[ # END preHandle # ]");
			return true;
		}

		public void postHandle(HttpServletRequest request,HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {
			logger.debug("[ # START postHandle # ]");
			
			if(modelAndView!=null){
				logger.debug("model map : " + modelAndView.getModelMap());
				logger.debug("view name : " + modelAndView.getViewName());
			}
			
//			Enumeration en = request.getAttributeNames();
//			while(en.hasMoreElements()){
//				String attr = (String) en.nextElement();
//				logger.debug("key : " + attr  + " / value : " + request.getAttribute(attr));
//			}

			//로깅 ... 각 전문에서 처리하는게 낫나, 여기서 하는게 낫나
			
			logger.debug("[ # END postHandle # ]");
		}

		public void afterCompletion(HttpServletRequest request,HttpServletResponse response, Object handler, Exception ex)
				throws Exception {

			logger.debug("[ # afterCompletion # ]");
		}

		
	
		
		
		/* 
		 * 파라미터 포함된 URL 얻기
		 */
/*		private String getUrl(HttpServletRequest request)
		{
			String parameterList = ""; 
			String ret_url = request.getRequestURI();            // No Parameter url 
			  
			int k=0; 
			  
			for (java.util.Enumeration e = request.getParameterNames(); e.hasMoreElements() ;k++) { 
				String name = (String) e.nextElement(); 
				String[] value = request.getParameterValues(name);
				
				if (k == 0) ret_url = ret_url + "?"; 
				else if (k>0) ret_url = ret_url + "&"; 
					parameterList = parameterList + "&";
				
				for (int q=0; q<value.length;q++){                                 
					if (q>0) { 
						ret_url = ret_url + "&"; 
						parameterList = parameterList + "&"; 
					} 
					ret_url = ret_url + name + "=" + value[q]; 
					parameterList = parameterList + name + "=" + value[q]; 
				}
			
			}
			
			String result=ret_url;
			return result;
		}*/
		
		
		/*
		 * 무결성 검증
		 */
/*		private boolean verifyRequest(String menuId, HttpServletRequest request)
		{
			String spt = "";

			//고객정보변경
			if ( "/idongbu/customer/customerModify".equals(menuId) ) {
				for ( int i=0; i < cmmConst.veriCustInfo.length; i++ ) {
					spt += StringUtil.nvl(request.getParameter(cmmConst.veriCustInfo[i])) + ":";
				}
			}
			//자동이체계좌변경
			else if ( "/idongbu/contract/directDebitDetailSave".equals(menuId) ) {
				for ( int i=0; i < cmmConst.veriChAcc.length; i++ ) {
					spt += StringUtil.nvl(request.getParameter(cmmConst.veriChAcc[i])) + ":";
				}
			}
			//대출
			else if ( "/idongbu/contractLoan/step3".equals(menuId) ) {
				for ( int i=0; i < cmmConst.veriLoan.length; i++ ) {
					spt += StringUtil.nvl(request.getParameter(cmmConst.veriLoan[i])) + ":";
				}
			}
			//레인보우
			else if ( "/idongbu/service/rainbow/rainbowgifticon".equals(menuId) ) {
				for ( int i=0; i < cmmConst.veriRainBow.length; i++ ) {
					spt += StringUtil.nvl(request.getParameter(cmmConst.veriRainBow[i])) + ":";
				}
			}
			else 
			{
				logger.debug("무결성 검증 대상 아님" );
				return true;
			}

			logger.debug("무결성 검증 시작" );
			String shaData = (String)request.getParameter("SHA01Data");
			if ( shaData == null ) return false;

			SecurityUtil su = SecurityUtil.getInstance();
			boolean flag = su.isKeyValidate(spt, shaData);
			if (flag) {
				logger.debug("무결성 검증 : 정상" );
			} else {
				// 패킷 위변조 됨.
				logger.debug("무결성 검증 : 비정상" );
				return false;
			}
			
			return true;
		}*/
		
		//운영환경인지 여부 체크
		public boolean isReal() {
			if("REAL".equalsIgnoreCase(SERVER_MODE)){
				return true;
			}else{
				return false;
			}
		}
		
}
