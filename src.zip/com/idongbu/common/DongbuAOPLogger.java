package com.idongbu.common;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.idongbu.common.service.CommonService;
import com.idongbu.util.DBLogUtil;


@Aspect
@Component
public class DongbuAOPLogger {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired(required=true)
	private CommonService commonService;
	
	// execution : com.idongbu.smartcustomer 패키지 하위에 *Controller 내의 모든 메소드
	@Before("execution(* com.idongbu.smartcustomer..*Controller.*(..))")
	public void joinPoint(JoinPoint joinPoint){
		Signature signature = joinPoint.getSignature();
		ServletRequestAttributes servletReqAttr = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
		HttpServletRequest request = servletReqAttr.getRequest();
		
		logger.info("#####################################################################");
		logger.info("# Controller.method(param) : "+signature.toString());
		logger.info("BASIC INFO ---------------------------------------------------------------------------------------------------------------------"); 
		logger.info("# REMOTE IP : " + request.getRemoteAddr());
		logger.info("# URI : " + request.getRequestURI());
		logger.info("BODY INFO ----------------------------------------------------------------------------------------------------------------------"); 
		Enumeration<?> eParam = request.getParameterNames();
		while (eParam.hasMoreElements()) {
			String pName = (String)eParam.nextElement();
			String pValue = request.getParameter(pName);
			logger.info(pName + " : " + pValue);
		}
		logger.info("#####################################################################");
	}
	
	
	/*
	 * execution : 
	 * com.idongbu.smartcustomer 패키지 하위 *Controller 내의 return type 이 String인 모든 메소드
	 * (throw로 받은 에러 처리 수행) 
	 */
	@Around("execution(* com.idongbu.smartcustomer..*Controller.*(..)) && execution(public String *(..))")
	public String joinPoint(ProceedingJoinPoint joinPoint){
		String rtnStr = null;
		ServletRequestAttributes servletReqAttr = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
		HttpServletRequest request = servletReqAttr.getRequest();
		
		try {
			rtnStr = (String)joinPoint.proceed();

			request.setAttribute("rtnCd","000");
			request.setAttribute("rtnMsg","");
		} catch (Throwable e) {
			if ( request.getRequestURI() != null && request.getRequestURI().indexOf("submissionAndroid") > -1 ) {
				//Android로 넘길 에러
				rtnStr = "main/resAndroid";
			} else {
				
				//메세지 표시할 오류처리 
				if ( request.getAttribute("display_err_msg") != null && "1".equals((String)request.getAttribute("display_err_msg"))) {
					request.setAttribute("rtnMsg",e.getMessage());
					rtnStr = "main/ErrorView";
				}
				//메세지 표시 안함
				else {
					rtnStr = "error/errorPage";
				}
			}
			logger.error(e.getMessage());
		}
		
		if ( DevelopConf.IS_DEVELOP ) {
			request.setAttribute("isDevelop", "1");
		} else {
			request.setAttribute("isDevelop", "0");
		}
		
		return rtnStr;

	}
	
	
	@After("execution(* com.idongbu.smartcustomer..*Controller.*(..))")
	public void insertLogs(JoinPoint joinPoint){

		ServletRequestAttributes servletReqAttr = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
		HttpServletRequest request = servletReqAttr.getRequest();

		String qry = null;

		try {
			/** request attribute에 logQuery 값 있으면 해당 쿼리로 insert 수행 **/
			if ( request.getAttribute("logTable") != null ) {
				logger.debug("############ INSERT MOBILE LOG #############");
				HttpSession session = request.getSession();	
				Hashtable logTable = (Hashtable)request.getAttribute("logTable");

				qry = DBLogUtil.makeQuery(logTable, (String)session.getAttribute("ssno"), (String)session.getAttribute("csnm"));
				if ( qry != null ) {
					HashMap hm = new HashMap();
					hm.put("qry", qry);
					int insertLog = commonService.insertResultLog(hm);
					logger.info("inset log count : " + insertLog);
				}
			}

			if ( request.getAttribute("logTable2") != null ) {
				logger.debug("############ INSERT MOBILE LOG 2 #############");
				HttpSession session = request.getSession();	
				Hashtable logTable2 = (Hashtable)request.getAttribute("logTable2");

				qry = null;
				qry = DBLogUtil.makeQuery(logTable2, (String)session.getAttribute("ssno"), (String)session.getAttribute("csnm"));
				if ( qry != null ) {
					HashMap hm2 = new HashMap();
					hm2.put("qry", qry);
					int insertLog = commonService.insertResultLog(hm2);
					logger.info("inset log2 count : " + insertLog);
				}
			}

			if ( request.getAttribute("logList") != null ) {
				logger.debug("############ INSERT MOBILE LOG LIST #############");
				HttpSession session = request.getSession();
				List<Hashtable<String,String>> logList = (List) request.getAttribute("logList");
				
				for(Hashtable<String,String> logTable: logList) {
					qry = null;
					qry = DBLogUtil.makeQuery(logTable, (String)session.getAttribute("ssno"), (String)session.getAttribute("csnm"));
					if ( qry != null ) {
						HashMap hm3 = new HashMap();
						hm3.put("qry", qry);
						int insertLog = commonService.insertResultLog(hm3);
						logger.info("inset log list count : " + insertLog);
					}
				}
			}
			
		} catch (Exception e) {
			logger.debug("## INSERT MOBILE LOG FAILED!!");
			logger.debug(qry);
		} finally {
			request.removeAttribute("logQuery");
			request.removeAttribute("logQuery2");
		}

	}

}
