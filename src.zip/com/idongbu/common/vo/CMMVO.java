package com.idongbu.common.vo;

public class CMMVO {
	private final static String SYSID = "118J";	//모바일고객앱 공통
	private String PGMID;						//전문 프로그램 ID
	private String TRID;							//전문 트랜잭션 ID
	private String ERRMSG;	// 에러메세지
	
	private String COMM_CHANNEL        = null; // 채널구분
	private String COMM_UNIQUE         = null; // TSQ,VSAM FILE용 UNIQUE
	private String COMM_PROGRAM          = null; // PROGRAM-ID
	private String COMM_TRANS        = null; // 처리구분
	private String COMM_ACTION        = null; // 기능키
	private String COMM_USER_GB   = null; // 사용자구분
	private String COMM_USER_ID   = null; // 사용자ID
	private String COMM_JIJUM_CD  = null; // 사용자지점
	private String COMM_JIBU_CD   = null; // 사용자지부
	private String COMM_PROTOCOL       = null; // 전문사용구분
	private String COMM_RETN_CODE = null; // 처리결과
	private String COMM_LAST_FLAG      = null; // 마지막자료여부
	private String COMM_CUR_FLD     = null; // CURSOR  MAP  NAME
	private String COMM_CUR_POS    = null; // CURSOR  POSITION
	private String COMM_MSG_CODE     = null; // MESSAGE  CODE
	private String H_COMM_MSG_NAME = null; // MESSAGE  명
	private String COMM_SYS_ERR        = null; // 시스템 MESSAGE
	private String COMM_SYS_CODE   = null; // 시스템 CODE 
	private String COMM_FIL = null; // FILLER
	private String COMM_BOJONG_CD = null; // 보종 CODE
	private String ERRORCODE = null; // 보종 CODE
	private String OUTMESSAGE = null; // 보종 CODE
	private String Z_MSG_CD = null; // 보종 CODE
	private String HS_B_PIHE_NM = null; // 피보험자명
	private String SS_B_PIHE_JUMIN = null; // 피보험자주민번호
	private String SS_JUBSU_YMD = null; // 피보험자주민번호
	private String SS_JUBSU_HM = null; // 피보험자주민번호
	
	public String getSS_JUBSU_YMD() {
		return SS_JUBSU_YMD;
	}
	public void setSS_JUBSU_YMD(String sS_JUBSU_YMD) {
		SS_JUBSU_YMD = sS_JUBSU_YMD;
	}
	public String getSS_JUBSU_HM() {
		return SS_JUBSU_HM;
	}
	public void setSS_JUBSU_HM(String sS_JUBSU_HM) {
		SS_JUBSU_HM = sS_JUBSU_HM;
	}
	public String getSS_B_PIHE_JUMIN() {
		return SS_B_PIHE_JUMIN;
	}
	public void setSS_B_PIHE_JUMIN(String sS_B_PIHE_JUMIN) {
		SS_B_PIHE_JUMIN = sS_B_PIHE_JUMIN;
	}
	public String getHS_B_PIHE_NM() {
		return HS_B_PIHE_NM;
	}
	public void setHS_B_PIHE_NM(String hS_B_PIHE_NM) {
		HS_B_PIHE_NM = hS_B_PIHE_NM;
	}
	public String getZ_MSG_CD() {
		return Z_MSG_CD;
	}
	public void setZ_MSG_CD(String z_MSG_CD) {
		Z_MSG_CD = z_MSG_CD;
	}
	public String getOUTMESSAGE() {
		return OUTMESSAGE;
	}
	public void setOUTMESSAGE(String oUTMESSAGE) {
		OUTMESSAGE = oUTMESSAGE;
	}
	public String getSYSID() {
		return SYSID;
	}
	public String getPGMID() {
		return PGMID;
	}
	public void setPGMID(String pGMID) {
		PGMID = pGMID;
	}
	public String getTRID() {
		return TRID;
	}
	public void setTRID(String tRID) {
		TRID = tRID;
	}
	public String getERRMSG() {
		return ERRMSG;
	}
	public String getERRORCODE() {
		return ERRORCODE;
	}
	public void setERRORCODE(String eRRORCODE) {
		ERRORCODE = eRRORCODE;
	}
	public void setERRMSG(String eRRMSG) {
		ERRMSG = eRRMSG;
	}
	public String getCOMM_CHANNEL() {
		return COMM_CHANNEL;
	}
	public void setCOMM_CHANNEL(String cOMM_CHANNEL) {
		COMM_CHANNEL = cOMM_CHANNEL;
	}
	public String getCOMM_UNIQUE() {
		return COMM_UNIQUE;
	}
	public void setCOMM_UNIQUE(String cOMM_UNIQUE) {
		COMM_UNIQUE = cOMM_UNIQUE;
	}
	public String getCOMM_PROGRAM() {
		return COMM_PROGRAM;
	}
	public void setCOMM_PROGRAM(String cOMM_PROGRAM) {
		COMM_PROGRAM = cOMM_PROGRAM;
	}
	public String getCOMM_TRANS() {
		return COMM_TRANS;
	}
	public void setCOMM_TRANS(String cOMM_TRANS) {
		COMM_TRANS = cOMM_TRANS;
	}
	public String getCOMM_ACTION() {
		return COMM_ACTION;
	}
	public void setCOMM_ACTION(String cOMM_ACTION) {
		COMM_ACTION = cOMM_ACTION;
	}
	public String getCOMM_USER_GB() {
		return COMM_USER_GB;
	}
	public void setCOMM_USER_GB(String cOMM_USER_GB) {
		COMM_USER_GB = cOMM_USER_GB;
	}
	public String getCOMM_USER_ID() {
		return COMM_USER_ID;
	}
	public void setCOMM_USER_ID(String cOMM_USER_ID) {
		COMM_USER_ID = cOMM_USER_ID;
	}
	public String getCOMM_JIJUM_CD() {
		return COMM_JIJUM_CD;
	}
	public void setCOMM_JIJUM_CD(String cOMM_JIJUM_CD) {
		COMM_JIJUM_CD = cOMM_JIJUM_CD;
	}
	public String getCOMM_JIBU_CD() {
		return COMM_JIBU_CD;
	}
	public void setCOMM_JIBU_CD(String cOMM_JIBU_CD) {
		COMM_JIBU_CD = cOMM_JIBU_CD;
	}
	public String getCOMM_PROTOCOL() {
		return COMM_PROTOCOL;
	}
	public void setCOMM_PROTOCOL(String cOMM_PROTOCOL) {
		COMM_PROTOCOL = cOMM_PROTOCOL;
	}
	public String getCOMM_RETN_CODE() {
		return COMM_RETN_CODE;
	}
	public void setCOMM_RETN_CODE(String cOMM_RETN_CODE) {
		COMM_RETN_CODE = cOMM_RETN_CODE;
	}
	public String getCOMM_LAST_FLAG() {
		return COMM_LAST_FLAG;
	}
	public void setCOMM_LAST_FLAG(String cOMM_LAST_FLAG) {
		COMM_LAST_FLAG = cOMM_LAST_FLAG;
	}
	public String getCOMM_CUR_FLD() {
		return COMM_CUR_FLD;
	}
	public void setCOMM_CUR_FLD(String cOMM_CUR_FLD) {
		COMM_CUR_FLD = cOMM_CUR_FLD;
	}
	public String getCOMM_CUR_POS() {
		return COMM_CUR_POS;
	}
	public void setCOMM_CUR_POS(String cOMM_CUR_POS) {
		COMM_CUR_POS = cOMM_CUR_POS;
	}
	public String getCOMM_MSG_CODE() {
		return COMM_MSG_CODE;
	}
	public void setCOMM_MSG_CODE(String cOMM_MSG_CODE) {
		COMM_MSG_CODE = cOMM_MSG_CODE;
	}
	public String getH_COMM_MSG_NAME() {
		return H_COMM_MSG_NAME;
	}
	public void setH_COMM_MSG_NAME(String h_COMM_MSG_NAME) {
		H_COMM_MSG_NAME = h_COMM_MSG_NAME;
	}
	public String getCOMM_SYS_ERR() {
		return COMM_SYS_ERR;
	}
	public void setCOMM_SYS_ERR(String cOMM_SYS_ERR) {
		COMM_SYS_ERR = cOMM_SYS_ERR;
	}
	public String getCOMM_FIL() {
		return COMM_FIL;
	}
	public void setCOMM_FIL(String cOMM_FIL) {
		COMM_FIL = cOMM_FIL;
	}
	public String getCOMM_BOJONG_CD() {
		return COMM_BOJONG_CD;
	}
	public void setCOMM_BOJONG_CD(String cOMM_BOJONG_CD) {
		COMM_BOJONG_CD = cOMM_BOJONG_CD;
	}
	public String getCOMM_SYS_CODE() {
		return COMM_SYS_CODE;
	}
	public void setCOMM_SYS_CODE(String cOMM_SYS_CODE) {
		COMM_SYS_CODE = cOMM_SYS_CODE;
	}
	
	
}
