package com.idongbu.common.vo;

public class MenuInfoVO {
	private int    menuNo 			= 0;	//메뉴번호
	private String menuNm 			= null;	//메뉴명
	private String menuPath 		= null;	//메뉴경로
	private String menuFileNm 		= null;	//메뉴파일명
	private String useYn 			= null;	//사용 여부
	private String needAppYn 		= null;	//앱실행필요 여부
	private String loginYn 			= null;	//로그인필요 여부
	private String bizMemberYn		= null;	//금융회원필요 여부
	private String closeYn 			= null;	//화면 차단 여부
	private String closeStaDt  		= null;	//차단시작시간
	private String closeEndDt  		= null;	//차단종료시간
	private String closeMsg			= null;	//화면 차단 메세지
	private String staTm     		= null;	//평일서비스시작시간
	private String endTm     		= null;	//평일서비스종료시간
	private String endTmNextDayYn	= null;	//평일서비스종료익일여부
	private String svcNotSatYn 		= null;	//토요일서비스막음여부
	private String staTmSat    		= null;	//토요일서비스시작시간
	private String endTmSat    		= null;	//토요일서비스종료시간
	private String endTmSatNextDayYn = null; //토요일서비스종료익일여부
	private String svcNotHollyYn 	= null;	//휴일서비스막음여부
	private String staTmHolly  		= null;	//휴일서비스시작시간
	private String endTmHolly  		= null;	//휴일서비스종료시간
	private String endTmHollyNextDayYn = null; //휴일서비스종료익일여부

	public int getMenuNo() {
		return menuNo;
	}
	public void setMenuNo(int menuNo) {
		this.menuNo = menuNo;
	}
	public String getMenuNm() {
		return menuNm;
	}
	public void setMenuNm(String menuNm) {
		this.menuNm = menuNm;
	}
	public String getMenuPath() {
		return menuPath;
	}
	public void setMenuPath(String menuPath) {
		this.menuPath = menuPath;
	}
	public String getMenuFileNm() {
		return menuFileNm;
	}
	public void setMenuFileNm(String menuFileNm) {
		this.menuFileNm = menuFileNm;
	}
	public String getUseYn() {
		return useYn;
	}
	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}
	public String getNeedAppYn() {
		return needAppYn;
	}
	public void setNeedAppYn(String needAppYn) {
		this.needAppYn = needAppYn;
	}
	public String getLoginYn() {
		return loginYn;
	}
	public void setLoginYn(String loginYn) {
		this.loginYn = loginYn;
	}
	public String getBizMemberYn() {
		return bizMemberYn;
	}
	public void setBizMemberYn(String bizMemberYn) {
		this.bizMemberYn = bizMemberYn;
	}
	public String getCloseYn() {
		return closeYn;
	}
	public void setCloseYn(String closeYn) {
		this.closeYn = closeYn;
	}
	public String getCloseStaDt() {
		return closeStaDt;
	}
	public void setCloseStaDt(String closeStaDt) {
		this.closeStaDt = closeStaDt;
	}
	public String getCloseEndDt() {
		return closeEndDt;
	}
	public void setCloseEndDt(String closeEndDt) {
		this.closeEndDt = closeEndDt;
	}
	public String getCloseMsg() {
		return closeMsg;
	}
	public void setCloseMsg(String closeMsg) {
		this.closeMsg = closeMsg;
	}
	public String getStaTm() {
		return staTm;
	}
	public void setStaTm(String staTm) {
		this.staTm = staTm;
	}
	public String getEndTm() {
		return endTm;
	}
	public void setEndTm(String endTm) {
		this.endTm = endTm;
	}
	public String getEndTmNextDayYn() {
		return endTmNextDayYn;
	}
	public void setEndTmNextDayYn(String endTmNextDayYn) {
		this.endTmNextDayYn = endTmNextDayYn;
	}
	public String getSvcNotSatYn() {
		return svcNotSatYn;
	}
	public void setSvcNotSatYn(String svcNotSatYn) {
		this.svcNotSatYn = svcNotSatYn;
	}
	public String getStaTmSat() {
		return staTmSat;
	}
	public void setStaTmSat(String staTmSat) {
		this.staTmSat = staTmSat;
	}
	public String getEndTmSat() {
		return endTmSat;
	}
	public void setEndTmSat(String endTmSat) {
		this.endTmSat = endTmSat;
	}
	public String getEndTmSatNextDayYn() {
		return endTmSatNextDayYn;
	}
	public void setEndTmSatNextDayYn(String endTmSatNextDayYn) {
		this.endTmSatNextDayYn = endTmSatNextDayYn;
	}
	public String getSvcNotHollyYn() {
		return svcNotHollyYn;
	}
	public void setSvcNotHollyYn(String svcNotHollyYn) {
		this.svcNotHollyYn = svcNotHollyYn;
	}
	public String getStaTmHolly() {
		return staTmHolly;
	}
	public void setStaTmHolly(String staTmHolly) {
		this.staTmHolly = staTmHolly;
	}
	public String getEndTmHolly() {
		return endTmHolly;
	}
	public void setEndTmHolly(String endTmHolly) {
		this.endTmHolly = endTmHolly;
	}
	public String getEndTmHollyNextDayYn() {
		return endTmHollyNextDayYn;
	}
	public void setEndTmHollyNextDayYn(String endTmHollyNextDayYn) {
		this.endTmHollyNextDayYn = endTmHollyNextDayYn;
	}
	
}
