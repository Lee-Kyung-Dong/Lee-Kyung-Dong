package com.idongbu.common.vo;

public class LogSessionVO {
	private String sessionId= null;		//세션아이디
	private String juminNo 	= null;		//주민번호
	
	public String getSessionId() {
		return sessionId;
	}
	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}
	public String getJuminNo() {
		return juminNo;
	}
	public void setJuminNo(String juminNo) {
		this.juminNo = juminNo;
	}
	

}
