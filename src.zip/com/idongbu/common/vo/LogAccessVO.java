package com.idongbu.common.vo;

public class LogAccessVO {
	private String juminNo 	= null;		//주민번호
	private String csNm 	= null;		//고객명
	private int    menuNo	= 0;		//화면번호
	private String appType	= null;		//접속타입(W:웹/A:앱)
	private String deviceOs	= null;		//장비OS(A:안드로이드/I:iOS)
	private String deviceIp	= null;		//장비IP


	public String getJuminNo() {
		return juminNo;
	}
	public void setJuminNo(String juminNo) {
		this.juminNo = juminNo;
	}
	public String getCsNm() {
		return csNm;
	}
	public void setCsNm(String csNm) {
		this.csNm = csNm;
	}
	public int getMenuNo() {
		return menuNo;
	}
	public void setMenuNo(int menuNo) {
		this.menuNo = menuNo;
	}
	public String getAppType() {
		return appType;
	}
	public void setAppType(String appType) {
		this.appType = appType;
	}
	public String getDeviceOs() {
		return deviceOs;
	}
	public void setDeviceOs(String deviceOs) {
		this.deviceOs = deviceOs;
	}
	public String getDeviceIp() {
		return deviceIp;
	}
	public void setDeviceIp(String deviceIp) {
		this.deviceIp = deviceIp;
	}
}
