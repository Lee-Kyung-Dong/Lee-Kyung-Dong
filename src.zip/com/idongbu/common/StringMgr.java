package com.idongbu.common;
 

import java.util.Enumeration;
import java.util.HashMap;
import java.util.Properties;

public final class StringMgr
{
	private StringMgr() {}
	
	
	public static String leftTrim(String str)
	{
		int len = str.length();
		int idx = 0;
		
		while (idx < len && str.charAt(idx) <= ' '){ idx++; }
		
		return str.substring(idx, len);
	}
	
	
	public static String rightTrim(String str)
	{
		int len = str.length();
		
		while (0 < len && str.charAt(len - 1) <= ' '){ len--; }
		
		return str.substring(0, len);
	}
	
	
	public static String splitHead(String str, int size)
	{
		if (str == null) return "";
		
		if (str.length() > size) str = str.substring(0, size) + "...";
		
		return str;
	}
	
	
	public static String splitTail(String str, int size)
	{
		if (str == null) return "";
		
		if (str.length() > size) str =  "..." + str.substring(str.length() - size);
		
		return str;
	}
	
	public static String leftPad(String str, String addStr, int count)
	{
		if (str == null) return "";
		
		for (int i = str.length(); i < count; i++)
		{
			str = addStr + str;
		}
	
		return str;
	}
	
	
	public static String rightPad(String str, String addStr, int count)
	{
		if (str == null) return "";
	
		for (int i = str.length(); i < count; i++)
		{
			str = str + addStr;
		}
		
		return str;
	}
	
	
	public static int byteLength(String str)
	{
		if (str == null) return -1;
		
		return str.getBytes().length;
	}
	
	
	public static int byteLengthDB2(String str)
	{
		if (str == null) return -1;
		
		int stemp = 0;
		int stemp2 = 0;
		int count = 0;
		
		for (int i = 0; i < str.getBytes().length; i++)
		{
			if (str.getBytes()[i] >= 0) stemp = 0;
			else stemp = 1;
			 
			if (stemp != stemp2) count += 2;
			else count += 1;
			
			stemp2 = stemp;
			if (i + 1 == str.getBytes().length && stemp2 == 1) count += 1;
		}
		
		return count;
	}
	
	
	public static String byteValue(String str, int Length)
	{
		if (str == null) return "";
		
		String value = null;
		int count = 0;
		
		for (int y = 0; y <str.length(); y++)
		{
			count = 0;
			value = str.substring(0, str.length() - y);
			count = byteLength(value);
			
			if (count <= Length) break; // �뜝�룞�삕�뜝�룞�삕�뜝�룞�삕�뜝�룞�삕�뜝�룞�삕�뜝�룞�삕�뜝�룞�삕�뜝�룞�삕�뜝�룞�삕
		}
		
		return value;
	}
	
	
	public static String byteValueDB2(String str, int Length)
	{
		if (str == null) return "";
		
		String value = null;
		int stemp = 0;
		int stemp2 = 0;
		int count = 0;
		
		for (int y = 0; y <str.length(); y++)
		{
			count = 0;
			value = str.substring(0, str.length() - y);
			
			for (int i = 0; i < value.getBytes().length; i++)
			{
				if (value.getBytes()[i] >= 0) stemp = 0;
				else stemp = 1;
				 
				if (stemp != stemp2) count += 2;
				else count += 1;
				
				stemp2 = stemp;
				
				if (i + 1 == value.getBytes().length && stemp2 == 1) count += 1;
			}
			
			if (count <= Length) break; // �뜝�룞�삕�뜝�룞�삕�뜝�룞�삕�뜝�룞�삕�뜝�룞�삕�뜝�룞�삕�뜝�룞�삕�뜝�룞�삕�뜝�룞�삕
		}
		
		return value;
	}
	
	
	public static String removeChar(String str, char ch)
	{
		if (str == null) return "";
		else if (str.equals("")) return "";
	
		String value = "";
		
		for (int i = 0; i < str.length(); i++)
		{
			if (str.charAt(i) == ch) continue;
			value = value + str.charAt(i);
		}
		
		return value;
	}
	
	
	public static String removeCharAll (String str)
	{
		String value = null;
		value = removeChar(str, '/'); // '/'
		value = removeChar(value, '-'); // '-'
		value = removeChar(value, ':'); // ':'
		value = removeChar(value, ','); // ','/
		value = removeChar(value, '.'); // '.'
		value = removeChar(value, '%'); // '%'
		value = removeChar(value, '{'); // '{'
		value = removeChar(value, '}'); // '}'
		value = value.trim(); //
		
		return value;
	}
	
	public static String removeCharSpec(String str) {
		String value = null;
		value = removeChar(value, '{'); // '{'
		value = removeChar(value, '}'); // '}'
		value = value.trim(); //
		
		return value;
	}
	
	
	public static String convert(String str)
	{
		return convert(str, true);
	}

	
	public static String convert(String str, boolean type)
	{
		if (str == null) return "";
		
		String converted = null;
		
		try
		{ 
			if (type) converted = new String(new String(str.getBytes("8859_1"), "KSC5601"));
			else converted = new String(new String(str.getBytes("KSC5601"), "8859_1"));
		}
		catch (java.io.UnsupportedEncodingException uee)
		{
			converted = str;
		}
		
		return converted;
	}

	
	public static String replace(String str, String target, String replace)
	{              
		if (str == null) return "";
		
		int targetLen = target.length();
		
		StringBuffer value = new StringBuffer();     
		int i = 0;     
		int j = 0;
	 
		while (j > -1)
		{
			j = str.indexOf(target, i);
			        
			if (j > -1)
			{
				value.append(str.substring(i, j)).append(replace);
				i = j + targetLen;
			}
		}
		
		value.append(str.substring(i, str.length()));
		
		return value.toString();
	}       
	
	
	public static String getVirtualFileName(String orgn_name) {
		if(orgn_name == null || orgn_name.length() < 1) {
			return "";
		}
		
		int start = orgn_name.indexOf("_", orgn_name.indexOf("_") + 1);
		if(start == -1) {
			return "";
		}
		
		String vName = orgn_name.substring(start + 1);
		return vName;
	}


	public static int strToInt(String myD){
		int iValue = 0 ; 
		try{
			iValue = Integer.parseInt(myD.trim());
		}catch(Exception e){
			iValue = 0 ; 
		}
		return iValue ; 
	}
	 
	public static int strToInt(String myD,int defaultVal){
		int iValue = 0 ; 
		try{
			iValue = Integer.parseInt(myD.trim());
		}catch(Exception e){
			iValue = defaultVal ; 
		}
		return iValue ; 
	}
	

	public static String substr(String orStr,int firstIndex,int length){
		String reStr = orStr ;
		try{
			reStr = reStr.substring(firstIndex-1,firstIndex+length-1);
		}catch(Exception e){
			try{
				reStr = reStr.substring(firstIndex-1);
			}catch(Exception ex){
				reStr = ""; 
			}
		}
		return reStr ; 
	}
	
	public static String NVL(String orginalText, String changeText) {
		if(orginalText == null || orginalText.length() == 0) {
			orginalText = changeText;
		}
		return orginalText;
	}
	
	 
	public static String fixNull(String str) 
	{
		String value = null;
		if ( str == null ) 
			value = "";
		else
			value = trim(str);
		return value;
	}

	 
	public static String fixZero(String str) {
		String value = fixNull(str);
		if (value.equals("")) 
			return "0";
		else
			return value;
	}
	
	 
	public static String trim(String str) {
		int idx = 0;
		char[] val = str.toCharArray();
		int count = val.length;
		int len = count;

		while ((idx < len) && (val[idx] <= ' ')){ idx++; }
		while ((idx < len) && (val[len - 1] <= ' ')){ len--; }
		//while ((idx < len) && ((val[idx] <= ' ') || (val[idx] == '�뜝�룞�삕�뜝�룞�삕�뜝占�) ) )   idx++;
		//while ((idx < len) && ((val[len - 1] <= ' ') || (val[len-1] == '�뜝�룞�삕�뜝�룞�삕�뜝占�)))  len--;
		
		return ((idx > 0) || (len < count)) ? str.substring(idx, len) : str;
	}   
	
	 
	public static String getLevelDepth(String lvl){ 
		String mylvl = lvl ;
		String fullLvl = "" ; 
		for(int i = 0 ; i < strToInt(mylvl) ; i++){
			fullLvl += " ";
		}
		fullLvl += mylvl ; 
		return fullLvl ; 
	}
	   
	public static String getFirstDashFront(String orgStr)throws Exception{
		int myPos = orgStr.indexOf("-");
		String reStr = "" ; 
		if(myPos > 0){
			reStr = orgStr.substring(0, myPos);
		}
		return reStr ; 
	}
	
	// 차세대2차전환 시작 : 함수추가 박춘하 2014.01.24
	public static boolean chkNullArray(String[] strArr) 
	{
		boolean chk = false;
		if ( strArr == null || strArr.length <1 ) chk = true;
		return chk;
	}
 
}