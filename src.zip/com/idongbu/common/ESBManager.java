package com.idongbu.common;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.StringReader;
import java.io.StringWriter;
import java.lang.reflect.Field;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;
import javax.xml.transform.dom.DOMSource;

import org.apache.commons.lang.ArrayUtils;
import org.jdom.input.DOMBuilder;
import org.jdom.output.XMLOutputter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import com.idongbu.common.vo.CMMVO;

import org.apache.xml.serialize.OutputFormat; 
import org.apache.xml.serialize.XMLSerializer;

import com.thoughtworks.xstream.XStream;

public class ESBManager {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//ESBManager esb = new ESBManager();
		//esb.sendDataTest();
	}

	public static String getXmlData(ESBChannelHeader channelHead, ESBBizHeader bizHead, Object dataVO)
	{
		XStream xstream = new XStream();

		StringBuffer hxml = new StringBuffer();
		hxml.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
		hxml.append("<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\">\n");
		hxml.append("<soapenv:Header>\n");
		hxml.append("</soapenv:Header>\n");
		hxml.append("<soapenv:Body>\n");
		hxml.append("<request>\n");

		/////////////////////////
		//
		xstream.alias("channelHeader",  channelHead.getClass());
		String xml = xstream.toXML(channelHead);
		hxml.append(xml);
		hxml.append("\n");


		/////////////////////////
		//
		xstream.alias("bizHeader",  bizHead.getClass());
		xml = xstream.toXML(bizHead);
		hxml.append(xml);
		hxml.append("\n");

		/////////////////////////
		//Body
		xstream.alias("bizBody",  dataVO.getClass());
		xml = xstream.toXML(dataVO);
		hxml.append(xml);

		////////////////////////////////////////////////////
		hxml.append("\n</request>\n");
		hxml.append("</soapenv:Body>\n");
		hxml.append("</soapenv:Envelope>\n");
		/////////////////////////

		System.out.println(hxml.toString());
		return  hxml.toString().replaceAll("__","_");
	}

	/**
	 * ESB
	 * @param formId
	 * @param UserId
	 * @return
	 */
	public static ESBChannelHeader makeDefaultChannelHeader(String formId, String UserId)
	{
		if(formId.length() < 8)
			return null;
		String userIp = "";
		try {
			InetAddress ia = InetAddress.getLocalHost();
			userIp = ia.getHostAddress();
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		String orgDvcd =  formId.substring(0, 1);
		String orgCd = formId.substring(1, 4);
		
		
		ESBChannelHeader channelHead = new ESBChannelHeader();
		channelHead.setZ_rqst_dvcd("S");
		channelHead.setZ_trns_org_dvcd("X");
		channelHead.setZ_trns_org_cd("SMZ");

		channelHead.setZ_rc_org_dvcd(orgDvcd);
		channelHead.setZ_rc_org_cd(orgCd);

		channelHead.setZ_tlg_sp_cd("0200");
		channelHead.setZ_dgs_dvcd(formId);

		channelHead.setZ_resp_cd("");
		channelHead.setZ_resp_msg("");

		SimpleDateFormat ISO8601UTC = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.KOREA);
		String trid = ISO8601UTC.format(new Date())+"_"+UserId+"_9874_XSMZ";
		channelHead.setZ_trsc_id(trid);
		channelHead.setZ_clt_srv_nm("ClientSendSoap_" + formId);
		channelHead.setZ_clt_ip(userIp);
		
		//channelHead.setTraceFlag("true");//트레이스 로그 On 09.12 추가
		
		return channelHead;
	}

	/**
	 * ESB
	 * @param
	 * @return
	 */
	public static ESBBizHeader makeDefaultBizHeader(String UserId) // 기본 biz 헤더 세팅(조직원코드 셋팅)
	{
		ESBBizHeader bizHead = new ESBBizHeader();
		bizHead.setZ_chn_cd("ESB");
		bizHead.setZ_user_id(UserId);//
		bizHead.setZ_mac_adr("");//MAC Address
		bizHead.setZ_afcp_dvcd("");//
		bizHead.setZ_orn_dvcd("");//
		bizHead.setZ_orn_no("");//

		bizHead.setZ_stcn_no("");//
		bizHead.setZ_hdqt_no("");//
		bizHead.setZ_bzlv_no("");//
		bizHead.setZ_bh_no("");//
		bizHead.setZ_brc_no("");//
		bizHead.setZ_cnof_yn("");//
		
		bizHead.setZ_ormm_no("");//
		bizHead.setZ_ormm_dvcd("");//
		bizHead.setZ_ormm_tpcd(""); //
		bizHead.setZ_ormm_ptl_tpcd("");//

		bizHead.setZ_auth_grp_cd("01");//(Role ID)
		bizHead.setZ_comm_auth_grp_cd("");//(Role ID)

		bizHead.setErrorCode("");//
		bizHead.setZ_msg_cd("");//
		bizHead.setReturnMessage("");//

		bizHead.setZ_err_cpn_id("");//
		
		bizHead.setTraceFlag("true");//트레이스 로그 On 09.12 추가
		
		bizHead.setZ_page_if_key("");//
		bizHead.setZ_next_page_exis_yn("0");//
		bizHead.setZ_row_cnt_per_page("20"); //
		bizHead.setZ_rqst_page_no("1");//
		bizHead.setZ_wh_cnum("");
		bizHead.setZ_wh_page_cnt(""); 
		return bizHead;
	}
	/**
	 * ESB
	 * @param
	 * @return
	 */
	public static ESBBizHeader makeDefaultBizHeader(String UserId,String bzlv_no) // 기본 biz 헤더 세팅(조직원코드,지점코드 둘다 셋팅)
	{
		ESBBizHeader bizHead = new ESBBizHeader();
		bizHead.setZ_chn_cd("ESB");
		bizHead.setZ_user_id(UserId);//
		bizHead.setZ_mac_adr("");//MAC Address
		bizHead.setZ_afcp_dvcd("");//
		bizHead.setZ_orn_dvcd("");//
		bizHead.setZ_orn_no("");//

		bizHead.setZ_stcn_no("");//
		bizHead.setZ_hdqt_no("");//
		bizHead.setZ_bzlv_no(bzlv_no);//
		bizHead.setZ_bh_no("");//
		bizHead.setZ_brc_no("");//
		bizHead.setZ_cnof_yn("");//
		
		bizHead.setZ_ormm_no("");//
		bizHead.setZ_ormm_dvcd("");//
		bizHead.setZ_ormm_tpcd(""); //
		bizHead.setZ_ormm_ptl_tpcd("");//

		bizHead.setZ_auth_grp_cd("01");//(Role ID)
		bizHead.setZ_comm_auth_grp_cd("");//(Role ID)

		bizHead.setErrorCode("");//
		bizHead.setZ_msg_cd("");//
		bizHead.setReturnMessage("");//

		bizHead.setZ_err_cpn_id("");//
		
		bizHead.setTraceFlag("true");//트레이스 로그 On 09.12 추가
		
		bizHead.setZ_page_if_key("");//
		bizHead.setZ_next_page_exis_yn("0");//
		bizHead.setZ_row_cnt_per_page("20"); //
		bizHead.setZ_rqst_page_no("1");//
		bizHead.setZ_wh_cnum("");
		bizHead.setZ_wh_page_cnt(""); 
		return bizHead;
	}
	public static ESBBizHeader makePageBizHeader(String UserId, String ifKey, String nextYn, String rowCnt, String pageNo, String whCnum, String whCnt){
		
		ESBBizHeader bizHead = new ESBBizHeader();
		
		bizHead.setZ_chn_cd("ESB");
		bizHead.setZ_user_id(UserId);//
		bizHead.setZ_mac_adr("");//MAC Address
		bizHead.setZ_afcp_dvcd("");//
		bizHead.setZ_orn_dvcd("");//
		bizHead.setZ_orn_no("");//

		bizHead.setZ_stcn_no("");//
		bizHead.setZ_hdqt_no("");//
		bizHead.setZ_bzlv_no("");//
		bizHead.setZ_bh_no("");//
		bizHead.setZ_brc_no("");//
		bizHead.setZ_cnof_yn("");//

		bizHead.setZ_ormm_no("");//
		bizHead.setZ_ormm_dvcd("");//
		bizHead.setZ_ormm_tpcd(""); //
		bizHead.setZ_ormm_ptl_tpcd("");//

		bizHead.setZ_auth_grp_cd("01");//
		bizHead.setZ_comm_auth_grp_cd("");//

		bizHead.setErrorCode("");//
		bizHead.setZ_msg_cd("");//
		bizHead.setReturnMessage("");//

		bizHead.setZ_err_cpn_id("");//
		
		bizHead.setZ_page_if_key(ifKey);//
		bizHead.setZ_next_page_exis_yn(nextYn);//
		bizHead.setZ_row_cnt_per_page(rowCnt); //
		bizHead.setZ_rqst_page_no(pageNo);//
		bizHead.setZ_wh_cnum(whCnum);
		bizHead.setZ_wh_page_cnt(whCnt);
		
		return bizHead;
	}
	 public static CMMVO xmlToVOnew(String xmlData, CMMVO vo) throws Exception {
			
			//logger.debug("▶▶▶CmmXmlEsbUtil.CmmJmVO xmlToVOnew(String xmlData, CmmJmVO vo)");
			//logger.debug("phk 2012.05.09 xmlData=========== 100 : "+xmlData);
			
			StringReader srReader = new StringReader(xmlData);
			InputSource isInput = new InputSource(srReader);
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = dbf.newDocumentBuilder();
			Document doc = db.parse(isInput);
			///////////////////////////////////////////////////////////////

			//doc.getElementsByTagName("");
			Element root = doc.getDocumentElement();
			//NodeList children = root.getChildNodes();

			NodeList nl = null;

			//logger.debug("The root element is ::::: " + root.getNodeName());
			//logger.debug("There are "+children.getLength()+" nodes in this document.");

//			logger.debug("================== stepThroughAll ======================");
			ArrayList<String> dataList = new ArrayList<String>();
			ArrayList<String> dataList_DupLs = new ArrayList<String>();
			dataList = xmlAndVoArrList(root, dataList);

			int sameCnt = 0;
			int forExit = 0;  //중복제거를 위해 빠져나기 

			ArrayList<String> bizBodyObjctList = new ArrayList<String>();  //중복제거한 객체리스트 
			for(int i=0; i<dataList.size(); i++) {
				if(dataList_DupLs.size() > 0) {  //알고리즘 중복건만 추출
					for(int x=0; x<dataList_DupLs.size(); x++) {
						//logger.debug("dataList_DupLs.get(x)==="+dataList_DupLs.get(x));
						if(dataList.get(i).equals(dataList_DupLs.get(x)) ) {
							forExit = 1;
							continue;
						}
					}
				}

				if(forExit>0) {
					forExit = 0;  	//검사를 위한 초기화
					continue;  		//exit for i
				}

				for(int j=0; j<dataList.size(); j++){

					if(dataList_DupLs.size() > 0) {  //알고리즘 중복건만 추출
						for(int x=0; x<dataList_DupLs.size(); x++) {
							if(dataList.get(i).equals(dataList_DupLs.get(x)) ) {
								forExit = 1;
								continue;
							}
						}
					}

					if(forExit>0) {
						forExit = 0;  	//중복 검사를 위한 초기화
						continue;  		//exit for j
					}

					if(dataList.get(i).equals(dataList.get(j))) {
						sameCnt++;
						if(sameCnt>1){
							dataList_DupLs.add(dataList.get(j).toString());
							continue;
						}
					}
				}

				bizBodyObjctList.add(dataList.get(i));  //중복제거한 순수 객체결과만 넣기 
				sameCnt = 0;  //한줄단위로 수행후 초기화 

			} //exit for i

//			logger.debug("▶▶▶bizBodyObjctList.size() = " + bizBodyObjctList.size());

			//Node 마다 값을 셋팅한다.
			for(int i=0; i<bizBodyObjctList.size(); i++) {
//				logger.debug("▶▶▶bizBodyObjctList.get(" + i + ").toString() = " + bizBodyObjctList.get(i).toString());
				nl = doc.getElementsByTagName(bizBodyObjctList.get(i).toString());
				getTextValueNew(doc, bizBodyObjctList.get(i).toString(), nl, vo);
			}

			//logger.debug("▶▶▶vo.toString() = \n" + vo.toString());
			return vo;
		}
	 public static ArrayList<String> xmlAndVoArrList(Node start, ArrayList<String> dataList) {
			//logger.debug("0000swapFlag=="+swapFlag+"  // "+start.getNodeName()+" = "+stargetNodeValue());   

//			logger.debug("★bizBodyFlag = " + bizBodyFlag);
			
			//Element 명의 값을 넣기 위해서 
//			if (!start.getNodeName().trim().equals("#text") && bizBodyFlag.equals("on")) {
			if (!start.getNodeName().trim().equals("#text")) {
//				tagName = StringMgr.fixNull(start.getNodeName());	
//				tagValue = StringMgr.fixNull(start.getNodeValue());
				dataList.add(start.getNodeName());
				//logger.debug("111swapFlag=="+swapFlag+"  // "+start.getNodeName()+" = "+start.getNodeValue());
			}
//			else {
//				tagName = "";
//				tagValue = "";
//			}
//			if(start.getNodeName().toUpperCase().equals("BIZBODY")) { bizBodyFlag = "on"; }  //스위치 켜기 전문 바디부분많 넣기

			if(start.getNodeType() == Node.ELEMENT_NODE) {   
				NamedNodeMap startAttr = start.getAttributes();
				for(int i = 0; i < startAttr.getLength(); i++) {
//					Node attr = startAttr.item(i);
					//logger.debug("Attribute:  "+ attr.getNodeName()+" = "+attr.getNodeValue());
				}
			}

			for(Node child = start.getFirstChild(); child != null; child = child.getNextSibling()) {
				xmlAndVoArrList(child, dataList);
			}
			return dataList;
		}
	//특정 태그 정보를 vo에 세팅한다.
		public static void getTextValue(String tagName, Element el, CMMVO vo) throws Exception{
			String textVal = "";

			//태그에 정보가 없을때.. NullPointerException 발생. 
			try {
				textVal = el.getFirstChild().getNodeValue();
			} catch(NullPointerException nullEx) {
				throw new Exception("NullPointerException");
			}

			Field field = null;
			try {
				field = vo.getClass().getDeclaredField(tagName);

				if(field.getType().isArray()) {
					String[] val2 = (String[]) field.get(vo);
					val2 = (String[]) ArrayUtils.add(val2, textVal);
					field.set(vo, val2);
				} else {
					field.set(vo, textVal);
				}
			} catch(NoSuchFieldException e) {
				//field = vo.getClass().getField(tagName);
				throw new Exception("NoSuchFieldException");
			}
		}
		public static void getTextValueNew(Document doc,String tagName, NodeList nl, CMMVO vo) throws Exception{

//			logger.debug("\n\n▶▶▶CmmXmlEsbUtil.getTextValueNew(Document doc,String tagName, NodeList nl, CmmJmVO vo)");
//			logger.debug("▶tagName = " + tagName);

			String textVal = "";
			String noSuchFieldTagName = "";
			
			nl = doc.getElementsByTagName(tagName);

			int items = nl.getLength();

//			if(nl.item(0).getFirstChild() == null){
//				logger.debug("null");
//			} else {
//				try {
//					textVal = nl.item(0).getFirstChild().getNodeValue();
//				} catch(NullPointerException nullEx) {
//					throw new Exception("NullPointerException");
//				}
//			}

			try {
				if(nl.item(0).getFirstChild() != null){
					textVal = nl.item(0).getFirstChild().getNodeValue();
				}
				
				//RD관련 xml데이터 추출
				if ("PRT_DATA".equals(tagName)) {
					NodeList printNodeList = doc.getElementsByTagName("PRT_DATA");
					DOMBuilder b = new DOMBuilder();
//					logger.debug("(Element)nl.item(0) = " + (Element)printNodeList.item(0));
					org.jdom.Element element = b.build((Element)printNodeList.item(0));
					XMLOutputter out = new XMLOutputter();
					textVal = out.outputString(element);
//					logger.debug("textVal = " + textVal);
				}
			} catch(NullPointerException nullEx) {
				throw new Exception("NullPointerException");
			}
//			logger.debug("▶tagName = " + tagName + " ▷textVal = " + textVal);

			Field field = null;
			try {
//				field = vo.getClass().getDeclaredField(tagName);
				field = vo.getClass().getField(tagName);  //상위클래스 변수까지 등록
//				logger.debug("▶field = " + field);
				
				if(field.getType().isArray()) {
					//기존 vo값 입력??
//					String[] val2 = (String[]) field.get(vo);
//					logger.debug("▶▶▶val2.length = " + val2.length);
					
					//배열초기화
					String[] val2 = new String[0];
					
					//변경
					for(int i=0; i<items; i++) {
//						logger.debug("▶i = " + i);
//						logger.debug("▶nl.item(" + i + ").getNodeName() = " + nl.item(i).getNodeName());
//						logger.debug("▶nl.item(" + i + ").getNodeType() = " + nl.item(i).getNodeType());
//						logger.debug("▶nl.item(" + i + ").getNodeValue() = " + nl.item(i).getNodeValue());
//						logger.debug("▶nl.item(" + i + ").getFirstChild() = " + nl.item(i).getFirstChild());
						
						if (nl.item(i).getFirstChild() == null) {
							//데이터가 안넘어올때 화면에 어떻게 보여줄건지 정의 필요(빈값을 안넘길건지/넘길건지)
							val2 = (String[]) ArrayUtils.add(val2, "");
						}
						else {
//							logger.debug("▶nl.item(" + i + ").getFirstChild().getNodeName() = " + nl.item(i).getFirstChild().getNodeName());
//							logger.debug("▶nl.item(" + i + ").getFirstChild().getNodeType() = " + nl.item(i).getFirstChild().getNodeType());
//							logger.debug("▶nl.item(" + i + ").getFirstChild().getNodeValue() = " + nl.item(i).getFirstChild().getNodeValue());
//							logger.debug("▶StringUtil.escapeXml(nl.item(" + i + ").getFirstChild().getNodeValue()) = " + StringUtil.escapeXml(nl.item(i).getFirstChild().getNodeValue()));

							val2 = (String[]) ArrayUtils.add(val2, StringMgr.fixNull(nl.item(i).getFirstChild().getNodeValue()));						
							//val2 = (String[]) ArrayUtils.add(val2, StringMgr.fixNull(StringUtil.escapeXml(nl.item(i).getFirstChild().getNodeValue())));  //특수문자 escape	처리
						}

					}
					
					//데이터확인
//					for(int loop=0; loop < val2.length; loop++) {
//						logger.debug("▶val2[" + loop + "] = " + val2[loop]);
//					}
					
					field.set(vo, val2);
				} else {
					field.set(vo, textVal);
				}
			} catch(NoSuchFieldException e) {
				//field = vo.getClass().getField(tagName);
				//logger.debug("NoSuchField tagName = " + tagName);
				noSuchFieldTagName = noSuchFieldTagName + tagName;
			}
		}

		/**
		 * Document 정리해서 로그 보여주기.
		 */
		public void xmlLog(String GB, Object obj){
	    	synchronized (obj) {
	    		logger.debug("[" + GB + "]" + obj.getClass());
				if(obj instanceof String){
					logger.debug("[" + GB + "] FORMAT:"+"\r\n"+obj); // 20120524 pch
				}else  if(obj instanceof Document){
					try
					{
						StringWriter stringOut = new StringWriter();
						OutputFormat format = new OutputFormat((Document)obj, "UTF-8", true);
						XMLSerializer serial = new XMLSerializer(stringOut, format);
						serial.asDOMSerializer();
						serial.serialize(((Document)obj).getDocumentElement());
						logger.debug("[" + GB + "] FORMAT:========================================================================");
						logger.debug("\r\n"+stringOut.toString());
						logger.debug("==============================================================================");
					}catch(Exception e){
						logger.error("exception", e);
					}
				}else if(obj instanceof Exception){
					logger.error("exception", obj);
				}
	    	}
		}			
		
		public static String sendSoap(String sendXml, String callUrl){
			String reXml = null;
			try {
				
				if(sendXml.indexOf("<?xml version=\"1.0\" encoding=\"UTF-8\"?>")<0){
					sendXml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" + sendXml;
				}
				System.out.println("====sendSoap start");
				DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
				factory.setNamespaceAware(true);
				DocumentBuilder parser = factory.newDocumentBuilder();
			
				StringReader reader = new StringReader(sendXml);
				InputSource is = new InputSource(reader);
				Document document = (Document) parser.parse(is);
				DOMSource requestSource = new DOMSource((Node) document);
			
				ESBManager esbm = new ESBManager();
//				System.out.println("==============");
				esbm.xmlLog("IN", document);
//				System.out.println("==============");
				
				MessageFactory messageFactory = MessageFactory.newInstance();
				SOAPMessage requestSoapMessage = messageFactory.createMessage();
				SOAPPart requestSoapPart = requestSoapMessage.getSOAPPart();
				
				requestSoapPart.setContent(requestSource);
				SOAPConnectionFactory scf = SOAPConnectionFactory.newInstance();
				SOAPConnection connection = scf.createConnection();
				SOAPMessage responseSoapMessage = connection.call(requestSoapMessage, callUrl);
				
				ByteArrayOutputStream byteOut = new ByteArrayOutputStream();
				responseSoapMessage.writeTo(byteOut);
				reXml = new String(byteOut.toByteArray(),"UTF-8");	
				
				int beginIndex = reXml.indexOf("<soapenv:Envelope");//BodyArea -> bizBody
				int endIndex = reXml.indexOf("</soapenv:Envelope>");
				int add = "</soapenv:Envelope>".length();//19
				String soapenv = reXml.substring(beginIndex, endIndex+add);//beginIndex + 11 -> endIndex + 10			
				
				System.out.println("====sendSoap end");		
				
				reXml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" + soapenv;
				
		        DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
		        ByteArrayInputStream resIn = new ByteArrayInputStream(reXml.getBytes("utf-8"));
		        Document resdocument = builder.parse(new InputSource(resIn));			
				
//				System.out.println("==============");
		        esbm.xmlLog("OUT", resdocument);
//				System.out.println("==============");		
				
				beginIndex = reXml.indexOf("<response>");
				endIndex = reXml.indexOf("</response>");
				add = "</response>".length();//10
				String response = reXml.substring(beginIndex, endIndex + add);

				//서브루트 태그 삭제
				response = response.replaceAll("<channelHeader>", "");
				response = response.replaceAll("</channelHeader>", "");
				response = response.replaceAll("<bizHeader>", "");
				response = response.replaceAll("</bizHeader>", "");
				response = response.replaceAll("<bizBody>", "");
				response = response.replaceAll("</bizBody>", "");

//				System.out.println("reXml1(callESBImpl) --> " + reXml);	
				reXml = response;
				
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			return reXml;
		}		
		
}
