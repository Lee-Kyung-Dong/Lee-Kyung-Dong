package com.idongbu.common;


import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackageClasses = {DBConnBean.class})
public class StaticInjectionConfig {

	@Autowired(required=true)
	@Qualifier("sqlSessionFactory")
	protected SqlSessionFactory sqlSessionFactory;
		
	@Bean
	public SqlSessionTemplate dbSqlSession() {
		return new SqlSessionTemplate( sqlSessionFactory);
		
	}
	
	
}
