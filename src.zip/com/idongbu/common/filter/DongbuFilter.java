package com.idongbu.common.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.idongbu.common.DevelopConf;

import xecure.servlet.XecureServlet;
import xecure.servlet.XecureServletConfigException;
import xecure.servlet.XecureServletException;

public class DongbuFilter implements Filter {
	private final static Logger logger = LoggerFactory.getLogger(DongbuFilter.class);
	
	@Override
	public void doFilter(ServletRequest request, ServletResponse response,FilterChain chain) throws IOException, ServletException {
		
		HttpServletRequest httpReq = null;
		HttpServletResponse httpRes = null;
		
		String xecureQ = request.getParameter("q");
		XecureServlet xservlet = null;
		
		if(DevelopConf.IS_DEVELOP){
        	httpReq = (HttpServletRequest)request;
        	httpRes = (HttpServletResponse)response;			
		}else{
		
	        if ( xecureQ != null ) {	//xecure 요청시
	        	try {
	        		xservlet = new XecureServlet( (HttpServletRequest)request, (HttpServletResponse)response );
	        		httpReq = xservlet.request;
	        		httpRes = xservlet.response;
				} catch (XecureServletException e) {
					logger.error(e.getMessage());
				} catch (XecureServletConfigException e) {
					logger.error(e.getMessage());
				}
	        } else {	//일반 plain text 요청시
	        	httpReq = (HttpServletRequest)request;
	        	httpRes = (HttpServletResponse)response;
	        }
	        
		}
		
        chain.doFilter(httpReq, httpRes);	//Filter -> InterCepter로 next step 진행
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		// Auto-generated method stub
	}

	@Override
	public void destroy() {
		// Auto-generated method stub
		
	}

}
