package com.idongbu.common.mapper;

import java.util.HashMap;

import com.idongbu.common.vo.LogAccessVO;
import com.idongbu.common.vo.LogSessionVO;
import com.idongbu.common.vo.MenuInfoVO;

public interface CommonDao {
	MenuInfoVO menuInfoSelect(String menuid);
	int insertAccessLog(LogAccessVO insertvo);
	@SuppressWarnings("rawtypes")
	int insertResultLog(HashMap hm);
	int insertSessionLog(LogSessionVO insertvo);
	String getSessionId(LogSessionVO insertvo);
	@SuppressWarnings("rawtypes")
	int getLogSequence(HashMap hm);
}
