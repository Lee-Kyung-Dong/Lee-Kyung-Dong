package com.idongbu.common;

import java.util.Enumeration;
import java.util.Hashtable;

import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionBindingEvent;
import javax.servlet.http.HttpSessionBindingListener;

import org.mybatis.spring.SqlSessionTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.idongbu.common.vo.LogSessionVO;
import com.idongbu.smartcustomer.login.vo.MobileLoginDBVO;
import com.idongbu.smartcustomer.vo.CmmFBM0299RVO;
import com.idongbu.util.StringUtil;
import com.idongbu.common.mapper.CommonDao;

public class LoginManager implements HttpSessionBindingListener {
	
	private LoginManager()
	{
		super();
	}
		
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	private static Hashtable loginUsers = new Hashtable();
	
	private static class LoginHolder{
		public static final LoginManager loginManager = new LoginManager();
	}
	public static LoginManager getInstance(){
		return LoginHolder.loginManager;
	}
	
	//주민번호와 세션으로 로그인 상태인지 체크(static 변수로 로그인 여부 확인)
	public boolean isLogin(String juminNo, String sessionID)
	{
		
			if ( juminNo == null ) return false;
			if ( sessionID == null ) return false;
	
		    if ( sessionID.equals(loginUsers.get(juminNo)) ) {
		    	return true;
		    }
		

	    return false;
	}
	
	//주민번호와 세션으로 로그인 상태인지 체크(이중화 서버 중복로그인 체크 (DB체크))
	public boolean isLogin(String juminNo, String sessionID,SqlSessionTemplate sqlSession)
	{
		try{
			if ( juminNo == null ) return false;
			if ( sessionID == null ) return false;
			
			//이중화 서버 중복로그인 체크를 위해 세션생성시 세션아이디,주민번호 DB테이블에 INSERT 하고 로그인 상태 체크할때 DB에서 세션주민번호에 대한 세션ID 값이 같은지 체크
			//오늘 로그인한 주민번호중 가장 최근의 세션ID 를 가져와서 비교한다.
			LogSessionVO logvo = new LogSessionVO();
			logvo.setJuminNo(juminNo);			
			String strSessionId = getSessionId(sqlSession,logvo);			
			
			//세션ID와 오늘로그인한 주민번호중 가장 최근의 세션ID가 같으면 로그인상태 인정
		    if ( sessionID.equals(strSessionId) ) {		    	
		    	return true;
		    }
		    
		}catch(Exception e){
			logger.debug("isLogin : " + e);
		}
		    
	    return false;
	}
	
	/* 사용안함
	//중복 로그인 막기 위해 주민번호 사용중인지 체크
	public boolean isUsing(String juminNo)
	{
		boolean isUsing = false;
		
		    Enumeration e = loginUsers.keys();
		    String key = "";
		    while(e.hasMoreElements())
		    {
		        key = (String)e.nextElement();
		        if(juminNo.equals(loginUsers.get(key)))
		        {
		            isUsing = true;
		        }
		    }
		
	    return isUsing;
	}

	
	//세션 생성
	public void setSession(HttpSession session, String juminNo, MobileLoginDBVO vo)
	{
		
			System.out.println("#############setSession##########");
			System.out.println("## juminNo :" + juminNo);
			System.out.println("## sessionId :" + session.getId());
	
		    loginUsers.put(juminNo, session.getId());	//주민-세션 hashktable 생성
		    session.setAttribute("login", this.getInstance());
			session.setAttribute("ssno", juminNo);	//주민번호
			session.setAttribute("csnm", vo.getFD_MB_NAME());	//고객명
			session.setAttribute("maskssno", StringUtil.strMaskJumin(juminNo));	//주민번호
			session.setAttribute("maskcsnm", StringUtil.strMaskName(vo.getFD_MB_NAME()));	//고객명
			session.setAttribute("hphone1", vo.getFD_MB_HPHONE1());	//집전화1
			session.setAttribute("hphone2", vo.getFD_MB_HPHONE2());	//집전화2
			session.setAttribute("hphone3", vo.getFD_MB_HPHONE3());	//집전화3
			session.setAttribute("mphone1", vo.getFD_MB_MPHONE1());	//휴대전화1
			session.setAttribute("mphone2", vo.getFD_MB_MPHONE2());	//휴대전화2
			session.setAttribute("mphone3", vo.getFD_MB_MPHONE3());	//휴대전화3
			session.setAttribute("cphone1", vo.getFD_MB_CPHONE1());	
			session.setAttribute("cphone2", vo.getFD_MB_CPHONE2());	
			session.setAttribute("cphone3", vo.getFD_MB_CPHONE3());	
			session.setAttribute("email"  , vo.getFD_MB_EMAIL());	//이메일
			session.setAttribute("fax1"   , vo.getFD_MB_CFAX1());	//팩스1
			session.setAttribute("fax2"   , vo.getFD_MB_CFAX2());	//팩스2
			session.setAttribute("fax3"   , vo.getFD_MB_CFAX3());	//팩스3
			session.setAttribute("bizmember", vo.getFD_BUSINESS_GB());	//금융회원여부
		
	}
	*/
	//통합고객에서 받은 정보 추가하여 세션 생성
	public void setSession(HttpSession session, String juminNo, MobileLoginDBVO vo, CmmFBM0299RVO vo2,SqlSessionTemplate sqlSession)
	{
		try{
			System.out.println("#############setSession##########");
			System.out.println("## juminNo :" + juminNo);
			System.out.println("## sessionId :" + session.getId());
	
		    loginUsers.put(juminNo, session.getId());	//주민-세션 hashktable 생성
		    session.setAttribute("login", this.getInstance());
			session.setAttribute("ssno", juminNo);		//주민번호
			session.setAttribute("maskssno", StringUtil.strMaskJumin(juminNo));	//주민번호
				
			if ( vo2 != null && vo2.getHO_GOGEK_NM() != null && !"".equals(vo2.getHO_GOGEK_NM())) {
				//통고고객명이 존재하면 통고고객명으로 고객명 셋팅
				session.setAttribute("csnm", vo2.getHO_GOGEK_NM());	//고객명
				session.setAttribute("maskcsnm", StringUtil.strMaskName(vo2.getHO_GOGEK_NM()));	//고객명마스킹
			}else if ( vo != null && vo.getFD_MB_NAME() != null && !"".equals(vo.getFD_MB_NAME())) {
				//통고고객명이 존재하지 않으면 회원테이블명으로 고객명 셋팅
				session.setAttribute("csnm", vo.getFD_MB_NAME());	//고객명
				session.setAttribute("maskcsnm", StringUtil.strMaskName(vo.getFD_MB_NAME()));	//고객명마스킹
			}else{
				session.setAttribute("csnm", "");		//고객명
				session.setAttribute("maskcsnm", "");	//고객명마스킹
			}		
	
			if ( vo2 != null ) {
				
				if ( vo2.getSI_H_TEL1() != null ) { 
					session.setAttribute("hphone1", vo2.getSI_H_TEL1());	//집전화1 
				} else { 
					session.setAttribute("hphone1", ""); 
				}
	
				if ( vo2.getSI_H_TEL2() != null ) { 
					session.setAttribute("hphone2", vo2.getSI_H_TEL2());	//집전화2 
				} else { 
					session.setAttribute("hphone2", ""); 
				}
	
				if ( vo2.getSI_H_TEL3() != null ) {
					session.setAttribute("hphone3", vo2.getSI_H_TEL3());	//집전화3 
				} else { 
					session.setAttribute("hphone3", ""); 
				}
	
				if ( vo2.getSI_HP_TEL1() != null ) {
					session.setAttribute("mphone1", vo2.getSI_HP_TEL1());	//휴대전화1 
				}
				else {
					session.setAttribute("mphone1", "");
				}
				
				if("".equals((String)session.getAttribute("mphone1")) && vo.getFD_MB_MPHONE1() != null) {
					session.setAttribute("mphone1", vo.getFD_MB_MPHONE1());
				}
				
				if ( vo2.getSI_HP_TEL2() != null ) {
					session.setAttribute("mphone2", vo2.getSI_HP_TEL2());	//휴대전화2 
				}
				else { 
					session.setAttribute("mphone2", ""); 
				}

				if("".equals((String)session.getAttribute("mphone2")) && vo.getFD_MB_MPHONE2() != null) {
					session.setAttribute("mphone2", vo.getFD_MB_MPHONE2());
				}
				
				if ( vo2.getSI_HP_TEL3() != null ) { 
					session.setAttribute("mphone3", vo2.getSI_HP_TEL3());	//휴대전화3 
				}
				else { 
					session.setAttribute("mphone3", ""); 
				}
				
				if("".equals((String)session.getAttribute("mphone3")) && vo.getFD_MB_MPHONE3() != null) {
					session.setAttribute("mphone3", vo.getFD_MB_MPHONE3());
				}

				if ( vo2.getSI_J_TEL1() != null ) { 
					session.setAttribute("cphone1", vo2.getSI_J_TEL1()); 
				} else { 
					session.setAttribute("cphone1", ""); 
				}
				
				if ( vo2.getSI_J_TEL2() != null ) { 
					session.setAttribute("cphone2", vo2.getSI_J_TEL2()); 
				} else { 
					session.setAttribute("cphone2", ""); 
				}
				
				if ( vo2.getSI_J_TEL3() != null ) { 
					session.setAttribute("cphone3", vo2.getSI_J_TEL3()); 
				} else { 
					session.setAttribute("cphone3", ""); 
				}
				
				if ( vo2.getSI_EMAIL_ID() != null ) {
					session.setAttribute("email"  , vo2.getSI_EMAIL_ID());	//이메일 
				} else { 
					session.setAttribute("email"  , ""); 
				}
	
			} else {
				session.setAttribute("hphone1", "");	//집전화1
				session.setAttribute("hphone2", "");	//집전화2
				session.setAttribute("hphone3", "");	//집전화3
				session.setAttribute("mphone1", "");	//휴대전화1
				session.setAttribute("mphone2", "");	//휴대전화2
				session.setAttribute("mphone3", "");	//휴대전화3
				session.setAttribute("cphone1", "");	
				session.setAttribute("cphone2", "");	
				session.setAttribute("cphone3", "");	
				session.setAttribute("email"  , "");	//이메일	
			}
			
			if ( vo != null && vo.getFD_MB_CFAX1() != null ) { 
				session.setAttribute("fax1" , vo.getFD_MB_CFAX1());	//팩스1 
			} else { 
				session.setAttribute("fax1" , ""); 
			}
			
			if ( vo != null && vo.getFD_MB_CFAX2() != null ) {
				session.setAttribute("fax2"   , vo.getFD_MB_CFAX2());	//팩스2 
			} else { 
				session.setAttribute("fax2" , ""); 
			}
			
			if ( vo != null && vo.getFD_MB_CFAX3() != null ) { 
				session.setAttribute("fax3"   , vo.getFD_MB_CFAX3());	//팩스3 
			} else { 
				session.setAttribute("fax3" , ""); 
			}
			
			if ( "1".equals(vo.getFD_BUSINESS_GB()) || "2".equals(vo.getFD_MB_BANK_GB()) ) {
				System.out.println("##금융회원임 ");
				session.setAttribute("bizmember", "1");	//금융회원여부
			} else {
				System.out.println("##비금융회원임 ");
				session.setAttribute("bizmember", "0");	//금융회원여부
			}
			
			//이중화 서버 중복로그인 체크를 위해 세션생성시 세션아이디,주민번호 DB테이블에 INSERT
			LogSessionVO logvo = new LogSessionVO();
			logvo.setSessionId(session.getId().toString());
			logvo.setJuminNo(juminNo);			
			int insertLog = insertSessionLog(sqlSession,logvo);						
			logger.debug("insertSessionLog result : " + insertLog);
			
		} catch (Exception e) {
			logger.error("setSession e: " + e);					
		}
	}
	//로그인후 세션 생성시 DB에 인서트
	private int insertSessionLog(SqlSessionTemplate sqlSession, LogSessionVO logvo) {
		int insertLog = sqlSession.getMapper(CommonDao.class).insertSessionLog(logvo);
		
		return insertLog;
	}
	//DB에서 세션에 있는 주민번호에 해당하는 가장 최근의 세션ID 조회
	private String getSessionId(SqlSessionTemplate sqlSession, LogSessionVO logvo) {
		String strSessionId = sqlSession.getMapper(CommonDao.class).getSessionId(logvo);
		
		return strSessionId;
	}
	
	
	//세션 성립될 때
	public void valueBound(HttpSessionBindingEvent event)
	{
		//valueBound
	}
	
	//세션 끊길때
	public void valueUnbound(HttpSessionBindingEvent event)
	{
		
			System.out.println("############# Session Value Unbound ##########");
			
			Enumeration e = loginUsers.keys();
		    String key = "";
		    String strSessionId = (String)event.getSession().getId();
		    while(e.hasMoreElements())
		    {
		        key = (String)e.nextElement();
		        if(strSessionId.equals(loginUsers.get(key)))
		        {
		    		System.out.println("## juminNo :" + key);
		    		System.out.println("## sessionId :" + strSessionId);
	
		        	//주민-세션 hashktable에서 삭제
		        	loginUsers.remove( strSessionId );
		        }
		    }
		
	}

	
	//세션에서 주민번호 얻기
	public String getJumin(String sessionId)
	{
		if ( sessionId == null ) {
			return "";
		}

	    String juminNo = "";
	    
	    
	    Enumeration e = loginUsers.keys();
		    String key = "";
		    while(e.hasMoreElements())
		    {
		        key = (String)e.nextElement();
		        if(sessionId.equals(loginUsers.get(key)))
		        {
		        	juminNo = key;
		        	break;
		        }
		    }
	    
	    return juminNo;
	}
	
}