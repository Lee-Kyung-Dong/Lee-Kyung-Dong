package com.idongbu.common;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.URL;

import org.apache.log4j.Logger;
 
public class HttpViewer {

	  private static Logger logger = Logger.getLogger(HttpViewer.class);
	
	  public static String excutePost(String targetURL, String urlParameters)  
	  {    
		  URL url;    
		  HttpURLConnection connection = null;      
		  // ExStopWatch esw = new ExStopWatch();
		  StringBuffer response = new StringBuffer();
		  DataOutputStream wr = null;
		  InputStream    is = null;
		  BufferedReader rd = null;
		  try 
		  {      
			  //Create connection   
			  logger.info("Send request Start");
			  url = new URL(targetURL);    
			  connection = (HttpURLConnection)url.openConnection();   
			  connection.setReadTimeout(20000);
			  
			  connection.setRequestMethod("POST");      
			  connection.setRequestProperty("Content-Type",     "application/x-www-form-urlencoded");			      
			  connection.setRequestProperty("Content-Length", "" + Integer.toString(urlParameters.getBytes().length));      
			  connection.setRequestProperty("Content-Language", "utf-8");  			      
			  connection.setUseCaches (false);      
			  connection.setDoInput(true);      
			  connection.setDoOutput(true);      
			  
			  //Send request      
			  wr = new DataOutputStream ( connection.getOutputStream ());      
			  wr.writeBytes (urlParameters);      
			  wr.flush ();      
			        
			  logger.info("Send request End;");
			  //Get Response	      
			  is = connection.getInputStream();      
			  rd = new BufferedReader(new InputStreamReader(is));
			  
			  String line;      
			         
//			  while((line = rd.readLine()) != null) 
			  while(true) 
			  {        
				  line = rd.readLine();
				  if(line == null) break;
				  
				  response.append(line);        
				  response.append('\r');      
			  }      
			    
			  logger.info("Read request End;");
			  return response.toString();   
		  } catch(SocketTimeoutException ex){
			  logger.error(ex.toString());
              return  "timeout";
		  } catch (Exception e) {   
			     logger.error(e.toString());
				 return null;    
		  } finally {
			  if(rd != null) try{rd.close();}catch(Exception e){ rd = null;}   
			  if(is != null) try{is.close();}catch(Exception e){ is = null;}   
			  if(wr != null) try{wr.close();}catch(Exception e){ wr = null;}
			  if(connection != null) try{connection.disconnect();}catch(Exception e){connection = null;} 
		 }
		  
	  }
	
}
