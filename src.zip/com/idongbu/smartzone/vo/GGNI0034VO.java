package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class GGNI0034VO extends CMMVO{
	
	//전문필드
	public String plno = "";  //[I] 증권번호 LK_WK2808_POLI_NO 증권번호
	public String inpd_cd = "";  //[I/O] 보종코드 LK_WK2808_BOJONG_CD 보종코드
	public String inpd_nm = "";  //[O] 보종명 H_LK_WK2808_BOJONG_NM 보종명
	public String apl_dttm_ps = "";  //[O] 청약일시기 LK_WK2808_CHUNGYAK_SYMD 청약일(시기)
	public String apl_dd_et = "";  //[O] 청약일종기 LK_WK2808_CHUNGYAK_EYMD 청약일(종기)
	public String plhd_nm = "";  //[O] 계약자명 H_LK_WK2808_GYEYAKJA_NM 계약자명
	public String psno = "";  //[O] 우편번호 LK_WK2808_UPYUN_NO 우편번호
	public String eta_stn = "";  //[O] 기타번지 H_LK_WK2808_GITA_BUNJI 기타번지
	public String pym_prm = "";  //[O] 납입보험료 LK_WK2808_NAPIP_AMT 납입보험료
	public String pym_mtd = "";  //[O] 납입방법 LK_WK2808_NAPBANG_CD 납입방법
	public String pym_mtd_hngl_nm = "";  //[O] 납입방법한글명 H_LK_WK2808_NAPIP_BB 납입방법한글명
	public String eny_tpcd = "";  //[O] 가입유형코드 LK_WK2808_GAIP_YUHYUNG_CD 가입유형코드
	public String eny_typ = "";  //[O] 가입유형 H_LK_WK2808_GAIP_YUHYUNG 가입유형
	public String ctc_stat_cd = "";  //[O] 계약상태코드 LK_WK2808_GYEYAK_ST_CD 계약상태코드
	public String ctc_stat_nm = "";  //[O] 계약상태명 H_LK_WK2808_GYEYAK_ST 계약상태명
	public String hdlr = "";  //[O] 취급자 LK_WK2808_CHUIGPJA 취급자
	public String hdlr_nm = "";  //[O] 취급자명 H_LK_WK2808_CHUIGPJA_NM 취급자명
	public String tlno = "";  //[O] 전화번호 LK_WK2808_TELEPHONE 전화번호
	public String psno_1 = "";  //[O] 우편번호1 LK_ZIP 소재지 우편번호
	public String eta_stn_1 = "";  //[O] 기타번지1 H_LK_GITA_BUNJI 소재지 기타번지
	public String nw_adr_dvn = "";  //[O] 신주소구분 LK-WK2808-SINGU-GB  신주소구분
	public String psno_nw_adr = "";  //[O] 우편번호신주소 LK-WK2808-ST-ZIP-NO 우편번호(신주소)
	public String nw_adr = "";  //[O] 신주소 H-LK-WK2808-ST-ADDR 주소(신주소)
	public String eta_main_stn_nw_adr = "";  //[O] 기타주번지신주소 H-LK-WK2808-ST-GITA 기타주번지(신주소)
	public String[] gnrl_arc_dtl_srch_7_3_4_1__bsc_cvr_nm = new String[0];  //[O] 일반보험상세조회734_배열1_기본담보명 H_LK_WK2808_GIBON_DAMBO 기본담보명
	public String[] gnrl_arc_dtl_srch_7_3_4_1__bsc_cvr_cd = new String[0];  //[O] 일반보험상세조회734_배열1_기본담보코드  
	public String[] gnrl_arc_dtl_srch_7_3_4_1__cvr_inam = new String[0];  //[O] 일반보험상세조회734_배열1_담보가입금액 LK_WK2808_DAMBO_GAIP_AMT 담보가입금액
	public String[] gnrl_arc_dtl_srch_7_3_4_2__tty_cd_nm = new String[0];  //[O] 일반보험상세조회734_배열2_특약명 H_LK_WK2808_TKYAK_DAMBO 특약코드
	public String[] gnrl_arc_dtl_srch_7_3_4_2__tty_cd = new String[0];  //[O] 일반보험상세조회734_배열2_특약코드
	public String[] gnrl_arc_dtl_srch_7_3_4_2__tty_inam = new String[0];  //[O] 일반보험상세조회734_배열2_특약가입금액 LK_WK2808_TKYAK_GAIP_AMT 특약가입금액
	
	public String msg_cd = "";  //[O] 메시지코드  
	public String msg_err = "";  //[O] 에러메시지 
	
	
	
	public String getPlno() {
		return plno;
	}
	public void setPlno(String plno) {
		this.plno = plno;
	}
	public String getInpd_cd() {
		return inpd_cd;
	}
	public void setInpd_cd(String inpd_cd) {
		this.inpd_cd = inpd_cd;
	}
	public String getInpd_nm() {
		return inpd_nm;
	}
	public void setInpd_nm(String inpd_nm) {
		this.inpd_nm = inpd_nm;
	}
	public String getApl_dttm_ps() {
		return apl_dttm_ps;
	}
	public void setApl_dttm_ps(String apl_dttm_ps) {
		this.apl_dttm_ps = apl_dttm_ps;
	}
	public String getApl_dd_et() {
		return apl_dd_et;
	}
	public void setApl_dd_et(String apl_dd_et) {
		this.apl_dd_et = apl_dd_et;
	}
	public String getPlhd_nm() {
		return plhd_nm;
	}
	public void setPlhd_nm(String plhd_nm) {
		this.plhd_nm = plhd_nm;
	}
	public String getPsno() {
		return psno;
	}
	public void setPsno(String psno) {
		this.psno = psno;
	}
	public String getEta_stn() {
		return eta_stn;
	}
	public void setEta_stn(String eta_stn) {
		this.eta_stn = eta_stn;
	}
	public String getPym_prm() {
		return pym_prm;
	}
	public void setPym_prm(String pym_prm) {
		this.pym_prm = pym_prm;
	}
	public String getPym_mtd() {
		return pym_mtd;
	}
	public void setPym_mtd(String pym_mtd) {
		this.pym_mtd = pym_mtd;
	}
	public String getPym_mtd_hngl_nm() {
		return pym_mtd_hngl_nm;
	}
	public void setPym_mtd_hngl_nm(String pym_mtd_hngl_nm) {
		this.pym_mtd_hngl_nm = pym_mtd_hngl_nm;
	}
	public String getEny_tpcd() {
		return eny_tpcd;
	}
	public void setEny_tpcd(String eny_tpcd) {
		this.eny_tpcd = eny_tpcd;
	}
	public String getEny_typ() {
		return eny_typ;
	}
	public void setEny_typ(String eny_typ) {
		this.eny_typ = eny_typ;
	}
	public String getCtc_stat_cd() {
		return ctc_stat_cd;
	}
	public void setCtc_stat_cd(String ctc_stat_cd) {
		this.ctc_stat_cd = ctc_stat_cd;
	}
	public String getCtc_stat_nm() {
		return ctc_stat_nm;
	}
	public void setCtc_stat_nm(String ctc_stat_nm) {
		this.ctc_stat_nm = ctc_stat_nm;
	}
	public String getHdlr() {
		return hdlr;
	}
	public void setHdlr(String hdlr) {
		this.hdlr = hdlr;
	}
	public String getHdlr_nm() {
		return hdlr_nm;
	}
	public void setHdlr_nm(String hdlr_nm) {
		this.hdlr_nm = hdlr_nm;
	}
	public String getTlno() {
		return tlno;
	}
	public void setTlno(String tlno) {
		this.tlno = tlno;
	}
	public String getPsno_1() {
		return psno_1;
	}
	public void setPsno_1(String psno_1) {
		this.psno_1 = psno_1;
	}
	public String getEta_stn_1() {
		return eta_stn_1;
	}
	public void setEta_stn_1(String eta_stn_1) {
		this.eta_stn_1 = eta_stn_1;
	}
	public String getNw_adr_dvn() {
		return nw_adr_dvn;
	}
	public void setNw_adr_dvn(String nw_adr_dvn) {
		this.nw_adr_dvn = nw_adr_dvn;
	}
	public String getPsno_nw_adr() {
		return psno_nw_adr;
	}
	public void setPsno_nw_adr(String psno_nw_adr) {
		this.psno_nw_adr = psno_nw_adr;
	}
	public String getNw_adr() {
		return nw_adr;
	}
	public void setNw_adr(String nw_adr) {
		this.nw_adr = nw_adr;
	}
	public String getEta_main_stn_nw_adr() {
		return eta_main_stn_nw_adr;
	}
	public void setEta_main_stn_nw_adr(String eta_main_stn_nw_adr) {
		this.eta_main_stn_nw_adr = eta_main_stn_nw_adr;
	}
	public String[] getGnrl_arc_dtl_srch_7_3_4_1__bsc_cvr_nm() {
		return gnrl_arc_dtl_srch_7_3_4_1__bsc_cvr_nm;
	}
	public void setGnrl_arc_dtl_srch_7_3_4_1__bsc_cvr_nm(
			String[] gnrl_arc_dtl_srch_7_3_4_1__bsc_cvr_nm) {
		this.gnrl_arc_dtl_srch_7_3_4_1__bsc_cvr_nm = gnrl_arc_dtl_srch_7_3_4_1__bsc_cvr_nm;
	}
	public String[] getGnrl_arc_dtl_srch_7_3_4_1__bsc_cvr_cd() {
		return gnrl_arc_dtl_srch_7_3_4_1__bsc_cvr_cd;
	}
	public void setGnrl_arc_dtl_srch_7_3_4_1__bsc_cvr_cd(
			String[] gnrl_arc_dtl_srch_7_3_4_1__bsc_cvr_cd) {
		this.gnrl_arc_dtl_srch_7_3_4_1__bsc_cvr_cd = gnrl_arc_dtl_srch_7_3_4_1__bsc_cvr_cd;
	}
	public String[] getGnrl_arc_dtl_srch_7_3_4_1__cvr_inam() {
		return gnrl_arc_dtl_srch_7_3_4_1__cvr_inam;
	}
	public void setGnrl_arc_dtl_srch_7_3_4_1__cvr_inam(
			String[] gnrl_arc_dtl_srch_7_3_4_1__cvr_inam) {
		this.gnrl_arc_dtl_srch_7_3_4_1__cvr_inam = gnrl_arc_dtl_srch_7_3_4_1__cvr_inam;
	}
	public String[] getGnrl_arc_dtl_srch_7_3_4_2__tty_cd_nm() {
		return gnrl_arc_dtl_srch_7_3_4_2__tty_cd_nm;
	}
	public void setGnrl_arc_dtl_srch_7_3_4_2__tty_cd_nm(
			String[] gnrl_arc_dtl_srch_7_3_4_2__tty_cd_nm) {
		this.gnrl_arc_dtl_srch_7_3_4_2__tty_cd_nm = gnrl_arc_dtl_srch_7_3_4_2__tty_cd_nm;
	}
	public String[] getGnrl_arc_dtl_srch_7_3_4_2__tty_cd() {
		return gnrl_arc_dtl_srch_7_3_4_2__tty_cd;
	}
	public void setGnrl_arc_dtl_srch_7_3_4_2__tty_cd(
			String[] gnrl_arc_dtl_srch_7_3_4_2__tty_cd) {
		this.gnrl_arc_dtl_srch_7_3_4_2__tty_cd = gnrl_arc_dtl_srch_7_3_4_2__tty_cd;
	}
	public String[] getGnrl_arc_dtl_srch_7_3_4_2__tty_inam() {
		return gnrl_arc_dtl_srch_7_3_4_2__tty_inam;
	}
	public void setGnrl_arc_dtl_srch_7_3_4_2__tty_inam(
			String[] gnrl_arc_dtl_srch_7_3_4_2__tty_inam) {
		this.gnrl_arc_dtl_srch_7_3_4_2__tty_inam = gnrl_arc_dtl_srch_7_3_4_2__tty_inam;
	}
	public String getMsg_cd() {
		return msg_cd;
	}
	public void setMsg_cd(String msg_cd) {
		this.msg_cd = msg_cd;
	}
	public String getMsg_err() {
		return msg_err;
	}
	public void setMsg_err(String msg_err) {
		this.msg_err = msg_err;
	}

}
