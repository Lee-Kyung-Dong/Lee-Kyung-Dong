package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class IFMOB014VO extends CMMVO {

    public String webM = "IF_MOB_014";

    // 입력
    public String I_LN_ID = null;           // 대출약정번호
    public String I_SSN = null;             // 고객주민번호
    public String I_CUST_NM = null;         // 고객명
    public String I_CNTR_YMD = null;        // 약정일자
    public String I_CL_ASS_YMD = null;      // 지급예정일
    public String I_PICD = null;            // 상품코드
    public String I_LN_PRG_SCD = null;      // 대출진행상태코드
    public String I_LN_APY_AMT = null;      // 대출신청금액
    public String I_REU_RAT = null;         // 대출금리
    public String I_INT_PM_DD = null;       // 이자납입일
    public String I_LN_PRD = null;          // 대출기간(개월)
    public String I_EXH_MCD = null;         // 상환방법코드
    public String I_DIV_EXC_CD = null;	    // 분할상환코드
    public String I_COLL_KCD = null;	    // 담보종류코드
    public String I_COLL_ATT_CD = null;	    // 담보속성코드
    public String I_LN_FUSE_CD = null;	    // 자금용도구분코드
    public String I_CMS_RT_USE = null;	    // CMS/RT 개인정보 수집/이용 동의
    public String I_CMS_RT_OFFR = null;	    // CMS/RT 개인정보 제3자 제공동의
    public String I_DEPO_BCD = null;	    // 지급 계좌 은행코드
    public String I_DEPO_ACNO = null;	    // 지급 계좌 번호
    public String I_RECV_BCD = null;	    // 이자납입 계좌 은행코드
    public String I_RECV_ACNO = null;	    // 이자납입 계좌 번호
    public String I_ACN_SCD = null;	        // 계좌상태
    public String I_ACN_SCD_RT = null;	    // 실시간 계좌상태

    // 출력
    public String O_RET_CD = null;			// 결과코드 - 00:정상 , 10:입력값 누락, 11:입력값 오류, 99:시스템오류
    public String O_RET_MSG = null;			// 결과메시지
    public String O_LN_ID = null;	        // 대출약정번호
    public String O_LN_EXP_YMD = null;	    // 대출종료일
    public String O_INT_PM_YMD = null;	    // 차기원리금납입일
}
