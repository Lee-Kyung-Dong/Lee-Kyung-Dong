package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class MMTI0259VO extends CMMVO{
	
	public String pbox_use_yn = "";		// [I] 사서함사용유무
	public String pbox_no = "";			// [I] 사서함번호
	public String phgp_cnfm_dt = "";	// [I] 사진확인일자
	public String phgp_strg_yn = "";	// [I] 사진저장여부
	public String pbox_resp_tlno = "";	// [I] 사서함응답전화번호
	public String pbox_chr_nm = "";		// [I] 사서함문자명
	public String errorCode = "";
	public String z_resp_msg = "";
	
	public String aut_cgnt_trv_dstc_rsl_cd = "";	// [I] 자동인식주행거리결과코드
	public String aut_cgnt_vh_no_rsl_cd = "";		// [I] 자동인식차량번호결과코드
	public String inpt_trv_dstc = "";				// [I] 입력주행거리
	public String aut_cgnt_trv_dstc = "";			// [I] 자동인식주행거리
	public String aut_cgnt_vh_no = "";				// [I] 자동인식차량번호
	public String exp_exca_plan_proc_dvn = "";		// [I] 만기정산설계처리구분
	public String aut_cgnt_hist_sqno = "";			// [I] 자동인식이력일련번호
	public String exp_exca_plan_rsl_cd = "";		// [O] 만기정산설계결과코드
	public String adc_rtrn_dvn = "";				// [O] 추징환급구분
	public String adc_rtrn_prm = "";				// [O] 추징환급보험료
	public String plno = "";						// [O] 증권번호
	public String exp_exca_plan_no = "";			// [O] 만기정산설계번호
	public String exp_exca_plan_bse_dd = "";		// [O] 만기정산설계기준일
	public String cnv_trv_dstc = "";
	public String phgp_ptgr_dt = "";				// [I] 사진촬영일자
	public String pdc_sr_dvn = "";					// [O] CM, TM, TD
	public String plhd_cust_nm = "";				// [O] 계약자고객명
	
	public String aut_cgnt_trv_dstc_1;				// [I] 자동인식주행거리1
	public String aut_cgnt_trv_dstc_2;				// [I] 자동인식주행거리2
	public String aut_cgnt_trv_dstc_3;				// [I] 자동인식주행거리3
	
	public String phgp_rl_ptgr_dt = "";				// 사진실제촬영일자(년월일시분초)
	public String phgp_apdx_way_cd = "";			// 사진첨부방식코드 (1. 촬영, 2. 불러오기)
	
	public String crd_scn_cncl_pss_yn = "";			// 카드부분취소가능여부
	public String stlm_cdcp_nm = "";				// 결제카드사명
	public String stlm_crd_no = "";					// 결제카드번호
	
	public String z_tlg_sp_cd = "";
	public String z_trns_org_cd = "";
	public String z_trns_org_dvcd = "";
	public String z_trsc_id = "";
	public String z_resp_cd = "";
	
	//20220816 aiocr용 추가
	public String a_i_o_c_r_rqst_dsky_val = "";		// [I/O] aiocr요청구분키값
	public String dtcn_cgnt_rt = "";				// [I/O] 검출인식률
	public String cgnt_cgnt_rt = "";				// [I/O] 인식인식률
	
	
	public String getPbox_use_yn() {
		return pbox_use_yn;
	}
	public void setPbox_use_yn(String pbox_use_yn) {
		this.pbox_use_yn = pbox_use_yn;
	}
	public String getPbox_no() {
		return pbox_no;
	}
	public void setPbox_no(String pbox_no) {
		this.pbox_no = pbox_no;
	}
	public String getPhgp_cnfm_dt() {
		return phgp_cnfm_dt;
	}
	public void setPhgp_cnfm_dt(String phgp_cnfm_dt) {
		this.phgp_cnfm_dt = phgp_cnfm_dt;
	}
	public String getPhgp_strg_yn() {
		return phgp_strg_yn;
	}
	public void setPhgp_strg_yn(String phgp_strg_yn) {
		this.phgp_strg_yn = phgp_strg_yn;
	}
	public String getPbox_resp_tlno() {
		return pbox_resp_tlno;
	}
	public void setPbox_resp_tlno(String pbox_resp_tlno) {
		this.pbox_resp_tlno = pbox_resp_tlno;
	}
	public String getPbox_chr_nm() {
		return pbox_chr_nm;
	}
	public void setPbox_chr_nm(String pbox_chr_nm) {
		this.pbox_chr_nm = pbox_chr_nm;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getZ_resp_msg() {
		return z_resp_msg;
	}
	public void setZ_resp_msg(String z_resp_msg) {
		this.z_resp_msg = z_resp_msg;
	}
	public String getAut_cgnt_trv_dstc_rsl_cd() {
		return aut_cgnt_trv_dstc_rsl_cd;
	}
	public void setAut_cgnt_trv_dstc_rsl_cd(String aut_cgnt_trv_dstc_rsl_cd) {
		this.aut_cgnt_trv_dstc_rsl_cd = aut_cgnt_trv_dstc_rsl_cd;
	}
	public String getAut_cgnt_vh_no_rsl_cd() {
		return aut_cgnt_vh_no_rsl_cd;
	}
	public void setAut_cgnt_vh_no_rsl_cd(String aut_cgnt_vh_no_rsl_cd) {
		this.aut_cgnt_vh_no_rsl_cd = aut_cgnt_vh_no_rsl_cd;
	}
	public String getInpt_trv_dstc() {
		return inpt_trv_dstc;
	}
	public void setInpt_trv_dstc(String inpt_trv_dstc) {
		this.inpt_trv_dstc = inpt_trv_dstc;
	}
	public String getAut_cgnt_trv_dstc() {
		return aut_cgnt_trv_dstc;
	}
	public void setAut_cgnt_trv_dstc(String aut_cgnt_trv_dstc) {
		this.aut_cgnt_trv_dstc = aut_cgnt_trv_dstc;
	}
	public String getAut_cgnt_vh_no() {
		return aut_cgnt_vh_no;
	}
	public void setAut_cgnt_vh_no(String aut_cgnt_vh_no) {
		this.aut_cgnt_vh_no = aut_cgnt_vh_no;
	}
	public String getExp_exca_plan_proc_dvn() {
		return exp_exca_plan_proc_dvn;
	}
	public void setExp_exca_plan_proc_dvn(String exp_exca_plan_proc_dvn) {
		this.exp_exca_plan_proc_dvn = exp_exca_plan_proc_dvn;
	}
	public String getAut_cgnt_hist_sqno() {
		return aut_cgnt_hist_sqno;
	}
	public void setAut_cgnt_hist_sqno(String aut_cgnt_hist_sqno) {
		this.aut_cgnt_hist_sqno = aut_cgnt_hist_sqno;
	}
	public String getExp_exca_plan_rsl_cd() {
		return exp_exca_plan_rsl_cd;
	}
	public void setExp_exca_plan_rsl_cd(String exp_exca_plan_rsl_cd) {
		this.exp_exca_plan_rsl_cd = exp_exca_plan_rsl_cd;
	}
	public String getAdc_rtrn_dvn() {
		return adc_rtrn_dvn;
	}
	public void setAdc_rtrn_dvn(String adc_rtrn_dvn) {
		this.adc_rtrn_dvn = adc_rtrn_dvn;
	}
	public String getAdc_rtrn_prm() {
		return adc_rtrn_prm;
	}
	public void setAdc_rtrn_prm(String adc_rtrn_prm) {
		this.adc_rtrn_prm = adc_rtrn_prm;
	}
	public String getPlno() {
		return plno;
	}
	public void setPlno(String plno) {
		this.plno = plno;
	}
	public String getExp_exca_plan_no() {
		return exp_exca_plan_no;
	}
	public void setExp_exca_plan_no(String exp_exca_plan_no) {
		this.exp_exca_plan_no = exp_exca_plan_no;
	}
	public String getExp_exca_plan_bse_dd() {
		return exp_exca_plan_bse_dd;
	}
	public void setExp_exca_plan_bse_dd(String exp_exca_plan_bse_dd) {
		this.exp_exca_plan_bse_dd = exp_exca_plan_bse_dd;
	}
	public String getCnv_trv_dstc() {
		return cnv_trv_dstc;
	}
	public void setCnv_trv_dstc(String cnv_trv_dstc) {
		this.cnv_trv_dstc = cnv_trv_dstc;
	}
	public String getPhgp_ptgr_dt() {
		return phgp_ptgr_dt;
	}
	public void setPhgp_ptgr_dt(String phgp_ptgr_dt) {
		this.phgp_ptgr_dt = phgp_ptgr_dt;
	}
	public String getPdc_sr_dvn() {
		return pdc_sr_dvn;
	}
	public void setPdc_sr_dvn(String pdc_sr_dvn) {
		this.pdc_sr_dvn = pdc_sr_dvn;
	}
	public String getPlhd_cust_nm() {
		return plhd_cust_nm;
	}
	public void setPlhd_cust_nm(String plhd_cust_nm) {
		this.plhd_cust_nm = plhd_cust_nm;
	}
	public String getAut_cgnt_trv_dstc_1() {
		return aut_cgnt_trv_dstc_1;
	}
	public void setAut_cgnt_trv_dstc_1(String aut_cgnt_trv_dstc_1) {
		this.aut_cgnt_trv_dstc_1 = aut_cgnt_trv_dstc_1;
	}
	public String getAut_cgnt_trv_dstc_2() {
		return aut_cgnt_trv_dstc_2;
	}
	public void setAut_cgnt_trv_dstc_2(String aut_cgnt_trv_dstc_2) {
		this.aut_cgnt_trv_dstc_2 = aut_cgnt_trv_dstc_2;
	}
	public String getAut_cgnt_trv_dstc_3() {
		return aut_cgnt_trv_dstc_3;
	}
	public void setAut_cgnt_trv_dstc_3(String aut_cgnt_trv_dstc_3) {
		this.aut_cgnt_trv_dstc_3 = aut_cgnt_trv_dstc_3;
	}
	public String getPhgp_rl_ptgr_dt() {
		return phgp_rl_ptgr_dt;
	}
	public void setPhgp_rl_ptgr_dt(String phgp_rl_ptgr_dt) {
		this.phgp_rl_ptgr_dt = phgp_rl_ptgr_dt;
	}
	public String getPhgp_apdx_way_cd() {
		return phgp_apdx_way_cd;
	}
	public void setPhgp_apdx_way_cd(String phgp_apdx_way_cd) {
		this.phgp_apdx_way_cd = phgp_apdx_way_cd;
	}
	public String getCrd_scn_cncl_pss_yn() {
		return crd_scn_cncl_pss_yn;
	}
	public void setCrd_scn_cncl_pss_yn(String crd_scn_cncl_pss_yn) {
		this.crd_scn_cncl_pss_yn = crd_scn_cncl_pss_yn;
	}
	public String getStlm_cdcp_nm() {
		return stlm_cdcp_nm;
	}
	public void setStlm_cdcp_nm(String stlm_cdcp_nm) {
		this.stlm_cdcp_nm = stlm_cdcp_nm;
	}
	public String getStlm_crd_no() {
		return stlm_crd_no;
	}
	public void setStlm_crd_no(String stlm_crd_no) {
		this.stlm_crd_no = stlm_crd_no;
	}
	public String getZ_tlg_sp_cd() {
		return z_tlg_sp_cd;
	}
	public void setZ_tlg_sp_cd(String z_tlg_sp_cd) {
		this.z_tlg_sp_cd = z_tlg_sp_cd;
	}
	public String getZ_trns_org_cd() {
		return z_trns_org_cd;
	}
	public void setZ_trns_org_cd(String z_trns_org_cd) {
		this.z_trns_org_cd = z_trns_org_cd;
	}
	public String getZ_trns_org_dvcd() {
		return z_trns_org_dvcd;
	}
	public void setZ_trns_org_dvcd(String z_trns_org_dvcd) {
		this.z_trns_org_dvcd = z_trns_org_dvcd;
	}
	public String getZ_trsc_id() {
		return z_trsc_id;
	}
	public void setZ_trsc_id(String z_trsc_id) {
		this.z_trsc_id = z_trsc_id;
	}
	public String getZ_resp_cd() {
		return z_resp_cd;
	}
	public void setZ_resp_cd(String z_resp_cd) {
		this.z_resp_cd = z_resp_cd;
	}
	public String getA_i_o_c_r_rqst_dsky_val() {
		return a_i_o_c_r_rqst_dsky_val;
	}
	public void setA_i_o_c_r_rqst_dsky_val(String a_i_o_c_r_rqst_dsky_val) {
		this.a_i_o_c_r_rqst_dsky_val = a_i_o_c_r_rqst_dsky_val;
	}
	public String getDtcn_cgnt_rt() {
		return dtcn_cgnt_rt;
	}
	public void setDtcn_cgnt_rt(String dtcn_cgnt_rt) {
		this.dtcn_cgnt_rt = dtcn_cgnt_rt;
	}
	public String getCgnt_cgnt_rt() {
		return cgnt_cgnt_rt;
	}
	public void setCgnt_cgnt_rt(String cgnt_cgnt_rt) {
		this.cgnt_cgnt_rt = cgnt_cgnt_rt;
	}
	
}
