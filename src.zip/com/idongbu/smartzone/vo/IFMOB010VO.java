package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

//홈페이지 상담
public class IFMOB010VO extends CMMVO {
	public String webM = "IF_MOB_010";

	// 입력
	public String I_SSN = null;				// 주민번호
	public String I_CUST_NM = null;			// 고객명
	public String I_APY_YMD = null;			// 신청일자
	public String I_COLL_KCD = null;		// 대출구분 10:부동산,  20:신용, 90:전세자금대출 , 자동차담보대출
	public String I_COLL_ATT_CD = null;		// 2012 차세대수정, 대출세부구분자 추가, 2012.08.06 빈현욱. 대출세부구분  11:부동산,  21:신용, 98: 전세자금, 99: 자동차담보대출
	public String I_PNO = null;				// 전화번호
	public String I_PICD = null;			// 상품코드
	public String I_DEC_RT = null;			// CSS판정결과 
	public String I_LM_GD = null;			// 한도등급
	public String I_LM = null; 				// 대출가능한도
	public String I_RAT_GD = null;			// 금리등급
	public String I_RAT = null; 			// 대출가능금리
	

	// 출력
	public String O_RET_CD = null;			// 결과코드  00:정상 , 10:입력항목오류 , 99:시스템오류
	public String O_RET_MSG = null;			// 결과메시지
}
