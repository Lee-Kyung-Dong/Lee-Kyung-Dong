package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class AACT0022VO extends CMMVO{
	
	public String bank_cd = null;		//[I]은행코드
	public String bank_nm = null;		//[I]은행명
	public String acc_no = null;		//[I]계좌번호
	public String rsdn_no = null;		//[I]주민번호
	public String dpsr_nm = null;		//[I]예금주명
	public String rmn_rs_dvcd = null;	//[I]송금사유구분코드 (01(철회/취소) 02(해지/만기) : 예금주 확인만 하는경우 01 셋팅)
	public String chek_cd = null;		//[O]체크코드
	public String chek_cd_nm = null;	//[O]체크코드명
	public String outp_dpsr_nm = null;	//[O]출력예금주명
	public String com_pg_id = null;		//[O]통신프로그램ID
	public String com_fld = null;		//[O]통신필드

	public String errorCode = null;
	public String returnMessage = null;
	public String z_resp_msg = null;

	
	public String getBank_cd() {
		return bank_cd;
	}

	public void setBank_cd(String bank_cd) {
		this.bank_cd = bank_cd;
	}

	public String getBank_nm() {
		return bank_nm;
	}

	public void setBank_nm(String bank_nm) {
		this.bank_nm = bank_nm;
	}

	public String getAcc_no() {
		return acc_no;
	}

	public void setAcc_no(String acc_no) {
		this.acc_no = acc_no;
	}

	public String getRsdn_no() {
		return rsdn_no;
	}

	public void setRsdn_no(String rsdn_no) {
		this.rsdn_no = rsdn_no;
	}

	public String getDpsr_nm() {
		return dpsr_nm;
	}

	public void setDpsr_nm(String dpsr_nm) {
		this.dpsr_nm = dpsr_nm;
	}

	public String getRmn_rs_dvcd() {
		return rmn_rs_dvcd;
	}

	public void setRmn_rs_dvcd(String rmn_rs_dvcd) {
		this.rmn_rs_dvcd = rmn_rs_dvcd;
	}
	
	public String getChek_cd() {
		return chek_cd;
	}

	public void setChek_cd(String chek_cd) {
		this.chek_cd = chek_cd;
	}

	public String getChek_cd_nm() {
		return chek_cd_nm;
	}

	public void setChek_cd_nm(String chek_cd_nm) {
		this.chek_cd_nm = chek_cd_nm;
	}

	public String getOutp_dpsr_nm() {
		return outp_dpsr_nm;
	}

	public void setOutp_dpsr_nm(String outp_dpsr_nm) {
		this.outp_dpsr_nm = outp_dpsr_nm;
	}

	public String getCom_pg_id() {
		return com_pg_id;
	}

	public void setCom_pg_id(String com_pg_id) {
		this.com_pg_id = com_pg_id;
	}

	public String getCom_fld() {
		return com_fld;
	}

	public void setCom_fld(String com_fld) {
		this.com_fld = com_fld;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getReturnMessage() {
		return returnMessage;
	}

	public void setReturnMessage(String returnMessage) {
		this.returnMessage = returnMessage;
	}

	public String getZ_resp_msg() {
		return z_resp_msg;
	}

	public void setZ_resp_msg(String z_resp_msg) {
		this.z_resp_msg = z_resp_msg;
	}
	
}
