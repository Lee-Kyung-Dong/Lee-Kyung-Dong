// 경계주행거리정산처리

package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class MMTI0291VO extends CMMVO{ 
	public String trv_dstc_exca_mtt__exca_bz_proc_dvn = "";			// [I/O] 정산업무처리구분 (1: 설계, 2: 확정)
	public String trv_dstc_exca_mtt__plno = "";						// [I/O] 증권번호
	public String trv_dstc_exca_mtt__plan_no = "";					// [I/O] 설계번호
	public String trv_dstc_exca_mtt__plan_dt = "";					// [I/O] 설계일자
	public String trv_dstc_exca_mtt__exca_rtrn_dvn = "";			// [I/O] 정산환급구분 (1: 계좌환급, 2: 갱신계약활용)
	public String trv_dstc_exca_mtt__bank_cd = "";					// [I/O] 은행코드
	public String trv_dstc_exca_mtt__acc_no = "";					// [I/O] 계좌번호
	public String trv_dstc_exca_mtt__adc_rtrn_dvn = "";				// [I/O] 추징환급구분 (1: 추징, 2: 환급, 3: 미발생)
	public String trv_dstc_exca_mtt__adc_rtrn_prm = "";				// [I/O] 추징환급보험료
	public String trv_dstc_exca_mtt__cnv_trv_dstc = "";				// [I/O] 환산주행거리
	public String trv_dstc_exca_mtt__nrm_proc_yn = "";				// [I/O] 정상처리여부
	public String trv_dstc_exca_mtt__aut_cgnt_vh_no_eqal_yn = "";	// [I/O] 자동인식차량번호일치여부
	public String trv_dstc_exca_mtt__aut_cgnt_trv_dstc_eqal_yn = "";// [I/O] 자동인식주행거리일치여부
	public String trv_dstc_exca_mtt__rnw_plno = "";					// [I/O] 갱신증권번호
	public String trv_dstc_exca_mtt__hdlr_empno = "";				// [I/O] 취급자사원번호
	public String trv_dstc_exca_mtt__aut_cgnt_trv_dstc_rsl_cd = "";	// [I/O] 자동인식주행거리결과코드
	public String trv_dstc_exca_mtt__plhd_cust_nm = "";				// [I/O] 계약자고객명
	public String trv_dstc_exca_mtt__pdc_sr_dvn = "";				// [I/O] 상품출처구분 TM:TM상품,CM:CM상품,TD:그외상품
	public String trv_dstc_exca_mtt__scrn_proc_cd = "";				// [I/O] 화면처리코드 01:확정화면까지 진행,02:계좌입력화면까지 진행,03 혹은 빈값 혹은 null:계좌입력화면 띄우면 안됨
	public String trv_dstc_exca_mtt__arc_trm_str_dt = "";			// [I/O] 주행거리정산사항 보험기간시작일자
	public String trv_dstc_exca_mtt__trv_dstc_splc_exca_yn = "";	// [I/O] 주행거리간편정산여부
	public String trv_dstc_exca_mtt__pbox_no				= "";	// [I/O] 사서함번호
	
	public String trv_dstc_exca_mtt__imag_dup_yn = "";				// [I/O] 이미지중복여부
	public String trv_dstc_exca_mtt__rsl_cd = "";					// [I/O] 결과코드
	public String trv_dstc_exca_mtt__rsl_msg = "";					// [I/O] 결과메시지
	
	public String trv_dstc_exca_mtt__crd_scn_cncl_pss_yn = "";		// [I] 카드부분취소가능여부
	public String trv_dstc_exca_mtt__stlm_cdcp_nm = "";				// [I] 결제카드사명
	public String trv_dstc_exca_mtt__stlm_crd_no = "";				// [I] 결제카드번호
	
	public String errorCode = "";
	public String z_resp_msg = "";
	public String z_resp_cd = "";
	
	public String z_tlg_sp_cd = "";
	public String z_trns_org_cd = "";
	public String z_trns_org_dvcd = "";
	public String z_trsc_id = "";
	
	public String getTrv_dstc_exca_mtt__exca_bz_proc_dvn() {
		return trv_dstc_exca_mtt__exca_bz_proc_dvn;
	}
	public void setTrv_dstc_exca_mtt__exca_bz_proc_dvn(String trv_dstc_exca_mtt__exca_bz_proc_dvn) {
		this.trv_dstc_exca_mtt__exca_bz_proc_dvn = trv_dstc_exca_mtt__exca_bz_proc_dvn;
	}
	public String getTrv_dstc_exca_mtt__plno() {
		return trv_dstc_exca_mtt__plno;
	}
	public void setTrv_dstc_exca_mtt__plno(String trv_dstc_exca_mtt__plno) {
		this.trv_dstc_exca_mtt__plno = trv_dstc_exca_mtt__plno;
	}
	public String getTrv_dstc_exca_mtt__plan_no() {
		return trv_dstc_exca_mtt__plan_no;
	}
	public void setTrv_dstc_exca_mtt__plan_no(String trv_dstc_exca_mtt__plan_no) {
		this.trv_dstc_exca_mtt__plan_no = trv_dstc_exca_mtt__plan_no;
	}
	public String getTrv_dstc_exca_mtt__plan_dt() {
		return trv_dstc_exca_mtt__plan_dt;
	}
	public void setTrv_dstc_exca_mtt__plan_dt(String trv_dstc_exca_mtt__plan_dt) {
		this.trv_dstc_exca_mtt__plan_dt = trv_dstc_exca_mtt__plan_dt;
	}
	public String getTrv_dstc_exca_mtt__exca_rtrn_dvn() {
		return trv_dstc_exca_mtt__exca_rtrn_dvn;
	}
	public void setTrv_dstc_exca_mtt__exca_rtrn_dvn(String trv_dstc_exca_mtt__exca_rtrn_dvn) {
		this.trv_dstc_exca_mtt__exca_rtrn_dvn = trv_dstc_exca_mtt__exca_rtrn_dvn;
	}
	public String getTrv_dstc_exca_mtt__bank_cd() {
		return trv_dstc_exca_mtt__bank_cd;
	}
	public void setTrv_dstc_exca_mtt__bank_cd(String trv_dstc_exca_mtt__bank_cd) {
		this.trv_dstc_exca_mtt__bank_cd = trv_dstc_exca_mtt__bank_cd;
	}
	public String getTrv_dstc_exca_mtt__acc_no() {
		return trv_dstc_exca_mtt__acc_no;
	}
	public void setTrv_dstc_exca_mtt__acc_no(String trv_dstc_exca_mtt__acc_no) {
		this.trv_dstc_exca_mtt__acc_no = trv_dstc_exca_mtt__acc_no;
	}
	public String getTrv_dstc_exca_mtt__adc_rtrn_dvn() {
		return trv_dstc_exca_mtt__adc_rtrn_dvn;
	}
	public void setTrv_dstc_exca_mtt__adc_rtrn_dvn(String trv_dstc_exca_mtt__adc_rtrn_dvn) {
		this.trv_dstc_exca_mtt__adc_rtrn_dvn = trv_dstc_exca_mtt__adc_rtrn_dvn;
	}
	public String getTrv_dstc_exca_mtt__adc_rtrn_prm() {
		return trv_dstc_exca_mtt__adc_rtrn_prm;
	}
	public void setTrv_dstc_exca_mtt__adc_rtrn_prm(String trv_dstc_exca_mtt__adc_rtrn_prm) {
		this.trv_dstc_exca_mtt__adc_rtrn_prm = trv_dstc_exca_mtt__adc_rtrn_prm;
	}
	public String getTrv_dstc_exca_mtt__cnv_trv_dstc() {
		return trv_dstc_exca_mtt__cnv_trv_dstc;
	}
	public void setTrv_dstc_exca_mtt__cnv_trv_dstc(String trv_dstc_exca_mtt__cnv_trv_dstc) {
		this.trv_dstc_exca_mtt__cnv_trv_dstc = trv_dstc_exca_mtt__cnv_trv_dstc;
	}
	public String getTrv_dstc_exca_mtt__nrm_proc_yn() {
		return trv_dstc_exca_mtt__nrm_proc_yn;
	}
	public void setTrv_dstc_exca_mtt__nrm_proc_yn(String trv_dstc_exca_mtt__nrm_proc_yn) {
		this.trv_dstc_exca_mtt__nrm_proc_yn = trv_dstc_exca_mtt__nrm_proc_yn;
	}
	public String getTrv_dstc_exca_mtt__aut_cgnt_vh_no_eqal_yn() {
		return trv_dstc_exca_mtt__aut_cgnt_vh_no_eqal_yn;
	}
	public void setTrv_dstc_exca_mtt__aut_cgnt_vh_no_eqal_yn(String trv_dstc_exca_mtt__aut_cgnt_vh_no_eqal_yn) {
		this.trv_dstc_exca_mtt__aut_cgnt_vh_no_eqal_yn = trv_dstc_exca_mtt__aut_cgnt_vh_no_eqal_yn;
	}
	public String getTrv_dstc_exca_mtt__aut_cgnt_trv_dstc_eqal_yn() {
		return trv_dstc_exca_mtt__aut_cgnt_trv_dstc_eqal_yn;
	}
	public void setTrv_dstc_exca_mtt__aut_cgnt_trv_dstc_eqal_yn(String trv_dstc_exca_mtt__aut_cgnt_trv_dstc_eqal_yn) {
		this.trv_dstc_exca_mtt__aut_cgnt_trv_dstc_eqal_yn = trv_dstc_exca_mtt__aut_cgnt_trv_dstc_eqal_yn;
	}
	public String getTrv_dstc_exca_mtt__rnw_plno() {
		return trv_dstc_exca_mtt__rnw_plno;
	}
	public void setTrv_dstc_exca_mtt__rnw_plno(String trv_dstc_exca_mtt__rnw_plno) {
		this.trv_dstc_exca_mtt__rnw_plno = trv_dstc_exca_mtt__rnw_plno;
	}
	public String getTrv_dstc_exca_mtt__hdlr_empno() {
		return trv_dstc_exca_mtt__hdlr_empno;
	}
	public void setTrv_dstc_exca_mtt__hdlr_empno(String trv_dstc_exca_mtt__hdlr_empno) {
		this.trv_dstc_exca_mtt__hdlr_empno = trv_dstc_exca_mtt__hdlr_empno;
	}
	public String getTrv_dstc_exca_mtt__aut_cgnt_trv_dstc_rsl_cd() {
		return trv_dstc_exca_mtt__aut_cgnt_trv_dstc_rsl_cd;
	}
	public void setTrv_dstc_exca_mtt__aut_cgnt_trv_dstc_rsl_cd(String trv_dstc_exca_mtt__aut_cgnt_trv_dstc_rsl_cd) {
		this.trv_dstc_exca_mtt__aut_cgnt_trv_dstc_rsl_cd = trv_dstc_exca_mtt__aut_cgnt_trv_dstc_rsl_cd;
	}
	public String getTrv_dstc_exca_mtt__plhd_cust_nm() {
		return trv_dstc_exca_mtt__plhd_cust_nm;
	}
	public void setTrv_dstc_exca_mtt__plhd_cust_nm(String trv_dstc_exca_mtt__plhd_cust_nm) {
		this.trv_dstc_exca_mtt__plhd_cust_nm = trv_dstc_exca_mtt__plhd_cust_nm;
	}
	public String getTrv_dstc_exca_mtt__pdc_sr_dvn() {
		return trv_dstc_exca_mtt__pdc_sr_dvn;
	}
	public void setTrv_dstc_exca_mtt__pdc_sr_dvn(String trv_dstc_exca_mtt__pdc_sr_dvn) {
		this.trv_dstc_exca_mtt__pdc_sr_dvn = trv_dstc_exca_mtt__pdc_sr_dvn;
	}
	public String getTrv_dstc_exca_mtt__scrn_proc_cd() {
		return trv_dstc_exca_mtt__scrn_proc_cd;
	}
	public void setTrv_dstc_exca_mtt__scrn_proc_cd(String trv_dstc_exca_mtt__scrn_proc_cd) {
		this.trv_dstc_exca_mtt__scrn_proc_cd = trv_dstc_exca_mtt__scrn_proc_cd;
	}
	public String getTrv_dstc_exca_mtt__arc_trm_str_dt() {
		return trv_dstc_exca_mtt__arc_trm_str_dt;
	}
	public void setTrv_dstc_exca_mtt__arc_trm_str_dt(String trv_dstc_exca_mtt__arc_trm_str_dt) {
		this.trv_dstc_exca_mtt__arc_trm_str_dt = trv_dstc_exca_mtt__arc_trm_str_dt;
	}
	public String getTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn() {
		return trv_dstc_exca_mtt__trv_dstc_splc_exca_yn;
	}
	public void setTrv_dstc_exca_mtt__trv_dstc_splc_exca_yn(String trv_dstc_exca_mtt__trv_dstc_splc_exca_yn) {
		this.trv_dstc_exca_mtt__trv_dstc_splc_exca_yn = trv_dstc_exca_mtt__trv_dstc_splc_exca_yn;
	}
	public String getTrv_dstc_exca_mtt__pbox_no() {
		return trv_dstc_exca_mtt__pbox_no;
	}
	public void setTrv_dstc_exca_mtt__pbox_no(String trv_dstc_exca_mtt__pbox_no) {
		this.trv_dstc_exca_mtt__pbox_no = trv_dstc_exca_mtt__pbox_no;
	}
	public String getTrv_dstc_exca_mtt__imag_dup_yn() {
		return trv_dstc_exca_mtt__imag_dup_yn;
	}
	public void setTrv_dstc_exca_mtt__imag_dup_yn(String trv_dstc_exca_mtt__imag_dup_yn) {
		this.trv_dstc_exca_mtt__imag_dup_yn = trv_dstc_exca_mtt__imag_dup_yn;
	}
	public String getTrv_dstc_exca_mtt__rsl_cd() {
		return trv_dstc_exca_mtt__rsl_cd;
	}
	public void setTrv_dstc_exca_mtt__rsl_cd(String trv_dstc_exca_mtt__rsl_cd) {
		this.trv_dstc_exca_mtt__rsl_cd = trv_dstc_exca_mtt__rsl_cd;
	}
	public String getTrv_dstc_exca_mtt__rsl_msg() {
		return trv_dstc_exca_mtt__rsl_msg;
	}
	public void setTrv_dstc_exca_mtt__rsl_msg(String trv_dstc_exca_mtt__rsl_msg) {
		this.trv_dstc_exca_mtt__rsl_msg = trv_dstc_exca_mtt__rsl_msg;
	}
	public String getTrv_dstc_exca_mtt__crd_scn_cncl_pss_yn() {
		return trv_dstc_exca_mtt__crd_scn_cncl_pss_yn;
	}
	public void setTrv_dstc_exca_mtt__crd_scn_cncl_pss_yn(String trv_dstc_exca_mtt__crd_scn_cncl_pss_yn) {
		this.trv_dstc_exca_mtt__crd_scn_cncl_pss_yn = trv_dstc_exca_mtt__crd_scn_cncl_pss_yn;
	}
	public String getTrv_dstc_exca_mtt__stlm_cdcp_nm() {
		return trv_dstc_exca_mtt__stlm_cdcp_nm;
	}
	public void setTrv_dstc_exca_mtt__stlm_cdcp_nm(String trv_dstc_exca_mtt__stlm_cdcp_nm) {
		this.trv_dstc_exca_mtt__stlm_cdcp_nm = trv_dstc_exca_mtt__stlm_cdcp_nm;
	}
	public String getTrv_dstc_exca_mtt__stlm_crd_no() {
		return trv_dstc_exca_mtt__stlm_crd_no;
	}
	public void setTrv_dstc_exca_mtt__stlm_crd_no(String trv_dstc_exca_mtt__stlm_crd_no) {
		this.trv_dstc_exca_mtt__stlm_crd_no = trv_dstc_exca_mtt__stlm_crd_no;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getZ_resp_msg() {
		return z_resp_msg;
	}
	public void setZ_resp_msg(String z_resp_msg) {
		this.z_resp_msg = z_resp_msg;
	}
	public String getZ_resp_cd() {
		return z_resp_cd;
	}
	public void setZ_resp_cd(String z_resp_cd) {
		this.z_resp_cd = z_resp_cd;
	}
	public String getZ_tlg_sp_cd() {
		return z_tlg_sp_cd;
	}
	public void setZ_tlg_sp_cd(String z_tlg_sp_cd) {
		this.z_tlg_sp_cd = z_tlg_sp_cd;
	}
	public String getZ_trns_org_cd() {
		return z_trns_org_cd;
	}
	public void setZ_trns_org_cd(String z_trns_org_cd) {
		this.z_trns_org_cd = z_trns_org_cd;
	}
	public String getZ_trns_org_dvcd() {
		return z_trns_org_dvcd;
	}
	public void setZ_trns_org_dvcd(String z_trns_org_dvcd) {
		this.z_trns_org_dvcd = z_trns_org_dvcd;
	}
	public String getZ_trsc_id() {
		return z_trsc_id;
	}
	public void setZ_trsc_id(String z_trsc_id) {
		this.z_trsc_id = z_trsc_id;
	}
	
}
