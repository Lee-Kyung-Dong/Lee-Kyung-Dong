package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class CCLM0066VO extends CMMVO{
	//전문필드
		public String msg_cd = "";  //[I/O] 메세지코드 LK-MSG-CD2 메세지코드2
		public String msg = "";  //[I/O] 메시지 H-LK-MESSAGE2 메시지2
		public String pat_dvn_1 = "";  //[I/O] 파트구분1 LK-PART-GB1 파트구분1
		public String pat_dvn_2 = "";  //[I/O] 파트구분2 LK-PART-GB2 파트구분2
		public String bz_dvn_1 = "";  //[I/O] 업무구분1 LK-UPMU-CD1 업무구분1
		public String bz_dvn_2 = "";  //[I/O] 업무구분2 LK-UPMU-CD2 업무구분2
		public String bz_dvn_3 = "";  //[I/O] 업무구분3 LK-UPMU-CD3 업무구분3
		public String accd_rpt_no = "";  //[I/O] 사고접수번호          LK-I-SAGO-NO 사고접수번호         
		public String[] clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_vtm_if__cvr_nm = new String[0];  //[I/O] 보상OneClick서비스진행사항조회_피해자정보_담보명 LK-I-DAMBO-NM 담보명
		public String[] clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_vtm_if__accd_oj_sqno = new String[0];  //[I/O] 보상OneClick서비스진행사항조회_피해자정보_사고목적일련번호  LK-I-MOKJUK-SEQ 사고목적일련번호 
		public String[] clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_vtm_if__vtm_nm = new String[0];  //[I/O] 보상OneClick서비스진행사항조회_피해자정보_피해자명 LK-I-PIHEJA-NM 피해자명
		public String[] clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_vtm_if__hosp_nm = new String[0];  //[I/O] 보상OneClick서비스진행사항조회_피해자정보_병원명 LK-I-HOSPITAL-NM 병원명
		public String[] clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_vtm_if__wnd_dvn = new String[0];  //[I/O] 보상OneClick서비스진행사항조회_피해자정보_부상구분 LK-I-BUSANG-GB 부상구분
		public String[] clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_vtm_if__mngt_ed_typ_cd_nm = new String[0];  //[I/O] 보상OneClick서비스진행사항조회_피해자정보_관리종결유형코드명 LK-I-JINHENG-GB 진행구분
		public String[] clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_vtm_if__ds_bnf = new String[0];  //[I/O] 보상OneClick서비스진행사항조회_피해자정보_결정보험금 LK-I-PL-AMT 결정보험금
		public String[] clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_vtm_if__psic_nm = new String[0];  //[I/O] 보상OneClick서비스진행사항조회_피해자정보_담당자명 LK-I-DAMDANGJA 담당자명
		public String[] clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_vtm_if__tlno = new String[0];  //[I/O] 보상OneClick서비스진행사항조회_피해자정보_전화번호 LK-I-TEL-NO 전화번호
		public String[] clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_dmit_if__cvr_nm = new String[0];  //[I/O] 보상OneClick서비스진행사항조회_피해물정보_담보명 LK-M-DAMBO-NM 담보명
		public String[] clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_dmit_if__accd_oj_sqno = new String[0];  //[I/O] 보상OneClick서비스진행사항조회_피해물정보_사고목적일련번호  LK-M-MOKJUK-SEQ 사고목적일련번호 
		public String[] clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_dmit_if__vtm_nm = new String[0];  //[I/O] 보상OneClick서비스진행사항조회_피해물정보_피해자명 LK-M-PIHEMUL-NM 피해자명
		public String[] clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_dmit_if__hosp_nm = new String[0];  //[I/O] 보상OneClick서비스진행사항조회_피해물정보_병원명 LK-M-SURICHEO-NM 병원명
		public String[] clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_dmit_if__wnd_dvn = new String[0];  //[I/O] 보상OneClick서비스진행사항조회_피해물정보_부상구분 LK-M-SONHE-JUNGDO-NM 부상구분
		public String[] clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_dmit_if__accd_prg_crs_cd_nm = new String[0];  //[I/O] 보상OneClick서비스진행사항조회_피해물정보_사고진행과정코드명 LK-M-JINHENG-GB 진행구분
		public String[] clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_dmit_if__ds_bnf = new String[0];  //[I/O] 보상OneClick서비스진행사항조회_피해물정보_결정보험금 LK-M-PL-AMT 결정보험금
		public String[] clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_dmit_if__psic_nm = new String[0];  //[I/O] 보상OneClick서비스진행사항조회_피해물정보_담당자명 LK-M-DAMDANGJA 담당자명
		public String[] clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_dmit_if__tlno = new String[0];  //[I/O] 보상OneClick서비스진행사항조회_피해물정보_전화번호 LK-M-TEL-NO 전화번호
		public String errorCode = ""; 
		
		
		public String getErrorCode() {
			return errorCode;
		}
		public void setErrorCode(String errorCode) {
			this.errorCode = errorCode;
		}
		public String getMsg_cd() {
			return msg_cd;
		}
		public void setMsg_cd(String msg_cd) {
			this.msg_cd = msg_cd;
		}
		public String getMsg() {
			return msg;
		}
		public void setMsg(String msg) {
			this.msg = msg;
		}
		public String getPat_dvn_1() {
			return pat_dvn_1;
		}
		public void setPat_dvn_1(String pat_dvn_1) {
			this.pat_dvn_1 = pat_dvn_1;
		}
		public String getPat_dvn_2() {
			return pat_dvn_2;
		}
		public void setPat_dvn_2(String pat_dvn_2) {
			this.pat_dvn_2 = pat_dvn_2;
		}
		public String getBz_dvn_1() {
			return bz_dvn_1;
		}
		public void setBz_dvn_1(String bz_dvn_1) {
			this.bz_dvn_1 = bz_dvn_1;
		}
		public String getBz_dvn_2() {
			return bz_dvn_2;
		}
		public void setBz_dvn_2(String bz_dvn_2) {
			this.bz_dvn_2 = bz_dvn_2;
		}
		public String getBz_dvn_3() {
			return bz_dvn_3;
		}
		public void setBz_dvn_3(String bz_dvn_3) {
			this.bz_dvn_3 = bz_dvn_3;
		}
		public String getAccd_rpt_no() {
			return accd_rpt_no;
		}
		public void setAccd_rpt_no(String accd_rpt_no) {
			this.accd_rpt_no = accd_rpt_no;
		}
		public String[] getClam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_vtm_if__cvr_nm() {
			return clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_vtm_if__cvr_nm;
		}
		public void setClam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_vtm_if__cvr_nm(
				String[] clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_vtm_if__cvr_nm) {
			this.clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_vtm_if__cvr_nm = clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_vtm_if__cvr_nm;
		}
		public String[] getClam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_vtm_if__accd_oj_sqno() {
			return clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_vtm_if__accd_oj_sqno;
		}
		public void setClam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_vtm_if__accd_oj_sqno(
				String[] clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_vtm_if__accd_oj_sqno) {
			this.clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_vtm_if__accd_oj_sqno = clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_vtm_if__accd_oj_sqno;
		}
		public String[] getClam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_vtm_if__vtm_nm() {
			return clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_vtm_if__vtm_nm;
		}
		public void setClam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_vtm_if__vtm_nm(
				String[] clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_vtm_if__vtm_nm) {
			this.clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_vtm_if__vtm_nm = clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_vtm_if__vtm_nm;
		}
		public String[] getClam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_vtm_if__hosp_nm() {
			return clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_vtm_if__hosp_nm;
		}
		public void setClam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_vtm_if__hosp_nm(
				String[] clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_vtm_if__hosp_nm) {
			this.clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_vtm_if__hosp_nm = clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_vtm_if__hosp_nm;
		}
		public String[] getClam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_vtm_if__wnd_dvn() {
			return clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_vtm_if__wnd_dvn;
		}
		public void setClam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_vtm_if__wnd_dvn(
				String[] clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_vtm_if__wnd_dvn) {
			this.clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_vtm_if__wnd_dvn = clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_vtm_if__wnd_dvn;
		}
		public String[] getClam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_vtm_if__mngt_ed_typ_cd_nm() {
			return clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_vtm_if__mngt_ed_typ_cd_nm;
		}
		public void setClam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_vtm_if__mngt_ed_typ_cd_nm(
				String[] clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_vtm_if__mngt_ed_typ_cd_nm) {
			this.clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_vtm_if__mngt_ed_typ_cd_nm = clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_vtm_if__mngt_ed_typ_cd_nm;
		}
		public String[] getClam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_vtm_if__ds_bnf() {
			return clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_vtm_if__ds_bnf;
		}
		public void setClam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_vtm_if__ds_bnf(
				String[] clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_vtm_if__ds_bnf) {
			this.clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_vtm_if__ds_bnf = clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_vtm_if__ds_bnf;
		}
		public String[] getClam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_vtm_if__psic_nm() {
			return clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_vtm_if__psic_nm;
		}
		public void setClam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_vtm_if__psic_nm(
				String[] clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_vtm_if__psic_nm) {
			this.clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_vtm_if__psic_nm = clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_vtm_if__psic_nm;
		}
		public String[] getClam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_vtm_if__tlno() {
			return clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_vtm_if__tlno;
		}
		public void setClam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_vtm_if__tlno(
				String[] clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_vtm_if__tlno) {
			this.clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_vtm_if__tlno = clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_vtm_if__tlno;
		}
		public String[] getClam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_dmit_if__cvr_nm() {
			return clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_dmit_if__cvr_nm;
		}
		public void setClam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_dmit_if__cvr_nm(
				String[] clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_dmit_if__cvr_nm) {
			this.clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_dmit_if__cvr_nm = clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_dmit_if__cvr_nm;
		}
		public String[] getClam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_dmit_if__accd_oj_sqno() {
			return clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_dmit_if__accd_oj_sqno;
		}
		public void setClam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_dmit_if__accd_oj_sqno(
				String[] clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_dmit_if__accd_oj_sqno) {
			this.clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_dmit_if__accd_oj_sqno = clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_dmit_if__accd_oj_sqno;
		}
		public String[] getClam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_dmit_if__vtm_nm() {
			return clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_dmit_if__vtm_nm;
		}
		public void setClam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_dmit_if__vtm_nm(
				String[] clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_dmit_if__vtm_nm) {
			this.clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_dmit_if__vtm_nm = clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_dmit_if__vtm_nm;
		}
		public String[] getClam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_dmit_if__hosp_nm() {
			return clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_dmit_if__hosp_nm;
		}
		public void setClam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_dmit_if__hosp_nm(
				String[] clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_dmit_if__hosp_nm) {
			this.clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_dmit_if__hosp_nm = clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_dmit_if__hosp_nm;
		}
		public String[] getClam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_dmit_if__wnd_dvn() {
			return clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_dmit_if__wnd_dvn;
		}
		public void setClam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_dmit_if__wnd_dvn(
				String[] clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_dmit_if__wnd_dvn) {
			this.clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_dmit_if__wnd_dvn = clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_dmit_if__wnd_dvn;
		}
		public String[] getClam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_dmit_if__accd_prg_crs_cd_nm() {
			return clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_dmit_if__accd_prg_crs_cd_nm;
		}
		public void setClam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_dmit_if__accd_prg_crs_cd_nm(
				String[] clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_dmit_if__accd_prg_crs_cd_nm) {
			this.clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_dmit_if__accd_prg_crs_cd_nm = clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_dmit_if__accd_prg_crs_cd_nm;
		}
		public String[] getClam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_dmit_if__ds_bnf() {
			return clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_dmit_if__ds_bnf;
		}
		public void setClam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_dmit_if__ds_bnf(
				String[] clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_dmit_if__ds_bnf) {
			this.clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_dmit_if__ds_bnf = clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_dmit_if__ds_bnf;
		}
		public String[] getClam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_dmit_if__psic_nm() {
			return clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_dmit_if__psic_nm;
		}
		public void setClam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_dmit_if__psic_nm(
				String[] clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_dmit_if__psic_nm) {
			this.clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_dmit_if__psic_nm = clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_dmit_if__psic_nm;
		}
		public String[] getClam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_dmit_if__tlno() {
			return clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_dmit_if__tlno;
		}
		public void setClam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_dmit_if__tlno(
				String[] clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_dmit_if__tlno) {
			this.clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_dmit_if__tlno = clam_o_n_e_c_l_i_c_k_srv_prg_mtt_srch_dmit_if__tlno;
		}
		
		
}
