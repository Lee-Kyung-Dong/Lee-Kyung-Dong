package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class LLTI0272VO extends CMMVO {

	//전문필드
		public String proc_dvcd = "";  //[I] 처리구분코드 CC-PROC-GB 처리구분
		public String proc_gb = "";  //[I] 처리구분코드 CC-PROC-GB 처리구분
		public String plhd_rsdn_no = "";  //[O] 계약자주민번호 JJ-GYEYAKJA-NO 계약자주민번호
		public String dvcd = "";  //[I/O] 구분코드 JJ-GUBUN 구분코드
		public String rpmn_proc_ep_cd = "";  //[I] 입금처리 사원코드 JJ-IPGMJA 입금처리 사원코드
		public String rpmn_dlmn_bh_cd = "";  //[I/O] 입금처리자 지점코드 JJ-IPGMJA-JIJUM 입금처리자 지점코드
		public String rpmn_dlmn_brn_cd = "";  //[I/O] 입금처리자 지부코드 JJ-IPGMJA-JIBU 입금처리자 지부코드
		public String act_proc_dd = "";  //[I/O] 회계처리일 JJ-HOIGE-CHEORIIL 회계처리일
		public String rpmn_dd = "";  //[I/O] 입금일 JJ-IPGMIL 입금일
		public String plno_1 = "";  //[I] 증권번호1 JJ-POLI-NO 증권번호
		public String pdc_cd_1 = "";  //[O] 상품코드1  
		public String ins_pcpl_dvcd = "";  //[O] 피보험자소재지구분코드  
		public String ply_sqno = "";  //[O] 증권일련번호  
		public String orr = "";  //[I/O] 회차 JJ-HOIBUN 회차
		public String pym_mthl = "";  //[O] 납입월도 JJ-FROM-WOLDO 납입월도
		public String inpt_ret = "";  //[O] 입력회분 JJ-FROM-HOI 입력회분
		public String last_pym_mthl = "";  //[O] 마지막납입월도 JJ-TO-WOLDO 납입월도 TO
		public String inpt_ret_af = "";  //[O] 입력회분후 JJ-TO-HOI 입력회분 후
		public String plhd_nm = "";  //[O] 계약자명 HJ-GYEYAKJA-NAME 계약자명
		public String ins_nm = "";  //[O] 피보험자명 HJ-PIBOJA-NAME 피보험자명
		public String clmn_nm = "";  //[O] 수금자명 HJ-SUGMJA-NAME 수금자 명
		public String coll_bh_cd = "";  //[O] 수금지점코드 JJ-SUGMJA-JIJUM 수금지점코드
		public String coll_brn_cd = "";  //[O] 수금지부코드 JJ-SUGMJA-JIBU 수금지부코드
		public String coll_ormm_cd = "";  //[O] 수금조직원코드 JJ-SUGMJA-CD 수금조직원코드
		public String fnal_pym_mon = "";  //[O] 최종납입월 JJ-LAST-WOLDO 최종납입월
		public String fnal_pym_nts = "";  //[O] 최종납입횟수 JJ-LAST-HOI 최종납입횟수
		public String pym_mtd_nm = "";  //[O] 납입방법 명 HJ-NAPIP-BANGBUP 납입방법 명
		public String appr_mthl = "";  //[O] 인정월도 JJ-INJUNG-WOLDO 인정월도
		public String mst_dvn_nm = "";  //[O] 착오구분명 HJ-CHAKO-GUBUN 착오구분명
		public String mst_prm = "";  //[O] 착오보험료 JJ-CHAKO-PRM 착오보험료
		public String lbl_dvn_nm = "";  //[O] 책임구분명 HJ-CHEKIM-GUBUN 책임구분명
		public String lbl_rf = "";  //[O] 책임준비금 JJ-CHEKIM-JUNBIGM 책임준비금
		public String ctc_stat_nm = "";  //[O] 계약상태 명 HJ-SANGTE-NAME 계약상태 명
		public String ctc_stat_chng_dd = "";  //[O] 계약상태 변경일 JJ-SANGTE-YMD 계약상태 변경일
		public String[] rpmn_if__ctc_stat_dvn_nm = new String[0];  //[O] 입금사항정보_계약상태구분명 HJ-ITEM-GUBUN 계약상태구분명
		public String[] rpmn_if__pym_nts = new String[0];  //[O] 입금사항정보_납입횟수 JJ-HOICHA 납입횟수
		public String[] rpmn_if__pym_mthl = new String[0];  //[O] 입금사항정보_납입월도 JJ-NAPIP-WOLDO 납입월도
		public String[] rpmn_if__cltd_prm = new String[0];  //[O] 입금사항정보_영수보험료 JJ-BATUL-GMEK 받을보험료
		public String[] rpmn_if__nrm_prm = new String[0];  //[O] 입금사항정보_정상보험료 JJ-JUNGSANG-PRM 정상보험료
		public String[] rpmn_if__ppy_dst = new String[0];  //[O] 입금사항정보_선납할인 JJ-SUNNAP-HALIN 선납할인
		public String wh_amt = "";  //[I/O] 전체금액 JJ-TOT-BATUL-GMEK 전체 받을 금액
		public String wh_ppy_dst = "";  //[O] 전체선납할인 JJ-TOT-SUNNAP-HALIN 전체 선납할인
		public String wh_rnst_inte = "";  //[O] 전체부활이자 JJ-TOT-BUHWAL-IJA 전체 부활이자
		public String recp_no = "";  //[I/O] 영수증번호 JJ-YUNGSUJNG-1 영수증번호
		public String cltd_amt = "";  //[I/O] 영수금액 JJ-YUNGSUGMEK-1 영수금액
		public String mntp_cd = "";  //[I/O] 금종코드 JJ-GMJONG-1 금종코드
		public String bank_cd = "";  //[I/O] 은행코드 JJ-BANK-CD 은행코드
		public String bank_nm = "";  //[I/O] 은행명 HJ-BANK-NM 은행명
		public String acc_no = "";  //[I/O] 계좌번호 JJ-GYEJWA-NO 계좌번호
		public String rmk = "";  //[O] 비고 HJ-REMARK 리마크
		public String plno_2 = "";  //[I/O] 증권번호2 UU-POLI-NO 증권번호
		public String pdc_cd_2 = "";  //[O] 상품코드2  
		public String tlno_1 = "";  //[I/O] 전화번호1 JJ-PHONE-NO1 전화번호1
		public String tlno_2 = "";  //[I/O] 전화번호2 JJ-PHONE-NO2 전화번호2
		public String tlno_3 = "";  //[I/O] 전화번호3 JJ-PHONE-NO3 전화번호3
		public String rrno = "";  //[I/O] 주민등록번호 JJ-CUST-NO 고객주민번호
		public String cust_nm = "";  //[I/O] 고객명 HJ-CUST-NAME 고객명
		public String sms_cn = "";  //[I/O] SMS내용 JJ-SMS-CONT SMS내용
		public String errorCode = "";  //
//		public String returnMessage = "";  //
		public String z_resp_msg = "";  //
		public String z_msg_cd = "";  //
		
		
		
		
		public String getZ_resp_msg() {
			return z_resp_msg;
		}
		public void setZ_resp_msg(String z_resp_msg) {
			this.z_resp_msg = z_resp_msg;
		}
		public String getZ_msg_cd() {
			return z_msg_cd;
		}
		public void setZ_msg_cd(String z_msg_cd) {
			this.z_msg_cd = z_msg_cd;
		}
		public String getErrorCode() {
			return errorCode;
		}
		public void setErrorCode(String errorCode) {
			this.errorCode = errorCode;
		}
		public String getProc_gb() {
			return proc_gb;
		}
		public void setProc_gb(String proc_gb) {
			this.proc_gb = proc_gb;
		}
		public String getProc_dvcd() {
			return proc_dvcd;
		}
		public void setProc_dvcd(String proc_dvcd) {
			this.proc_dvcd = proc_dvcd;
		}
		public String getPlhd_rsdn_no() {
			return plhd_rsdn_no;
		}
		public void setPlhd_rsdn_no(String plhd_rsdn_no) {
			this.plhd_rsdn_no = plhd_rsdn_no;
		}
		public String getDvcd() {
			return dvcd;
		}
		public void setDvcd(String dvcd) {
			this.dvcd = dvcd;
		}
		public String getRpmn_proc_ep_cd() {
			return rpmn_proc_ep_cd;
		}
		public void setRpmn_proc_ep_cd(String rpmn_proc_ep_cd) {
			this.rpmn_proc_ep_cd = rpmn_proc_ep_cd;
		}
		public String getRpmn_dlmn_bh_cd() {
			return rpmn_dlmn_bh_cd;
		}
		public void setRpmn_dlmn_bh_cd(String rpmn_dlmn_bh_cd) {
			this.rpmn_dlmn_bh_cd = rpmn_dlmn_bh_cd;
		}
		public String getRpmn_dlmn_brn_cd() {
			return rpmn_dlmn_brn_cd;
		}
		public void setRpmn_dlmn_brn_cd(String rpmn_dlmn_brn_cd) {
			this.rpmn_dlmn_brn_cd = rpmn_dlmn_brn_cd;
		}
		public String getAct_proc_dd() {
			return act_proc_dd;
		}
		public void setAct_proc_dd(String act_proc_dd) {
			this.act_proc_dd = act_proc_dd;
		}
		public String getRpmn_dd() {
			return rpmn_dd;
		}
		public void setRpmn_dd(String rpmn_dd) {
			this.rpmn_dd = rpmn_dd;
		}
		public String getPlno_1() {
			return plno_1;
		}
		public void setPlno_1(String plno_1) {
			this.plno_1 = plno_1;
		}
		public String getPdc_cd_1() {
			return pdc_cd_1;
		}
		public void setPdc_cd_1(String pdc_cd_1) {
			this.pdc_cd_1 = pdc_cd_1;
		}
		public String getIns_pcpl_dvcd() {
			return ins_pcpl_dvcd;
		}
		public void setIns_pcpl_dvcd(String ins_pcpl_dvcd) {
			this.ins_pcpl_dvcd = ins_pcpl_dvcd;
		}
		public String getPly_sqno() {
			return ply_sqno;
		}
		public void setPly_sqno(String ply_sqno) {
			this.ply_sqno = ply_sqno;
		}
		public String getOrr() {
			return orr;
		}
		public void setOrr(String orr) {
			this.orr = orr;
		}
		public String getPym_mthl() {
			return pym_mthl;
		}
		public void setPym_mthl(String pym_mthl) {
			this.pym_mthl = pym_mthl;
		}
		public String getInpt_ret() {
			return inpt_ret;
		}
		public void setInpt_ret(String inpt_ret) {
			this.inpt_ret = inpt_ret;
		}
		public String getLast_pym_mthl() {
			return last_pym_mthl;
		}
		public void setLast_pym_mthl(String last_pym_mthl) {
			this.last_pym_mthl = last_pym_mthl;
		}
		public String getInpt_ret_af() {
			return inpt_ret_af;
		}
		public void setInpt_ret_af(String inpt_ret_af) {
			this.inpt_ret_af = inpt_ret_af;
		}
		public String getPlhd_nm() {
			return plhd_nm;
		}
		public void setPlhd_nm(String plhd_nm) {
			this.plhd_nm = plhd_nm;
		}
		public String getIns_nm() {
			return ins_nm;
		}
		public void setIns_nm(String ins_nm) {
			this.ins_nm = ins_nm;
		}
		public String getClmn_nm() {
			return clmn_nm;
		}
		public void setClmn_nm(String clmn_nm) {
			this.clmn_nm = clmn_nm;
		}
		public String getColl_bh_cd() {
			return coll_bh_cd;
		}
		public void setColl_bh_cd(String coll_bh_cd) {
			this.coll_bh_cd = coll_bh_cd;
		}
		public String getColl_brn_cd() {
			return coll_brn_cd;
		}
		public void setColl_brn_cd(String coll_brn_cd) {
			this.coll_brn_cd = coll_brn_cd;
		}
		public String getColl_ormm_cd() {
			return coll_ormm_cd;
		}
		public void setColl_ormm_cd(String coll_ormm_cd) {
			this.coll_ormm_cd = coll_ormm_cd;
		}
		public String getFnal_pym_mon() {
			return fnal_pym_mon;
		}
		public void setFnal_pym_mon(String fnal_pym_mon) {
			this.fnal_pym_mon = fnal_pym_mon;
		}
		public String getFnal_pym_nts() {
			return fnal_pym_nts;
		}
		public void setFnal_pym_nts(String fnal_pym_nts) {
			this.fnal_pym_nts = fnal_pym_nts;
		}
		public String getPym_mtd_nm() {
			return pym_mtd_nm;
		}
		public void setPym_mtd_nm(String pym_mtd_nm) {
			this.pym_mtd_nm = pym_mtd_nm;
		}
		public String getAppr_mthl() {
			return appr_mthl;
		}
		public void setAppr_mthl(String appr_mthl) {
			this.appr_mthl = appr_mthl;
		}
		public String getMst_dvn_nm() {
			return mst_dvn_nm;
		}
		public void setMst_dvn_nm(String mst_dvn_nm) {
			this.mst_dvn_nm = mst_dvn_nm;
		}
		public String getMst_prm() {
			return mst_prm;
		}
		public void setMst_prm(String mst_prm) {
			this.mst_prm = mst_prm;
		}
		public String getLbl_dvn_nm() {
			return lbl_dvn_nm;
		}
		public void setLbl_dvn_nm(String lbl_dvn_nm) {
			this.lbl_dvn_nm = lbl_dvn_nm;
		}
		public String getLbl_rf() {
			return lbl_rf;
		}
		public void setLbl_rf(String lbl_rf) {
			this.lbl_rf = lbl_rf;
		}
		public String getCtc_stat_nm() {
			return ctc_stat_nm;
		}
		public void setCtc_stat_nm(String ctc_stat_nm) {
			this.ctc_stat_nm = ctc_stat_nm;
		}
		public String getCtc_stat_chng_dd() {
			return ctc_stat_chng_dd;
		}
		public void setCtc_stat_chng_dd(String ctc_stat_chng_dd) {
			this.ctc_stat_chng_dd = ctc_stat_chng_dd;
		}
		public String[] getRpmn_if__ctc_stat_dvn_nm() {
			return rpmn_if__ctc_stat_dvn_nm;
		}
		public void setRpmn_if__ctc_stat_dvn_nm(String[] rpmn_if__ctc_stat_dvn_nm) {
			this.rpmn_if__ctc_stat_dvn_nm = rpmn_if__ctc_stat_dvn_nm;
		}
		public String[] getRpmn_if__pym_nts() {
			return rpmn_if__pym_nts;
		}
		public void setRpmn_if__pym_nts(String[] rpmn_if__pym_nts) {
			this.rpmn_if__pym_nts = rpmn_if__pym_nts;
		}
		public String[] getRpmn_if__pym_mthl() {
			return rpmn_if__pym_mthl;
		}
		public void setRpmn_if__pym_mthl(String[] rpmn_if__pym_mthl) {
			this.rpmn_if__pym_mthl = rpmn_if__pym_mthl;
		}
		public String[] getRpmn_if__cltd_prm() {
			return rpmn_if__cltd_prm;
		}
		public void setRpmn_if__cltd_prm(String[] rpmn_if__cltd_prm) {
			this.rpmn_if__cltd_prm = rpmn_if__cltd_prm;
		}
		public String[] getRpmn_if__nrm_prm() {
			return rpmn_if__nrm_prm;
		}
		public void setRpmn_if__nrm_prm(String[] rpmn_if__nrm_prm) {
			this.rpmn_if__nrm_prm = rpmn_if__nrm_prm;
		}
		public String[] getRpmn_if__ppy_dst() {
			return rpmn_if__ppy_dst;
		}
		public void setRpmn_if__ppy_dst(String[] rpmn_if__ppy_dst) {
			this.rpmn_if__ppy_dst = rpmn_if__ppy_dst;
		}
		public String getWh_amt() {
			return wh_amt;
		}
		public void setWh_amt(String wh_amt) {
			this.wh_amt = wh_amt;
		}
		public String getWh_ppy_dst() {
			return wh_ppy_dst;
		}
		public void setWh_ppy_dst(String wh_ppy_dst) {
			this.wh_ppy_dst = wh_ppy_dst;
		}
		public String getWh_rnst_inte() {
			return wh_rnst_inte;
		}
		public void setWh_rnst_inte(String wh_rnst_inte) {
			this.wh_rnst_inte = wh_rnst_inte;
		}
		public String getRecp_no() {
			return recp_no;
		}
		public void setRecp_no(String recp_no) {
			this.recp_no = recp_no;
		}
		public String getCltd_amt() {
			return cltd_amt;
		}
		public void setCltd_amt(String cltd_amt) {
			this.cltd_amt = cltd_amt;
		}
		public String getMntp_cd() {
			return mntp_cd;
		}
		public void setMntp_cd(String mntp_cd) {
			this.mntp_cd = mntp_cd;
		}
		public String getBank_cd() {
			return bank_cd;
		}
		public void setBank_cd(String bank_cd) {
			this.bank_cd = bank_cd;
		}
		public String getBank_nm() {
			return bank_nm;
		}
		public void setBank_nm(String bank_nm) {
			this.bank_nm = bank_nm;
		}
		public String getAcc_no() {
			return acc_no;
		}
		public void setAcc_no(String acc_no) {
			this.acc_no = acc_no;
		}
		public String getRmk() {
			return rmk;
		}
		public void setRmk(String rmk) {
			this.rmk = rmk;
		}
		public String getPlno_2() {
			return plno_2;
		}
		public void setPlno_2(String plno_2) {
			this.plno_2 = plno_2;
		}
		public String getPdc_cd_2() {
			return pdc_cd_2;
		}
		public void setPdc_cd_2(String pdc_cd_2) {
			this.pdc_cd_2 = pdc_cd_2;
		}
		public String getTlno_1() {
			return tlno_1;
		}
		public void setTlno_1(String tlno_1) {
			this.tlno_1 = tlno_1;
		}
		public String getTlno_2() {
			return tlno_2;
		}
		public void setTlno_2(String tlno_2) {
			this.tlno_2 = tlno_2;
		}
		public String getTlno_3() {
			return tlno_3;
		}
		public void setTlno_3(String tlno_3) {
			this.tlno_3 = tlno_3;
		}
		public String getRrno() {
			return rrno;
		}
		public void setRrno(String rrno) {
			this.rrno = rrno;
		}
		public String getCust_nm() {
			return cust_nm;
		}
		public void setCust_nm(String cust_nm) {
			this.cust_nm = cust_nm;
		}
		public String getSms_cn() {
			return sms_cn;
		}
		public void setSms_cn(String sms_cn) {
			this.sms_cn = sms_cn;
		}
		
}
