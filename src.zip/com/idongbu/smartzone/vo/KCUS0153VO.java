package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class KCUS0153VO extends CMMVO {

	public String tlp_arno        		= ""; //전화지역번호
	public String tlp_ofno        		= ""; //전화국번호
	public String tlp_idvno       		= ""; //전화개별번호
	public String cust_hngl_nm    		= ""; //고객한글명
	public String cust_dcmt_no_brth    	= ""; //고객식별번호생년월일
	public String sx_cd        			= ""; //성별코드 (1:남자, 2:여자)
	
	public String hpg_prct_hdlr_lit_srch_lit__hdlr_empno[]        	= new String[0]; //취급자사원번호
	public String hpg_prct_hdlr_lit_srch_lit__hdlr_nm[]        		= new String[0]; //취급자명
	public String hpg_prct_hdlr_lit_srch_lit__agnc_mtu[]        	= new String[0]; //대리점상호
	public String hpg_prct_hdlr_lit_srch_lit__hdlr_clp_arno[]       = new String[0]; //취급자휴대폰지역번호
	public String hpg_prct_hdlr_lit_srch_lit__hdlr_clp_ofno[]       = new String[0]; //취급자휴대폰국번호
	public String hpg_prct_hdlr_lit_srch_lit__hdlr_clp_idvno[]      = new String[0]; //취급자휴대폰개별번호
	public String hpg_prct_hdlr_lit_srch_lit__hdlr_eml_adr[]        = new String[0]; //취급자이메일주소
	public String hpg_prct_hdlr_lit_srch_lit__bzlv_no[]        		= new String[0]; //사업단번호
	public String hpg_prct_hdlr_lit_srch_lit__bzlv_nm[]        		= new String[0]; //사업단명
	public String hpg_prct_hdlr_lit_srch_lit__bh_no[]        		= new String[0]; //지점번호
	public String hpg_prct_hdlr_lit_srch_lit__bh_nm[]        		= new String[0]; //지점명
	public String hpg_prct_hdlr_lit_srch_lit__hdqt_no[]        		= new String[0]; //본부번호
	public String hpg_prct_hdlr_lit_srch_lit__hdqt_nm[]        		= new String[0]; //본부명
	public String hpg_prct_hdlr_lit_srch_lit__bh_tlp_arno[]        	= new String[0]; //지점전화지역번호
	public String hpg_prct_hdlr_lit_srch_lit__bh_tlp_ofno[]        	= new String[0]; //지점전화국번호
	public String hpg_prct_hdlr_lit_srch_lit__bh_tlp_idvno[]        = new String[0]; //지점전화개별번호
	public String hpg_prct_hdlr_lit_srch_lit__brc_tlp_arno[]        = new String[0]; //출장소전화지역번호
	public String hpg_prct_hdlr_lit_srch_lit__brc_tlp_ofno[]        = new String[0]; //출장소전화국번호
	public String hpg_prct_hdlr_lit_srch_lit__brc_tlp_idvno[]       = new String[0]; //출장소전화개별번호
	public String hpg_prct_hdlr_lit_srch_lit__hdlr_tlp_arno[]       = new String[0]; //취급자전화지역번호
	public String hpg_prct_hdlr_lit_srch_lit__hdlr_tlp_ofno[]       = new String[0]; //취급자전화국번호
	public String hpg_prct_hdlr_lit_srch_lit__hdlr_tlp_idvno[]      = new String[0]; //취급자전화개별번호
	
	// 임시 시작
	public String errorCode;//에러코드
	public String z_msg_cd;//메시지 코드
	public String returnMessage;//메시지 내용
	
	public String getTlp_arno() {
		return tlp_arno;
	}
	public void setTlp_arno(String tlp_arno) {
		this.tlp_arno = tlp_arno;
	}
	public String getTlp_ofno() {
		return tlp_ofno;
	}
	public void setTlp_ofno(String tlp_ofno) {
		this.tlp_ofno = tlp_ofno;
	}
	public String getTlp_idvno() {
		return tlp_idvno;
	}
	public void setTlp_idvno(String tlp_idvno) {
		this.tlp_idvno = tlp_idvno;
	}
	public String getCust_hngl_nm() {
		return cust_hngl_nm;
	}
	public void setCust_hngl_nm(String cust_hngl_nm) {
		this.cust_hngl_nm = cust_hngl_nm;
	}
	public String getCust_dcmt_no_brth() {
		return cust_dcmt_no_brth;
	}
	public void setCust_dcmt_no_brth(String cust_dcmt_no_brth) {
		this.cust_dcmt_no_brth = cust_dcmt_no_brth;
	}
	public String getSx_cd() {
		return sx_cd;
	}
	public void setSx_cd(String sx_cd) {
		this.sx_cd = sx_cd;
	}
	public String[] getHpg_prct_hdlr_lit_srch_lit__hdlr_empno() {
		return hpg_prct_hdlr_lit_srch_lit__hdlr_empno;
	}
	public void setHpg_prct_hdlr_lit_srch_lit__hdlr_empno(String[] hpg_prct_hdlr_lit_srch_lit__hdlr_empno) {
		this.hpg_prct_hdlr_lit_srch_lit__hdlr_empno = hpg_prct_hdlr_lit_srch_lit__hdlr_empno;
	}
	public String[] getHpg_prct_hdlr_lit_srch_lit__hdlr_nm() {
		return hpg_prct_hdlr_lit_srch_lit__hdlr_nm;
	}
	public void setHpg_prct_hdlr_lit_srch_lit__hdlr_nm(String[] hpg_prct_hdlr_lit_srch_lit__hdlr_nm) {
		this.hpg_prct_hdlr_lit_srch_lit__hdlr_nm = hpg_prct_hdlr_lit_srch_lit__hdlr_nm;
	}
	public String[] getHpg_prct_hdlr_lit_srch_lit__agnc_mtu() {
		return hpg_prct_hdlr_lit_srch_lit__agnc_mtu;
	}
	public void setHpg_prct_hdlr_lit_srch_lit__agnc_mtu(String[] hpg_prct_hdlr_lit_srch_lit__agnc_mtu) {
		this.hpg_prct_hdlr_lit_srch_lit__agnc_mtu = hpg_prct_hdlr_lit_srch_lit__agnc_mtu;
	}
	public String[] getHpg_prct_hdlr_lit_srch_lit__hdlr_clp_arno() {
		return hpg_prct_hdlr_lit_srch_lit__hdlr_clp_arno;
	}
	public void setHpg_prct_hdlr_lit_srch_lit__hdlr_clp_arno(String[] hpg_prct_hdlr_lit_srch_lit__hdlr_clp_arno) {
		this.hpg_prct_hdlr_lit_srch_lit__hdlr_clp_arno = hpg_prct_hdlr_lit_srch_lit__hdlr_clp_arno;
	}
	public String[] getHpg_prct_hdlr_lit_srch_lit__hdlr_clp_ofno() {
		return hpg_prct_hdlr_lit_srch_lit__hdlr_clp_ofno;
	}
	public void setHpg_prct_hdlr_lit_srch_lit__hdlr_clp_ofno(String[] hpg_prct_hdlr_lit_srch_lit__hdlr_clp_ofno) {
		this.hpg_prct_hdlr_lit_srch_lit__hdlr_clp_ofno = hpg_prct_hdlr_lit_srch_lit__hdlr_clp_ofno;
	}
	public String[] getHpg_prct_hdlr_lit_srch_lit__hdlr_clp_idvno() {
		return hpg_prct_hdlr_lit_srch_lit__hdlr_clp_idvno;
	}
	public void setHpg_prct_hdlr_lit_srch_lit__hdlr_clp_idvno(String[] hpg_prct_hdlr_lit_srch_lit__hdlr_clp_idvno) {
		this.hpg_prct_hdlr_lit_srch_lit__hdlr_clp_idvno = hpg_prct_hdlr_lit_srch_lit__hdlr_clp_idvno;
	}
	public String[] getHpg_prct_hdlr_lit_srch_lit__hdlr_eml_adr() {
		return hpg_prct_hdlr_lit_srch_lit__hdlr_eml_adr;
	}
	public void setHpg_prct_hdlr_lit_srch_lit__hdlr_eml_adr(String[] hpg_prct_hdlr_lit_srch_lit__hdlr_eml_adr) {
		this.hpg_prct_hdlr_lit_srch_lit__hdlr_eml_adr = hpg_prct_hdlr_lit_srch_lit__hdlr_eml_adr;
	}
	public String[] getHpg_prct_hdlr_lit_srch_lit__bzlv_no() {
		return hpg_prct_hdlr_lit_srch_lit__bzlv_no;
	}
	public void setHpg_prct_hdlr_lit_srch_lit__bzlv_no(String[] hpg_prct_hdlr_lit_srch_lit__bzlv_no) {
		this.hpg_prct_hdlr_lit_srch_lit__bzlv_no = hpg_prct_hdlr_lit_srch_lit__bzlv_no;
	}
	public String[] getHpg_prct_hdlr_lit_srch_lit__bzlv_nm() {
		return hpg_prct_hdlr_lit_srch_lit__bzlv_nm;
	}
	public void setHpg_prct_hdlr_lit_srch_lit__bzlv_nm(String[] hpg_prct_hdlr_lit_srch_lit__bzlv_nm) {
		this.hpg_prct_hdlr_lit_srch_lit__bzlv_nm = hpg_prct_hdlr_lit_srch_lit__bzlv_nm;
	}
	public String[] getHpg_prct_hdlr_lit_srch_lit__bh_no() {
		return hpg_prct_hdlr_lit_srch_lit__bh_no;
	}
	public void setHpg_prct_hdlr_lit_srch_lit__bh_no(String[] hpg_prct_hdlr_lit_srch_lit__bh_no) {
		this.hpg_prct_hdlr_lit_srch_lit__bh_no = hpg_prct_hdlr_lit_srch_lit__bh_no;
	}
	public String[] getHpg_prct_hdlr_lit_srch_lit__bh_nm() {
		return hpg_prct_hdlr_lit_srch_lit__bh_nm;
	}
	public void setHpg_prct_hdlr_lit_srch_lit__bh_nm(String[] hpg_prct_hdlr_lit_srch_lit__bh_nm) {
		this.hpg_prct_hdlr_lit_srch_lit__bh_nm = hpg_prct_hdlr_lit_srch_lit__bh_nm;
	}
	public String[] getHpg_prct_hdlr_lit_srch_lit__hdqt_no() {
		return hpg_prct_hdlr_lit_srch_lit__hdqt_no;
	}
	public void setHpg_prct_hdlr_lit_srch_lit__hdqt_no(String[] hpg_prct_hdlr_lit_srch_lit__hdqt_no) {
		this.hpg_prct_hdlr_lit_srch_lit__hdqt_no = hpg_prct_hdlr_lit_srch_lit__hdqt_no;
	}
	public String[] getHpg_prct_hdlr_lit_srch_lit__hdqt_nm() {
		return hpg_prct_hdlr_lit_srch_lit__hdqt_nm;
	}
	public void setHpg_prct_hdlr_lit_srch_lit__hdqt_nm(String[] hpg_prct_hdlr_lit_srch_lit__hdqt_nm) {
		this.hpg_prct_hdlr_lit_srch_lit__hdqt_nm = hpg_prct_hdlr_lit_srch_lit__hdqt_nm;
	}
	public String[] getHpg_prct_hdlr_lit_srch_lit__bh_tlp_arno() {
		return hpg_prct_hdlr_lit_srch_lit__bh_tlp_arno;
	}
	public void setHpg_prct_hdlr_lit_srch_lit__bh_tlp_arno(String[] hpg_prct_hdlr_lit_srch_lit__bh_tlp_arno) {
		this.hpg_prct_hdlr_lit_srch_lit__bh_tlp_arno = hpg_prct_hdlr_lit_srch_lit__bh_tlp_arno;
	}
	public String[] getHpg_prct_hdlr_lit_srch_lit__bh_tlp_ofno() {
		return hpg_prct_hdlr_lit_srch_lit__bh_tlp_ofno;
	}
	public void setHpg_prct_hdlr_lit_srch_lit__bh_tlp_ofno(String[] hpg_prct_hdlr_lit_srch_lit__bh_tlp_ofno) {
		this.hpg_prct_hdlr_lit_srch_lit__bh_tlp_ofno = hpg_prct_hdlr_lit_srch_lit__bh_tlp_ofno;
	}
	public String[] getHpg_prct_hdlr_lit_srch_lit__bh_tlp_idvno() {
		return hpg_prct_hdlr_lit_srch_lit__bh_tlp_idvno;
	}
	public void setHpg_prct_hdlr_lit_srch_lit__bh_tlp_idvno(String[] hpg_prct_hdlr_lit_srch_lit__bh_tlp_idvno) {
		this.hpg_prct_hdlr_lit_srch_lit__bh_tlp_idvno = hpg_prct_hdlr_lit_srch_lit__bh_tlp_idvno;
	}
	public String[] getHpg_prct_hdlr_lit_srch_lit__brc_tlp_arno() {
		return hpg_prct_hdlr_lit_srch_lit__brc_tlp_arno;
	}
	public void setHpg_prct_hdlr_lit_srch_lit__brc_tlp_arno(String[] hpg_prct_hdlr_lit_srch_lit__brc_tlp_arno) {
		this.hpg_prct_hdlr_lit_srch_lit__brc_tlp_arno = hpg_prct_hdlr_lit_srch_lit__brc_tlp_arno;
	}
	public String[] getHpg_prct_hdlr_lit_srch_lit__brc_tlp_ofno() {
		return hpg_prct_hdlr_lit_srch_lit__brc_tlp_ofno;
	}
	public void setHpg_prct_hdlr_lit_srch_lit__brc_tlp_ofno(String[] hpg_prct_hdlr_lit_srch_lit__brc_tlp_ofno) {
		this.hpg_prct_hdlr_lit_srch_lit__brc_tlp_ofno = hpg_prct_hdlr_lit_srch_lit__brc_tlp_ofno;
	}
	public String[] getHpg_prct_hdlr_lit_srch_lit__brc_tlp_idvno() {
		return hpg_prct_hdlr_lit_srch_lit__brc_tlp_idvno;
	}
	public void setHpg_prct_hdlr_lit_srch_lit__brc_tlp_idvno(String[] hpg_prct_hdlr_lit_srch_lit__brc_tlp_idvno) {
		this.hpg_prct_hdlr_lit_srch_lit__brc_tlp_idvno = hpg_prct_hdlr_lit_srch_lit__brc_tlp_idvno;
	}
	public String[] getHpg_prct_hdlr_lit_srch_lit__hdlr_tlp_arno() {
		return hpg_prct_hdlr_lit_srch_lit__hdlr_tlp_arno;
	}
	public void setHpg_prct_hdlr_lit_srch_lit__hdlr_tlp_arno(String[] hpg_prct_hdlr_lit_srch_lit__hdlr_tlp_arno) {
		this.hpg_prct_hdlr_lit_srch_lit__hdlr_tlp_arno = hpg_prct_hdlr_lit_srch_lit__hdlr_tlp_arno;
	}
	public String[] getHpg_prct_hdlr_lit_srch_lit__hdlr_tlp_ofno() {
		return hpg_prct_hdlr_lit_srch_lit__hdlr_tlp_ofno;
	}
	public void setHpg_prct_hdlr_lit_srch_lit__hdlr_tlp_ofno(String[] hpg_prct_hdlr_lit_srch_lit__hdlr_tlp_ofno) {
		this.hpg_prct_hdlr_lit_srch_lit__hdlr_tlp_ofno = hpg_prct_hdlr_lit_srch_lit__hdlr_tlp_ofno;
	}
	public String[] getHpg_prct_hdlr_lit_srch_lit__hdlr_tlp_idvno() {
		return hpg_prct_hdlr_lit_srch_lit__hdlr_tlp_idvno;
	}
	public void setHpg_prct_hdlr_lit_srch_lit__hdlr_tlp_idvno(String[] hpg_prct_hdlr_lit_srch_lit__hdlr_tlp_idvno) {
		this.hpg_prct_hdlr_lit_srch_lit__hdlr_tlp_idvno = hpg_prct_hdlr_lit_srch_lit__hdlr_tlp_idvno;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getZ_msg_cd() {
		return z_msg_cd;
	}
	public void setZ_msg_cd(String z_msg_cd) {
		this.z_msg_cd = z_msg_cd;
	}
	public String getReturnMessage() {
		return returnMessage;
	}
	public void setReturnMessage(String returnMessage) {
		this.returnMessage = returnMessage;
	}
	
}
