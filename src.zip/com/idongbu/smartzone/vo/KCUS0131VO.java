package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class KCUS0131VO extends CMMVO {

	//전문필드
	public String dvn               = "";// 구분
	public String rsdn_no           = "";// 주민번호
	public String plno              = "";// 증권번호
	public String smat_lif_tgt_dvcd = "";// 서비스구분
	public String cust_no           = "";// 고객번호
	public String cust_nm           = "";// 고객명
	public String rcpl              = "";// 우편물수령처
	public String old_psno          = "";// 구우편번호
	public String old_pst_adr       = "";// 구우편주소
	public String old_dtl_adr       = "";// 구상세주소
	public String nw_psno           = "";// 신우편번호
	public String nw_pst_adr        = "";// 신우편주소
	public String nw_dtl_adr        = "";// 신상세주소
	public String clp_1             = "";// 휴대폰1
	public String clp_2             = "";// 휴대폰2
	public String clp_3             = "";// 휴대폰3
	public String hm_tlp_1          = "";// 자택전화1
	public String hm_tlp_2          = "";// 자택전화2
	public String hm_tlp_3          = "";// 자택전화3
	public String wpc_tlp_1         = "";// 직장전화1
	public String wpc_tlp_2         = "";// 직장전화2
	public String wpc_tlp_3         = "";// 직장전화3
	public String ctc_stat          = "";// 계약상태
	public String apl_dd            = "";// 청약일
	public String trmt_dd           = "";// 해지일
	public String srv_str_dd        = "";// 서비스시작일
	public String srv_fin_dd        = "";// 서비스종료일
	public String hdlr_no           = "";// 취급자번호
	public String hdlr_nm           = "";// 취급자명
	public String srv_dtl_cd        = "";// 서비스상테코드
	public String nwod_adr_dvcd     = "";// 신구주소구분코드
	public String psno              = "";// 우편번호
	public String pst_adr           = "";// 우편주소
	public String dtl_adr           = "";// 상세주소
	public String bzaq_tlp_arno     = "";// 거래처전화지역번호
	public String bzaq_tlp_ofno     = "";// 거래처전화국번호
	public String bzaq_tlp_idvno    = "";// 거래처전화개별번호
	public String memo_cn           = "";// 메모내용
	public String srv_aply_dd       = "";// 서비스신청일
	public String srv_ofer_dd       = "";// 서비스제공일
	public String ivc_us_dvcd       = "";// 송장이용구분코드
	public String ivc_us_no         = "";// 송장이용번호
	public String tgt_srch_ref_orr  = "";// 대상조회참조회차
	public String rsl_srch_ref_orr  = "";// 결과조회참조회차
	public String arc_pd			= "";// 보험시기
	public String arc_et			= "";// 보험종기
	public String mpy_cnv_prm		= "";// 월납환산보험료
	public String srv_tpcd			= "";// 서비스유형코드

	// 임시 시작
	public String errorCode;//에러코드
	public String z_msg_cd;//메시지 코드
	public String returnMessage;//메시지 내용
	
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getZ_msg_cd() {
		return z_msg_cd;
	}
	public void setZ_msg_cd(String z_msg_cd) {
		this.z_msg_cd = z_msg_cd;
	}
	public String getReturnMessage() {
		return returnMessage;
	}
	public void setReturnMessage(String returnMessage) {
		this.returnMessage = returnMessage;
	}
	// 임시 끝
	
	public String getDvn() {
		return dvn;
	}
	public void setDvn(String dvn) {
		this.dvn = dvn;
	}
	public String getRsdn_no() {
		return rsdn_no;
	}
	public void setRsdn_no(String rsdn_no) {
		this.rsdn_no = rsdn_no;
	}
	public String getPlno() {
		return plno;
	}
	public void setPlno(String plno) {
		this.plno = plno;
	}
	public String getSmat_lif_tgt_dvcd() {
		return smat_lif_tgt_dvcd;
	}
	public void setSmat_lif_tgt_dvcd(String smat_lif_tgt_dvcd) {
		this.smat_lif_tgt_dvcd = smat_lif_tgt_dvcd;
	}
	public String getCust_no() {
		return cust_no;
	}
	public void setCust_no(String cust_no) {
		this.cust_no = cust_no;
	}
	public String getCust_nm() {
		return cust_nm;
	}
	public void setCust_nm(String cust_nm) {
		this.cust_nm = cust_nm;
	}
	public String getRcpl() {
		return rcpl;
	}
	public void setRcpl(String rcpl) {
		this.rcpl = rcpl;
	}
	public String getOld_psno() {
		return old_psno;
	}
	public void setOld_psno(String old_psno) {
		this.old_psno = old_psno;
	}
	public String getOld_pst_adr() {
		return old_pst_adr;
	}
	public void setOld_pst_adr(String old_pst_adr) {
		this.old_pst_adr = old_pst_adr;
	}
	public String getOld_dtl_adr() {
		return old_dtl_adr;
	}
	public void setOld_dtl_adr(String old_dtl_adr) {
		this.old_dtl_adr = old_dtl_adr;
	}
	public String getNw_psno() {
		return nw_psno;
	}
	public void setNw_psno(String nw_psno) {
		this.nw_psno = nw_psno;
	}
	public String getNw_pst_adr() {
		return nw_pst_adr;
	}
	public void setNw_pst_adr(String nw_pst_adr) {
		this.nw_pst_adr = nw_pst_adr;
	}
	public String getNw_dtl_adr() {
		return nw_dtl_adr;
	}
	public void setNw_dtl_adr(String nw_dtl_adr) {
		this.nw_dtl_adr = nw_dtl_adr;
	}
	public String getClp_1() {
		return clp_1;
	}
	public void setClp_1(String clp_1) {
		this.clp_1 = clp_1;
	}
	public String getClp_2() {
		return clp_2;
	}
	public void setClp_2(String clp_2) {
		this.clp_2 = clp_2;
	}
	public String getClp_3() {
		return clp_3;
	}
	public void setClp_3(String clp_3) {
		this.clp_3 = clp_3;
	}
	public String getHm_tlp_1() {
		return hm_tlp_1;
	}
	public void setHm_tlp_1(String hm_tlp_1) {
		this.hm_tlp_1 = hm_tlp_1;
	}
	public String getHm_tlp_2() {
		return hm_tlp_2;
	}
	public void setHm_tlp_2(String hm_tlp_2) {
		this.hm_tlp_2 = hm_tlp_2;
	}
	public String getHm_tlp_3() {
		return hm_tlp_3;
	}
	public void setHm_tlp_3(String hm_tlp_3) {
		this.hm_tlp_3 = hm_tlp_3;
	}
	public String getWpc_tlp_1() {
		return wpc_tlp_1;
	}
	public void setWpc_tlp_1(String wpc_tlp_1) {
		this.wpc_tlp_1 = wpc_tlp_1;
	}
	public String getWpc_tlp_2() {
		return wpc_tlp_2;
	}
	public void setWpc_tlp_2(String wpc_tlp_2) {
		this.wpc_tlp_2 = wpc_tlp_2;
	}
	public String getWpc_tlp_3() {
		return wpc_tlp_3;
	}
	public void setWpc_tlp_3(String wpc_tlp_3) {
		this.wpc_tlp_3 = wpc_tlp_3;
	}
	public String getCtc_stat() {
		return ctc_stat;
	}
	public void setCtc_stat(String ctc_stat) {
		this.ctc_stat = ctc_stat;
	}
	public String getApl_dd() {
		return apl_dd;
	}
	public void setApl_dd(String apl_dd) {
		this.apl_dd = apl_dd;
	}
	public String getTrmt_dd() {
		return trmt_dd;
	}
	public void setTrmt_dd(String trmt_dd) {
		this.trmt_dd = trmt_dd;
	}
	public String getSrv_str_dd() {
		return srv_str_dd;
	}
	public void setSrv_str_dd(String srv_str_dd) {
		this.srv_str_dd = srv_str_dd;
	}
	public String getSrv_fin_dd() {
		return srv_fin_dd;
	}
	public void setSrv_fin_dd(String srv_fin_dd) {
		this.srv_fin_dd = srv_fin_dd;
	}
	public String getHdlr_no() {
		return hdlr_no;
	}
	public void setHdlr_no(String hdlr_no) {
		this.hdlr_no = hdlr_no;
	}
	public String getHdlr_nm() {
		return hdlr_nm;
	}
	public void setHdlr_nm(String hdlr_nm) {
		this.hdlr_nm = hdlr_nm;
	}
	public String getSrv_dtl_cd() {
		return srv_dtl_cd;
	}
	public void setSrv_dtl_cd(String srv_dtl_cd) {
		this.srv_dtl_cd = srv_dtl_cd;
	}
	public String getNwod_adr_dvcd() {
		return nwod_adr_dvcd;
	}
	public void setNwod_adr_dvcd(String nwod_adr_dvcd) {
		this.nwod_adr_dvcd = nwod_adr_dvcd;
	}
	public String getPsno() {
		return psno;
	}
	public void setPsno(String psno) {
		this.psno = psno;
	}
	public String getPst_adr() {
		return pst_adr;
	}
	public void setPst_adr(String pst_adr) {
		this.pst_adr = pst_adr;
	}
	public String getDtl_adr() {
		return dtl_adr;
	}
	public void setDtl_adr(String dtl_adr) {
		this.dtl_adr = dtl_adr;
	}
	public String getBzaq_tlp_arno() {
		return bzaq_tlp_arno;
	}
	public void setBzaq_tlp_arno(String bzaq_tlp_arno) {
		this.bzaq_tlp_arno = bzaq_tlp_arno;
	}
	public String getBzaq_tlp_ofno() {
		return bzaq_tlp_ofno;
	}
	public void setBzaq_tlp_ofno(String bzaq_tlp_ofno) {
		this.bzaq_tlp_ofno = bzaq_tlp_ofno;
	}
	public String getBzaq_tlp_idvno() {
		return bzaq_tlp_idvno;
	}
	public void setBzaq_tlp_idvno(String bzaq_tlp_idvno) {
		this.bzaq_tlp_idvno = bzaq_tlp_idvno;
	}
	public String getMemo_cn() {
		return memo_cn;
	}
	public void setMemo_cn(String memo_cn) {
		this.memo_cn = memo_cn;
	}
	public String getSrv_aply_dd() {
		return srv_aply_dd;
	}
	public void setSrv_aply_dd(String srv_aply_dd) {
		this.srv_aply_dd = srv_aply_dd;
	}
	public String getSrv_ofer_dd() {
		return srv_ofer_dd;
	}
	public void setSrv_ofer_dd(String srv_ofer_dd) {
		this.srv_ofer_dd = srv_ofer_dd;
	}
	public String getIvc_us_dvcd() {
		return ivc_us_dvcd;
	}
	public void setIvc_us_dvcd(String ivc_us_dvcd) {
		this.ivc_us_dvcd = ivc_us_dvcd;
	}
	public String getIvc_us_no() {
		return ivc_us_no;
	}
	public void setIvc_us_no(String ivc_us_no) {
		this.ivc_us_no = ivc_us_no;
	}
	public String getTgt_srch_ref_orr() {
		return tgt_srch_ref_orr;
	}
	public void setTgt_srch_ref_orr(String tgt_srch_ref_orr) {
		this.tgt_srch_ref_orr = tgt_srch_ref_orr;
	}
	public String getRsl_srch_ref_orr() {
		return rsl_srch_ref_orr;
	}
	public void setRsl_srch_ref_orr(String rsl_srch_ref_orr) {
		this.rsl_srch_ref_orr = rsl_srch_ref_orr;
	}
	public String getArc_pd() {
		return arc_pd;
	}
	public void setArc_pd(String arc_pd) {
		this.arc_pd = arc_pd;
	}
	public String getArc_et() {
		return arc_et;
	}
	public void setArc_et(String arc_et) {
		this.arc_et = arc_et;
	}
	public String getMpy_cnv_prm() {
		return mpy_cnv_prm;
	}
	public void setMpy_cnv_prm(String mpy_cnv_prm) {
		this.mpy_cnv_prm = mpy_cnv_prm;
	}
	public String getSrv_tpcd() {
		return srv_tpcd;
	}
	public void setSrv_tpcd(String srv_tpcd) {
		this.srv_tpcd = srv_tpcd;
	}
}
