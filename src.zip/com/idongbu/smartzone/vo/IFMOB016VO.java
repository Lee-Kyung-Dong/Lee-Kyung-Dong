package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class IFMOB016VO extends CMMVO {

    public String webM = "IF_MOB_016";

    // 입력
    public String I_SSN = null;				// 주민번호
    public String I_CUST_NM = null;         // 고객명
    public String I_STD_YMD = null;         // 기준일

    // 출력
    public String O_RET_CD = null;			// 결과코드 - 00:정상 , 10:입력값 누락, 11:입력값 오류, 99:시스템오류
    public String O_RET_MSG = null;			// 결과메시지

    public String[] O_LN_ID = new String[0];	    // 대출약정번호
    public String[] O_CNTR_YMD = new String[0];	    // 약정일자
    public String[] O_PICD = new String[0];	        // 상품코드
    public String[] O_LN_APY_AMT = new String[0];	// 대출신청금액
    public String[] O_LN_PRG_SCD = new String[0];	// 대출진행상태코드 - 4900:접수완료, 5700:접수완료, 5800:지급심사중, 5900:지급완료

}
