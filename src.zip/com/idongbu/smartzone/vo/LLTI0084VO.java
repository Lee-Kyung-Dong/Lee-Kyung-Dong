package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class LLTI0084VO extends CMMVO{
	
	public String plhd_rrno = null;		                                        //[I]계약자주민등록번호 
	public String plhd_nme = null;                                           	//[O]계약자성명 

	public String[] mway_wdra_pss_aot_if__mway_wdra_pss_dvcd = new String[0];	//[O]중도인출가능구분코드
	public String[] mway_wdra_pss_aot_if__mway_wdra_pss_amt = new String[0];   	//[O]중도인출가능금액    
	public String[] mway_wdra_pss_aot_if__arc_tp_cd = new String[0];   			//[O]보험종목코드        
	public String[] mway_wdra_pss_aot_if__arc_tp_nm = new String[0];   			//[O]보험종목명          
	public String[] mway_wdra_pss_aot_if__plno = new String[0];   				//[O]증권번호            
	public String[] mway_wdra_pss_aot_if__ps_pyn_amt = new String[0];   		//[O]기지급금액          
	public String[] mway_wdra_pss_aot_if__pym_amt = new String[0];   			//[O]납입금액            
	public String[] mway_wdra_pss_aot_if__wdra_nts = new String[0];   			//[O]인출횟수            
	public String[] mway_wdra_pss_aot_if__lmt_bse_nts = new String[0];   		//[O]한도기준횟수        
	public String[] mway_wdra_pss_aot_if__tot_wdra_nts = new String[0];   		//[O]총인출횟수          
	public String[] mway_wdra_pss_aot_if__wthd_dvcd = new String[0];   			//[O]출금구분코드        
	public String[] mway_wdra_pss_aot_if__wthd_dvn_nm = new String[0];   		//[O]출금구분명          
	public String[] mway_wdra_pss_aot_if__ctc_stat_cd = new String[0];   		//[O]계약상태코드        
	public String[] mway_wdra_pss_aot_if__ctc_stat_nm = new String[0];   		//[O]계약상태명          
	public String[] mway_wdra_pss_aot_if__arc_trm_str_dt = new String[0];   	//[O]보험기간시작일자    
	public String[] mway_wdra_pss_aot_if__arc_trm_fin_dt = new String[0];   	//[O]보험기간종료일자    
	public String[] mway_wdra_pss_aot_if__coll_mtd_cd = new String[0];   		//[O]수금방법코드        
	public String[] mway_wdra_pss_aot_if__coll_mtd_nm = new String[0];   		//[O]수금방법명          
	public String[] mway_wdra_pss_aot_if__dpsr_rrno = new String[0];   			//[O]예금주주민등록번호  
	public String[] mway_wdra_pss_aot_if__dpsr_nm = new String[0];   			//[O]예금주명            
	public String[] mway_wdra_pss_aot_if__aut_tsfr_bank_cd = new String[0];   	//[O]자동이체은행코드    
	public String[] mway_wdra_pss_aot_if__aut_tsfr_bank_nm = new String[0];   	//[O]자동이체은행명      
	public String[] mway_wdra_pss_aot_if__acc_no = new String[0];   			//[O]계좌번호            
	public String[] mway_wdra_pss_aot_if__tsfr_dd = new String[0];   			//[O]이체일              
	public String[] mway_wdra_pss_aot_if__aut_tsfr_chng_dt = new String[0];   	//[O]자동이체변경일자  

	public String srch_rrno = null;                                             //[O]조회주민등록번호  
	public String srch_plno = null;                                             //[O]조회증권번호      
	public String str_rrno = null;                                             	//[O]시작주민등록번호  
	public String str_plno = null;                                             	//[O]시작증권번호      
	public String last_rrno = null;                                             //[O]마지막주민등록번호
	public String last_plno = null;                                             //[O]마지막증권번호    
	
	public String errorCode = null;
	public String returnMessage = null;
	public String z_resp_msg = null;

	public String z_rqst_page_no = null;
	public String z_wh_page_cnt = null;
	public String z_wh_cnum = null;
	public String z_user_page_key_set = null;
	public String z_next_page_exis_yn = null;	//다음페이지 유무
	
	
	public String getPlhd_rrno() {
		return plhd_rrno;
	}
	public void setPlhd_rrno(String plhd_rrno) {
		this.plhd_rrno = plhd_rrno;
	}
	public String getPlhd_nme() {
		return plhd_nme;
	}
	public void setPlhd_nme(String plhd_nme) {
		this.plhd_nme = plhd_nme;
	}
	public String[] getMway_wdra_pss_aot_if__mway_wdra_pss_dvcd() {
		return mway_wdra_pss_aot_if__mway_wdra_pss_dvcd;
	}
	public void setMway_wdra_pss_aot_if__mway_wdra_pss_dvcd(
			String[] mway_wdra_pss_aot_if__mway_wdra_pss_dvcd) {
		this.mway_wdra_pss_aot_if__mway_wdra_pss_dvcd = mway_wdra_pss_aot_if__mway_wdra_pss_dvcd;
	}
	public String[] getMway_wdra_pss_aot_if__mway_wdra_pss_amt() {
		return mway_wdra_pss_aot_if__mway_wdra_pss_amt;
	}
	public void setMway_wdra_pss_aot_if__mway_wdra_pss_amt(
			String[] mway_wdra_pss_aot_if__mway_wdra_pss_amt) {
		this.mway_wdra_pss_aot_if__mway_wdra_pss_amt = mway_wdra_pss_aot_if__mway_wdra_pss_amt;
	}
	public String[] getMway_wdra_pss_aot_if__arc_tp_cd() {
		return mway_wdra_pss_aot_if__arc_tp_cd;
	}
	public void setMway_wdra_pss_aot_if__arc_tp_cd(
			String[] mway_wdra_pss_aot_if__arc_tp_cd) {
		this.mway_wdra_pss_aot_if__arc_tp_cd = mway_wdra_pss_aot_if__arc_tp_cd;
	}
	public String[] getMway_wdra_pss_aot_if__arc_tp_nm() {
		return mway_wdra_pss_aot_if__arc_tp_nm;
	}
	public void setMway_wdra_pss_aot_if__arc_tp_nm(
			String[] mway_wdra_pss_aot_if__arc_tp_nm) {
		this.mway_wdra_pss_aot_if__arc_tp_nm = mway_wdra_pss_aot_if__arc_tp_nm;
	}
	public String[] getMway_wdra_pss_aot_if__plno() {
		return mway_wdra_pss_aot_if__plno;
	}
	public void setMway_wdra_pss_aot_if__plno(String[] mway_wdra_pss_aot_if__plno) {
		this.mway_wdra_pss_aot_if__plno = mway_wdra_pss_aot_if__plno;
	}
	public String[] getMway_wdra_pss_aot_if__ps_pyn_amt() {
		return mway_wdra_pss_aot_if__ps_pyn_amt;
	}
	public void setMway_wdra_pss_aot_if__ps_pyn_amt(
			String[] mway_wdra_pss_aot_if__ps_pyn_amt) {
		this.mway_wdra_pss_aot_if__ps_pyn_amt = mway_wdra_pss_aot_if__ps_pyn_amt;
	}
	public String[] getMway_wdra_pss_aot_if__pym_amt() {
		return mway_wdra_pss_aot_if__pym_amt;
	}
	public void setMway_wdra_pss_aot_if__pym_amt(
			String[] mway_wdra_pss_aot_if__pym_amt) {
		this.mway_wdra_pss_aot_if__pym_amt = mway_wdra_pss_aot_if__pym_amt;
	}
	public String[] getMway_wdra_pss_aot_if__wdra_nts() {
		return mway_wdra_pss_aot_if__wdra_nts;
	}
	public void setMway_wdra_pss_aot_if__wdra_nts(
			String[] mway_wdra_pss_aot_if__wdra_nts) {
		this.mway_wdra_pss_aot_if__wdra_nts = mway_wdra_pss_aot_if__wdra_nts;
	}
	public String[] getMway_wdra_pss_aot_if__lmt_bse_nts() {
		return mway_wdra_pss_aot_if__lmt_bse_nts;
	}
	public void setMway_wdra_pss_aot_if__lmt_bse_nts(
			String[] mway_wdra_pss_aot_if__lmt_bse_nts) {
		this.mway_wdra_pss_aot_if__lmt_bse_nts = mway_wdra_pss_aot_if__lmt_bse_nts;
	}
	public String[] getMway_wdra_pss_aot_if__tot_wdra_nts() {
		return mway_wdra_pss_aot_if__tot_wdra_nts;
	}
	public void setMway_wdra_pss_aot_if__tot_wdra_nts(
			String[] mway_wdra_pss_aot_if__tot_wdra_nts) {
		this.mway_wdra_pss_aot_if__tot_wdra_nts = mway_wdra_pss_aot_if__tot_wdra_nts;
	}
	public String[] getMway_wdra_pss_aot_if__wthd_dvcd() {
		return mway_wdra_pss_aot_if__wthd_dvcd;
	}
	public void setMway_wdra_pss_aot_if__wthd_dvcd(
			String[] mway_wdra_pss_aot_if__wthd_dvcd) {
		this.mway_wdra_pss_aot_if__wthd_dvcd = mway_wdra_pss_aot_if__wthd_dvcd;
	}
	public String[] getMway_wdra_pss_aot_if__wthd_dvn_nm() {
		return mway_wdra_pss_aot_if__wthd_dvn_nm;
	}
	public void setMway_wdra_pss_aot_if__wthd_dvn_nm(
			String[] mway_wdra_pss_aot_if__wthd_dvn_nm) {
		this.mway_wdra_pss_aot_if__wthd_dvn_nm = mway_wdra_pss_aot_if__wthd_dvn_nm;
	}
	public String[] getMway_wdra_pss_aot_if__ctc_stat_cd() {
		return mway_wdra_pss_aot_if__ctc_stat_cd;
	}
	public void setMway_wdra_pss_aot_if__ctc_stat_cd(
			String[] mway_wdra_pss_aot_if__ctc_stat_cd) {
		this.mway_wdra_pss_aot_if__ctc_stat_cd = mway_wdra_pss_aot_if__ctc_stat_cd;
	}
	public String[] getMway_wdra_pss_aot_if__ctc_stat_nm() {
		return mway_wdra_pss_aot_if__ctc_stat_nm;
	}
	public void setMway_wdra_pss_aot_if__ctc_stat_nm(
			String[] mway_wdra_pss_aot_if__ctc_stat_nm) {
		this.mway_wdra_pss_aot_if__ctc_stat_nm = mway_wdra_pss_aot_if__ctc_stat_nm;
	}
	public String[] getMway_wdra_pss_aot_if__arc_trm_str_dt() {
		return mway_wdra_pss_aot_if__arc_trm_str_dt;
	}
	public void setMway_wdra_pss_aot_if__arc_trm_str_dt(
			String[] mway_wdra_pss_aot_if__arc_trm_str_dt) {
		this.mway_wdra_pss_aot_if__arc_trm_str_dt = mway_wdra_pss_aot_if__arc_trm_str_dt;
	}
	public String[] getMway_wdra_pss_aot_if__arc_trm_fin_dt() {
		return mway_wdra_pss_aot_if__arc_trm_fin_dt;
	}
	public void setMway_wdra_pss_aot_if__arc_trm_fin_dt(
			String[] mway_wdra_pss_aot_if__arc_trm_fin_dt) {
		this.mway_wdra_pss_aot_if__arc_trm_fin_dt = mway_wdra_pss_aot_if__arc_trm_fin_dt;
	}
	public String[] getMway_wdra_pss_aot_if__coll_mtd_cd() {
		return mway_wdra_pss_aot_if__coll_mtd_cd;
	}
	public void setMway_wdra_pss_aot_if__coll_mtd_cd(
			String[] mway_wdra_pss_aot_if__coll_mtd_cd) {
		this.mway_wdra_pss_aot_if__coll_mtd_cd = mway_wdra_pss_aot_if__coll_mtd_cd;
	}
	public String[] getMway_wdra_pss_aot_if__coll_mtd_nm() {
		return mway_wdra_pss_aot_if__coll_mtd_nm;
	}
	public void setMway_wdra_pss_aot_if__coll_mtd_nm(
			String[] mway_wdra_pss_aot_if__coll_mtd_nm) {
		this.mway_wdra_pss_aot_if__coll_mtd_nm = mway_wdra_pss_aot_if__coll_mtd_nm;
	}
	public String[] getMway_wdra_pss_aot_if__dpsr_rrno() {
		return mway_wdra_pss_aot_if__dpsr_rrno;
	}
	public void setMway_wdra_pss_aot_if__dpsr_rrno(
			String[] mway_wdra_pss_aot_if__dpsr_rrno) {
		this.mway_wdra_pss_aot_if__dpsr_rrno = mway_wdra_pss_aot_if__dpsr_rrno;
	}
	public String[] getMway_wdra_pss_aot_if__dpsr_nm() {
		return mway_wdra_pss_aot_if__dpsr_nm;
	}
	public void setMway_wdra_pss_aot_if__dpsr_nm(
			String[] mway_wdra_pss_aot_if__dpsr_nm) {
		this.mway_wdra_pss_aot_if__dpsr_nm = mway_wdra_pss_aot_if__dpsr_nm;
	}
	public String[] getMway_wdra_pss_aot_if__aut_tsfr_bank_cd() {
		return mway_wdra_pss_aot_if__aut_tsfr_bank_cd;
	}
	public void setMway_wdra_pss_aot_if__aut_tsfr_bank_cd(
			String[] mway_wdra_pss_aot_if__aut_tsfr_bank_cd) {
		this.mway_wdra_pss_aot_if__aut_tsfr_bank_cd = mway_wdra_pss_aot_if__aut_tsfr_bank_cd;
	}
	public String[] getMway_wdra_pss_aot_if__aut_tsfr_bank_nm() {
		return mway_wdra_pss_aot_if__aut_tsfr_bank_nm;
	}
	public void setMway_wdra_pss_aot_if__aut_tsfr_bank_nm(
			String[] mway_wdra_pss_aot_if__aut_tsfr_bank_nm) {
		this.mway_wdra_pss_aot_if__aut_tsfr_bank_nm = mway_wdra_pss_aot_if__aut_tsfr_bank_nm;
	}
	public String[] getMway_wdra_pss_aot_if__acc_no() {
		return mway_wdra_pss_aot_if__acc_no;
	}
	public void setMway_wdra_pss_aot_if__acc_no(
			String[] mway_wdra_pss_aot_if__acc_no) {
		this.mway_wdra_pss_aot_if__acc_no = mway_wdra_pss_aot_if__acc_no;
	}
	public String[] getMway_wdra_pss_aot_if__tsfr_dd() {
		return mway_wdra_pss_aot_if__tsfr_dd;
	}
	public void setMway_wdra_pss_aot_if__tsfr_dd(
			String[] mway_wdra_pss_aot_if__tsfr_dd) {
		this.mway_wdra_pss_aot_if__tsfr_dd = mway_wdra_pss_aot_if__tsfr_dd;
	}
	public String[] getMway_wdra_pss_aot_if__aut_tsfr_chng_dt() {
		return mway_wdra_pss_aot_if__aut_tsfr_chng_dt;
	}
	public void setMway_wdra_pss_aot_if__aut_tsfr_chng_dt(
			String[] mway_wdra_pss_aot_if__aut_tsfr_chng_dt) {
		this.mway_wdra_pss_aot_if__aut_tsfr_chng_dt = mway_wdra_pss_aot_if__aut_tsfr_chng_dt;
	}
	public String getSrch_rrno() {
		return srch_rrno;
	}
	public void setSrch_rrno(String srch_rrno) {
		this.srch_rrno = srch_rrno;
	}
	public String getSrch_plno() {
		return srch_plno;
	}
	public void setSrch_plno(String srch_plno) {
		this.srch_plno = srch_plno;
	}
	public String getStr_rrno() {
		return str_rrno;
	}
	public void setStr_rrno(String str_rrno) {
		this.str_rrno = str_rrno;
	}
	public String getStr_plno() {
		return str_plno;
	}
	public void setStr_plno(String str_plno) {
		this.str_plno = str_plno;
	}
	public String getLast_rrno() {
		return last_rrno;
	}
	public void setLast_rrno(String last_rrno) {
		this.last_rrno = last_rrno;
	}
	public String getLast_plno() {
		return last_plno;
	}
	public void setLast_plno(String last_plno) {
		this.last_plno = last_plno;
	}
}
