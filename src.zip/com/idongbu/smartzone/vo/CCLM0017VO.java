package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class CCLM0017VO extends CMMVO{
	//전문필드
		public String clam_cg_cntr_cd = "";  //[I] 보상담당센터코드 SS_JIJUM_CD 센터코드
		public String clam_cg_team_cd = "";  //[I] 보상담당팀코드 SS_TEAM_CD 팀코드
		public String clam_psic_empno = "";  //[I] 보상담당자사원번호 SS_JOJIKWON_CD 조직원코드
		public String frst_srch_dt = "";  //[I] 최초조회일자 SS_H_JUBSU_DATE_FR 기준일 From
		public String fnal_srch_dt = "";  //[I] 최종조회일자 SS_H_JUBSU_DATE_TO 기준일 To
		public String ins_rsdn_no = "";  //[I] 피보험자주민번호  
		public String ins_cust_no = "";  //[I/O] 피보험자고객번호  
		public String ins_nm = "";  //[O] 피보험자명  
		public String plno = "";  //[I] 증권번호  
		public String srch_cnsl_stat = "";  //[I] 조회상담상태 SS_H_SANGDAM_STAT 상담상태
		public String srch_cnsl_typ = "";  //[I] 조회상담유형 SS_H_SANGDAM_TYPE1 상담유형
		public String srch_cust_tend = "";  //[I] 조회고객성향 SS_H_SUNGHYANG_GB 고객성향
		public String[] cnsl_detl__cnsl_no = new String[0];  //[O] 상담내역_상담번호 SS_SANGDAM_NO1 상담번호1
		public String[] cnsl_detl__cnsl_rpt_dt = new String[0];  //[O] 상담내역_상담접수일자 SS_SANG_JUBSU_DATE 상담접수일자
		public String[] cnsl_detl__rpt_yn = new String[0];  //[O] 상담내역_접수여부  
		public String[] cnsl_detl__accd_dt = new String[0];  //[O] 상담내역_사고일자 SS_GIJUNIL_FROM 사고일
		public String[] cnsl_detl__accd_typ_lgcg = new String[0];  //[O] 상담내역_사고유형대분류  
		public String[] cnsl_detl__accd_typ_lgcg_nm = new String[0];  //[O] 상담내역_사고유형대분류명 HS_SAGO_TYPE2 사고유형
		public String[] cnsl_detl__accd_typ_mdcg = new String[0];  //[O] 상담내역_사고유형중분류  
		public String[] cnsl_detl__accd_typ_mdcg_nm = new String[0];  //[O] 상담내역_사고유형중분류명  
		public String[] cnsl_detl__cnsl_typ = new String[0];  //[O] 상담내역_상담유형  
		public String[] cnsl_detl__cnsl_typ_nm = new String[0];  //[O] 상담내역_상담유형명 HS_SANGDAM_TYPE1 상담유형
		public String[] cnsl_detl__cnsl_stat = new String[0];  //[O] 상담내역_상담상태  
		public String[] cnsl_detl__cnsl_stat_nm = new String[0];  //[O] 상담내역_상담상태명 HS_SANGDAM_STAT 상담상태
		public String[] cnsl_detl__cust_tend = new String[0];  //[O] 상담내역_고객성향 HS_SUNGHYANG_NY 고객성향
		public String[] cnsl_detl__cust_tend_cd = new String[0];  //[O] 상담내역_고객성향코드  
		public String[] cnsl_detl__askg_dcu_cplt_yn = new String[0];  //[O] 상담내역_청구서류완료여부  
		public String[] cnsl_detl__cnsr = new String[0];  //[O] 상담내역_상담자 HS_SANGDAMJA 상담자
		public String tot_cnum = "";  //[O] 총건수 SS_TOT_CNT 총건수
		
		
		public String getClam_cg_cntr_cd() {
			return clam_cg_cntr_cd;
		}
		public void setClam_cg_cntr_cd(String clam_cg_cntr_cd) {
			this.clam_cg_cntr_cd = clam_cg_cntr_cd;
		}
		public String getClam_cg_team_cd() {
			return clam_cg_team_cd;
		}
		public void setClam_cg_team_cd(String clam_cg_team_cd) {
			this.clam_cg_team_cd = clam_cg_team_cd;
		}
		public String getClam_psic_empno() {
			return clam_psic_empno;
		}
		public void setClam_psic_empno(String clam_psic_empno) {
			this.clam_psic_empno = clam_psic_empno;
		}
		public String getFrst_srch_dt() {
			return frst_srch_dt;
		}
		public void setFrst_srch_dt(String frst_srch_dt) {
			this.frst_srch_dt = frst_srch_dt;
		}
		public String getFnal_srch_dt() {
			return fnal_srch_dt;
		}
		public void setFnal_srch_dt(String fnal_srch_dt) {
			this.fnal_srch_dt = fnal_srch_dt;
		}
		public String getIns_rsdn_no() {
			return ins_rsdn_no;
		}
		public void setIns_rsdn_no(String ins_rsdn_no) {
			this.ins_rsdn_no = ins_rsdn_no;
		}
		public String getIns_cust_no() {
			return ins_cust_no;
		}
		public void setIns_cust_no(String ins_cust_no) {
			this.ins_cust_no = ins_cust_no;
		}
		public String getIns_nm() {
			return ins_nm;
		}
		public void setIns_nm(String ins_nm) {
			this.ins_nm = ins_nm;
		}
		public String getPlno() {
			return plno;
		}
		public void setPlno(String plno) {
			this.plno = plno;
		}
		public String getSrch_cnsl_stat() {
			return srch_cnsl_stat;
		}
		public void setSrch_cnsl_stat(String srch_cnsl_stat) {
			this.srch_cnsl_stat = srch_cnsl_stat;
		}
		public String getSrch_cnsl_typ() {
			return srch_cnsl_typ;
		}
		public void setSrch_cnsl_typ(String srch_cnsl_typ) {
			this.srch_cnsl_typ = srch_cnsl_typ;
		}
		public String getSrch_cust_tend() {
			return srch_cust_tend;
		}
		public void setSrch_cust_tend(String srch_cust_tend) {
			this.srch_cust_tend = srch_cust_tend;
		}
		public String[] getCnsl_detl__cnsl_no() {
			return cnsl_detl__cnsl_no;
		}
		public void setCnsl_detl__cnsl_no(String[] cnsl_detl__cnsl_no) {
			this.cnsl_detl__cnsl_no = cnsl_detl__cnsl_no;
		}
		public String[] getCnsl_detl__cnsl_rpt_dt() {
			return cnsl_detl__cnsl_rpt_dt;
		}
		public void setCnsl_detl__cnsl_rpt_dt(String[] cnsl_detl__cnsl_rpt_dt) {
			this.cnsl_detl__cnsl_rpt_dt = cnsl_detl__cnsl_rpt_dt;
		}
		public String[] getCnsl_detl__rpt_yn() {
			return cnsl_detl__rpt_yn;
		}
		public void setCnsl_detl__rpt_yn(String[] cnsl_detl__rpt_yn) {
			this.cnsl_detl__rpt_yn = cnsl_detl__rpt_yn;
		}
		public String[] getCnsl_detl__accd_dt() {
			return cnsl_detl__accd_dt;
		}
		public void setCnsl_detl__accd_dt(String[] cnsl_detl__accd_dt) {
			this.cnsl_detl__accd_dt = cnsl_detl__accd_dt;
		}
		public String[] getCnsl_detl__accd_typ_lgcg() {
			return cnsl_detl__accd_typ_lgcg;
		}
		public void setCnsl_detl__accd_typ_lgcg(String[] cnsl_detl__accd_typ_lgcg) {
			this.cnsl_detl__accd_typ_lgcg = cnsl_detl__accd_typ_lgcg;
		}
		public String[] getCnsl_detl__accd_typ_lgcg_nm() {
			return cnsl_detl__accd_typ_lgcg_nm;
		}
		public void setCnsl_detl__accd_typ_lgcg_nm(String[] cnsl_detl__accd_typ_lgcg_nm) {
			this.cnsl_detl__accd_typ_lgcg_nm = cnsl_detl__accd_typ_lgcg_nm;
		}
		public String[] getCnsl_detl__accd_typ_mdcg() {
			return cnsl_detl__accd_typ_mdcg;
		}
		public void setCnsl_detl__accd_typ_mdcg(String[] cnsl_detl__accd_typ_mdcg) {
			this.cnsl_detl__accd_typ_mdcg = cnsl_detl__accd_typ_mdcg;
		}
		public String[] getCnsl_detl__accd_typ_mdcg_nm() {
			return cnsl_detl__accd_typ_mdcg_nm;
		}
		public void setCnsl_detl__accd_typ_mdcg_nm(String[] cnsl_detl__accd_typ_mdcg_nm) {
			this.cnsl_detl__accd_typ_mdcg_nm = cnsl_detl__accd_typ_mdcg_nm;
		}
		public String[] getCnsl_detl__cnsl_typ() {
			return cnsl_detl__cnsl_typ;
		}
		public void setCnsl_detl__cnsl_typ(String[] cnsl_detl__cnsl_typ) {
			this.cnsl_detl__cnsl_typ = cnsl_detl__cnsl_typ;
		}
		public String[] getCnsl_detl__cnsl_typ_nm() {
			return cnsl_detl__cnsl_typ_nm;
		}
		public void setCnsl_detl__cnsl_typ_nm(String[] cnsl_detl__cnsl_typ_nm) {
			this.cnsl_detl__cnsl_typ_nm = cnsl_detl__cnsl_typ_nm;
		}
		public String[] getCnsl_detl__cnsl_stat() {
			return cnsl_detl__cnsl_stat;
		}
		public void setCnsl_detl__cnsl_stat(String[] cnsl_detl__cnsl_stat) {
			this.cnsl_detl__cnsl_stat = cnsl_detl__cnsl_stat;
		}
		public String[] getCnsl_detl__cnsl_stat_nm() {
			return cnsl_detl__cnsl_stat_nm;
		}
		public void setCnsl_detl__cnsl_stat_nm(String[] cnsl_detl__cnsl_stat_nm) {
			this.cnsl_detl__cnsl_stat_nm = cnsl_detl__cnsl_stat_nm;
		}
		public String[] getCnsl_detl__cust_tend() {
			return cnsl_detl__cust_tend;
		}
		public void setCnsl_detl__cust_tend(String[] cnsl_detl__cust_tend) {
			this.cnsl_detl__cust_tend = cnsl_detl__cust_tend;
		}
		public String[] getCnsl_detl__cust_tend_cd() {
			return cnsl_detl__cust_tend_cd;
		}
		public void setCnsl_detl__cust_tend_cd(String[] cnsl_detl__cust_tend_cd) {
			this.cnsl_detl__cust_tend_cd = cnsl_detl__cust_tend_cd;
		}
		public String[] getCnsl_detl__askg_dcu_cplt_yn() {
			return cnsl_detl__askg_dcu_cplt_yn;
		}
		public void setCnsl_detl__askg_dcu_cplt_yn(String[] cnsl_detl__askg_dcu_cplt_yn) {
			this.cnsl_detl__askg_dcu_cplt_yn = cnsl_detl__askg_dcu_cplt_yn;
		}
		public String[] getCnsl_detl__cnsr() {
			return cnsl_detl__cnsr;
		}
		public void setCnsl_detl__cnsr(String[] cnsl_detl__cnsr) {
			this.cnsl_detl__cnsr = cnsl_detl__cnsr;
		}
		public String getTot_cnum() {
			return tot_cnum;
		}
		public void setTot_cnum(String tot_cnum) {
			this.tot_cnum = tot_cnum;
		}
		
		
}
