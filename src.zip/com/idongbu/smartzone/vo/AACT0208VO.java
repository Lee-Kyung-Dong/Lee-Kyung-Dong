package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class AACT0208VO extends CMMVO{
	
		//전문필드
		public String rcwc_chn_dvcd = "";		//	I	: 입출금채널구분코드 ( 01:영업포탈, 02:방카. 03:신채널, 04:홈페이지, 05:콜센터)
		public String proc_dvcd = "";			//	I	: 처리구분코드
		public String dvcd = "";        					//	I    :	구분코드                  
		//public String rcwc_aply_id = "";          //	I    :  입출금신청ID    
		public String dlmn_empno = "";				//	I	:	처리자사번(임시)
		public String act_ocr_dvcd = "";          //	I    :  회계발생구분코드 [장기:02]       
		public String plno = "";                  //	I    :  증권번호                  
		public String bh_cd = "";                 //	I    :  지점코드                  
		public String bh_nm = "";                 //	O    :  지점명                    
		public String empno = "";                 //	I    :  사원번호                  
		public String ormm_nm = "";               //	O    :  조직원명                  
		public String pdc_cd = "";                //	O    :  상품코드                  
		public String pdc_nm = "";                //	O    :  상품명                    
		public String pdc_typ = "";               //	O    :  상품유형                  
		public String ctc_stat_nm = "";           //	O    :  계약상태명                
		public String ctc_stat_chng_bh = "";      //	O    :  계약상태변경지점          
		public String ctc_stat_dt = "";           //	O    :  계약상태일자              
		public String plhd_nm = "";               //	O    :  계약자명                  
		public String psco_dvn_nm = "";           //	O    :  개인법인구분명            
		public String plhd_rrno = "";             //	O    :  계약자주민등록번호        
		public String arc_pd_dt = "";             //	O    :  보험시기일자              
		public String arc_et_dt = "";             //	O    :  보험종기일자              
		public String pym_ycnt = "";              //	O    :  납입년수                  
		public String dfmt_ycnt = "";             //	O    :  거치년수                  
		public String exp_ycnt = "";              //	O    :  만기년수                  
		public String coll_mtd_nm = "";           //	O    :  수금방법명                
		public String fnal_pym_mon = "";          //	O    :  최종납입월                
		public String pym_mtd_nm = "";            //	O    :  납입방법명                
		public String pym_epct_prm = "";          //	O    :  납입예정보험료            
		public String tot_pym_nts = "";           //	O    :  총납입횟수                
		public String fnal_pym_nts = "";          //	O    :  최종납입횟수              
		public String tot_pym_prm = "";           //	O    :  총납입보험료              
		public String coll_bh_cd = "";            //	O    :  수금지점코드              
		public String coll_brn_cd = "";           //	O    :  수금지부코드              
		public String coll_empno = "";            //	O    :  수금사원번호              
		public String coll_bh_nm = "";            //	O    :  수금지점명                
		public String coll_brn_nm = "";           //	O    :  수금지부명                
		public String coll_ep_nm = "";            //	O    :  수금사원명                
		public String coll_agnc_main = "";        //	O    :  수금대리점주              
		public String coll_bh_tlno = "";          //	O    :  수금지점전화번호          
		public String bz_dvn_nm = "";             //	O    :  업무구분명                
		public String rqst_no = "";               //	O    :  요청번호                  
		public String pym_nts = "";               //	I/O  :  납입횟수                  
		public String pym_prm = "";               //	O    :  납입보험료                
		public String pym_pd_mon = "";            //	O    :  납입시기월                
		public String pym_pd_nts = "";            //	O    :  납입시기횟수              
		public String rnst_inte = "";             //	O    :  부활이자                  
		public String pym_et_mon = "";            //	O    :  납입종기월                
		public String pym_et_nts = "";            //	O    :  납입종기횟수              
		public String ppy_inte = "";              //	O    :  선납이자      
		public String ACCU_PRM = "";			
		public String askg_prm = "";              //	O    :  청구보험료                
		public String[] rpmn_if__cltd_dvn =  new String[0];        //입금정보_영수구분
		public String[] rpmn_if__ind_plno =  new String[0];        //입금정보_개별증권번호
		public String[] rpmn_if__ind_ins_lcpl_dvcd =  new String[0];        //입금정보_개별피보험자소재지구분코드
		public String[] rpmn_if__ind_ply_sqno =  new String[0];        //입금정보_개별증권일련번호
		public String[] rpmn_if__ind_pdc_cd =  new String[0];        //입금정보_개별상품코드
		public String[] rpmn_if__cust_nm =  new String[0];        //입금정보_고객명
		public String[] rpmn_if__rlt_nm =  new String[0];        //입금정보_관계명
		public String[] rpmn_if__pym_str_mon =  new String[0];        //입금정보_납입시작월
		public String[] rpmn_if__pym_str_orr =  new String[0];        //입금정보_납입시작회차
		public String[] rpmn_if__pym_fin_mon =  new String[0];        //입금정보_납입종료월
		public String[] rpmn_if__pym_fin_orr =  new String[0];        //입금정보_납입종료회차
		public String[] rpmn_if__ctc_stat_nm =  new String[0];        //입금정보_계약상태명2
		public String[] rpmn_if__pym_epct_prm =  new String[0];        //입금정보_납입예정보험료2
		public String[] rpmn_if__rmk =  new String[0];        //입금정보_비고             
		public String bank_cd = "";               //	I    :  은행코드                  
		public String bank_nm = "";               //	I    :  은행명                    
		public String acc_no = "";                //	I    :  계좌번호                  
		public String clp = "";                   //	I    :  휴대폰                    
		public String dpsr_nm = "";               //	I    :  예금주명                  
		public String dpsr_rrno = "";             //	I    :  예금주주민등록번호        
		public String dpsr_eqal_yn = "";          //	I    :  예금주일치여부            
		public String rmk_2 = "";                   //	I    :  비고                      
		public String rtun_cd = "";               //	O    :  리턴코드                  
		public String errorCode = "";               //	O    :  리턴코드                  
		public String returnMessage = "";               //	O    :  리턴메세지                  
		public String z_resp_msg = "";				// O : 응답메세지
		public String wthd_csn_evd_dat_dvcd = ""; // [I] 출금동의증빙자료구분코드
		public String wthd_csn_evd_dat_inpt_dvcd = ""; // [I] 출금동의증빙자료입력구분코드
		public String wthd_csn_evd_dat_val = ""; // [I] 출금동의증빙자료값
		public String msg_1 = "";				// O : 비즈니스 로직 결과 '0000' : 정상출금, 이외 불능처리
		public String msg_2 = "";				// O : 비즈니스 로직 결과 메세지

		public String getMsg_1() {
			return msg_1;
		}
		public void setMsg_1(String msg_1) {
			this.msg_1 = msg_1;
		}
		public String getMsg_2() {
			return msg_2;
		}
		public void setMsg_2(String msg_2) {
			this.msg_2 = msg_2;
		}
		public String getZ_resp_msg() {
			return z_resp_msg;
		}
		public void setZ_resp_msg(String z_resp_msg) {
			this.z_resp_msg = z_resp_msg;
		}
		public String getReturnMessage() {
			return returnMessage;
		}
		public void setReturnMessage(String returnMessage) {
			this.returnMessage = returnMessage;
		}
		public String getErrorCode() {
			return errorCode;
		}
		public void setErrorCode(String errorCode) {
			this.errorCode = errorCode;
		}
		public String getRcwc_chn_dvcd() {
			return rcwc_chn_dvcd;
		}
		public void setRcwc_chn_dvcd(String rcwc_chn_dvcd) {
			this.rcwc_chn_dvcd = rcwc_chn_dvcd;
		}
		public String getProc_dvcd() {
			return proc_dvcd;
		}
		public void setProc_dvcd(String proc_dvcd) {
			this.proc_dvcd = proc_dvcd;
		}
		public String getDvcd() {
			return dvcd;
		}
		public void setDvcd(String dvcd) {
			this.dvcd = dvcd;
		}
		public String getDlmn_empno() {
			return dlmn_empno;
		}
		public void setDlmn_empno(String dlmn_empno) {
			this.dlmn_empno = dlmn_empno;
		}
		public String getAct_ocr_dvcd() {
			return act_ocr_dvcd;
		}
		public void setAct_ocr_dvcd(String act_ocr_dvcd) {
			this.act_ocr_dvcd = act_ocr_dvcd;
		}
		public String getPlno() {
			return plno;
		}
		public void setPlno(String plno) {
			this.plno = plno;
		}
		public String getBh_cd() {
			return bh_cd;
		}
		public void setBh_cd(String bh_cd) {
			this.bh_cd = bh_cd;
		}
		public String getBh_nm() {
			return bh_nm;
		}
		public void setBh_nm(String bh_nm) {
			this.bh_nm = bh_nm;
		}
		public String getEmpno() {
			return empno;
		}
		public void setEmpno(String empno) {
			this.empno = empno;
		}
		public String getOrmm_nm() {
			return ormm_nm;
		}
		public void setOrmm_nm(String ormm_nm) {
			this.ormm_nm = ormm_nm;
		}
		public String getPdc_cd() {
			return pdc_cd;
		}
		public void setPdc_cd(String pdc_cd) {
			this.pdc_cd = pdc_cd;
		}
		public String getPdc_nm() {
			return pdc_nm;
		}
		public void setPdc_nm(String pdc_nm) {
			this.pdc_nm = pdc_nm;
		}
		public String getPdc_typ() {
			return pdc_typ;
		}
		public void setPdc_typ(String pdc_typ) {
			this.pdc_typ = pdc_typ;
		}
		public String getCtc_stat_nm() {
			return ctc_stat_nm;
		}
		public void setCtc_stat_nm(String ctc_stat_nm) {
			this.ctc_stat_nm = ctc_stat_nm;
		}
		public String getCtc_stat_chng_bh() {
			return ctc_stat_chng_bh;
		}
		public void setCtc_stat_chng_bh(String ctc_stat_chng_bh) {
			this.ctc_stat_chng_bh = ctc_stat_chng_bh;
		}
		public String getCtc_stat_dt() {
			return ctc_stat_dt;
		}
		public void setCtc_stat_dt(String ctc_stat_dt) {
			this.ctc_stat_dt = ctc_stat_dt;
		}
		public String getPlhd_nm() {
			return plhd_nm;
		}
		public void setPlhd_nm(String plhd_nm) {
			this.plhd_nm = plhd_nm;
		}
		public String getPsco_dvn_nm() {
			return psco_dvn_nm;
		}
		public void setPsco_dvn_nm(String psco_dvn_nm) {
			this.psco_dvn_nm = psco_dvn_nm;
		}
		public String getPlhd_rrno() {
			return plhd_rrno;
		}
		public void setPlhd_rrno(String plhd_rrno) {
			this.plhd_rrno = plhd_rrno;
		}
		public String getArc_pd_dt() {
			return arc_pd_dt;
		}
		public void setArc_pd_dt(String arc_pd_dt) {
			this.arc_pd_dt = arc_pd_dt;
		}
		public String getArc_et_dt() {
			return arc_et_dt;
		}
		public void setArc_et_dt(String arc_et_dt) {
			this.arc_et_dt = arc_et_dt;
		}
		public String getPym_ycnt() {
			return pym_ycnt;
		}
		public void setPym_ycnt(String pym_ycnt) {
			this.pym_ycnt = pym_ycnt;
		}
		public String getDfmt_ycnt() {
			return dfmt_ycnt;
		}
		public void setDfmt_ycnt(String dfmt_ycnt) {
			this.dfmt_ycnt = dfmt_ycnt;
		}
		public String getExp_ycnt() {
			return exp_ycnt;
		}
		public void setExp_ycnt(String exp_ycnt) {
			this.exp_ycnt = exp_ycnt;
		}
		public String getColl_mtd_nm() {
			return coll_mtd_nm;
		}
		public void setColl_mtd_nm(String coll_mtd_nm) {
			this.coll_mtd_nm = coll_mtd_nm;
		}
		public String getFnal_pym_mon() {
			return fnal_pym_mon;
		}
		public void setFnal_pym_mon(String fnal_pym_mon) {
			this.fnal_pym_mon = fnal_pym_mon;
		}
		public String getPym_mtd_nm() {
			return pym_mtd_nm;
		}
		public void setPym_mtd_nm(String pym_mtd_nm) {
			this.pym_mtd_nm = pym_mtd_nm;
		}
		public String getPym_epct_prm() {
			return pym_epct_prm;
		}
		public void setPym_epct_prm(String pym_epct_prm) {
			this.pym_epct_prm = pym_epct_prm;
		}
		public String getTot_pym_nts() {
			return tot_pym_nts;
		}
		public void setTot_pym_nts(String tot_pym_nts) {
			this.tot_pym_nts = tot_pym_nts;
		}
		public String getFnal_pym_nts() {
			return fnal_pym_nts;
		}
		public void setFnal_pym_nts(String fnal_pym_nts) {
			this.fnal_pym_nts = fnal_pym_nts;
		}
		public String getTot_pym_prm() {
			return tot_pym_prm;
		}
		public void setTot_pym_prm(String tot_pym_prm) {
			this.tot_pym_prm = tot_pym_prm;
		}
		public String getColl_bh_cd() {
			return coll_bh_cd;
		}
		public void setColl_bh_cd(String coll_bh_cd) {
			this.coll_bh_cd = coll_bh_cd;
		}
		public String getColl_brn_cd() {
			return coll_brn_cd;
		}
		public void setColl_brn_cd(String coll_brn_cd) {
			this.coll_brn_cd = coll_brn_cd;
		}
		public String getColl_empno() {
			return coll_empno;
		}
		public void setColl_empno(String coll_empno) {
			this.coll_empno = coll_empno;
		}
		public String getColl_bh_nm() {
			return coll_bh_nm;
		}
		public void setColl_bh_nm(String coll_bh_nm) {
			this.coll_bh_nm = coll_bh_nm;
		}
		public String getColl_brn_nm() {
			return coll_brn_nm;
		}
		public void setColl_brn_nm(String coll_brn_nm) {
			this.coll_brn_nm = coll_brn_nm;
		}
		public String getColl_ep_nm() {
			return coll_ep_nm;
		}
		public void setColl_ep_nm(String coll_ep_nm) {
			this.coll_ep_nm = coll_ep_nm;
		}
		public String getColl_agnc_main() {
			return coll_agnc_main;
		}
		public void setColl_agnc_main(String coll_agnc_main) {
			this.coll_agnc_main = coll_agnc_main;
		}
		public String getColl_bh_tlno() {
			return coll_bh_tlno;
		}
		public void setColl_bh_tlno(String coll_bh_tlno) {
			this.coll_bh_tlno = coll_bh_tlno;
		}
		public String getBz_dvn_nm() {
			return bz_dvn_nm;
		}
		public void setBz_dvn_nm(String bz_dvn_nm) {
			this.bz_dvn_nm = bz_dvn_nm;
		}
		public String getRqst_no() {
			return rqst_no;
		}
		public void setRqst_no(String rqst_no) {
			this.rqst_no = rqst_no;
		}
		public String getPym_nts() {
			return pym_nts;
		}
		public void setPym_nts(String pym_nts) {
			this.pym_nts = pym_nts;
		}
		public String getPym_prm() {
			return pym_prm;
		}
		public void setPym_prm(String pym_prm) {
			this.pym_prm = pym_prm;
		}
		public String getPym_pd_mon() {
			return pym_pd_mon;
		}
		public void setPym_pd_mon(String pym_pd_mon) {
			this.pym_pd_mon = pym_pd_mon;
		}
		public String getPym_pd_nts() {
			return pym_pd_nts;
		}
		public void setPym_pd_nts(String pym_pd_nts) {
			this.pym_pd_nts = pym_pd_nts;
		}
		public String getRnst_inte() {
			return rnst_inte;
		}
		public void setRnst_inte(String rnst_inte) {
			this.rnst_inte = rnst_inte;
		}
		public String getPym_et_mon() {
			return pym_et_mon;
		}
		public void setPym_et_mon(String pym_et_mon) {
			this.pym_et_mon = pym_et_mon;
		}
		public String getPym_et_nts() {
			return pym_et_nts;
		}
		public void setPym_et_nts(String pym_et_nts) {
			this.pym_et_nts = pym_et_nts;
		}
		public String getPpy_inte() {
			return ppy_inte;
		}
		public void setPpy_inte(String ppy_inte) {
			this.ppy_inte = ppy_inte;
		}
		public String getACCU_PRM() {
			return ACCU_PRM;
		}
		public void setACCU_PRM(String aCCU_PRM) {
			ACCU_PRM = aCCU_PRM;
		}
		public String getAskg_prm() {
			return askg_prm;
		}
		public void setAskg_prm(String askg_prm) {
			this.askg_prm = askg_prm;
		}
		public String[] getRpmn_if__cltd_dvn() {
			return rpmn_if__cltd_dvn;
		}
		public void setRpmn_if__cltd_dvn(String[] rpmn_if__cltd_dvn) {
			this.rpmn_if__cltd_dvn = rpmn_if__cltd_dvn;
		}
		public String[] getRpmn_if__ind_plno() {
			return rpmn_if__ind_plno;
		}
		public void setRpmn_if__ind_plno(String[] rpmn_if__ind_plno) {
			this.rpmn_if__ind_plno = rpmn_if__ind_plno;
		}
		public String[] getRpmn_if__ind_ins_lcpl_dvcd() {
			return rpmn_if__ind_ins_lcpl_dvcd;
		}
		public void setRpmn_if__ind_ins_lcpl_dvcd(String[] rpmn_if__ind_ins_lcpl_dvcd) {
			this.rpmn_if__ind_ins_lcpl_dvcd = rpmn_if__ind_ins_lcpl_dvcd;
		}
		public String[] getRpmn_if__ind_ply_sqno() {
			return rpmn_if__ind_ply_sqno;
		}
		public void setRpmn_if__ind_ply_sqno(String[] rpmn_if__ind_ply_sqno) {
			this.rpmn_if__ind_ply_sqno = rpmn_if__ind_ply_sqno;
		}
		public String[] getRpmn_if__ind_pdc_cd() {
			return rpmn_if__ind_pdc_cd;
		}
		public void setRpmn_if__ind_pdc_cd(String[] rpmn_if__ind_pdc_cd) {
			this.rpmn_if__ind_pdc_cd = rpmn_if__ind_pdc_cd;
		}
		public String[] getRpmn_if__cust_nm() {
			return rpmn_if__cust_nm;
		}
		public void setRpmn_if__cust_nm(String[] rpmn_if__cust_nm) {
			this.rpmn_if__cust_nm = rpmn_if__cust_nm;
		}
		public String[] getRpmn_if__rlt_nm() {
			return rpmn_if__rlt_nm;
		}
		public void setRpmn_if__rlt_nm(String[] rpmn_if__rlt_nm) {
			this.rpmn_if__rlt_nm = rpmn_if__rlt_nm;
		}
		public String[] getRpmn_if__pym_str_mon() {
			return rpmn_if__pym_str_mon;
		}
		public void setRpmn_if__pym_str_mon(String[] rpmn_if__pym_str_mon) {
			this.rpmn_if__pym_str_mon = rpmn_if__pym_str_mon;
		}
		public String[] getRpmn_if__pym_str_orr() {
			return rpmn_if__pym_str_orr;
		}
		public void setRpmn_if__pym_str_orr(String[] rpmn_if__pym_str_orr) {
			this.rpmn_if__pym_str_orr = rpmn_if__pym_str_orr;
		}
		public String[] getRpmn_if__pym_fin_mon() {
			return rpmn_if__pym_fin_mon;
		}
		public void setRpmn_if__pym_fin_mon(String[] rpmn_if__pym_fin_mon) {
			this.rpmn_if__pym_fin_mon = rpmn_if__pym_fin_mon;
		}
		public String[] getRpmn_if__pym_fin_orr() {
			return rpmn_if__pym_fin_orr;
		}
		public void setRpmn_if__pym_fin_orr(String[] rpmn_if__pym_fin_orr) {
			this.rpmn_if__pym_fin_orr = rpmn_if__pym_fin_orr;
		}
		public String[] getRpmn_if__ctc_stat_nm() {
			return rpmn_if__ctc_stat_nm;
		}
		public void setRpmn_if__ctc_stat_nm(String[] rpmn_if__ctc_stat_nm) {
			this.rpmn_if__ctc_stat_nm = rpmn_if__ctc_stat_nm;
		}
		public String[] getRpmn_if__pym_epct_prm() {
			return rpmn_if__pym_epct_prm;
		}
		public void setRpmn_if__pym_epct_prm(String[] rpmn_if__pym_epct_prm) {
			this.rpmn_if__pym_epct_prm = rpmn_if__pym_epct_prm;
		}
		public String[] getRpmn_if__rmk() {
			return rpmn_if__rmk;
		}
		public void setRpmn_if__rmk(String[] rpmn_if__rmk) {
			this.rpmn_if__rmk = rpmn_if__rmk;
		}
		public String getBank_cd() {
			return bank_cd;
		}
		public void setBank_cd(String bank_cd) {
			this.bank_cd = bank_cd;
		}
		public String getBank_nm() {
			return bank_nm;
		}
		public void setBank_nm(String bank_nm) {
			this.bank_nm = bank_nm;
		}
		public String getAcc_no() {
			return acc_no;
		}
		public void setAcc_no(String acc_no) {
			this.acc_no = acc_no;
		}
		public String getClp() {
			return clp;
		}
		public void setClp(String clp) {
			this.clp = clp;
		}
		public String getDpsr_nm() {
			return dpsr_nm;
		}
		public void setDpsr_nm(String dpsr_nm) {
			this.dpsr_nm = dpsr_nm;
		}
		public String getDpsr_rrno() {
			return dpsr_rrno;
		}
		public void setDpsr_rrno(String dpsr_rrno) {
			this.dpsr_rrno = dpsr_rrno;
		}
		public String getDpsr_eqal_yn() {
			return dpsr_eqal_yn;
		}
		public void setDpsr_eqal_yn(String dpsr_eqal_yn) {
			this.dpsr_eqal_yn = dpsr_eqal_yn;
		}
		public String getRmk_2() {
			return rmk_2;
		}
		public void setRmk_2(String rmk_2) {
			this.rmk_2 = rmk_2;
		}
		public String getRtun_cd() {
			return rtun_cd;
		}
		public void setRtun_cd(String rtun_cd) {
			this.rtun_cd = rtun_cd;
		}
		public String getWthd_csn_evd_dat_dvcd() {
			return wthd_csn_evd_dat_dvcd;
		}
		public void setWthd_csn_evd_dat_dvcd(String wthd_csn_evd_dat_dvcd) {
			this.wthd_csn_evd_dat_dvcd = wthd_csn_evd_dat_dvcd;
		}
		public String getWthd_csn_evd_dat_inpt_dvcd() {
			return wthd_csn_evd_dat_inpt_dvcd;
		}
		public void setWthd_csn_evd_dat_inpt_dvcd(String wthd_csn_evd_dat_inpt_dvcd) {
			this.wthd_csn_evd_dat_inpt_dvcd = wthd_csn_evd_dat_inpt_dvcd;
		}
		public String getWthd_csn_evd_dat_val() {
			return wthd_csn_evd_dat_val;
		}
		public void setWthd_csn_evd_dat_val(String wthd_csn_evd_dat_val) {
			this.wthd_csn_evd_dat_val = wthd_csn_evd_dat_val;
		}
}
