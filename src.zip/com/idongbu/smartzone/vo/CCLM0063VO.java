package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class CCLM0063VO extends CMMVO {

	//전문필드
		public String clam_dvn = "";  //[I/O] 보상구분 LK_COMP_GB 보상구분
		public String user = "";  //[I/O] 사용자 LK_USER_ID 사용자
		public String pat_dvn_1 = "";  //[I/O] 파트구분1 LK_PART_GB1 파트구분1
		public String pat_dvn_2 = "";  //[I/O] 파트구분2 LK_PART_GB2 파트구분2
		public String bz_dvn_1 = "";  //[I/O] 업무구분1 LK_UPMU_CD1 업무구분1
		public String bz_dvn_2 = "";  //[I/O] 업무구분2 LK_UPMU_CD2 업무구분2
		public String bz_dvn_3 = "";  //[I/O] 업무구분3 LK_UPMU_CD3 업무구분3
		public String rsl_dvn = "";  //[I/O] 결과구분 LK_GULK_GB 결과구분
		public String msg_cd_2 = "";  //[I/O] 메시지코드 LK_MSG_CD2 메세지코드2
		public String msg_2 = "";  //[I/O] 메시지 H_LK_MESSAGE2 메시지2
		public String cust_no = "";  //[I/O] 고객번호 LK_I_GOGEK_NO 고객번호
		public String[] clam_srh_srv_accd_srch_if__accd_rpt_no = new String[0];  //[O] 보상검색서비스 사고조회_정보_사고접수번호 LK_SAGO_JUBSU_NO 사고접수번호         
		public String[] clam_srh_srv_accd_srch_if__vh_no = new String[0];  //[O] 보상검색서비스 사고조회_정보_차량번호 LK_CAR_NO 차량번호
		public String[] clam_srh_srv_accd_srch_if__accd_dttm = new String[0];  //[O] 보상검색서비스 사고조회_정보_사고일시 LK_SAGO_YMDSB 사고일시
		public String[] clam_srh_srv_accd_srch_if__accd_prg_crs_cd = new String[0];  //[O] 보상검색서비스 사고조회_정보_사고진행과정코드 LK_JINHANG_GB 진행구분
		public String[] clam_srh_srv_accd_srch_if__accd_prg_crs_cd_nm = new String[0];  //[O] 보상검색서비스 사고조회_정보_사고진행과정코드명  
		public String hdlr_empno = "";  //[I] 취급자사원번호  
		public String getClam_dvn() {
			return clam_dvn;
		}
		public void setClam_dvn(String clam_dvn) {
			this.clam_dvn = clam_dvn;
		}
		public String getUser() {
			return user;
		}
		public void setUser(String user) {
			this.user = user;
		}
		public String getPat_dvn_1() {
			return pat_dvn_1;
		}
		public void setPat_dvn_1(String pat_dvn_1) {
			this.pat_dvn_1 = pat_dvn_1;
		}
		public String getPat_dvn_2() {
			return pat_dvn_2;
		}
		public void setPat_dvn_2(String pat_dvn_2) {
			this.pat_dvn_2 = pat_dvn_2;
		}
		public String getBz_dvn_1() {
			return bz_dvn_1;
		}
		public void setBz_dvn_1(String bz_dvn_1) {
			this.bz_dvn_1 = bz_dvn_1;
		}
		public String getBz_dvn_2() {
			return bz_dvn_2;
		}
		public void setBz_dvn_2(String bz_dvn_2) {
			this.bz_dvn_2 = bz_dvn_2;
		}
		public String getBz_dvn_3() {
			return bz_dvn_3;
		}
		public void setBz_dvn_3(String bz_dvn_3) {
			this.bz_dvn_3 = bz_dvn_3;
		}
		public String getRsl_dvn() {
			return rsl_dvn;
		}
		public void setRsl_dvn(String rsl_dvn) {
			this.rsl_dvn = rsl_dvn;
		}
		public String getMsg_cd_2() {
			return msg_cd_2;
		}
		public void setMsg_cd_2(String msg_cd_2) {
			this.msg_cd_2 = msg_cd_2;
		}
		public String getMsg_2() {
			return msg_2;
		}
		public void setMsg_2(String msg_2) {
			this.msg_2 = msg_2;
		}
		public String getCust_no() {
			return cust_no;
		}
		public void setCust_no(String cust_no) {
			this.cust_no = cust_no;
		}
		public String[] getClam_srh_srv_accd_srch_if__accd_rpt_no() {
			return clam_srh_srv_accd_srch_if__accd_rpt_no;
		}
		public void setClam_srh_srv_accd_srch_if__accd_rpt_no(
				String[] clam_srh_srv_accd_srch_if__accd_rpt_no) {
			this.clam_srh_srv_accd_srch_if__accd_rpt_no = clam_srh_srv_accd_srch_if__accd_rpt_no;
		}
		public String[] getClam_srh_srv_accd_srch_if__vh_no() {
			return clam_srh_srv_accd_srch_if__vh_no;
		}
		public void setClam_srh_srv_accd_srch_if__vh_no(
				String[] clam_srh_srv_accd_srch_if__vh_no) {
			this.clam_srh_srv_accd_srch_if__vh_no = clam_srh_srv_accd_srch_if__vh_no;
		}
		public String[] getClam_srh_srv_accd_srch_if__accd_dttm() {
			return clam_srh_srv_accd_srch_if__accd_dttm;
		}
		public void setClam_srh_srv_accd_srch_if__accd_dttm(
				String[] clam_srh_srv_accd_srch_if__accd_dttm) {
			this.clam_srh_srv_accd_srch_if__accd_dttm = clam_srh_srv_accd_srch_if__accd_dttm;
		}
		public String[] getClam_srh_srv_accd_srch_if__accd_prg_crs_cd() {
			return clam_srh_srv_accd_srch_if__accd_prg_crs_cd;
		}
		public void setClam_srh_srv_accd_srch_if__accd_prg_crs_cd(
				String[] clam_srh_srv_accd_srch_if__accd_prg_crs_cd) {
			this.clam_srh_srv_accd_srch_if__accd_prg_crs_cd = clam_srh_srv_accd_srch_if__accd_prg_crs_cd;
		}
		public String[] getClam_srh_srv_accd_srch_if__accd_prg_crs_cd_nm() {
			return clam_srh_srv_accd_srch_if__accd_prg_crs_cd_nm;
		}
		public void setClam_srh_srv_accd_srch_if__accd_prg_crs_cd_nm(
				String[] clam_srh_srv_accd_srch_if__accd_prg_crs_cd_nm) {
			this.clam_srh_srv_accd_srch_if__accd_prg_crs_cd_nm = clam_srh_srv_accd_srch_if__accd_prg_crs_cd_nm;
		}
		public String getHdlr_empno() {
			return hdlr_empno;
		}
		public void setHdlr_empno(String hdlr_empno) {
			this.hdlr_empno = hdlr_empno;
		}
}
