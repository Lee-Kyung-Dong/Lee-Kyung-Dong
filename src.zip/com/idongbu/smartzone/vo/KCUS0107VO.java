package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class KCUS0107VO extends CMMVO
{
	private String cust_if_csn_dvcd;     // 고객정보동의구분코드
	private String regt_mtd_dvcd;        // 등록방법구분코드
	private String csn_sr_dvcd;          // 동의출처구분코드
	private String hdlr_empno;           // 취급자사원번호
	private String cust_hngl_nm;         // 고객한글명
	private String cust_dcmt_no;         // 고객식별번호
	private String prn_if_clct_us_csn_yn;// 개인정보수집이용동의여부
	private String prn_if_srch_csn_yn;   // 개인정보조회동의여부
	private String prn_if_ofer_csn_yn;   // 개인정보제공동의여부
	private String sent_if_csn_yn;       // 민감정보동의여부
	private String prop_dcmt_if_csn_yn;  // 고유식별정보동의여부
	private String csn_dt;               // 동의일자
	private String cour_agnt_nm_1;       // 법정대리인명1
	private String cour_agnt_nm_2;       // 법정대리인명2
	private String cust_rqst_cn;         // 고객요청내용
	
	private String chn_dvn_dtl_cd;       // 채널구분상세코드
	private String csn_cnfm_if_dvcd;     // 동의확인정보구분코드
	private String csn_cnfm_if_val;      // 동의확인정보값
	private String cust_if_csn_no;       // 고객정보동의번호
	private String cust_exis_yn;         // 고객존재여부
	
	// 임시 시작
	public String errorCode;//에러코드
	public String z_msg_cd;//메시지 코드
	public String returnMessage;//메시지 내용
	
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getZ_msg_cd() {
		return z_msg_cd;
	}
	public void setZ_msg_cd(String z_msg_cd) {
		this.z_msg_cd = z_msg_cd;
	}
	public String getReturnMessage() {
		return returnMessage;
	}
	public void setReturnMessage(String returnMessage) {
		this.returnMessage = returnMessage;
	}
	
	public String getCust_if_csn_dvcd() {
		return cust_if_csn_dvcd;
	}
	public void setCust_if_csn_dvcd(String cust_if_csn_dvcd) {
		this.cust_if_csn_dvcd = cust_if_csn_dvcd;
	}
	public String getRegt_mtd_dvcd() {
		return regt_mtd_dvcd;
	}
	public void setRegt_mtd_dvcd(String regt_mtd_dvcd) {
		this.regt_mtd_dvcd = regt_mtd_dvcd;
	}
	public String getCsn_sr_dvcd() {
		return csn_sr_dvcd;
	}
	public void setCsn_sr_dvcd(String csn_sr_dvcd) {
		this.csn_sr_dvcd = csn_sr_dvcd;
	}
	public String getHdlr_empno() {
		return hdlr_empno;
	}
	public void setHdlr_empno(String hdlr_empno) {
		this.hdlr_empno = hdlr_empno;
	}
	public String getCust_hngl_nm() {
		return cust_hngl_nm;
	}
	public void setCust_hngl_nm(String cust_hngl_nm) {
		this.cust_hngl_nm = cust_hngl_nm;
	}
	public String getCust_dcmt_no() {
		return cust_dcmt_no;
	}
	public void setCust_dcmt_no(String cust_dcmt_no) {
		this.cust_dcmt_no = cust_dcmt_no;
	}
	public String getPrn_if_clct_us_csn_yn() {
		return prn_if_clct_us_csn_yn;
	}
	public void setPrn_if_clct_us_csn_yn(String prn_if_clct_us_csn_yn) {
		this.prn_if_clct_us_csn_yn = prn_if_clct_us_csn_yn;
	}
	public String getPrn_if_srch_csn_yn() {
		return prn_if_srch_csn_yn;
	}
	public void setPrn_if_srch_csn_yn(String prn_if_srch_csn_yn) {
		this.prn_if_srch_csn_yn = prn_if_srch_csn_yn;
	}
	public String getPrn_if_ofer_csn_yn() {
		return prn_if_ofer_csn_yn;
	}
	public void setPrn_if_ofer_csn_yn(String prn_if_ofer_csn_yn) {
		this.prn_if_ofer_csn_yn = prn_if_ofer_csn_yn;
	}
	public String getSent_if_csn_yn() {
		return sent_if_csn_yn;
	}
	public void setSent_if_csn_yn(String sent_if_csn_yn) {
		this.sent_if_csn_yn = sent_if_csn_yn;
	}
	public String getProp_dcmt_if_csn_yn() {
		return prop_dcmt_if_csn_yn;
	}
	public void setProp_dcmt_if_csn_yn(String prop_dcmt_if_csn_yn) {
		this.prop_dcmt_if_csn_yn = prop_dcmt_if_csn_yn;
	}
	public String getCsn_dt() {
		return csn_dt;
	}
	public void setCsn_dt(String csn_dt) {
		this.csn_dt = csn_dt;
	}
	public String getCour_agnt_nm_1() {
		return cour_agnt_nm_1;
	}
	public void setCour_agnt_nm_1(String cour_agnt_nm_1) {
		this.cour_agnt_nm_1 = cour_agnt_nm_1;
	}
	public String getCour_agnt_nm_2() {
		return cour_agnt_nm_2;
	}
	public void setCour_agnt_nm_2(String cour_agnt_nm_2) {
		this.cour_agnt_nm_2 = cour_agnt_nm_2;
	}
	public String getCust_rqst_cn() {
		return cust_rqst_cn;
	}
	public void setCust_rqst_cn(String cust_rqst_cn) {
		this.cust_rqst_cn = cust_rqst_cn;
	}
	public String getChn_dvn_dtl_cd() {
		return chn_dvn_dtl_cd;
	}
	public void setChn_dvn_dtl_cd(String chn_dvn_dtl_cd) {
		this.chn_dvn_dtl_cd = chn_dvn_dtl_cd;
	}
	public String getCsn_cnfm_if_dvcd() {
		return csn_cnfm_if_dvcd;
	}
	public void setCsn_cnfm_if_dvcd(String csn_cnfm_if_dvcd) {
		this.csn_cnfm_if_dvcd = csn_cnfm_if_dvcd;
	}
	public String getCsn_cnfm_if_val() {
		return csn_cnfm_if_val;
	}
	public void setCsn_cnfm_if_val(String csn_cnfm_if_val) {
		this.csn_cnfm_if_val = csn_cnfm_if_val;
	}
	public String getCust_if_csn_no() {
		return cust_if_csn_no;
	}
	public void setCust_if_csn_no(String cust_if_csn_no) {
		this.cust_if_csn_no = cust_if_csn_no;
	}
	public String getCust_exis_yn() {
		return cust_exis_yn;
	}
	public void setCust_exis_yn(String cust_exis_yn) {
		this.cust_exis_yn = cust_exis_yn;
	}
}
