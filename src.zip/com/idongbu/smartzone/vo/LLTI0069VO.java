package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class LLTI0069VO extends CMMVO{
	//전문필드
		public String chng_plno = "";  //[I] 변경증권번호 JJ_NGI_POLI_NO 변액증권번호
		public String plno = "";  //[I] 증권번호 JJ_POLI_NO 증권번호
		public String ins_lcpl_dvcd = "";  //[I] 피보험자소재지구분코드  
		public String ply_sqno = "";  //[I] 증권일련번호  
		public String ctrmf_no = "";  //[I] 계약변경번호 JJ_BESU_NO 베서번호
		public String ctrmf_no_1 = "";  //[I] 계약변경번호1 JJ_BESU_SEQ 베서번호
		public String slc_dvn_nm = "";  //[I] 선택구분명 JJ_SEL_GB 선택구분명
		public String pdc_cd = "";  //[O] 상품코드 JJ_BJ_CD 보종코드
		public String scy_dvn = "";  //[O] 단체구분 JJ_DANCHE_GB 단체구분
		public String inpd_nm = "";  //[O] 보종명 HJ_BJ_NAME 보종명
		public String arc_knd_nm = "";  //[O] 보험종류명 HJ_BJ_GBN 보험종류명
		public String cust_gr = "";  //[O] 고객등급 JJ_GOGEK_GB 고객등급
		public String arc_pd_dt = "";  //[O] 보험시기일자 JJ_BH_SYMD 보험시기
		public String arc_et_dt = "";  //[O] 보험종기일자 JJ_BH_EYMD 보험종기
		public String arc_trm_nm = "";  //[O] 보험기간명 HJ_BH_NM 보험기간명
		public String apl_dt = "";  //[O] 청약일자 JJ_CHUNG_YMD 청약일
		public String plhd_nm = "";  //[O] 계약자명 HJ_GYE_NAME 계약자명
		public String plhd_rrno_btpy_no = "";  //[O] 계약자주민등록번호사업자번호 JJ_GYE_JUMIN 계약자의　주민／사업자번호
		public String plhd_cntp_1 = "";  //[O] 계약자연락처1 JJ_GYE_TEL1 계약처연락처1
		public String plhd_cntp_2 = "";  //[O] 계약자연락처2 JJ_GYE_TEL2 계약처연락처2
		public String plhd_cntp_3 = "";  //[O] 계약자연락처3 JJ_GYE_TEL3 계약처연락처3
		public String ctry_nm = "";  //[O] 국가명 HJ_GUKGA_NM 국가명
		public String plhd_psno_1 = "";  //[O] 계약자우편번호1 JJ_GYE_ZIP1 계약자 우편번호1
		public String plhd_psno_2 = "";  //[O] 계약자우편번호2 JJ_GYE_ZIP2 계약자 우편번호2
		public String plhd_adr_1 = "";  //[O] 계약자주소1 HJ_GYE_ADDR1 계약자 주소1
		public String plhd_adr_2 = "";  //[O] 계약자주소2 HJ_GYE_ADDR2 계약자 주소2
		public String isu_dvn = "";  //[O] 발급구분 JJ_BALGUP_GB 발급구분
		public String isu_dvn_nm = "";  //[O] 발급구분명 HJ_BALGUP_NM 발급구분명
		public String ins_nm = "";  //[O] 피보험자명 HJ_PI_NAME 피보험자명
		public String ins_rrno_btpy_no = "";  //[O] 피보험자주민등록번호사업자번호 JJ_PI_JUMIN 피보험자　주민／사업자번호
		public String ins_inj_rtg = "";  //[O] 피보험자상해급수 JJ_GBSU_CD 피보험자　상해급수
		public String ctc_stat_nm = "";  //[O] 계약상태명 HJ_GYE_SANGTE 계약상태명
		public String stat_dt = "";  //[O] 상태일자 JJ_SANGTE_YMD 상태일자
		public String bh_cd = "";  //[O] 지점코드 JJ_C_JIJUM_CD 지점코드
		public String bh_nm = "";  //[O] 지점명 HJ_C_JIJUM_NM 지점명
		public String stat_amt = "";  //[O] 상태금액 JJ_C_GMEK 상태금액
		public String stat_amt_1 = "";  //[O] 상태금액1 HJ_C_NM 상태금액('원')
		public String prn_scy_dvcd = "";  //[O] 개인단체구분코드 HJ_TYPE 가입유형(개인／단체취급／단체)
		public String gnrl_mtt = "";  //[O] 일반사항 HJ_IL_SAHANG 일반사항
		public String asr_prm = "";  //[O] 보장보험료 JJ_BOJANG_PRM 보장보험료
		public String fnal_pym_yr = "";  //[O] 최종납입년도 JJ_L_NAPIP_YY 최종납입년
		public String fnal_pym_mon = "";  //[O] 최종납입월 JJ_L_NAPIP_MM 최종납입월
		public String pym_ycnt = "";  //[O] 납입년수 JJ_NAPIP_CNT 최종납입횟수
		public String appr_yr = "";  //[O] 인정년 JJ_INJUNG_YY 인정월도
		public String appr_mon = "";  //[O] 인정월 JJ_INJUNG_MM 인정월도
		public String pym_mtd_nm = "";  //[O] 납입방법명 HJ_BUNNAP_NM 납입방법명
		public String coll_mtd_nm = "";  //[O] 수금방법명 HJ_SU_BANGBAP 수금방법명
		public String bank_nm = "";  //[O] 은행명 HJ_BANK_NM 은행명
		public String tsfr_dd_cnt = "";  //[O] 이체일수 JJ_ICHE_ILSU 이체일수
		public String acc_no = "";  //[O] 계좌번호 JJ_GYEJA_NO 계좌번호
		public String dpsr_nm = "";  //[O] 예금주명 HJ_YEGUM_JU 예금주명
		public String ctrmf_yn = "";  //[O] 계약변경여부 HJ_BE_NM 배서여부
		public String ctrmf_nts = "";  //[O] 계약변경횟수 JJ_BE_CNT 배서횟수
		public String ln_mtt = "";  //[O] 대출사항 HJ_YAKGWAN 대출사항
		public String pmpt = "";  //[O] 납입면제 HJ_M_REM 납입면제
		public String pmpt_dt = "";  //[O] 납입면제일자 JJ_M_YMD 납입면제일
		public String aut_ln_aply_yn = "";  //[O] 자동대출신청여부 HJ_JADONG 자동대출신청여부
		public String aut_ln_aply_dt = "";  //[O] 자동대출신청일자 JJ_J_YMD 자동대출신청일
		public String tszr_fxng_yn = "";  //[O] 가압류설정유무 HJ_JIL_GA 가압류설정유무
		public String accd = "";  //[O] 사고  HJ_SAGO_NM 사고 
		public String accd_nts = "";  //[O] 사고횟수 JJ_SAGO_CNT 사고횟수
		public String accd_dd_1 = "";  //[O] 사고일1 JJ_SAGO_YMD1 사고일1
		public String accd_dd_2 = "";  //[O] 사고일2 JJ_SAGO_YMD2 사고일2
		public String accd_dd_3 = "";  //[O] 사고일3 JJ_SAGO_YMD3 사고일3
		public String last_dcs_ustk_conu_mtt = "";  //[O] 마지막확정인수품의사항 HJ_INSU_PUMI 최종확정인수품의　사항
		public String ply_isu_nts = "";  //[O] 증권발급횟수 JJ_BALGB_CNT 증권발급횟수
		public String ply_isu_dt = "";  //[O] 증권발급일자 JJ_BALGB_YMD 증권발급일
		public String cllt_bh_nm = "";  //[O] 모집지점명 HJ_M_JIJUM_NM 모집지점명
		public String cllt_brn_nm = "";  //[O] 모집지부명 HJ_M_JIBU_NM 모집지부명
		public String cllt_ep_nm = "";  //[O] 모집사원명 HJ_M_JOJIK_NM 모집조직원명
		public String cllt_bh_cd = "";  //[O] 모집지점코드 JJ_M_JIJUM_CD 모집지점코드
		public String cllt_brn_cd = "";  //[O] 모집지부코드 JJ_M_JIBU_CD 모집지부코드
		public String cllt_empno = "";  //[O] 모집사원번호 JJ_M_JOJIK_CD 모집조직원코드
		public String coll_ep_nm = "";  //[O] 수금사원명 HJ_S_JIJUM_NM 수금조직원명
		public String coll_brn_nm = "";  //[O] 수금지부명 HJ_S_JIBU_NM 수금지부명
		public String coll_ep_nm_1 = "";  //[O] 수금사원명1 HJ_S_JOJIK_NM 수금조직원명
		public String coll_bh_cd = "";  //[O] 수금지점코드 JJ_S_JIJUM_CD 수금지점코드
		public String coll_brn_cd = "";  //[O] 수금지부코드 JJ_S_JIBU_CD 수금지부코드
		public String coll_empno = "";  //[O] 수금사원번호 JJ_S_JOJIK_CD 수금조직원코드
		public String imag_regt_yn = "";  //[O] 이미지등록여부 JJ_IMAGE_YN IMAGE  등록　여부
		public String ustk_conu = "";  //[O] 인수품의 JJ_IMCHUL_YN 인수품의
		public String plsw_yn = "";  //[O] 승환계약여부 JJ-SEUNGHWAN-YN 승환계약유무
		public String cbl_trmt_csn_yn = "";  //[O] 유선해지동의여부 JJ-HEJI-YN  유선해지동의여부
		public String cbl_trmt_csn_yn_nm = "";  //[O] 유선해지동의여부명 HJ-HEJI-YN  유선해지동의여부
		public String plhd_nwod_adr_dvcd = "";  //[O] 계약자신구주소구분코드 JJ-G-SINGU-GB  계약자주소 신구구분
		public String lcpl_nwod_adr_dvcd = "";  //[O] 소재지신구주소구분코드  JJ-S-SINGU-GB 소재지주소 신구구분
		public String kpn_plno = "";  //[O] 보관증권번호 UU_POLI_NO 증권번호
		public String kpn_ins_lcpl_dvcd = "";  //[O] 보관피보험자소재지구분코드  
		public String kpn_ply_sqno = "";  //[O] 보관증권일련번호  
		public String kpn_ctrmf_no = "";  //[O] 보관계약변경번호 UU_BESU_NO 베서번호
		public String trsr_tszr_yn = "";  //[O] 총무가압류여부 HJ_C_JIL_GA 총무가압류여부]
		public String getChng_plno() {
			return chng_plno;
		}
		public void setChng_plno(String chng_plno) {
			this.chng_plno = chng_plno;
		}
		public String getPlno() {
			return plno;
		}
		public void setPlno(String plno) {
			this.plno = plno;
		}
		public String getIns_lcpl_dvcd() {
			return ins_lcpl_dvcd;
		}
		public void setIns_lcpl_dvcd(String ins_lcpl_dvcd) {
			this.ins_lcpl_dvcd = ins_lcpl_dvcd;
		}
		public String getPly_sqno() {
			return ply_sqno;
		}
		public void setPly_sqno(String ply_sqno) {
			this.ply_sqno = ply_sqno;
		}
		public String getCtrmf_no() {
			return ctrmf_no;
		}
		public void setCtrmf_no(String ctrmf_no) {
			this.ctrmf_no = ctrmf_no;
		}
		public String getCtrmf_no_1() {
			return ctrmf_no_1;
		}
		public void setCtrmf_no_1(String ctrmf_no_1) {
			this.ctrmf_no_1 = ctrmf_no_1;
		}
		public String getSlc_dvn_nm() {
			return slc_dvn_nm;
		}
		public void setSlc_dvn_nm(String slc_dvn_nm) {
			this.slc_dvn_nm = slc_dvn_nm;
		}
		public String getPdc_cd() {
			return pdc_cd;
		}
		public void setPdc_cd(String pdc_cd) {
			this.pdc_cd = pdc_cd;
		}
		public String getScy_dvn() {
			return scy_dvn;
		}
		public void setScy_dvn(String scy_dvn) {
			this.scy_dvn = scy_dvn;
		}
		public String getInpd_nm() {
			return inpd_nm;
		}
		public void setInpd_nm(String inpd_nm) {
			this.inpd_nm = inpd_nm;
		}
		public String getArc_knd_nm() {
			return arc_knd_nm;
		}
		public void setArc_knd_nm(String arc_knd_nm) {
			this.arc_knd_nm = arc_knd_nm;
		}
		public String getCust_gr() {
			return cust_gr;
		}
		public void setCust_gr(String cust_gr) {
			this.cust_gr = cust_gr;
		}
		public String getArc_pd_dt() {
			return arc_pd_dt;
		}
		public void setArc_pd_dt(String arc_pd_dt) {
			this.arc_pd_dt = arc_pd_dt;
		}
		public String getArc_et_dt() {
			return arc_et_dt;
		}
		public void setArc_et_dt(String arc_et_dt) {
			this.arc_et_dt = arc_et_dt;
		}
		public String getArc_trm_nm() {
			return arc_trm_nm;
		}
		public void setArc_trm_nm(String arc_trm_nm) {
			this.arc_trm_nm = arc_trm_nm;
		}
		public String getApl_dt() {
			return apl_dt;
		}
		public void setApl_dt(String apl_dt) {
			this.apl_dt = apl_dt;
		}
		public String getPlhd_nm() {
			return plhd_nm;
		}
		public void setPlhd_nm(String plhd_nm) {
			this.plhd_nm = plhd_nm;
		}
		public String getPlhd_rrno_btpy_no() {
			return plhd_rrno_btpy_no;
		}
		public void setPlhd_rrno_btpy_no(String plhd_rrno_btpy_no) {
			this.plhd_rrno_btpy_no = plhd_rrno_btpy_no;
		}
		public String getPlhd_cntp_1() {
			return plhd_cntp_1;
		}
		public void setPlhd_cntp_1(String plhd_cntp_1) {
			this.plhd_cntp_1 = plhd_cntp_1;
		}
		public String getPlhd_cntp_2() {
			return plhd_cntp_2;
		}
		public void setPlhd_cntp_2(String plhd_cntp_2) {
			this.plhd_cntp_2 = plhd_cntp_2;
		}
		public String getPlhd_cntp_3() {
			return plhd_cntp_3;
		}
		public void setPlhd_cntp_3(String plhd_cntp_3) {
			this.plhd_cntp_3 = plhd_cntp_3;
		}
		public String getCtry_nm() {
			return ctry_nm;
		}
		public void setCtry_nm(String ctry_nm) {
			this.ctry_nm = ctry_nm;
		}
		public String getPlhd_psno_1() {
			return plhd_psno_1;
		}
		public void setPlhd_psno_1(String plhd_psno_1) {
			this.plhd_psno_1 = plhd_psno_1;
		}
		public String getPlhd_psno_2() {
			return plhd_psno_2;
		}
		public void setPlhd_psno_2(String plhd_psno_2) {
			this.plhd_psno_2 = plhd_psno_2;
		}
		public String getPlhd_adr_1() {
			return plhd_adr_1;
		}
		public void setPlhd_adr_1(String plhd_adr_1) {
			this.plhd_adr_1 = plhd_adr_1;
		}
		public String getPlhd_adr_2() {
			return plhd_adr_2;
		}
		public void setPlhd_adr_2(String plhd_adr_2) {
			this.plhd_adr_2 = plhd_adr_2;
		}
		public String getIsu_dvn() {
			return isu_dvn;
		}
		public void setIsu_dvn(String isu_dvn) {
			this.isu_dvn = isu_dvn;
		}
		public String getIsu_dvn_nm() {
			return isu_dvn_nm;
		}
		public void setIsu_dvn_nm(String isu_dvn_nm) {
			this.isu_dvn_nm = isu_dvn_nm;
		}
		public String getIns_nm() {
			return ins_nm;
		}
		public void setIns_nm(String ins_nm) {
			this.ins_nm = ins_nm;
		}
		public String getIns_rrno_btpy_no() {
			return ins_rrno_btpy_no;
		}
		public void setIns_rrno_btpy_no(String ins_rrno_btpy_no) {
			this.ins_rrno_btpy_no = ins_rrno_btpy_no;
		}
		public String getIns_inj_rtg() {
			return ins_inj_rtg;
		}
		public void setIns_inj_rtg(String ins_inj_rtg) {
			this.ins_inj_rtg = ins_inj_rtg;
		}
		public String getCtc_stat_nm() {
			return ctc_stat_nm;
		}
		public void setCtc_stat_nm(String ctc_stat_nm) {
			this.ctc_stat_nm = ctc_stat_nm;
		}
		public String getStat_dt() {
			return stat_dt;
		}
		public void setStat_dt(String stat_dt) {
			this.stat_dt = stat_dt;
		}
		public String getBh_cd() {
			return bh_cd;
		}
		public void setBh_cd(String bh_cd) {
			this.bh_cd = bh_cd;
		}
		public String getBh_nm() {
			return bh_nm;
		}
		public void setBh_nm(String bh_nm) {
			this.bh_nm = bh_nm;
		}
		public String getStat_amt() {
			return stat_amt;
		}
		public void setStat_amt(String stat_amt) {
			this.stat_amt = stat_amt;
		}
		public String getStat_amt_1() {
			return stat_amt_1;
		}
		public void setStat_amt_1(String stat_amt_1) {
			this.stat_amt_1 = stat_amt_1;
		}
		public String getPrn_scy_dvcd() {
			return prn_scy_dvcd;
		}
		public void setPrn_scy_dvcd(String prn_scy_dvcd) {
			this.prn_scy_dvcd = prn_scy_dvcd;
		}
		public String getGnrl_mtt() {
			return gnrl_mtt;
		}
		public void setGnrl_mtt(String gnrl_mtt) {
			this.gnrl_mtt = gnrl_mtt;
		}
		public String getAsr_prm() {
			return asr_prm;
		}
		public void setAsr_prm(String asr_prm) {
			this.asr_prm = asr_prm;
		}
		public String getFnal_pym_yr() {
			return fnal_pym_yr;
		}
		public void setFnal_pym_yr(String fnal_pym_yr) {
			this.fnal_pym_yr = fnal_pym_yr;
		}
		public String getFnal_pym_mon() {
			return fnal_pym_mon;
		}
		public void setFnal_pym_mon(String fnal_pym_mon) {
			this.fnal_pym_mon = fnal_pym_mon;
		}
		public String getPym_ycnt() {
			return pym_ycnt;
		}
		public void setPym_ycnt(String pym_ycnt) {
			this.pym_ycnt = pym_ycnt;
		}
		public String getAppr_yr() {
			return appr_yr;
		}
		public void setAppr_yr(String appr_yr) {
			this.appr_yr = appr_yr;
		}
		public String getAppr_mon() {
			return appr_mon;
		}
		public void setAppr_mon(String appr_mon) {
			this.appr_mon = appr_mon;
		}
		public String getPym_mtd_nm() {
			return pym_mtd_nm;
		}
		public void setPym_mtd_nm(String pym_mtd_nm) {
			this.pym_mtd_nm = pym_mtd_nm;
		}
		public String getColl_mtd_nm() {
			return coll_mtd_nm;
		}
		public void setColl_mtd_nm(String coll_mtd_nm) {
			this.coll_mtd_nm = coll_mtd_nm;
		}
		public String getBank_nm() {
			return bank_nm;
		}
		public void setBank_nm(String bank_nm) {
			this.bank_nm = bank_nm;
		}
		public String getTsfr_dd_cnt() {
			return tsfr_dd_cnt;
		}
		public void setTsfr_dd_cnt(String tsfr_dd_cnt) {
			this.tsfr_dd_cnt = tsfr_dd_cnt;
		}
		public String getAcc_no() {
			return acc_no;
		}
		public void setAcc_no(String acc_no) {
			this.acc_no = acc_no;
		}
		public String getDpsr_nm() {
			return dpsr_nm;
		}
		public void setDpsr_nm(String dpsr_nm) {
			this.dpsr_nm = dpsr_nm;
		}
		public String getCtrmf_yn() {
			return ctrmf_yn;
		}
		public void setCtrmf_yn(String ctrmf_yn) {
			this.ctrmf_yn = ctrmf_yn;
		}
		public String getCtrmf_nts() {
			return ctrmf_nts;
		}
		public void setCtrmf_nts(String ctrmf_nts) {
			this.ctrmf_nts = ctrmf_nts;
		}
		public String getLn_mtt() {
			return ln_mtt;
		}
		public void setLn_mtt(String ln_mtt) {
			this.ln_mtt = ln_mtt;
		}
		public String getPmpt() {
			return pmpt;
		}
		public void setPmpt(String pmpt) {
			this.pmpt = pmpt;
		}
		public String getPmpt_dt() {
			return pmpt_dt;
		}
		public void setPmpt_dt(String pmpt_dt) {
			this.pmpt_dt = pmpt_dt;
		}
		public String getAut_ln_aply_yn() {
			return aut_ln_aply_yn;
		}
		public void setAut_ln_aply_yn(String aut_ln_aply_yn) {
			this.aut_ln_aply_yn = aut_ln_aply_yn;
		}
		public String getAut_ln_aply_dt() {
			return aut_ln_aply_dt;
		}
		public void setAut_ln_aply_dt(String aut_ln_aply_dt) {
			this.aut_ln_aply_dt = aut_ln_aply_dt;
		}
		public String getTszr_fxng_yn() {
			return tszr_fxng_yn;
		}
		public void setTszr_fxng_yn(String tszr_fxng_yn) {
			this.tszr_fxng_yn = tszr_fxng_yn;
		}
		public String getAccd() {
			return accd;
		}
		public void setAccd(String accd) {
			this.accd = accd;
		}
		public String getAccd_nts() {
			return accd_nts;
		}
		public void setAccd_nts(String accd_nts) {
			this.accd_nts = accd_nts;
		}
		public String getAccd_dd_1() {
			return accd_dd_1;
		}
		public void setAccd_dd_1(String accd_dd_1) {
			this.accd_dd_1 = accd_dd_1;
		}
		public String getAccd_dd_2() {
			return accd_dd_2;
		}
		public void setAccd_dd_2(String accd_dd_2) {
			this.accd_dd_2 = accd_dd_2;
		}
		public String getAccd_dd_3() {
			return accd_dd_3;
		}
		public void setAccd_dd_3(String accd_dd_3) {
			this.accd_dd_3 = accd_dd_3;
		}
		public String getLast_dcs_ustk_conu_mtt() {
			return last_dcs_ustk_conu_mtt;
		}
		public void setLast_dcs_ustk_conu_mtt(String last_dcs_ustk_conu_mtt) {
			this.last_dcs_ustk_conu_mtt = last_dcs_ustk_conu_mtt;
		}
		public String getPly_isu_nts() {
			return ply_isu_nts;
		}
		public void setPly_isu_nts(String ply_isu_nts) {
			this.ply_isu_nts = ply_isu_nts;
		}
		public String getPly_isu_dt() {
			return ply_isu_dt;
		}
		public void setPly_isu_dt(String ply_isu_dt) {
			this.ply_isu_dt = ply_isu_dt;
		}
		public String getCllt_bh_nm() {
			return cllt_bh_nm;
		}
		public void setCllt_bh_nm(String cllt_bh_nm) {
			this.cllt_bh_nm = cllt_bh_nm;
		}
		public String getCllt_brn_nm() {
			return cllt_brn_nm;
		}
		public void setCllt_brn_nm(String cllt_brn_nm) {
			this.cllt_brn_nm = cllt_brn_nm;
		}
		public String getCllt_ep_nm() {
			return cllt_ep_nm;
		}
		public void setCllt_ep_nm(String cllt_ep_nm) {
			this.cllt_ep_nm = cllt_ep_nm;
		}
		public String getCllt_bh_cd() {
			return cllt_bh_cd;
		}
		public void setCllt_bh_cd(String cllt_bh_cd) {
			this.cllt_bh_cd = cllt_bh_cd;
		}
		public String getCllt_brn_cd() {
			return cllt_brn_cd;
		}
		public void setCllt_brn_cd(String cllt_brn_cd) {
			this.cllt_brn_cd = cllt_brn_cd;
		}
		public String getCllt_empno() {
			return cllt_empno;
		}
		public void setCllt_empno(String cllt_empno) {
			this.cllt_empno = cllt_empno;
		}
		public String getColl_ep_nm() {
			return coll_ep_nm;
		}
		public void setColl_ep_nm(String coll_ep_nm) {
			this.coll_ep_nm = coll_ep_nm;
		}
		public String getColl_brn_nm() {
			return coll_brn_nm;
		}
		public void setColl_brn_nm(String coll_brn_nm) {
			this.coll_brn_nm = coll_brn_nm;
		}
		public String getColl_ep_nm_1() {
			return coll_ep_nm_1;
		}
		public void setColl_ep_nm_1(String coll_ep_nm_1) {
			this.coll_ep_nm_1 = coll_ep_nm_1;
		}
		public String getColl_bh_cd() {
			return coll_bh_cd;
		}
		public void setColl_bh_cd(String coll_bh_cd) {
			this.coll_bh_cd = coll_bh_cd;
		}
		public String getColl_brn_cd() {
			return coll_brn_cd;
		}
		public void setColl_brn_cd(String coll_brn_cd) {
			this.coll_brn_cd = coll_brn_cd;
		}
		public String getColl_empno() {
			return coll_empno;
		}
		public void setColl_empno(String coll_empno) {
			this.coll_empno = coll_empno;
		}
		public String getImag_regt_yn() {
			return imag_regt_yn;
		}
		public void setImag_regt_yn(String imag_regt_yn) {
			this.imag_regt_yn = imag_regt_yn;
		}
		public String getUstk_conu() {
			return ustk_conu;
		}
		public void setUstk_conu(String ustk_conu) {
			this.ustk_conu = ustk_conu;
		}
		public String getPlsw_yn() {
			return plsw_yn;
		}
		public void setPlsw_yn(String plsw_yn) {
			this.plsw_yn = plsw_yn;
		}
		public String getCbl_trmt_csn_yn() {
			return cbl_trmt_csn_yn;
		}
		public void setCbl_trmt_csn_yn(String cbl_trmt_csn_yn) {
			this.cbl_trmt_csn_yn = cbl_trmt_csn_yn;
		}
		public String getCbl_trmt_csn_yn_nm() {
			return cbl_trmt_csn_yn_nm;
		}
		public void setCbl_trmt_csn_yn_nm(String cbl_trmt_csn_yn_nm) {
			this.cbl_trmt_csn_yn_nm = cbl_trmt_csn_yn_nm;
		}
		public String getPlhd_nwod_adr_dvcd() {
			return plhd_nwod_adr_dvcd;
		}
		public void setPlhd_nwod_adr_dvcd(String plhd_nwod_adr_dvcd) {
			this.plhd_nwod_adr_dvcd = plhd_nwod_adr_dvcd;
		}
		public String getLcpl_nwod_adr_dvcd() {
			return lcpl_nwod_adr_dvcd;
		}
		public void setLcpl_nwod_adr_dvcd(String lcpl_nwod_adr_dvcd) {
			this.lcpl_nwod_adr_dvcd = lcpl_nwod_adr_dvcd;
		}
		public String getKpn_plno() {
			return kpn_plno;
		}
		public void setKpn_plno(String kpn_plno) {
			this.kpn_plno = kpn_plno;
		}
		public String getKpn_ins_lcpl_dvcd() {
			return kpn_ins_lcpl_dvcd;
		}
		public void setKpn_ins_lcpl_dvcd(String kpn_ins_lcpl_dvcd) {
			this.kpn_ins_lcpl_dvcd = kpn_ins_lcpl_dvcd;
		}
		public String getKpn_ply_sqno() {
			return kpn_ply_sqno;
		}
		public void setKpn_ply_sqno(String kpn_ply_sqno) {
			this.kpn_ply_sqno = kpn_ply_sqno;
		}
		public String getKpn_ctrmf_no() {
			return kpn_ctrmf_no;
		}
		public void setKpn_ctrmf_no(String kpn_ctrmf_no) {
			this.kpn_ctrmf_no = kpn_ctrmf_no;
		}
		public String getTrsr_tszr_yn() {
			return trsr_tszr_yn;
		}
		public void setTrsr_tszr_yn(String trsr_tszr_yn) {
			this.trsr_tszr_yn = trsr_tszr_yn;
		}
		
		
}
