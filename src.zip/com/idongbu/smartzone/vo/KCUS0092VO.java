package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class KCUS0092VO extends CMMVO{
	public String ars_com_leng = null;				//[I]ARS통신길이               
	public String ars_proc_id = null;               //[I]ARS처리ID                 
	public String rtun_cd = null;                   //[O]리턴코드                  
	public String proc_dvn = null;                  //[I]처리구분                  
	public String sos_srv_rpt_no = null;            //[I]SOS서비스접수번호         
	public String rpt_dttm = null;                  //[I]접수일시                  
	//public String sos_dvn = null;                 //[I]SOS구분                   
	public String hngl_vh_no = null;                //[I]차량번호                  
	public String dmdr_rrno = null;              	//[I]요청자주민번호            
	public String plno = null;                      //[I]증권번호                  
	public String dmdr_nm = null;                   //[I]요청자                    
	public String dmdr_rlt_cd = null;               //[I]요청자관계코드            
	//public String cntp_tlno_1 = null;             //[I]요청자전화지역번호1       
	//public String dmdr_tlp_ofno_1 = null;         //[I]요청자전화국번호1         
	//public String dmdr_tlp_idvno_1 = null;        //[I]요청자전화개별번호1       
	public String cntp_tlno_1 = null;               //[]연락처전화번호1            
	public String sos_cntp_rlt_cd_1 = null;         //[I]요청자구분1               
	//public String dmdr_tlp_arno_2 = null;         //[I]요청자전화지역번호2       
	//public String dmdr_tlp_ofno_2 = null;         //[I]요청자전화국번호2         
	//public String dmdr_tlp_idvno_2 = null;        //[I]요청자전화개별번호2       
	public String cntp_tlno_2 = null;               //[]연락처전화번호1            
	public String sos_cntp_rlt_cd_2 = null;         //[I]요청자구분2               
	public String dmdr_dvn_3 = null;                //[I]요청자구분3               
	public String cust_psno = null;                 //[I]요청지역우편번호          
	public String cust_eta_adr = null;              //[I]요청지역기타번지          
	public String cust_rqst_cn = null;              //[I]요청내용                  
	public String rqst_cn_2 = null;                 //[I]요청내용2                 
	public String sos_cpr_bzaq_no = null;           //[I]SOS협력거래처번호         
	public String cpr_ntp_cnvps_nm = null;          //[I]업체통화자                
	public String cpr_ntp_cmn_dttm = null;          //[I]업체통화일자              
	public String srv_rcvr_empno = null;            //[I]서비스접수자사원번호      
	public String srv_proc_cn = null;               //[I]서비스처리내용            
	public String proc_rsl_cd = null;               //[I]SOS처리결과코드           
	//public String ustd_cd = null;                 //[I]양해코드                  
	//public String ustd_ep = null;                 //[I]양해사원                  
	//public String ustd_dt = null;                 //[I]양해일자                  
	public String srv_proc_rqm_time = null;         //[I]서비스처리소요시간        
	public String srv_proc_cpr_ntp_cnvps_nm = null; //[I]서비스처리협력업체통화자명
	public String srv_bsc_amt = null;               //[I]서비스기본금액            
	public String srv_proc_dttm = null;             //[I]도착일자                  
	public String sos_srv_dst_dvn = null;           //[I]SOS서비스할인구분코드     
	public String srv_dst_amt = null;               //[I]서비스할인금액            
	public String cust_altm = null;                 //[I]고객부담금                
	public String sos_mntr_stat_cd = null;          //[I]모니터링상태코드          
	public String proc_cn = null;                   //[I]처리내용                  
	//public String proc_cn_2 = null;               //[I]처리내용2                 
	//public String proc_cn_3 = null;               //[I]처리내용3                 
	//public String proc_cn_4 = null;               //[I]처리내용4                 
	//public String proc_cn_5 = null;               //[I]처리내용5                 
	//public String proc_cn_6 = null;               //[I]처리내용6                 
	public String frst_ipmn_empno = null;           //[I]최조입력자사원번호        
	public String frst_inpt_dttm = null;            //[I]최초입력일시              
	//public String ipt_dt = null;                  //[I]검사일자                  
	public String sos_tty_dvcd = null;              //[I]SOS특약구분코드           
	public String cust_hngl_nm = null;              //[I]피보험자명                
	//public String ins_cd = null;                  //[I]피보험자코드              
	public String pdc_cd = null;                    //[I]상품코드                  
	//public String crnm_cd = null;                 //[I]차명코드                  
	public String crnm = null;                      //[I]차명                      
	public String sos_benf_tgt_yn = null;           //[I]SOS수혜대상여부           
	public String sos_ntrg_rs_cd = null;            //[I]SOS비대상사유코드         
	//public String tty_nm = null;                  //[I]특약명                    
	public String fnal_updt_dttm = null;            //[I]최종수정일시              
	public String fnal_amdr_empno = null;           //[I]최종수정자사원번호        
	public String sos_srv_ctp_dvcd = null;          //[I]SOS서비스차종구분코드     
	public String srv_crnm = null;              	//[I]SOS서비스차명             
	//public String ipt_dvn = null;                 //[I]검사구분                  
	//public String ipt_altm = null;                //[I]검사부담금                
	public String sos_rpt_area_dvcd = null;         //[I]SOS접수지역구분코드       
	//public String sccr_cd = null;                 //[I]폐차코드                  
	public String ctp_cd = null;                    //[I]차종코드                  
	//public String rpdt_pnt = null;                //[I]신속점수                  
	//public String stft_pnt = null;                //[I]만족점수                  
	//public String mng_pnt = null;                 //[I]조치점수                  
	public String sos_proc_rsl_cd = null;           //[I]SOS처리결과코드           
	public String fuln_ofer_yn = null;              //[I]택배여부                  
	public String sos_wrhs_bzaq_no = null;          //[I]SOS입고거래처번호         
	public String sos_wrhs_rs_cd = null;            //[I]SOS입고사유코드           
	public String wrhs_ntp_nm = null;               //[I]입고업체명                
	public String sos_dst_tpcd = null;              //[I]SOS할인유형코드           
	public String sos_dst_typ_ptl_cd = null;        //[I]SOS할인유형세부코드       
	public String dst_rs_cn = null;                 //[I]할인사유내용              
	public String sos_xtr_tpcd = null;              //[I]SOS할증유형코드           
	public String sos_xtr_typ_ptl_cd = null;        //[I]SOS할증유형세부코드       
	public String xtr_add_dstc = null;              //[I]할증추가거리              
	public String mvt_agt_nm = null;                //[I]출동요원명                
	public String mvt_agt_clp_tlcno = null;         //[I]출동요원휴대폰통신사번호  
	public String mvt_agt_clp_ofno = null;          //[I]출동요원휴대폰국번호      
	public String mvt_agt_clp_idvno = null;         //[I]출동요원휴대폰개별번호    
	public String sms_mvt_agt_ts_yn = null;         //[I]SMS출동요원전송여부       
	public String sms_mvt_agt_ts_dttm = null;       //[I]SMS출동요원전송일시       
	public String sms_cust_ts_yn = null;            //[I]SMS고객전송여부           
	public String sms_cust_ts_dttm = null;          //[I]SMS고객전송일자           
	public String tw_exn_tty_eny_yn = null;         //[I]견인확대특약가입여부      
	//public String sms_snd_yn = null;              //[I]SMS발송여부               
	//public String sms_hdlr_cd = null;             //[I]SMS취급자코드             
	//public String sms_clp_1 = null;               //[I]SMS휴대폰1                
	//public String sms_clp_2 = null;               //[I]SMS휴대폰2                
	//public String sms_clp_3 = null;               //[I]SMS휴대폰3                
	public String nwod_psno_dvcd = null;            //[I]주소신/구구분             
	public String pst_road_nm_adr = null;           //[I]도로명주소                
	public String cust_eta_adr_2 = null;            //[I]도로명상세주소            
	public String trv_dstc_tty_eny_yn = null;       //[I]주행거리특약가입여부      
	public String trv_dstc_tty_sms_ts_yn = null;    //[I]주행거리특약SMS전송여부   
	public String fnal_trv_dstc = null;             //[I]주행거리                  
	public String fnal_trv_dstc_inpt_dttm = null;   //[I]주행거리확인일            
	public String phgp_strg_yn = null;              //[I]주행거리사진첨부여부      
	public String emg_mvt_upc_cd = null;            //[I]긴급출동단가코드          
	public String emg_mvt_grcd = null;              //[I]긴급출동등급코드          
	public String mlg_amt = null;                   //[I]마일리지금액 
	
	
	public String errorCode = null;
	
	
	public String getArs_com_leng() {
		return ars_com_leng;
	}
	public void setArs_com_leng(String ars_com_leng) {
		this.ars_com_leng = ars_com_leng;
	}
	public String getArs_proc_id() {
		return ars_proc_id;
	}
	public void setArs_proc_id(String ars_proc_id) {
		this.ars_proc_id = ars_proc_id;
	}
	public String getRtun_cd() {
		return rtun_cd;
	}
	public void setRtun_cd(String rtun_cd) {
		this.rtun_cd = rtun_cd;
	}
	public String getProc_dvn() {
		return proc_dvn;
	}
	public void setProc_dvn(String proc_dvn) {
		this.proc_dvn = proc_dvn;
	}
	public String getSos_srv_rpt_no() {
		return sos_srv_rpt_no;
	}
	public void setSos_srv_rpt_no(String sos_srv_rpt_no) {
		this.sos_srv_rpt_no = sos_srv_rpt_no;
	}
	public String getRpt_dttm() {
		return rpt_dttm;
	}
	public void setRpt_dttm(String rpt_dttm) {
		this.rpt_dttm = rpt_dttm;
	}
	public String getHngl_vh_no() {
		return hngl_vh_no;
	}
	public void setHngl_vh_no(String hngl_vh_no) {
		this.hngl_vh_no = hngl_vh_no;
	}
	public String getDmdr_rrno() {
		return dmdr_rrno;
	}
	public void setDmdr_rrno(String dmdr_rrno) {
		this.dmdr_rrno = dmdr_rrno;
	}
	public String getPlno() {
		return plno;
	}
	public void setPlno(String plno) {
		this.plno = plno;
	}
	public String getDmdr_nm() {
		return dmdr_nm;
	}
	public void setDmdr_nm(String dmdr_nm) {
		this.dmdr_nm = dmdr_nm;
	}
	public String getDmdr_rlt_cd() {
		return dmdr_rlt_cd;
	}
	public void setDmdr_rlt_cd(String dmdr_rlt_cd) {
		this.dmdr_rlt_cd = dmdr_rlt_cd;
	}
	public String getCntp_tlno_1() {
		return cntp_tlno_1;
	}
	public void setCntp_tlno_1(String cntp_tlno_1) {
		this.cntp_tlno_1 = cntp_tlno_1;
	}
	public String getSos_cntp_rlt_cd_1() {
		return sos_cntp_rlt_cd_1;
	}
	public void setSos_cntp_rlt_cd_1(String sos_cntp_rlt_cd_1) {
		this.sos_cntp_rlt_cd_1 = sos_cntp_rlt_cd_1;
	}
	public String getCntp_tlno_2() {
		return cntp_tlno_2;
	}
	public void setCntp_tlno_2(String cntp_tlno_2) {
		this.cntp_tlno_2 = cntp_tlno_2;
	}
	public String getSos_cntp_rlt_cd_2() {
		return sos_cntp_rlt_cd_2;
	}
	public void setSos_cntp_rlt_cd_2(String sos_cntp_rlt_cd_2) {
		this.sos_cntp_rlt_cd_2 = sos_cntp_rlt_cd_2;
	}
	public String getDmdr_dvn_3() {
		return dmdr_dvn_3;
	}
	public void setDmdr_dvn_3(String dmdr_dvn_3) {
		this.dmdr_dvn_3 = dmdr_dvn_3;
	}
	public String getCust_psno() {
		return cust_psno;
	}
	public void setCust_psno(String cust_psno) {
		this.cust_psno = cust_psno;
	}
	public String getCust_eta_adr() {
		return cust_eta_adr;
	}
	public void setCust_eta_adr(String cust_eta_adr) {
		this.cust_eta_adr = cust_eta_adr;
	}
	public String getCust_rqst_cn() {
		return cust_rqst_cn;
	}
	public void setCust_rqst_cn(String cust_rqst_cn) {
		this.cust_rqst_cn = cust_rqst_cn;
	}
	public String getRqst_cn_2() {
		return rqst_cn_2;
	}
	public void setRqst_cn_2(String rqst_cn_2) {
		this.rqst_cn_2 = rqst_cn_2;
	}
	public String getSos_cpr_bzaq_no() {
		return sos_cpr_bzaq_no;
	}
	public void setSos_cpr_bzaq_no(String sos_cpr_bzaq_no) {
		this.sos_cpr_bzaq_no = sos_cpr_bzaq_no;
	}
	public String getCpr_ntp_cnvps_nm() {
		return cpr_ntp_cnvps_nm;
	}
	public void setCpr_ntp_cnvps_nm(String cpr_ntp_cnvps_nm) {
		this.cpr_ntp_cnvps_nm = cpr_ntp_cnvps_nm;
	}
	public String getCpr_ntp_cmn_dttm() {
		return cpr_ntp_cmn_dttm;
	}
	public void setCpr_ntp_cmn_dttm(String cpr_ntp_cmn_dttm) {
		this.cpr_ntp_cmn_dttm = cpr_ntp_cmn_dttm;
	}
	public String getSrv_rcvr_empno() {
		return srv_rcvr_empno;
	}
	public void setSrv_rcvr_empno(String srv_rcvr_empno) {
		this.srv_rcvr_empno = srv_rcvr_empno;
	}
	public String getSrv_proc_cn() {
		return srv_proc_cn;
	}
	public void setSrv_proc_cn(String srv_proc_cn) {
		this.srv_proc_cn = srv_proc_cn;
	}
	public String getProc_rsl_cd() {
		return proc_rsl_cd;
	}
	public void setProc_rsl_cd(String proc_rsl_cd) {
		this.proc_rsl_cd = proc_rsl_cd;
	}
	public String getSrv_proc_rqm_time() {
		return srv_proc_rqm_time;
	}
	public void setSrv_proc_rqm_time(String srv_proc_rqm_time) {
		this.srv_proc_rqm_time = srv_proc_rqm_time;
	}
	public String getSrv_proc_cpr_ntp_cnvps_nm() {
		return srv_proc_cpr_ntp_cnvps_nm;
	}
	public void setSrv_proc_cpr_ntp_cnvps_nm(String srv_proc_cpr_ntp_cnvps_nm) {
		this.srv_proc_cpr_ntp_cnvps_nm = srv_proc_cpr_ntp_cnvps_nm;
	}
	public String getSrv_bsc_amt() {
		return srv_bsc_amt;
	}
	public void setSrv_bsc_amt(String srv_bsc_amt) {
		this.srv_bsc_amt = srv_bsc_amt;
	}
	public String getSrv_proc_dttm() {
		return srv_proc_dttm;
	}
	public void setSrv_proc_dttm(String srv_proc_dttm) {
		this.srv_proc_dttm = srv_proc_dttm;
	}
	public String getSos_srv_dst_dvn() {
		return sos_srv_dst_dvn;
	}
	public void setSos_srv_dst_dvn(String sos_srv_dst_dvn) {
		this.sos_srv_dst_dvn = sos_srv_dst_dvn;
	}
	public String getSrv_dst_amt() {
		return srv_dst_amt;
	}
	public void setSrv_dst_amt(String srv_dst_amt) {
		this.srv_dst_amt = srv_dst_amt;
	}
	public String getCust_altm() {
		return cust_altm;
	}
	public void setCust_altm(String cust_altm) {
		this.cust_altm = cust_altm;
	}
	public String getSos_mntr_stat_cd() {
		return sos_mntr_stat_cd;
	}
	public void setSos_mntr_stat_cd(String sos_mntr_stat_cd) {
		this.sos_mntr_stat_cd = sos_mntr_stat_cd;
	}
	public String getProc_cn() {
		return proc_cn;
	}
	public void setProc_cn(String proc_cn) {
		this.proc_cn = proc_cn;
	}
	public String getFrst_ipmn_empno() {
		return frst_ipmn_empno;
	}
	public void setFrst_ipmn_empno(String frst_ipmn_empno) {
		this.frst_ipmn_empno = frst_ipmn_empno;
	}
	public String getFrst_inpt_dttm() {
		return frst_inpt_dttm;
	}
	public void setFrst_inpt_dttm(String frst_inpt_dttm) {
		this.frst_inpt_dttm = frst_inpt_dttm;
	}
	public String getSos_tty_dvcd() {
		return sos_tty_dvcd;
	}
	public void setSos_tty_dvcd(String sos_tty_dvcd) {
		this.sos_tty_dvcd = sos_tty_dvcd;
	}
	public String getCust_hngl_nm() {
		return cust_hngl_nm;
	}
	public void setCust_hngl_nm(String cust_hngl_nm) {
		this.cust_hngl_nm = cust_hngl_nm;
	}
	public String getPdc_cd() {
		return pdc_cd;
	}
	public void setPdc_cd(String pdc_cd) {
		this.pdc_cd = pdc_cd;
	}
	public String getCrnm() {
		return crnm;
	}
	public void setCrnm(String crnm) {
		this.crnm = crnm;
	}
	public String getSos_benf_tgt_yn() {
		return sos_benf_tgt_yn;
	}
	public void setSos_benf_tgt_yn(String sos_benf_tgt_yn) {
		this.sos_benf_tgt_yn = sos_benf_tgt_yn;
	}
	public String getSos_ntrg_rs_cd() {
		return sos_ntrg_rs_cd;
	}
	public void setSos_ntrg_rs_cd(String sos_ntrg_rs_cd) {
		this.sos_ntrg_rs_cd = sos_ntrg_rs_cd;
	}
	public String getFnal_updt_dttm() {
		return fnal_updt_dttm;
	}
	public void setFnal_updt_dttm(String fnal_updt_dttm) {
		this.fnal_updt_dttm = fnal_updt_dttm;
	}
	public String getFnal_amdr_empno() {
		return fnal_amdr_empno;
	}
	public void setFnal_amdr_empno(String fnal_amdr_empno) {
		this.fnal_amdr_empno = fnal_amdr_empno;
	}
	public String getSos_srv_ctp_dvcd() {
		return sos_srv_ctp_dvcd;
	}
	public void setSos_srv_ctp_dvcd(String sos_srv_ctp_dvcd) {
		this.sos_srv_ctp_dvcd = sos_srv_ctp_dvcd;
	}
	public String getSrv_crnm() {
		return srv_crnm;
	}
	public void setSrv_crnm(String srv_crnm) {
		this.srv_crnm = srv_crnm;
	}
	public String getSos_rpt_area_dvcd() {
		return sos_rpt_area_dvcd;
	}
	public void setSos_rpt_area_dvcd(String sos_rpt_area_dvcd) {
		this.sos_rpt_area_dvcd = sos_rpt_area_dvcd;
	}
	public String getCtp_cd() {
		return ctp_cd;
	}
	public void setCtp_cd(String ctp_cd) {
		this.ctp_cd = ctp_cd;
	}
	public String getSos_proc_rsl_cd() {
		return sos_proc_rsl_cd;
	}
	public void setSos_proc_rsl_cd(String sos_proc_rsl_cd) {
		this.sos_proc_rsl_cd = sos_proc_rsl_cd;
	}
	public String getFuln_ofer_yn() {
		return fuln_ofer_yn;
	}
	public void setFuln_ofer_yn(String fuln_ofer_yn) {
		this.fuln_ofer_yn = fuln_ofer_yn;
	}
	public String getSos_wrhs_bzaq_no() {
		return sos_wrhs_bzaq_no;
	}
	public void setSos_wrhs_bzaq_no(String sos_wrhs_bzaq_no) {
		this.sos_wrhs_bzaq_no = sos_wrhs_bzaq_no;
	}
	public String getSos_wrhs_rs_cd() {
		return sos_wrhs_rs_cd;
	}
	public void setSos_wrhs_rs_cd(String sos_wrhs_rs_cd) {
		this.sos_wrhs_rs_cd = sos_wrhs_rs_cd;
	}
	public String getWrhs_ntp_nm() {
		return wrhs_ntp_nm;
	}
	public void setWrhs_ntp_nm(String wrhs_ntp_nm) {
		this.wrhs_ntp_nm = wrhs_ntp_nm;
	}
	public String getSos_dst_tpcd() {
		return sos_dst_tpcd;
	}
	public void setSos_dst_tpcd(String sos_dst_tpcd) {
		this.sos_dst_tpcd = sos_dst_tpcd;
	}
	public String getSos_dst_typ_ptl_cd() {
		return sos_dst_typ_ptl_cd;
	}
	public void setSos_dst_typ_ptl_cd(String sos_dst_typ_ptl_cd) {
		this.sos_dst_typ_ptl_cd = sos_dst_typ_ptl_cd;
	}
	public String getDst_rs_cn() {
		return dst_rs_cn;
	}
	public void setDst_rs_cn(String dst_rs_cn) {
		this.dst_rs_cn = dst_rs_cn;
	}
	public String getSos_xtr_tpcd() {
		return sos_xtr_tpcd;
	}
	public void setSos_xtr_tpcd(String sos_xtr_tpcd) {
		this.sos_xtr_tpcd = sos_xtr_tpcd;
	}
	public String getSos_xtr_typ_ptl_cd() {
		return sos_xtr_typ_ptl_cd;
	}
	public void setSos_xtr_typ_ptl_cd(String sos_xtr_typ_ptl_cd) {
		this.sos_xtr_typ_ptl_cd = sos_xtr_typ_ptl_cd;
	}
	public String getXtr_add_dstc() {
		return xtr_add_dstc;
	}
	public void setXtr_add_dstc(String xtr_add_dstc) {
		this.xtr_add_dstc = xtr_add_dstc;
	}
	public String getMvt_agt_nm() {
		return mvt_agt_nm;
	}
	public void setMvt_agt_nm(String mvt_agt_nm) {
		this.mvt_agt_nm = mvt_agt_nm;
	}
	public String getMvt_agt_clp_tlcno() {
		return mvt_agt_clp_tlcno;
	}
	public void setMvt_agt_clp_tlcno(String mvt_agt_clp_tlcno) {
		this.mvt_agt_clp_tlcno = mvt_agt_clp_tlcno;
	}
	public String getMvt_agt_clp_ofno() {
		return mvt_agt_clp_ofno;
	}
	public void setMvt_agt_clp_ofno(String mvt_agt_clp_ofno) {
		this.mvt_agt_clp_ofno = mvt_agt_clp_ofno;
	}
	public String getMvt_agt_clp_idvno() {
		return mvt_agt_clp_idvno;
	}
	public void setMvt_agt_clp_idvno(String mvt_agt_clp_idvno) {
		this.mvt_agt_clp_idvno = mvt_agt_clp_idvno;
	}
	public String getSms_mvt_agt_ts_yn() {
		return sms_mvt_agt_ts_yn;
	}
	public void setSms_mvt_agt_ts_yn(String sms_mvt_agt_ts_yn) {
		this.sms_mvt_agt_ts_yn = sms_mvt_agt_ts_yn;
	}
	public String getSms_mvt_agt_ts_dttm() {
		return sms_mvt_agt_ts_dttm;
	}
	public void setSms_mvt_agt_ts_dttm(String sms_mvt_agt_ts_dttm) {
		this.sms_mvt_agt_ts_dttm = sms_mvt_agt_ts_dttm;
	}
	public String getSms_cust_ts_yn() {
		return sms_cust_ts_yn;
	}
	public void setSms_cust_ts_yn(String sms_cust_ts_yn) {
		this.sms_cust_ts_yn = sms_cust_ts_yn;
	}
	public String getSms_cust_ts_dttm() {
		return sms_cust_ts_dttm;
	}
	public void setSms_cust_ts_dttm(String sms_cust_ts_dttm) {
		this.sms_cust_ts_dttm = sms_cust_ts_dttm;
	}
	public String getTw_exn_tty_eny_yn() {
		return tw_exn_tty_eny_yn;
	}
	public void setTw_exn_tty_eny_yn(String tw_exn_tty_eny_yn) {
		this.tw_exn_tty_eny_yn = tw_exn_tty_eny_yn;
	}
	public String getNwod_psno_dvcd() {
		return nwod_psno_dvcd;
	}
	public void setNwod_psno_dvcd(String nwod_psno_dvcd) {
		this.nwod_psno_dvcd = nwod_psno_dvcd;
	}
	public String getPst_road_nm_adr() {
		return pst_road_nm_adr;
	}
	public void setPst_road_nm_adr(String pst_road_nm_adr) {
		this.pst_road_nm_adr = pst_road_nm_adr;
	}
	public String getCust_eta_adr_2() {
		return cust_eta_adr_2;
	}
	public void setCust_eta_adr_2(String cust_eta_adr_2) {
		this.cust_eta_adr_2 = cust_eta_adr_2;
	}
	public String getTrv_dstc_tty_eny_yn() {
		return trv_dstc_tty_eny_yn;
	}
	public void setTrv_dstc_tty_eny_yn(String trv_dstc_tty_eny_yn) {
		this.trv_dstc_tty_eny_yn = trv_dstc_tty_eny_yn;
	}
	public String getTrv_dstc_tty_sms_ts_yn() {
		return trv_dstc_tty_sms_ts_yn;
	}
	public void setTrv_dstc_tty_sms_ts_yn(String trv_dstc_tty_sms_ts_yn) {
		this.trv_dstc_tty_sms_ts_yn = trv_dstc_tty_sms_ts_yn;
	}
	public String getFnal_trv_dstc() {
		return fnal_trv_dstc;
	}
	public void setFnal_trv_dstc(String fnal_trv_dstc) {
		this.fnal_trv_dstc = fnal_trv_dstc;
	}
	public String getFnal_trv_dstc_inpt_dttm() {
		return fnal_trv_dstc_inpt_dttm;
	}
	public void setFnal_trv_dstc_inpt_dttm(String fnal_trv_dstc_inpt_dttm) {
		this.fnal_trv_dstc_inpt_dttm = fnal_trv_dstc_inpt_dttm;
	}
	public String getPhgp_strg_yn() {
		return phgp_strg_yn;
	}
	public void setPhgp_strg_yn(String phgp_strg_yn) {
		this.phgp_strg_yn = phgp_strg_yn;
	}
	public String getEmg_mvt_upc_cd() {
		return emg_mvt_upc_cd;
	}
	public void setEmg_mvt_upc_cd(String emg_mvt_upc_cd) {
		this.emg_mvt_upc_cd = emg_mvt_upc_cd;
	}
	public String getEmg_mvt_grcd() {
		return emg_mvt_grcd;
	}
	public void setEmg_mvt_grcd(String emg_mvt_grcd) {
		this.emg_mvt_grcd = emg_mvt_grcd;
	}
	public String getMlg_amt() {
		return mlg_amt;
	}
	public void setMlg_amt(String mlg_amt) {
		this.mlg_amt = mlg_amt;
	}
}
