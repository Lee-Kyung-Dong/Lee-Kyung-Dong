package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class GGNI0035VO extends CMMVO
{
	public String proc_dvn		;// 처리구분
	public String inpd_cd		;// 보종코드
	public String plan_no		;// 설계번호
	public String scy_typ		;// 단체유형
	public String sme_cvr_no	;// 동일담보번호
	public String cvr_sqno		;// 담보일련번호
	public String ins_cnt		;// 피보험자수
	public String sl_typ		;// 판매유형
	public String fmy_dvn		;// 가족구분
	public String bz_cd			;// 업무코드
	public String ins_rtg		;// 피보험자급수
	public String ins_cnt_1		;// 피보험자수1
	public String crcy_cd		;// 화폐코드　 
	public String pan_cd		;// 플랜코드                      
	public String tdtn_nm		;// 여행지명
	public String tdtn			;// 여행지
	public String trvl_oj_nm	;// 여행목적명
	public String trvl_oj_cd	;// 여행목적코드
	
	public String[] inj_plan_prm_cmp_7_3_5_arrm_1__cvr_cd_1	;// 상해설계보험료산출735_배열1_담보코드1
	public String[] inj_plan_prm_cmp_7_3_5_arrm_1__inam_1	;// 상해설계보험료산출735_배열1_가입금액1
	public String[] inj_plan_prm_cmp_7_3_5_arrm_1__acc_cnt_1;// 상해설계보험료산출735_배열1_계좌수1
	public String[] inj_plan_prm_cmp_7_3_5_arrm_1__rn_prm_1	;// 상해설계보험료산출735_배열1_출재보험료1
	public String[] inj_plan_prm_cmp_7_3_5_arrm_1__dct_amt_1;// 상해설계보험료산출735_배열1_공제금액1
	 	
	public String wncr_tot_prm	;// 원화총보험료
	public String arc_trm_pd_1	;// 보험기간시기1 
	public String arc_trm_pd_2	;// 보험기간시기2
	public String arc_time_et	;// 보험시간종기 
	public String arc_trm_et	;// 보험기간종기
	
	public String[] inj_plan_prm_cmp_7_3_5_arrm_2__ins_oj_sqno	;// 상해설계보험료산출735_배열2_피보험자목적일련번호
	public String[] inj_plan_prm_cmp_7_3_5_arrm_2__ins_rsdn_no	;// 상해설계보험료산출735_배열2_피보험자주민번호        
	public String[] inj_plan_prm_cmp_7_3_5_arrm_2__ins_nm		;// 상해설계보험료산출735_배열2_피보험자명
	
	// 임시 시작
	public String errorCode;//에러코드
	public String z_msg_cd;//메시지 코드
	public String returnMessage;//메시지 내용
	
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getZ_msg_cd() {
		return z_msg_cd;
	}
	public void setZ_msg_cd(String z_msg_cd) {
		this.z_msg_cd = z_msg_cd;
	}
	public String getReturnMessage() {
		return returnMessage;
	}
	public void setReturnMessage(String returnMessage) {
		this.returnMessage = returnMessage;
	}
	// 임시 끝
	
	public String getProc_dvn() {
		return proc_dvn;
	}
	public void setProc_dvn(String proc_dvn) {
		this.proc_dvn = proc_dvn;
	}
	public String getInpd_cd() {
		return inpd_cd;
	}
	public void setInpd_cd(String inpd_cd) {
		this.inpd_cd = inpd_cd;
	}
	public String getPlan_no() {
		return plan_no;
	}
	public void setPlan_no(String plan_no) {
		this.plan_no = plan_no;
	}
	public String getScy_typ() {
		return scy_typ;
	}
	public void setScy_typ(String scy_typ) {
		this.scy_typ = scy_typ;
	}
	public String getSme_cvr_no() {
		return sme_cvr_no;
	}
	public void setSme_cvr_no(String sme_cvr_no) {
		this.sme_cvr_no = sme_cvr_no;
	}
	public String getCvr_sqno() {
		return cvr_sqno;
	}
	public void setCvr_sqno(String cvr_sqno) {
		this.cvr_sqno = cvr_sqno;
	}
	public String getIns_cnt() {
		return ins_cnt;
	}
	public void setIns_cnt(String ins_cnt) {
		this.ins_cnt = ins_cnt;
	}
	public String getSl_typ() {
		return sl_typ;
	}
	public void setSl_typ(String sl_typ) {
		this.sl_typ = sl_typ;
	}
	public String getFmy_dvn() {
		return fmy_dvn;
	}
	public void setFmy_dvn(String fmy_dvn) {
		this.fmy_dvn = fmy_dvn;
	}
	public String getBz_cd() {
		return bz_cd;
	}
	public void setBz_cd(String bz_cd) {
		this.bz_cd = bz_cd;
	}
	public String getIns_rtg() {
		return ins_rtg;
	}
	public void setIns_rtg(String ins_rtg) {
		this.ins_rtg = ins_rtg;
	}
	public String getIns_cnt_1() {
		return ins_cnt_1;
	}
	public void setIns_cnt_1(String ins_cnt_1) {
		this.ins_cnt_1 = ins_cnt_1;
	}
	public String getCrcy_cd() {
		return crcy_cd;
	}
	public void setCrcy_cd(String crcy_cd) {
		this.crcy_cd = crcy_cd;
	}
	public String getPan_cd() {
		return pan_cd;
	}
	public void setPan_cd(String pan_cd) {
		this.pan_cd = pan_cd;
	}
	public String getTdtn_nm() {
		return tdtn_nm;
	}
	public void setTdtn_nm(String tdtn_nm) {
		this.tdtn_nm = tdtn_nm;
	}
	public String getTdtn() {
		return tdtn;
	}
	public void setTdtn(String tdtn) {
		this.tdtn = tdtn;
	}
	public String getTrvl_oj_nm() {
		return trvl_oj_nm;
	}
	public void setTrvl_oj_nm(String trvl_oj_nm) {
		this.trvl_oj_nm = trvl_oj_nm;
	}
	public String getTrvl_oj_cd() {
		return trvl_oj_cd;
	}
	public void setTrvl_oj_cd(String trvl_oj_cd) {
		this.trvl_oj_cd = trvl_oj_cd;
	}
	public String[] getInj_plan_prm_cmp_7_3_5_arrm_1__cvr_cd_1() {
		return inj_plan_prm_cmp_7_3_5_arrm_1__cvr_cd_1;
	}
	public void setInj_plan_prm_cmp_7_3_5_arrm_1__cvr_cd_1(
			String[] inj_plan_prm_cmp_7_3_5_arrm_1__cvr_cd_1) {
		this.inj_plan_prm_cmp_7_3_5_arrm_1__cvr_cd_1 = inj_plan_prm_cmp_7_3_5_arrm_1__cvr_cd_1;
	}
	public String[] getInj_plan_prm_cmp_7_3_5_arrm_1__inam_1() {
		return inj_plan_prm_cmp_7_3_5_arrm_1__inam_1;
	}
	public void setInj_plan_prm_cmp_7_3_5_arrm_1__inam_1(
			String[] inj_plan_prm_cmp_7_3_5_arrm_1__inam_1) {
		this.inj_plan_prm_cmp_7_3_5_arrm_1__inam_1 = inj_plan_prm_cmp_7_3_5_arrm_1__inam_1;
	}
	public String[] getInj_plan_prm_cmp_7_3_5_arrm_1__acc_cnt_1() {
		return inj_plan_prm_cmp_7_3_5_arrm_1__acc_cnt_1;
	}
	public void setInj_plan_prm_cmp_7_3_5_arrm_1__acc_cnt_1(
			String[] inj_plan_prm_cmp_7_3_5_arrm_1__acc_cnt_1) {
		this.inj_plan_prm_cmp_7_3_5_arrm_1__acc_cnt_1 = inj_plan_prm_cmp_7_3_5_arrm_1__acc_cnt_1;
	}
	public String[] getInj_plan_prm_cmp_7_3_5_arrm_1__rn_prm_1() {
		return inj_plan_prm_cmp_7_3_5_arrm_1__rn_prm_1;
	}
	public void setInj_plan_prm_cmp_7_3_5_arrm_1__rn_prm_1(
			String[] inj_plan_prm_cmp_7_3_5_arrm_1__rn_prm_1) {
		this.inj_plan_prm_cmp_7_3_5_arrm_1__rn_prm_1 = inj_plan_prm_cmp_7_3_5_arrm_1__rn_prm_1;
	}
	public String[] getInj_plan_prm_cmp_7_3_5_arrm_1__dct_amt_1() {
		return inj_plan_prm_cmp_7_3_5_arrm_1__dct_amt_1;
	}
	public void setInj_plan_prm_cmp_7_3_5_arrm_1__dct_amt_1(
			String[] inj_plan_prm_cmp_7_3_5_arrm_1__dct_amt_1) {
		this.inj_plan_prm_cmp_7_3_5_arrm_1__dct_amt_1 = inj_plan_prm_cmp_7_3_5_arrm_1__dct_amt_1;
	}
	public String getWncr_tot_prm() {
		return wncr_tot_prm;
	}
	public void setWncr_tot_prm(String wncr_tot_prm) {
		this.wncr_tot_prm = wncr_tot_prm;
	}
	public String getArc_trm_pd_1() {
		return arc_trm_pd_1;
	}
	public void setArc_trm_pd_1(String arc_trm_pd_1) {
		this.arc_trm_pd_1 = arc_trm_pd_1;
	}
	public String getArc_trm_pd_2() {
		return arc_trm_pd_2;
	}
	public void setArc_trm_pd_2(String arc_trm_pd_2) {
		this.arc_trm_pd_2 = arc_trm_pd_2;
	}
	public String getArc_time_et() {
		return arc_time_et;
	}
	public void setArc_time_et(String arc_time_et) {
		this.arc_time_et = arc_time_et;
	}
	public String getArc_trm_et() {
		return arc_trm_et;
	}
	public void setArc_trm_et(String arc_trm_et) {
		this.arc_trm_et = arc_trm_et;
	}
	public String[] getInj_plan_prm_cmp_7_3_5_arrm_2__ins_oj_sqno() {
		return inj_plan_prm_cmp_7_3_5_arrm_2__ins_oj_sqno;
	}
	public void setInj_plan_prm_cmp_7_3_5_arrm_2__ins_oj_sqno(
			String[] inj_plan_prm_cmp_7_3_5_arrm_2__ins_oj_sqno) {
		this.inj_plan_prm_cmp_7_3_5_arrm_2__ins_oj_sqno = inj_plan_prm_cmp_7_3_5_arrm_2__ins_oj_sqno;
	}
	public String[] getInj_plan_prm_cmp_7_3_5_arrm_2__ins_rsdn_no() {
		return inj_plan_prm_cmp_7_3_5_arrm_2__ins_rsdn_no;
	}
	public void setInj_plan_prm_cmp_7_3_5_arrm_2__ins_rsdn_no(
			String[] inj_plan_prm_cmp_7_3_5_arrm_2__ins_rsdn_no) {
		this.inj_plan_prm_cmp_7_3_5_arrm_2__ins_rsdn_no = inj_plan_prm_cmp_7_3_5_arrm_2__ins_rsdn_no;
	}
	public String[] getInj_plan_prm_cmp_7_3_5_arrm_2__ins_nm() {
		return inj_plan_prm_cmp_7_3_5_arrm_2__ins_nm;
	}
	public void setInj_plan_prm_cmp_7_3_5_arrm_2__ins_nm(
			String[] inj_plan_prm_cmp_7_3_5_arrm_2__ins_nm) {
		this.inj_plan_prm_cmp_7_3_5_arrm_2__ins_nm = inj_plan_prm_cmp_7_3_5_arrm_2__ins_nm;
	}
}
