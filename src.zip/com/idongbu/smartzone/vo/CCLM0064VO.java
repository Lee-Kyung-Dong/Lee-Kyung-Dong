package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class CCLM0064VO extends CMMVO {

	//전문필드
		public String msg_cd = "";  //[] 메세지코드 LK_MSG_CD2 메세지코드2
		public String msg = "";  //[] 메시지 H_LK_MESSAGE2 메시지2
		public String pat_dvn_1 = "";  //[] 파트구분1 LK_PART_GB1 파트구분1
		public String pat_dvn_2 = "";  //[] 파트구분2 LK_PART_GB2 파트구분2
		public String bz_dvn_1 = "";  //[] 업무구분1 LK_UPMU_CD1 업무구분1
		public String bz_dvn_2 = "";  //[] 업무구분2 LK_UPMU_CD2 업무구분2
		public String bz_dvn_3 = "";  //[] 업무구분3 LK_UPMU_CD3 업무구분3
		public String accd_rpt_no = "";  //[I/O] 사고접수번호 LK_I_SAGO_JUBSU_NO 사고접수번호         
		public String accd_dttm = "";  //[O] 사고일시 LK_SAGO_YMDSB 사고일시
		public String accd_plc_1 = "";  //[O] 사고장소1 LK_SAGO_JANGSO1 사고장소1
		public String rptr_nm_1 = "";  //[O] 통보자명1 LK_TONGBO_NAME 통보자명1
		public String tlp_1 = "";  //[O] 전화1 LK_TONGBO_TEL 전화1
		public String drvr_nm_1 = "";  //[O] 운전자명1 LK_UNJUNJA_NAME 운전자명1
		public String drvr_tlp_1 = "";  //[O] 운전자전화1 LK_UNJUNJA_TEL 운전자전화1
		public String accd_plc_2 = "";  //[O] 사고장소2 LK_SAGO_JANGSO2 사고장소2
		public String accd_cn = "";  //[O] 사고내용 LK_SAGO_CONT 사고내용
		public String rpt_cnum = "";  //[O] 접수건수 LK_JUBSU_GUNSU 접수건수
		public String[] clam_o_n_e_c_l_i_c_k_srv_accd_cn_srch_srch__accd_oj_dvcd = new String[0];  //[O] 보상ONE_CLICK서비스_사고내용조회_조회_사고목적구분코드 LK_SAGO_MOKJUK_GB 사고목적구분     
		public String[] clam_o_n_e_c_l_i_c_k_srv_accd_cn_srch_srch__accd_oj_nm = new String[0];  //[O] 보상ONE_CLICK서비스_사고내용조회_조회_사고목적명 LK_SAGO_MOKJUK_NM 사고목적명     
		public String[] clam_o_n_e_c_l_i_c_k_srv_accd_cn_srch_srch__accd_oj_sqno = new String[0];  //[O] 보상ONE_CLICK서비스_사고내용조회_조회_사고목적일련번호 LK_SAGO_MOKJUK_SEQ 사고목적일련번호 
		public String[] clam_o_n_e_c_l_i_c_k_srv_accd_cn_srch_srch__vtm_nm = new String[0];  //[O] 보상ONE_CLICK서비스_사고내용조회_조회_피해자명 LK_PIHEJAMUL_NM 피해자명
		public String[] clam_o_n_e_c_l_i_c_k_srv_accd_cn_srch_srch__hosp_nm = new String[0];  //[O] 보상ONE_CLICK서비스_사고내용조회_조회_병원명 LK_HOSP_SURI 병원명
		public String[] clam_o_n_e_c_l_i_c_k_srv_accd_cn_srch_srch__psic_nm = new String[0];  //[O] 보상ONE_CLICK서비스_사고내용조회_조회_담당자명 LK_DAMDANGJA 담당자명
		public String[] clam_o_n_e_c_l_i_c_k_srv_accd_cn_srch_srch__tlp = new String[0];  //[O] 보상ONE_CLICK서비스_사고내용조회_조회_전화 LK_DAMDANG_TEL 전화
		
		public String getMsg_cd() {
			return msg_cd;
		}
		public void setMsg_cd(String msg_cd) {
			this.msg_cd = msg_cd;
		}
		public String getMsg() {
			return msg;
		}
		public void setMsg(String msg) {
			this.msg = msg;
		}
		public String getPat_dvn_1() {
			return pat_dvn_1;
		}
		public void setPat_dvn_1(String pat_dvn_1) {
			this.pat_dvn_1 = pat_dvn_1;
		}
		public String getPat_dvn_2() {
			return pat_dvn_2;
		}
		public void setPat_dvn_2(String pat_dvn_2) {
			this.pat_dvn_2 = pat_dvn_2;
		}
		public String getBz_dvn_1() {
			return bz_dvn_1;
		}
		public void setBz_dvn_1(String bz_dvn_1) {
			this.bz_dvn_1 = bz_dvn_1;
		}
		public String getBz_dvn_2() {
			return bz_dvn_2;
		}
		public void setBz_dvn_2(String bz_dvn_2) {
			this.bz_dvn_2 = bz_dvn_2;
		}
		public String getBz_dvn_3() {
			return bz_dvn_3;
		}
		public void setBz_dvn_3(String bz_dvn_3) {
			this.bz_dvn_3 = bz_dvn_3;
		}
		public String getAccd_rpt_no() {
			return accd_rpt_no;
		}
		public void setAccd_rpt_no(String accd_rpt_no) {
			this.accd_rpt_no = accd_rpt_no;
		}
		public String getAccd_dttm() {
			return accd_dttm;
		}
		public void setAccd_dttm(String accd_dttm) {
			this.accd_dttm = accd_dttm;
		}
		public String getAccd_plc_1() {
			return accd_plc_1;
		}
		public void setAccd_plc_1(String accd_plc_1) {
			this.accd_plc_1 = accd_plc_1;
		}
		public String getRptr_nm_1() {
			return rptr_nm_1;
		}
		public void setRptr_nm_1(String rptr_nm_1) {
			this.rptr_nm_1 = rptr_nm_1;
		}
		public String getTlp_1() {
			return tlp_1;
		}
		public void setTlp_1(String tlp_1) {
			this.tlp_1 = tlp_1;
		}
		public String getDrvr_nm_1() {
			return drvr_nm_1;
		}
		public void setDrvr_nm_1(String drvr_nm_1) {
			this.drvr_nm_1 = drvr_nm_1;
		}
		public String getDrvr_tlp_1() {
			return drvr_tlp_1;
		}
		public void setDrvr_tlp_1(String drvr_tlp_1) {
			this.drvr_tlp_1 = drvr_tlp_1;
		}
		public String getAccd_plc_2() {
			return accd_plc_2;
		}
		public void setAccd_plc_2(String accd_plc_2) {
			this.accd_plc_2 = accd_plc_2;
		}
		public String getAccd_cn() {
			return accd_cn;
		}
		public void setAccd_cn(String accd_cn) {
			this.accd_cn = accd_cn;
		}
		public String getRpt_cnum() {
			return rpt_cnum;
		}
		public void setRpt_cnum(String rpt_cnum) {
			this.rpt_cnum = rpt_cnum;
		}
		public String[] getClam_o_n_e_c_l_i_c_k_srv_accd_cn_srch_srch__accd_oj_dvcd() {
			return clam_o_n_e_c_l_i_c_k_srv_accd_cn_srch_srch__accd_oj_dvcd;
		}
		public void setClam_o_n_e_c_l_i_c_k_srv_accd_cn_srch_srch__accd_oj_dvcd(
				String[] clam_o_n_e_c_l_i_c_k_srv_accd_cn_srch_srch__accd_oj_dvcd) {
			this.clam_o_n_e_c_l_i_c_k_srv_accd_cn_srch_srch__accd_oj_dvcd = clam_o_n_e_c_l_i_c_k_srv_accd_cn_srch_srch__accd_oj_dvcd;
		}
		public String[] getClam_o_n_e_c_l_i_c_k_srv_accd_cn_srch_srch__accd_oj_nm() {
			return clam_o_n_e_c_l_i_c_k_srv_accd_cn_srch_srch__accd_oj_nm;
		}
		public void setClam_o_n_e_c_l_i_c_k_srv_accd_cn_srch_srch__accd_oj_nm(
				String[] clam_o_n_e_c_l_i_c_k_srv_accd_cn_srch_srch__accd_oj_nm) {
			this.clam_o_n_e_c_l_i_c_k_srv_accd_cn_srch_srch__accd_oj_nm = clam_o_n_e_c_l_i_c_k_srv_accd_cn_srch_srch__accd_oj_nm;
		}
		public String[] getClam_o_n_e_c_l_i_c_k_srv_accd_cn_srch_srch__accd_oj_sqno() {
			return clam_o_n_e_c_l_i_c_k_srv_accd_cn_srch_srch__accd_oj_sqno;
		}
		public void setClam_o_n_e_c_l_i_c_k_srv_accd_cn_srch_srch__accd_oj_sqno(
				String[] clam_o_n_e_c_l_i_c_k_srv_accd_cn_srch_srch__accd_oj_sqno) {
			this.clam_o_n_e_c_l_i_c_k_srv_accd_cn_srch_srch__accd_oj_sqno = clam_o_n_e_c_l_i_c_k_srv_accd_cn_srch_srch__accd_oj_sqno;
		}
		public String[] getClam_o_n_e_c_l_i_c_k_srv_accd_cn_srch_srch__vtm_nm() {
			return clam_o_n_e_c_l_i_c_k_srv_accd_cn_srch_srch__vtm_nm;
		}
		public void setClam_o_n_e_c_l_i_c_k_srv_accd_cn_srch_srch__vtm_nm(
				String[] clam_o_n_e_c_l_i_c_k_srv_accd_cn_srch_srch__vtm_nm) {
			this.clam_o_n_e_c_l_i_c_k_srv_accd_cn_srch_srch__vtm_nm = clam_o_n_e_c_l_i_c_k_srv_accd_cn_srch_srch__vtm_nm;
		}
		public String[] getClam_o_n_e_c_l_i_c_k_srv_accd_cn_srch_srch__hosp_nm() {
			return clam_o_n_e_c_l_i_c_k_srv_accd_cn_srch_srch__hosp_nm;
		}
		public void setClam_o_n_e_c_l_i_c_k_srv_accd_cn_srch_srch__hosp_nm(
				String[] clam_o_n_e_c_l_i_c_k_srv_accd_cn_srch_srch__hosp_nm) {
			this.clam_o_n_e_c_l_i_c_k_srv_accd_cn_srch_srch__hosp_nm = clam_o_n_e_c_l_i_c_k_srv_accd_cn_srch_srch__hosp_nm;
		}
		public String[] getClam_o_n_e_c_l_i_c_k_srv_accd_cn_srch_srch__psic_nm() {
			return clam_o_n_e_c_l_i_c_k_srv_accd_cn_srch_srch__psic_nm;
		}
		public void setClam_o_n_e_c_l_i_c_k_srv_accd_cn_srch_srch__psic_nm(
				String[] clam_o_n_e_c_l_i_c_k_srv_accd_cn_srch_srch__psic_nm) {
			this.clam_o_n_e_c_l_i_c_k_srv_accd_cn_srch_srch__psic_nm = clam_o_n_e_c_l_i_c_k_srv_accd_cn_srch_srch__psic_nm;
		}
		public String[] getClam_o_n_e_c_l_i_c_k_srv_accd_cn_srch_srch__tlp() {
			return clam_o_n_e_c_l_i_c_k_srv_accd_cn_srch_srch__tlp;
		}
		public void setClam_o_n_e_c_l_i_c_k_srv_accd_cn_srch_srch__tlp(
				String[] clam_o_n_e_c_l_i_c_k_srv_accd_cn_srch_srch__tlp) {
			this.clam_o_n_e_c_l_i_c_k_srv_accd_cn_srch_srch__tlp = clam_o_n_e_c_l_i_c_k_srv_accd_cn_srch_srch__tlp;
		}
}
