package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class KCUS0012VO extends CMMVO {

	//전문필드
		public String cust_dcmt_no = "";  			//[I]고객식별번호
		public String hdlr_empno = "";  			//[I]취급자사원번호
		public String cust_chng_atl_clsf_cd = "";  	//[I]고객변경항목분류코드
		public String cust_chng_atl_cd = "";  		//[I]고객변경항목코드
		public String sjt_trty_cd = "";  			//[I]주제영역코드
			
		public String[] cust_if_chng_hist_srch_chng_hist__cust_chng_atl_cd = new String[0];		//[O]고객정보변경이력조회_변경이력_고객변경항목코드
		public String[] cust_if_chng_hist_srch_chng_hist__chng_dttm = new String[0];  			//[O]고객정보변경이력조회_변경이력_변경일시
		public String[] cust_if_chng_hist_srch_chng_hist__chng_bse_dtl_dttm = new String[0]; 	//[O]고객정보변경이력조회_변경이력_변경기준상세일시
		public String[] cust_if_chng_hist_srch_chng_hist__inpt_tm = new String[0];  			//[O]고객정보변경이력조회_변경이력_입력시각
		public String[] cust_if_chng_hist_srch_chng_hist__cust_chng_atl_cd_nm = new String[0];  //[O]고객정보변경이력조회_변경이력_고객변경항목코드명
		public String[] cust_if_chng_hist_srch_chng_hist__chng_prv_cn = new String[0];  		//[O]고객정보변경이력조회_변경이력_변경전내용
		public String[] cust_if_chng_hist_srch_chng_hist__chng_af_cn = new String[0];  			//[O]고객정보변경이력조회_변경이력_변경후내용
		public String[] cust_if_chng_hist_srch_chng_hist__bzlv_nm = new String[0];  			//[O]고객정보변경이력조회_변경이력_사업단명
		public String[] cust_if_chng_hist_srch_chng_hist__bh_nm = new String[0];  				//[O]고객정보변경이력조회_변경이력_지점명
		public String[] cust_if_chng_hist_srch_chng_hist__chng_staf_empno = new String[0];  	//[O]고객정보변경이력조회_변경이력_변경직원사원번호
		public String[] cust_if_chng_hist_srch_chng_hist__chng_staf_nm = new String[0];  		//[O]고객정보변경이력조회_변경이력_변경직원명
		public String[] cust_if_chng_hist_srch_chng_hist__sjt_trty_cd = new String[0];  		//[O]고객정보변경이력조회_변경이력_주제영역코드
		
		public String errorCode = "";

		public String getCust_dcmt_no() {
			return cust_dcmt_no;
		}

		public void setCust_dcmt_no(String cust_dcmt_no) {
			this.cust_dcmt_no = cust_dcmt_no;
		}

		public String getHdlr_empno() {
			return hdlr_empno;
		}

		public void setHdlr_empno(String hdlr_empno) {
			this.hdlr_empno = hdlr_empno;
		}

		public String getCust_chng_atl_clsf_cd() {
			return cust_chng_atl_clsf_cd;
		}

		public void setCust_chng_atl_clsf_cd(String cust_chng_atl_clsf_cd) {
			this.cust_chng_atl_clsf_cd = cust_chng_atl_clsf_cd;
		}

		public String getCust_chng_atl_cd() {
			return cust_chng_atl_cd;
		}

		public void setCust_chng_atl_cd(String cust_chng_atl_cd) {
			this.cust_chng_atl_cd = cust_chng_atl_cd;
		}

		public String getSjt_trty_cd() {
			return sjt_trty_cd;
		}

		public void setSjt_trty_cd(String sjt_trty_cd) {
			this.sjt_trty_cd = sjt_trty_cd;
		}

		public String[] getCust_if_chng_hist_srch_chng_hist__cust_chng_atl_cd() {
			return cust_if_chng_hist_srch_chng_hist__cust_chng_atl_cd;
		}

		public void setCust_if_chng_hist_srch_chng_hist__cust_chng_atl_cd(
				String[] cust_if_chng_hist_srch_chng_hist__cust_chng_atl_cd) {
			this.cust_if_chng_hist_srch_chng_hist__cust_chng_atl_cd = cust_if_chng_hist_srch_chng_hist__cust_chng_atl_cd;
		}

		public String[] getCust_if_chng_hist_srch_chng_hist__chng_dttm() {
			return cust_if_chng_hist_srch_chng_hist__chng_dttm;
		}

		public void setCust_if_chng_hist_srch_chng_hist__chng_dttm(String[] cust_if_chng_hist_srch_chng_hist__chng_dttm) {
			this.cust_if_chng_hist_srch_chng_hist__chng_dttm = cust_if_chng_hist_srch_chng_hist__chng_dttm;
		}

		public String[] getCust_if_chng_hist_srch_chng_hist__chng_bse_dtl_dttm() {
			return cust_if_chng_hist_srch_chng_hist__chng_bse_dtl_dttm;
		}

		public void setCust_if_chng_hist_srch_chng_hist__chng_bse_dtl_dttm(
				String[] cust_if_chng_hist_srch_chng_hist__chng_bse_dtl_dttm) {
			this.cust_if_chng_hist_srch_chng_hist__chng_bse_dtl_dttm = cust_if_chng_hist_srch_chng_hist__chng_bse_dtl_dttm;
		}

		public String[] getCust_if_chng_hist_srch_chng_hist__inpt_tm() {
			return cust_if_chng_hist_srch_chng_hist__inpt_tm;
		}

		public void setCust_if_chng_hist_srch_chng_hist__inpt_tm(String[] cust_if_chng_hist_srch_chng_hist__inpt_tm) {
			this.cust_if_chng_hist_srch_chng_hist__inpt_tm = cust_if_chng_hist_srch_chng_hist__inpt_tm;
		}

		public String[] getCust_if_chng_hist_srch_chng_hist__cust_chng_atl_cd_nm() {
			return cust_if_chng_hist_srch_chng_hist__cust_chng_atl_cd_nm;
		}

		public void setCust_if_chng_hist_srch_chng_hist__cust_chng_atl_cd_nm(
				String[] cust_if_chng_hist_srch_chng_hist__cust_chng_atl_cd_nm) {
			this.cust_if_chng_hist_srch_chng_hist__cust_chng_atl_cd_nm = cust_if_chng_hist_srch_chng_hist__cust_chng_atl_cd_nm;
		}

		public String[] getCust_if_chng_hist_srch_chng_hist__chng_prv_cn() {
			return cust_if_chng_hist_srch_chng_hist__chng_prv_cn;
		}

		public void setCust_if_chng_hist_srch_chng_hist__chng_prv_cn(String[] cust_if_chng_hist_srch_chng_hist__chng_prv_cn) {
			this.cust_if_chng_hist_srch_chng_hist__chng_prv_cn = cust_if_chng_hist_srch_chng_hist__chng_prv_cn;
		}

		public String[] getCust_if_chng_hist_srch_chng_hist__chng_af_cn() {
			return cust_if_chng_hist_srch_chng_hist__chng_af_cn;
		}

		public void setCust_if_chng_hist_srch_chng_hist__chng_af_cn(String[] cust_if_chng_hist_srch_chng_hist__chng_af_cn) {
			this.cust_if_chng_hist_srch_chng_hist__chng_af_cn = cust_if_chng_hist_srch_chng_hist__chng_af_cn;
		}

		public String[] getCust_if_chng_hist_srch_chng_hist__bzlv_nm() {
			return cust_if_chng_hist_srch_chng_hist__bzlv_nm;
		}

		public void setCust_if_chng_hist_srch_chng_hist__bzlv_nm(String[] cust_if_chng_hist_srch_chng_hist__bzlv_nm) {
			this.cust_if_chng_hist_srch_chng_hist__bzlv_nm = cust_if_chng_hist_srch_chng_hist__bzlv_nm;
		}

		public String[] getCust_if_chng_hist_srch_chng_hist__bh_nm() {
			return cust_if_chng_hist_srch_chng_hist__bh_nm;
		}

		public void setCust_if_chng_hist_srch_chng_hist__bh_nm(String[] cust_if_chng_hist_srch_chng_hist__bh_nm) {
			this.cust_if_chng_hist_srch_chng_hist__bh_nm = cust_if_chng_hist_srch_chng_hist__bh_nm;
		}

		public String[] getCust_if_chng_hist_srch_chng_hist__chng_staf_empno() {
			return cust_if_chng_hist_srch_chng_hist__chng_staf_empno;
		}

		public void setCust_if_chng_hist_srch_chng_hist__chng_staf_empno(
				String[] cust_if_chng_hist_srch_chng_hist__chng_staf_empno) {
			this.cust_if_chng_hist_srch_chng_hist__chng_staf_empno = cust_if_chng_hist_srch_chng_hist__chng_staf_empno;
		}

		public String[] getCust_if_chng_hist_srch_chng_hist__chng_staf_nm() {
			return cust_if_chng_hist_srch_chng_hist__chng_staf_nm;
		}

		public void setCust_if_chng_hist_srch_chng_hist__chng_staf_nm(String[] cust_if_chng_hist_srch_chng_hist__chng_staf_nm) {
			this.cust_if_chng_hist_srch_chng_hist__chng_staf_nm = cust_if_chng_hist_srch_chng_hist__chng_staf_nm;
		}

		public String[] getCust_if_chng_hist_srch_chng_hist__sjt_trty_cd() {
			return cust_if_chng_hist_srch_chng_hist__sjt_trty_cd;
		}

		public void setCust_if_chng_hist_srch_chng_hist__sjt_trty_cd(String[] cust_if_chng_hist_srch_chng_hist__sjt_trty_cd) {
			this.cust_if_chng_hist_srch_chng_hist__sjt_trty_cd = cust_if_chng_hist_srch_chng_hist__sjt_trty_cd;
		}

		public String getErrorCode() {
			return errorCode;
		}

		public void setErrorCode(String errorCode) {
			this.errorCode = errorCode;
		}
		
		
}
