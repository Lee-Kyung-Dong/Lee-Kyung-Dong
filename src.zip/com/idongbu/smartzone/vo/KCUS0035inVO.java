package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class KCUS0035inVO extends CMMVO{
	
	public String dvn = null;  //[I/O] 구분 SI_GUBUN 구분
	public String cust_dcmt_no = null;  //[I/O] 고객식별번호 SI_GOGEK_NO 고객번호
	public String cust_nm = null;  //[I/O] 고객명 HO_GOGEK_NM 고객명
	public String hm_psno = null;  //[I/O] 자택우편번호 SO_H_ZIP 자택우편번호
	public String hm_adr = null;  //[I/O] 자택주소 HO_H_JUSO 자택주소
	public String hm_stn = null;  //[I/O] 자택번지 HO_H_ADDR 자택번지
	public String wpc_psno = null;  //[I/O] 직장우편번호 SO_J_ZIP 직장우편번호
	public String wpc_adr = null;  //[I/O] 직장주소 HO_J_JUSO 직장주소
	public String wpc_stn = null;  //[I/O] 직장번지 HO_J_ADDR 직장번지
	public String eta_psno = null;  //[I/O] 기타우편번호 SO_G_ZIP 기타우편번호
	public String eta_adr = null;  //[I/O] 기타주소 HO_G_JUSO 기타주소
	public String eta_stn = null;  //[I/O] 기타번지 HO_G_ADDR 기타번지
	public String nw_hm_psno = null;  //[I/O] 신자택우편주소 SO-ST-H-ZIP 신자택우편주소
	public String nw_hm_adr = null;  //[I/O] 신자택주소 HO-ST-H-ADDR 신자택주소
	public String nw_hm_stn = null;  //[I/O] 신자택번지 HO-ST-H-GITA 신자택번지
	public String nw_wpc_psno = null;  //[I/O] 신직장우편번호 SO-ST-J-ZIP 신직장우편번호
	public String nw_wpc_adr = null;  //[I/O] 신직장주소 HO-ST-J-ADDR 신직장주소
	public String nw_wpc_stn = null;  //[I/O] 신직장번지 HO-ST-J-GITA 신직장번지
	public String nw_eta_psno = null;  //[I/O] 신기타우편번호 SO-ST-G-ZIP 신기타우편번호
	public String nw_eta_adr = null;  //[I/O] 신기타주소 HO-ST-G-ADDR 신기타주소
	public String nw_eta_stn = null;  //[I/O] 신기타번지 HO-ST-G-GITA 신기타번지
	public String hpg_cust_chng_lit___slc = null;  //[I/O] 홈페이지고객변경목록_선택 SI_L_SELECT_FLAG SELECT FLAG
	public String hpg_cust_chng_lit___plno = null;  //[I/O] 홈페이지고객변경목록_증권번호 SO_L_POLI_NO 증권번호
	public String hpg_cust_chng_lit___vh_no = null;  //[I/O] 홈페이지고객변경목록_차량번호 HO_L_CAR_NO 차량번호
	public String hpg_cust_chng_lit___pdc_cd = null;  //[I/O] 홈페이지고객변경목록_상품코드 SO_L_BOJONG_CD 보종코드
	public String hpg_cust_chng_lit___pdc_nm = null;  //[I/O] 홈페이지고객변경목록_상품명 HO_L_BOJONG_NM 상품명
	public String hpg_cust_chng_lit___inpd_dvcd = null;  //[I/O] 홈페이지고객변경목록_보종구분코드  
	public String hpg_cust_chng_lit___cust_dvn = null;  //[I/O] 홈페이지고객변경목록_고객구분 SO_L_GOGEK_GB 고객구분
	public String hpg_cust_chng_lit___cust_dvn_nm = null;  //[I/O] 홈페이지고객변경목록_고객구분명 HO_L_GOGEK_GB_NM 고객구분명
	public String hpg_cust_chng_lit___arc_pd = null;  //[I/O] 홈페이지고객변경목록_보험시기 SO_L_BOHUM_SYMD 보험시기
	public String hpg_cust_chng_lit___arc_et = null;  //[I/O] 홈페이지고객변경목록_보험종기 SO_L_BOHUM_EYMD 보험종기
	public String hpg_cust_chng_lit___ctc_stat = null;  //[I/O] 홈페이지고객변경목록_계약상태 SO_L_GEYAK_SANGTE 계약상태
	public String hpg_cust_chng_lit___ctc_stat_nm = null;  //[I/O] 홈페이지고객변경목록_계약상태명 HO_L_GEYAK_SANGTE_NM 계약상태명
	public String hpg_cust_chng_lit___pcl_rcpl_dvcd = null;  //[I/O] 홈페이지고객변경목록_우편물수령처구분코드 SI_L_SURYUNG_GB 수령구분
	public String hpg_cust_chng_lit___nwod_adr_dvcd = null;  //[I/O] 홈페이지고객변경목록_신구주소구분코드 SI-L-SINGU-GB 신구주소구분코드
	public String hpg_cust_chng_lit___eta_dpp_mngt_no = null;  //[I/O] 홈페이지고객변경목록_기타발송처관리번호  

	public String getDvn() {
		return dvn;
	}

	public void setDvn(String dvn) {
		this.dvn = dvn;
	}

	public String getCust_dcmt_no() {
		return cust_dcmt_no;
	}

	public void setCust_dcmt_no(String cust_dcmt_no) {
		this.cust_dcmt_no = cust_dcmt_no;
	}

	public String getCust_nm() {
		return cust_nm;
	}

	public void setCust_nm(String cust_nm) {
		this.cust_nm = cust_nm;
	}

	public String getHm_psno() {
		return hm_psno;
	}

	public void setHm_psno(String hm_psno) {
		this.hm_psno = hm_psno;
	}

	public String getHm_adr() {
		return hm_adr;
	}

	public void setHm_adr(String hm_adr) {
		this.hm_adr = hm_adr;
	}

	public String getHm_stn() {
		return hm_stn;
	}

	public void setHm_stn(String hm_stn) {
		this.hm_stn = hm_stn;
	}

	public String getWpc_psno() {
		return wpc_psno;
	}

	public void setWpc_psno(String wpc_psno) {
		this.wpc_psno = wpc_psno;
	}

	public String getWpc_adr() {
		return wpc_adr;
	}

	public void setWpc_adr(String wpc_adr) {
		this.wpc_adr = wpc_adr;
	}

	public String getWpc_stn() {
		return wpc_stn;
	}

	public void setWpc_stn(String wpc_stn) {
		this.wpc_stn = wpc_stn;
	}

	public String getEta_psno() {
		return eta_psno;
	}

	public void setEta_psno(String eta_psno) {
		this.eta_psno = eta_psno;
	}

	public String getEta_adr() {
		return eta_adr;
	}

	public void setEta_adr(String eta_adr) {
		this.eta_adr = eta_adr;
	}

	public String getEta_stn() {
		return eta_stn;
	}

	public void setEta_stn(String eta_stn) {
		this.eta_stn = eta_stn;
	}

	public String getNw_hm_psno() {
		return nw_hm_psno;
	}

	public void setNw_hm_psno(String nw_hm_psno) {
		this.nw_hm_psno = nw_hm_psno;
	}

	public String getNw_hm_adr() {
		return nw_hm_adr;
	}

	public void setNw_hm_adr(String nw_hm_adr) {
		this.nw_hm_adr = nw_hm_adr;
	}

	public String getNw_hm_stn() {
		return nw_hm_stn;
	}

	public void setNw_hm_stn(String nw_hm_stn) {
		this.nw_hm_stn = nw_hm_stn;
	}

	public String getNw_wpc_psno() {
		return nw_wpc_psno;
	}

	public void setNw_wpc_psno(String nw_wpc_psno) {
		this.nw_wpc_psno = nw_wpc_psno;
	}

	public String getNw_wpc_adr() {
		return nw_wpc_adr;
	}

	public void setNw_wpc_adr(String nw_wpc_adr) {
		this.nw_wpc_adr = nw_wpc_adr;
	}

	public String getNw_wpc_stn() {
		return nw_wpc_stn;
	}

	public void setNw_wpc_stn(String nw_wpc_stn) {
		this.nw_wpc_stn = nw_wpc_stn;
	}

	public String getNw_eta_psno() {
		return nw_eta_psno;
	}

	public void setNw_eta_psno(String nw_eta_psno) {
		this.nw_eta_psno = nw_eta_psno;
	}

	public String getNw_eta_adr() {
		return nw_eta_adr;
	}

	public void setNw_eta_adr(String nw_eta_adr) {
		this.nw_eta_adr = nw_eta_adr;
	}

	public String getNw_eta_stn() {
		return nw_eta_stn;
	}

	public void setNw_eta_stn(String nw_eta_stn) {
		this.nw_eta_stn = nw_eta_stn;
	}

	public String getHpg_cust_chng_lit___slc() {
		return hpg_cust_chng_lit___slc;
	}

	public void setHpg_cust_chng_lit___slc(String hpg_cust_chng_lit___slc) {
		this.hpg_cust_chng_lit___slc = hpg_cust_chng_lit___slc;
	}

	public String getHpg_cust_chng_lit___plno() {
		return hpg_cust_chng_lit___plno;
	}

	public void setHpg_cust_chng_lit___plno(String hpg_cust_chng_lit___plno) {
		this.hpg_cust_chng_lit___plno = hpg_cust_chng_lit___plno;
	}

	public String getHpg_cust_chng_lit___vh_no() {
		return hpg_cust_chng_lit___vh_no;
	}

	public void setHpg_cust_chng_lit___vh_no(String hpg_cust_chng_lit___vh_no) {
		this.hpg_cust_chng_lit___vh_no = hpg_cust_chng_lit___vh_no;
	}

	public String getHpg_cust_chng_lit___pdc_cd() {
		return hpg_cust_chng_lit___pdc_cd;
	}

	public void setHpg_cust_chng_lit___pdc_cd(String hpg_cust_chng_lit___pdc_cd) {
		this.hpg_cust_chng_lit___pdc_cd = hpg_cust_chng_lit___pdc_cd;
	}

	public String getHpg_cust_chng_lit___pdc_nm() {
		return hpg_cust_chng_lit___pdc_nm;
	}

	public void setHpg_cust_chng_lit___pdc_nm(String hpg_cust_chng_lit___pdc_nm) {
		this.hpg_cust_chng_lit___pdc_nm = hpg_cust_chng_lit___pdc_nm;
	}

	public String getHpg_cust_chng_lit___inpd_dvcd() {
		return hpg_cust_chng_lit___inpd_dvcd;
	}

	public void setHpg_cust_chng_lit___inpd_dvcd(
			String hpg_cust_chng_lit___inpd_dvcd) {
		this.hpg_cust_chng_lit___inpd_dvcd = hpg_cust_chng_lit___inpd_dvcd;
	}

	public String getHpg_cust_chng_lit___cust_dvn() {
		return hpg_cust_chng_lit___cust_dvn;
	}

	public void setHpg_cust_chng_lit___cust_dvn(String hpg_cust_chng_lit___cust_dvn) {
		this.hpg_cust_chng_lit___cust_dvn = hpg_cust_chng_lit___cust_dvn;
	}

	public String getHpg_cust_chng_lit___cust_dvn_nm() {
		return hpg_cust_chng_lit___cust_dvn_nm;
	}

	public void setHpg_cust_chng_lit___cust_dvn_nm(
			String hpg_cust_chng_lit___cust_dvn_nm) {
		this.hpg_cust_chng_lit___cust_dvn_nm = hpg_cust_chng_lit___cust_dvn_nm;
	}

	public String getHpg_cust_chng_lit___arc_pd() {
		return hpg_cust_chng_lit___arc_pd;
	}

	public void setHpg_cust_chng_lit___arc_pd(String hpg_cust_chng_lit___arc_pd) {
		this.hpg_cust_chng_lit___arc_pd = hpg_cust_chng_lit___arc_pd;
	}

	public String getHpg_cust_chng_lit___arc_et() {
		return hpg_cust_chng_lit___arc_et;
	}

	public void setHpg_cust_chng_lit___arc_et(String hpg_cust_chng_lit___arc_et) {
		this.hpg_cust_chng_lit___arc_et = hpg_cust_chng_lit___arc_et;
	}

	public String getHpg_cust_chng_lit___ctc_stat() {
		return hpg_cust_chng_lit___ctc_stat;
	}

	public void setHpg_cust_chng_lit___ctc_stat(String hpg_cust_chng_lit___ctc_stat) {
		this.hpg_cust_chng_lit___ctc_stat = hpg_cust_chng_lit___ctc_stat;
	}

	public String getHpg_cust_chng_lit___ctc_stat_nm() {
		return hpg_cust_chng_lit___ctc_stat_nm;
	}

	public void setHpg_cust_chng_lit___ctc_stat_nm(
			String hpg_cust_chng_lit___ctc_stat_nm) {
		this.hpg_cust_chng_lit___ctc_stat_nm = hpg_cust_chng_lit___ctc_stat_nm;
	}

	public String getHpg_cust_chng_lit___pcl_rcpl_dvcd() {
		return hpg_cust_chng_lit___pcl_rcpl_dvcd;
	}

	public void setHpg_cust_chng_lit___pcl_rcpl_dvcd(
			String hpg_cust_chng_lit___pcl_rcpl_dvcd) {
		this.hpg_cust_chng_lit___pcl_rcpl_dvcd = hpg_cust_chng_lit___pcl_rcpl_dvcd;
	}

	public String getHpg_cust_chng_lit___nwod_adr_dvcd() {
		return hpg_cust_chng_lit___nwod_adr_dvcd;
	}

	public void setHpg_cust_chng_lit___nwod_adr_dvcd(
			String hpg_cust_chng_lit___nwod_adr_dvcd) {
		this.hpg_cust_chng_lit___nwod_adr_dvcd = hpg_cust_chng_lit___nwod_adr_dvcd;
	}

	public String getHpg_cust_chng_lit___eta_dpp_mngt_no() {
		return hpg_cust_chng_lit___eta_dpp_mngt_no;
	}

	public void setHpg_cust_chng_lit___eta_dpp_mngt_no(
			String hpg_cust_chng_lit___eta_dpp_mngt_no) {
		this.hpg_cust_chng_lit___eta_dpp_mngt_no = hpg_cust_chng_lit___eta_dpp_mngt_no;
	}

}
