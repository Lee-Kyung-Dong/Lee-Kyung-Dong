package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class XIDB0004VO extends CMMVO{

	public String seq = "";	// [I/O] 시퀀스번호
	public String stat = "";	// [I/O] 상태코드
	public String msg = "";	// [I/O] 메시지
	public String eta_dtl_cn = ""; // 기타상세내용 - 만기정산(차감)일때만
	
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getStat() {
		return stat;
	}
	public void setStat(String stat) {
		this.stat = stat;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public String getEta_dtl_cn() {
		return eta_dtl_cn;
	}
	public void setEta_dtl_cn(String eta_dtl_cn) {
		this.eta_dtl_cn = eta_dtl_cn;
	}
	
	
}
