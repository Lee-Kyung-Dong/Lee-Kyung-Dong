package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class EAST0021VO extends CMMVO{

		//전문필드
		public String plno = "";  //[I] 증권번호 JJ_POLI_NO 증권번호
		// 차세대 2차 전환 시작 필드 추가 (김도연 2014.02.14)
		public String ins_lcpl_dvcd = "";  //[I] 피보험자소재지구분코드  
		public String ply_sqno = "";  //[I] 증권일련번호  
		// 차세대 2차 전환 종료 필드 추가 (김도연 2014.02.14) 
		public String proc_dvn = "";  //[I] 처리구분 JJ_GBN 처리구분
		public String nxt_inte_rv_dd = "";  //[I/O] 차기이자수납일 JJ_SUNAP_YMD 차기이자수납일
		public String plhd_nm = "";  //[I/O] 계약자명 HJ_GY_NM 계약자명
		public String plhd_rsdn_no = "";  //[I] 계약자주민번호 JJ_GY_JUMIN 계약자주민번호
		public String inpd_cd = "";  //[O] 보종코드  
		public String ps_stln_rckn_prpl = "";  //[O] 기약대기산원금 JJ_GI_GISAN_GM 기　약대기산원금
		public String ps_stln_rckd = "";  //[O] 기약대기산일 JJ_GI_GISAN_YMD 기　약대기산일
		public String ps_ppy_et_dd = "";  //[O] 기선납종기일 JJ_GI_SUNN_EYMD 기선납종기일
		public String irt = "";  //[O] 이율 JJ_IYUL 이율
		public String nrm_inte_pd_dt = "";  //[O] 정상이자시기일자      JJ_JUNG_F1 정상이자 시작일1
		public String nrm_inte_et_dt = "";  //[O] 정상이자종기일자      JJ_JUNG_T1 정상일자 종료일1
		public String nrm_inte_rckn_prpl = "";  //[O] 정상이자기산원금 JJ_JUNG_ILSU1 정상이자 일수1
		public String nrm_inte_irt = "";  //[O] 정상이자이율 JJ_JUNG_IJA1 정상일자 이자1
		public String nrm_inte_cal_dcnt = "";  //[O] 정상이자계산일수 JJ_JUNG_F2 정상이자 시작일2
		public String nrm_inte_dt = "";  //[O] 정상이자일자 JJ_JUNG_T2 정상일자 종료일2
		public String nrm_inte_amt = "";  //[O] 정상이자금액          JJ_JUNG_ILSU2 정상이자 일수2
		public String npt_inte_sm_amt = "";  //[O] 미납이자합계금액 JJ_JUNG_IJA2 정상일자 이자2
		public String npt_inte_pd_dt = "";  //[O] 미납이자시기일자       JJ_YUNC_F1 연체이자 시작일1
		public String npt_inte_et_dt = "";  //[O] 미납이자종기일자       JJ_YUNC_T1 연체일자 종료일1
		public String npt_inte_rckn_prpl = "";  //[O] 미납이자기산원금 JJ_YUNC_ILSU1 연체이자 일수1
		public String npt_inte_irt = "";  //[O] 미납이자이율 JJ_YUNC_IJA1 연체일자 이자1
		public String npt_inte_cal_dcnt = "";  //[O] 미납이자계산일수 JJ_YUNC_F2 연체이자 시작일2
		public String npt_inte_dt = "";  //[O] 미납이자일자         JJ_YUNC_T2 연체일자 종료일2
		public String npt_inte_ocr_amt = "";  //[O] 미납이자발생금액 JJ_YUNC_ILSU2 연체이자 일수2
		public String ppy_inte_pd_dt = "";  //[O] 선납이자시기일자 JJ_YUNC_IJA2 연체일자 이자2
		public String ppy_inte_et_dt = "";  //[O] 선납이자종기일자 JJ_MIGU_F 시작일
		public String ppy_inte_rckn_prpl = "";  //[O] 선납이자기산원금 JJ_MIGU_T 종료일
		public String ppy_inte_irt = "";  //[O] 선납이자이율 JJ_MIGU_ILSU 일수
		public String ppy_inte_cal_dcnt = "";  //[O] 선납이자계산일수 JJ_MIGU_IJA 이자
		public String ppy_inte_dt = "";  //[O] 선납이자일자 HJ_GWAO 과오구분
		public String ppy_inte_amt = "";  //[O] 선납이자금액 JJ_GWAO 과오금액
		public String urnd_inte_pd_dt = "";  //[O] 미경과이자시기일자 JJ_NAPIP_IJA 이자합계
		public String urnd_inte_et_dt = "";  //[O] 미경과이자종기일자 JJ_GWAO_F 과오시작일자
		public String urnd_inte_rckn_prpl = "";  //[O] 미경과이자기산원금 JJ_GWAO_T 과오종료일자
		public String urnd_inte_irt = "";  //[O] 미경과이자이율 JJ_GWAO_ILSU 과오일수
		public String urnd_inte_cal_dcnt = "";  //[O] 미경과이자계산일수  
		public String urnd_inte_dt = "";  //[O] 미경과이자일자  
		public String urnd_inte_amt = "";  //[O] 미경과이자금액  
		public String exca_inte_amt = "";  //[O] 정산이자금액  
		public String mprt_dvn = "";  //[O] 과오구분  
		public String mprt_amt = "";  //[O] 과오금액  
		public String inte_sm = "";  //[O] 이자합계  
		
		public String getPlno() {
			return plno;
		}
		public void setPlno(String plno) {
			this.plno = plno;
		}
		public String getIns_lcpl_dvcd() {
			return ins_lcpl_dvcd;
		}
		public void setIns_lcpl_dvcd(String ins_lcpl_dvcd) {
			this.ins_lcpl_dvcd = ins_lcpl_dvcd;
		}
		public String getPly_sqno() {
			return ply_sqno;
		}
		public void setPly_sqno(String ply_sqno) {
			this.ply_sqno = ply_sqno;
		}
		public String getProc_dvn() {
			return proc_dvn;
		}
		public void setProc_dvn(String proc_dvn) {
			this.proc_dvn = proc_dvn;
		}
		public String getNxt_inte_rv_dd() {
			return nxt_inte_rv_dd;
		}
		public void setNxt_inte_rv_dd(String nxt_inte_rv_dd) {
			this.nxt_inte_rv_dd = nxt_inte_rv_dd;
		}
		public String getPlhd_nm() {
			return plhd_nm;
		}
		public void setPlhd_nm(String plhd_nm) {
			this.plhd_nm = plhd_nm;
		}
		public String getPlhd_rsdn_no() {
			return plhd_rsdn_no;
		}
		public void setPlhd_rsdn_no(String plhd_rsdn_no) {
			this.plhd_rsdn_no = plhd_rsdn_no;
		}
		public String getInpd_cd() {
			return inpd_cd;
		}
		public void setInpd_cd(String inpd_cd) {
			this.inpd_cd = inpd_cd;
		}
		public String getPs_stln_rckn_prpl() {
			return ps_stln_rckn_prpl;
		}
		public void setPs_stln_rckn_prpl(String ps_stln_rckn_prpl) {
			this.ps_stln_rckn_prpl = ps_stln_rckn_prpl;
		}
		public String getPs_stln_rckd() {
			return ps_stln_rckd;
		}
		public void setPs_stln_rckd(String ps_stln_rckd) {
			this.ps_stln_rckd = ps_stln_rckd;
		}
		public String getPs_ppy_et_dd() {
			return ps_ppy_et_dd;
		}
		public void setPs_ppy_et_dd(String ps_ppy_et_dd) {
			this.ps_ppy_et_dd = ps_ppy_et_dd;
		}
		public String getIrt() {
			return irt;
		}
		public void setIrt(String irt) {
			this.irt = irt;
		}
		public String getNrm_inte_pd_dt() {
			return nrm_inte_pd_dt;
		}
		public void setNrm_inte_pd_dt(String nrm_inte_pd_dt) {
			this.nrm_inte_pd_dt = nrm_inte_pd_dt;
		}
		public String getNrm_inte_et_dt() {
			return nrm_inte_et_dt;
		}
		public void setNrm_inte_et_dt(String nrm_inte_et_dt) {
			this.nrm_inte_et_dt = nrm_inte_et_dt;
		}
		public String getNrm_inte_rckn_prpl() {
			return nrm_inte_rckn_prpl;
		}
		public void setNrm_inte_rckn_prpl(String nrm_inte_rckn_prpl) {
			this.nrm_inte_rckn_prpl = nrm_inte_rckn_prpl;
		}
		public String getNrm_inte_irt() {
			return nrm_inte_irt;
		}
		public void setNrm_inte_irt(String nrm_inte_irt) {
			this.nrm_inte_irt = nrm_inte_irt;
		}
		public String getNrm_inte_cal_dcnt() {
			return nrm_inte_cal_dcnt;
		}
		public void setNrm_inte_cal_dcnt(String nrm_inte_cal_dcnt) {
			this.nrm_inte_cal_dcnt = nrm_inte_cal_dcnt;
		}
		public String getNrm_inte_dt() {
			return nrm_inte_dt;
		}
		public void setNrm_inte_dt(String nrm_inte_dt) {
			this.nrm_inte_dt = nrm_inte_dt;
		}
		public String getNrm_inte_amt() {
			return nrm_inte_amt;
		}
		public void setNrm_inte_amt(String nrm_inte_amt) {
			this.nrm_inte_amt = nrm_inte_amt;
		}
		public String getNpt_inte_sm_amt() {
			return npt_inte_sm_amt;
		}
		public void setNpt_inte_sm_amt(String npt_inte_sm_amt) {
			this.npt_inte_sm_amt = npt_inte_sm_amt;
		}
		public String getNpt_inte_pd_dt() {
			return npt_inte_pd_dt;
		}
		public void setNpt_inte_pd_dt(String npt_inte_pd_dt) {
			this.npt_inte_pd_dt = npt_inte_pd_dt;
		}
		public String getNpt_inte_et_dt() {
			return npt_inte_et_dt;
		}
		public void setNpt_inte_et_dt(String npt_inte_et_dt) {
			this.npt_inte_et_dt = npt_inte_et_dt;
		}
		public String getNpt_inte_rckn_prpl() {
			return npt_inte_rckn_prpl;
		}
		public void setNpt_inte_rckn_prpl(String npt_inte_rckn_prpl) {
			this.npt_inte_rckn_prpl = npt_inte_rckn_prpl;
		}
		public String getNpt_inte_irt() {
			return npt_inte_irt;
		}
		public void setNpt_inte_irt(String npt_inte_irt) {
			this.npt_inte_irt = npt_inte_irt;
		}
		public String getNpt_inte_cal_dcnt() {
			return npt_inte_cal_dcnt;
		}
		public void setNpt_inte_cal_dcnt(String npt_inte_cal_dcnt) {
			this.npt_inte_cal_dcnt = npt_inte_cal_dcnt;
		}
		public String getNpt_inte_dt() {
			return npt_inte_dt;
		}
		public void setNpt_inte_dt(String npt_inte_dt) {
			this.npt_inte_dt = npt_inte_dt;
		}
		public String getNpt_inte_ocr_amt() {
			return npt_inte_ocr_amt;
		}
		public void setNpt_inte_ocr_amt(String npt_inte_ocr_amt) {
			this.npt_inte_ocr_amt = npt_inte_ocr_amt;
		}
		public String getPpy_inte_pd_dt() {
			return ppy_inte_pd_dt;
		}
		public void setPpy_inte_pd_dt(String ppy_inte_pd_dt) {
			this.ppy_inte_pd_dt = ppy_inte_pd_dt;
		}
		public String getPpy_inte_et_dt() {
			return ppy_inte_et_dt;
		}
		public void setPpy_inte_et_dt(String ppy_inte_et_dt) {
			this.ppy_inte_et_dt = ppy_inte_et_dt;
		}
		public String getPpy_inte_rckn_prpl() {
			return ppy_inte_rckn_prpl;
		}
		public void setPpy_inte_rckn_prpl(String ppy_inte_rckn_prpl) {
			this.ppy_inte_rckn_prpl = ppy_inte_rckn_prpl;
		}
		public String getPpy_inte_irt() {
			return ppy_inte_irt;
		}
		public void setPpy_inte_irt(String ppy_inte_irt) {
			this.ppy_inte_irt = ppy_inte_irt;
		}
		public String getPpy_inte_cal_dcnt() {
			return ppy_inte_cal_dcnt;
		}
		public void setPpy_inte_cal_dcnt(String ppy_inte_cal_dcnt) {
			this.ppy_inte_cal_dcnt = ppy_inte_cal_dcnt;
		}
		public String getPpy_inte_dt() {
			return ppy_inte_dt;
		}
		public void setPpy_inte_dt(String ppy_inte_dt) {
			this.ppy_inte_dt = ppy_inte_dt;
		}
		public String getPpy_inte_amt() {
			return ppy_inte_amt;
		}
		public void setPpy_inte_amt(String ppy_inte_amt) {
			this.ppy_inte_amt = ppy_inte_amt;
		}
		public String getUrnd_inte_pd_dt() {
			return urnd_inte_pd_dt;
		}
		public void setUrnd_inte_pd_dt(String urnd_inte_pd_dt) {
			this.urnd_inte_pd_dt = urnd_inte_pd_dt;
		}
		public String getUrnd_inte_et_dt() {
			return urnd_inte_et_dt;
		}
		public void setUrnd_inte_et_dt(String urnd_inte_et_dt) {
			this.urnd_inte_et_dt = urnd_inte_et_dt;
		}
		public String getUrnd_inte_rckn_prpl() {
			return urnd_inte_rckn_prpl;
		}
		public void setUrnd_inte_rckn_prpl(String urnd_inte_rckn_prpl) {
			this.urnd_inte_rckn_prpl = urnd_inte_rckn_prpl;
		}
		public String getUrnd_inte_irt() {
			return urnd_inte_irt;
		}
		public void setUrnd_inte_irt(String urnd_inte_irt) {
			this.urnd_inte_irt = urnd_inte_irt;
		}
		public String getUrnd_inte_cal_dcnt() {
			return urnd_inte_cal_dcnt;
		}
		public void setUrnd_inte_cal_dcnt(String urnd_inte_cal_dcnt) {
			this.urnd_inte_cal_dcnt = urnd_inte_cal_dcnt;
		}
		public String getUrnd_inte_dt() {
			return urnd_inte_dt;
		}
		public void setUrnd_inte_dt(String urnd_inte_dt) {
			this.urnd_inte_dt = urnd_inte_dt;
		}
		public String getUrnd_inte_amt() {
			return urnd_inte_amt;
		}
		public void setUrnd_inte_amt(String urnd_inte_amt) {
			this.urnd_inte_amt = urnd_inte_amt;
		}
		public String getExca_inte_amt() {
			return exca_inte_amt;
		}
		public void setExca_inte_amt(String exca_inte_amt) {
			this.exca_inte_amt = exca_inte_amt;
		}
		public String getMprt_dvn() {
			return mprt_dvn;
		}
		public void setMprt_dvn(String mprt_dvn) {
			this.mprt_dvn = mprt_dvn;
		}
		public String getMprt_amt() {
			return mprt_amt;
		}
		public void setMprt_amt(String mprt_amt) {
			this.mprt_amt = mprt_amt;
		}
		public String getInte_sm() {
			return inte_sm;
		}
		public void setInte_sm(String inte_sm) {
			this.inte_sm = inte_sm;
		}
}
