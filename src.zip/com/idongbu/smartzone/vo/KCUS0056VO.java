package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class KCUS0056VO extends CMMVO{
	
	public String cust_dcmt_no = null;	//[I]고객식별번호
	public String tgt_ym = null;     	//[I]대상년월
	public String bcst_dvn = null;		//[O]우수고객구분
	public String clam = null;     		//[O]보상
	public String inpt_dt = null;     	//[O]입력일자
	public String inpt_time = null;		//[O]입력시간
	public String pint = null;     		//[O]포인트
	public String gr = null;     		//[O]등급
	public String gr_nm = null;     	//[O]등급명

	public String errorCode = null;
	
	
	
	public String getCust_dcmt_no() {
		return cust_dcmt_no;
	}
	public void setCust_dcmt_no(String cust_dcmt_no) {
		this.cust_dcmt_no = cust_dcmt_no;
	}
	public String getTgt_ym() {
		return tgt_ym;
	}
	public void setTgt_ym(String tgt_ym) {
		this.tgt_ym = tgt_ym;
	}
	public String getBcst_dvn() {
		return bcst_dvn;
	}
	public void setBcst_dvn(String bcst_dvn) {
		this.bcst_dvn = bcst_dvn;
	}
	public String getClam() {
		return clam;
	}
	public void setClam(String clam) {
		this.clam = clam;
	}
	public String getInpt_dt() {
		return inpt_dt;
	}
	public void setInpt_dt(String inpt_dt) {
		this.inpt_dt = inpt_dt;
	}
	public String getInpt_time() {
		return inpt_time;
	}
	public void setInpt_time(String inpt_time) {
		this.inpt_time = inpt_time;
	}
	public String getPint() {
		return pint;
	}
	public void setPint(String pint) {
		this.pint = pint;
	}
	public String getGr() {
		return gr;
	}
	public void setGr(String gr) {
		this.gr = gr;
	}
	public String getGr_nm() {
		return gr_nm;
	}
	public void setGr_nm(String gr_nm) {
		this.gr_nm = gr_nm;
	}
}
