package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class IFMOB015VO extends CMMVO {

    public String webM = "IF_MOB_015";

    // 입력
    public String I_LN_ID = null;	        // 대출약정번호
    public String I_SSN = null;	            // 고객주민번호
    public String I_CUST_NM = null;	        // 고객명
    public String I_APY_YMD = null;	        // 신청일
    public String I_LN_PRG_SCD = null;	    // 대출진행상태코드
    public String I_DIGIT_SIGN = null;	    // 전자서명값
    public String I_CERT_GB = null;			// 증빙구분
    public String I_CHNL_GB = null;			// 채널구분
    public String I_CERT_ID = null;			// 전자서명 증빙 키값

    // 출력
    public String O_RET_CD = null;			// 결과코드 - 00:정상 , 10:입력값 누락, 11:입력값 오류, 99:시스템오류
    public String O_RET_MSG = null;			// 결과메시지
}
