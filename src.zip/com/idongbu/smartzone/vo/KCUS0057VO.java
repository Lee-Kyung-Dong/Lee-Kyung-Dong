package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class KCUS0057VO extends CMMVO
{
	public String gspt					;// 구분자
	public String cust_no				;// 고객번호
	public String sqno					;// 일련번호
	public String cust_nm				;// 고객명
	public String csn_wrl_yn			;// 동의철회여부
	public String tlp_rc_rejt_yn		;// 전화수신거부여부
	public String cust_if_pus_stop_yn	;// 고객정보열람중지여부
	public String inpt_sr				;// 입력출처
	public String aplc_cust_no			;// 신청인고객번호
	public String rpt_empno				;// 접수사원번호
	public String rpt_ep_nm				;// 접수사원명
	public String aplc_cust_rlt			;// 신청인고객관계
	public String rs_1					;// 사유1
	public String rs_2					;// 사유2
	public String rs_3					;// 사유3
	public String rs_4					;// 사유4
	public String rs_5					;// 사유5
	public String inpt_ep				;// 입력사원
	public String inpt_ep_nm			;// 입력사원명
	public String inpt_bh				;// 입력지점
	public String inpt_brn				;// 입력지부
	public String pw					;// 비밀번호
	
	public String getGspt() {
		return gspt;
	}
	public void setGspt(String gspt) {
		this.gspt = gspt;
	}
	public String getCust_no() {
		return cust_no;
	}
	public void setCust_no(String cust_no) {
		this.cust_no = cust_no;
	}
	public String getSqno() {
		return sqno;
	}
	public void setSqno(String sqno) {
		this.sqno = sqno;
	}
	public String getCust_nm() {
		return cust_nm;
	}
	public void setCust_nm(String cust_nm) {
		this.cust_nm = cust_nm;
	}
	public String getCsn_wrl_yn() {
		return csn_wrl_yn;
	}
	public void setCsn_wrl_yn(String csn_wrl_yn) {
		this.csn_wrl_yn = csn_wrl_yn;
	}
	public String getTlp_rc_rejt_yn() {
		return tlp_rc_rejt_yn;
	}
	public void setTlp_rc_rejt_yn(String tlp_rc_rejt_yn) {
		this.tlp_rc_rejt_yn = tlp_rc_rejt_yn;
	}
	public String getCust_if_pus_stop_yn() {
		return cust_if_pus_stop_yn;
	}
	public void setCust_if_pus_stop_yn(String cust_if_pus_stop_yn) {
		this.cust_if_pus_stop_yn = cust_if_pus_stop_yn;
	}
	public String getInpt_sr() {
		return inpt_sr;
	}
	public void setInpt_sr(String inpt_sr) {
		this.inpt_sr = inpt_sr;
	}
	public String getAplc_cust_no() {
		return aplc_cust_no;
	}
	public void setAplc_cust_no(String aplc_cust_no) {
		this.aplc_cust_no = aplc_cust_no;
	}
	public String getRpt_empno() {
		return rpt_empno;
	}
	public void setRpt_empno(String rpt_empno) {
		this.rpt_empno = rpt_empno;
	}
	public String getRpt_ep_nm() {
		return rpt_ep_nm;
	}
	public void setRpt_ep_nm(String rpt_ep_nm) {
		this.rpt_ep_nm = rpt_ep_nm;
	}
	public String getAplc_cust_rlt() {
		return aplc_cust_rlt;
	}
	public void setAplc_cust_rlt(String aplc_cust_rlt) {
		this.aplc_cust_rlt = aplc_cust_rlt;
	}
	public String getRs_1() {
		return rs_1;
	}
	public void setRs_1(String rs_1) {
		this.rs_1 = rs_1;
	}
	public String getRs_2() {
		return rs_2;
	}
	public void setRs_2(String rs_2) {
		this.rs_2 = rs_2;
	}
	public String getRs_3() {
		return rs_3;
	}
	public void setRs_3(String rs_3) {
		this.rs_3 = rs_3;
	}
	public String getRs_4() {
		return rs_4;
	}
	public void setRs_4(String rs_4) {
		this.rs_4 = rs_4;
	}
	public String getRs_5() {
		return rs_5;
	}
	public void setRs_5(String rs_5) {
		this.rs_5 = rs_5;
	}
	public String getInpt_ep() {
		return inpt_ep;
	}
	public void setInpt_ep(String inpt_ep) {
		this.inpt_ep = inpt_ep;
	}
	public String getInpt_ep_nm() {
		return inpt_ep_nm;
	}
	public void setInpt_ep_nm(String inpt_ep_nm) {
		this.inpt_ep_nm = inpt_ep_nm;
	}
	public String getInpt_bh() {
		return inpt_bh;
	}
	public void setInpt_bh(String inpt_bh) {
		this.inpt_bh = inpt_bh;
	}
	public String getInpt_brn() {
		return inpt_brn;
	}
	public void setInpt_brn(String inpt_brn) {
		this.inpt_brn = inpt_brn;
	}
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}
}
