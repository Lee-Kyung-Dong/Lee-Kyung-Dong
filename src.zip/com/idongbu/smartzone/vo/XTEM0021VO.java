package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class XTEM0021VO extends CMMVO {

	// 주행거리 미정산 건(변경확정신청까지만 된 경우) TM통합시스템에 계약정보 적재 요청(2020.09.23 김영민 과장)
	// 계약정보 및 고객정보 TM통합 적재위한 전문
	
	// [IN]
	public String cnsl_rpt_no = "";					// 상담접수번호
	public String cm_bz_dvcd = "";					// CM업무구분코드 (02: 자동차)
	public String cnsl_typ_dvcd = "";				// 상담유형구분코드 (07: 계약변경확정신청)
	public String cm_plan_no = "";					// CM설계번호
	public String cnsl_rpy_dvcd = "";				// 상담회신구분코드 (1: 전화)
	public String cnsl_rpt_dttm = "";				// 상담접수일시 (현재일시(년월일시분초 14자리))
	public String cust_nm = "";						// 고객명
	public String cust_no = "";						// 고객번호
	public String brth = "";						// 생년월일
	public String sx_cd = "";						// 성별코드(1: 남성, 2: 여성)
	public String eml_adr = "";						// 이메일주소
	public String clp_tlcno = "";					// 휴대폰통신사번호
	public String clp_ofno = "";					// 휴대폰국번호
	public String clp_idvno = "";					// 휴대폰개별번호
	public String cnsl_rsvt_dt = "";				// 상담예약일자 (99990101 고정)
	public String cnsl_rsvt_time_cd = "";			// 상담예약시간코드 (1(09~12시))
	public String cnsl_cn = "";						// 상담내용 ("최종주행거리사진등록/만기정산")
	public String cnsl_aply_csn_yn = "";			// 상담신청동의여부 (1: Y)
	public String url_adr = "";						// URL 주소
	public String cm_ctrmf_tpcd = "";				// CM계약변경유형코드 (32: 최종사진등록)
	public String frst_ipmn_empno = "";				// 최초입력자사원번호 (80000028)
	public String frst_ipnpt_dttm = "";				// 최초입력일시 (현재일시(년월일시분초 14자리))
	
	// [OUT]
	public String proc_rtn = "";					// 처리결과

	public String getCnsl_rpt_no() {
		return cnsl_rpt_no;
	}

	public void setCnsl_rpt_no(String cnsl_rpt_no) {
		this.cnsl_rpt_no = cnsl_rpt_no;
	}

	public String getCm_bz_dvcd() {
		return cm_bz_dvcd;
	}

	public void setCm_bz_dvcd(String cm_bz_dvcd) {
		this.cm_bz_dvcd = cm_bz_dvcd;
	}

	public String getCnsl_typ_dvcd() {
		return cnsl_typ_dvcd;
	}

	public void setCnsl_typ_dvcd(String cnsl_typ_dvcd) {
		this.cnsl_typ_dvcd = cnsl_typ_dvcd;
	}

	public String getCm_plan_no() {
		return cm_plan_no;
	}

	public void setCm_plan_no(String cm_plan_no) {
		this.cm_plan_no = cm_plan_no;
	}

	public String getCnsl_rpy_dvcd() {
		return cnsl_rpy_dvcd;
	}

	public void setCnsl_rpy_dvcd(String cnsl_rpy_dvcd) {
		this.cnsl_rpy_dvcd = cnsl_rpy_dvcd;
	}

	public String getCnsl_rpt_dttm() {
		return cnsl_rpt_dttm;
	}

	public void setCnsl_rpt_dttm(String cnsl_rpt_dttm) {
		this.cnsl_rpt_dttm = cnsl_rpt_dttm;
	}

	public String getCust_nm() {
		return cust_nm;
	}

	public void setCust_nm(String cust_nm) {
		this.cust_nm = cust_nm;
	}

	public String getCust_no() {
		return cust_no;
	}

	public void setCust_no(String cust_no) {
		this.cust_no = cust_no;
	}

	public String getBrth() {
		return brth;
	}

	public void setBrth(String brth) {
		this.brth = brth;
	}

	public String getSx_cd() {
		return sx_cd;
	}

	public void setSx_cd(String sx_cd) {
		this.sx_cd = sx_cd;
	}

	public String getEml_adr() {
		return eml_adr;
	}

	public void setEml_adr(String eml_adr) {
		this.eml_adr = eml_adr;
	}

	public String getClp_tlcno() {
		return clp_tlcno;
	}

	public void setClp_tlcno(String clp_tlcno) {
		this.clp_tlcno = clp_tlcno;
	}

	public String getClp_ofno() {
		return clp_ofno;
	}

	public void setClp_ofno(String clp_ofno) {
		this.clp_ofno = clp_ofno;
	}

	public String getClp_idvno() {
		return clp_idvno;
	}

	public void setClp_idvno(String clp_idvno) {
		this.clp_idvno = clp_idvno;
	}

	public String getCnsl_rsvt_dt() {
		return cnsl_rsvt_dt;
	}

	public void setCnsl_rsvt_dt(String cnsl_rsvt_dt) {
		this.cnsl_rsvt_dt = cnsl_rsvt_dt;
	}

	public String getCnsl_rsvt_time_cd() {
		return cnsl_rsvt_time_cd;
	}

	public void setCnsl_rsvt_time_cd(String cnsl_rsvt_time_cd) {
		this.cnsl_rsvt_time_cd = cnsl_rsvt_time_cd;
	}

	public String getCnsl_cn() {
		return cnsl_cn;
	}

	public void setCnsl_cn(String cnsl_cn) {
		this.cnsl_cn = cnsl_cn;
	}

	public String getCnsl_aply_csn_yn() {
		return cnsl_aply_csn_yn;
	}

	public void setCnsl_aply_csn_yn(String cnsl_aply_csn_yn) {
		this.cnsl_aply_csn_yn = cnsl_aply_csn_yn;
	}

	public String getUrl_adr() {
		return url_adr;
	}

	public void setUrl_adr(String url_adr) {
		this.url_adr = url_adr;
	}

	public String getCm_ctrmf_tpcd() {
		return cm_ctrmf_tpcd;
	}

	public void setCm_ctrmf_tpcd(String cm_ctrmf_tpcd) {
		this.cm_ctrmf_tpcd = cm_ctrmf_tpcd;
	}

	public String getFrst_ipmn_empno() {
		return frst_ipmn_empno;
	}

	public void setFrst_ipmn_empno(String frst_ipmn_empno) {
		this.frst_ipmn_empno = frst_ipmn_empno;
	}

	public String getFrst_ipnpt_dttm() {
		return frst_ipnpt_dttm;
	}

	public void setFrst_ipnpt_dttm(String frst_ipnpt_dttm) {
		this.frst_ipnpt_dttm = frst_ipnpt_dttm;
	}

	public String getProc_rtn() {
		return proc_rtn;
	}

	public void setProc_rtn(String proc_rtn) {
		this.proc_rtn = proc_rtn;
	}
	
	
	
}
