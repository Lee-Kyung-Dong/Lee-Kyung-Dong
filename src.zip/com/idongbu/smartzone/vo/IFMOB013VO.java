package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class IFMOB013VO extends CMMVO {

    public String webM = "IF_MOB_013";

    // 입력
    public String I_SSN = null;				// 주민번호
    public String I_CUST_NM = null;         // 고객명
    public String I_PNO = null;             // 우편번호
    public String I_ADDR1 = null;           // 우편번호 주소
    public String I_ADDR2 = null;           // 상세주소
    public String I_HOME_TEL = null;        // 자택전화번호
    public String I_HP_TEL = null;          // 휴대폰번호
    public String I_SMS_RECI_YN = null;     // SMS 수신여부
    public String I_EMAIL = null;           // 이메일주소
    public String I_PST_GRE_YN = null;      // 안내장수령방법
    public String I_PST_GRE_ADDR_GB = null; // 우편물수령처 구분

    // 출력
    public String O_RET_CD = null;			// 결과코드 - 00:정상 , 10:입력값 누락, 11:입력값 오류, 99:시스템오류
    public String O_RET_MSG = null;			// 결과메시지

}
