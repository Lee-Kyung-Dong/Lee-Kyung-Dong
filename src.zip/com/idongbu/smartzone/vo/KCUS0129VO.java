package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class KCUS0129VO extends CMMVO
{
	public String proc_dvn			= ""; // 처리구분
	public String cust_dcmt_no		= ""; // 고객식별번호
	public String clp_arno			= ""; // 휴대폰지역번호
	public String clp_ofno			= ""; // 휴대폰국번호
	public String clp_idvno			= ""; // 휴대폰개별번호
	public String tlp_can_rejt_yn	= ""; // 전화연락거부여부
	public String sms_rc_rejt_yn	= ""; // SMS수신거부여부
	public String eml_rc_rejt_yn	= ""; // 이메일수신거부여부
	public String dm_rc_rejt_yn		= ""; // DM수신거부여부
	public String regt_mtd_dvcd		= ""; // 등록방법구분코드
	public String csn_sr_dvcd		= ""; // 동의출처구분코드

}
