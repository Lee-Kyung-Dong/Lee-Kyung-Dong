package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class EAST0012VO extends CMMVO{
	//전문필드
		public String plno = "";  //[I] 증권번호 JJ_POLI_NO 증권번호
		// 차세대 2차 전환 시작 필드 추가 (김도연 2014.02.14)
		public String ins_lcpl_dvcd = "";  //[I] 피보험자소재지구분코드  
		public String ply_sqno = "";  //[I] 증권일련번호  
		public String plno1 = "";  //[I] 증권번호 JJ_POLI_NO 증권번호
		public String ins_lcpl_dvcd1 = "";  //[I] 피보험자소재지구분코드  
		public String ply_sqno1 = "";  //[I] 증권일련번호
		// 차세대 2차 전환 종료 필드 추가 (김도연 2014.02.14) 
		public String rmn_sno = "";  //[I] 송금순번 JJ_SONGGUM_SEQ 송금순번
		public String ln_amt = "";  //[I] 대출금액 JJ_DECHUL_GM 대출금
		public String tsfr_dd = "";  //[I] 이체일 JJ_ICHE_D 이체일
		public String slf_yn = "";  //[I] 본인여부 JJ_BONIN_YN 본인여부
		public String plno_1 = "";  //[I] 증권번호1 JJ_S_POLI_NO 증권번호
		public String bank_cd = "";  //[I] 은행코드 JJ_S_BANK_CD 은행코드
		public String acc_no = "";  //[I] 계좌번호 JJ_S_GYEJWA_NO 계좌번호
		public String inpl_ln_bank_cd = "";  //[I/O] 약관대출은행코드 JJ_I_BANK_CD 약관대출은행코드
		public String inpl_ln_acc_no = "";  //[I/O] 약관대출계좌번호 JJ_I_GYEJWA_NO 약관대출계좌번호
		public String acc_yn = "";  //[I] 계좌여부 JJ_GYEJWA_YN 계좌여부
		public String inpd_nm = "";  //[O] 보종명 HJ_BJ_NM 보종명
		public String inpd_cd = "";  //[O] 보종코드
		public String rckn_amt = "";  //[O] 기산금액 JJ_GISAN_GM 기산금
		public String pym_dd = "";  //[O] 납입일 JJ_NAPIP_YMD 납입일
		public String nrm_irt = "";  //[O] 정상이율 JJ_JUNG_IYUL 정상이율
		public String stln_pss_amt = "";  //[O] 약대가능금액 JJ_GANUNG_GM 약대가능금액
		public String bank_cd_1 = "";  //[O] 은행코드1 JJ_BANK_CD 은행코드
		public String bank_nm = "";  //[O] 은행명 HJ_BANK_NM 은행명
		public String bank_bh_cd = "";  //[O] 은행지점코드 JJ_BANK_JIJUM 은행지점코드
		public String bank_bh_nm = "";  //[O] 은행지점명 HJ_BANK_JIJUM_NM 은행지점명
		public String acc_no_1 = "";  //[O] 계좌번호1 JJ_GYEJWA_NO 계좌번호
		public String dpsr_nm = "";  //[O] 예금주명 HJ_YEGMJU_NM 예금주명
		public String dpsr_tlno = "";  //[O] 예금주전화번호 JJ_YEGMJU_TEL 예금주전화번호
		public String inpt_cd = "";  //[O] 입력코드 JJ_RECI_CD RECEIVE코드
		public String pym_inte = "";  //[O] 납입이자 JJ_NAPIP_IJA 납입이자
		public String rcog_tx = "";  //[O] 인지세 JJ_INJIDAE 인지대
		public String dct_amt = "";  //[O] 공제금액 JJ_GONGJE_GM 공제금
		public String subt_amt = "";  //[O] 차감금액 JJ_CHAGAM_GM 차감금
		public String ovdu_irt = "";  //[O] 연체이율 JJ_YUNC_IYUL 연체이율
		public String ctf_yn = "";  //[I] 인증여부 JJ_INJNG 인증여부
		public String ars_rtun_cd = "";  //[I] ARS리턴코드 JJ_ARS_RC ARS리턴코드
		public String slp = "";  //[I/O] 전표 JJ_JUNPYO 전표
		public String staf_pa_dvn = "";  //[I] 직원PA구분 JJ_JIKWON_PA 직원PA구분
		public String errorCode = "";  //에러코드

		public String wthd_csn_evd_dat_dvcd = ""; // [I] 출금동의증빙자료구분코드
		public String wthd_csn_evd_dat_inpt_dvcd = ""; // [I] 출금동의증빙자료입력구분코드
		public String wthd_csn_evd_dat_val = ""; // [I] 출금동의증빙자료값
		
		public String getPlno() {
			return plno;
		}
		public void setPlno(String plno) {
			this.plno = plno;
		}
		public String getPlno1() {
			return plno1;
		}
		public void setPlno1(String plno1) {
			this.plno1 = plno1;
		}
		public void setPlno_1(String plno_1) {
			this.plno_1 = plno_1;
		}
		public String getIns_lcpl_dvcd() {
			return ins_lcpl_dvcd;
		}
		public void setIns_lcpl_dvcd(String ins_lcpl_dvcd) {
			this.ins_lcpl_dvcd = ins_lcpl_dvcd;
		}
		public String getPly_sqno() {
			return ply_sqno;
		}
		public void setPly_sqno(String ply_sqno) {
			this.ply_sqno = ply_sqno;
		}
		
		public String getIns_lcpl_dvcd1() {
			return ins_lcpl_dvcd1;
		}
		public void setIns_lcpl_dvcd1(String ins_lcpl_dvcd1) {
			this.ins_lcpl_dvcd1 = ins_lcpl_dvcd1;
		}
		public String getPly_sqno1() {
			return ply_sqno1;
		}
		public void setPly_sqno1(String ply_sqno1) {
			this.ply_sqno1 = ply_sqno1;
		}
		public String getRmn_sno() {
			return rmn_sno;
		}
		public void setRmn_sno(String rmn_sno) {
			this.rmn_sno = rmn_sno;
		}
		public String getLn_amt() {
			return ln_amt;
		}
		public void setLn_amt(String ln_amt) {
			this.ln_amt = ln_amt;
		}
		public String getTsfr_dd() {
			return tsfr_dd;
		}
		public void setTsfr_dd(String tsfr_dd) {
			this.tsfr_dd = tsfr_dd;
		}
		public String getSlf_yn() {
			return slf_yn;
		}
		public void setSlf_yn(String slf_yn) {
			this.slf_yn = slf_yn;
		}
		
		
		public String getBank_cd() {
			return bank_cd;
		}
		public void setBank_cd(String bank_cd) {
			this.bank_cd = bank_cd;
		}
		public String getAcc_no() {
			return acc_no;
		}
		public void setAcc_no(String acc_no) {
			this.acc_no = acc_no;
		}
		public String getInpl_ln_bank_cd() {
			return inpl_ln_bank_cd;
		}
		public void setInpl_ln_bank_cd(String inpl_ln_bank_cd) {
			this.inpl_ln_bank_cd = inpl_ln_bank_cd;
		}
		public String getInpl_ln_acc_no() {
			return inpl_ln_acc_no;
		}
		public void setInpl_ln_acc_no(String inpl_ln_acc_no) {
			this.inpl_ln_acc_no = inpl_ln_acc_no;
		}
		public String getAcc_yn() {
			return acc_yn;
		}
		public void setAcc_yn(String acc_yn) {
			this.acc_yn = acc_yn;
		}
		public String getInpd_nm() {
			return inpd_nm;
		}
		public void setInpd_nm(String inpd_nm) {
			this.inpd_nm = inpd_nm;
		}
		public String getInpd_cd() {
			return inpd_cd;
		}
		public void setInpd_cd(String inpd_cd) {
			this.inpd_cd = inpd_cd;
		}
		public String getRckn_amt() {
			return rckn_amt;
		}
		public void setRckn_amt(String rckn_amt) {
			this.rckn_amt = rckn_amt;
		}
		public String getPym_dd() {
			return pym_dd;
		}
		public void setPym_dd(String pym_dd) {
			this.pym_dd = pym_dd;
		}
		public String getNrm_irt() {
			return nrm_irt;
		}
		public void setNrm_irt(String nrm_irt) {
			this.nrm_irt = nrm_irt;
		}
		public String getStln_pss_amt() {
			return stln_pss_amt;
		}
		public void setStln_pss_amt(String stln_pss_amt) {
			this.stln_pss_amt = stln_pss_amt;
		}
		public String getBank_cd_1() {
			return bank_cd_1;
		}
		public void setBank_cd_1(String bank_cd_1) {
			this.bank_cd_1 = bank_cd_1;
		}
		public String getBank_nm() {
			return bank_nm;
		}
		public void setBank_nm(String bank_nm) {
			this.bank_nm = bank_nm;
		}
		public String getBank_bh_cd() {
			return bank_bh_cd;
		}
		public void setBank_bh_cd(String bank_bh_cd) {
			this.bank_bh_cd = bank_bh_cd;
		}
		public String getBank_bh_nm() {
			return bank_bh_nm;
		}
		public void setBank_bh_nm(String bank_bh_nm) {
			this.bank_bh_nm = bank_bh_nm;
		}
		public String getAcc_no_1() {
			return acc_no_1;
		}
		public void setAcc_no_1(String acc_no_1) {
			this.acc_no_1 = acc_no_1;
		}
		public String getDpsr_nm() {
			return dpsr_nm;
		}
		public void setDpsr_nm(String dpsr_nm) {
			this.dpsr_nm = dpsr_nm;
		}
		public String getDpsr_tlno() {
			return dpsr_tlno;
		}
		public void setDpsr_tlno(String dpsr_tlno) {
			this.dpsr_tlno = dpsr_tlno;
		}
		public String getInpt_cd() {
			return inpt_cd;
		}
		public void setInpt_cd(String inpt_cd) {
			this.inpt_cd = inpt_cd;
		}
		public String getPym_inte() {
			return pym_inte;
		}
		public void setPym_inte(String pym_inte) {
			this.pym_inte = pym_inte;
		}
		public String getRcog_tx() {
			return rcog_tx;
		}
		public void setRcog_tx(String rcog_tx) {
			this.rcog_tx = rcog_tx;
		}
		public String getDct_amt() {
			return dct_amt;
		}
		public void setDct_amt(String dct_amt) {
			this.dct_amt = dct_amt;
		}
		public String getSubt_amt() {
			return subt_amt;
		}
		public void setSubt_amt(String subt_amt) {
			this.subt_amt = subt_amt;
		}
		public String getOvdu_irt() {
			return ovdu_irt;
		}
		public void setOvdu_irt(String ovdu_irt) {
			this.ovdu_irt = ovdu_irt;
		}
		public String getCtf_yn() {
			return ctf_yn;
		}
		public void setCtf_yn(String ctf_yn) {
			this.ctf_yn = ctf_yn;
		}
		public String getArs_rtun_cd() {
			return ars_rtun_cd;
		}
		public void setArs_rtun_cd(String ars_rtun_cd) {
			this.ars_rtun_cd = ars_rtun_cd;
		}
		public String getSlp() {
			return slp;
		}
		public void setSlp(String slp) {
			this.slp = slp;
		}
		public String getStaf_pa_dvn() {
			return staf_pa_dvn;
		}
		public void setStaf_pa_dvn(String staf_pa_dvn) {
			this.staf_pa_dvn = staf_pa_dvn;
		}
		
		public String getWthd_csn_evd_dat_dvcd() {
			return wthd_csn_evd_dat_dvcd;
		}
		public void setWthd_csn_evd_dat_dvcd(String wthd_csn_evd_dat_dvcd) {
			this.wthd_csn_evd_dat_dvcd = wthd_csn_evd_dat_dvcd;
		}
		public String getWthd_csn_evd_dat_inpt_dvcd() {
			return wthd_csn_evd_dat_inpt_dvcd;
		}
		public void setWthd_csn_evd_dat_inpt_dvcd(String wthd_csn_evd_dat_inpt_dvcd) {
			this.wthd_csn_evd_dat_inpt_dvcd = wthd_csn_evd_dat_inpt_dvcd;
		}
		public String getWthd_csn_evd_dat_val() {
			return wthd_csn_evd_dat_val;
		}
		public void setWthd_csn_evd_dat_val(String wthd_csn_evd_dat_val) {
			this.wthd_csn_evd_dat_val = wthd_csn_evd_dat_val;
		}		

}
