package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class CCLM0065VO extends CMMVO {

	//전문필드
		public String msg_cd = "";  //[O] 메세지코드 LK_MSG_CD2 메세지코드2
		public String msg = "";  //[O] 메시지 H_LK_MESSAGE2 메시지2
		public String accd_rpt_no = "";  //[I] 사고접수번호          LK_I_SAGO_JUBSU_NO 사고접수번호         
		public String accd_typ = "";  //[O] 사고유형 LK_SAGO_TYPE_NAME 사고유형
		public String accd_typ_2 = "";  //[O] 사고유형2 LK_SAGO_TYPE_NAME2 사고유형2
		public String flt_dvn = "";  //[O] 과실구분 LK_GWASIL_GB 과실구분
		public String flt_nm = "";  //[O] 과실명 LK_GWASIL_NAME 과실명
		public String poli_rpr = "";  //[O] 경찰신고 LK_POLICE_SINGO 경찰신고
		public String accd_cn = "";  //[O] 사고내용 LK_SAGO_CONT 사고내용
		public String bh_nm = "";  //[O] 지점명 LK_BR_NAME 지점명
		public String team_nm = "";  //[O] 팀명 LK_TEAM_NAME 팀명
		public String psic_nm = "";  //[O] 담당자명 LK_DAMDANGJA 담당자명
		public String tlno = "";  //[O] 전화번호 LK_DAMDANG_TEL 전화번호
		
		public String getMsg_cd() {
			return msg_cd;
		}
		public void setMsg_cd(String msg_cd) {
			this.msg_cd = msg_cd;
		}
		public String getMsg() {
			return msg;
		}
		public void setMsg(String msg) {
			this.msg = msg;
		}
		public String getAccd_rpt_no() {
			return accd_rpt_no;
		}
		public void setAccd_rpt_no(String accd_rpt_no) {
			this.accd_rpt_no = accd_rpt_no;
		}
		public String getAccd_typ() {
			return accd_typ;
		}
		public void setAccd_typ(String accd_typ) {
			this.accd_typ = accd_typ;
		}
		public String getAccd_typ_2() {
			return accd_typ_2;
		}
		public void setAccd_typ_2(String accd_typ_2) {
			this.accd_typ_2 = accd_typ_2;
		}
		public String getFlt_dvn() {
			return flt_dvn;
		}
		public void setFlt_dvn(String flt_dvn) {
			this.flt_dvn = flt_dvn;
		}
		public String getFlt_nm() {
			return flt_nm;
		}
		public void setFlt_nm(String flt_nm) {
			this.flt_nm = flt_nm;
		}
		public String getPoli_rpr() {
			return poli_rpr;
		}
		public void setPoli_rpr(String poli_rpr) {
			this.poli_rpr = poli_rpr;
		}
		public String getAccd_cn() {
			return accd_cn;
		}
		public void setAccd_cn(String accd_cn) {
			this.accd_cn = accd_cn;
		}
		public String getBh_nm() {
			return bh_nm;
		}
		public void setBh_nm(String bh_nm) {
			this.bh_nm = bh_nm;
		}
		public String getTeam_nm() {
			return team_nm;
		}
		public void setTeam_nm(String team_nm) {
			this.team_nm = team_nm;
		}
		public String getPsic_nm() {
			return psic_nm;
		}
		public void setPsic_nm(String psic_nm) {
			this.psic_nm = psic_nm;
		}
		public String getTlno() {
			return tlno;
		}
		public void setTlno(String tlno) {
			this.tlno = tlno;
		}
}
