package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class EAST0014VO extends CMMVO{
	//전문필드
		public String plhd_rsdn_no = "";  //[I] 계약자주민번호 JJ_GY_JUMIN 계약자주민번호
		public String plhd_nm = "";  //[I] 계약자명 HJ_GY_NM 계약자명
		public String[] inet_arc_ctc_ln_rpm_srch_mngt_lit__plno = new String[0];  //[O] _증권번호 JJ_POLI_NO 증권번호
		// 차세대 2차 전환 시작 필드 추가 (김도연 2014.02.14)
		public String[] inet_arc_ctc_ln_rpm_srch_mngt_lit__ins_lcpl_dvcd = new String[0];  //[O] _피보험자소재지구분코드  
		public String[] inet_arc_ctc_ln_rpm_srch_mngt_lit__ply_sqno = new String[0];  //[O] _증권일련번호
		// 차세대 2차 전환 종료 필드 추가 (김도연 2014.02.14) 
		public String[] inet_arc_ctc_ln_rpm_srch_mngt_lit__inpd_cd = new String[0];  //[O] _보종코드 JJ_BJ 보종코드
		public String[] inet_arc_ctc_ln_rpm_srch_mngt_lit__inpd_nm = new String[0];  //[O] _보종명 HJ_BJ 보종명
		public String[] inet_arc_ctc_ln_rpm_srch_mngt_lit__rckn_amt = new String[0];  //[O] _기산금액 JJ_GISAN_GM 기산금액
		public String[] inet_arc_ctc_ln_rpm_srch_mngt_lit__npt_inte = new String[0];  //[O] _미납이자 JJ_MINAP_IJA 미납이자
		public String[] inet_arc_ctc_ln_rpm_srch_mngt_lit__rpm_amtt = new String[0];  //[O] _상환금액합계 JJ_SANG_TOT 상환금액합계
		public String[] inet_arc_ctc_ln_rpm_srch_mngt_lit__rckn_dt = new String[0];  //[O] _기산일자 JJ_GISAN_YMD 기산일자
		public String[] inet_arc_ctc_ln_rpm_srch_mngt_lit__irt = new String[0];  //[O] _이율 JJ_IYUL 이율
		public String[] inet_arc_ctc_ln_rpm_srch_mngt_lit__acc_no = new String[0];  //[O] _계좌번호 JJ_GYEJWA_NO 계좌번호
		public String[] inet_arc_ctc_ln_rpm_srch_mngt_lit__dpsr_rsdn_no = new String[0];  //[O] _예금주주민번호 JJ_YEGMJU_JUMINNO 예금주주민번호
		public String[] inet_arc_ctc_ln_rpm_srch_mngt_lit__dpsr_nm = new String[0];  //[O] _예금주명 HJ_YEGMJU_NAME 예금주명
		public String[] inet_arc_ctc_ln_rpm_srch_mngt_lit__tsfr_ocd = new String[0];  //[O] _이체관코드 JJ_ICHE_GWANCD 이체관코드
		public String[] inet_arc_ctc_ln_rpm_srch_mngt_lit__bank_cd = new String[0];  //[O] _은행코드 JJ_BANK_CD 은행코드
		public String[] inet_arc_ctc_ln_rpm_srch_mngt_lit__bank_nm = new String[0];  //[O] _은행명 HJ_BANK_NAME 은행명
		public String[] inet_arc_ctc_ln_rpm_srch_mngt_lit__tsfr_dt = new String[0];  //[O] _이체일자 JJ_ICHE_DD 이체일자
		public String[] inet_arc_ctc_ln_rpm_srch_mngt_lit__aply_rsl = new String[0];  //[O] _신청결과 JJ_SINCHERNG_RST 신청결과
		public String[] inet_arc_ctc_ln_rpm_srch_mngt_lit__pym_prm = new String[0];  //[O] _납입보험료 JJ_NAPIPHAL_PRM 납입할보험료
		public String[] inet_arc_ctc_ln_rpm_srch_mngt_lit__chng_dt = new String[0];  //[O] _변경일자 JJ_CHANGE_YMD 변경일자
		
		//2015.06.09 상환프로세스 제어 추가 박형규 
		public String[] inet_arc_ctc_ln_rpm_srch_mngt_lit__ctc_stat_cd = new String[0];  //[O] _계약상태코드
		public String[] inet_arc_ctc_ln_rpm_srch_mngt_lit__arc_trm_str_dt = new String[0];  //[O] _보험기간시작일자
		
		
		public String errorCode = ""; // 에러코드
		
		
		public String getErrorCode() {
			return errorCode;
		}
		public void setErrorCode(String errorCode) {
			this.errorCode = errorCode;
		}
		public String getPlhd_rsdn_no() {
			return plhd_rsdn_no;
		}
		public void setPlhd_rsdn_no(String plhd_rsdn_no) {
			this.plhd_rsdn_no = plhd_rsdn_no;
		}
		public String getPlhd_nm() {
			return plhd_nm;
		}
		public void setPlhd_nm(String plhd_nm) {
			this.plhd_nm = plhd_nm;
		}
		public String[] getInet_arc_ctc_ln_rpm_srch_mngt_lit__plno() {
			return inet_arc_ctc_ln_rpm_srch_mngt_lit__plno;
		}
		public void setInet_arc_ctc_ln_rpm_srch_mngt_lit__plno(
				String[] inet_arc_ctc_ln_rpm_srch_mngt_lit__plno) {
			this.inet_arc_ctc_ln_rpm_srch_mngt_lit__plno = inet_arc_ctc_ln_rpm_srch_mngt_lit__plno;
		}
		public String[] getInet_arc_ctc_ln_rpm_srch_mngt_lit__ins_lcpl_dvcd() {
			return inet_arc_ctc_ln_rpm_srch_mngt_lit__ins_lcpl_dvcd;
		}
		public void setInet_arc_ctc_ln_rpm_srch_mngt_lit__ins_lcpl_dvcd(
				String[] inet_arc_ctc_ln_rpm_srch_mngt_lit__ins_lcpl_dvcd) {
			this.inet_arc_ctc_ln_rpm_srch_mngt_lit__ins_lcpl_dvcd = inet_arc_ctc_ln_rpm_srch_mngt_lit__ins_lcpl_dvcd;
		}
		public String[] getInet_arc_ctc_ln_rpm_srch_mngt_lit__ply_sqno() {
			return inet_arc_ctc_ln_rpm_srch_mngt_lit__ply_sqno;
		}
		public void setInet_arc_ctc_ln_rpm_srch_mngt_lit__ply_sqno(
				String[] inet_arc_ctc_ln_rpm_srch_mngt_lit__ply_sqno) {
			this.inet_arc_ctc_ln_rpm_srch_mngt_lit__ply_sqno = inet_arc_ctc_ln_rpm_srch_mngt_lit__ply_sqno;
		}
		public String[] getInet_arc_ctc_ln_rpm_srch_mngt_lit__inpd_cd() {
			return inet_arc_ctc_ln_rpm_srch_mngt_lit__inpd_cd;
		}
		public void setInet_arc_ctc_ln_rpm_srch_mngt_lit__inpd_cd(
				String[] inet_arc_ctc_ln_rpm_srch_mngt_lit__inpd_cd) {
			this.inet_arc_ctc_ln_rpm_srch_mngt_lit__inpd_cd = inet_arc_ctc_ln_rpm_srch_mngt_lit__inpd_cd;
		}
		public String[] getInet_arc_ctc_ln_rpm_srch_mngt_lit__inpd_nm() {
			return inet_arc_ctc_ln_rpm_srch_mngt_lit__inpd_nm;
		}
		public void setInet_arc_ctc_ln_rpm_srch_mngt_lit__inpd_nm(
				String[] inet_arc_ctc_ln_rpm_srch_mngt_lit__inpd_nm) {
			this.inet_arc_ctc_ln_rpm_srch_mngt_lit__inpd_nm = inet_arc_ctc_ln_rpm_srch_mngt_lit__inpd_nm;
		}
		public String[] getInet_arc_ctc_ln_rpm_srch_mngt_lit__rckn_amt() {
			return inet_arc_ctc_ln_rpm_srch_mngt_lit__rckn_amt;
		}
		public void setInet_arc_ctc_ln_rpm_srch_mngt_lit__rckn_amt(
				String[] inet_arc_ctc_ln_rpm_srch_mngt_lit__rckn_amt) {
			this.inet_arc_ctc_ln_rpm_srch_mngt_lit__rckn_amt = inet_arc_ctc_ln_rpm_srch_mngt_lit__rckn_amt;
		}
		public String[] getInet_arc_ctc_ln_rpm_srch_mngt_lit__npt_inte() {
			return inet_arc_ctc_ln_rpm_srch_mngt_lit__npt_inte;
		}
		public void setInet_arc_ctc_ln_rpm_srch_mngt_lit__npt_inte(
				String[] inet_arc_ctc_ln_rpm_srch_mngt_lit__npt_inte) {
			this.inet_arc_ctc_ln_rpm_srch_mngt_lit__npt_inte = inet_arc_ctc_ln_rpm_srch_mngt_lit__npt_inte;
		}
		public String[] getInet_arc_ctc_ln_rpm_srch_mngt_lit__rpm_amtt() {
			return inet_arc_ctc_ln_rpm_srch_mngt_lit__rpm_amtt;
		}
		public void setInet_arc_ctc_ln_rpm_srch_mngt_lit__rpm_amtt(
				String[] inet_arc_ctc_ln_rpm_srch_mngt_lit__rpm_amtt) {
			this.inet_arc_ctc_ln_rpm_srch_mngt_lit__rpm_amtt = inet_arc_ctc_ln_rpm_srch_mngt_lit__rpm_amtt;
		}
		public String[] getInet_arc_ctc_ln_rpm_srch_mngt_lit__rckn_dt() {
			return inet_arc_ctc_ln_rpm_srch_mngt_lit__rckn_dt;
		}
		public void setInet_arc_ctc_ln_rpm_srch_mngt_lit__rckn_dt(
				String[] inet_arc_ctc_ln_rpm_srch_mngt_lit__rckn_dt) {
			this.inet_arc_ctc_ln_rpm_srch_mngt_lit__rckn_dt = inet_arc_ctc_ln_rpm_srch_mngt_lit__rckn_dt;
		}
		public String[] getInet_arc_ctc_ln_rpm_srch_mngt_lit__irt() {
			return inet_arc_ctc_ln_rpm_srch_mngt_lit__irt;
		}
		public void setInet_arc_ctc_ln_rpm_srch_mngt_lit__irt(
				String[] inet_arc_ctc_ln_rpm_srch_mngt_lit__irt) {
			this.inet_arc_ctc_ln_rpm_srch_mngt_lit__irt = inet_arc_ctc_ln_rpm_srch_mngt_lit__irt;
		}
		public String[] getInet_arc_ctc_ln_rpm_srch_mngt_lit__acc_no() {
			return inet_arc_ctc_ln_rpm_srch_mngt_lit__acc_no;
		}
		public void setInet_arc_ctc_ln_rpm_srch_mngt_lit__acc_no(
				String[] inet_arc_ctc_ln_rpm_srch_mngt_lit__acc_no) {
			this.inet_arc_ctc_ln_rpm_srch_mngt_lit__acc_no = inet_arc_ctc_ln_rpm_srch_mngt_lit__acc_no;
		}
		public String[] getInet_arc_ctc_ln_rpm_srch_mngt_lit__dpsr_rsdn_no() {
			return inet_arc_ctc_ln_rpm_srch_mngt_lit__dpsr_rsdn_no;
		}
		public void setInet_arc_ctc_ln_rpm_srch_mngt_lit__dpsr_rsdn_no(
				String[] inet_arc_ctc_ln_rpm_srch_mngt_lit__dpsr_rsdn_no) {
			this.inet_arc_ctc_ln_rpm_srch_mngt_lit__dpsr_rsdn_no = inet_arc_ctc_ln_rpm_srch_mngt_lit__dpsr_rsdn_no;
		}
		public String[] getInet_arc_ctc_ln_rpm_srch_mngt_lit__dpsr_nm() {
			return inet_arc_ctc_ln_rpm_srch_mngt_lit__dpsr_nm;
		}
		public void setInet_arc_ctc_ln_rpm_srch_mngt_lit__dpsr_nm(
				String[] inet_arc_ctc_ln_rpm_srch_mngt_lit__dpsr_nm) {
			this.inet_arc_ctc_ln_rpm_srch_mngt_lit__dpsr_nm = inet_arc_ctc_ln_rpm_srch_mngt_lit__dpsr_nm;
		}
		public String[] getInet_arc_ctc_ln_rpm_srch_mngt_lit__tsfr_ocd() {
			return inet_arc_ctc_ln_rpm_srch_mngt_lit__tsfr_ocd;
		}
		public void setInet_arc_ctc_ln_rpm_srch_mngt_lit__tsfr_ocd(
				String[] inet_arc_ctc_ln_rpm_srch_mngt_lit__tsfr_ocd) {
			this.inet_arc_ctc_ln_rpm_srch_mngt_lit__tsfr_ocd = inet_arc_ctc_ln_rpm_srch_mngt_lit__tsfr_ocd;
		}
		public String[] getInet_arc_ctc_ln_rpm_srch_mngt_lit__bank_cd() {
			return inet_arc_ctc_ln_rpm_srch_mngt_lit__bank_cd;
		}
		public void setInet_arc_ctc_ln_rpm_srch_mngt_lit__bank_cd(
				String[] inet_arc_ctc_ln_rpm_srch_mngt_lit__bank_cd) {
			this.inet_arc_ctc_ln_rpm_srch_mngt_lit__bank_cd = inet_arc_ctc_ln_rpm_srch_mngt_lit__bank_cd;
		}
		public String[] getInet_arc_ctc_ln_rpm_srch_mngt_lit__bank_nm() {
			return inet_arc_ctc_ln_rpm_srch_mngt_lit__bank_nm;
		}
		public void setInet_arc_ctc_ln_rpm_srch_mngt_lit__bank_nm(
				String[] inet_arc_ctc_ln_rpm_srch_mngt_lit__bank_nm) {
			this.inet_arc_ctc_ln_rpm_srch_mngt_lit__bank_nm = inet_arc_ctc_ln_rpm_srch_mngt_lit__bank_nm;
		}
		public String[] getInet_arc_ctc_ln_rpm_srch_mngt_lit__tsfr_dt() {
			return inet_arc_ctc_ln_rpm_srch_mngt_lit__tsfr_dt;
		}
		public void setInet_arc_ctc_ln_rpm_srch_mngt_lit__tsfr_dt(
				String[] inet_arc_ctc_ln_rpm_srch_mngt_lit__tsfr_dt) {
			this.inet_arc_ctc_ln_rpm_srch_mngt_lit__tsfr_dt = inet_arc_ctc_ln_rpm_srch_mngt_lit__tsfr_dt;
		}
		public String[] getInet_arc_ctc_ln_rpm_srch_mngt_lit__aply_rsl() {
			return inet_arc_ctc_ln_rpm_srch_mngt_lit__aply_rsl;
		}
		public void setInet_arc_ctc_ln_rpm_srch_mngt_lit__aply_rsl(
				String[] inet_arc_ctc_ln_rpm_srch_mngt_lit__aply_rsl) {
			this.inet_arc_ctc_ln_rpm_srch_mngt_lit__aply_rsl = inet_arc_ctc_ln_rpm_srch_mngt_lit__aply_rsl;
		}
		public String[] getInet_arc_ctc_ln_rpm_srch_mngt_lit__pym_prm() {
			return inet_arc_ctc_ln_rpm_srch_mngt_lit__pym_prm;
		}
		public void setInet_arc_ctc_ln_rpm_srch_mngt_lit__pym_prm(
				String[] inet_arc_ctc_ln_rpm_srch_mngt_lit__pym_prm) {
			this.inet_arc_ctc_ln_rpm_srch_mngt_lit__pym_prm = inet_arc_ctc_ln_rpm_srch_mngt_lit__pym_prm;
		}
		public String[] getInet_arc_ctc_ln_rpm_srch_mngt_lit__chng_dt() {
			return inet_arc_ctc_ln_rpm_srch_mngt_lit__chng_dt;
		}
		public void setInet_arc_ctc_ln_rpm_srch_mngt_lit__chng_dt(
				String[] inet_arc_ctc_ln_rpm_srch_mngt_lit__chng_dt) {
			this.inet_arc_ctc_ln_rpm_srch_mngt_lit__chng_dt = inet_arc_ctc_ln_rpm_srch_mngt_lit__chng_dt;
		}
		public String[] getInet_arc_ctc_ln_rpm_srch_mngt_lit__ctc_stat_cd() {
			return inet_arc_ctc_ln_rpm_srch_mngt_lit__ctc_stat_cd;
		}
		public void setInet_arc_ctc_ln_rpm_srch_mngt_lit__ctc_stat_cd(
				String[] inet_arc_ctc_ln_rpm_srch_mngt_lit__ctc_stat_cd) {
			this.inet_arc_ctc_ln_rpm_srch_mngt_lit__ctc_stat_cd = inet_arc_ctc_ln_rpm_srch_mngt_lit__ctc_stat_cd;
		}
		
		public String[] getInet_arc_ctc_ln_rpm_srch_mngt_lit__arc_trm_str_dt() {
			return inet_arc_ctc_ln_rpm_srch_mngt_lit__arc_trm_str_dt;
		}
		public void setInet_arc_ctc_ln_rpm_srch_mngt_lit__arc_trm_str_dt(
				String[] inet_arc_ctc_ln_rpm_srch_mngt_lit__arc_trm_str_dt) {
			this.inet_arc_ctc_ln_rpm_srch_mngt_lit__arc_trm_str_dt = inet_arc_ctc_ln_rpm_srch_mngt_lit__arc_trm_str_dt;
		}
		
		
}
