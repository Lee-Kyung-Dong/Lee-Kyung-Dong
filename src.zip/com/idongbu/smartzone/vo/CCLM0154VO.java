package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class CCLM0154VO extends CMMVO{

	//전문필드
		public String accd_rpt_no = "";  //[I] 사고접수번호 SS-SAGO-JUBSU-NO  사고접수번호
		public String accd_oj_dvcd = "";  //[I] 사고목적구분코드 SS-SAGO-MOKJUK-GB 면책담보구분
		public String accd_oj_rnk = "";  //[I] 사고목적서열 SS-SAGO-MOKJUK-SEQ   사고일련번호
		public String seal_yn = "";  //[I] 직인유무 SS-JIKIN 직인출력

		public String PRT_DATA = "";  //[O] RD관련 xml데이터 변수 추가(2013.04.29)

		public String getAccd_rpt_no() {
			return accd_rpt_no;
		}

		public void setAccd_rpt_no(String accd_rpt_no) {
			this.accd_rpt_no = accd_rpt_no;
		}

		public String getAccd_oj_dvcd() {
			return accd_oj_dvcd;
		}

		public void setAccd_oj_dvcd(String accd_oj_dvcd) {
			this.accd_oj_dvcd = accd_oj_dvcd;
		}

		public String getAccd_oj_rnk() {
			return accd_oj_rnk;
		}

		public void setAccd_oj_rnk(String accd_oj_rnk) {
			this.accd_oj_rnk = accd_oj_rnk;
		}

		public String getSeal_yn() {
			return seal_yn;
		}

		public void setSeal_yn(String seal_yn) {
			this.seal_yn = seal_yn;
		}

		public String getPRT_DATA() {
			return PRT_DATA;
		}

		public void setPRT_DATA(String pRT_DATA) {
			PRT_DATA = pRT_DATA;
		}
}
