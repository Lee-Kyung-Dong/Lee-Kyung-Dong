package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class GGNI0219VO extends CMMVO{
	//전문필드
		public String plan_no = "";  //[I] 설계번호  
		public String plno = "";  //[I] 증권번호  
		public String ctrmf_sqno = "";  //[I] 계약변경일련번호  
		public String nstl_orr = "";  //[I] 분납회차  
		public String outp_opti_if___isgd_typ_ptl_cd = "";  //[I] 출력옵션정보__발급물유형세부코드  
		public String outp_opti_if___isgd_typ_dvcd = "";  //[I] 출력옵션정보__발급물유형분류코드  
		public String PRT_DATA = "";
		public String getPlan_no() {
			return plan_no;
		}
		public void setPlan_no(String plan_no) {
			this.plan_no = plan_no;
		}
		public String getPlno() {
			return plno;
		}
		public void setPlno(String plno) {
			this.plno = plno;
		}
		public String getCtrmf_sqno() {
			return ctrmf_sqno;
		}
		public void setCtrmf_sqno(String ctrmf_sqno) {
			this.ctrmf_sqno = ctrmf_sqno;
		}
		public String getNstl_orr() {
			return nstl_orr;
		}
		public void setNstl_orr(String nstl_orr) {
			this.nstl_orr = nstl_orr;
		}
		public String getoutp_opti_if___isgd_typ_ptl_cd() {
			return outp_opti_if___isgd_typ_ptl_cd;
		}
		public void setoutp_opti_if___isgd_typ_ptl_cd(
				String outp_opti_if___isgd_typ_ptl_cd) {
			this.outp_opti_if___isgd_typ_ptl_cd = outp_opti_if___isgd_typ_ptl_cd;
		}
		public String getoutp_opti_if___isgd_typ_dvcd() {
			return outp_opti_if___isgd_typ_dvcd;
		}
		public void setoutp_opti_if___isgd_typ_dvcd(String outp_opti_if___isgd_typ_dvcd) {
			this.outp_opti_if___isgd_typ_dvcd = outp_opti_if___isgd_typ_dvcd;
		}
		public String getPRT_DATA() {
			return PRT_DATA;
		}
		public void setPRT_DATA(String pRT_DATA) {
			PRT_DATA = pRT_DATA;
		}
		
		

}
