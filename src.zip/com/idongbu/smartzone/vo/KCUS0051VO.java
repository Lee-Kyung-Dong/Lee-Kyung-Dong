package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class KCUS0051VO extends CMMVO{
	
	public String proc_dvn = null;			//[I]처리구분
	public String cust_dcmt_no = null;     	//[I]고객식별번호
	public String hpg_memr_dvcd = null;		//[I]홈페이지회원구분코드
	public String inpt_empno = null;     	//[O]입력사원번호
	public String inpt_dt = null;     		//[O]입력일자
	public String inpt_hmns = null;     	//[O]입력시분초
	public String updt_empno = null;     	//[O]수정사원번호
	public String updt_dt = null;     		//[O]수정일자
	public String updt_hmns = null;     	//[O]수정일시
	
	
	
	public String getProc_dvn() {
		return proc_dvn;
	}
	public void setProc_dvn(String proc_dvn) {
		this.proc_dvn = proc_dvn;
	}
	public String getCust_dcmt_no() {
		return cust_dcmt_no;
	}
	public void setCust_dcmt_no(String cust_dcmt_no) {
		this.cust_dcmt_no = cust_dcmt_no;
	}
	public String getHpg_memr_dvcd() {
		return hpg_memr_dvcd;
	}
	public void setHpg_memr_dvcd(String hpg_memr_dvcd) {
		this.hpg_memr_dvcd = hpg_memr_dvcd;
	}
	public String getInpt_empno() {
		return inpt_empno;
	}
	public void setInpt_empno(String inpt_empno) {
		this.inpt_empno = inpt_empno;
	}
	public String getInpt_dt() {
		return inpt_dt;
	}
	public void setInpt_dt(String inpt_dt) {
		this.inpt_dt = inpt_dt;
	}
	public String getInpt_hmns() {
		return inpt_hmns;
	}
	public void setInpt_hmns(String inpt_hmns) {
		this.inpt_hmns = inpt_hmns;
	}
	public String getUpdt_empno() {
		return updt_empno;
	}
	public void setUpdt_empno(String updt_empno) {
		this.updt_empno = updt_empno;
	}
	public String getUpdt_dt() {
		return updt_dt;
	}
	public void setUpdt_dt(String updt_dt) {
		this.updt_dt = updt_dt;
	}
	public String getUpdt_hmns() {
		return updt_hmns;
	}
	public void setUpdt_hmns(String updt_hmns) {
		this.updt_hmns = updt_hmns;
	}
}
