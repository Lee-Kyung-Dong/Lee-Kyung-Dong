package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class GGNI0046VO extends CMMVO
{
	public String inpd_nm		;// 보종명
	public String plan_no		;// 설계번호
	public String plno			;// 증권번호
	public String plno_1		;// 증권번호1
	public String chng_no		;// 변경번호
	public String norm_inpl_nm	;// 보통약관명
	public String ctc_shp		;// 계약형태
	public String apl_dt		;// 청약일자
	public String apt_dt		;// 계상일자
	public String arc_pd		;// 보험시기
	public String arc_et		;// 보험종기
	public String pym_mtd		;// 납입방법
	public String cins			;// 공동인수
	public String ldcp_nm		;// 간사사명
	public String ptcp_rt		;// 참여율
	public String ins_nm		;// 피보험자명
	public String old_plno		;// 구증권번호
	public String old_plno_1	;// 구증권번호1
	public String pym_prm		;// 납입보험료
	
	// 임시 시작
	public String errorCode;//에러코드
	public String z_msg_cd;//메시지 코드
	public String returnMessage;//메시지 내용
	
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getZ_msg_cd() {
		return z_msg_cd;
	}
	public void setZ_msg_cd(String z_msg_cd) {
		this.z_msg_cd = z_msg_cd;
	}
	public String getReturnMessage() {
		return returnMessage;
	}
	public void setReturnMessage(String returnMessage) {
		this.returnMessage = returnMessage;
	}
	// 임시 끝
	
	public String getInpd_nm() {
		return inpd_nm;
	}
	public void setInpd_nm(String inpd_nm) {
		this.inpd_nm = inpd_nm;
	}
	public String getPlan_no() {
		return plan_no;
	}
	public void setPlan_no(String plan_no) {
		this.plan_no = plan_no;
	}
	public String getPlno() {
		return plno;
	}
	public void setPlno(String plno) {
		this.plno = plno;
	}
	public String getPlno_1() {
		return plno_1;
	}
	public void setPlno_1(String plno_1) {
		this.plno_1 = plno_1;
	}
	public String getChng_no() {
		return chng_no;
	}
	public void setChng_no(String chng_no) {
		this.chng_no = chng_no;
	}
	public String getNorm_inpl_nm() {
		return norm_inpl_nm;
	}
	public void setNorm_inpl_nm(String norm_inpl_nm) {
		this.norm_inpl_nm = norm_inpl_nm;
	}
	public String getCtc_shp() {
		return ctc_shp;
	}
	public void setCtc_shp(String ctc_shp) {
		this.ctc_shp = ctc_shp;
	}
	public String getApl_dt() {
		return apl_dt;
	}
	public void setApl_dt(String apl_dt) {
		this.apl_dt = apl_dt;
	}
	public String getApt_dt() {
		return apt_dt;
	}
	public void setApt_dt(String apt_dt) {
		this.apt_dt = apt_dt;
	}
	public String getArc_pd() {
		return arc_pd;
	}
	public void setArc_pd(String arc_pd) {
		this.arc_pd = arc_pd;
	}
	public String getArc_et() {
		return arc_et;
	}
	public void setArc_et(String arc_et) {
		this.arc_et = arc_et;
	}
	public String getPym_mtd() {
		return pym_mtd;
	}
	public void setPym_mtd(String pym_mtd) {
		this.pym_mtd = pym_mtd;
	}
	public String getCins() {
		return cins;
	}
	public void setCins(String cins) {
		this.cins = cins;
	}
	public String getLdcp_nm() {
		return ldcp_nm;
	}
	public void setLdcp_nm(String ldcp_nm) {
		this.ldcp_nm = ldcp_nm;
	}
	public String getPtcp_rt() {
		return ptcp_rt;
	}
	public void setPtcp_rt(String ptcp_rt) {
		this.ptcp_rt = ptcp_rt;
	}
	public String getIns_nm() {
		return ins_nm;
	}
	public void setIns_nm(String ins_nm) {
		this.ins_nm = ins_nm;
	}
	public String getOld_plno() {
		return old_plno;
	}
	public void setOld_plno(String old_plno) {
		this.old_plno = old_plno;
	}
	public String getOld_plno_1() {
		return old_plno_1;
	}
	public void setOld_plno_1(String old_plno_1) {
		this.old_plno_1 = old_plno_1;
	}
	public String getPym_prm() {
		return pym_prm;
	}
	public void setPym_prm(String pym_prm) {
		this.pym_prm = pym_prm;
	}
}
