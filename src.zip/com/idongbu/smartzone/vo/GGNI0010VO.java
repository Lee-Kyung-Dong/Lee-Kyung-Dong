package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class GGNI0010VO extends CMMVO{

		//전문필드
		public String proc_dvn = "";  //[I/O] 처리구분 COMM_CHURI_GB 처리구분
		public String proc_dvn_1 = "";  //[I/O] 처리구분1 COMM_V_R_GB V-R구분
		public String pdc_cd = "";  //[I/O] 상품코드 COMM_BOJONG_CD 보종코드
		public String plan_no = "";  //[I/O] 설계번호 COMM_SULGYE_NO 설계번호
		public String plno = "";  //[I/O] 증권번호  COMM_POLI_NO 증권번호 
		public String apl_dd = "";  //[I/O] 청약일 COMM_CHUNGYAK_YMD 청약일
		public String arc_pd = "";  //[I/O] 보험시기 COMM_BO_GIGAN_SYMD 보험시기
		public String arc_et = "";  //[I/O] 보험종기 COMM_BO_GIGAN_EYMD 보험종기
		public String ins_dvn = "";  //[I/O] 피보험자구분 COMM_PIBO_GB 피보험자구분
		public String ins_no = "";  //[I/O] 피보험자번호 COMM_PIBO_NO 피보험자번호
		public String ins_nm = "";  //[I/O] 피보험자명 H_COMM_PIBO_NM 피보험자명
		public String ins_ntnl = "";  //[I/O] 피보험자국적 COMM_PIBO_GOOK_JUK 피보험자국적
		public String ins_rlt = "";  //[I/O] 피보험자관계 COMM_PIBO_GWANGE 피보험자관계
		public String psno = "";  //[I/O] 우편번호 COMM_PIBO_ZIP 우편번호
		public String eta_stn = "";  //[I/O] 기타번지 H_COMM_PIBO_GITA_BUNJI 기타번지
		public String psno_nw_adr = "";  //[I/O] 우편번호_신주소 COMM_PIBO_ST_ZIP 우편번호(신주소)
		public String add_nw_adr = "";  //[I/O] 주소_신주소 H_COMM_PIBO_ST_ADDR 주소(신주소)
		public String eta_stn_nw_adr = "";  //[I/O] 기타번지_신주소 H_COMM_PIBO_ST_GITA 기타번지(신주소
		public String wpc_nm = "";  //[I/O] 직장명 H_COMM_PIBO_JIKJANG_NM 직장명
		public String ins_tlno = "";  //[I/O] 피보험자전화번호 COMM_PIBO_HOME_TEL 피보험자전화번호
		public String ins_cryg_no = "";  //[I/O] 피보험자휴대번호 COMM_PIBO_HP_TEL 피보험자휴대번호
		public String ins_ofc_no = "";  //[I/O] 피보험자사무실번호 COMM_PIBO_OFFICE_TEL 피보험자사무실번호
		public String ins_eml = "";  //[I/O] 피보험자이메일 COMM_PIBO_EMAIL 피보험자이메일
		public String heal_stat = "";  //[I/O] 건강상태 COMM_GUNGANG_SANGTE 건강상태
		public String funt_dsb = "";  //[I/O] 기능장애 COMM_GING_JANGHE_YN 기능장애
		public String inj_dsa_yn = "";  //[I/O] 상해질병유무 COMM_SANGBYUNG_YN 상병유무
		public String hrdt_dss_yn = "";  //[I/O] 유전성질환유무 COMM_YUJUNSUNG_YN 유전성질환유무
		public String mntl_dss = "";  //[I/O] 정신질환 COMM_JUNGSIN_YN 정신질환유뮤
		public String bnfc_nm = "";  //[I/O] 수익자명 H_COMM_SUIKJA_NM 수익자명
		public String bnfc_rsdn_no = "";  //[I/O] 수익자주민번호 COMM_SUIKJA_JUMIN_NO 수익자주민번호
		public String bnfc_rlt = "";  //[I/O] 수익자관계 COMM_SUIKJA_GWANGE 수익자관계
		public String mlpc_dvn = "";  //[I/O] 우송처구분 COMM_USONGCHU_GB 우송처구분
		public String nw_adr_dvn = "";  //[I/O] 신주소구분 COMM-USONGCHU-ST-GB  신주소구분
		public String plhd_dvn = "";  //[I/O] 계약자구분 COMM_GEYAK_GB 계약자구분
		public String plhd_no = "";  //[I/O] 계약자번호 COMM_GEYAK_NO 계약자번호
		public String plhd_nm = "";  //[I/O] 계약자명 H_COMM_GEYAK_NM 계약자명
		public String plhd_psno = "";  //[I/O] 계약자우편번호 COMM_GEYAK_ZIP 계약자우편번호
		public String plhd_ntnl = "";  //[I/O] 계약자국적 COMM_GEYAK_GOOK_JUK 계약자국적
		public String plhd_eta_stn = "";  //[I/O] 계약자기타번지 H_COMM_GEYAK_GITA_BUNJI 계약자기타번지
		public String psno_nw_adr_1 = "";  //[I/O] 우편번호_신주소1 COMM-GEYAK-ST-ZIP    우편번호(신주소)
		public String adr_nw_adr_1 = "";  //[I/O] 주소_신주소1 H-COMM-GEYAK-ST-ADDR 주소(신주소)
		public String eta_stn_nw_adr_1 = "";  //[I/O] 기타번지_신주소1 H-COMM-GEYAK-ST-GITA 기타번지(신주소
		public String plhd_tlno = "";  //[I/O] 계약자전화번호 COMM_GEYAK_HOME_TEL 계약자전화번호
		public String plhd_cryg_no = "";  //[I/O] 계약자휴대번호 COMM_GEYAK_HP_TEL 계약자휴대번호
		public String plhd_ofc_no = "";  //[I/O] 계약자사무실번호 COMM_GEYAK_OFFICE_TEL 계약자사무실번호
		public String plhd_eml = "";  //[I/O] 계약자이메일 COMM_GEYAK_EMAIL 계약자이메일
		public String hsec_dvn = "";  //[I/O] 가계구분 COMM_GAGYE_GB 가계구분
		
		public String getProc_dvn() {
			return proc_dvn;
		}
		public void setProc_dvn(String proc_dvn) {
			this.proc_dvn = proc_dvn;
		}
		public String getProc_dvn_1() {
			return proc_dvn_1;
		}
		public void setProc_dvn_1(String proc_dvn_1) {
			this.proc_dvn_1 = proc_dvn_1;
		}
		public String getPdc_cd() {
			return pdc_cd;
		}
		public void setPdc_cd(String pdc_cd) {
			this.pdc_cd = pdc_cd;
		}
		public String getPlan_no() {
			return plan_no;
		}
		public void setPlan_no(String plan_no) {
			this.plan_no = plan_no;
		}
		public String getPlno() {
			return plno;
		}
		public void setPlno(String plno) {
			this.plno = plno;
		}
		public String getApl_dd() {
			return apl_dd;
		}
		public void setApl_dd(String apl_dd) {
			this.apl_dd = apl_dd;
		}
		public String getArc_pd() {
			return arc_pd;
		}
		public void setArc_pd(String arc_pd) {
			this.arc_pd = arc_pd;
		}
		public String getArc_et() {
			return arc_et;
		}
		public void setArc_et(String arc_et) {
			this.arc_et = arc_et;
		}
		public String getIns_dvn() {
			return ins_dvn;
		}
		public void setIns_dvn(String ins_dvn) {
			this.ins_dvn = ins_dvn;
		}
		public String getIns_no() {
			return ins_no;
		}
		public void setIns_no(String ins_no) {
			this.ins_no = ins_no;
		}
		public String getIns_nm() {
			return ins_nm;
		}
		public void setIns_nm(String ins_nm) {
			this.ins_nm = ins_nm;
		}
		public String getIns_ntnl() {
			return ins_ntnl;
		}
		public void setIns_ntnl(String ins_ntnl) {
			this.ins_ntnl = ins_ntnl;
		}
		public String getIns_rlt() {
			return ins_rlt;
		}
		public void setIns_rlt(String ins_rlt) {
			this.ins_rlt = ins_rlt;
		}
		public String getPsno() {
			return psno;
		}
		public void setPsno(String psno) {
			this.psno = psno;
		}
		public String getEta_stn() {
			return eta_stn;
		}
		public void setEta_stn(String eta_stn) {
			this.eta_stn = eta_stn;
		}
		public String getPsno_nw_adr() {
			return psno_nw_adr;
		}
		public void setPsno_nw_adr(String psno_nw_adr) {
			this.psno_nw_adr = psno_nw_adr;
		}
		public String getAdd_nw_adr() {
			return add_nw_adr;
		}
		public void setAdd_nw_adr(String add_nw_adr) {
			this.add_nw_adr = add_nw_adr;
		}
		public String getEta_stn_nw_adr() {
			return eta_stn_nw_adr;
		}
		public void setEta_stn_nw_adr(String eta_stn_nw_adr) {
			this.eta_stn_nw_adr = eta_stn_nw_adr;
		}
		public String getWpc_nm() {
			return wpc_nm;
		}
		public void setWpc_nm(String wpc_nm) {
			this.wpc_nm = wpc_nm;
		}
		public String getIns_tlno() {
			return ins_tlno;
		}
		public void setIns_tlno(String ins_tlno) {
			this.ins_tlno = ins_tlno;
		}
		public String getIns_cryg_no() {
			return ins_cryg_no;
		}
		public void setIns_cryg_no(String ins_cryg_no) {
			this.ins_cryg_no = ins_cryg_no;
		}
		public String getIns_ofc_no() {
			return ins_ofc_no;
		}
		public void setIns_ofc_no(String ins_ofc_no) {
			this.ins_ofc_no = ins_ofc_no;
		}
		public String getIns_eml() {
			return ins_eml;
		}
		public void setIns_eml(String ins_eml) {
			this.ins_eml = ins_eml;
		}
		public String getHeal_stat() {
			return heal_stat;
		}
		public void setHeal_stat(String heal_stat) {
			this.heal_stat = heal_stat;
		}
		public String getFunt_dsb() {
			return funt_dsb;
		}
		public void setFunt_dsb(String funt_dsb) {
			this.funt_dsb = funt_dsb;
		}
		public String getInj_dsa_yn() {
			return inj_dsa_yn;
		}
		public void setInj_dsa_yn(String inj_dsa_yn) {
			this.inj_dsa_yn = inj_dsa_yn;
		}
		public String getHrdt_dss_yn() {
			return hrdt_dss_yn;
		}
		public void setHrdt_dss_yn(String hrdt_dss_yn) {
			this.hrdt_dss_yn = hrdt_dss_yn;
		}
		public String getMntl_dss() {
			return mntl_dss;
		}
		public void setMntl_dss(String mntl_dss) {
			this.mntl_dss = mntl_dss;
		}
		public String getBnfc_nm() {
			return bnfc_nm;
		}
		public void setBnfc_nm(String bnfc_nm) {
			this.bnfc_nm = bnfc_nm;
		}
		public String getBnfc_rsdn_no() {
			return bnfc_rsdn_no;
		}
		public void setBnfc_rsdn_no(String bnfc_rsdn_no) {
			this.bnfc_rsdn_no = bnfc_rsdn_no;
		}
		public String getBnfc_rlt() {
			return bnfc_rlt;
		}
		public void setBnfc_rlt(String bnfc_rlt) {
			this.bnfc_rlt = bnfc_rlt;
		}
		public String getMlpc_dvn() {
			return mlpc_dvn;
		}
		public void setMlpc_dvn(String mlpc_dvn) {
			this.mlpc_dvn = mlpc_dvn;
		}
		public String getNw_adr_dvn() {
			return nw_adr_dvn;
		}
		public void setNw_adr_dvn(String nw_adr_dvn) {
			this.nw_adr_dvn = nw_adr_dvn;
		}
		public String getPlhd_dvn() {
			return plhd_dvn;
		}
		public void setPlhd_dvn(String plhd_dvn) {
			this.plhd_dvn = plhd_dvn;
		}
		public String getPlhd_no() {
			return plhd_no;
		}
		public void setPlhd_no(String plhd_no) {
			this.plhd_no = plhd_no;
		}
		public String getPlhd_nm() {
			return plhd_nm;
		}
		public void setPlhd_nm(String plhd_nm) {
			this.plhd_nm = plhd_nm;
		}
		public String getPlhd_psno() {
			return plhd_psno;
		}
		public void setPlhd_psno(String plhd_psno) {
			this.plhd_psno = plhd_psno;
		}
		public String getPlhd_ntnl() {
			return plhd_ntnl;
		}
		public void setPlhd_ntnl(String plhd_ntnl) {
			this.plhd_ntnl = plhd_ntnl;
		}
		public String getPlhd_eta_stn() {
			return plhd_eta_stn;
		}
		public void setPlhd_eta_stn(String plhd_eta_stn) {
			this.plhd_eta_stn = plhd_eta_stn;
		}
		public String getPsno_nw_adr_1() {
			return psno_nw_adr_1;
		}
		public void setPsno_nw_adr_1(String psno_nw_adr_1) {
			this.psno_nw_adr_1 = psno_nw_adr_1;
		}
		public String getAdr_nw_adr_1() {
			return adr_nw_adr_1;
		}
		public void setAdr_nw_adr_1(String adr_nw_adr_1) {
			this.adr_nw_adr_1 = adr_nw_adr_1;
		}
		public String getEta_stn_nw_adr_1() {
			return eta_stn_nw_adr_1;
		}
		public void setEta_stn_nw_adr_1(String eta_stn_nw_adr_1) {
			this.eta_stn_nw_adr_1 = eta_stn_nw_adr_1;
		}
		public String getPlhd_tlno() {
			return plhd_tlno;
		}
		public void setPlhd_tlno(String plhd_tlno) {
			this.plhd_tlno = plhd_tlno;
		}
		public String getPlhd_cryg_no() {
			return plhd_cryg_no;
		}
		public void setPlhd_cryg_no(String plhd_cryg_no) {
			this.plhd_cryg_no = plhd_cryg_no;
		}
		public String getPlhd_ofc_no() {
			return plhd_ofc_no;
		}
		public void setPlhd_ofc_no(String plhd_ofc_no) {
			this.plhd_ofc_no = plhd_ofc_no;
		}
		public String getPlhd_eml() {
			return plhd_eml;
		}
		public void setPlhd_eml(String plhd_eml) {
			this.plhd_eml = plhd_eml;
		}
		public String getHsec_dvn() {
			return hsec_dvn;
		}
		public void setHsec_dvn(String hsec_dvn) {
			this.hsec_dvn = hsec_dvn;
		}
}
