package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class AACT0015VO extends CMMVO
{
	//전문필드
	public String ormm_no				;// 조직원번호
//	public String recp_no				;// 영수증번호
	public String crd_no				;// 카드번호
	public String rrno					;// 주민등록번호
	public String crd_isu_cmy_cd		;// 카드발급회사코드
	public String crd_isu_cmy_nm		;// 카드발급회사명
	public String vlid_trm				;// 유효기간
	public String allt_trm				;// 할부기간
	public String dgs_amt				;// 거래금액
	public String ap_no					;// 승인번호
	public String msg_cd				;// 메시지코드
	public String msg_cn				;// 메시지내용          
	public String ap_mngt_no			;// 승인관리번호
//	public String bzlv_conu_yr			;// 사업단품의년도
//	public String bzlv_conu_sqno		;// 사업단품의일련번호
//	public String at_new_cust_cnfm_yn	;// 자동차신규고객확인유무
	public String crd_pint				;// 카드포인트
	public String pint_srch				;// 포인트조회
	public String bzlv_no				;// 사업단번호
//	public String act_bzlv_no			;// 회계사업단번호
	public String bh_no					;// 지점번호
//	public String act_yr				;// 회계년도
//	public String act_sqno				;// 회계일련번호
//	public String cdcp_yn				;// 카드사유무
	public String vn_dvn				;// VAN사구분
//	public String ap_dta				;// 승인데이터
//	public String key_dvn_val			;// 키구분값
//	public String ctf_dvn				;// 인증구분
//	public String vn_sqno				;// VAN사일련번호
	public String bz_dvn				;// 업무구분
	public String act_ocr_dvcd			;// 회계발생구분코드
	public String cust_typ				;// 고객유형
	
	public String ins_dcmt_no			;// 피보험자주민번호
	public String plhd_dcmt_no			;// 계약자주민번호
	public String plhd_no_yn			;// 계약자번호존재유무
	public String bz_slc				;// 업무선택
	public String chn_crd_ap_key		;// 채널카드승인키
	
	// 임시 시작
	public String errorCode;//에러코드
	public String z_msg_cd;//메시지 코드
	public String returnMessage;//메시지 내용
	
	public String z_resp_cd;
	public String z_resp_msg;
	
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getZ_msg_cd() {
		return z_msg_cd;
	}
	public void setZ_msg_cd(String z_msg_cd) {
		this.z_msg_cd = z_msg_cd;
	}
	public String getReturnMessage() {
		return returnMessage;
	}
	public void setReturnMessage(String returnMessage) {
		this.returnMessage = returnMessage;
	}
	// 임시 끝
	
	public String getOrmm_no() {
		return ormm_no;
	}
	public void setOrmm_no(String ormm_no) {
		this.ormm_no = ormm_no;
	}
	public String getCrd_no() {
		return crd_no;
	}
	public void setCrd_no(String crd_no) {
		this.crd_no = crd_no;
	}
	public String getRrno() {
		return rrno;
	}
	public void setRrno(String rrno) {
		this.rrno = rrno;
	}
	public String getCrd_isu_cmy_cd() {
		return crd_isu_cmy_cd;
	}
	public void setCrd_isu_cmy_cd(String crd_isu_cmy_cd) {
		this.crd_isu_cmy_cd = crd_isu_cmy_cd;
	}
	public String getCrd_isu_cmy_nm() {
		return crd_isu_cmy_nm;
	}
	public void setCrd_isu_cmy_nm(String crd_isu_cmy_nm) {
		this.crd_isu_cmy_nm = crd_isu_cmy_nm;
	}
	public String getVlid_trm() {
		return vlid_trm;
	}
	public void setVlid_trm(String vlid_trm) {
		this.vlid_trm = vlid_trm;
	}
	public String getAllt_trm() {
		return allt_trm;
	}
	public void setAllt_trm(String allt_trm) {
		this.allt_trm = allt_trm;
	}
	public String getDgs_amt() {
		return dgs_amt;
	}
	public void setDgs_amt(String dgs_amt) {
		this.dgs_amt = dgs_amt;
	}
	public String getAp_no() {
		return ap_no;
	}
	public void setAp_no(String ap_no) {
		this.ap_no = ap_no;
	}
	public String getMsg_cd() {
		return msg_cd;
	}
	public void setMsg_cd(String msg_cd) {
		this.msg_cd = msg_cd;
	}
	public String getMsg_cn() {
		return msg_cn;
	}
	public void setMsg_cn(String msg_cn) {
		this.msg_cn = msg_cn;
	}
	public String getAp_mngt_no() {
		return ap_mngt_no;
	}
	public void setAp_mngt_no(String ap_mngt_no) {
		this.ap_mngt_no = ap_mngt_no;
	}
	public String getCrd_pint() {
		return crd_pint;
	}
	public void setCrd_pint(String crd_pint) {
		this.crd_pint = crd_pint;
	}
	public String getPint_srch() {
		return pint_srch;
	}
	public void setPint_srch(String pint_srch) {
		this.pint_srch = pint_srch;
	}
	public String getBzlv_no() {
		return bzlv_no;
	}
	public void setBzlv_no(String bzlv_no) {
		this.bzlv_no = bzlv_no;
	}
	public String getBh_no() {
		return bh_no;
	}
	public void setBh_no(String bh_no) {
		this.bh_no = bh_no;
	}
	public String getVn_dvn() {
		return vn_dvn;
	}
	public void setVn_dvn(String vn_dvn) {
		this.vn_dvn = vn_dvn;
	}
	public String getBz_dvn() {
		return bz_dvn;
	}
	public void setBz_dvn(String bz_dvn) {
		this.bz_dvn = bz_dvn;
	}
	public String getAct_ocr_dvcd() {
		return act_ocr_dvcd;
	}
	public void setAct_ocr_dvcd(String act_ocr_dvcd) {
		this.act_ocr_dvcd = act_ocr_dvcd;
	}
	public String getCust_typ() {
		return cust_typ;
	}
	public void setCust_typ(String cust_typ) {
		this.cust_typ = cust_typ;
	}
	public String getIns_dcmt_no() {
		return ins_dcmt_no;
	}
	public void setIns_dcmt_no(String ins_dcmt_no) {
		this.ins_dcmt_no = ins_dcmt_no;
	}
	public String getPlhd_dcmt_no() {
		return plhd_dcmt_no;
	}
	public void setPlhd_dcmt_no(String plhd_dcmt_no) {
		this.plhd_dcmt_no = plhd_dcmt_no;
	}
	public String getPlhd_no_yn() {
		return plhd_no_yn;
	}
	public void setPlhd_no_yn(String plhd_no_yn) {
		this.plhd_no_yn = plhd_no_yn;
	}
	public String getBz_slc() {
		return bz_slc;
	}
	public void setBz_slc(String bz_slc) {
		this.bz_slc = bz_slc;
	}
	public String getChn_crd_ap_key() {
		return chn_crd_ap_key;
	}
	public void setChn_crd_ap_key(String chn_crd_ap_key) {
		this.chn_crd_ap_key = chn_crd_ap_key;
	}
	public String getZ_resp_cd() {
		return z_resp_cd;
	}
	public void setZ_resp_cd(String z_resp_cd) {
		this.z_resp_cd = z_resp_cd;
	}
	public String getZ_resp_msg() {
		return z_resp_msg;
	}
	public void setZ_resp_msg(String z_resp_msg) {
		this.z_resp_msg = z_resp_msg;
	}
	
}
