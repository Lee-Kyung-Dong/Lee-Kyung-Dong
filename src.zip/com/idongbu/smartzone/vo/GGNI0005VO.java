package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class GGNI0005VO extends CMMVO
{
	public String plno			;// 증권번호
	public String ormm_cd		;// 조직원코드
	public String plhd_tlno		;// 계약자전화번호
	public String ins_tlno		;// 피보험자전화번호
	public String eml			;// 이메일
	public String act_proc_dvn	;// 회계처리구분
	public String crd_slip_no	;// 카드전표번호
	public String fill			;// FILLER
	public String recp_no		;// 영수증번호
	public String cdcp_dvn		;// 카드사구분
	public String crd_no		;// 카드번호
	public String crd_usr_nm	;// 카드이용자명
	public String vlid_trm		;// 유효기간
	public String allt_dvn		;// 할부구분
	public String allt_trm		;// 할부기간
	public String dgs_amt		;// 거래금액
	public String ap_dt			;// 승인일자
	public String ap_no			;// 승인번호
	public String isu_cmy_cd	;// 발급회사코드
	public String vn_dvn		;// VAN사구분
	public String bank_cd		;// 은행코드
	public String sms_no_1		;// SMS번호1
	public String sms_no_2		;// SMS번호2
	public String sms_no_3		;// SMS번호3
	public String acc_no		;// 계좌번호
	public String pym_prm		;// 납입보험료
	public String lbl_fin_dd	;// 책임종료일
	
	// 임시 시작
	public String errorCode;//에러코드
	public String z_msg_cd;//메시지 코드
	public String returnMessage;//메시지 내용
	
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getZ_msg_cd() {
		return z_msg_cd;
	}
	public void setZ_msg_cd(String z_msg_cd) {
		this.z_msg_cd = z_msg_cd;
	}
	public String getReturnMessage() {
		return returnMessage;
	}
	public void setReturnMessage(String returnMessage) {
		this.returnMessage = returnMessage;
	}
	// 임시 끝
	
	public String getPlno() {
		return plno;
	}
	public void setPlno(String plno) {
		this.plno = plno;
	}
	public String getOrmm_cd() {
		return ormm_cd;
	}
	public void setOrmm_cd(String ormm_cd) {
		this.ormm_cd = ormm_cd;
	}
	public String getPlhd_tlno() {
		return plhd_tlno;
	}
	public void setPlhd_tlno(String plhd_tlno) {
		this.plhd_tlno = plhd_tlno;
	}
	public String getIns_tlno() {
		return ins_tlno;
	}
	public void setIns_tlno(String ins_tlno) {
		this.ins_tlno = ins_tlno;
	}
	public String getEml() {
		return eml;
	}
	public void setEml(String eml) {
		this.eml = eml;
	}
	public String getAct_proc_dvn() {
		return act_proc_dvn;
	}
	public void setAct_proc_dvn(String act_proc_dvn) {
		this.act_proc_dvn = act_proc_dvn;
	}
	public String getCrd_slip_no() {
		return crd_slip_no;
	}
	public void setCrd_slip_no(String crd_slip_no) {
		this.crd_slip_no = crd_slip_no;
	}
	public String getFill() {
		return fill;
	}
	public void setFill(String fill) {
		this.fill = fill;
	}
	public String getRecp_no() {
		return recp_no;
	}
	public void setRecp_no(String recp_no) {
		this.recp_no = recp_no;
	}
	public String getCdcp_dvn() {
		return cdcp_dvn;
	}
	public void setCdcp_dvn(String cdcp_dvn) {
		this.cdcp_dvn = cdcp_dvn;
	}
	public String getCrd_no() {
		return crd_no;
	}
	public void setCrd_no(String crd_no) {
		this.crd_no = crd_no;
	}
	public String getCrd_usr_nm() {
		return crd_usr_nm;
	}
	public void setCrd_usr_nm(String crd_usr_nm) {
		this.crd_usr_nm = crd_usr_nm;
	}
	public String getVlid_trm() {
		return vlid_trm;
	}
	public void setVlid_trm(String vlid_trm) {
		this.vlid_trm = vlid_trm;
	}
	public String getAllt_dvn() {
		return allt_dvn;
	}
	public void setAllt_dvn(String allt_dvn) {
		this.allt_dvn = allt_dvn;
	}
	public String getAllt_trm() {
		return allt_trm;
	}
	public void setAllt_trm(String allt_trm) {
		this.allt_trm = allt_trm;
	}
	public String getDgs_amt() {
		return dgs_amt;
	}
	public void setDgs_amt(String dgs_amt) {
		this.dgs_amt = dgs_amt;
	}
	public String getAp_dt() {
		return ap_dt;
	}
	public void setAp_dt(String ap_dt) {
		this.ap_dt = ap_dt;
	}
	public String getAp_no() {
		return ap_no;
	}
	public void setAp_no(String ap_no) {
		this.ap_no = ap_no;
	}
	public String getIsu_cmy_cd() {
		return isu_cmy_cd;
	}
	public void setIsu_cmy_cd(String isu_cmy_cd) {
		this.isu_cmy_cd = isu_cmy_cd;
	}
	public String getVn_dvn() {
		return vn_dvn;
	}
	public void setVn_dvn(String vn_dvn) {
		this.vn_dvn = vn_dvn;
	}
	public String getBank_cd() {
		return bank_cd;
	}
	public void setBank_cd(String bank_cd) {
		this.bank_cd = bank_cd;
	}
	public String getSms_no_1() {
		return sms_no_1;
	}
	public void setSms_no_1(String sms_no_1) {
		this.sms_no_1 = sms_no_1;
	}
	public String getSms_no_2() {
		return sms_no_2;
	}
	public void setSms_no_2(String sms_no_2) {
		this.sms_no_2 = sms_no_2;
	}
	public String getSms_no_3() {
		return sms_no_3;
	}
	public void setSms_no_3(String sms_no_3) {
		this.sms_no_3 = sms_no_3;
	}
	public String getAcc_no() {
		return acc_no;
	}
	public void setAcc_no(String acc_no) {
		this.acc_no = acc_no;
	}
	public String getPym_prm() {
		return pym_prm;
	}
	public void setPym_prm(String pym_prm) {
		this.pym_prm = pym_prm;
	}
	public String getLbl_fin_dd() {
		return lbl_fin_dd;
	}
	public void setLbl_fin_dd(String lbl_fin_dd) {
		this.lbl_fin_dd = lbl_fin_dd;
	}
}