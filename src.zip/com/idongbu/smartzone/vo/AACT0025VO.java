package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class AACT0025VO extends CMMVO{
	//전문필드
		public String bz_slc = "";  //[I] 업무선택 RE_SELECT 업무선택
		public String hdlr_cd = "";  //[I] 취급자코드 RE_JOJIKWON_CD 취급자코드
		public String plhd_cd = "";  //[I] 계약자코드 RE_H_JUMIN_NO 계약자코드
		public String plhd_nm = "";  //[I] 계약자명 H_RE_NAME 계약자명
		public String bank_cd = "";  //[I] 은행코드 RE_BANK_CD 은행코드
		public String pw = "";  //[I] 비밀번호 RE_PASSWORD PASSWORD
		public String acc_no = "";  //[O] 계좌번호 RE_H_GYEJWA_NO 계좌번호
		public String grnt_dt = "";  //[O] 부여일자 RE_H_ASSIGN_DATE 부여일자
		public String cnum = "";  //[I] 건수 RE_CNT 건수
		public String sm = "";  //[I] 합계 RE_TOT 합계
		public String dvn = "";  //[I] 구분 RE_GUBUN 구분
		public String str_srch_trm = "";  //[I] 시작조회기간 RE_FR_DATE 조회기간FROM
		public String last_srch_trm = "";  //[I] 마지막조회기간 RE_TO_DATE 조회기간TO
		public String[] vrtl_acc_iner_grnt_lit__slc;  //[I/O] _선택 RE_PROCESS 선택
		public String[] vrtl_acc_iner_grnt_lit__bank_nm;  //[I/O] _은행명 H_RE_BANK_NM 은행명
		public String[] vrtl_acc_iner_grnt_lit__acc_no;  //[I/O] _계좌번호 RE_GYEJWA_NO 계좌번호
		public String[] vrtl_acc_iner_grnt_lit__rsdn_no;  //[I/O] _주민번호 RE_JUMIN_NO 주민번호
		public String[] vrtl_acc_iner_grnt_lit__plhd_nm;  //[I/O] _계약자명 H_RE_GYEYAKJA_NAME 계약자명
		public String[] vrtl_acc_iner_grnt_lit__grnt_dt;  //[I/O] _부여일자 RE_ASSIGN_DATE 부여일자
		public String[] vrtl_acc_iner_grnt_lit__aply_amt;  //[I/O] _신청금액 RE_SINCHUNG_AMT 신청금액
		public String[] vrtl_acc_iner_grnt_lit__acc_sno;  //[I/O] _계좌순번 RE_GYEJWA_NO_SEQ 계좌SEQ
		public String[] vrtl_acc_iner_grnt_lit__bank_cd;  //[I/O] _은행코드 RE_BANK_CODE 은행코드
		public String[] vrtl_acc_iner_grnt_lit__vrtl_acc_knd_cd;  //[I/O] _가상계좌종류코드  
		public String sm_cnum = "";  //[O] 합계건수 RE_TOTAL_CNT 합계건수
		public String sm_amt = "";  //[O] 합계금액 RE_TOTAL_AMT 합계금액
		public String bh_cd_1 = "";  //[O] 지점코드1   RE_U_D_JIJUM_CD 지점코드     
		public String bh_nm = "";  //[O] 지점명 H_RE_U_D_JIJUM_NM 지점명
		public String bank_cd_1 = "";  //[O] 은행코드1 RE_U_D_BANK_CD 은행코드
		public String sm_amt_1 = "";  //[O] 합계금액1 RE_U_D_TOTAL_AMT 합계금액
		public String errorCode = "";	//[O] 에러코드 COND_CODE 에러코드
		public String getBz_slc() {
			return bz_slc;
		}
		public void setBz_slc(String bz_slc) {
			this.bz_slc = bz_slc;
		}
		public String getHdlr_cd() {
			return hdlr_cd;
		}
		public void setHdlr_cd(String hdlr_cd) {
			this.hdlr_cd = hdlr_cd;
		}
		public String getPlhd_cd() {
			return plhd_cd;
		}
		public void setPlhd_cd(String plhd_cd) {
			this.plhd_cd = plhd_cd;
		}
		public String getPlhd_nm() {
			return plhd_nm;
		}
		public void setPlhd_nm(String plhd_nm) {
			this.plhd_nm = plhd_nm;
		}
		public String getBank_cd() {
			return bank_cd;
		}
		public void setBank_cd(String bank_cd) {
			this.bank_cd = bank_cd;
		}
		public String getPw() {
			return pw;
		}
		public void setPw(String pw) {
			this.pw = pw;
		}
		public String getAcc_no() {
			return acc_no;
		}
		public void setAcc_no(String acc_no) {
			this.acc_no = acc_no;
		}
		public String getGrnt_dt() {
			return grnt_dt;
		}
		public void setGrnt_dt(String grnt_dt) {
			this.grnt_dt = grnt_dt;
		}
		public String getCnum() {
			return cnum;
		}
		public void setCnum(String cnum) {
			this.cnum = cnum;
		}
		public String getSm() {
			return sm;
		}
		public void setSm(String sm) {
			this.sm = sm;
		}
		public String getDvn() {
			return dvn;
		}
		public void setDvn(String dvn) {
			this.dvn = dvn;
		}
		public String getStr_srch_trm() {
			return str_srch_trm;
		}
		public void setStr_srch_trm(String str_srch_trm) {
			this.str_srch_trm = str_srch_trm;
		}
		public String getLast_srch_trm() {
			return last_srch_trm;
		}
		public void setLast_srch_trm(String last_srch_trm) {
			this.last_srch_trm = last_srch_trm;
		}
		public String[] getVrtl_acc_iner_grnt_lit__slc() {
			return vrtl_acc_iner_grnt_lit__slc;
		}
		public void setVrtl_acc_iner_grnt_lit__slc(String[] vrtl_acc_iner_grnt_lit__slc) {
			this.vrtl_acc_iner_grnt_lit__slc = vrtl_acc_iner_grnt_lit__slc;
		}
		public String[] getVrtl_acc_iner_grnt_lit__bank_nm() {
			return vrtl_acc_iner_grnt_lit__bank_nm;
		}
		public void setVrtl_acc_iner_grnt_lit__bank_nm(
				String[] vrtl_acc_iner_grnt_lit__bank_nm) {
			this.vrtl_acc_iner_grnt_lit__bank_nm = vrtl_acc_iner_grnt_lit__bank_nm;
		}
		public String[] getVrtl_acc_iner_grnt_lit__acc_no() {
			return vrtl_acc_iner_grnt_lit__acc_no;
		}
		public void setVrtl_acc_iner_grnt_lit__acc_no(
				String[] vrtl_acc_iner_grnt_lit__acc_no) {
			this.vrtl_acc_iner_grnt_lit__acc_no = vrtl_acc_iner_grnt_lit__acc_no;
		}
		public String[] getVrtl_acc_iner_grnt_lit__rsdn_no() {
			return vrtl_acc_iner_grnt_lit__rsdn_no;
		}
		public void setVrtl_acc_iner_grnt_lit__rsdn_no(
				String[] vrtl_acc_iner_grnt_lit__rsdn_no) {
			this.vrtl_acc_iner_grnt_lit__rsdn_no = vrtl_acc_iner_grnt_lit__rsdn_no;
		}
		public String[] getVrtl_acc_iner_grnt_lit__plhd_nm() {
			return vrtl_acc_iner_grnt_lit__plhd_nm;
		}
		public void setVrtl_acc_iner_grnt_lit__plhd_nm(
				String[] vrtl_acc_iner_grnt_lit__plhd_nm) {
			this.vrtl_acc_iner_grnt_lit__plhd_nm = vrtl_acc_iner_grnt_lit__plhd_nm;
		}
		public String[] getVrtl_acc_iner_grnt_lit__grnt_dt() {
			return vrtl_acc_iner_grnt_lit__grnt_dt;
		}
		public void setVrtl_acc_iner_grnt_lit__grnt_dt(
				String[] vrtl_acc_iner_grnt_lit__grnt_dt) {
			this.vrtl_acc_iner_grnt_lit__grnt_dt = vrtl_acc_iner_grnt_lit__grnt_dt;
		}
		public String[] getVrtl_acc_iner_grnt_lit__aply_amt() {
			return vrtl_acc_iner_grnt_lit__aply_amt;
		}
		public void setVrtl_acc_iner_grnt_lit__aply_amt(
				String[] vrtl_acc_iner_grnt_lit__aply_amt) {
			this.vrtl_acc_iner_grnt_lit__aply_amt = vrtl_acc_iner_grnt_lit__aply_amt;
		}
		public String[] getVrtl_acc_iner_grnt_lit__acc_sno() {
			return vrtl_acc_iner_grnt_lit__acc_sno;
		}
		public void setVrtl_acc_iner_grnt_lit__acc_sno(
				String[] vrtl_acc_iner_grnt_lit__acc_sno) {
			this.vrtl_acc_iner_grnt_lit__acc_sno = vrtl_acc_iner_grnt_lit__acc_sno;
		}
		public String[] getVrtl_acc_iner_grnt_lit__bank_cd() {
			return vrtl_acc_iner_grnt_lit__bank_cd;
		}
		public void setVrtl_acc_iner_grnt_lit__bank_cd(
				String[] vrtl_acc_iner_grnt_lit__bank_cd) {
			this.vrtl_acc_iner_grnt_lit__bank_cd = vrtl_acc_iner_grnt_lit__bank_cd;
		}
		public String[] getVrtl_acc_iner_grnt_lit__vrtl_acc_knd_cd() {
			return vrtl_acc_iner_grnt_lit__vrtl_acc_knd_cd;
		}
		public void setVrtl_acc_iner_grnt_lit__vrtl_acc_knd_cd(
				String[] vrtl_acc_iner_grnt_lit__vrtl_acc_knd_cd) {
			this.vrtl_acc_iner_grnt_lit__vrtl_acc_knd_cd = vrtl_acc_iner_grnt_lit__vrtl_acc_knd_cd;
		}
		public String getSm_cnum() {
			return sm_cnum;
		}
		public void setSm_cnum(String sm_cnum) {
			this.sm_cnum = sm_cnum;
		}
		public String getSm_amt() {
			return sm_amt;
		}
		public void setSm_amt(String sm_amt) {
			this.sm_amt = sm_amt;
		}
		public String getBh_cd_1() {
			return bh_cd_1;
		}
		public void setBh_cd_1(String bh_cd_1) {
			this.bh_cd_1 = bh_cd_1;
		}
		public String getBh_nm() {
			return bh_nm;
		}
		public void setBh_nm(String bh_nm) {
			this.bh_nm = bh_nm;
		}
		public String getBank_cd_1() {
			return bank_cd_1;
		}
		public void setBank_cd_1(String bank_cd_1) {
			this.bank_cd_1 = bank_cd_1;
		}
		public String getSm_amt_1() {
			return sm_amt_1;
		}
		public void setSm_amt_1(String sm_amt_1) {
			this.sm_amt_1 = sm_amt_1;
		}
		public String getErrorCode() {
			return errorCode;
		}
		public void setErrorCode(String errorCode) {
			this.errorCode = errorCode;
		}
		
		
}
