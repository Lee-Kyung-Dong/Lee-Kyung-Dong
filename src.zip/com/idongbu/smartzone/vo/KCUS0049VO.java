package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class KCUS0049VO extends CMMVO
{
	public String proc_dvn												= "";// 처리구분
	public String cust_dcmt_no											= "";// 고객식별번호
	public String cust_hngl_nm											= "";// 고객한글명
	public String csn_dt												= "";// 동의일자
	public String prn_if_clct_us_csn_yn									= "";// 개인정보수집이용동의여부
	public String csn_trm_end_dt_prn_if_clct_us_csn_yn					= "";// 동의기간만료일자개인정보수집이용동의여부
	public String prop_dcmt_if_csn_yn_pdc_intr_clct_us					= "";// 고유식별정보동의여부상품소개수집이용
	public String csn_trm_end_dt_prop_dcmt_if_csn_yn_pdc_intr_clct_us	= "";// 동의기간만료일자고유식별정보동의여부상품소개수집이용
	public String prn_if_ofer_csn_yn									= "";// 개인정보제공동의여부
	public String csn_trm_end_dt_prn_if_ofer_csn_yn						= "";// 동의기간만료일자개인정보제공동의여부
	public String prop_dcmt_if_csn_yn_pdc_intr_if_ofer					= "";// 고유식별정보동의여부상품소개정보제공
	public String csn_trm_end_dt_prop_dcmt_if_csn_yn_pdc_intr_if_ofer	= "";// 동의기간만료일자고유식별정보동의여부상품소개정보제공
	public String regt_mtd_dvcd											= "";// 등록방법구분코드
	public String csn_sr_dvcd											= "";// 동의출처구분코드
     
	public String cour_agnt_nm_1										= "";// 법정대리인명1
	public String cour_agnt_nm_2										= "";// 법정대리인명2
	public String rcvr_empno											= "";// 접수자사원번호
	public String rcvr_ep_nm											= "";// 접수자사원명
	
	public String cust_rqst_cn											= "";// 고객요청내용
	public String cust_exis_yn											= "";// 고객존재여부
}
