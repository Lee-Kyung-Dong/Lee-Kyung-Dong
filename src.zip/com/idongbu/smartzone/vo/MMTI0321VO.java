package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class MMTI0321VO extends CMMVO {

	public String srch_cnd__pbox_no = "";					// [I/O] 조회조건_사서함번호(암호화대상)
	
	public String srch_rsl__rtun_cd = "";					// [I/O] 조회결과__리턴코드
	public String srch_rsl__rtun_msg = "";					// [I/O] 조회결과__리턴메시지
	public String srch_rsl__plhd_nm = "";					// [I/O] 조회결과__계약자명
	public String srch_rsl__plno = "";						// [I/O] 조회결과__증권번호
	public String srch_rsl__plan_no = "";					// [I/O] 조회결과__설계번호
	public String srch_rsl__ctrmf_bse_dt = "";				// [I/O] 조회결과__계약변경기준일자
	public String srch_rsl__hngl_vh_no = "";				// [I/O] 조회결과__한글차량번호
	public String srch_rsl__adc_rtrn_dvcd = "";				// [I/O] 조회결과__추징환급구분코드(1:추징, 2:환급, 3:미발생)
	public String srch_rsl__pdc_sr_dvn = "";				// [I/O] 조회결과__상품출처구분(TM:TM상품, CM:CM상품, TD:그외상품)
	public String srch_rsl__plhd_brth = "";					// [I/O] 조회결과__계약자생년월일
	public String srch_rsl__cnv_trv_dstc = "";				// [I/O] 조회결과__환산주행거리
	public String srch_rsl__kid_trv_dstc = "";				// [I/O] 조회결과__개발원주행거리
	public String srch_rsl__adc_rtrn_prm = "";				// [I/O] 조회결과__추징환급보험료
	public String srch_rsl__crd_scn_cncl_pss_yn = "";		// [I/O] 조회결과__카드부분취소가능여부(1:카드부분취소가능)
	public String srch_rsl__stlm_cdcp_nm = "";				// [I/O] 조회결과__결제카드사명
	public String srch_rsl__stlm_crd_no = "";				// [I/O] 조회결과__결제카드번호
	public String srch_rsl__trv_dstc_exp_exca_dvcd = "";    // [I/O] 주행거리만기정산구분코드(1:정산완료)
	
	public String z_tlg_sp_cd = "";
	public String z_trns_org_cd = "";
	public String z_trns_org_dvcd = "";
	public String z_trsc_id = "";
	public String z_resp_cd = "";
	public String z_resp_msg = "";
	
	
	public String getSrch_cnd__pbox_no() {
		return srch_cnd__pbox_no;
	}
	public void setSrch_cnd__pbox_no(String srch_cnd__pbox_no) {
		this.srch_cnd__pbox_no = srch_cnd__pbox_no;
	}
	public String getSrch_rsl__rtun_cd() {
		return srch_rsl__rtun_cd;
	}
	public void setSrch_rsl__rtun_cd(String srch_rsl__rtun_cd) {
		this.srch_rsl__rtun_cd = srch_rsl__rtun_cd;
	}
	public String getSrch_rsl__rtun_msg() {
		return srch_rsl__rtun_msg;
	}
	public void setSrch_rsl__rtun_msg(String srch_rsl__rtun_msg) {
		this.srch_rsl__rtun_msg = srch_rsl__rtun_msg;
	}
	public String getSrch_rsl__plhd_nm() {
		return srch_rsl__plhd_nm;
	}
	public void setSrch_rsl__plhd_nm(String srch_rsl__plhd_nm) {
		this.srch_rsl__plhd_nm = srch_rsl__plhd_nm;
	}
	public String getSrch_rsl__plno() {
		return srch_rsl__plno;
	}
	public void setSrch_rsl__plno(String srch_rsl__plno) {
		this.srch_rsl__plno = srch_rsl__plno;
	}
	public String getSrch_rsl__plan_no() {
		return srch_rsl__plan_no;
	}
	public void setSrch_rsl__plan_no(String srch_rsl__plan_no) {
		this.srch_rsl__plan_no = srch_rsl__plan_no;
	}
	public String getSrch_rsl__ctrmf_bse_dt() {
		return srch_rsl__ctrmf_bse_dt;
	}
	public void setSrch_rsl__ctrmf_bse_dt(String srch_rsl__ctrmf_bse_dt) {
		this.srch_rsl__ctrmf_bse_dt = srch_rsl__ctrmf_bse_dt;
	}
	public String getSrch_rsl__hngl_vh_no() {
		return srch_rsl__hngl_vh_no;
	}
	public void setSrch_rsl__hngl_vh_no(String srch_rsl__hngl_vh_no) {
		this.srch_rsl__hngl_vh_no = srch_rsl__hngl_vh_no;
	}
	public String getSrch_rsl__adc_rtrn_dvcd() {
		return srch_rsl__adc_rtrn_dvcd;
	}
	public void setSrch_rsl__adc_rtrn_dvcd(String srch_rsl__adc_rtrn_dvcd) {
		this.srch_rsl__adc_rtrn_dvcd = srch_rsl__adc_rtrn_dvcd;
	}
	public String getSrch_rsl__pdc_sr_dvn() {
		return srch_rsl__pdc_sr_dvn;
	}
	public void setSrch_rsl__pdc_sr_dvn(String srch_rsl__pdc_sr_dvn) {
		this.srch_rsl__pdc_sr_dvn = srch_rsl__pdc_sr_dvn;
	}
	public String getSrch_rsl__plhd_brth() {
		return srch_rsl__plhd_brth;
	}
	public void setSrch_rsl__plhd_brth(String srch_rsl__plhd_brth) {
		this.srch_rsl__plhd_brth = srch_rsl__plhd_brth;
	}
	public String getSrch_rsl__cnv_trv_dstc() {
		return srch_rsl__cnv_trv_dstc;
	}
	public void setSrch_rsl__cnv_trv_dstc(String srch_rsl__cnv_trv_dstc) {
		this.srch_rsl__cnv_trv_dstc = srch_rsl__cnv_trv_dstc;
	}
	public String getSrch_rsl__kid_trv_dstc() {
		return srch_rsl__kid_trv_dstc;
	}
	public void setSrch_rsl__kid_trv_dstc(String srch_rsl__kid_trv_dstc) {
		this.srch_rsl__kid_trv_dstc = srch_rsl__kid_trv_dstc;
	}
	public String getSrch_rsl__adc_rtrn_prm() {
		return srch_rsl__adc_rtrn_prm;
	}
	public void setSrch_rsl__adc_rtrn_prm(String srch_rsl__adc_rtrn_prm) {
		this.srch_rsl__adc_rtrn_prm = srch_rsl__adc_rtrn_prm;
	}
	public String getSrch_rsl__crd_scn_cncl_pss_yn() {
		return srch_rsl__crd_scn_cncl_pss_yn;
	}
	public void setSrch_rsl__crd_scn_cncl_pss_yn(
			String srch_rsl__crd_scn_cncl_pss_yn) {
		this.srch_rsl__crd_scn_cncl_pss_yn = srch_rsl__crd_scn_cncl_pss_yn;
	}
	public String getSrch_rsl__stlm_cdcp_nm() {
		return srch_rsl__stlm_cdcp_nm;
	}
	public void setSrch_rsl__stlm_cdcp_nm(String srch_rsl__stlm_cdcp_nm) {
		this.srch_rsl__stlm_cdcp_nm = srch_rsl__stlm_cdcp_nm;
	}
	public String getSrch_rsl__stlm_crd_no() {
		return srch_rsl__stlm_crd_no;
	}
	public void setSrch_rsl__stlm_crd_no(String srch_rsl__stlm_crd_no) {
		this.srch_rsl__stlm_crd_no = srch_rsl__stlm_crd_no;
	}
	public String getSrch_rsl__trv_dstc_exp_exca_dvcd() {
		return srch_rsl__trv_dstc_exp_exca_dvcd;
	}
	public void setSrch_rsl__trv_dstc_exp_exca_dvcd(
			String srch_rsl__trv_dstc_exp_exca_dvcd) {
		this.srch_rsl__trv_dstc_exp_exca_dvcd = srch_rsl__trv_dstc_exp_exca_dvcd;
	}
	public String getZ_tlg_sp_cd() {
		return z_tlg_sp_cd;
	}
	public void setZ_tlg_sp_cd(String z_tlg_sp_cd) {
		this.z_tlg_sp_cd = z_tlg_sp_cd;
	}
	public String getZ_trns_org_cd() {
		return z_trns_org_cd;
	}
	public void setZ_trns_org_cd(String z_trns_org_cd) {
		this.z_trns_org_cd = z_trns_org_cd;
	}
	public String getZ_trns_org_dvcd() {
		return z_trns_org_dvcd;
	}
	public void setZ_trns_org_dvcd(String z_trns_org_dvcd) {
		this.z_trns_org_dvcd = z_trns_org_dvcd;
	}
	public String getZ_trsc_id() {
		return z_trsc_id;
	}
	public void setZ_trsc_id(String z_trsc_id) {
		this.z_trsc_id = z_trsc_id;
	}
	public String getZ_resp_cd() {
		return z_resp_cd;
	}
	public void setZ_resp_cd(String z_resp_cd) {
		this.z_resp_cd = z_resp_cd;
	}
	public String getZ_resp_msg() {
		return z_resp_msg;
	}
	public void setZ_resp_msg(String z_resp_msg) {
		this.z_resp_msg = z_resp_msg;
	}
	
}
