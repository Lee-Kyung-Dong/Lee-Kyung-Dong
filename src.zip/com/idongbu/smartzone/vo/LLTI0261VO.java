package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;


public class LLTI0261VO  extends CMMVO {
	
		//전문필드
		public String plno = "";  //[I] 증권번호 JJ-POLI-NO 증권번호
		public String ins_lcpl_dvcd = "";  //[I] 증권번호 JJ-POLI-NO 증권번호
		public String ply_sqno = "";  //[I] 증권번호 JJ-POLI-NO 증권번호
		public String fom_nm = "";  //[O] 폼명  CC_FORM_ID  
		public String outp_dvn = "";  //[I] 출력구분 JJ-CHUL-GB      출력구분
		public String srch_slc = "";  //[I] 조회선택 JJ-PIBO-CAR-SEL 조회선택
		public String fom_dvn = "";  //[I] 폼구분 JJ-FORM-GB      폼구분
		public String dta_last_yn = "";  //[O] 데이타마지막여부 JJ-PRINT-ESIGN 데이터마지막여부
		public String rei_rs = "";  //[I] 재발급사유 JJ-REWRT-GB 재발급사유
		public String ply_yn = "";  //[O] 증권여부 RD-POLICY-YN   증권여부
		public String cpy_yn = "";  //[O] 복사여부 RD-COPY-YN     복사여부
		public String grn_yn = "";  //[O] 녹색여부 RD-GREEN-YN    녹색여부
		public String ecde_yn = "";  //[O] 암호화여부 RD-ENCRYPT-YN  암호화여부
		public String ecde_key = "";  //[O] 암호화키 RD-ENCRYPT-KEY 암호화키
		public String bz_dvn = "";  //[O] 업무구분 RD-UPMU-GB     업무구분
		public String doc_dvn = "";  //[O] 문서구분 RD-DOCU-GB     문서구분
		public String sig_key = "";  //[O] 서명키 RD-SIGN-KEY    서명키
		public String at_plno_cnum = "";  //[O] 자동차증권번호건수 UU-CAR-CNT 자동차증번건수
		public String PRT_DATA = ""; //[O] 프린트 데이타 JJ_PRINT_DATA로 임의 맵핑.
		
		
		
		
		
		public String getIns_lcpl_dvcd() {
			return ins_lcpl_dvcd;
		}
		public void setIns_lcpl_dvcd(String ins_lcpl_dvcd) {
			this.ins_lcpl_dvcd = ins_lcpl_dvcd;
		}
		public String getPly_sqno() {
			return ply_sqno;
		}
		public void setPly_sqno(String ply_sqno) {
			this.ply_sqno = ply_sqno;
		}
		public String getPlno() {
			return plno;
		}
		public void setPlno(String plno) {
			this.plno = plno;
		}
		public String getFom_nm() {
			return fom_nm;
		}
		public void setFom_nm(String fom_nm) {
			this.fom_nm = fom_nm;
		}
		public String getOutp_dvn() {
			return outp_dvn;
		}
		public void setOutp_dvn(String outp_dvn) {
			this.outp_dvn = outp_dvn;
		}
		public String getSrch_slc() {
			return srch_slc;
		}
		public void setSrch_slc(String srch_slc) {
			this.srch_slc = srch_slc;
		}
		public String getFom_dvn() {
			return fom_dvn;
		}
		public void setFom_dvn(String fom_dvn) {
			this.fom_dvn = fom_dvn;
		}
		public String getDta_last_yn() {
			return dta_last_yn;
		}
		public void setDta_last_yn(String dta_last_yn) {
			this.dta_last_yn = dta_last_yn;
		}
		public String getRei_rs() {
			return rei_rs;
		}
		public void setRei_rs(String rei_rs) {
			this.rei_rs = rei_rs;
		}
		public String getPly_yn() {
			return ply_yn;
		}
		public void setPly_yn(String ply_yn) {
			this.ply_yn = ply_yn;
		}
		public String getCpy_yn() {
			return cpy_yn;
		}
		public void setCpy_yn(String cpy_yn) {
			this.cpy_yn = cpy_yn;
		}
		public String getGrn_yn() {
			return grn_yn;
		}
		public void setGrn_yn(String grn_yn) {
			this.grn_yn = grn_yn;
		}
		public String getEcde_yn() {
			return ecde_yn;
		}
		public void setEcde_yn(String ecde_yn) {
			this.ecde_yn = ecde_yn;
		}
		public String getEcde_key() {
			return ecde_key;
		}
		public void setEcde_key(String ecde_key) {
			this.ecde_key = ecde_key;
		}
		public String getBz_dvn() {
			return bz_dvn;
		}
		public void setBz_dvn(String bz_dvn) {
			this.bz_dvn = bz_dvn;
		}
		public String getDoc_dvn() {
			return doc_dvn;
		}
		public void setDoc_dvn(String doc_dvn) {
			this.doc_dvn = doc_dvn;
		}
		public String getSig_key() {
			return sig_key;
		}
		public void setSig_key(String sig_key) {
			this.sig_key = sig_key;
		}
		public String getAt_plno_cnum() {
			return at_plno_cnum;
		}
		public void setAt_plno_cnum(String at_plno_cnum) {
			this.at_plno_cnum = at_plno_cnum;
		}
		public String getPRT_DATA() {
			return PRT_DATA;
		}
		public void setPRT_DATA(String pRT_DATA) {
			PRT_DATA = pRT_DATA;
		}
}
