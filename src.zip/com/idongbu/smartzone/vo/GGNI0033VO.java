package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class GGNI0033VO extends CMMVO{

	//전문필드
		public String proc_dvn = "";  //[I] 처리구분 COMM-CHURI-GB  처리구분
		public String inpd_cd = "";  //[I] 보종코드 COMM-BJ-CD   보종코드
		public String plan_no = "";  //[I] 설계번호 COMM-SULGYE-NO  설계번호
		public String plno = "";  //[I] 증권번호 COMM-POLI-NO   증권번호
		public String chng_sqno = "";  //[I] 변경일련번호 COMM-BESU-SEQ   배서SEQ
		public String scy_typ = "";  //[I] 단체유형 COMM-DANCHE-YH 단체유형
		public String ins_cnt_1 = "";  //[I] 피보험자수1 COMM-PIBO-CNT   피보험자수1
		public String sl_typ = "";  //[I] 판매유형 COMM-PANME-YH  판매유형
		public String mcup_fmy_dvn = "";  //[I] 부부가족구분 COMM-GAJOK-GB    부부가족구분
		public String job_cd = "";  //[I] 직업코드 COMM-JOB-CD    직업코드
		public String ins_rtg = "";  //[I] 피보험자급수 COMM-PB-GBSU  피보험자급수
		public String ins_cnt_2 = "";  //[I] 피보험자수2 COMM-PB-CNT  피보험자수2
		public String crcy_cd = "";  //[I] 화폐코드 COMM-AMT-CODE  화폐코드
		public String tdtn = "";  //[I] 여행지 H-COMM-TRIP-PLACE  여행지
		public String trvl_ctry_cd = "";  //[I] 여행국가코드 COMM-TRIP-CODE    여행국가코드
		public String trvl_oj_nm = "";  //[I] 여행목적명 H-COMM-TRIP-OBJECT 여행목적명
		public String arc_trm_pd = "";  //[I] 보험기간시기 COMM-BO-GIGAN-SYMD  보험기간시기
		public String arc_trm_pd_1 = "";  //[I] 보험기간시기1 COMM-BO-GIGAN-SHM   보험기간시기시분
		public String arc_trm_et = "";  //[I] 보험기간종기 COMM-BO-GIGAN-EYMD   보험기간종기
		public String arc_trm_et_1 = "";  //[I] 보험기간종기1 COMM-BO-GIGAN-EHM  보험기간종기시분
		public String dst_rt = "";  //[I] 할인율 COMM-HALIN-YUL    할인율
		public String[] gnrl_srch_mngt_7_3_2_arrm_1__ins_rsdn_no = new String[0];  //[I] 일반조회관리732_배열1_피보험자주민등록번호 COMM-PIBO-JUMIN-N 피보험자주민번호
		public String[] gnrl_srch_mngt_7_3_2_arrm_1__ins_nm = new String[0];  //[I] 일반조회관리732_배열1_피보험자명 H-COMM-PIBO-NM 피보험자명
		public String[] gnrl_srch_mngt_7_3_2_arrm_2__pan_cd = new String[0];  //[I] 일반조회관리732_배열2_플랜코드 COMM-PLAN-CD   플랜코드
		public String[] gnrl_srch_mngt_7_3_2_arrm_2__pan_prm = new String[0];  //[I/O] 일반조회관리732_배열2_플랜보험료 COMM-PLAN-PRM   플랜보험료
		public String[] gnrl_srch_mngt_7_3_2_arrm_3__cvr_cd = new String[0];  //[I] 일반조회관리732_배열3_담보코드  담보코드
		public String[] gnrl_srch_mngt_7_3_2_arrm_3__inam = new String[0];  //[I] 일반조회관리732_배열3_가입금액  가입금액
		public String[] gnrl_srch_mngt_7_3_2_arrm_3__pan_cd = new String[0];  //[I] 일반조회관리732_배열3_플랜코드  플랜코드
		
		public String getProc_dvn() {
			return proc_dvn;
		}
		public void setProc_dvn(String proc_dvn) {
			this.proc_dvn = proc_dvn;
		}
		public String getInpd_cd() {
			return inpd_cd;
		}
		public void setInpd_cd(String inpd_cd) {
			this.inpd_cd = inpd_cd;
		}
		public String getPlan_no() {
			return plan_no;
		}
		public void setPlan_no(String plan_no) {
			this.plan_no = plan_no;
		}
		public String getPlno() {
			return plno;
		}
		public void setPlno(String plno) {
			this.plno = plno;
		}
		public String getChng_sqno() {
			return chng_sqno;
		}
		public void setChng_sqno(String chng_sqno) {
			this.chng_sqno = chng_sqno;
		}
		public String getScy_typ() {
			return scy_typ;
		}
		public void setScy_typ(String scy_typ) {
			this.scy_typ = scy_typ;
		}
		public String getIns_cnt_1() {
			return ins_cnt_1;
		}
		public void setIns_cnt_1(String ins_cnt_1) {
			this.ins_cnt_1 = ins_cnt_1;
		}
		public String getSl_typ() {
			return sl_typ;
		}
		public void setSl_typ(String sl_typ) {
			this.sl_typ = sl_typ;
		}
		public String getMcup_fmy_dvn() {
			return mcup_fmy_dvn;
		}
		public void setMcup_fmy_dvn(String mcup_fmy_dvn) {
			this.mcup_fmy_dvn = mcup_fmy_dvn;
		}
		public String getJob_cd() {
			return job_cd;
		}
		public void setJob_cd(String job_cd) {
			this.job_cd = job_cd;
		}
		public String getIns_rtg() {
			return ins_rtg;
		}
		public void setIns_rtg(String ins_rtg) {
			this.ins_rtg = ins_rtg;
		}
		public String getIns_cnt_2() {
			return ins_cnt_2;
		}
		public void setIns_cnt_2(String ins_cnt_2) {
			this.ins_cnt_2 = ins_cnt_2;
		}
		public String getCrcy_cd() {
			return crcy_cd;
		}
		public void setCrcy_cd(String crcy_cd) {
			this.crcy_cd = crcy_cd;
		}
		public String getTdtn() {
			return tdtn;
		}
		public void setTdtn(String tdtn) {
			this.tdtn = tdtn;
		}
		public String getTrvl_ctry_cd() {
			return trvl_ctry_cd;
		}
		public void setTrvl_ctry_cd(String trvl_ctry_cd) {
			this.trvl_ctry_cd = trvl_ctry_cd;
		}
		public String getTrvl_oj_nm() {
			return trvl_oj_nm;
		}
		public void setTrvl_oj_nm(String trvl_oj_nm) {
			this.trvl_oj_nm = trvl_oj_nm;
		}
		public String getArc_trm_pd() {
			return arc_trm_pd;
		}
		public void setArc_trm_pd(String arc_trm_pd) {
			this.arc_trm_pd = arc_trm_pd;
		}
		public String getArc_trm_pd_1() {
			return arc_trm_pd_1;
		}
		public void setArc_trm_pd_1(String arc_trm_pd_1) {
			this.arc_trm_pd_1 = arc_trm_pd_1;
		}
		public String getArc_trm_et() {
			return arc_trm_et;
		}
		public void setArc_trm_et(String arc_trm_et) {
			this.arc_trm_et = arc_trm_et;
		}
		public String getArc_trm_et_1() {
			return arc_trm_et_1;
		}
		public void setArc_trm_et_1(String arc_trm_et_1) {
			this.arc_trm_et_1 = arc_trm_et_1;
		}
		public String getDst_rt() {
			return dst_rt;
		}
		public void setDst_rt(String dst_rt) {
			this.dst_rt = dst_rt;
		}
		public String[] getGnrl_srch_mngt_7_3_2_arrm_1__ins_rsdn_no() {
			return gnrl_srch_mngt_7_3_2_arrm_1__ins_rsdn_no;
		}
		public void setGnrl_srch_mngt_7_3_2_arrm_1__ins_rsdn_no(
				String[] gnrl_srch_mngt_7_3_2_arrm_1__ins_rsdn_no) {
			this.gnrl_srch_mngt_7_3_2_arrm_1__ins_rsdn_no = gnrl_srch_mngt_7_3_2_arrm_1__ins_rsdn_no;
		}
		public String[] getGnrl_srch_mngt_7_3_2_arrm_1__ins_nm() {
			return gnrl_srch_mngt_7_3_2_arrm_1__ins_nm;
		}
		public void setGnrl_srch_mngt_7_3_2_arrm_1__ins_nm(
				String[] gnrl_srch_mngt_7_3_2_arrm_1__ins_nm) {
			this.gnrl_srch_mngt_7_3_2_arrm_1__ins_nm = gnrl_srch_mngt_7_3_2_arrm_1__ins_nm;
		}
		public String[] getGnrl_srch_mngt_7_3_2_arrm_2__pan_cd() {
			return gnrl_srch_mngt_7_3_2_arrm_2__pan_cd;
		}
		public void setGnrl_srch_mngt_7_3_2_arrm_2__pan_cd(
				String[] gnrl_srch_mngt_7_3_2_arrm_2__pan_cd) {
			this.gnrl_srch_mngt_7_3_2_arrm_2__pan_cd = gnrl_srch_mngt_7_3_2_arrm_2__pan_cd;
		}
		public String[] getGnrl_srch_mngt_7_3_2_arrm_2__pan_prm() {
			return gnrl_srch_mngt_7_3_2_arrm_2__pan_prm;
		}
		public void setGnrl_srch_mngt_7_3_2_arrm_2__pan_prm(
				String[] gnrl_srch_mngt_7_3_2_arrm_2__pan_prm) {
			this.gnrl_srch_mngt_7_3_2_arrm_2__pan_prm = gnrl_srch_mngt_7_3_2_arrm_2__pan_prm;
		}
		public String[] getGnrl_srch_mngt_7_3_2_arrm_3__cvr_cd() {
			return gnrl_srch_mngt_7_3_2_arrm_3__cvr_cd;
		}
		public void setGnrl_srch_mngt_7_3_2_arrm_3__cvr_cd(
				String[] gnrl_srch_mngt_7_3_2_arrm_3__cvr_cd) {
			this.gnrl_srch_mngt_7_3_2_arrm_3__cvr_cd = gnrl_srch_mngt_7_3_2_arrm_3__cvr_cd;
		}
		public String[] getGnrl_srch_mngt_7_3_2_arrm_3__inam() {
			return gnrl_srch_mngt_7_3_2_arrm_3__inam;
		}
		public void setGnrl_srch_mngt_7_3_2_arrm_3__inam(
				String[] gnrl_srch_mngt_7_3_2_arrm_3__inam) {
			this.gnrl_srch_mngt_7_3_2_arrm_3__inam = gnrl_srch_mngt_7_3_2_arrm_3__inam;
		}
		public String[] getGnrl_srch_mngt_7_3_2_arrm_3__pan_cd() {
			return gnrl_srch_mngt_7_3_2_arrm_3__pan_cd;
		}
		public void setGnrl_srch_mngt_7_3_2_arrm_3__pan_cd(
				String[] gnrl_srch_mngt_7_3_2_arrm_3__pan_cd) {
			this.gnrl_srch_mngt_7_3_2_arrm_3__pan_cd = gnrl_srch_mngt_7_3_2_arrm_3__pan_cd;
		}
}
