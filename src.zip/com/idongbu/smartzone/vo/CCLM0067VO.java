package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class CCLM0067VO extends CMMVO{
	//전문필드
		public String msg_cd = "";  //[I/O] 메세지코드 LK-MSG-CD2 메세지코드2
		public String msg = "";  //[I/O] 메시지 H-LK-MESSAGE2 메시지2
		public String accd_rpt_no = "";  //[I/O] 사고접수번호          LK-I-SAGO-NO 사고접수번호         
		public String[] clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_vtm_if__cvr_nm = new String[0];  //[I/O] 보상OneClick서비스종결내역조회_피해자정보_담보명 LK-I-DAMBO-NM 담보명
		public String[] clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_vtm_if__accd_oj_sqno = new String[0];  //[I/O] 보상OneClick서비스종결내역조회_피해자정보_사고목적일련번호  LK-I-MOKJUK-SEQ 사고목적일련번호 
		public String[] clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_vtm_if__vtm_nm = new String[0];  //[I/O] 보상OneClick서비스종결내역조회_피해자정보_피해자명 LK-I-PIHEJA-NM 피해자명
		public String[] clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_vtm_if__trtf = new String[0];  //[I/O] 보상OneClick서비스종결내역조회_피해자정보_치료비 LK-I-CHIRYOBI-AMT 치료비
		public String[] clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_vtm_if__grmy = new String[0];  //[I/O] 보상OneClick서비스종결내역조회_피해자정보_합의금 LK-I-HAPIGM-AMT 합의금
		public String[] clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_vtm_if__sm = new String[0];  //[I/O] 보상OneClick서비스종결내역조회_피해자정보_합계 LK-I-HAPGYE-AMT 합계
		public String[] clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_vtm_if__ed_dt = new String[0];  //[I/O] 보상OneClick서비스종결내역조회_피해자정보_종결일자 LK-I-JONGKYUL-YMD 종결일자
		public String[] clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_vtm_if__psic_nm = new String[0];  //[I/O] 보상OneClick서비스종결내역조회_피해자정보_담당자명 LK-I-DAMDANGJA 담당자명
		public String[] clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_vtm_if__tlno = new String[0];  //[I/O] 보상OneClick서비스종결내역조회_피해자정보_전화번호 LK-I-TEL-NO 전화번호
		public String[] clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_dmit_if__cvr_nm = new String[0];  //[I/O] 보상OneClick서비스종결내역조회_피해물정보_담보명 LK-M-DAMBO-NM 담보명
		public String[] clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_dmit_if__accd_oj_sqno = new String[0];  //[I/O] 보상OneClick서비스종결내역조회_피해물정보_사고목적일련번호  LK-M-MOKJUK-SEQ 사고목적일련번호 
		public String[] clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_dmit_if__vtm_nm = new String[0];  //[I/O] 보상OneClick서비스종결내역조회_피해물정보_피해물명 LK-M-PIHEMUL-NM 피해물명
		public String[] clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_dmit_if__cmpn_amt = new String[0];  //[I/O] 보상OneClick서비스종결내역조회_피해물정보_부품금액 LK-M-BUPUM-AMT 부품금액
		public String[] clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_dmit_if__clab_amt = new String[0];  //[I/O] 보상OneClick서비스종결내역조회_피해물정보_공임금액 LK-M-GONGIM-AMT 공임금액
		public String[] clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_dmit_if__sm = new String[0];  //[I/O] 보상OneClick서비스종결내역조회_피해물정보_합계 LK-M-HAPGYE-AMT 합계
		public String[] clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_dmit_if__ed_dt = new String[0];  //[I/O] 보상OneClick서비스종결내역조회_피해물정보_종결일자 LK-M-JONGKYUL-YMD 종결일자
		public String[] clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_dmit_if__psic_nm = new String[0];  //[I/O] 보상OneClick서비스종결내역조회_피해물정보_담당자명 LK-M-DAMDANGJA 담당자명
		public String[] clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_dmit_if__tlno = new String[0];  //[I/O] 보상OneClick서비스종결내역조회_피해물정보_전화번호 LK-M-TEL-NO 전화번호
		public String getMsg_cd() {
			return msg_cd;
		}
		public void setMsg_cd(String msg_cd) {
			this.msg_cd = msg_cd;
		}
		public String getMsg() {
			return msg;
		}
		public void setMsg(String msg) {
			this.msg = msg;
		}
		public String getAccd_rpt_no() {
			return accd_rpt_no;
		}
		public void setAccd_rpt_no(String accd_rpt_no) {
			this.accd_rpt_no = accd_rpt_no;
		}
		public String[] getClam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_vtm_if__cvr_nm() {
			return clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_vtm_if__cvr_nm;
		}
		public void setClam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_vtm_if__cvr_nm(
				String[] clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_vtm_if__cvr_nm) {
			this.clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_vtm_if__cvr_nm = clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_vtm_if__cvr_nm;
		}
		public String[] getClam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_vtm_if__accd_oj_sqno() {
			return clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_vtm_if__accd_oj_sqno;
		}
		public void setClam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_vtm_if__accd_oj_sqno(
				String[] clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_vtm_if__accd_oj_sqno) {
			this.clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_vtm_if__accd_oj_sqno = clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_vtm_if__accd_oj_sqno;
		}
		public String[] getClam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_vtm_if__vtm_nm() {
			return clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_vtm_if__vtm_nm;
		}
		public void setClam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_vtm_if__vtm_nm(
				String[] clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_vtm_if__vtm_nm) {
			this.clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_vtm_if__vtm_nm = clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_vtm_if__vtm_nm;
		}
		public String[] getClam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_vtm_if__trtf() {
			return clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_vtm_if__trtf;
		}
		public void setClam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_vtm_if__trtf(
				String[] clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_vtm_if__trtf) {
			this.clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_vtm_if__trtf = clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_vtm_if__trtf;
		}
		public String[] getClam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_vtm_if__grmy() {
			return clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_vtm_if__grmy;
		}
		public void setClam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_vtm_if__grmy(
				String[] clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_vtm_if__grmy) {
			this.clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_vtm_if__grmy = clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_vtm_if__grmy;
		}
		public String[] getClam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_vtm_if__sm() {
			return clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_vtm_if__sm;
		}
		public void setClam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_vtm_if__sm(
				String[] clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_vtm_if__sm) {
			this.clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_vtm_if__sm = clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_vtm_if__sm;
		}
		public String[] getClam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_vtm_if__ed_dt() {
			return clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_vtm_if__ed_dt;
		}
		public void setClam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_vtm_if__ed_dt(
				String[] clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_vtm_if__ed_dt) {
			this.clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_vtm_if__ed_dt = clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_vtm_if__ed_dt;
		}
		public String[] getClam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_vtm_if__psic_nm() {
			return clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_vtm_if__psic_nm;
		}
		public void setClam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_vtm_if__psic_nm(
				String[] clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_vtm_if__psic_nm) {
			this.clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_vtm_if__psic_nm = clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_vtm_if__psic_nm;
		}
		public String[] getClam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_vtm_if__tlno() {
			return clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_vtm_if__tlno;
		}
		public void setClam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_vtm_if__tlno(
				String[] clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_vtm_if__tlno) {
			this.clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_vtm_if__tlno = clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_vtm_if__tlno;
		}
		public String[] getClam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_dmit_if__cvr_nm() {
			return clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_dmit_if__cvr_nm;
		}
		public void setClam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_dmit_if__cvr_nm(
				String[] clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_dmit_if__cvr_nm) {
			this.clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_dmit_if__cvr_nm = clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_dmit_if__cvr_nm;
		}
		public String[] getClam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_dmit_if__accd_oj_sqno() {
			return clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_dmit_if__accd_oj_sqno;
		}
		public void setClam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_dmit_if__accd_oj_sqno(
				String[] clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_dmit_if__accd_oj_sqno) {
			this.clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_dmit_if__accd_oj_sqno = clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_dmit_if__accd_oj_sqno;
		}
		public String[] getClam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_dmit_if__vtm_nm() {
			return clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_dmit_if__vtm_nm;
		}
		public void setClam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_dmit_if__vtm_nm(
				String[] clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_dmit_if__vtm_nm) {
			this.clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_dmit_if__vtm_nm = clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_dmit_if__vtm_nm;
		}
		public String[] getClam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_dmit_if__cmpn_amt() {
			return clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_dmit_if__cmpn_amt;
		}
		public void setClam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_dmit_if__cmpn_amt(
				String[] clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_dmit_if__cmpn_amt) {
			this.clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_dmit_if__cmpn_amt = clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_dmit_if__cmpn_amt;
		}
		public String[] getClam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_dmit_if__clab_amt() {
			return clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_dmit_if__clab_amt;
		}
		public void setClam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_dmit_if__clab_amt(
				String[] clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_dmit_if__clab_amt) {
			this.clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_dmit_if__clab_amt = clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_dmit_if__clab_amt;
		}
		public String[] getClam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_dmit_if__sm() {
			return clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_dmit_if__sm;
		}
		public void setClam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_dmit_if__sm(
				String[] clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_dmit_if__sm) {
			this.clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_dmit_if__sm = clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_dmit_if__sm;
		}
		public String[] getClam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_dmit_if__ed_dt() {
			return clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_dmit_if__ed_dt;
		}
		public void setClam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_dmit_if__ed_dt(
				String[] clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_dmit_if__ed_dt) {
			this.clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_dmit_if__ed_dt = clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_dmit_if__ed_dt;
		}
		public String[] getClam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_dmit_if__psic_nm() {
			return clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_dmit_if__psic_nm;
		}
		public void setClam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_dmit_if__psic_nm(
				String[] clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_dmit_if__psic_nm) {
			this.clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_dmit_if__psic_nm = clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_dmit_if__psic_nm;
		}
		public String[] getClam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_dmit_if__tlno() {
			return clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_dmit_if__tlno;
		}
		public void setClam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_dmit_if__tlno(
				String[] clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_dmit_if__tlno) {
			this.clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_dmit_if__tlno = clam_o_n_e_c_l_i_c_k_srv_ed_detl_srch_dmit_if__tlno;
		}
		
		
}
