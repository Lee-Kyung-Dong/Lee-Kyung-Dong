package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class MMTI0013VO extends CMMVO{
	//전문필드
		public String proc_dvn = "";  //[I/O] 처리구분  
		public String funt_key = "";  //[I/O] 기능키  
		public String splc_plan_yn = "";  //[I/O] 간편설계여부  
		public String plno = "";  //[I/O] 증권번호 LK-GA1085-POLI-NO 증권번호
		public String pdgr_cd = "";  //[I/O] 상품군코드  
		public String pdc_cd = "";  //[I/O] 상품코드 LK-GA1085-BJ-CD 보험종목코드
		public String arc_trm_str_dt = "";  //[I/O] 보험기간시작일자 LK-GA1085-BOHUM-GIGAN-SYMD 보험기간시기
		public String arc_trm_fin_dt = "";  //[I/O] 보험기간종료일자 LK-GA1085-BOHUM-GIGAN-EYMD 보험기간종기
		public String aut_tsfr_yn = "";  //[O] 자동이체여부 LK-GA1085-JADONG-ICHE-GB 자동계약구분
		public String[] hdlr__bzlv_no = new String[0];  //[I/O] 취급자_사업단번호 LK-GA1085-JIJUM-CD 계약   지점코드
		public String[] hdlr__bzlv_nm = new String[0];  //[I/O] 취급자_사업단명 H-LK-GA1085-JIJUM-NAME        지점명
		public String[] hdlr__bh_no = new String[0];  //[I/O] 취급자_지점번호 LK-GA1085-JIBU-CD        지부영업소코드
		public String[] hdlr__bh_nm = new String[0];  //[I/O] 취급자_지점명 H-LK-GA1085-JIBU-NAME        지부명
		public String[] hdlr__empno = new String[0];  //[I/O] 취급자_사원번호 LK-GA1085-JOJIKWON-CD        조직원코드
		public String[] hdlr__ep_nm = new String[0];  //[I/O] 취급자_사원명 H-LK-GA1085-JOJIKWON-NAME        조직원명
		public String[] hdlr__ormm_tlno = new String[0];  //[I/O] 취급자_조직원전화번호 LK-GA1085-JOJIKWON-TEL-NO        조직원전화번호
		public String plan_no = "";  //[I/O] 설계번호 LK-GA1085-SULGYE-NO 설계번호
		public String plan_id = "";  //[I/O] 설계ID  
		public String plan_stat_cd = "";  //[I/O] 설계상태코드 LK-GA1085-JINHANG-GUBUN 진행상태구분
		public String plan_stat_cd_nm = "";  //[I/O] 설계상태코드명 H-LK-GA1085-JINHANG-NAME 진행상태명
		public String plan_stat_ptl_cd = "";  //[I/O] 설계상태세부코드  
		public String plan_stat_ptl_cd_nm = "";  //[I/O] 설계상태세부코드명  
		public String sme_ply_yn = "";  //[I/O] 동일증권여부 LK-GA1085-DONGIL-GB 동일증권가입여부코드
		public String ctc_stat_cd = "";  //[] 계약상태코드 LK-GA1085-GYEYAK-SANGTE-CD 계약상태
		public String bsn_if_dat_dvcd = "";  //[I/O] 영업정보자료구분코드 LK-GA1085-GENGSIN-JARYO-GB 갱신자료구분
		public String undw_rsl_cd = "";  //[O] 심사결과코드  
		public String undw_rsl_nm = "";  //[O] 심사결과명  
		public String[] ctc_aprp__undw_cd = new String[0];  //[O] 계약적정성_심사코드  
		public String[] ctc_aprp__ctc_aprp_nm = new String[0];  //[O] 계약적정성_계약적정성명  
		public String uw_rsl_cd = "";  //[O] 인수심사결과코드 LK-GA1085-INSU-SNGIN-GB 인수승인구분
		public String uw_rsl_nm = "";  //[O] 인수심사결과명 H-LK-GA1085-INSU-SNGIN-NAME 인수승인명
		public String ctc_aprp_nm = "";  //[O] 계약적정성명  
		public String fnal_pym_nts = "";  //[I/O] 최종납입횟수 LK-GA1085-BULIP-CNT 불입횟수
		public String nxtm_nstl_ym_dd = "";  //[I/O] 차회분납년월일 LK-GA1085-CHAHWOI-BUNNAP-YMD 차회분납년월일
		public String[] nstl_acc__bank_cd = new String[0];  //[I/O] 은행코드 LK-GA1085-BANK-CD 은행코드
		public String[] nstl_acc__acc_no = new String[0];  //[I/O] 계좌번호 LK-GA1085-GYEJWA-NO 계좌번호
		public String[] nstl_acc__dpsr_dcmt_no = new String[0];  //[I/O] 예금주식별번호 LK-GA1085-GYEJWA-JUMIN-NO 계좌번호주민번호
		public String rcwc_mtd_cd = "";  //[I/O] 입출금방법코드 LK-GA1085-IPCHULGM-BANG-CD 입출금방법 코드
		public String aut_tsfr_epct_dd = "";  //[I/O] 자동이체예정일 LK-GA1085-ICHE-YMD 이체일
		public String pym_mtd_cd = "";  //[I/O] 납입방법코드 LK-GA1085-BUNNAP-BANGCD 분납방법코드
		public String nstl_nts = "";  //[I/O] 분납횟수 LK-GA1085-BUNNAP-CNT 분납횟수
		public String[] ins__cust_dcmt_no = new String[0];  //[I/O] 피보험자_고객식별번호 LK-GA1085-PIB-GOGEK-NO 고객번호
		public String[] ins__cust_no_dvcd = new String[0];  //[I/O] 피보험자_고객번호구분코드 LK-GA1085-PIB-GOGEK-GB 피보험자 고객번호 구분코드
		public String[] ins__cust_no = new String[0];  //[I/O] 피보험자_고객번호 LK-GA1085-PIB-CONTROL-NO 피보험자 고객관리번호
		public String[] ins__cust_nm = new String[0];  //[I/O] 피보험자_고객명 H-LK-GA1085-PIB-GOGEK-NAME 고객명
		public String[] ins__psco_dvcd = new String[0];  //[I/O] 피보험자_개인법인구분코드  
		public String[] ins__copr_regt_no = new String[0];  //[I/O] 피보험자_법인등록번호 LK-GA1085-PIB-BUPIN-NO 법인번호
		public String[] ins__nwod_adr_dvcd = new String[0];  //[I/O] 피보험자_신구주소구분코드  
		public String[] ins__iage = new String[0];  //[I/O] 피보험자_만나이 LK-GA1085-PIB-YUNRYUNG 피보험자 연령
		public String[] ins__cntp_dvcd = new String[0];  //[I/O] 피보험자_연락처구분코드  
		public String[] ins__eml = new String[0];  //[I/O] 피보험자_이메일 LK-GA1085-PIB-E-MAIL E-MAIL
		public String[] ins__at_ins_tpcd = new String[0];  //[I/O] 피보험자_자동차피보험자유형코드  
		public String[] ins_adr_if__cntp_dvcd = new String[0];  //[I/O] 피보험자주소정보_연락처구분코드 H-LK-GA1085-PIB-JIB-ZIP-NM 피보험자집주소
		public String[] ins_adr_if__nwod_adr_dvcd = new String[0];  //[I/O] 피보험자주소정보_신구주소구분코드 LK-GA1085-PIB-JUSO-SINGU-GB 피보험자주소신구구분
		public String[] ins_adr_if__psno = new String[0];  //[I/O] 피보험자주소정보_우편번호 H-LK-GA1085-PIB-JIB-ADDR 기타번지(집)
		public String[] ins_adr_if__pst_adr = new String[0];  //[I/O] 피보험자주소정보_우편주소 LK-GA1085-PIB-JIK-ZIP 우편번호(직장)
		public String[] ins_adr_if__eta_adr = new String[0];  //[I/O] 피보험자주소정보_기타주소 H-LK-GA1085-PIB-JIK-ZIP-NM 피보험자직장주소
		public String[] ins_cntp_if__cntp_dvcd = new String[0];  //[I/O] 피보험자연락처정보_연락처구분코드 LK-GA1085-PIB-JIB-TEL-NO 전화번호
		public String[] ins_cntp_if__tlp_arno = new String[0];  //[I/O] 피보험자연락처정보_전화지역번호 LK-GA1085-PIB-JIK-TEL-NO 직장전화번호
		public String[] ins_cntp_if__tlp_ofno = new String[0];  //[I/O] 피보험자연락처정보_전화국번호 LK-GA1085-PIB-HP-TEL-NO 휴대폰번호
		public String[] ins_cntp_if__tlp_idvno = new String[0];  //[I/O] 피보험자연락처정보_전화개별번호  
		public String job_cd = "";  //[I/O] 직업코드 LK-GA1085-PIB-JOB-CD 피보험자 직업코드
		public String job_nm = "";  //[I/O] 직업코드명  
		public String oprn_usge_cd = "";  //[I/O] 운용용도코드  
		public String oprn_usge_nm = "";  //[O] 운용용도명  
		public String wedd_yn = "";  //[I/O] 결혼여부 LK-GA1085-PIB-GYULHON-YN 결혼여부코드
		public String[] drvr__cust_dcmt_no = new String[0];  //[I/O] 운전자_고객식별번호 LK-GA1085-UNJ-GOGEK-NO 주운전자 고객번호
		public String[] drvr__cust_no_dvcd = new String[0];  //[I/O] 운전자_고객번호구분코드 LK-GA1085-UNJ-GOGEK-GB 주운전자 고객번호 구분코드
		public String[] drvr__cust_no = new String[0];  //[I/O] 운전자_고객번호 LK-GA1085-UNJ-CONTROL-NO 주운전자 고객관리번호
		public String[] drvr__cust_nm = new String[0];  //[I/O] 운전자_고객명 H-LK-GA1085-UNJ-GOGEK-NAME 주운전자 성명
		public String[] drvr__iage = new String[0];  //[I/O] 운전자_만나이 LK-GA1085-UNJ-YUNRYUNG 연령
		public String[] drvr__ins_rlt_cd = new String[0];  //[I/O] 운전자_피보험자관계코드 LK-GA1085-UNJ-GWANGE 피보험자와의 관계코드
		public String[] plhd__cust_dcmt_no = new String[0];  //[I/O] 계약자_고객식별번호 LK-GA1085-GYE-GOGEK-NO 계약자 고객번호
		public String[] plhd__cust_no_dvcd = new String[0];  //[I/O] 계약자_고객번호구분코드 LK-GA1085-GYE-GOGEK-GB 계약자 고객구분코드
		public String[] plhd__cust_no = new String[0];  //[I/O] 계약자_고객번호 LK-GA1085-GYE-CONTROL-NO 계약자 고객관리번호
		public String[] plhd__cust_nm = new String[0];  //[I/O] 계약자_고객명 H-LK-GA1085-GYE-GOGEK-NAME 계약자 고객명
		public String[] plhd__nwod_adr_dvcd = new String[0];  //[I/O] 계약자_신구주소구분코드  
		public String[] plhd__eml = new String[0];  //[I/O] 계약자_이메일 LK-GA1085-GYE-E-MAIL E-MAIL
		public String[] plhd__cntp_dvcd = new String[0];  //[I/O] 계약자_연락처구분코드  
		public String[] plhd_adr_if__cntp_dvcd = new String[0];  //[I/O] 계약자주소정보_연락처구분코드 H-LK-GA1085-GYE-JIB-ZIP-NM 계약자자택주소
		public String[] plhd_adr_if__nwod_adr_dvcd = new String[0];  //[I/O] 계약자주소정보_신구주소구분코드 LK-GA1085-GYE-JUSO-SINGU-GB 계약자주소신구구분
		public String[] plhd_adr_if__psno = new String[0];  //[I/O] 계약자주소정보_우편번호 H-LK-GA1085-GYE-JIB-ADDR 계약자 기타번지(집)
		public String[] plhd_adr_if__pst_adr = new String[0];  //[I/O] 계약자주소정보_우편주소 LK-GA1085-GYE-JIK-ZIP 우편번호(직장)
		public String[] plhd_adr_if__eta_adr = new String[0];  //[I/O] 계약자주소정보_기타주소 H-LK-GA1085-GYE-JIK-ZIP-NM 계약자직장주소
		public String[] plhd_cntp_if__cntp_dvcd = new String[0];  //[I/O] 계약자연락처정보_연락처구분코드  
		public String[] plhd_cntp_if__tlp_arno = new String[0];  //[I/O] 계약자연락처정보_전화지역번호 LK-GA1085-GYE-JIB-TEL-NO 계약자 자택 전화번호
		public String[] plhd_cntp_if__tlp_ofno = new String[0];  //[I/O] 계약자연락처정보_전화국번호 LK-GA1085-GYE-JIK-TEL-NO 직장전화번호
		public String[] plhd_cntp_if__tlp_idvno = new String[0];  //[I/O] 계약자연락처정보_전화개별번호 LK-GA1085-GYE-HP-TEL-NO 휴대폰번호
		public String[] lwt_tago__cust_dcmt_no = new String[0];  //[I/O] 최저연령자_고객식별번호 LK-GA1085-C-UNJ-GOGEK-NO 추가운전자  고객번호
		public String[] lwt_tago__cust_no_dvcd = new String[0];  //[I/O] 최저연령자_고객번호구분코드 LK-GA1085-C-UNJ-GOGEK-GB 추가운전자  고객번호 구분코드
		public String[] lwt_tago__cust_no = new String[0];  //[I/O] 최저연령자_고객번호 LK-GA1085-C-UNJ-CONTROL-NO 추가운전자  고객관리번호
		public String[] lwt_tago__cust_nm = new String[0];  //[I/O] 최저연령자_고객명 H-LK-GA1085-C-UNJ-GOGEK-NAME 추가운전자 성명
		public String[] lwt_tago__iage = new String[0];  //[I/O] 최저연령자_만나이 LK-GA1085-C-UNJ-YUNRYUNG 추가운전자  연령
		public String[] lwt_tago__ins_rlt_cd = new String[0];  //[I/O] 최저연령자_피보험자관계코드 LK-GA1085-C-UNJ-GWANGE   피보험자와의 관계코드
		public String[] bnfc__cust_dcmt_no = new String[0];  //[I/O] 수익자_고객식별번호 LK-GA1085-SUIKJA-GOGEKNO 수익자주민번호
		public String[] bnfc__cust_nm = new String[0];  //[I/O] 수익자_고객명 H-LK-GA1085-SUIKJA-NAME 수익자성명
		public String[] bnfc__ins_rlt_cd = new String[0];  //[I/O] 수익자_피보험자관계코드 LK-GA1085-PIBO-GWANGE 피보험자와의관계
		public String[] bnfc__nwod_adr_dvcd = new String[0];  //[I/O] 수익자_신구주소구분코드  
		public String[] bnfc_adr_if__cntp_dvcd = new String[0];  //[I/O] 수익자주소정보_연락처구분코드 LK-GA1085-SUIKJA-ZIP 우편번호
		public String[] bnfc_adr_if__nwod_adr_dvcd = new String[0];  //[I/O] 수익자주소정보_신구주소구분코드 LK-GA1085-SUIKJA-JUSO-SINGU-GB 수익자주소신구구분
		public String[] bnfc_adr_if__psno = new String[0];  //[I/O] 수익자주소정보_우편번호 H-LK-GA1085-SUIKJA-ZIP-NM 수익자자택주소
		public String[] bnfc_adr_if__pst_adr = new String[0];  //[I/O] 수익자주소정보_우편주소 H-LK-GA1085-SUIKJA-GITA-ADDR 기타주소
		public String[] bnfc_adr_if__eta_adr = new String[0];  //[I/O] 수익자주소정보_기타주소  
		public String[] bnfc_cntp_if__cntp_dvcd = new String[0];  //[I/O] 수익자연락처정보_연락처구분코드 LK_GA1085_HP_TEL1_NO2 핸드폰번호2
		public String[] bnfc_cntp_if__tlp_arno = new String[0];  //[I/O] 수익자연락처정보_전화지역번호 LK_GA1085_HP_TEL1_NO3 핸드폰번호3
		public String[] bnfc_cntp_if__tlp_ofno = new String[0];  //[I/O] 수익자연락처정보_전화국번호 LK_GA1085_HOME_TEL2_NO1 자택전화번호1
		public String[] bnfc_cntp_if__tlp_idvno = new String[0];  //[I/O] 수익자연락처정보_전화개별번호 LK_GA1085_HOME_TEL2_NO2 자택전화번호2
		public String hngl_vh_no = "";  //[I/O] 한글차량번호 H-LK-GA1085-MOKJUK-NAME 차량번호
		public String vh_ocd = "";  //[I/O] 차량관코드 LK-GA1085-GWAN-CD 관코드
		public String vh_no = "";  //[I/O] 차량번호 LK-GA1085-MOKJUK-CD 목적코드
		public String vh_usge_cd = "";  //[I/O] 차량용도코드 LK-GA1085-CAR-YONGDO-CD 차량용도
		public String vh_use_usge_cd = "";  //[I/O] 차량사용용도코드 LK-GA1085-SAYONG-YONGDO-CD 사용용도
		public String ctp_cd = "";  //[I/O] 차종코드 LK-GA1085-CHAJONG-CD 차종코드
		public String ctp_nm = "";  //[I/O] 차종명 H-LK-GA1085-CHAJONG-NAME 차종명
		public String crnm_cd = "";  //[I/O] 차명코드 LK-GA1085-CAR-CD 차명코드
		public String crnm_cd_hngl_nm = "";  //[I/O] 차명코드한글명 H-LK-GA1085-CAR-NAME 차명
		public String vh_pyy = "";  //[I/O] 차량년식 LK-GA1085-YUNSIK 연식
		public String pyy_dvcd = "";  //[I/O] 년식구분코드  
		public String dspl = "";  //[I/O] 배기량 LK-GA1085-BEGIRYANG 배기량
		public String ld_tns = "";  //[I/O] 적재톤수 LK-GA1085-JUKJE-TON 적재톤수
		public String cpct_cnt = "";  //[I/O] 정원수 LK-GA1085-JUNGWON-CNT 정원수
		public String cbdy_no_dvcd = "";  //[I/O] 차대번호구분코드 LK-GA1085-CHADE-NO-GB 차대번호 구분코드
		public String cbdy_no = "";  //[I/O] 차대번호 LK-GA1085-CHADE-NO 차대번호
		public String cpnt_tot_invl = "";  //[I/O] 부속품총보험가액 LK-GA1085-BUSOKPUM-GAEK 부속품 보험가액
		public String mach_eqp_invl = "";  //[I/O] 기계장치보험가액 LK-GA1085-GIGE-BOGAEK 기계장치 보험가액
		public String vh_vae = "";  //[I/O] 차량가액 LK-GA1085-CAR-GAEK 차량가액
		public String vh_tot_vae = "";  //[O] 차량총가액  
		public String nca_rt = "";  //[I/O] 새차율 LK-GA1085-NEW-CAR-RATE 새차요율
		public String ucr_rt = "";  //[I/O] 중고차율 LK-GA1085-OLD-CAR-RATE 중고차요율
		public String dvry_oj_use_dvcd = "";  //[I/O] 배달목적사용구분코드 LK-GA1085-BEDAL-SAYONG-YN 배달목적사용여부
		public String aiba_damg_qnty_dvcd = "";  //[I/O] 에어백파손수량구분코드 LK-GA1085-AIR-PASON-GB 에어백파손여부
		public String vh_temp_dvcd = "";  //[I/O] 차량임시구분코드 LK-GA1085-CAR-CD-IMSI-GB 임시차명구분
		public String vh_regt_dt = "";  //[I/O] 차량등록일자 LK-GA1085-DEUNGROK-YMD 최초등록일
		public String apcn_trt_eny_carr_rt = "";  //[I/O] 적용요율가입경력율 LK-GA1085-GAIP-YIM-GUNGRUK 변경후 임의가입자 경력요율
		public String apcn_trt_rglt_vlt_rt = "";  //[I/O] 적용요율법규위반율 LK-GA1085-GAIP-YIM-GOTONG 변경후 임의가입자 교통법규 위반요율
		public String chng_af_fac_ssrt_chrc_trt_sm = "";  //[I/O] 변경후임의가입자 특성요율 합계 LK-GA1085-GAIP-YIM-TOT 변경후 임의가입자 특성요율 합계
		public String apcn_trt_dst_xtr_rt = "";  //[I/O] 적용요율할인할증율 LK-GA1085-HAL-YIM-HALIN 변경후 임의 우량할인.불량할증
		public String apcn_trt_spc_xtr_rt = "";  //[I/O] 적용요율특별할증율 LK-GA1085-HAL-YIM-TUKBUL 변경 후 특별할증율
		public String apcn_trt_spc_xtr_cd = "";  //[I/O] 적용요율특별할증코드 LK-GA1085-HAL-YIM-TUKBUL-CD 변경 후 특별할증코드
		public String mky_tptn_use_shp_cd = "";  //[I/O] 유상운송사용형태코드 LK-GA1085-SAYONG-CD   사용코드
		public String shtm_rt = "";  //[I/O] 단기율 LK-GA1085-DANGI-YUL   단기율
		public String apcn_trt_dysy_vlt_cd = "";  //[I/O] 적용요율요일제위반코드 LK-GA1085-TKBYUL-TYPE-ECD 요일제위반특별할증코드
		public String dysy_vlt_rt = "0";  //[I/O] 요일제위반율 LK-GA1085-URYU-0006-899-YUL 요일제위반특별할증율임의
		public String ag_tty_aut_chng_tgt_yn = "";  //[I/O] 연령특약자동변경대상여부 LK-GA1085-YUNRYUNG-BESU-GB  연령자동변경     배서구분
		public String ag_tty_aut_chng_bse_dd = "";  //[I/O] 연령특약자동변경기준일 LK-GA1085-YUNRYUNG-YMD 연령특약자동변경     배서기준일
		public String ag_chng_trgm_dcmt_no = "";  //[I/O] 연령변경대상자식별번호 LK-GA1085-YUNRYUNG-GOGEK-NO 연력특약자동변경 대상고객식별번호
		public String ag_chng_trgm_nm = "";  //[I/O] 연령변경대상자명 H-LK-GA1085-YUNRYUNG-GOGEK-NM  연력특약자동변경 대상고객명
		public String mtl_accd_xtr_amt_cd = "";  //[I/O] 물적사고할증금액코드 LK-GA1085-MULSAGO-GIJUN-GMEK 물적사고기준금액
		public String ag_tty_aut_chng_tty_cd = "";  //[I/O] 연령특약자동변경특약코드 LK_GA1085_YUNRYUNG_HU 연령자동변경 후특약코드
		public String ag_tty_aut_chng_tty_trt = "";  //[I/O] 연령특약자동변경특약요율 LK_GA1085_YUNRYUNG_HU_YOYUL 연령자동변경 특약요율
		public String[] eny_tty_spc_if__tty_spc_trt_dvcd = new String[0];  //[I/O] 가입특약특별정보_특약특별요율구분코드  
		public String[] eny_tty_spc_if__cd = new String[0];  //[I/O] 가입특약특별정보_코드  
		public String[] eny_tty_spc_if__dsn = new String[0];  //[I/O] 가입특약특별정보_명칭  
		public String[] eny_tty_spc_if__at_apcn_trt = new String[0];  //[I/O] 가입특약특별정보_자동차적용요율  
		public String[] eny_tty_spc_if__apcn_gr_val = new String[0];  //[I/O] 가입특약특별정보_적용등급값  
		public String[] eny_tty_spc_if__tty_spc_grp_cd = new String[0];  //[I/O] 가입특약특별정보_특약특별그룹코드  
		public String[] eny_tty_spc_if__updt_pss_yn = new String[0];  //[I/O] 가입특약특별정보_수정가능여부  
		public String[] eny_cvr_if__cd = new String[0];  //[I/O] 가입담보정보_코드  
		public String[] eny_cvr_if__ctc_cvr_dvcd = new String[0];  //[I/O] 가입담보정보_계약담보구분코드  
		public String[] eny_cvr_if__dsn = new String[0];  //[I/O] 가입담보정보_명칭  
		public String[] eny_cvr_if__bsc_cvr_cd = new String[0];  //[I/O] 가입담보정보_기본담보코드  
		public String[] eny_cvr_if__tty_rt = new String[0];  //[I/O] 가입담보정보_특약률  
		public String[] eny_cvr_if__spc_rt = new String[0];  //[I/O] 가입담보정보_특별률  
		public String[] eny_cvr_if__ind_bsc_rnge_rt = new String[0];  //[I/O] 가입담보정보_개별기본범위율  
		public String[] eny_cvr_if__scy_bsc_rnge_rt = new String[0];  //[I/O] 가입담보정보_단체기본범위율  
		public String[] eny_cvr_if__apcn_bsc_rnge_rt = new String[0];  //[I/O] 가입담보정보_적용기본범위율  
		public String[] eny_cvr_if__inam_cd = new String[0];  //[I/O] 가입담보정보_가입금액코드  
		public String[] eny_cvr_if__inam = new String[0];  //[I/O] 가입담보정보_가입금액  
		public String[] eny_cvr_if__dct_amt_cd = new String[0];  //[I/O] 가입담보정보_공제금액코드  
		public String[] eny_cvr_if__dct_rt = new String[0];  //[I/O] 가입담보정보_공제율  
		public String[] eny_cvr_if__at_bsc_prm = new String[0];  //[I/O] 가입담보정보_자동차기본보험료  
		public String[] eny_cvr_if__at_apcn_prm = new String[0];  //[I/O] 가입담보정보_자동차적용보험료  
		public String[] eny_cvr_if__at_fnal_apcn_prm = new String[0];  //[I/O] 가입담보정보_자동차최종적용보험료  
		public String[] eny_cvr_if__sym_impr_prv_fnal_apcn_prm = new String[0];  //[I/O] 가입담보정보_제도개선전최종적용보험료  
		public String[] eny_cvr_if__sym_impr_af_fnal_apcn_prm = new String[0];  //[I/O] 가입담보정보_제도개선후최종적용보험료  
		public String[] eny_cvr_if__cvr_stat_cd = new String[0];  //[I/O] 가입담보정보_담보상태코드  
		public String[] eny_cvr_if__cvr_stat_cd_nm = new String[0];  //[I/O] 가입담보정보_담보상태코드명  
		public String[] eny_cvr_if__cvr_trm_str_dt = new String[0];  //[I/O] 가입담보정보_담보기간시작일자  
		public String[] eny_cvr_if__cvr_trm_fin_dt = new String[0];  //[I/O] 가입담보정보_담보기간종료일자  
		public String[] eny_cvr_if__cvr_id = new String[0];  //[I/O] 가입담보정보_담보ID  
		public String[] eny_cvr_if__updt_pss_yn = new String[0];  //[I/O] 가입담보정보_수정가능여부  
		public String[] pcg__cd = new String[0];  //[I/O] 패키지_코드  
		public String[] pcg__dsn = new String[0];  //[I/O] 패키지_명칭  
		public String[] pcg__use_pss_yn = new String[0];  //[I/O] 패키지_사용가능여부  
		public String[] rcwc_epct__rcwc_orr = new String[0];  //[O] 입출금예정_입출금회차 LK-GA1085-HWOICHA 분납회차
		public String[] rcwc_epct__nstl_epct_prm = new String[0];  //[O] 입출금예정_분납예정보험료 LK-GA1085-HWOICHA-PRM 분납회차보험료
		public String eltc_yn = "";  //[I/O] 전기차여부 LK-GA1085-ELECTRIC-GB 전기자동차구분
		public String oty = "";  //[I/O] 출력량 LK-GA1085-CHULRYUKRYANG 전기자동차출력
		public String dysy_dvcd = "";  //[I/O] 요일제구분코드 LK-GA1085-S-WEEK-DAY 승용차요일제요일
		public String[] cmp_prm__fsti_prm = new String[0];  //[I/O] 산출보험료_초회보험료 LK-GA1085-YIM-FIRST 초회보험료      종합
		public String[] cmp_prm__nstl_prm = new String[0];  //[I/O] 산출보험료_분납보험료 LK-GA1085-BUNNAP-TOT       분납보험료 합계
		public String[] cmp_prm__tot_prm = new String[0];  //[I/O] 산출보험료_총보험료 LK-GA1085-TOT-JUKYONG 적용보험료     합계
		public String[] cmp_prm__cltd_prm = new String[0];  //[I/O] 산출보험료_영수보험료 LK_GA1085_TOT_YUNGSU_PRM 총영수보험료
		public String dst_xtr_vlut_accd_cnum = "";  //[O] 할인할증평가사고건수 LK-GA1085-PYOUNG-SAGO-GUNSU 평가대상사고건수
		public String apcn_prm_fac_sm = "";  //[O] 적용보험료임의합계 LK-GA1085-YIM-JUKYONG 적용보험료      종합
		public String apcn_prm_lbl_sm = "";  //[O] 적용보험료책임합계 LK-GA1085-CHK-JUKYONG 적용보험료      책임
		public String arc_eny_carr_ycnt = "";  //[O] 보험가입경력년수 LK-GA1085-GR-YEAR-CNT 보험가입경력 년수
		public String arc_eny_carr_mcnt = "";  //[O] 보험가입경력월수 LK-GA1085-GR-MON-CNT 보험가입경력 월수
		public String arc_eny_carr_dcnt = "";  //[O] 보험가입경력일수 LK-GA1085-GR-DAY-CNT 보험가입경력 일수
		public String scy_eny_yn = "";  //[O] 단체가입여부 LK-GA1085-DANCHE-YN 단체가입여부
		public String dst_xtr_dvcd = "";  //[O] 할인할증구분코드 LK-GA1085-DANCHE-YUNGSU-GB 할인할증적용 구분(1:개별, 2:단체)
		public String asg_obj_yn = "";  //[O] 배정물건여부 LK-GA1085-BEJUNG-MULGUN-YN 배정물건 여부코드
		public String vlut_tgt_str_dt = "";  //[O] 평가대상시작일자 LK-GA1085-PYUNG-GIGAN-SYMD 평가기간 시기
		public String vlut_tgt_fin_dt = "";  //[O] 평가대상종료일자 LK-GA1085-PYUNG-GIGAN-EYMD 평가기간 종기
		public String past_f3yr_vlut_tgt_str_dt = "";  //[O] 과거3년간평가대상시작일자 LK-GA1085-3-YEAR-GIGAN-SYMD 3년간사고기간     FROM
		public String past_f3yr_vlut_tgt_fin_dt = "";  //[O] 과거3년간평가대상종료일자 LK-GA1085-3-YEAR-GIGAN-EYMD 3년간사고기간     TO
		public String tot_accd_cnum = "";  //[O] 총사고건수 LK-GA1085-TOT-SAGO-GUN 총사고건수
		public String dst_xtr_vlut_accd_pnt = "";  //[O] 할인할증평가사고점수 LK-GA1085-TOT-SAGO-JUMSU 총사고점수
		public String past_f3yr_accd_cnum = "";  //[O] 과거3년간사고건수 LK-GA1085-3-YEAR-SAGO-GUN 과거3년간 사고건수
		public String prv_iscp_cd = "";  //[O] 전보험사코드 LK-GA1085-JUN-BOHUMJA-CD 전보험사코드
		public String prv_plno = "";  //[O] 전증권번호 LK-GA1085-JUN-POLI-NO 전계약 임의 증권번호
		public String stdd_dst_xtr_rt = "";  //[O] 표준할인할증률 LK-GA1085-JUN-HAL-YIM-HALIN 변경전  임의 우량할인.불량할증
		public String spc_xtr_rt = "";  //[O] 특별할증률 LK-GA1085-JUN-HAL-TUKBUL   특별할증율
		public String spc_xtr_cd = "";  //[O] 특별할증코드 LK-GA1085-JUN-HAL-TUKBUL-CD   특별할증코드
		public String eny_carr_rt = "";  //[O] 가입경력률 LK-GA1085-JUN-GAIP-YIM-GUNGRUK 변경전 임의가입자 경력요율
		public String rglt_vlt_rt = "";  //[O] 법규위반율 LK-GA1085-JUN-GAIP-YIM-GOTONG 변경전 임의가입자 교통법규 위반요율
		public String chng_prv_fac_ssrt_chrc_trt_sm = "";  //[O] 변경전임의가입자 특성요율 합계 LK-GA1085-JUN-GAIP-YIM-TOT 변경전 임의가입자 특성요율 합계
		public String et_eqal_yn = "";  //[O] 종기일치여부 LK-GA1085-JONGGI-ILCHI-GB 종기일치여부
		public String pan_tpcd = "";  //[I/O] 플랜유형코드 LK-GA1085-PLAN-GB 플랜구분
		public String chn_cd = "";  //[I/O] 채널코드 LK-GA1085-CHANNEL-CD 채널코드
		public String bsc_equp_eqp_cd = "";  //[O] 기본장착장치코드  
		public String bsc_equp_eqp_cd_nm = "";  //[O] 기본장착장치코드명  
		public String apcn_trt_dst_xtr_cd = "";  //[I/O] 적용요율할인할증코드 LK-GA1085-HAL-YIM-DUNGGUP 변경후 임의 우량할인.불량할증등급
		public String stdd_dst_xtr_grcd = "";  //[O] 표준할인할증등급코드 LK-GA1085-JUN-HAL-YIM-DUNGGUP 변경전 임의 우량할인.불량할증등급
		public String vh_mode_each_gr_cd = "";  //[I/O] 차량모델별등급코드 LK-GA1085-MODEL-DUNGGUP 차명 모델별 등급
		public String vh_mode_each_gr_aprt = "";  //[I/O] 차량모델별등급적용률 LK-GA1085-MODEL-YUL 차명 모델별 등급 요율 
		public String frst_trv_dstc = "";  //[I/O] 최초주행거리 LK-GA1085-DRIVE-KM 주행거리특약거리
		public String yy_avg_trv_dstc = "";  //[I/O] 년평균주행거리 LK-GA1085-AVG-DRIVE-KM 평균주행거리
		public String ctt_trv_dstc_cd = "";  //[I/O] 약정주행거리코드 LK-GA1085-FIX-DRIVE-KM 고정주행거리
		public String trv_dstc_tty_dst_rt = "";  //[O] 주행거리특약할인율 LK-GA1085-DRIVE-02-YUL 주행거리후할인율
		public String trv_dstc_tty_dst_amt = "";  //[O] 주행거리특약할인금액 LK-GA1085-DRIVE-0152-PRM 주행거리후할인보험료
		public String vh_vae_updt_rs_cd = "";  //[I/O] 차량가액수정사유코드 LK-GA1085-SAYU-GB 차량기본가액수정사유구분
		public String blbo_dvn = "";  //[I/O] 블랙박스구분 LK-GA1085-B-SEBU-CD 블랙박스세부코드
		public String vh_eqp_mafr_nm = "";  //[I/O] 차량장치제조사명 H-LK-GA1085-B-COMPANY 블랙박스제조회사
		public String vh_eqp_gds_nm = "";  //[I/O] 차량장치제품명 H-LK-GA1085-B-GOODS 블랙박스제품명
		public String vh_eqp_mode_nm = "";  //[I/O] 차량장치모델명 H-LK-GA1085-B-MODEL 블랙박스모델명
		public String ownr_dcdc_dvcd = "";  //[I/O] 소유자불일치구분코드 LK-GA1085-NAME-IJUN-GB 소유자불일치구분
		public String ownr_dcdc_cust_dcmt_no = "";  //[I/O] 소유자불일치고객식별번호 LK-GA1085-GONGDONG-NAME-CD 공동명의자주민번호
		public String ownr_dcdc_cust_no = "";  //[I/O] 소유자불일치고객번호  
		public String ownr_dcdc_cust_nm = "";  //[I/O] 소유자불일치고객명  
		public String ins_rlt_cd = "";  //[I/O] 피보험자관계코드 LK-GA1085-GONGDONG-GWANGE 공동명의자피보험자관계
		public String dcdc_rs = "";  //[I/O] 불일치사유 H-LK-GA1085-NAME-IJUN-SAYU 소유자불일치사유
		public String[] add_cpnt__cd = new String[0];  //[I/O] 추가부속품_코드 LK-GA1085-GITA-BUSOK-CD 추가부속품코드
		public String[] add_cpnt__dsn = new String[0];  //[I/O] 추가부속품_명칭 H-LK-GA1085-GITA-BUSOK-NM 추가부속품명
		public String[] add_cpnt__vae = new String[0];  //[I/O] 추가부속품_가액 LK-GA1085-GITA-BUSOK-GMEK 추가부속품가입금액
		public String[] ecvr_bz_rcwc__sl_cvr_cd = new String[0];  //[I/O] 담보별입출금예정_판매담보코드  
		public String[] ecvr_bz_rcwc__cvr_each_prm = new String[0];  //[I/O] 담보별입출금예정_담보별보험료
		
		public String sbt_drvr_cust_dcmt_no = ""; // [I/O] 대리운전자고객식별번호
		public String sbt_drve_trdr_plhd_csn_yn = ""; // [O] 대리운전업자계약자동의여부
		public String sbt_drvr_apcn_prm = ""; // [O] 대리운전자적용보험료
		public String accd_mtt = ""; // [O] 사고사항
		public String ctrmf_nts = ""; // [O] 계약변경횟수
		
		public String getProc_dvn() {
			return proc_dvn;
		}
		public void setProc_dvn(String proc_dvn) {
			this.proc_dvn = proc_dvn;
		}
		public String getFunt_key() {
			return funt_key;
		}
		public void setFunt_key(String funt_key) {
			this.funt_key = funt_key;
		}
		public String getSplc_plan_yn() {
			return splc_plan_yn;
		}
		public void setSplc_plan_yn(String splc_plan_yn) {
			this.splc_plan_yn = splc_plan_yn;
		}
		public String getPlno() {
			return plno;
		}
		public void setPlno(String plno) {
			this.plno = plno;
		}
		public String getPdgr_cd() {
			return pdgr_cd;
		}
		public void setPdgr_cd(String pdgr_cd) {
			this.pdgr_cd = pdgr_cd;
		}
		public String getPdc_cd() {
			return pdc_cd;
		}
		public void setPdc_cd(String pdc_cd) {
			this.pdc_cd = pdc_cd;
		}
		public String getArc_trm_str_dt() {
			return arc_trm_str_dt;
		}
		public void setArc_trm_str_dt(String arc_trm_str_dt) {
			this.arc_trm_str_dt = arc_trm_str_dt;
		}
		public String getArc_trm_fin_dt() {
			return arc_trm_fin_dt;
		}
		public void setArc_trm_fin_dt(String arc_trm_fin_dt) {
			this.arc_trm_fin_dt = arc_trm_fin_dt;
		}
		public String getAut_tsfr_yn() {
			return aut_tsfr_yn;
		}
		public void setAut_tsfr_yn(String aut_tsfr_yn) {
			this.aut_tsfr_yn = aut_tsfr_yn;
		}
		public String[] getHdlr__bzlv_no() {
			return hdlr__bzlv_no;
		}
		public void setHdlr__bzlv_no(String[] hdlr__bzlv_no) {
			this.hdlr__bzlv_no = hdlr__bzlv_no;
		}
		public String[] getHdlr__bzlv_nm() {
			return hdlr__bzlv_nm;
		}
		public void setHdlr__bzlv_nm(String[] hdlr__bzlv_nm) {
			this.hdlr__bzlv_nm = hdlr__bzlv_nm;
		}
		public String[] getHdlr__bh_no() {
			return hdlr__bh_no;
		}
		public void setHdlr__bh_no(String[] hdlr__bh_no) {
			this.hdlr__bh_no = hdlr__bh_no;
		}
		public String[] getHdlr__bh_nm() {
			return hdlr__bh_nm;
		}
		public void setHdlr__bh_nm(String[] hdlr__bh_nm) {
			this.hdlr__bh_nm = hdlr__bh_nm;
		}
		public String[] getHdlr__empno() {
			return hdlr__empno;
		}
		public void setHdlr__empno(String[] hdlr__empno) {
			this.hdlr__empno = hdlr__empno;
		}
		public String[] getHdlr__ep_nm() {
			return hdlr__ep_nm;
		}
		public void setHdlr__ep_nm(String[] hdlr__ep_nm) {
			this.hdlr__ep_nm = hdlr__ep_nm;
		}
		public String[] getHdlr__ormm_tlno() {
			return hdlr__ormm_tlno;
		}
		public void setHdlr__ormm_tlno(String[] hdlr__ormm_tlno) {
			this.hdlr__ormm_tlno = hdlr__ormm_tlno;
		}
		public String getPlan_no() {
			return plan_no;
		}
		public void setPlan_no(String plan_no) {
			this.plan_no = plan_no;
		}
		public String getPlan_id() {
			return plan_id;
		}
		public void setPlan_id(String plan_id) {
			this.plan_id = plan_id;
		}
		public String getPlan_stat_cd() {
			return plan_stat_cd;
		}
		public void setPlan_stat_cd(String plan_stat_cd) {
			this.plan_stat_cd = plan_stat_cd;
		}
		public String getPlan_stat_cd_nm() {
			return plan_stat_cd_nm;
		}
		public void setPlan_stat_cd_nm(String plan_stat_cd_nm) {
			this.plan_stat_cd_nm = plan_stat_cd_nm;
		}
		public String getPlan_stat_ptl_cd() {
			return plan_stat_ptl_cd;
		}
		public void setPlan_stat_ptl_cd(String plan_stat_ptl_cd) {
			this.plan_stat_ptl_cd = plan_stat_ptl_cd;
		}
		public String getPlan_stat_ptl_cd_nm() {
			return plan_stat_ptl_cd_nm;
		}
		public void setPlan_stat_ptl_cd_nm(String plan_stat_ptl_cd_nm) {
			this.plan_stat_ptl_cd_nm = plan_stat_ptl_cd_nm;
		}
		public String getSme_ply_yn() {
			return sme_ply_yn;
		}
		public void setSme_ply_yn(String sme_ply_yn) {
			this.sme_ply_yn = sme_ply_yn;
		}
		public String getCtc_stat_cd() {
			return ctc_stat_cd;
		}
		public void setCtc_stat_cd(String ctc_stat_cd) {
			this.ctc_stat_cd = ctc_stat_cd;
		}
		public String getBsn_if_dat_dvcd() {
			return bsn_if_dat_dvcd;
		}
		public void setBsn_if_dat_dvcd(String bsn_if_dat_dvcd) {
			this.bsn_if_dat_dvcd = bsn_if_dat_dvcd;
		}
		public String getUndw_rsl_cd() {
			return undw_rsl_cd;
		}
		public void setUndw_rsl_cd(String undw_rsl_cd) {
			this.undw_rsl_cd = undw_rsl_cd;
		}
		public String getUndw_rsl_nm() {
			return undw_rsl_nm;
		}
		public void setUndw_rsl_nm(String undw_rsl_nm) {
			this.undw_rsl_nm = undw_rsl_nm;
		}
		public String[] getCtc_aprp__undw_cd() {
			return ctc_aprp__undw_cd;
		}
		public void setCtc_aprp__undw_cd(String[] ctc_aprp__undw_cd) {
			this.ctc_aprp__undw_cd = ctc_aprp__undw_cd;
		}
		public String[] getCtc_aprp__ctc_aprp_nm() {
			return ctc_aprp__ctc_aprp_nm;
		}
		public void setCtc_aprp__ctc_aprp_nm(String[] ctc_aprp__ctc_aprp_nm) {
			this.ctc_aprp__ctc_aprp_nm = ctc_aprp__ctc_aprp_nm;
		}
		public String getUw_rsl_cd() {
			return uw_rsl_cd;
		}
		public void setUw_rsl_cd(String uw_rsl_cd) {
			this.uw_rsl_cd = uw_rsl_cd;
		}
		public String getUw_rsl_nm() {
			return uw_rsl_nm;
		}
		public void setUw_rsl_nm(String uw_rsl_nm) {
			this.uw_rsl_nm = uw_rsl_nm;
		}
		public String getCtc_aprp_nm() {
			return ctc_aprp_nm;
		}
		public void setCtc_aprp_nm(String ctc_aprp_nm) {
			this.ctc_aprp_nm = ctc_aprp_nm;
		}
		public String getFnal_pym_nts() {
			return fnal_pym_nts;
		}
		public void setFnal_pym_nts(String fnal_pym_nts) {
			this.fnal_pym_nts = fnal_pym_nts;
		}
		public String getNxtm_nstl_ym_dd() {
			return nxtm_nstl_ym_dd;
		}
		public void setNxtm_nstl_ym_dd(String nxtm_nstl_ym_dd) {
			this.nxtm_nstl_ym_dd = nxtm_nstl_ym_dd;
		}
		public String[] getNstl_acc__bank_cd() {
			return nstl_acc__bank_cd;
		}
		public void setNstl_acc__bank_cd(String[] nstl_acc__bank_cd) {
			this.nstl_acc__bank_cd = nstl_acc__bank_cd;
		}
		public String[] getNstl_acc__acc_no() {
			return nstl_acc__acc_no;
		}
		public void setNstl_acc__acc_no(String[] nstl_acc__acc_no) {
			this.nstl_acc__acc_no = nstl_acc__acc_no;
		}
		public String[] getNstl_acc__dpsr_dcmt_no() {
			return nstl_acc__dpsr_dcmt_no;
		}
		public void setNstl_acc__dpsr_dcmt_no(String[] nstl_acc__dpsr_dcmt_no) {
			this.nstl_acc__dpsr_dcmt_no = nstl_acc__dpsr_dcmt_no;
		}
		public String getRcwc_mtd_cd() {
			return rcwc_mtd_cd;
		}
		public void setRcwc_mtd_cd(String rcwc_mtd_cd) {
			this.rcwc_mtd_cd = rcwc_mtd_cd;
		}
		public String getAut_tsfr_epct_dd() {
			return aut_tsfr_epct_dd;
		}
		public void setAut_tsfr_epct_dd(String aut_tsfr_epct_dd) {
			this.aut_tsfr_epct_dd = aut_tsfr_epct_dd;
		}
		public String getPym_mtd_cd() {
			return pym_mtd_cd;
		}
		public void setPym_mtd_cd(String pym_mtd_cd) {
			this.pym_mtd_cd = pym_mtd_cd;
		}
		public String getNstl_nts() {
			return nstl_nts;
		}
		public void setNstl_nts(String nstl_nts) {
			this.nstl_nts = nstl_nts;
		}
		public String[] getIns__cust_dcmt_no() {
			return ins__cust_dcmt_no;
		}
		public void setIns__cust_dcmt_no(String[] ins__cust_dcmt_no) {
			this.ins__cust_dcmt_no = ins__cust_dcmt_no;
		}
		public String[] getIns__cust_no_dvcd() {
			return ins__cust_no_dvcd;
		}
		public void setIns__cust_no_dvcd(String[] ins__cust_no_dvcd) {
			this.ins__cust_no_dvcd = ins__cust_no_dvcd;
		}
		public String[] getIns__cust_no() {
			return ins__cust_no;
		}
		public void setIns__cust_no(String[] ins__cust_no) {
			this.ins__cust_no = ins__cust_no;
		}
		public String[] getIns__cust_nm() {
			return ins__cust_nm;
		}
		public void setIns__cust_nm(String[] ins__cust_nm) {
			this.ins__cust_nm = ins__cust_nm;
		}
		public String[] getIns__psco_dvcd() {
			return ins__psco_dvcd;
		}
		public void setIns__psco_dvcd(String[] ins__psco_dvcd) {
			this.ins__psco_dvcd = ins__psco_dvcd;
		}
		public String[] getIns__copr_regt_no() {
			return ins__copr_regt_no;
		}
		public void setIns__copr_regt_no(String[] ins__copr_regt_no) {
			this.ins__copr_regt_no = ins__copr_regt_no;
		}
		public String[] getIns__nwod_adr_dvcd() {
			return ins__nwod_adr_dvcd;
		}
		public void setIns__nwod_adr_dvcd(String[] ins__nwod_adr_dvcd) {
			this.ins__nwod_adr_dvcd = ins__nwod_adr_dvcd;
		}
		public String[] getIns__iage() {
			return ins__iage;
		}
		public void setIns__iage(String[] ins__iage) {
			this.ins__iage = ins__iage;
		}
		public String[] getIns__cntp_dvcd() {
			return ins__cntp_dvcd;
		}
		public void setIns__cntp_dvcd(String[] ins__cntp_dvcd) {
			this.ins__cntp_dvcd = ins__cntp_dvcd;
		}
		public String[] getIns__eml() {
			return ins__eml;
		}
		public void setIns__eml(String[] ins__eml) {
			this.ins__eml = ins__eml;
		}
		public String[] getIns__at_ins_tpcd() {
			return ins__at_ins_tpcd;
		}
		public void setIns__at_ins_tpcd(String[] ins__at_ins_tpcd) {
			this.ins__at_ins_tpcd = ins__at_ins_tpcd;
		}
		public String[] getIns_adr_if__cntp_dvcd() {
			return ins_adr_if__cntp_dvcd;
		}
		public void setIns_adr_if__cntp_dvcd(String[] ins_adr_if__cntp_dvcd) {
			this.ins_adr_if__cntp_dvcd = ins_adr_if__cntp_dvcd;
		}
		public String[] getIns_adr_if__nwod_adr_dvcd() {
			return ins_adr_if__nwod_adr_dvcd;
		}
		public void setIns_adr_if__nwod_adr_dvcd(String[] ins_adr_if__nwod_adr_dvcd) {
			this.ins_adr_if__nwod_adr_dvcd = ins_adr_if__nwod_adr_dvcd;
		}
		public String[] getIns_adr_if__psno() {
			return ins_adr_if__psno;
		}
		public void setIns_adr_if__psno(String[] ins_adr_if__psno) {
			this.ins_adr_if__psno = ins_adr_if__psno;
		}
		public String[] getIns_adr_if__pst_adr() {
			return ins_adr_if__pst_adr;
		}
		public void setIns_adr_if__pst_adr(String[] ins_adr_if__pst_adr) {
			this.ins_adr_if__pst_adr = ins_adr_if__pst_adr;
		}
		public String[] getIns_adr_if__eta_adr() {
			return ins_adr_if__eta_adr;
		}
		public void setIns_adr_if__eta_adr(String[] ins_adr_if__eta_adr) {
			this.ins_adr_if__eta_adr = ins_adr_if__eta_adr;
		}
		public String[] getIns_cntp_if__cntp_dvcd() {
			return ins_cntp_if__cntp_dvcd;
		}
		public void setIns_cntp_if__cntp_dvcd(String[] ins_cntp_if__cntp_dvcd) {
			this.ins_cntp_if__cntp_dvcd = ins_cntp_if__cntp_dvcd;
		}
		public String[] getIns_cntp_if__tlp_arno() {
			return ins_cntp_if__tlp_arno;
		}
		public void setIns_cntp_if__tlp_arno(String[] ins_cntp_if__tlp_arno) {
			this.ins_cntp_if__tlp_arno = ins_cntp_if__tlp_arno;
		}
		public String[] getIns_cntp_if__tlp_ofno() {
			return ins_cntp_if__tlp_ofno;
		}
		public void setIns_cntp_if__tlp_ofno(String[] ins_cntp_if__tlp_ofno) {
			this.ins_cntp_if__tlp_ofno = ins_cntp_if__tlp_ofno;
		}
		public String[] getIns_cntp_if__tlp_idvno() {
			return ins_cntp_if__tlp_idvno;
		}
		public void setIns_cntp_if__tlp_idvno(String[] ins_cntp_if__tlp_idvno) {
			this.ins_cntp_if__tlp_idvno = ins_cntp_if__tlp_idvno;
		}
		public String getJob_cd() {
			return job_cd;
		}
		public void setJob_cd(String job_cd) {
			this.job_cd = job_cd;
		}
		public String getJob_nm() {
			return job_nm;
		}
		public void setJob_nm(String job_nm) {
			this.job_nm = job_nm;
		}
		public String getOprn_usge_cd() {
			return oprn_usge_cd;
		}
		public void setOprn_usge_cd(String oprn_usge_cd) {
			this.oprn_usge_cd = oprn_usge_cd;
		}
		public String getOprn_usge_nm() {
			return oprn_usge_nm;
		}
		public void setOprn_usge_nm(String oprn_usge_nm) {
			this.oprn_usge_nm = oprn_usge_nm;
		}
		public String getWedd_yn() {
			return wedd_yn;
		}
		public void setWedd_yn(String wedd_yn) {
			this.wedd_yn = wedd_yn;
		}
		public String[] getDrvr__cust_dcmt_no() {
			return drvr__cust_dcmt_no;
		}
		public void setDrvr__cust_dcmt_no(String[] drvr__cust_dcmt_no) {
			this.drvr__cust_dcmt_no = drvr__cust_dcmt_no;
		}
		public String[] getDrvr__cust_no_dvcd() {
			return drvr__cust_no_dvcd;
		}
		public void setDrvr__cust_no_dvcd(String[] drvr__cust_no_dvcd) {
			this.drvr__cust_no_dvcd = drvr__cust_no_dvcd;
		}
		public String[] getDrvr__cust_no() {
			return drvr__cust_no;
		}
		public void setDrvr__cust_no(String[] drvr__cust_no) {
			this.drvr__cust_no = drvr__cust_no;
		}
		public String[] getDrvr__cust_nm() {
			return drvr__cust_nm;
		}
		public void setDrvr__cust_nm(String[] drvr__cust_nm) {
			this.drvr__cust_nm = drvr__cust_nm;
		}
		public String[] getDrvr__iage() {
			return drvr__iage;
		}
		public void setDrvr__iage(String[] drvr__iage) {
			this.drvr__iage = drvr__iage;
		}
		public String[] getDrvr__ins_rlt_cd() {
			return drvr__ins_rlt_cd;
		}
		public void setDrvr__ins_rlt_cd(String[] drvr__ins_rlt_cd) {
			this.drvr__ins_rlt_cd = drvr__ins_rlt_cd;
		}
		public String[] getPlhd__cust_dcmt_no() {
			return plhd__cust_dcmt_no;
		}
		public void setPlhd__cust_dcmt_no(String[] plhd__cust_dcmt_no) {
			this.plhd__cust_dcmt_no = plhd__cust_dcmt_no;
		}
		public String[] getPlhd__cust_no_dvcd() {
			return plhd__cust_no_dvcd;
		}
		public void setPlhd__cust_no_dvcd(String[] plhd__cust_no_dvcd) {
			this.plhd__cust_no_dvcd = plhd__cust_no_dvcd;
		}
		public String[] getPlhd__cust_no() {
			return plhd__cust_no;
		}
		public void setPlhd__cust_no(String[] plhd__cust_no) {
			this.plhd__cust_no = plhd__cust_no;
		}
		public String[] getPlhd__cust_nm() {
			return plhd__cust_nm;
		}
		public void setPlhd__cust_nm(String[] plhd__cust_nm) {
			this.plhd__cust_nm = plhd__cust_nm;
		}
		public String[] getPlhd__nwod_adr_dvcd() {
			return plhd__nwod_adr_dvcd;
		}
		public void setPlhd__nwod_adr_dvcd(String[] plhd__nwod_adr_dvcd) {
			this.plhd__nwod_adr_dvcd = plhd__nwod_adr_dvcd;
		}
		public String[] getPlhd__eml() {
			return plhd__eml;
		}
		public void setPlhd__eml(String[] plhd__eml) {
			this.plhd__eml = plhd__eml;
		}
		public String[] getPlhd__cntp_dvcd() {
			return plhd__cntp_dvcd;
		}
		public void setPlhd__cntp_dvcd(String[] plhd__cntp_dvcd) {
			this.plhd__cntp_dvcd = plhd__cntp_dvcd;
		}
		public String[] getPlhd_adr_if__cntp_dvcd() {
			return plhd_adr_if__cntp_dvcd;
		}
		public void setPlhd_adr_if__cntp_dvcd(String[] plhd_adr_if__cntp_dvcd) {
			this.plhd_adr_if__cntp_dvcd = plhd_adr_if__cntp_dvcd;
		}
		public String[] getPlhd_adr_if__nwod_adr_dvcd() {
			return plhd_adr_if__nwod_adr_dvcd;
		}
		public void setPlhd_adr_if__nwod_adr_dvcd(String[] plhd_adr_if__nwod_adr_dvcd) {
			this.plhd_adr_if__nwod_adr_dvcd = plhd_adr_if__nwod_adr_dvcd;
		}
		public String[] getPlhd_adr_if__psno() {
			return plhd_adr_if__psno;
		}
		public void setPlhd_adr_if__psno(String[] plhd_adr_if__psno) {
			this.plhd_adr_if__psno = plhd_adr_if__psno;
		}
		public String[] getPlhd_adr_if__pst_adr() {
			return plhd_adr_if__pst_adr;
		}
		public void setPlhd_adr_if__pst_adr(String[] plhd_adr_if__pst_adr) {
			this.plhd_adr_if__pst_adr = plhd_adr_if__pst_adr;
		}
		public String[] getPlhd_adr_if__eta_adr() {
			return plhd_adr_if__eta_adr;
		}
		public void setPlhd_adr_if__eta_adr(String[] plhd_adr_if__eta_adr) {
			this.plhd_adr_if__eta_adr = plhd_adr_if__eta_adr;
		}
		public String[] getPlhd_cntp_if__cntp_dvcd() {
			return plhd_cntp_if__cntp_dvcd;
		}
		public void setPlhd_cntp_if__cntp_dvcd(String[] plhd_cntp_if__cntp_dvcd) {
			this.plhd_cntp_if__cntp_dvcd = plhd_cntp_if__cntp_dvcd;
		}
		public String[] getPlhd_cntp_if__tlp_arno() {
			return plhd_cntp_if__tlp_arno;
		}
		public void setPlhd_cntp_if__tlp_arno(String[] plhd_cntp_if__tlp_arno) {
			this.plhd_cntp_if__tlp_arno = plhd_cntp_if__tlp_arno;
		}
		public String[] getPlhd_cntp_if__tlp_ofno() {
			return plhd_cntp_if__tlp_ofno;
		}
		public void setPlhd_cntp_if__tlp_ofno(String[] plhd_cntp_if__tlp_ofno) {
			this.plhd_cntp_if__tlp_ofno = plhd_cntp_if__tlp_ofno;
		}
		public String[] getPlhd_cntp_if__tlp_idvno() {
			return plhd_cntp_if__tlp_idvno;
		}
		public void setPlhd_cntp_if__tlp_idvno(String[] plhd_cntp_if__tlp_idvno) {
			this.plhd_cntp_if__tlp_idvno = plhd_cntp_if__tlp_idvno;
		}
		public String[] getLwt_tago__cust_dcmt_no() {
			return lwt_tago__cust_dcmt_no;
		}
		public void setLwt_tago__cust_dcmt_no(String[] lwt_tago__cust_dcmt_no) {
			this.lwt_tago__cust_dcmt_no = lwt_tago__cust_dcmt_no;
		}
		public String[] getLwt_tago__cust_no_dvcd() {
			return lwt_tago__cust_no_dvcd;
		}
		public void setLwt_tago__cust_no_dvcd(String[] lwt_tago__cust_no_dvcd) {
			this.lwt_tago__cust_no_dvcd = lwt_tago__cust_no_dvcd;
		}
		public String[] getLwt_tago__cust_no() {
			return lwt_tago__cust_no;
		}
		public void setLwt_tago__cust_no(String[] lwt_tago__cust_no) {
			this.lwt_tago__cust_no = lwt_tago__cust_no;
		}
		public String[] getLwt_tago__cust_nm() {
			return lwt_tago__cust_nm;
		}
		public void setLwt_tago__cust_nm(String[] lwt_tago__cust_nm) {
			this.lwt_tago__cust_nm = lwt_tago__cust_nm;
		}
		public String[] getLwt_tago__iage() {
			return lwt_tago__iage;
		}
		public void setLwt_tago__iage(String[] lwt_tago__iage) {
			this.lwt_tago__iage = lwt_tago__iage;
		}
		public String[] getLwt_tago__ins_rlt_cd() {
			return lwt_tago__ins_rlt_cd;
		}
		public void setLwt_tago__ins_rlt_cd(String[] lwt_tago__ins_rlt_cd) {
			this.lwt_tago__ins_rlt_cd = lwt_tago__ins_rlt_cd;
		}
		public String[] getBnfc__cust_dcmt_no() {
			return bnfc__cust_dcmt_no;
		}
		public void setBnfc__cust_dcmt_no(String[] bnfc__cust_dcmt_no) {
			this.bnfc__cust_dcmt_no = bnfc__cust_dcmt_no;
		}
		public String[] getBnfc__cust_nm() {
			return bnfc__cust_nm;
		}
		public void setBnfc__cust_nm(String[] bnfc__cust_nm) {
			this.bnfc__cust_nm = bnfc__cust_nm;
		}
		public String[] getBnfc__ins_rlt_cd() {
			return bnfc__ins_rlt_cd;
		}
		public void setBnfc__ins_rlt_cd(String[] bnfc__ins_rlt_cd) {
			this.bnfc__ins_rlt_cd = bnfc__ins_rlt_cd;
		}
		public String[] getBnfc__nwod_adr_dvcd() {
			return bnfc__nwod_adr_dvcd;
		}
		public void setBnfc__nwod_adr_dvcd(String[] bnfc__nwod_adr_dvcd) {
			this.bnfc__nwod_adr_dvcd = bnfc__nwod_adr_dvcd;
		}
		public String[] getBnfc_adr_if__cntp_dvcd() {
			return bnfc_adr_if__cntp_dvcd;
		}
		public void setBnfc_adr_if__cntp_dvcd(String[] bnfc_adr_if__cntp_dvcd) {
			this.bnfc_adr_if__cntp_dvcd = bnfc_adr_if__cntp_dvcd;
		}
		public String[] getBnfc_adr_if__nwod_adr_dvcd() {
			return bnfc_adr_if__nwod_adr_dvcd;
		}
		public void setBnfc_adr_if__nwod_adr_dvcd(String[] bnfc_adr_if__nwod_adr_dvcd) {
			this.bnfc_adr_if__nwod_adr_dvcd = bnfc_adr_if__nwod_adr_dvcd;
		}
		public String[] getBnfc_adr_if__psno() {
			return bnfc_adr_if__psno;
		}
		public void setBnfc_adr_if__psno(String[] bnfc_adr_if__psno) {
			this.bnfc_adr_if__psno = bnfc_adr_if__psno;
		}
		public String[] getBnfc_adr_if__pst_adr() {
			return bnfc_adr_if__pst_adr;
		}
		public void setBnfc_adr_if__pst_adr(String[] bnfc_adr_if__pst_adr) {
			this.bnfc_adr_if__pst_adr = bnfc_adr_if__pst_adr;
		}
		public String[] getBnfc_adr_if__eta_adr() {
			return bnfc_adr_if__eta_adr;
		}
		public void setBnfc_adr_if__eta_adr(String[] bnfc_adr_if__eta_adr) {
			this.bnfc_adr_if__eta_adr = bnfc_adr_if__eta_adr;
		}
		public String[] getBnfc_cntp_if__cntp_dvcd() {
			return bnfc_cntp_if__cntp_dvcd;
		}
		public void setBnfc_cntp_if__cntp_dvcd(String[] bnfc_cntp_if__cntp_dvcd) {
			this.bnfc_cntp_if__cntp_dvcd = bnfc_cntp_if__cntp_dvcd;
		}
		public String[] getBnfc_cntp_if__tlp_arno() {
			return bnfc_cntp_if__tlp_arno;
		}
		public void setBnfc_cntp_if__tlp_arno(String[] bnfc_cntp_if__tlp_arno) {
			this.bnfc_cntp_if__tlp_arno = bnfc_cntp_if__tlp_arno;
		}
		public String[] getBnfc_cntp_if__tlp_ofno() {
			return bnfc_cntp_if__tlp_ofno;
		}
		public void setBnfc_cntp_if__tlp_ofno(String[] bnfc_cntp_if__tlp_ofno) {
			this.bnfc_cntp_if__tlp_ofno = bnfc_cntp_if__tlp_ofno;
		}
		public String[] getBnfc_cntp_if__tlp_idvno() {
			return bnfc_cntp_if__tlp_idvno;
		}
		public void setBnfc_cntp_if__tlp_idvno(String[] bnfc_cntp_if__tlp_idvno) {
			this.bnfc_cntp_if__tlp_idvno = bnfc_cntp_if__tlp_idvno;
		}
		public String getHngl_vh_no() {
			return hngl_vh_no;
		}
		public void setHngl_vh_no(String hngl_vh_no) {
			this.hngl_vh_no = hngl_vh_no;
		}
		public String getVh_ocd() {
			return vh_ocd;
		}
		public void setVh_ocd(String vh_ocd) {
			this.vh_ocd = vh_ocd;
		}
		public String getVh_no() {
			return vh_no;
		}
		public void setVh_no(String vh_no) {
			this.vh_no = vh_no;
		}
		public String getVh_usge_cd() {
			return vh_usge_cd;
		}
		public void setVh_usge_cd(String vh_usge_cd) {
			this.vh_usge_cd = vh_usge_cd;
		}
		public String getVh_use_usge_cd() {
			return vh_use_usge_cd;
		}
		public void setVh_use_usge_cd(String vh_use_usge_cd) {
			this.vh_use_usge_cd = vh_use_usge_cd;
		}
		public String getCtp_cd() {
			return ctp_cd;
		}
		public void setCtp_cd(String ctp_cd) {
			this.ctp_cd = ctp_cd;
		}
		public String getCtp_nm() {
			return ctp_nm;
		}
		public void setCtp_nm(String ctp_nm) {
			this.ctp_nm = ctp_nm;
		}
		public String getCrnm_cd() {
			return crnm_cd;
		}
		public void setCrnm_cd(String crnm_cd) {
			this.crnm_cd = crnm_cd;
		}
		public String getCrnm_cd_hngl_nm() {
			return crnm_cd_hngl_nm;
		}
		public void setCrnm_cd_hngl_nm(String crnm_cd_hngl_nm) {
			this.crnm_cd_hngl_nm = crnm_cd_hngl_nm;
		}
		public String getVh_pyy() {
			return vh_pyy;
		}
		public void setVh_pyy(String vh_pyy) {
			this.vh_pyy = vh_pyy;
		}
		public String getPyy_dvcd() {
			return pyy_dvcd;
		}
		public void setPyy_dvcd(String pyy_dvcd) {
			this.pyy_dvcd = pyy_dvcd;
		}
		public String getDspl() {
			return dspl;
		}
		public void setDspl(String dspl) {
			this.dspl = dspl;
		}
		public String getLd_tns() {
			return ld_tns;
		}
		public void setLd_tns(String ld_tns) {
			this.ld_tns = ld_tns;
		}
		public String getCpct_cnt() {
			return cpct_cnt;
		}
		public void setCpct_cnt(String cpct_cnt) {
			this.cpct_cnt = cpct_cnt;
		}
		public String getCbdy_no_dvcd() {
			return cbdy_no_dvcd;
		}
		public void setCbdy_no_dvcd(String cbdy_no_dvcd) {
			this.cbdy_no_dvcd = cbdy_no_dvcd;
		}
		public String getCbdy_no() {
			return cbdy_no;
		}
		public void setCbdy_no(String cbdy_no) {
			this.cbdy_no = cbdy_no;
		}
		public String getCpnt_tot_invl() {
			return cpnt_tot_invl;
		}
		public void setCpnt_tot_invl(String cpnt_tot_invl) {
			this.cpnt_tot_invl = cpnt_tot_invl;
		}
		public String getMach_eqp_invl() {
			return mach_eqp_invl;
		}
		public void setMach_eqp_invl(String mach_eqp_invl) {
			this.mach_eqp_invl = mach_eqp_invl;
		}
		public String getVh_vae() {
			return vh_vae;
		}
		public void setVh_vae(String vh_vae) {
			this.vh_vae = vh_vae;
		}
		public String getVh_tot_vae() {
			return vh_tot_vae;
		}
		public void setVh_tot_vae(String vh_tot_vae) {
			this.vh_tot_vae = vh_tot_vae;
		}
		public String getNca_rt() {
			return nca_rt;
		}
		public void setNca_rt(String nca_rt) {
			this.nca_rt = nca_rt;
		}
		public String getUcr_rt() {
			return ucr_rt;
		}
		public void setUcr_rt(String ucr_rt) {
			this.ucr_rt = ucr_rt;
		}
		public String getDvry_oj_use_dvcd() {
			return dvry_oj_use_dvcd;
		}
		public void setDvry_oj_use_dvcd(String dvry_oj_use_dvcd) {
			this.dvry_oj_use_dvcd = dvry_oj_use_dvcd;
		}
		public String getAiba_damg_qnty_dvcd() {
			return aiba_damg_qnty_dvcd;
		}
		public void setAiba_damg_qnty_dvcd(String aiba_damg_qnty_dvcd) {
			this.aiba_damg_qnty_dvcd = aiba_damg_qnty_dvcd;
		}
		public String getVh_temp_dvcd() {
			return vh_temp_dvcd;
		}
		public void setVh_temp_dvcd(String vh_temp_dvcd) {
			this.vh_temp_dvcd = vh_temp_dvcd;
		}
		public String getVh_regt_dt() {
			return vh_regt_dt;
		}
		public void setVh_regt_dt(String vh_regt_dt) {
			this.vh_regt_dt = vh_regt_dt;
		}
		public String getApcn_trt_eny_carr_rt() {
			return apcn_trt_eny_carr_rt;
		}
		public void setApcn_trt_eny_carr_rt(String apcn_trt_eny_carr_rt) {
			this.apcn_trt_eny_carr_rt = apcn_trt_eny_carr_rt;
		}
		public String getApcn_trt_rglt_vlt_rt() {
			return apcn_trt_rglt_vlt_rt;
		}
		public void setApcn_trt_rglt_vlt_rt(String apcn_trt_rglt_vlt_rt) {
			this.apcn_trt_rglt_vlt_rt = apcn_trt_rglt_vlt_rt;
		}
		public String getChng_af_fac_ssrt_chrc_trt_sm() {
			return chng_af_fac_ssrt_chrc_trt_sm;
		}
		public void setChng_af_fac_ssrt_chrc_trt_sm(String chng_af_fac_ssrt_chrc_trt_sm) {
			this.chng_af_fac_ssrt_chrc_trt_sm = chng_af_fac_ssrt_chrc_trt_sm;
		}
		public String getApcn_trt_dst_xtr_rt() {
			return apcn_trt_dst_xtr_rt;
		}
		public void setApcn_trt_dst_xtr_rt(String apcn_trt_dst_xtr_rt) {
			this.apcn_trt_dst_xtr_rt = apcn_trt_dst_xtr_rt;
		}
		public String getApcn_trt_spc_xtr_rt() {
			return apcn_trt_spc_xtr_rt;
		}
		public void setApcn_trt_spc_xtr_rt(String apcn_trt_spc_xtr_rt) {
			this.apcn_trt_spc_xtr_rt = apcn_trt_spc_xtr_rt;
		}
		public String getApcn_trt_spc_xtr_cd() {
			return apcn_trt_spc_xtr_cd;
		}
		public void setApcn_trt_spc_xtr_cd(String apcn_trt_spc_xtr_cd) {
			this.apcn_trt_spc_xtr_cd = apcn_trt_spc_xtr_cd;
		}
		public String getMky_tptn_use_shp_cd() {
			return mky_tptn_use_shp_cd;
		}
		public void setMky_tptn_use_shp_cd(String mky_tptn_use_shp_cd) {
			this.mky_tptn_use_shp_cd = mky_tptn_use_shp_cd;
		}
		public String getShtm_rt() {
			return shtm_rt;
		}
		public void setShtm_rt(String shtm_rt) {
			this.shtm_rt = shtm_rt;
		}
		public String getApcn_trt_dysy_vlt_cd() {
			return apcn_trt_dysy_vlt_cd;
		}
		public void setApcn_trt_dysy_vlt_cd(String apcn_trt_dysy_vlt_cd) {
			this.apcn_trt_dysy_vlt_cd = apcn_trt_dysy_vlt_cd;
		}
		public String getDysy_vlt_rt() {
			return dysy_vlt_rt;
		}
		public void setDysy_vlt_rt(String dysy_vlt_rt) {
			this.dysy_vlt_rt = dysy_vlt_rt;
		}
		public String getAg_tty_aut_chng_tgt_yn() {
			return ag_tty_aut_chng_tgt_yn;
		}
		public void setAg_tty_aut_chng_tgt_yn(String ag_tty_aut_chng_tgt_yn) {
			this.ag_tty_aut_chng_tgt_yn = ag_tty_aut_chng_tgt_yn;
		}
		public String getAg_tty_aut_chng_bse_dd() {
			return ag_tty_aut_chng_bse_dd;
		}
		public void setAg_tty_aut_chng_bse_dd(String ag_tty_aut_chng_bse_dd) {
			this.ag_tty_aut_chng_bse_dd = ag_tty_aut_chng_bse_dd;
		}
		public String getAg_chng_trgm_dcmt_no() {
			return ag_chng_trgm_dcmt_no;
		}
		public void setAg_chng_trgm_dcmt_no(String ag_chng_trgm_dcmt_no) {
			this.ag_chng_trgm_dcmt_no = ag_chng_trgm_dcmt_no;
		}
		public String getAg_chng_trgm_nm() {
			return ag_chng_trgm_nm;
		}
		public void setAg_chng_trgm_nm(String ag_chng_trgm_nm) {
			this.ag_chng_trgm_nm = ag_chng_trgm_nm;
		}
		public String getMtl_accd_xtr_amt_cd() {
			return mtl_accd_xtr_amt_cd;
		}
		public void setMtl_accd_xtr_amt_cd(String mtl_accd_xtr_amt_cd) {
			this.mtl_accd_xtr_amt_cd = mtl_accd_xtr_amt_cd;
		}
		public String getAg_tty_aut_chng_tty_cd() {
			return ag_tty_aut_chng_tty_cd;
		}
		public void setAg_tty_aut_chng_tty_cd(String ag_tty_aut_chng_tty_cd) {
			this.ag_tty_aut_chng_tty_cd = ag_tty_aut_chng_tty_cd;
		}
		public String getAg_tty_aut_chng_tty_trt() {
			return ag_tty_aut_chng_tty_trt;
		}
		public void setAg_tty_aut_chng_tty_trt(String ag_tty_aut_chng_tty_trt) {
			this.ag_tty_aut_chng_tty_trt = ag_tty_aut_chng_tty_trt;
		}
		public String[] getEny_tty_spc_if__tty_spc_trt_dvcd() {
			return eny_tty_spc_if__tty_spc_trt_dvcd;
		}
		public void setEny_tty_spc_if__tty_spc_trt_dvcd(
				String[] eny_tty_spc_if__tty_spc_trt_dvcd) {
			this.eny_tty_spc_if__tty_spc_trt_dvcd = eny_tty_spc_if__tty_spc_trt_dvcd;
		}
		public String[] getEny_tty_spc_if__cd() {
			return eny_tty_spc_if__cd;
		}
		public void setEny_tty_spc_if__cd(String[] eny_tty_spc_if__cd) {
			this.eny_tty_spc_if__cd = eny_tty_spc_if__cd;
		}
		public String[] getEny_tty_spc_if__dsn() {
			return eny_tty_spc_if__dsn;
		}
		public void setEny_tty_spc_if__dsn(String[] eny_tty_spc_if__dsn) {
			this.eny_tty_spc_if__dsn = eny_tty_spc_if__dsn;
		}
		public String[] getEny_tty_spc_if__at_apcn_trt() {
			return eny_tty_spc_if__at_apcn_trt;
		}
		public void setEny_tty_spc_if__at_apcn_trt(String[] eny_tty_spc_if__at_apcn_trt) {
			this.eny_tty_spc_if__at_apcn_trt = eny_tty_spc_if__at_apcn_trt;
		}
		public String[] getEny_tty_spc_if__apcn_gr_val() {
			return eny_tty_spc_if__apcn_gr_val;
		}
		public void setEny_tty_spc_if__apcn_gr_val(String[] eny_tty_spc_if__apcn_gr_val) {
			this.eny_tty_spc_if__apcn_gr_val = eny_tty_spc_if__apcn_gr_val;
		}
		public String[] getEny_tty_spc_if__tty_spc_grp_cd() {
			return eny_tty_spc_if__tty_spc_grp_cd;
		}
		public void setEny_tty_spc_if__tty_spc_grp_cd(
				String[] eny_tty_spc_if__tty_spc_grp_cd) {
			this.eny_tty_spc_if__tty_spc_grp_cd = eny_tty_spc_if__tty_spc_grp_cd;
		}
		public String[] getEny_tty_spc_if__updt_pss_yn() {
			return eny_tty_spc_if__updt_pss_yn;
		}
		public void setEny_tty_spc_if__updt_pss_yn(String[] eny_tty_spc_if__updt_pss_yn) {
			this.eny_tty_spc_if__updt_pss_yn = eny_tty_spc_if__updt_pss_yn;
		}
		public String[] getEny_cvr_if__cd() {
			return eny_cvr_if__cd;
		}
		public void setEny_cvr_if__cd(String[] eny_cvr_if__cd) {
			this.eny_cvr_if__cd = eny_cvr_if__cd;
		}
		public String[] getEny_cvr_if__ctc_cvr_dvcd() {
			return eny_cvr_if__ctc_cvr_dvcd;
		}
		public void setEny_cvr_if__ctc_cvr_dvcd(String[] eny_cvr_if__ctc_cvr_dvcd) {
			this.eny_cvr_if__ctc_cvr_dvcd = eny_cvr_if__ctc_cvr_dvcd;
		}
		public String[] getEny_cvr_if__dsn() {
			return eny_cvr_if__dsn;
		}
		public void setEny_cvr_if__dsn(String[] eny_cvr_if__dsn) {
			this.eny_cvr_if__dsn = eny_cvr_if__dsn;
		}
		public String[] getEny_cvr_if__bsc_cvr_cd() {
			return eny_cvr_if__bsc_cvr_cd;
		}
		public void setEny_cvr_if__bsc_cvr_cd(String[] eny_cvr_if__bsc_cvr_cd) {
			this.eny_cvr_if__bsc_cvr_cd = eny_cvr_if__bsc_cvr_cd;
		}
		public String[] getEny_cvr_if__tty_rt() {
			return eny_cvr_if__tty_rt;
		}
		public void setEny_cvr_if__tty_rt(String[] eny_cvr_if__tty_rt) {
			this.eny_cvr_if__tty_rt = eny_cvr_if__tty_rt;
		}
		public String[] getEny_cvr_if__spc_rt() {
			return eny_cvr_if__spc_rt;
		}
		public void setEny_cvr_if__spc_rt(String[] eny_cvr_if__spc_rt) {
			this.eny_cvr_if__spc_rt = eny_cvr_if__spc_rt;
		}
		public String[] getEny_cvr_if__ind_bsc_rnge_rt() {
			return eny_cvr_if__ind_bsc_rnge_rt;
		}
		public void setEny_cvr_if__ind_bsc_rnge_rt(String[] eny_cvr_if__ind_bsc_rnge_rt) {
			this.eny_cvr_if__ind_bsc_rnge_rt = eny_cvr_if__ind_bsc_rnge_rt;
		}
		public String[] getEny_cvr_if__scy_bsc_rnge_rt() {
			return eny_cvr_if__scy_bsc_rnge_rt;
		}
		public void setEny_cvr_if__scy_bsc_rnge_rt(String[] eny_cvr_if__scy_bsc_rnge_rt) {
			this.eny_cvr_if__scy_bsc_rnge_rt = eny_cvr_if__scy_bsc_rnge_rt;
		}
		public String[] getEny_cvr_if__apcn_bsc_rnge_rt() {
			return eny_cvr_if__apcn_bsc_rnge_rt;
		}
		public void setEny_cvr_if__apcn_bsc_rnge_rt(
				String[] eny_cvr_if__apcn_bsc_rnge_rt) {
			this.eny_cvr_if__apcn_bsc_rnge_rt = eny_cvr_if__apcn_bsc_rnge_rt;
		}
		public String[] getEny_cvr_if__inam_cd() {
			return eny_cvr_if__inam_cd;
		}
		public void setEny_cvr_if__inam_cd(String[] eny_cvr_if__inam_cd) {
			this.eny_cvr_if__inam_cd = eny_cvr_if__inam_cd;
		}
		public String[] getEny_cvr_if__inam() {
			return eny_cvr_if__inam;
		}
		public void setEny_cvr_if__inam(String[] eny_cvr_if__inam) {
			this.eny_cvr_if__inam = eny_cvr_if__inam;
		}
		public String[] getEny_cvr_if__dct_amt_cd() {
			return eny_cvr_if__dct_amt_cd;
		}
		public void setEny_cvr_if__dct_amt_cd(String[] eny_cvr_if__dct_amt_cd) {
			this.eny_cvr_if__dct_amt_cd = eny_cvr_if__dct_amt_cd;
		}
		public String[] getEny_cvr_if__dct_rt() {
			return eny_cvr_if__dct_rt;
		}
		public void setEny_cvr_if__dct_rt(String[] eny_cvr_if__dct_rt) {
			this.eny_cvr_if__dct_rt = eny_cvr_if__dct_rt;
		}
		public String[] getEny_cvr_if__at_bsc_prm() {
			return eny_cvr_if__at_bsc_prm;
		}
		public void setEny_cvr_if__at_bsc_prm(String[] eny_cvr_if__at_bsc_prm) {
			this.eny_cvr_if__at_bsc_prm = eny_cvr_if__at_bsc_prm;
		}
		public String[] getEny_cvr_if__at_apcn_prm() {
			return eny_cvr_if__at_apcn_prm;
		}
		public void setEny_cvr_if__at_apcn_prm(String[] eny_cvr_if__at_apcn_prm) {
			this.eny_cvr_if__at_apcn_prm = eny_cvr_if__at_apcn_prm;
		}
		public String[] getEny_cvr_if__at_fnal_apcn_prm() {
			return eny_cvr_if__at_fnal_apcn_prm;
		}
		public void setEny_cvr_if__at_fnal_apcn_prm(
				String[] eny_cvr_if__at_fnal_apcn_prm) {
			this.eny_cvr_if__at_fnal_apcn_prm = eny_cvr_if__at_fnal_apcn_prm;
		}
		public String[] getEny_cvr_if__sym_impr_prv_fnal_apcn_prm() {
			return eny_cvr_if__sym_impr_prv_fnal_apcn_prm;
		}
		public void setEny_cvr_if__sym_impr_prv_fnal_apcn_prm(
				String[] eny_cvr_if__sym_impr_prv_fnal_apcn_prm) {
			this.eny_cvr_if__sym_impr_prv_fnal_apcn_prm = eny_cvr_if__sym_impr_prv_fnal_apcn_prm;
		}
		public String[] getEny_cvr_if__sym_impr_af_fnal_apcn_prm() {
			return eny_cvr_if__sym_impr_af_fnal_apcn_prm;
		}
		public void setEny_cvr_if__sym_impr_af_fnal_apcn_prm(
				String[] eny_cvr_if__sym_impr_af_fnal_apcn_prm) {
			this.eny_cvr_if__sym_impr_af_fnal_apcn_prm = eny_cvr_if__sym_impr_af_fnal_apcn_prm;
		}
		public String[] getEny_cvr_if__cvr_stat_cd() {
			return eny_cvr_if__cvr_stat_cd;
		}
		public void setEny_cvr_if__cvr_stat_cd(String[] eny_cvr_if__cvr_stat_cd) {
			this.eny_cvr_if__cvr_stat_cd = eny_cvr_if__cvr_stat_cd;
		}
		public String[] getEny_cvr_if__cvr_stat_cd_nm() {
			return eny_cvr_if__cvr_stat_cd_nm;
		}
		public void setEny_cvr_if__cvr_stat_cd_nm(String[] eny_cvr_if__cvr_stat_cd_nm) {
			this.eny_cvr_if__cvr_stat_cd_nm = eny_cvr_if__cvr_stat_cd_nm;
		}
		public String[] getEny_cvr_if__cvr_trm_str_dt() {
			return eny_cvr_if__cvr_trm_str_dt;
		}
		public void setEny_cvr_if__cvr_trm_str_dt(String[] eny_cvr_if__cvr_trm_str_dt) {
			this.eny_cvr_if__cvr_trm_str_dt = eny_cvr_if__cvr_trm_str_dt;
		}
		public String[] getEny_cvr_if__cvr_trm_fin_dt() {
			return eny_cvr_if__cvr_trm_fin_dt;
		}
		public void setEny_cvr_if__cvr_trm_fin_dt(String[] eny_cvr_if__cvr_trm_fin_dt) {
			this.eny_cvr_if__cvr_trm_fin_dt = eny_cvr_if__cvr_trm_fin_dt;
		}
		public String[] getEny_cvr_if__cvr_id() {
			return eny_cvr_if__cvr_id;
		}
		public void setEny_cvr_if__cvr_id(String[] eny_cvr_if__cvr_id) {
			this.eny_cvr_if__cvr_id = eny_cvr_if__cvr_id;
		}
		public String[] getEny_cvr_if__updt_pss_yn() {
			return eny_cvr_if__updt_pss_yn;
		}
		public void setEny_cvr_if__updt_pss_yn(String[] eny_cvr_if__updt_pss_yn) {
			this.eny_cvr_if__updt_pss_yn = eny_cvr_if__updt_pss_yn;
		}
		public String[] getPcg__cd() {
			return pcg__cd;
		}
		public void setPcg__cd(String[] pcg__cd) {
			this.pcg__cd = pcg__cd;
		}
		public String[] getPcg__dsn() {
			return pcg__dsn;
		}
		public void setPcg__dsn(String[] pcg__dsn) {
			this.pcg__dsn = pcg__dsn;
		}
		public String[] getPcg__use_pss_yn() {
			return pcg__use_pss_yn;
		}
		public void setPcg__use_pss_yn(String[] pcg__use_pss_yn) {
			this.pcg__use_pss_yn = pcg__use_pss_yn;
		}
		public String[] getRcwc_epct__rcwc_orr() {
			return rcwc_epct__rcwc_orr;
		}
		public void setRcwc_epct__rcwc_orr(String[] rcwc_epct__rcwc_orr) {
			this.rcwc_epct__rcwc_orr = rcwc_epct__rcwc_orr;
		}
		public String[] getRcwc_epct__nstl_epct_prm() {
			return rcwc_epct__nstl_epct_prm;
		}
		public void setRcwc_epct__nstl_epct_prm(String[] rcwc_epct__nstl_epct_prm) {
			this.rcwc_epct__nstl_epct_prm = rcwc_epct__nstl_epct_prm;
		}
		public String getEltc_yn() {
			return eltc_yn;
		}
		public void setEltc_yn(String eltc_yn) {
			this.eltc_yn = eltc_yn;
		}
		public String getOty() {
			return oty;
		}
		public void setOty(String oty) {
			this.oty = oty;
		}
		public String getDysy_dvcd() {
			return dysy_dvcd;
		}
		public void setDysy_dvcd(String dysy_dvcd) {
			this.dysy_dvcd = dysy_dvcd;
		}
		public String[] getCmp_prm__fsti_prm() {
			return cmp_prm__fsti_prm;
		}
		public void setCmp_prm__fsti_prm(String[] cmp_prm__fsti_prm) {
			this.cmp_prm__fsti_prm = cmp_prm__fsti_prm;
		}
		public String[] getCmp_prm__nstl_prm() {
			return cmp_prm__nstl_prm;
		}
		public void setCmp_prm__nstl_prm(String[] cmp_prm__nstl_prm) {
			this.cmp_prm__nstl_prm = cmp_prm__nstl_prm;
		}
		public String[] getCmp_prm__tot_prm() {
			return cmp_prm__tot_prm;
		}
		public void setCmp_prm__tot_prm(String[] cmp_prm__tot_prm) {
			this.cmp_prm__tot_prm = cmp_prm__tot_prm;
		}
		public String[] getCmp_prm__cltd_prm() {
			return cmp_prm__cltd_prm;
		}
		public void setCmp_prm__cltd_prm(String[] cmp_prm__cltd_prm) {
			this.cmp_prm__cltd_prm = cmp_prm__cltd_prm;
		}
		public String getDst_xtr_vlut_accd_cnum() {
			return dst_xtr_vlut_accd_cnum;
		}
		public void setDst_xtr_vlut_accd_cnum(String dst_xtr_vlut_accd_cnum) {
			this.dst_xtr_vlut_accd_cnum = dst_xtr_vlut_accd_cnum;
		}
		public String getApcn_prm_fac_sm() {
			return apcn_prm_fac_sm;
		}
		public void setApcn_prm_fac_sm(String apcn_prm_fac_sm) {
			this.apcn_prm_fac_sm = apcn_prm_fac_sm;
		}
		public String getApcn_prm_lbl_sm() {
			return apcn_prm_lbl_sm;
		}
		public void setApcn_prm_lbl_sm(String apcn_prm_lbl_sm) {
			this.apcn_prm_lbl_sm = apcn_prm_lbl_sm;
		}
		public String getArc_eny_carr_ycnt() {
			return arc_eny_carr_ycnt;
		}
		public void setArc_eny_carr_ycnt(String arc_eny_carr_ycnt) {
			this.arc_eny_carr_ycnt = arc_eny_carr_ycnt;
		}
		public String getArc_eny_carr_mcnt() {
			return arc_eny_carr_mcnt;
		}
		public void setArc_eny_carr_mcnt(String arc_eny_carr_mcnt) {
			this.arc_eny_carr_mcnt = arc_eny_carr_mcnt;
		}
		public String getArc_eny_carr_dcnt() {
			return arc_eny_carr_dcnt;
		}
		public void setArc_eny_carr_dcnt(String arc_eny_carr_dcnt) {
			this.arc_eny_carr_dcnt = arc_eny_carr_dcnt;
		}
		public String getScy_eny_yn() {
			return scy_eny_yn;
		}
		public void setScy_eny_yn(String scy_eny_yn) {
			this.scy_eny_yn = scy_eny_yn;
		}
		public String getDst_xtr_dvcd() {
			return dst_xtr_dvcd;
		}
		public void setDst_xtr_dvcd(String dst_xtr_dvcd) {
			this.dst_xtr_dvcd = dst_xtr_dvcd;
		}
		public String getAsg_obj_yn() {
			return asg_obj_yn;
		}
		public void setAsg_obj_yn(String asg_obj_yn) {
			this.asg_obj_yn = asg_obj_yn;
		}
		public String getVlut_tgt_str_dt() {
			return vlut_tgt_str_dt;
		}
		public void setVlut_tgt_str_dt(String vlut_tgt_str_dt) {
			this.vlut_tgt_str_dt = vlut_tgt_str_dt;
		}
		public String getVlut_tgt_fin_dt() {
			return vlut_tgt_fin_dt;
		}
		public void setVlut_tgt_fin_dt(String vlut_tgt_fin_dt) {
			this.vlut_tgt_fin_dt = vlut_tgt_fin_dt;
		}
		public String getPast_f3yr_vlut_tgt_str_dt() {
			return past_f3yr_vlut_tgt_str_dt;
		}
		public void setPast_f3yr_vlut_tgt_str_dt(String past_f3yr_vlut_tgt_str_dt) {
			this.past_f3yr_vlut_tgt_str_dt = past_f3yr_vlut_tgt_str_dt;
		}
		public String getPast_f3yr_vlut_tgt_fin_dt() {
			return past_f3yr_vlut_tgt_fin_dt;
		}
		public void setPast_f3yr_vlut_tgt_fin_dt(String past_f3yr_vlut_tgt_fin_dt) {
			this.past_f3yr_vlut_tgt_fin_dt = past_f3yr_vlut_tgt_fin_dt;
		}
		public String getTot_accd_cnum() {
			return tot_accd_cnum;
		}
		public void setTot_accd_cnum(String tot_accd_cnum) {
			this.tot_accd_cnum = tot_accd_cnum;
		}
		public String getDst_xtr_vlut_accd_pnt() {
			return dst_xtr_vlut_accd_pnt;
		}
		public void setDst_xtr_vlut_accd_pnt(String dst_xtr_vlut_accd_pnt) {
			this.dst_xtr_vlut_accd_pnt = dst_xtr_vlut_accd_pnt;
		}
		public String getPast_f3yr_accd_cnum() {
			return past_f3yr_accd_cnum;
		}
		public void setPast_f3yr_accd_cnum(String past_f3yr_accd_cnum) {
			this.past_f3yr_accd_cnum = past_f3yr_accd_cnum;
		}
		public String getPrv_iscp_cd() {
			return prv_iscp_cd;
		}
		public void setPrv_iscp_cd(String prv_iscp_cd) {
			this.prv_iscp_cd = prv_iscp_cd;
		}
		public String getPrv_plno() {
			return prv_plno;
		}
		public void setPrv_plno(String prv_plno) {
			this.prv_plno = prv_plno;
		}
		public String getStdd_dst_xtr_rt() {
			return stdd_dst_xtr_rt;
		}
		public void setStdd_dst_xtr_rt(String stdd_dst_xtr_rt) {
			this.stdd_dst_xtr_rt = stdd_dst_xtr_rt;
		}
		public String getSpc_xtr_rt() {
			return spc_xtr_rt;
		}
		public void setSpc_xtr_rt(String spc_xtr_rt) {
			this.spc_xtr_rt = spc_xtr_rt;
		}
		public String getSpc_xtr_cd() {
			return spc_xtr_cd;
		}
		public void setSpc_xtr_cd(String spc_xtr_cd) {
			this.spc_xtr_cd = spc_xtr_cd;
		}
		public String getEny_carr_rt() {
			return eny_carr_rt;
		}
		public void setEny_carr_rt(String eny_carr_rt) {
			this.eny_carr_rt = eny_carr_rt;
		}
		public String getRglt_vlt_rt() {
			return rglt_vlt_rt;
		}
		public void setRglt_vlt_rt(String rglt_vlt_rt) {
			this.rglt_vlt_rt = rglt_vlt_rt;
		}
		public String getChng_prv_fac_ssrt_chrc_trt_sm() {
			return chng_prv_fac_ssrt_chrc_trt_sm;
		}
		public void setChng_prv_fac_ssrt_chrc_trt_sm(
				String chng_prv_fac_ssrt_chrc_trt_sm) {
			this.chng_prv_fac_ssrt_chrc_trt_sm = chng_prv_fac_ssrt_chrc_trt_sm;
		}
		public String getEt_eqal_yn() {
			return et_eqal_yn;
		}
		public void setEt_eqal_yn(String et_eqal_yn) {
			this.et_eqal_yn = et_eqal_yn;
		}
		public String getPan_tpcd() {
			return pan_tpcd;
		}
		public void setPan_tpcd(String pan_tpcd) {
			this.pan_tpcd = pan_tpcd;
		}
		public String getChn_cd() {
			return chn_cd;
		}
		public void setChn_cd(String chn_cd) {
			this.chn_cd = chn_cd;
		}
		public String getBsc_equp_eqp_cd() {
			return bsc_equp_eqp_cd;
		}
		public void setBsc_equp_eqp_cd(String bsc_equp_eqp_cd) {
			this.bsc_equp_eqp_cd = bsc_equp_eqp_cd;
		}
		public String getBsc_equp_eqp_cd_nm() {
			return bsc_equp_eqp_cd_nm;
		}
		public void setBsc_equp_eqp_cd_nm(String bsc_equp_eqp_cd_nm) {
			this.bsc_equp_eqp_cd_nm = bsc_equp_eqp_cd_nm;
		}
		public String getApcn_trt_dst_xtr_cd() {
			return apcn_trt_dst_xtr_cd;
		}
		public void setApcn_trt_dst_xtr_cd(String apcn_trt_dst_xtr_cd) {
			this.apcn_trt_dst_xtr_cd = apcn_trt_dst_xtr_cd;
		}
		public String getStdd_dst_xtr_grcd() {
			return stdd_dst_xtr_grcd;
		}
		public void setStdd_dst_xtr_grcd(String stdd_dst_xtr_grcd) {
			this.stdd_dst_xtr_grcd = stdd_dst_xtr_grcd;
		}
		public String getVh_mode_each_gr_cd() {
			return vh_mode_each_gr_cd;
		}
		public void setVh_mode_each_gr_cd(String vh_mode_each_gr_cd) {
			this.vh_mode_each_gr_cd = vh_mode_each_gr_cd;
		}
		public String getVh_mode_each_gr_aprt() {
			return vh_mode_each_gr_aprt;
		}
		public void setVh_mode_each_gr_aprt(String vh_mode_each_gr_aprt) {
			this.vh_mode_each_gr_aprt = vh_mode_each_gr_aprt;
		}
		public String getFrst_trv_dstc() {
			return frst_trv_dstc;
		}
		public void setFrst_trv_dstc(String frst_trv_dstc) {
			this.frst_trv_dstc = frst_trv_dstc;
		}
		public String getYy_avg_trv_dstc() {
			return yy_avg_trv_dstc;
		}
		public void setYy_avg_trv_dstc(String yy_avg_trv_dstc) {
			this.yy_avg_trv_dstc = yy_avg_trv_dstc;
		}
		public String getCtt_trv_dstc_cd() {
			return ctt_trv_dstc_cd;
		}
		public void setCtt_trv_dstc_cd(String ctt_trv_dstc_cd) {
			this.ctt_trv_dstc_cd = ctt_trv_dstc_cd;
		}
		public String getTrv_dstc_tty_dst_rt() {
			return trv_dstc_tty_dst_rt;
		}
		public void setTrv_dstc_tty_dst_rt(String trv_dstc_tty_dst_rt) {
			this.trv_dstc_tty_dst_rt = trv_dstc_tty_dst_rt;
		}
		public String getTrv_dstc_tty_dst_amt() {
			return trv_dstc_tty_dst_amt;
		}
		public void setTrv_dstc_tty_dst_amt(String trv_dstc_tty_dst_amt) {
			this.trv_dstc_tty_dst_amt = trv_dstc_tty_dst_amt;
		}
		public String getVh_vae_updt_rs_cd() {
			return vh_vae_updt_rs_cd;
		}
		public void setVh_vae_updt_rs_cd(String vh_vae_updt_rs_cd) {
			this.vh_vae_updt_rs_cd = vh_vae_updt_rs_cd;
		}
		public String getBlbo_dvn() {
			return blbo_dvn;
		}
		public void setBlbo_dvn(String blbo_dvn) {
			this.blbo_dvn = blbo_dvn;
		}
		public String getVh_eqp_mafr_nm() {
			return vh_eqp_mafr_nm;
		}
		public void setVh_eqp_mafr_nm(String vh_eqp_mafr_nm) {
			this.vh_eqp_mafr_nm = vh_eqp_mafr_nm;
		}
		public String getVh_eqp_gds_nm() {
			return vh_eqp_gds_nm;
		}
		public void setVh_eqp_gds_nm(String vh_eqp_gds_nm) {
			this.vh_eqp_gds_nm = vh_eqp_gds_nm;
		}
		public String getVh_eqp_mode_nm() {
			return vh_eqp_mode_nm;
		}
		public void setVh_eqp_mode_nm(String vh_eqp_mode_nm) {
			this.vh_eqp_mode_nm = vh_eqp_mode_nm;
		}
		public String getOwnr_dcdc_dvcd() {
			return ownr_dcdc_dvcd;
		}
		public void setOwnr_dcdc_dvcd(String ownr_dcdc_dvcd) {
			this.ownr_dcdc_dvcd = ownr_dcdc_dvcd;
		}
		public String getOwnr_dcdc_cust_dcmt_no() {
			return ownr_dcdc_cust_dcmt_no;
		}
		public void setOwnr_dcdc_cust_dcmt_no(String ownr_dcdc_cust_dcmt_no) {
			this.ownr_dcdc_cust_dcmt_no = ownr_dcdc_cust_dcmt_no;
		}
		public String getOwnr_dcdc_cust_no() {
			return ownr_dcdc_cust_no;
		}
		public void setOwnr_dcdc_cust_no(String ownr_dcdc_cust_no) {
			this.ownr_dcdc_cust_no = ownr_dcdc_cust_no;
		}
		public String getOwnr_dcdc_cust_nm() {
			return ownr_dcdc_cust_nm;
		}
		public void setOwnr_dcdc_cust_nm(String ownr_dcdc_cust_nm) {
			this.ownr_dcdc_cust_nm = ownr_dcdc_cust_nm;
		}
		public String getIns_rlt_cd() {
			return ins_rlt_cd;
		}
		public void setIns_rlt_cd(String ins_rlt_cd) {
			this.ins_rlt_cd = ins_rlt_cd;
		}
		public String getDcdc_rs() {
			return dcdc_rs;
		}
		public void setDcdc_rs(String dcdc_rs) {
			this.dcdc_rs = dcdc_rs;
		}
		public String[] getAdd_cpnt__cd() {
			return add_cpnt__cd;
		}
		public void setAdd_cpnt__cd(String[] add_cpnt__cd) {
			this.add_cpnt__cd = add_cpnt__cd;
		}
		public String[] getAdd_cpnt__dsn() {
			return add_cpnt__dsn;
		}
		public void setAdd_cpnt__dsn(String[] add_cpnt__dsn) {
			this.add_cpnt__dsn = add_cpnt__dsn;
		}
		public String[] getAdd_cpnt__vae() {
			return add_cpnt__vae;
		}
		public void setAdd_cpnt__vae(String[] add_cpnt__vae) {
			this.add_cpnt__vae = add_cpnt__vae;
		}
		public String[] getEcvr_bz_rcwc__sl_cvr_cd() {
			return ecvr_bz_rcwc__sl_cvr_cd;
		}
		public void setEcvr_bz_rcwc__sl_cvr_cd(String[] ecvr_bz_rcwc__sl_cvr_cd) {
			this.ecvr_bz_rcwc__sl_cvr_cd = ecvr_bz_rcwc__sl_cvr_cd;
		}
		public String[] getEcvr_bz_rcwc__cvr_each_prm() {
			return ecvr_bz_rcwc__cvr_each_prm;
		}
		public void setEcvr_bz_rcwc__cvr_each_prm(String[] ecvr_bz_rcwc__cvr_each_prm) {
			this.ecvr_bz_rcwc__cvr_each_prm = ecvr_bz_rcwc__cvr_each_prm;
		}
		
		/**
		 * @return the sbt_drvr_cust_dcmt_no
		 */
		public String getSbt_drvr_cust_dcmt_no() {
			return sbt_drvr_cust_dcmt_no;
		}
		/**
		 * @param sbt_drvr_cust_dcmt_no the sbt_drvr_cust_dcmt_no to set
		 */
		public void setSbt_drvr_cust_dcmt_no(String sbt_drvr_cust_dcmt_no) {
			this.sbt_drvr_cust_dcmt_no = sbt_drvr_cust_dcmt_no;
		}
		/**
		 * @return the sbt_drve_trdr_plhd_csn_yn
		 */
		public String getSbt_drve_trdr_plhd_csn_yn() {
			return sbt_drve_trdr_plhd_csn_yn;
		}
		/**
		 * @param sbt_drve_trdr_plhd_csn_yn the sbt_drve_trdr_plhd_csn_yn to set
		 */
		public void setSbt_drve_trdr_plhd_csn_yn(String sbt_drve_trdr_plhd_csn_yn) {
			this.sbt_drve_trdr_plhd_csn_yn = sbt_drve_trdr_plhd_csn_yn;
		}
		/**
		 * @return the sbt_drvr_apcn_prm
		 */
		public String getSbt_drvr_apcn_prm() {
			return sbt_drvr_apcn_prm;
		}
		/**
		 * @param sbt_drvr_apcn_prm the sbt_drvr_apcn_prm to set
		 */
		public void setSbt_drvr_apcn_prm(String sbt_drvr_apcn_prm) {
			this.sbt_drvr_apcn_prm = sbt_drvr_apcn_prm;
		}
		/**
		 * @return the accd_mtt
		 */
		public String getAccd_mtt() {
			return accd_mtt;
		}
		/**
		 * @param accd_mtt the accd_mtt to set
		 */
		public void setAccd_mtt(String accd_mtt) {
			this.accd_mtt = accd_mtt;
		}
		/**
		 * @return the ctrmf_nts
		 */
		public String getCtrmf_nts() {
			return ctrmf_nts;
		}
		/**
		 * @param ctrmf_nts the ctrmf_nts to set
		 */
		public void setCtrmf_nts(String ctrmf_nts) {
			this.ctrmf_nts = ctrmf_nts;
		}
		
}
