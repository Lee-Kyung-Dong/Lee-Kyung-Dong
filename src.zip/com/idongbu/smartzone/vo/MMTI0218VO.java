package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class MMTI0218VO extends CMMVO{
	
	public String mbl_snd_no = "";											// [I/O] 모바일발송번호
	public String plan_plno_dvcd = "";										// [I/O] 설계증권번호구분코드: 1 설계번호, 2 증권번호
	public String plan_plno = "";											// [I/O] 설계증권번호
	public String chng_plan_no = "";										// [I/O] 변경설계번호
	public String[] phgp_regt_tgt__dst_tty_dvn = new String[0];				// [O] 할인특약구분: 01 주행거리, 02 블랙박스, 03 베이비인카, 04 차선이탈, 05 전방충돌
	public String[] phgp_regt_tgt__phgp_regt_cplt_yn = new String[0];		// [O] 사진등록완료여부: 1 등록, 0 미등록
	
	public String z_resp_msg = "";
	public String z_resp_cd = "";
	public String z_tlg_sp_cd = "";
	public String z_trns_org_cd = "";
	public String z_trns_org_dvcd = "";
	public String z_trsc_id = "";
	
	
	public String getMbl_snd_no() {
		return mbl_snd_no;
	}
	public void setMbl_snd_no(String mbl_snd_no) {
		this.mbl_snd_no = mbl_snd_no;
	}
	public String getPlan_plno_dvcd() {
		return plan_plno_dvcd;
	}
	public void setPlan_plno_dvcd(String plan_plno_dvcd) {
		this.plan_plno_dvcd = plan_plno_dvcd;
	}
	public String getPlan_plno() {
		return plan_plno;
	}
	public void setPlan_plno(String plan_plno) {
		this.plan_plno = plan_plno;
	}
	public String getChng_plan_no() {
		return chng_plan_no;
	}
	public void setChng_plan_no(String chng_plan_no) {
		this.chng_plan_no = chng_plan_no;
	}
	public String[] getPhgp_regt_tgt__dst_tty_dvn() {
		return phgp_regt_tgt__dst_tty_dvn;
	}
	public void setPhgp_regt_tgt__dst_tty_dvn(String[] phgp_regt_tgt__dst_tty_dvn) {
		this.phgp_regt_tgt__dst_tty_dvn = phgp_regt_tgt__dst_tty_dvn;
	}
	public String[] getPhgp_regt_tgt__phgp_regt_cplt_yn() {
		return phgp_regt_tgt__phgp_regt_cplt_yn;
	}
	public void setPhgp_regt_tgt__phgp_regt_cplt_yn(String[] phgp_regt_tgt__phgp_regt_cplt_yn) {
		this.phgp_regt_tgt__phgp_regt_cplt_yn = phgp_regt_tgt__phgp_regt_cplt_yn;
	}
	public String getZ_resp_msg() {
		return z_resp_msg;
	}
	public void setZ_resp_msg(String z_resp_msg) {
		this.z_resp_msg = z_resp_msg;
	}
	public String getZ_resp_cd() {
		return z_resp_cd;
	}
	public void setZ_resp_cd(String z_resp_cd) {
		this.z_resp_cd = z_resp_cd;
	}
	public String getZ_tlg_sp_cd() {
		return z_tlg_sp_cd;
	}
	public void setZ_tlg_sp_cd(String z_tlg_sp_cd) {
		this.z_tlg_sp_cd = z_tlg_sp_cd;
	}
	public String getZ_trns_org_cd() {
		return z_trns_org_cd;
	}
	public void setZ_trns_org_cd(String z_trns_org_cd) {
		this.z_trns_org_cd = z_trns_org_cd;
	}
	public String getZ_trns_org_dvcd() {
		return z_trns_org_dvcd;
	}
	public void setZ_trns_org_dvcd(String z_trns_org_dvcd) {
		this.z_trns_org_dvcd = z_trns_org_dvcd;
	}
	public String getZ_trsc_id() {
		return z_trsc_id;
	}
	public void setZ_trsc_id(String z_trsc_id) {
		this.z_trsc_id = z_trsc_id;
	}
	
}
