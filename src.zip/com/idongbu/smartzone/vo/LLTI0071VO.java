package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class LLTI0071VO extends CMMVO{
	//전문필드
		public String plno = "";  //[I] 증권번호 JJ_POLI_NO 증권번호
		public String ins_lcpl_dvcd = "";  //[I/O] 피보험자소재지구분코드  
		public String ply_sqno = "";  //[I/O] 증권일련번호  
		public String ctrmf_sqno = "";  //[I] 계약변경일련번호 JJ_BESU_SEQ 배서순번
		public String ctrmf_no = "";  //[I] 계약변경번호 JJ_BESU_NUM 배서번호
		public String ctc_id = "";  //[O] 계약ID  
		public String pdc_cd = "";  //[O] 상품코드 JJ_BJ_CD 보종코드
		public String inpd_nm = "";  //[O] 보종명 HJ_BJ_NAME 보종명
		public String pdc_dvn = "";  //[O] 상품구분 HJ_BJ_GBN 보종구분
		public String at_oprt_nm = "";  //[O] 자동차운행명 HJ_CAR_UNHENG_NM 운전여부
		public String obj_dvn = "";  //[O] 물건구분 HJ_MULGUN_GUBUN 흡연여부
		public String mtcc_inj_ncvr = "";  //[O] 이륜차상해부담보 HJ_SANGHE_CD15 이륜차상해부담보
		public String spcf_prtn_cvr_trm_1 = "";  //[O] 특정부위담보기간1 HJ_TUKJU_GIGAN1 특정부위담보기간1
		public String spcf_prtn_cvr_trm_2 = "";  //[O] 특정부위담보기간2 HJ_TUKJU_GIGAN2 특정부위담보기간2
		public String spcf_prtn_cvr_nm_1 = "";  //[O] 특정부위담보명1 HJ_TUKJU_1 특정부위담보명1
		public String spcf_prtn_cvr_nm_2 = "";  //[O] 특정부위담보명2 HJ_TUKJU_2 특정부위담보명2
		public String spcf_prtn_cvr_trm_3 = "";  //[O] 특정부위담보기간3 HJ_TUKJU_GIGAN3 특정부위담보기간3
		public String spcf_prtn_cvr_trm_4 = "";  //[O] 특정부위담보기간4 HJ_TUKJU_GIGAN4 특정부위담보기간4
		public String spcf_prtn_cvr_nm_3 = "";  //[O] 특정부위담보명3 HJ_TUKJU_1 특정부위담보명3
		public String spcf_prtn_cvr_nm_4 = "";  //[O] 특정부위담보명4 HJ_TUKJU_2 특정부위담보명4
		public String xtr_gr_nm = "";  //[O] 할증등급명 HJ_HAL_CODE_NM 할증등급명
		public String prm = "";  //[O] 보험료 JJ_HAL_PRM 보험료
		public String[] cvr_if__cvr_dvn = new String[0];  //[O] 담보정보_담보구분 HJ_DAMBO_GUN 담보구분
		public String[] cvr_if__cvr_nm = new String[0];  //[O] 담보정보_담보명 HJ_DAMBO_NAME 담보명
		public String[] cvr_if__pytr_dvcd = new String[0];  //[O] 담보정보_납기구분코드  
		public String[] cvr_if__pytr_val = new String[0];  //[O] 담보정보_납기값  
		public String[] cvr_if__exp_dvcd = new String[0];  //[O] 담보정보_만기구분코드  
		public String[] cvr_if__exp_val = new String[0];  //[O] 담보정보_만기값  
		public String[] cvr_if__cvr_cd = new String[0];  //[O] 담보정보_담보코드 JJ-DAMBO-CD 담보코드
		public String[] cvr_if__inam = new String[0];  //[O] 담보정보_가입금액 JJ_GAIP_GMEK 가입금액
		public String[] cvr_if__bsc_prm = new String[0];  //[O] 담보정보_기본보험료 JJ_GIBON_PRM 기본보험료
		public String[] cvr_if__arc_str_dt = new String[0];  //[O] 담보정보_보험시작일자 JJ_BOHUM_GIGAN_SYMD 보험시작일
		public String[] cvr_if__arc_fin_dt = new String[0];  //[O] 담보정보_보험종료일자 JJ_BOHUM_GIGAN_EYMD 보험종료일
		public String[] cvr_if__cvr_pym_ym = new String[0];  //[O] 담보정보_담보납입년월 JJ_DAMBO_LNAPIP_YM 담보납입년월
		public String[] cvr_if__spc_cdnl_xtr_gr_nm = new String[0];  //[O] 담보정보_특별조건부할증등급명 JJ-BIGO 특별조건부할증등급명
		public String kpn_plno = "";  //[O] 보관증권번호 UU_POLI_NO 증권번호
		public String kpn_ins_lcpl_dvcd = "";  //[O] 보관피보험자소재지구분코드  
		public String kpn_ply_sqno = "";  //[O] 보관증권일련번호  
		public String kpn_ctrmf_no = "";  //[O] 보관계약변경번호 UU_BESU_SEQ 배서번호
		public String kpn_ins_nm = "";  //[O] 보관피보험자명 UU_PI_NAME 피보험자명
		
		public String errorCode = "";  // 에러코드
		
		
		
		
		public String getPlno() {
			return plno;
		}
		public void setPlno(String plno) {
			this.plno = plno;
		}
		public String getIns_lcpl_dvcd() {
			return ins_lcpl_dvcd;
		}
		public void setIns_lcpl_dvcd(String ins_lcpl_dvcd) {
			this.ins_lcpl_dvcd = ins_lcpl_dvcd;
		}
		public String getPly_sqno() {
			return ply_sqno;
		}
		public void setPly_sqno(String ply_sqno) {
			this.ply_sqno = ply_sqno;
		}
		public String getCtrmf_sqno() {
			return ctrmf_sqno;
		}
		public void setCtrmf_sqno(String ctrmf_sqno) {
			this.ctrmf_sqno = ctrmf_sqno;
		}
		public String getCtrmf_no() {
			return ctrmf_no;
		}
		public void setCtrmf_no(String ctrmf_no) {
			this.ctrmf_no = ctrmf_no;
		}
		public String getCtc_id() {
			return ctc_id;
		}
		public void setCtc_id(String ctc_id) {
			this.ctc_id = ctc_id;
		}
		public String getPdc_cd() {
			return pdc_cd;
		}
		public void setPdc_cd(String pdc_cd) {
			this.pdc_cd = pdc_cd;
		}
		public String getInpd_nm() {
			return inpd_nm;
		}
		public void setInpd_nm(String inpd_nm) {
			this.inpd_nm = inpd_nm;
		}
		public String getPdc_dvn() {
			return pdc_dvn;
		}
		public void setPdc_dvn(String pdc_dvn) {
			this.pdc_dvn = pdc_dvn;
		}
		public String getAt_oprt_nm() {
			return at_oprt_nm;
		}
		public void setAt_oprt_nm(String at_oprt_nm) {
			this.at_oprt_nm = at_oprt_nm;
		}
		public String getObj_dvn() {
			return obj_dvn;
		}
		public void setObj_dvn(String obj_dvn) {
			this.obj_dvn = obj_dvn;
		}
		public String getMtcc_inj_ncvr() {
			return mtcc_inj_ncvr;
		}
		public void setMtcc_inj_ncvr(String mtcc_inj_ncvr) {
			this.mtcc_inj_ncvr = mtcc_inj_ncvr;
		}
		public String getSpcf_prtn_cvr_trm_1() {
			return spcf_prtn_cvr_trm_1;
		}
		public void setSpcf_prtn_cvr_trm_1(String spcf_prtn_cvr_trm_1) {
			this.spcf_prtn_cvr_trm_1 = spcf_prtn_cvr_trm_1;
		}
		public String getSpcf_prtn_cvr_trm_2() {
			return spcf_prtn_cvr_trm_2;
		}
		public void setSpcf_prtn_cvr_trm_2(String spcf_prtn_cvr_trm_2) {
			this.spcf_prtn_cvr_trm_2 = spcf_prtn_cvr_trm_2;
		}
		public String getSpcf_prtn_cvr_nm_1() {
			return spcf_prtn_cvr_nm_1;
		}
		public void setSpcf_prtn_cvr_nm_1(String spcf_prtn_cvr_nm_1) {
			this.spcf_prtn_cvr_nm_1 = spcf_prtn_cvr_nm_1;
		}
		public String getSpcf_prtn_cvr_nm_2() {
			return spcf_prtn_cvr_nm_2;
		}
		public void setSpcf_prtn_cvr_nm_2(String spcf_prtn_cvr_nm_2) {
			this.spcf_prtn_cvr_nm_2 = spcf_prtn_cvr_nm_2;
		}
		public String getSpcf_prtn_cvr_trm_3() {
			return spcf_prtn_cvr_trm_3;
		}
		public void setSpcf_prtn_cvr_trm_3(String spcf_prtn_cvr_trm_3) {
			this.spcf_prtn_cvr_trm_3 = spcf_prtn_cvr_trm_3;
		}
		public String getSpcf_prtn_cvr_trm_4() {
			return spcf_prtn_cvr_trm_4;
		}
		public void setSpcf_prtn_cvr_trm_4(String spcf_prtn_cvr_trm_4) {
			this.spcf_prtn_cvr_trm_4 = spcf_prtn_cvr_trm_4;
		}
		public String getSpcf_prtn_cvr_nm_3() {
			return spcf_prtn_cvr_nm_3;
		}
		public void setSpcf_prtn_cvr_nm_3(String spcf_prtn_cvr_nm_3) {
			this.spcf_prtn_cvr_nm_3 = spcf_prtn_cvr_nm_3;
		}
		public String getSpcf_prtn_cvr_nm_4() {
			return spcf_prtn_cvr_nm_4;
		}
		public void setSpcf_prtn_cvr_nm_4(String spcf_prtn_cvr_nm_4) {
			this.spcf_prtn_cvr_nm_4 = spcf_prtn_cvr_nm_4;
		}
		public String getXtr_gr_nm() {
			return xtr_gr_nm;
		}
		public void setXtr_gr_nm(String xtr_gr_nm) {
			this.xtr_gr_nm = xtr_gr_nm;
		}
		public String getPrm() {
			return prm;
		}
		public void setPrm(String prm) {
			this.prm = prm;
		}
		public String[] getCvr_if__cvr_dvn() {
			return cvr_if__cvr_dvn;
		}
		public void setCvr_if__cvr_dvn(String[] cvr_if__cvr_dvn) {
			this.cvr_if__cvr_dvn = cvr_if__cvr_dvn;
		}
		public String[] getCvr_if__cvr_nm() {
			return cvr_if__cvr_nm;
		}
		public void setCvr_if__cvr_nm(String[] cvr_if__cvr_nm) {
			this.cvr_if__cvr_nm = cvr_if__cvr_nm;
		}
		public String[] getCvr_if__pytr_dvcd() {
			return cvr_if__pytr_dvcd;
		}
		public void setCvr_if__pytr_dvcd(String[] cvr_if__pytr_dvcd) {
			this.cvr_if__pytr_dvcd = cvr_if__pytr_dvcd;
		}
		public String[] getCvr_if__pytr_val() {
			return cvr_if__pytr_val;
		}
		public void setCvr_if__pytr_val(String[] cvr_if__pytr_val) {
			this.cvr_if__pytr_val = cvr_if__pytr_val;
		}
		public String[] getCvr_if__exp_dvcd() {
			return cvr_if__exp_dvcd;
		}
		public void setCvr_if__exp_dvcd(String[] cvr_if__exp_dvcd) {
			this.cvr_if__exp_dvcd = cvr_if__exp_dvcd;
		}
		public String[] getCvr_if__exp_val() {
			return cvr_if__exp_val;
		}
		public void setCvr_if__exp_val(String[] cvr_if__exp_val) {
			this.cvr_if__exp_val = cvr_if__exp_val;
		}
		public String[] getCvr_if__cvr_cd() {
			return cvr_if__cvr_cd;
		}
		public void setCvr_if__cvr_cd(String[] cvr_if__cvr_cd) {
			this.cvr_if__cvr_cd = cvr_if__cvr_cd;
		}
		public String[] getCvr_if__inam() {
			return cvr_if__inam;
		}
		public void setCvr_if__inam(String[] cvr_if__inam) {
			this.cvr_if__inam = cvr_if__inam;
		}
		public String[] getCvr_if__bsc_prm() {
			return cvr_if__bsc_prm;
		}
		public void setCvr_if__bsc_prm(String[] cvr_if__bsc_prm) {
			this.cvr_if__bsc_prm = cvr_if__bsc_prm;
		}
		public String[] getCvr_if__arc_str_dt() {
			return cvr_if__arc_str_dt;
		}
		public void setCvr_if__arc_str_dt(String[] cvr_if__arc_str_dt) {
			this.cvr_if__arc_str_dt = cvr_if__arc_str_dt;
		}
		public String[] getCvr_if__arc_fin_dt() {
			return cvr_if__arc_fin_dt;
		}
		public void setCvr_if__arc_fin_dt(String[] cvr_if__arc_fin_dt) {
			this.cvr_if__arc_fin_dt = cvr_if__arc_fin_dt;
		}
		public String[] getCvr_if__cvr_pym_ym() {
			return cvr_if__cvr_pym_ym;
		}
		public void setCvr_if__cvr_pym_ym(String[] cvr_if__cvr_pym_ym) {
			this.cvr_if__cvr_pym_ym = cvr_if__cvr_pym_ym;
		}
		public String[] getCvr_if__spc_cdnl_xtr_gr_nm() {
			return cvr_if__spc_cdnl_xtr_gr_nm;
		}
		public void setCvr_if__spc_cdnl_xtr_gr_nm(String[] cvr_if__spc_cdnl_xtr_gr_nm) {
			this.cvr_if__spc_cdnl_xtr_gr_nm = cvr_if__spc_cdnl_xtr_gr_nm;
		}
		public String getKpn_plno() {
			return kpn_plno;
		}
		public void setKpn_plno(String kpn_plno) {
			this.kpn_plno = kpn_plno;
		}
		public String getKpn_ins_lcpl_dvcd() {
			return kpn_ins_lcpl_dvcd;
		}
		public void setKpn_ins_lcpl_dvcd(String kpn_ins_lcpl_dvcd) {
			this.kpn_ins_lcpl_dvcd = kpn_ins_lcpl_dvcd;
		}
		public String getKpn_ply_sqno() {
			return kpn_ply_sqno;
		}
		public void setKpn_ply_sqno(String kpn_ply_sqno) {
			this.kpn_ply_sqno = kpn_ply_sqno;
		}
		public String getKpn_ctrmf_no() {
			return kpn_ctrmf_no;
		}
		public void setKpn_ctrmf_no(String kpn_ctrmf_no) {
			this.kpn_ctrmf_no = kpn_ctrmf_no;
		}
		public String getKpn_ins_nm() {
			return kpn_ins_nm;
		}
		public void setKpn_ins_nm(String kpn_ins_nm) {
			this.kpn_ins_nm = kpn_ins_nm;
		}
		
		

}
