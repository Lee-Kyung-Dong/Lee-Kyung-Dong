package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class KCUS0005VO extends CMMVO{
	
	public String cust_dcmt_no = "";  //[I] 고객식별번호 SCR_BM0044_KEY_GOGEK_NO 고객번호
	public String bse_yy = "";  //[I] 기준년 SCR_BM0044_KEY_GIJUN_YY 기준년
	public String cust_nm = "";  //[O] 고객명 H_SCR_BM0044_GOGEK_NAME 고객명
	public String rsdn_no = "";  //[O] 주민번호 SCR_BM0044_GOGEK_JUMIN_NO 주민번호
	public String psno = "";  //[O] 우편번호 SCR_BM0044_GOGEK_ZIP 우편번호
	public String psno_nm = "";  //[O] 우편번호명 H_SCR_BM0044_GOGEK_ZIP_NAME 우편번호명
	public String eta_adr = "";  //[O] 기타주소 H_SCR_BM0044_GOGEK_GITA 기타주소
	public String[] ars_pym_crtf_isu_at__plno = new String[0];  //[O] 자동차납입증명목록_자보증권번호 SCR_BM0044_JABO_POLI_NO 증권번호
	public String[] ars_pym_crtf_isu_at__ins_nm = new String[0];  //[O] 자동차납입증명목록_자보피보험자명 H_SCR_BM0044_JABO_PIBO_NM 피보험자명
	public String[] ars_pym_crtf_isu_at__ins_rlt = new String[0];  //[O] 자동차납입증명목록_자보피보험자관계 H_SCR_BM0044_JABO_GWANGYE 피보험자관계
	public String[] ars_pym_crtf_isu_at__inpd_cd = new String[0];  //[O] 자동차납입증명목록_자보보종코드 SCR_BM0044_JABO_BJ_CD 보종코드
	public String[] ars_pym_crtf_isu_at__inpd_nm = new String[0];  //[O] 자동차납입증명목록_자보보종명 H_SCR_BM0044_JABO_BJ_NM 보종명
	public String[] ars_pym_crtf_isu_at__pym_mtd_cd = new String[0];  //[O] 자동차납입증명목록_자보납입방법코드 SCR_BM0044_JABO_NAPBANG 납입방법코드
	public String[] ars_pym_crtf_isu_at__pym_mtd_nm = new String[0];  //[O] 자동차납입증명목록_자보납입방법명 H_SCR_BM0044_JABO_NAPBANG_NM 납입방법명
	public String[] ars_pym_crtf_isu_at__fnal_pym_ym = new String[0];  //[O] 자동차납입증명목록_자보최종납입년월 SCR_BM0044_JABO_LAST_YM 최종납입년월
	public String[] ars_pym_crtf_isu_at__pym_nts = new String[0];  //[O] 자동차납입증명목록_자보납입횟수 SCR_BM0044_JABO_NAPIP_CNT 납입횟수
	public String[] ars_pym_crtf_isu_at__vh_no = new String[0];  //[O] 자동차납입증명목록_자보차량번호 H_SCR_BM0044_JABO_CAR_NO 차량번호
	public String[] ars_pym_crtf_isu_at__icdd_tgt_asrt_prm = new String[0];  //[O] 자동차납입증명목록_소득공제대상보장성보험료 SCR_BM0044_JABO_GONG_PRM 소득공제대상보험료（보장성
	public String[] ars_pym_crtf_isu_at__icdd_tgt_dsab_asrt_prm = new String[0];  //[O] 자동차납입증명목록_소득공제대상장애인보장성보험료 SCR_BM0044_JABO_JANG_PRM 소득공제대상보험료（장애인보장성－곰두리
	public String[] ars_pym_crtf_isu_ltm__plno = new String[0];  //[O] 장기납입증명목록_장기증권번호 SCR_BM0044_JANG_POLI_NO 증권번호
	public String[] ars_pym_crtf_isu_ltm__ins_nm = new String[0];  //[O] 장기납입증명목록_장기피보험자명 H_SCR_BM0044_JANG_PIBO_NM 피보험자명
	public String[] ars_pym_crtf_isu_ltm__ins_rlt = new String[0];  //[O] 장기납입증명목록_장기피보험자관계 H_SCR_BM0044_JANG_GWANGYE 피보험자관계
	public String[] ars_pym_crtf_isu_ltm__inpd_cd = new String[0];  //[O] 장기납입증명목록_장기보종코드 SCR_BM0044_JANG_BJ_CD 보종코드
	public String[] ars_pym_crtf_isu_ltm__inpd_nm = new String[0];  //[O] 장기납입증명목록_장기보종명 H_SCR_BM0044_JANG_BJ_NM 보종명
	public String[] ars_pym_crtf_isu_ltm__pym_mtd_cd = new String[0];  //[O] 장기납입증명목록_장기납입방법코드 SCR_BM0044_JANG_NAPBANG 납입방법코드
	public String[] ars_pym_crtf_isu_ltm__pym_mtd_nm = new String[0];  //[O] 장기납입증명목록_장기납입방법명 H_SCR_BM0044_JANG_NAPBANG_NM 납입방법명
	public String[] ars_pym_crtf_isu_ltm__fnal_pym_ym = new String[0];  //[O] 장기납입증명목록_장기최종납입년월 SCR_BM0044_JANG_LAST_YM 최종납입년월
	public String[] ars_pym_crtf_isu_ltm__pym_nts = new String[0];  //[O] 장기납입증명목록_장기납입횟수 SCR_BM0044_JANG_NAPIP_CNT 납입횟수
	public String[] ars_pym_crtf_isu_ltm__sm_prm = new String[0];  //[O] 장기납입증명목록_합계보험료 SCR-BM0044-JANG-BORYO 1회분보험료
	public String[] ars_pym_crtf_isu_ltm__vh_no = new String[0];  //[O] 장기납입증명목록_장기차량번호 H_SCR_BM0044_JANG_CAR_NO 차량번호
	public String[] ars_pym_crtf_isu_ltm__ltm_icdd_tgt_asrt_prm = new String[0];  //[O] 장기납입증명목록_장기소득공제대상보장성보험료 SCR_BM0044_JANG_GONG_PRM 소득공제대상보험료（보장성
	public String[] ars_pym_crtf_isu_ltm__ltm_icdd_tgt_prn_pnn_prm = new String[0];  //[O] 장기납입증명목록_장기소득공제대상개인연금보험료 SCR_BM0044_JANG_YUN_PRM 소득공제대상보험료（개인연금）
	public String[] ars_pym_crtf_isu_ltm__ltm_icdd_tgt_pnn_svi_prm = new String[0];  //[O] 장기납입증명목록_장기소득공제대상연금저축보험료 SCR_BM0044_JANG_YUN_SAVE 소득공제대상보험료（연금저축
	public String[] ars_pym_crtf_isu_ltm__ltm_icdd_tgt_hse_prep_prm = new String[0];  //[O] 장기납입증명목록_장기소득공제대상주택마련보험료 SCR_BM0044_JANG_JUTEK 소득공제대상보험료（주택마련）
	public String[] ars_pym_crtf_isu_gnrl__plno = new String[0];  //[O] 일반납입증명목록_일반증권번호 SCR_BM0044_ILBA_POLI_NO 증권번호
	public String[] ars_pym_crtf_isu_gnrl__ins_nm = new String[0];  //[O] 일반납입증명목록_일반피보험자명 H_SCR_BM0044_ILBA_PIBO_NM 피보험자명
	public String[] ars_pym_crtf_isu_gnrl__ins_rlt = new String[0];  //[O] 일반납입증명목록_일반피보험자관계 H_SCR_BM0044_ILBA_GWANGYE 피보험자관계
	public String[] ars_pym_crtf_isu_gnrl__inpd_cd = new String[0];  //[O] 일반납입증명목록_일반보종코드 SCR_BM0044_ILBA_BJ_CD 보종코드
	public String[] ars_pym_crtf_isu_gnrl__inpd_nm = new String[0];  //[O] 일반납입증명목록_일반보종명 H_SCR_BM0044_ILBA_BJ_NM 보종명
	public String[] ars_pym_crtf_isu_gnrl__pym_mtd_cd = new String[0];  //[O] 일반납입증명목록_일반납입방법코드 SCR_BM0044_ILBA_NAPBANG 납입방법코드
	public String[] ars_pym_crtf_isu_gnrl__pym_mtd_nm = new String[0];  //[O] 일반납입증명목록_일반납입방법명 H_SCR_BM0044_ILBA_NAPBANG_NM 납입방법명
	public String[] ars_pym_crtf_isu_gnrl__fnal_pym_ym = new String[0];  //[O] 일반납입증명목록_일반최종납입년월 SCR_BM0044_ILBA_LAST_YM 최종납입년월
	public String[] ars_pym_crtf_isu_gnrl__pym_nts = new String[0];  //[O] 일반납입증명목록_일반납입횟수 SCR_BM0044_ILBA_NAPIP_CNT 납입횟수
	public String[] ars_pym_crtf_isu_gnrl__vh_no = new String[0];  //[O] 일반납입증명목록_일반차량번호 H_SCR_BM0044_ILBA_CAR_NO 차량번호
	public String[] ars_pym_crtf_isu_gnrl__gnrl_icdd_tgt_asrt_prm = new String[0];  //[O] 일반납입증명목록_일반소득공제대상보장성보험료 SCR_BM0044_ILBA_GONG_PRM 소득공제대상보험료（보장성
	public String errorCode = "";  //에러코드
	
	
	public String getCust_dcmt_no() {
		return cust_dcmt_no;
	}
	public void setCust_dcmt_no(String cust_dcmt_no) {
		this.cust_dcmt_no = cust_dcmt_no;
	}
	public String getBse_yy() {
		return bse_yy;
	}
	public void setBse_yy(String bse_yy) {
		this.bse_yy = bse_yy;
	}
	public String getCust_nm() {
		return cust_nm;
	}
	public void setCust_nm(String cust_nm) {
		this.cust_nm = cust_nm;
	}
	public String getRsdn_no() {
		return rsdn_no;
	}
	public void setRsdn_no(String rsdn_no) {
		this.rsdn_no = rsdn_no;
	}
	public String getPsno() {
		return psno;
	}
	public void setPsno(String psno) {
		this.psno = psno;
	}
	public String getPsno_nm() {
		return psno_nm;
	}
	public void setPsno_nm(String psno_nm) {
		this.psno_nm = psno_nm;
	}
	public String getEta_adr() {
		return eta_adr;
	}
	public void setEta_adr(String eta_adr) {
		this.eta_adr = eta_adr;
	}
	public String[] getArs_pym_crtf_isu_at__plno() {
		return ars_pym_crtf_isu_at__plno;
	}
	public void setArs_pym_crtf_isu_at__plno(String[] ars_pym_crtf_isu_at__plno) {
		this.ars_pym_crtf_isu_at__plno = ars_pym_crtf_isu_at__plno;
	}
	public String[] getArs_pym_crtf_isu_at__ins_nm() {
		return ars_pym_crtf_isu_at__ins_nm;
	}
	public void setArs_pym_crtf_isu_at__ins_nm(String[] ars_pym_crtf_isu_at__ins_nm) {
		this.ars_pym_crtf_isu_at__ins_nm = ars_pym_crtf_isu_at__ins_nm;
	}
	public String[] getArs_pym_crtf_isu_at__ins_rlt() {
		return ars_pym_crtf_isu_at__ins_rlt;
	}
	public void setArs_pym_crtf_isu_at__ins_rlt(
			String[] ars_pym_crtf_isu_at__ins_rlt) {
		this.ars_pym_crtf_isu_at__ins_rlt = ars_pym_crtf_isu_at__ins_rlt;
	}
	public String[] getArs_pym_crtf_isu_at__inpd_cd() {
		return ars_pym_crtf_isu_at__inpd_cd;
	}
	public void setArs_pym_crtf_isu_at__inpd_cd(
			String[] ars_pym_crtf_isu_at__inpd_cd) {
		this.ars_pym_crtf_isu_at__inpd_cd = ars_pym_crtf_isu_at__inpd_cd;
	}
	public String[] getArs_pym_crtf_isu_at__inpd_nm() {
		return ars_pym_crtf_isu_at__inpd_nm;
	}
	public void setArs_pym_crtf_isu_at__inpd_nm(
			String[] ars_pym_crtf_isu_at__inpd_nm) {
		this.ars_pym_crtf_isu_at__inpd_nm = ars_pym_crtf_isu_at__inpd_nm;
	}
	public String[] getArs_pym_crtf_isu_at__pym_mtd_cd() {
		return ars_pym_crtf_isu_at__pym_mtd_cd;
	}
	public void setArs_pym_crtf_isu_at__pym_mtd_cd(
			String[] ars_pym_crtf_isu_at__pym_mtd_cd) {
		this.ars_pym_crtf_isu_at__pym_mtd_cd = ars_pym_crtf_isu_at__pym_mtd_cd;
	}
	public String[] getArs_pym_crtf_isu_at__pym_mtd_nm() {
		return ars_pym_crtf_isu_at__pym_mtd_nm;
	}
	public void setArs_pym_crtf_isu_at__pym_mtd_nm(
			String[] ars_pym_crtf_isu_at__pym_mtd_nm) {
		this.ars_pym_crtf_isu_at__pym_mtd_nm = ars_pym_crtf_isu_at__pym_mtd_nm;
	}
	public String[] getArs_pym_crtf_isu_at__fnal_pym_ym() {
		return ars_pym_crtf_isu_at__fnal_pym_ym;
	}
	public void setArs_pym_crtf_isu_at__fnal_pym_ym(
			String[] ars_pym_crtf_isu_at__fnal_pym_ym) {
		this.ars_pym_crtf_isu_at__fnal_pym_ym = ars_pym_crtf_isu_at__fnal_pym_ym;
	}
	public String[] getArs_pym_crtf_isu_at__pym_nts() {
		return ars_pym_crtf_isu_at__pym_nts;
	}
	public void setArs_pym_crtf_isu_at__pym_nts(
			String[] ars_pym_crtf_isu_at__pym_nts) {
		this.ars_pym_crtf_isu_at__pym_nts = ars_pym_crtf_isu_at__pym_nts;
	}
	public String[] getArs_pym_crtf_isu_at__vh_no() {
		return ars_pym_crtf_isu_at__vh_no;
	}
	public void setArs_pym_crtf_isu_at__vh_no(String[] ars_pym_crtf_isu_at__vh_no) {
		this.ars_pym_crtf_isu_at__vh_no = ars_pym_crtf_isu_at__vh_no;
	}
	public String[] getArs_pym_crtf_isu_at__icdd_tgt_asrt_prm() {
		return ars_pym_crtf_isu_at__icdd_tgt_asrt_prm;
	}
	public void setArs_pym_crtf_isu_at__icdd_tgt_asrt_prm(
			String[] ars_pym_crtf_isu_at__icdd_tgt_asrt_prm) {
		this.ars_pym_crtf_isu_at__icdd_tgt_asrt_prm = ars_pym_crtf_isu_at__icdd_tgt_asrt_prm;
	}
	public String[] getArs_pym_crtf_isu_at__icdd_tgt_dsab_asrt_prm() {
		return ars_pym_crtf_isu_at__icdd_tgt_dsab_asrt_prm;
	}
	public void setArs_pym_crtf_isu_at__icdd_tgt_dsab_asrt_prm(
			String[] ars_pym_crtf_isu_at__icdd_tgt_dsab_asrt_prm) {
		this.ars_pym_crtf_isu_at__icdd_tgt_dsab_asrt_prm = ars_pym_crtf_isu_at__icdd_tgt_dsab_asrt_prm;
	}
	public String[] getArs_pym_crtf_isu_ltm__plno() {
		return ars_pym_crtf_isu_ltm__plno;
	}
	public void setArs_pym_crtf_isu_ltm__plno(String[] ars_pym_crtf_isu_ltm__plno) {
		this.ars_pym_crtf_isu_ltm__plno = ars_pym_crtf_isu_ltm__plno;
	}
	public String[] getArs_pym_crtf_isu_ltm__ins_nm() {
		return ars_pym_crtf_isu_ltm__ins_nm;
	}
	public void setArs_pym_crtf_isu_ltm__ins_nm(
			String[] ars_pym_crtf_isu_ltm__ins_nm) {
		this.ars_pym_crtf_isu_ltm__ins_nm = ars_pym_crtf_isu_ltm__ins_nm;
	}
	public String[] getArs_pym_crtf_isu_ltm__ins_rlt() {
		return ars_pym_crtf_isu_ltm__ins_rlt;
	}
	public void setArs_pym_crtf_isu_ltm__ins_rlt(
			String[] ars_pym_crtf_isu_ltm__ins_rlt) {
		this.ars_pym_crtf_isu_ltm__ins_rlt = ars_pym_crtf_isu_ltm__ins_rlt;
	}
	public String[] getArs_pym_crtf_isu_ltm__inpd_cd() {
		return ars_pym_crtf_isu_ltm__inpd_cd;
	}
	public void setArs_pym_crtf_isu_ltm__inpd_cd(
			String[] ars_pym_crtf_isu_ltm__inpd_cd) {
		this.ars_pym_crtf_isu_ltm__inpd_cd = ars_pym_crtf_isu_ltm__inpd_cd;
	}
	public String[] getArs_pym_crtf_isu_ltm__inpd_nm() {
		return ars_pym_crtf_isu_ltm__inpd_nm;
	}
	public void setArs_pym_crtf_isu_ltm__inpd_nm(
			String[] ars_pym_crtf_isu_ltm__inpd_nm) {
		this.ars_pym_crtf_isu_ltm__inpd_nm = ars_pym_crtf_isu_ltm__inpd_nm;
	}
	public String[] getArs_pym_crtf_isu_ltm__pym_mtd_cd() {
		return ars_pym_crtf_isu_ltm__pym_mtd_cd;
	}
	public void setArs_pym_crtf_isu_ltm__pym_mtd_cd(
			String[] ars_pym_crtf_isu_ltm__pym_mtd_cd) {
		this.ars_pym_crtf_isu_ltm__pym_mtd_cd = ars_pym_crtf_isu_ltm__pym_mtd_cd;
	}
	public String[] getArs_pym_crtf_isu_ltm__pym_mtd_nm() {
		return ars_pym_crtf_isu_ltm__pym_mtd_nm;
	}
	public void setArs_pym_crtf_isu_ltm__pym_mtd_nm(
			String[] ars_pym_crtf_isu_ltm__pym_mtd_nm) {
		this.ars_pym_crtf_isu_ltm__pym_mtd_nm = ars_pym_crtf_isu_ltm__pym_mtd_nm;
	}
	public String[] getArs_pym_crtf_isu_ltm__fnal_pym_ym() {
		return ars_pym_crtf_isu_ltm__fnal_pym_ym;
	}
	public void setArs_pym_crtf_isu_ltm__fnal_pym_ym(
			String[] ars_pym_crtf_isu_ltm__fnal_pym_ym) {
		this.ars_pym_crtf_isu_ltm__fnal_pym_ym = ars_pym_crtf_isu_ltm__fnal_pym_ym;
	}
	public String[] getArs_pym_crtf_isu_ltm__pym_nts() {
		return ars_pym_crtf_isu_ltm__pym_nts;
	}
	public void setArs_pym_crtf_isu_ltm__pym_nts(
			String[] ars_pym_crtf_isu_ltm__pym_nts) {
		this.ars_pym_crtf_isu_ltm__pym_nts = ars_pym_crtf_isu_ltm__pym_nts;
	}
	public String[] getArs_pym_crtf_isu_ltm__sm_prm() {
		return ars_pym_crtf_isu_ltm__sm_prm;
	}
	public void setArs_pym_crtf_isu_ltm__sm_prm(
			String[] ars_pym_crtf_isu_ltm__sm_prm) {
		this.ars_pym_crtf_isu_ltm__sm_prm = ars_pym_crtf_isu_ltm__sm_prm;
	}
	public String[] getArs_pym_crtf_isu_ltm__vh_no() {
		return ars_pym_crtf_isu_ltm__vh_no;
	}
	public void setArs_pym_crtf_isu_ltm__vh_no(String[] ars_pym_crtf_isu_ltm__vh_no) {
		this.ars_pym_crtf_isu_ltm__vh_no = ars_pym_crtf_isu_ltm__vh_no;
	}
	public String[] getArs_pym_crtf_isu_ltm__ltm_icdd_tgt_asrt_prm() {
		return ars_pym_crtf_isu_ltm__ltm_icdd_tgt_asrt_prm;
	}
	public void setArs_pym_crtf_isu_ltm__ltm_icdd_tgt_asrt_prm(
			String[] ars_pym_crtf_isu_ltm__ltm_icdd_tgt_asrt_prm) {
		this.ars_pym_crtf_isu_ltm__ltm_icdd_tgt_asrt_prm = ars_pym_crtf_isu_ltm__ltm_icdd_tgt_asrt_prm;
	}
	public String[] getArs_pym_crtf_isu_ltm__ltm_icdd_tgt_prn_pnn_prm() {
		return ars_pym_crtf_isu_ltm__ltm_icdd_tgt_prn_pnn_prm;
	}
	public void setArs_pym_crtf_isu_ltm__ltm_icdd_tgt_prn_pnn_prm(
			String[] ars_pym_crtf_isu_ltm__ltm_icdd_tgt_prn_pnn_prm) {
		this.ars_pym_crtf_isu_ltm__ltm_icdd_tgt_prn_pnn_prm = ars_pym_crtf_isu_ltm__ltm_icdd_tgt_prn_pnn_prm;
	}
	public String[] getArs_pym_crtf_isu_ltm__ltm_icdd_tgt_pnn_svi_prm() {
		return ars_pym_crtf_isu_ltm__ltm_icdd_tgt_pnn_svi_prm;
	}
	public void setArs_pym_crtf_isu_ltm__ltm_icdd_tgt_pnn_svi_prm(
			String[] ars_pym_crtf_isu_ltm__ltm_icdd_tgt_pnn_svi_prm) {
		this.ars_pym_crtf_isu_ltm__ltm_icdd_tgt_pnn_svi_prm = ars_pym_crtf_isu_ltm__ltm_icdd_tgt_pnn_svi_prm;
	}
	public String[] getArs_pym_crtf_isu_ltm__ltm_icdd_tgt_hse_prep_prm() {
		return ars_pym_crtf_isu_ltm__ltm_icdd_tgt_hse_prep_prm;
	}
	public void setArs_pym_crtf_isu_ltm__ltm_icdd_tgt_hse_prep_prm(
			String[] ars_pym_crtf_isu_ltm__ltm_icdd_tgt_hse_prep_prm) {
		this.ars_pym_crtf_isu_ltm__ltm_icdd_tgt_hse_prep_prm = ars_pym_crtf_isu_ltm__ltm_icdd_tgt_hse_prep_prm;
	}
	public String[] getArs_pym_crtf_isu_gnrl__plno() {
		return ars_pym_crtf_isu_gnrl__plno;
	}
	public void setArs_pym_crtf_isu_gnrl__plno(String[] ars_pym_crtf_isu_gnrl__plno) {
		this.ars_pym_crtf_isu_gnrl__plno = ars_pym_crtf_isu_gnrl__plno;
	}
	public String[] getArs_pym_crtf_isu_gnrl__ins_nm() {
		return ars_pym_crtf_isu_gnrl__ins_nm;
	}
	public void setArs_pym_crtf_isu_gnrl__ins_nm(
			String[] ars_pym_crtf_isu_gnrl__ins_nm) {
		this.ars_pym_crtf_isu_gnrl__ins_nm = ars_pym_crtf_isu_gnrl__ins_nm;
	}
	public String[] getArs_pym_crtf_isu_gnrl__ins_rlt() {
		return ars_pym_crtf_isu_gnrl__ins_rlt;
	}
	public void setArs_pym_crtf_isu_gnrl__ins_rlt(
			String[] ars_pym_crtf_isu_gnrl__ins_rlt) {
		this.ars_pym_crtf_isu_gnrl__ins_rlt = ars_pym_crtf_isu_gnrl__ins_rlt;
	}
	public String[] getArs_pym_crtf_isu_gnrl__inpd_cd() {
		return ars_pym_crtf_isu_gnrl__inpd_cd;
	}
	public void setArs_pym_crtf_isu_gnrl__inpd_cd(
			String[] ars_pym_crtf_isu_gnrl__inpd_cd) {
		this.ars_pym_crtf_isu_gnrl__inpd_cd = ars_pym_crtf_isu_gnrl__inpd_cd;
	}
	public String[] getArs_pym_crtf_isu_gnrl__inpd_nm() {
		return ars_pym_crtf_isu_gnrl__inpd_nm;
	}
	public void setArs_pym_crtf_isu_gnrl__inpd_nm(
			String[] ars_pym_crtf_isu_gnrl__inpd_nm) {
		this.ars_pym_crtf_isu_gnrl__inpd_nm = ars_pym_crtf_isu_gnrl__inpd_nm;
	}
	public String[] getArs_pym_crtf_isu_gnrl__pym_mtd_cd() {
		return ars_pym_crtf_isu_gnrl__pym_mtd_cd;
	}
	public void setArs_pym_crtf_isu_gnrl__pym_mtd_cd(
			String[] ars_pym_crtf_isu_gnrl__pym_mtd_cd) {
		this.ars_pym_crtf_isu_gnrl__pym_mtd_cd = ars_pym_crtf_isu_gnrl__pym_mtd_cd;
	}
	public String[] getArs_pym_crtf_isu_gnrl__pym_mtd_nm() {
		return ars_pym_crtf_isu_gnrl__pym_mtd_nm;
	}
	public void setArs_pym_crtf_isu_gnrl__pym_mtd_nm(
			String[] ars_pym_crtf_isu_gnrl__pym_mtd_nm) {
		this.ars_pym_crtf_isu_gnrl__pym_mtd_nm = ars_pym_crtf_isu_gnrl__pym_mtd_nm;
	}
	public String[] getArs_pym_crtf_isu_gnrl__fnal_pym_ym() {
		return ars_pym_crtf_isu_gnrl__fnal_pym_ym;
	}
	public void setArs_pym_crtf_isu_gnrl__fnal_pym_ym(
			String[] ars_pym_crtf_isu_gnrl__fnal_pym_ym) {
		this.ars_pym_crtf_isu_gnrl__fnal_pym_ym = ars_pym_crtf_isu_gnrl__fnal_pym_ym;
	}
	public String[] getArs_pym_crtf_isu_gnrl__pym_nts() {
		return ars_pym_crtf_isu_gnrl__pym_nts;
	}
	public void setArs_pym_crtf_isu_gnrl__pym_nts(
			String[] ars_pym_crtf_isu_gnrl__pym_nts) {
		this.ars_pym_crtf_isu_gnrl__pym_nts = ars_pym_crtf_isu_gnrl__pym_nts;
	}
	public String[] getArs_pym_crtf_isu_gnrl__vh_no() {
		return ars_pym_crtf_isu_gnrl__vh_no;
	}
	public void setArs_pym_crtf_isu_gnrl__vh_no(
			String[] ars_pym_crtf_isu_gnrl__vh_no) {
		this.ars_pym_crtf_isu_gnrl__vh_no = ars_pym_crtf_isu_gnrl__vh_no;
	}
	public String[] getArs_pym_crtf_isu_gnrl__gnrl_icdd_tgt_asrt_prm() {
		return ars_pym_crtf_isu_gnrl__gnrl_icdd_tgt_asrt_prm;
	}
	public void setArs_pym_crtf_isu_gnrl__gnrl_icdd_tgt_asrt_prm(
			String[] ars_pym_crtf_isu_gnrl__gnrl_icdd_tgt_asrt_prm) {
		this.ars_pym_crtf_isu_gnrl__gnrl_icdd_tgt_asrt_prm = ars_pym_crtf_isu_gnrl__gnrl_icdd_tgt_asrt_prm;
	}
	
	

}
