package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class CCLM0020VO extends CMMVO {
	//전문필드
		public String psic = "";  //[I/O] 담당자 SS-DAMDANGJA 담당자
		public String clam_cntr = "";  //[O] 보상센터 HS-BOSANG-BR 보상센터
		public String clam_team = "";  //[O] 보상팀 HS-BOSANG-TEAM 보상팀
		public String nme = "";  //[O] 성명 HS-DAMDANGJA-NM 성명
		public String dty = "";  //[O] 직책 HS-JIKCHEK 직책
		public String ofc_tlp = "";  //[O] 사무실전화 SS-TEL 사무실전화
		public String clp = "";  //[O] 휴대폰 SS-HANDPHONE-NO 휴대폰
		public String fx_no = "";  //[O] 팩스번호 SS-FAX-NO 팩스번호
		public String eml = "";  //[O] 이메일 SS-EMAIL 이메일
		public String agnc_nm = "";  //[O] 대리점명 HS-DAERIJUM-NM 대리점명
		public String bank_nm = "";  //[O] 은행명 HS-BANK-NM 은행명
		public String acc_no = "";  //[O] 계좌번호 SS-ACCT-NO 계좌번호
		
		public String getPsic() {
			return psic;
		}
		public void setPsic(String psic) {
			this.psic = psic;
		}
		public String getClam_cntr() {
			return clam_cntr;
		}
		public void setClam_cntr(String clam_cntr) {
			this.clam_cntr = clam_cntr;
		}
		public String getClam_team() {
			return clam_team;
		}
		public void setClam_team(String clam_team) {
			this.clam_team = clam_team;
		}
		public String getNme() {
			return nme;
		}
		public void setNme(String nme) {
			this.nme = nme;
		}
		public String getDty() {
			return dty;
		}
		public void setDty(String dty) {
			this.dty = dty;
		}
		public String getOfc_tlp() {
			return ofc_tlp;
		}
		public void setOfc_tlp(String ofc_tlp) {
			this.ofc_tlp = ofc_tlp;
		}
		public String getClp() {
			return clp;
		}
		public void setClp(String clp) {
			this.clp = clp;
		}
		public String getFx_no() {
			return fx_no;
		}
		public void setFx_no(String fx_no) {
			this.fx_no = fx_no;
		}
		public String getEml() {
			return eml;
		}
		public void setEml(String eml) {
			this.eml = eml;
		}
		public String getAgnc_nm() {
			return agnc_nm;
		}
		public void setAgnc_nm(String agnc_nm) {
			this.agnc_nm = agnc_nm;
		}
		public String getBank_nm() {
			return bank_nm;
		}
		public void setBank_nm(String bank_nm) {
			this.bank_nm = bank_nm;
		}
		public String getAcc_no() {
			return acc_no;
		}
		public void setAcc_no(String acc_no) {
			this.acc_no = acc_no;
		}
		
		
		
}
