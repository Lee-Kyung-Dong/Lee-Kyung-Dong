package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class CCLM0013VO extends CMMVO{

	//전문필드
		public String accd_rpt_no = "";  //[I] 사고접수번호 SS_SAGO_JUBSU_NO 사고접수번호
		public String accd_oj_dvcd = "";  //[I] 사고목적구분코드 SS_SAGO_MOKJUK_GB 사고목적구분
		public String accd_oj_rnk = "";  //[I] 사고목적서열 SS_SAGO_MOKJUK_SEQ 사고목적일련번호
		public String[] pyn_if__cmp_sqno = new String[0];  //[O] 지급정보_산출일련번호 SS_SANCHUL_SEQ 산출일련번호
		public String[] pyn_if__ins_nm = new String[0];  //[O] 지급정보_피보험자명 HS_PIBO_NM 피보험자명
		public String[] pyn_if__inpd_cd = new String[0];  //[O] 지급정보_보종코드 SS_BOJONG_CD 보종코드
		public String[] pyn_if__inpd_nm = new String[0];  //[O] 지급정보_보종명 HS_BOJONG_NM 보종명
		public String[] pyn_if__plno = new String[0];  //[O] 지급정보_증권번호 SS_POLI_NO 증권번호
		public String[] pyn_if__chng_sqno = new String[0];  //[O] 지급정보_변경일련번호 SS_BESU_SEQ 배서일련번호
		public String[] pyn_if__cvr_cd = new String[0];  //[O] 지급정보_담보코드 SS_DAMBO_CD 담보코드
		public String[] pyn_if__cvr_nm = new String[0];  //[O] 지급정보_담보명 HS_DAMBO_NM 담보명
		public String[] pyn_if__pyn_bnf = new String[0];  //[O] 지급정보_지급보험금 SS_PL_CMT 지금보험금
		public String[] pyn_if__dcs_dt = new String[0];  //[O] 지급정보_확정일자 SS_WHAKJUNG_YMD 확정일자
		public String[] pyn_if__pyn_typ = new String[0];  //[O] 지급정보_지급유형 HS_PL_TYPE 지급유형
		public String[] pyn_if__psic_no = new String[0];  //[O] 지급정보_담당자번호 SS_DAMDANGJA_CD 담당자사번
		public String[] pyn_if__psic_nm = new String[0];  //[O] 지급정보_담당자명 HS_DAMDANGJA_NM 담당자명
		public String[] pyn_if__gnrl_ltm_at_dvn = new String[0];  //[O] 지급정보_일반장기자동차구분 SS_ILJANGJA 일장자구분
		public String[] pyn_if__arc_trm_str_dt = new String[0]; // 보험기간시작일자
		public String[] pyn_if__pyn_atl_lgcg_cd = new String[0]; // 지급항목대분류코드
		public String[] payp_if__ds_sqno = new String[0]; // 결정일련번호
		public String[] payp_if__bank_nm = new String[0]; // 은행명
		public String[] payp_if__acc_no = new String[0]; // 계좌번호
		public String[] payp_if__payp_nm = new String[0]; // 지급처명
		public String[] payp_if__ds_bnf = new String[0]; // 결정보험금
		public String[] payp_if__dcs_dt = new String[0]; // 확정일자
		public String tot_cnum = "";  //[O] 총건수 SS_TOT_CNT 총건수
		public String tot_amt = "";  //[O] 총금액 SS_TOT_AMT 총금액
		public String errorCode = "";  //[O] 총금액 SS_TOT_AMT 총금액
		
		
		public String getErrorCode() {
			return errorCode;
		}
		public void setErrorCode(String errorCode) {
			this.errorCode = errorCode;
		}
		public String getAccd_rpt_no() {
			return accd_rpt_no;
		}
		public void setAccd_rpt_no(String accd_rpt_no) {
			this.accd_rpt_no = accd_rpt_no;
		}
		public String getAccd_oj_dvcd() {
			return accd_oj_dvcd;
		}
		public void setAccd_oj_dvcd(String accd_oj_dvcd) {
			this.accd_oj_dvcd = accd_oj_dvcd;
		}
		public String getAccd_oj_rnk() {
			return accd_oj_rnk;
		}
		public void setAccd_oj_rnk(String accd_oj_rnk) {
			this.accd_oj_rnk = accd_oj_rnk;
		}
		public String[] getPyn_if__cmp_sqno() {
			return pyn_if__cmp_sqno;
		}
		public void setPyn_if__cmp_sqno(String[] pyn_if__cmp_sqno) {
			this.pyn_if__cmp_sqno = pyn_if__cmp_sqno;
		}
		public String[] getPyn_if__ins_nm() {
			return pyn_if__ins_nm;
		}
		public void setPyn_if__ins_nm(String[] pyn_if__ins_nm) {
			this.pyn_if__ins_nm = pyn_if__ins_nm;
		}
		public String[] getPyn_if__inpd_cd() {
			return pyn_if__inpd_cd;
		}
		public void setPyn_if__inpd_cd(String[] pyn_if__inpd_cd) {
			this.pyn_if__inpd_cd = pyn_if__inpd_cd;
		}
		public String[] getPyn_if__inpd_nm() {
			return pyn_if__inpd_nm;
		}
		public void setPyn_if__inpd_nm(String[] pyn_if__inpd_nm) {
			this.pyn_if__inpd_nm = pyn_if__inpd_nm;
		}
		public String[] getPyn_if__plno() {
			return pyn_if__plno;
		}
		public void setPyn_if__plno(String[] pyn_if__plno) {
			this.pyn_if__plno = pyn_if__plno;
		}
		public String[] getPyn_if__chng_sqno() {
			return pyn_if__chng_sqno;
		}
		public void setPyn_if__chng_sqno(String[] pyn_if__chng_sqno) {
			this.pyn_if__chng_sqno = pyn_if__chng_sqno;
		}
		public String[] getPyn_if__cvr_cd() {
			return pyn_if__cvr_cd;
		}
		public void setPyn_if__cvr_cd(String[] pyn_if__cvr_cd) {
			this.pyn_if__cvr_cd = pyn_if__cvr_cd;
		}
		public String[] getPyn_if__cvr_nm() {
			return pyn_if__cvr_nm;
		}
		public void setPyn_if__cvr_nm(String[] pyn_if__cvr_nm) {
			this.pyn_if__cvr_nm = pyn_if__cvr_nm;
		}
		public String[] getPyn_if__pyn_bnf() {
			return pyn_if__pyn_bnf;
		}
		public void setPyn_if__pyn_bnf(String[] pyn_if__pyn_bnf) {
			this.pyn_if__pyn_bnf = pyn_if__pyn_bnf;
		}
		public String[] getPyn_if__dcs_dt() {
			return pyn_if__dcs_dt;
		}
		public void setPyn_if__dcs_dt(String[] pyn_if__dcs_dt) {
			this.pyn_if__dcs_dt = pyn_if__dcs_dt;
		}
		public String[] getPyn_if__pyn_typ() {
			return pyn_if__pyn_typ;
		}
		public void setPyn_if__pyn_typ(String[] pyn_if__pyn_typ) {
			this.pyn_if__pyn_typ = pyn_if__pyn_typ;
		}
		public String[] getPyn_if__psic_no() {
			return pyn_if__psic_no;
		}
		public void setPyn_if__psic_no(String[] pyn_if__psic_no) {
			this.pyn_if__psic_no = pyn_if__psic_no;
		}
		public String[] getPyn_if__psic_nm() {
			return pyn_if__psic_nm;
		}
		public void setPyn_if__psic_nm(String[] pyn_if__psic_nm) {
			this.pyn_if__psic_nm = pyn_if__psic_nm;
		}
		public String[] getPyn_if__gnrl_ltm_at_dvn() {
			return pyn_if__gnrl_ltm_at_dvn;
		}
		public void setPyn_if__gnrl_ltm_at_dvn(String[] pyn_if__gnrl_ltm_at_dvn) {
			this.pyn_if__gnrl_ltm_at_dvn = pyn_if__gnrl_ltm_at_dvn;
		}
		public String getTot_cnum() {
			return tot_cnum;
		}
		public void setTot_cnum(String tot_cnum) {
			this.tot_cnum = tot_cnum;
		}
		public String getTot_amt() {
			return tot_amt;
		}
		public void setTot_amt(String tot_amt) {
			this.tot_amt = tot_amt;
		}
		public String[] getPyn_if__arc_trm_str_dt() {
			return pyn_if__arc_trm_str_dt;
		}
		public void setPyn_if__arc_trm_str_dt(String[] pyn_if__arc_trm_str_dt) {
			this.pyn_if__arc_trm_str_dt = pyn_if__arc_trm_str_dt;
		}
		public String[] getPyn_if__pyn_atl_lgcg_cd() {
			return pyn_if__pyn_atl_lgcg_cd;
		}
		public void setPyn_if__pyn_atl_lgcg_cd(String[] pyn_if__pyn_atl_lgcg_cd) {
			this.pyn_if__pyn_atl_lgcg_cd = pyn_if__pyn_atl_lgcg_cd;
		}
		public String[] getPayp_if__ds_sqno() {
			return payp_if__ds_sqno;
		}
		public void setPayp_if__ds_sqno(String[] payp_if__ds_sqno) {
			this.payp_if__ds_sqno = payp_if__ds_sqno;
		}
		public String[] getPayp_if__bank_nm() {
			return payp_if__bank_nm;
		}
		public void setPayp_if__bank_nm(String[] payp_if__bank_nm) {
			this.payp_if__bank_nm = payp_if__bank_nm;
		}
		public String[] getPayp_if__acc_no() {
			return payp_if__acc_no;
		}
		public void setPayp_if__acc_no(String[] payp_if__acc_no) {
			this.payp_if__acc_no = payp_if__acc_no;
		}
		public String[] getPayp_if__payp_nm() {
			return payp_if__payp_nm;
		}
		public void setPayp_if__payp_nm(String[] payp_if__payp_nm) {
			this.payp_if__payp_nm = payp_if__payp_nm;
		}
		public String[] getPayp_if__ds_bnf() {
			return payp_if__ds_bnf;
		}
		public void setPayp_if__ds_bnf(String[] payp_if__ds_bnf) {
			this.payp_if__ds_bnf = payp_if__ds_bnf;
		}
		public String[] getPayp_if__dcs_dt() {
			return payp_if__dcs_dt;
		}
		public void setPayp_if__dcs_dt(String[] payp_if__dcs_dt) {
			this.payp_if__dcs_dt = payp_if__dcs_dt;
		}
		
}
