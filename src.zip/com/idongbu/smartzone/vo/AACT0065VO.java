package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class AACT0065VO extends CMMVO
{
	//전문필드
	public String proc_dvn = "";				// 처리구분
	public String ctrmf_plan_no = "";			// 배서설계번호
	public String plno = "";					// 증권번호
	public String recp_no = "";					// 영수증번호
	public String ormm_cd = "";					// 조직원코드(MOBILE_JOJIKON_CD)
	public String act_dd = "";					// 회계일
	public String cltd_dd = "";					// 영수년월일
	public String cltd_hmns = "";				// 영수시분초
	public String cltd_prm = "";				// 영수보험료
	public String mntp_dvn = "";				// 금종구분(2:카드)
	public String crd_ap_mngt_no = "";			// 승인관리번호
	public String nstl_str_orr = "";			// 카드확정: 1
	public String nstl_fin_orr = "";			// 카드확정: 1
	public String bz_dvn = "";					// 업무구분 3: 배서
	public String dcp_empno = "";				// 설계자사번
	
	public String errorCode = "";
	public String z_resp_msg = "";
	public String z_resp_cd = "";
	public String getProc_dvn() {
		return proc_dvn;
	}
	public void setProc_dvn(String proc_dvn) {
		this.proc_dvn = proc_dvn;
	}
	public String getCtrmf_plan_no() {
		return ctrmf_plan_no;
	}
	public void setCtrmf_plan_no(String ctrmf_plan_no) {
		this.ctrmf_plan_no = ctrmf_plan_no;
	}
	public String getPlno() {
		return plno;
	}
	public void setPlno(String plno) {
		this.plno = plno;
	}
	public String getRecp_no() {
		return recp_no;
	}
	public void setRecp_no(String recp_no) {
		this.recp_no = recp_no;
	}
	public String getOrmm_cd() {
		return ormm_cd;
	}
	public void setOrmm_cd(String ormm_cd) {
		this.ormm_cd = ormm_cd;
	}
	public String getAct_dd() {
		return act_dd;
	}
	public void setAct_dd(String act_dd) {
		this.act_dd = act_dd;
	}
	public String getCltd_dd() {
		return cltd_dd;
	}
	public void setCltd_dd(String cltd_dd) {
		this.cltd_dd = cltd_dd;
	}
	public String getCltd_hmns() {
		return cltd_hmns;
	}
	public void setCltd_hmns(String cltd_hmns) {
		this.cltd_hmns = cltd_hmns;
	}
	public String getCltd_prm() {
		return cltd_prm;
	}
	public void setCltd_prm(String cltd_prm) {
		this.cltd_prm = cltd_prm;
	}
	public String getMntp_dvn() {
		return mntp_dvn;
	}
	public void setMntp_dvn(String mntp_dvn) {
		this.mntp_dvn = mntp_dvn;
	}
	public String getCrd_ap_mngt_no() {
		return crd_ap_mngt_no;
	}
	public void setCrd_ap_mngt_no(String crd_ap_mngt_no) {
		this.crd_ap_mngt_no = crd_ap_mngt_no;
	}
	public String getNstl_str_orr() {
		return nstl_str_orr;
	}
	public void setNstl_str_orr(String nstl_str_orr) {
		this.nstl_str_orr = nstl_str_orr;
	}
	public String getNstl_fin_orr() {
		return nstl_fin_orr;
	}
	public void setNstl_fin_orr(String nstl_fin_orr) {
		this.nstl_fin_orr = nstl_fin_orr;
	}
	public String getBz_dvn() {
		return bz_dvn;
	}
	public void setBz_dvn(String bz_dvn) {
		this.bz_dvn = bz_dvn;
	}
	public String getDcp_empno() {
		return dcp_empno;
	}
	public void setDcp_empno(String dcp_empno) {
		this.dcp_empno = dcp_empno;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getZ_resp_msg() {
		return z_resp_msg;
	}
	public void setZ_resp_msg(String z_resp_msg) {
		this.z_resp_msg = z_resp_msg;
	}
	public String getZ_resp_cd() {
		return z_resp_cd;
	}
	public void setZ_resp_cd(String z_resp_cd) {
		this.z_resp_cd = z_resp_cd;
	}
	
	
	
	
	
}
