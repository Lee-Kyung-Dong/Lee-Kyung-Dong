package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class MMTI0217VO extends CMMVO{
	
	public String mbl_snd_no = "";											// [I/O] 모바일발송번호
	public String[] iner_mbl_snd_mtt__dst_tty_dvn = new String[0];			// [O] 할인특약구분: 01 주행거리, 02 블랙박스, 03 베이비인카, 04 차선이탈, 05 전방충돌
	public String[] iner_mbl_snd_mtt__phgp_regt_cplt_yn = new String[0];	// [O] 사진등록완료여부: 1 등록, 0 미등록
	public String[] iner_mbl_snd_mtt__pbox_no = new String[0];				// [O] 사서함번호
	public String plan_plno_dvcd = "";										// [O] 설계증권번호구분코드: 1 설계번호, 2 증권번호
	public String plan_plno = "";											// [O] 설계증권번호
	public String vh_no = "";												// [O] 차량번호
	public String plno = "";												// [O] 증권번호: 변경설계시 사용
	public String chng_plan_no = "";										// [O] 변경설계번호
	public String mbl_ts_dtl_dvcd = "";										// [O] 모바일전송상세구분코드: 01 신규, 03 변경
	public String cm_yn = "";												// [O] CM여부: 1 CM계약
	public String hdlr_fire_yn = "";										// [O] 취급자해촉여부: 1 해촉
	
	public String getMbl_snd_no() {
		return mbl_snd_no;
	}
	public void setMbl_snd_no(String mbl_snd_no) {
		this.mbl_snd_no = mbl_snd_no;
	}
	public String[] getIner_mbl_snd_mtt__dst_tty_dvn() {
		return iner_mbl_snd_mtt__dst_tty_dvn;
	}
	public void setIner_mbl_snd_mtt__dst_tty_dvn(String[] iner_mbl_snd_mtt__dst_tty_dvn) {
		this.iner_mbl_snd_mtt__dst_tty_dvn = iner_mbl_snd_mtt__dst_tty_dvn;
	}
	public String[] getIner_mbl_snd_mtt__phgp_regt_cplt_yn() {
		return iner_mbl_snd_mtt__phgp_regt_cplt_yn;
	}
	public void setIner_mbl_snd_mtt__phgp_regt_cplt_yn(String[] iner_mbl_snd_mtt__phgp_regt_cplt_yn) {
		this.iner_mbl_snd_mtt__phgp_regt_cplt_yn = iner_mbl_snd_mtt__phgp_regt_cplt_yn;
	}
	public String[] getIner_mbl_snd_mtt__pbox_no() {
		return iner_mbl_snd_mtt__pbox_no;
	}
	public void setIner_mbl_snd_mtt__pbox_no(String[] iner_mbl_snd_mtt__pbox_no) {
		this.iner_mbl_snd_mtt__pbox_no = iner_mbl_snd_mtt__pbox_no;
	}
	public String getPlan_plno_dvcd() {
		return plan_plno_dvcd;
	}
	public void setPlan_plno_dvcd(String plan_plno_dvcd) {
		this.plan_plno_dvcd = plan_plno_dvcd;
	}
	public String getPlan_plno() {
		return plan_plno;
	}
	public void setPlan_plno(String plan_plno) {
		this.plan_plno = plan_plno;
	}
	public String getVh_no() {
		return vh_no;
	}
	public void setVh_no(String vh_no) {
		this.vh_no = vh_no;
	}
	public String getPlno() {
		return plno;
	}
	public void setPlno(String plno) {
		this.plno = plno;
	}
	public String getChng_plan_no() {
		return chng_plan_no;
	}
	public void setChng_plan_no(String chng_plan_no) {
		this.chng_plan_no = chng_plan_no;
	}
	public String getMbl_ts_dtl_dvcd() {
		return mbl_ts_dtl_dvcd;
	}
	public void setMbl_ts_dtl_dvcd(String mbl_ts_dtl_dvcd) {
		this.mbl_ts_dtl_dvcd = mbl_ts_dtl_dvcd;
	}
	public String getCm_yn() {
		return cm_yn;
	}
	public void setCm_yn(String cm_yn) {
		this.cm_yn = cm_yn;
	}
	public String getHdlr_fire_yn() {
		return hdlr_fire_yn;
	}
	public void setHdlr_fire_yn(String hdlr_fire_yn) {
		this.hdlr_fire_yn = hdlr_fire_yn;
	}
	
}
