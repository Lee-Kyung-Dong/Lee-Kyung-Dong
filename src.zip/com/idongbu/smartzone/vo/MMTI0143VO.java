package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class MMTI0143VO extends CMMVO{
	public String vh_no = "";  			//[I/O]차량번호
	public String proc_dvn = "";  		//[I/O]처리구분
	public String err_scrn_id = "";  	//[O]에러화면ID
	public String vh_no_scrn_proc = "";	//[O]차량번호화면처리
	
	public String[] sme_vh_ctc_det_srch_mngt_cust__ins_nm = new String[0];  					//[O] 동일차량계약명세조회관리_고객_피보험자명
	public String[] sme_vh_ctc_det_srch_mngt_cust__plno = new String[0];  						//[O] 동일차량계약명세조회관리_고객_증권번호
	public String[] sme_vh_ctc_det_srch_mngt_cust_arc_tp_cd = new String[0];  					//[O] 동일차량계약명세조회관리_고객_보험종목코드  
	public String[] sme_vh_ctc_det_srch_mngt_cust__arc_pd = new String[0];  					//[O] 동일차량계약명세조회관리_고객_보험시기  
	public String[] sme_vh_ctc_det_srch_mngt_cust__arc_et = new String[0];  					//[O] 동일차량계약명세조회관리_고객_보험종기
	public String[] sme_vh_ctc_det_srch_mngt_cust__cust_no = new String[0];  					//[O] 동일차량계약명세조회관리_고객_고객번호
	public String[] sme_vh_ctc_det_srch_mngt_cust__trv_dstc_tty_exp_exca_tgt_yn = new String[0]; //[O] 동일차량계약명세조회관리_고객_주행거리특약만기정산대상여부
	public String[] sme_vh_ctc_det_srch_mngt_cust__trv_dstc_tty_exp_exca_yn = new String[0];  	//[O] 동일차량계약명세조회관리_고객_주행거리특약만기정산여부  
	public String[] sme_vh_ctc_det_srch_mngt_cust__trv_dstc_chn_dvn = new String[0];  			//[O] 동일차량계약명세조회관리_고객_주행거리채널구분
	public String[] sme_vh_ctc_det_srch_mngt_cust__trv_dstc_dat_fnal_inpt_dt = new String[0];  	//[O] 동일차량계약명세조회관리_고객_주행거리자료최종입력일자
	public String[] sme_vh_ctc_det_srch_mngt_cust__crnm = new String[0];  						//[O] 차명
	public String[] sme_vh_ctc_det_srch_mngt_cust__blbo_yn = new String[0];						//[O] 블랙박스기가입여부

	
	public String getVh_no() {
		return vh_no;
	}
	public void setVh_no(String vh_no) {
		this.vh_no = vh_no;
	}
	public String getProc_dvn() {
		return proc_dvn;
	}
	public void setProc_dvn(String proc_dvn) {
		this.proc_dvn = proc_dvn;
	}
	public String getErr_scrn_id() {
		return err_scrn_id;
	}
	public void setErr_scrn_id(String err_scrn_id) {
		this.err_scrn_id = err_scrn_id;
	}
	public String getVh_no_scrn_proc() {
		return vh_no_scrn_proc;
	}
	public void setVh_no_scrn_proc(String vh_no_scrn_proc) {
		this.vh_no_scrn_proc = vh_no_scrn_proc;
	}
	public String[] getSme_vh_ctc_det_srch_mngt_cust__ins_nm() {
		return sme_vh_ctc_det_srch_mngt_cust__ins_nm;
	}
	public void setSme_vh_ctc_det_srch_mngt_cust__ins_nm(
			String[] sme_vh_ctc_det_srch_mngt_cust__ins_nm) {
		this.sme_vh_ctc_det_srch_mngt_cust__ins_nm = sme_vh_ctc_det_srch_mngt_cust__ins_nm;
	}
	public String[] getSme_vh_ctc_det_srch_mngt_cust__plno() {
		return sme_vh_ctc_det_srch_mngt_cust__plno;
	}
	public void setSme_vh_ctc_det_srch_mngt_cust__plno(
			String[] sme_vh_ctc_det_srch_mngt_cust__plno) {
		this.sme_vh_ctc_det_srch_mngt_cust__plno = sme_vh_ctc_det_srch_mngt_cust__plno;
	}
	public String[] getSme_vh_ctc_det_srch_mngt_cust_arc_tp_cd() {
		return sme_vh_ctc_det_srch_mngt_cust_arc_tp_cd;
	}
	public void setSme_vh_ctc_det_srch_mngt_cust_arc_tp_cd(
			String[] sme_vh_ctc_det_srch_mngt_cust_arc_tp_cd) {
		this.sme_vh_ctc_det_srch_mngt_cust_arc_tp_cd = sme_vh_ctc_det_srch_mngt_cust_arc_tp_cd;
	}
	public String[] getSme_vh_ctc_det_srch_mngt_cust__arc_pd() {
		return sme_vh_ctc_det_srch_mngt_cust__arc_pd;
	}
	public void setSme_vh_ctc_det_srch_mngt_cust__arc_pd(
			String[] sme_vh_ctc_det_srch_mngt_cust__arc_pd) {
		this.sme_vh_ctc_det_srch_mngt_cust__arc_pd = sme_vh_ctc_det_srch_mngt_cust__arc_pd;
	}
	public String[] getSme_vh_ctc_det_srch_mngt_cust__arc_et() {
		return sme_vh_ctc_det_srch_mngt_cust__arc_et;
	}
	public void setSme_vh_ctc_det_srch_mngt_cust__arc_et(
			String[] sme_vh_ctc_det_srch_mngt_cust__arc_et) {
		this.sme_vh_ctc_det_srch_mngt_cust__arc_et = sme_vh_ctc_det_srch_mngt_cust__arc_et;
	}
	public String[] getSme_vh_ctc_det_srch_mngt_cust__cust_no() {
		return sme_vh_ctc_det_srch_mngt_cust__cust_no;
	}
	public void setSme_vh_ctc_det_srch_mngt_cust__cust_no(
			String[] sme_vh_ctc_det_srch_mngt_cust__cust_no) {
		this.sme_vh_ctc_det_srch_mngt_cust__cust_no = sme_vh_ctc_det_srch_mngt_cust__cust_no;
	}
	public String[] getSme_vh_ctc_det_srch_mngt_cust__trv_dstc_tty_exp_exca_tgt_yn() {
		return sme_vh_ctc_det_srch_mngt_cust__trv_dstc_tty_exp_exca_tgt_yn;
	}
	public void setSme_vh_ctc_det_srch_mngt_cust__trv_dstc_tty_exp_exca_tgt_yn(
			String[] sme_vh_ctc_det_srch_mngt_cust__trv_dstc_tty_exp_exca_tgt_yn) {
		this.sme_vh_ctc_det_srch_mngt_cust__trv_dstc_tty_exp_exca_tgt_yn = sme_vh_ctc_det_srch_mngt_cust__trv_dstc_tty_exp_exca_tgt_yn;
	}
	public String[] getSme_vh_ctc_det_srch_mngt_cust__trv_dstc_tty_exp_exca_yn() {
		return sme_vh_ctc_det_srch_mngt_cust__trv_dstc_tty_exp_exca_yn;
	}
	public void setSme_vh_ctc_det_srch_mngt_cust__trv_dstc_tty_exp_exca_yn(
			String[] sme_vh_ctc_det_srch_mngt_cust__trv_dstc_tty_exp_exca_yn) {
		this.sme_vh_ctc_det_srch_mngt_cust__trv_dstc_tty_exp_exca_yn = sme_vh_ctc_det_srch_mngt_cust__trv_dstc_tty_exp_exca_yn;
	}
	public String[] getSme_vh_ctc_det_srch_mngt_cust__trv_dstc_chn_dvn() {
		return sme_vh_ctc_det_srch_mngt_cust__trv_dstc_chn_dvn;
	}
	public void setSme_vh_ctc_det_srch_mngt_cust__trv_dstc_chn_dvn(
			String[] sme_vh_ctc_det_srch_mngt_cust__trv_dstc_chn_dvn) {
		this.sme_vh_ctc_det_srch_mngt_cust__trv_dstc_chn_dvn = sme_vh_ctc_det_srch_mngt_cust__trv_dstc_chn_dvn;
	}
	public String[] getSme_vh_ctc_det_srch_mngt_cust__trv_dstc_dat_fnal_inpt_dt() {
		return sme_vh_ctc_det_srch_mngt_cust__trv_dstc_dat_fnal_inpt_dt;
	}
	public void setSme_vh_ctc_det_srch_mngt_cust__trv_dstc_dat_fnal_inpt_dt(
			String[] sme_vh_ctc_det_srch_mngt_cust__trv_dstc_dat_fnal_inpt_dt) {
		this.sme_vh_ctc_det_srch_mngt_cust__trv_dstc_dat_fnal_inpt_dt = sme_vh_ctc_det_srch_mngt_cust__trv_dstc_dat_fnal_inpt_dt;
	}
	public String[] getSme_vh_ctc_det_srch_mngt_cust__crnm() {
		return sme_vh_ctc_det_srch_mngt_cust__crnm;
	}
	public void setSme_vh_ctc_det_srch_mngt_cust__crnm(
			String[] sme_vh_ctc_det_srch_mngt_cust__crnm) {
		this.sme_vh_ctc_det_srch_mngt_cust__crnm = sme_vh_ctc_det_srch_mngt_cust__crnm;
	}
	public String[] getSme_vh_ctc_det_srch_mngt_cust__blbo_yn() {
		return sme_vh_ctc_det_srch_mngt_cust__blbo_yn;
	}
	public void setSme_vh_ctc_det_srch_mngt_cust__blbo_yn(
			String[] sme_vh_ctc_det_srch_mngt_cust__blbo_yn) {
		this.sme_vh_ctc_det_srch_mngt_cust__blbo_yn = sme_vh_ctc_det_srch_mngt_cust__blbo_yn;
	}
	
	
}
