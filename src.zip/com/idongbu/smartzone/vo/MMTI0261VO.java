package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class MMTI0261VO extends CMMVO{
	
	public String bz_dvn = null;
	public String proc_dvn = null;
	public String plan_no = null;
	public String ins_cd = null;
	public String plno = null;
	public String pbox_no = null;
	public String errorCode = null;
	public String z_msg_cd = null;
	public String returnMessage = null;
	public String z_resp_msg = null;
	
	
	public String getBz_dvn() {
		return bz_dvn;
	}
	public void setBz_dvn(String bz_dvn) {
		this.bz_dvn = bz_dvn;
	}
	public String getProc_dvn() {
		return proc_dvn;
	}
	public void setProc_dvn(String proc_dvn) {
		this.proc_dvn = proc_dvn;
	}
	public String getPlan_no() {
		return plan_no;
	}
	public void setPlan_no(String plan_no) {
		this.plan_no = plan_no;
	}
	public String getIns_cd() {
		return ins_cd;
	}
	public void setIns_cd(String ins_cd) {
		this.ins_cd = ins_cd;
	}
	public String getPlno() {
		return plno;
	}
	public void setPlno(String plno) {
		this.plno = plno;
	}
	public String getPbox_no() {
		return pbox_no;
	}
	public void setPbox_no(String pbox_no) {
		this.pbox_no = pbox_no;
	}
	
}
