/**
 * 경계 고객한글명변경
 */
package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class KCUS0150VO extends CMMVO
{
    private String chng_af_cust_dcmt_no = "";// 변경후고객식별번호
    private String chng_af_cust_hngl_nm = "";// 변경후고객한글명                  
    private String errorCode             = "";// 리턴코드                  
    private String returnMessage         = "";// 리턴메세지                  
    private String z_resp_msg            = "";// 응답메세지
    
    public String getChng_af_cust_dcmt_no()
    {
        return chng_af_cust_dcmt_no;
    }
    public void setChng_af_cust_dcmt_no(String chng_af_cust_dcmt_no)
    {
        this.chng_af_cust_dcmt_no = chng_af_cust_dcmt_no;
    }
    public String getChng_af_cust_hngl_nm()
    {
        return chng_af_cust_hngl_nm;
    }
    public void setChng_af_cust_hngl_nm(String chng_af_cust_hngl_nm)
    {
        this.chng_af_cust_hngl_nm = chng_af_cust_hngl_nm;
    }
    public String getErrorCode()
    {
        return errorCode;
    }
    public void setErrorCode(String errorCode)
    {
        this.errorCode = errorCode;
    }
    public String getReturnMessage()
    {
        return returnMessage;
    }
    public void setReturnMessage(String returnMessage)
    {
        this.returnMessage = returnMessage;
    }
    public String getZ_resp_msg()
    {
        return z_resp_msg;
    }
    public void setZ_resp_msg(String z_resp_msg)
    {
        this.z_resp_msg = z_resp_msg;
    }
}
