package com.idongbu.smartzone.vo;

import java.util.List;
import java.util.Map;

import com.idongbu.common.vo.CMMVO;

public class KCUS0006VO extends CMMVO{
	public String errorCode = null;
	public String cust_dcmt_no = null;
	public String srch_dvn = null;
	public String[] hpg_ctc_srch_ctc_lit__inpd_dvcd = new String[0];  //[O] 홈페이지계약조회_계약목록_보종구분코드 SO_BJ_GB 보종구분
	public String[] hpg_ctc_srch_ctc_lit__pdc_cd = new String[0];  //[O] 홈페이지계약조회_계약목록_상품코드 SO_BJ_CD 보종코드
	public String[] hpg_ctc_srch_ctc_lit__ctc_rlps_dvcd = new String[0];  //[O] 홈페이지계약조회_계약목록_계약관련자구분코드 SO_GOGEK_GB 고객구분
	public String[] hpg_ctc_srch_ctc_lit__plhd_nm = new String[0];  //[O] 홈페이지계약조회_계약목록_계약자명 HO_GYE_NAME 계약자명
	public String[] hpg_ctc_srch_ctc_lit__ins_nm = new String[0];  //[O] 홈페이지계약조회_계약목록_피보험자명 HO_PIB_NAME 피보험자명
	public String[] hpg_ctc_srch_ctc_lit__plno = new String[0];  //[O] 홈페이지계약조회_계약목록_증권번호 SO_POLI_NO 증권번호
	public String[] hpg_ctc_srch_ctc_lit__ins_lcpl_dvcd = new String[0];  //[O] 홈페이지계약조회_계약목록_피보험자소재지구분코드  
	public String[] hpg_ctc_srch_ctc_lit__ply_sqno = new String[0];  //[O] 홈페이지계약조회_계약목록_증권일련번호  
	public String[] hpg_ctc_srch_ctc_lit__hngl_vh_no = new String[0];  //[O] 홈페이지계약조회_계약목록_한글차량번호 HO_CAR_NO 차량번호
	public String[] hpg_ctc_srch_ctc_lit__pdc_nm = new String[0];  //[O] 홈페이지계약조회_계약목록_상품명 HO_BJ_NM 상품명
	public String[] hpg_ctc_srch_ctc_lit__arc_trm_str_dt = new String[0];  //[O] 홈페이지계약조회_계약목록_보험기간시작일자 SO_BOHUM_SYMD 보험기간시기
	public String[] hpg_ctc_srch_ctc_lit__arc_trm_fin_dt = new String[0];  //[O] 홈페이지계약조회_계약목록_보험기간종료일자 SO_BOHUM_EYMD 보험기간종기
	public String[] hpg_ctc_srch_ctc_lit__ctc_stat_nm = new String[0];  //[O] 홈페이지계약조회_계약목록_계약상태명 HO_SANGTE_NM 계약상태
	public String[] hpg_ctc_srch_ctc_lit__sl_pan_cd = new String[0];  //[O] 홈페이지계약조회_계약목록_판매플랜코드 SO_GAIP_TYPE1 가입유형1
	public String[] hpg_ctc_srch_ctc_lit__apl_dt = new String[0];  //[O] 홈페이지계약조회_계약목록_청약일자 SO_CHUNGYAK_YMD 청약일자
	public String[] hpg_ctc_srch_ctc_lit__plhd_cust_dcmt_no = new String[0];  //[O] 홈페이지계약조회_계약목록_계약자고객식별번호 SO_GYE_NO 계약자주민번호
	public String[] hpg_ctc_srch_ctc_lit__ins_cust_dcmt_no = new String[0];  //[O] 홈페이지계약조회_계약목록_피보험자고객식별번호 SO_PIB_NO 피보험자주민번호
	public String[] hpg_ctc_srch_ctc_lit__hdlr_empno = new String[0];  //[O] 홈페이지계약조회_계약목록_취급자사원번호 SO_CHIGPJA_CD 취급자코드
	public String[] hpg_ctc_srch_ctc_lit__hdlr_nm = new String[0];  //[O] 홈페이지계약조회_계약목록_취급자명 HO_PA_NAME 취급자명
	public String[] hpg_ctc_srch_ctc_lit__agnc_mtu = new String[0];  //[O] 홈페이지계약조회_계약목록_대리점상호 HO_SANGHO 대리점상호
	public String[] hpg_ctc_srch_ctc_lit__hdlr_clp_arno = new String[0];  //[O] 홈페이지계약조회_계약목록_취급자휴대폰지역번호  
	public String[] hpg_ctc_srch_ctc_lit__hdlr_clp_ofno = new String[0];  //[O] 홈페이지계약조회_계약목록_취급자휴대폰국번호  
	public String[] hpg_ctc_srch_ctc_lit__hdlr_clp_idvno = new String[0];  //[O] 홈페이지계약조회_계약목록_취급자휴대폰개별번호  
	public String[] hpg_ctc_srch_ctc_lit__hdlr_eml_adr = new String[0];  //[O] 홈페이지계약조회_계약목록_취급자이메일주소 SO_PA_MAIL 취급자메일
	public String[] hpg_ctc_srch_ctc_lit__bzlv_no = new String[0];  //[O] 홈페이지계약조회_계약목록_사업단번호 SO_JIJUM_CD 지점코드
	public String[] hpg_ctc_srch_ctc_lit__bzlv_nm = new String[0];  //[O] 홈페이지계약조회_계약목록_사업단명 HO_JIJUM 지점명
	public String[] hpg_ctc_srch_ctc_lit__bh_no = new String[0];  //[O] 홈페이지계약조회_계약목록_지점번호 SO_JIBU_CD 지부코드
	public String[] hpg_ctc_srch_ctc_lit__bh_nm = new String[0];  //[O] 홈페이지계약조회_계약목록_지점명 HO_JIBU 지부명
	public String[] hpg_ctc_srch_ctc_lit__hdqt_tlp_arno = new String[0];  //[O] 홈페이지계약조회_계약목록_본부전화지역번호  
	public String[] hpg_ctc_srch_ctc_lit__hdqt_tlp_ofno = new String[0];  //[O] 홈페이지계약조회_계약목록_본부전화국번호  
	public String[] hpg_ctc_srch_ctc_lit__hdqt_tlp_idvno = new String[0];  //[O] 홈페이지계약조회_계약목록_본부전화개별번호  
	public String[] hpg_ctc_srch_ctc_lit__bzlv_tlp_arno = new String[0];  //[O] 홈페이지계약조회_계약목록_사업단전화지역번호  
	public String[] hpg_ctc_srch_ctc_lit__bzlv_tlp_ofno = new String[0];  //[O] 홈페이지계약조회_계약목록_사업단전화국번호  
	public String[] hpg_ctc_srch_ctc_lit__bzlv_tlp_idvno = new String[0];  //[O] 홈페이지계약조회_계약목록_사업단전화개별번호  
	public String[] hpg_ctc_srch_ctc_lit__bh_tlp_arno = new String[0];  //[O] 홈페이지계약조회_계약목록_지점전화지역번호  
	public String[] hpg_ctc_srch_ctc_lit__bh_tlp_ofno = new String[0];  //[O] 홈페이지계약조회_계약목록_지점전화국번호  
	public String[] hpg_ctc_srch_ctc_lit__bh_tlp_idvno = new String[0];  //[O] 홈페이지계약조회_계약목록_지점전화개별번호  
	public String[] hpg_ctc_srch_ctc_lit__brc_tlp_arno = new String[0];  //[O] 홈페이지계약조회_계약목록_출장소전화지역번호  
	public String[] hpg_ctc_srch_ctc_lit__brc_tlp_ofno = new String[0];  //[O] 홈페이지계약조회_계약목록_출장소전화국번호  
	public String[] hpg_ctc_srch_ctc_lit__brc_tlp_idvno = new String[0];  //[O] 홈페이지계약조회_계약목록_출장소전화개별번호  
	public String[] hpg_ctc_srch_ctc_lit__hdlr_tlp_arno = new String[0];  //[O] 홈페이지계약조회_계약목록_취급자전화지역번호  
	public String[] hpg_ctc_srch_ctc_lit__hdlr_tlp_ofno = new String[0];  //[O] 홈페이지계약조회_계약목록_취급자전화국번호  
	public String[] hpg_ctc_srch_ctc_lit__hdlr_tlp_idvno = new String[0];  //[O] 홈페이지계약조회_계약목록_취급자전화개별번호  
	public String[] hpg_ctc_srch_ctc_lit__coll_mtd_cd = new String[0];  //[O] 홈페이지계약조회_계약목록_수금방법코드 SO_IPCHULGM_CD 입출금코드
	public String[] hpg_ctc_srch_ctc_lit__coll_mtd_cd_nm = new String[0];  //[O] 홈페이지계약조회_계약목록_수금방법코드명 HO_IPCHULGM_NM 입출금명
	public String[] hpg_ctc_srch_ctc_lit__fnal_pym_ym = new String[0];  //[O] 홈페이지계약조회_계약목록_최종납입년월 SO_LAST_NAPIP_YM 최종납입년월
	public String[] hpg_ctc_srch_ctc_lit__fnal_pym_nts = new String[0];  //[O] 홈페이지계약조회_계약목록_최종납입횟수 SO_LAST_NAPIP_CNT 최종납입횟수
	public String[] hpg_ctc_srch_ctc_lit__pym_mtd_cd = new String[0];  //[O] 홈페이지계약조회_계약목록_납입방법코드 SO_NAPIP_BANG_CD 납입방법코드
	public String[] hpg_ctc_srch_ctc_lit__pym_mtd_nm = new String[0];  //[O] 홈페이지계약조회_계약목록_납입방법명 HO_NAPIP_BANG_NM 납입방법명
	public String[] hpg_ctc_srch_ctc_lit__plus_2_tty_eny_yn = new String[0];  //[O] 홈페이지계약조회_계약목록_플러스2특약가입여부 SO_PLUS2_YN 플러스Ⅱ특약가입여부
	
	public String z_next_page_exis_yn;//페이징 처리 - 다음 페이지 존재 여부(존재 : 1, 존재 안함 :0)
	public String z_user_page_key_set;
	public String prev_z_user_page_key_set;
	public String page_action_type;
	public String z_rqst_page_no;	
	public String z_wh_page_cnt;
	
	public String cust_hngl_nm = ""; // 운전자명

	public String evt_ctc_str_dt = ""; // 이벤트계약시작일자
	public String evt_tgt_cust_yn = ""; // 이벤트대상고객여부
	
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String[] getHpg_ctc_srch_ctc_lit__inpd_dvcd() {
		return hpg_ctc_srch_ctc_lit__inpd_dvcd;
	}
	public void setHpg_ctc_srch_ctc_lit__inpd_dvcd(
			String[] hpg_ctc_srch_ctc_lit__inpd_dvcd) {
		this.hpg_ctc_srch_ctc_lit__inpd_dvcd = hpg_ctc_srch_ctc_lit__inpd_dvcd;
	}
	public String[] getHpg_ctc_srch_ctc_lit__pdc_cd() {
		return hpg_ctc_srch_ctc_lit__pdc_cd;
	}
	public void setHpg_ctc_srch_ctc_lit__pdc_cd(
			String[] hpg_ctc_srch_ctc_lit__pdc_cd) {
		this.hpg_ctc_srch_ctc_lit__pdc_cd = hpg_ctc_srch_ctc_lit__pdc_cd;
	}
	public String[] getHpg_ctc_srch_ctc_lit__ctc_rlps_dvcd() {
		return hpg_ctc_srch_ctc_lit__ctc_rlps_dvcd;
	}
	public void setHpg_ctc_srch_ctc_lit__ctc_rlps_dvcd(
			String[] hpg_ctc_srch_ctc_lit__ctc_rlps_dvcd) {
		this.hpg_ctc_srch_ctc_lit__ctc_rlps_dvcd = hpg_ctc_srch_ctc_lit__ctc_rlps_dvcd;
	}
	public String[] getHpg_ctc_srch_ctc_lit__plhd_nm() {
		return hpg_ctc_srch_ctc_lit__plhd_nm;
	}
	public void setHpg_ctc_srch_ctc_lit__plhd_nm(
			String[] hpg_ctc_srch_ctc_lit__plhd_nm) {
		this.hpg_ctc_srch_ctc_lit__plhd_nm = hpg_ctc_srch_ctc_lit__plhd_nm;
	}
	public String[] getHpg_ctc_srch_ctc_lit__ins_nm() {
		return hpg_ctc_srch_ctc_lit__ins_nm;
	}
	public void setHpg_ctc_srch_ctc_lit__ins_nm(
			String[] hpg_ctc_srch_ctc_lit__ins_nm) {
		this.hpg_ctc_srch_ctc_lit__ins_nm = hpg_ctc_srch_ctc_lit__ins_nm;
	}
	public String[] getHpg_ctc_srch_ctc_lit__plno() {
		return hpg_ctc_srch_ctc_lit__plno;
	}
	public void setHpg_ctc_srch_ctc_lit__plno(String[] hpg_ctc_srch_ctc_lit__plno) {
		this.hpg_ctc_srch_ctc_lit__plno = hpg_ctc_srch_ctc_lit__plno;
	}
	public String[] getHpg_ctc_srch_ctc_lit__ins_lcpl_dvcd() {
		return hpg_ctc_srch_ctc_lit__ins_lcpl_dvcd;
	}
	public void setHpg_ctc_srch_ctc_lit__ins_lcpl_dvcd(
			String[] hpg_ctc_srch_ctc_lit__ins_lcpl_dvcd) {
		this.hpg_ctc_srch_ctc_lit__ins_lcpl_dvcd = hpg_ctc_srch_ctc_lit__ins_lcpl_dvcd;
	}
	public String[] getHpg_ctc_srch_ctc_lit__ply_sqno() {
		return hpg_ctc_srch_ctc_lit__ply_sqno;
	}
	public void setHpg_ctc_srch_ctc_lit__ply_sqno(
			String[] hpg_ctc_srch_ctc_lit__ply_sqno) {
		this.hpg_ctc_srch_ctc_lit__ply_sqno = hpg_ctc_srch_ctc_lit__ply_sqno;
	}
	public String[] getHpg_ctc_srch_ctc_lit__hngl_vh_no() {
		return hpg_ctc_srch_ctc_lit__hngl_vh_no;
	}
	public void setHpg_ctc_srch_ctc_lit__hngl_vh_no(
			String[] hpg_ctc_srch_ctc_lit__hngl_vh_no) {
		this.hpg_ctc_srch_ctc_lit__hngl_vh_no = hpg_ctc_srch_ctc_lit__hngl_vh_no;
	}
	public String[] getHpg_ctc_srch_ctc_lit__pdc_nm() {
		return hpg_ctc_srch_ctc_lit__pdc_nm;
	}
	public void setHpg_ctc_srch_ctc_lit__pdc_nm(
			String[] hpg_ctc_srch_ctc_lit__pdc_nm) {
		this.hpg_ctc_srch_ctc_lit__pdc_nm = hpg_ctc_srch_ctc_lit__pdc_nm;
	}
	public String[] getHpg_ctc_srch_ctc_lit__arc_trm_str_dt() {
		return hpg_ctc_srch_ctc_lit__arc_trm_str_dt;
	}
	public void setHpg_ctc_srch_ctc_lit__arc_trm_str_dt(
			String[] hpg_ctc_srch_ctc_lit__arc_trm_str_dt) {
		this.hpg_ctc_srch_ctc_lit__arc_trm_str_dt = hpg_ctc_srch_ctc_lit__arc_trm_str_dt;
	}
	public String[] getHpg_ctc_srch_ctc_lit__arc_trm_fin_dt() {
		return hpg_ctc_srch_ctc_lit__arc_trm_fin_dt;
	}
	public void setHpg_ctc_srch_ctc_lit__arc_trm_fin_dt(
			String[] hpg_ctc_srch_ctc_lit__arc_trm_fin_dt) {
		this.hpg_ctc_srch_ctc_lit__arc_trm_fin_dt = hpg_ctc_srch_ctc_lit__arc_trm_fin_dt;
	}
	public String[] getHpg_ctc_srch_ctc_lit__ctc_stat_nm() {
		return hpg_ctc_srch_ctc_lit__ctc_stat_nm;
	}
	public void setHpg_ctc_srch_ctc_lit__ctc_stat_nm(
			String[] hpg_ctc_srch_ctc_lit__ctc_stat_nm) {
		this.hpg_ctc_srch_ctc_lit__ctc_stat_nm = hpg_ctc_srch_ctc_lit__ctc_stat_nm;
	}
	public String[] getHpg_ctc_srch_ctc_lit__sl_pan_cd() {
		return hpg_ctc_srch_ctc_lit__sl_pan_cd;
	}
	public void setHpg_ctc_srch_ctc_lit__sl_pan_cd(
			String[] hpg_ctc_srch_ctc_lit__sl_pan_cd) {
		this.hpg_ctc_srch_ctc_lit__sl_pan_cd = hpg_ctc_srch_ctc_lit__sl_pan_cd;
	}
	public String[] getHpg_ctc_srch_ctc_lit__apl_dt() {
		return hpg_ctc_srch_ctc_lit__apl_dt;
	}
	public void setHpg_ctc_srch_ctc_lit__apl_dt(
			String[] hpg_ctc_srch_ctc_lit__apl_dt) {
		this.hpg_ctc_srch_ctc_lit__apl_dt = hpg_ctc_srch_ctc_lit__apl_dt;
	}
	public String[] getHpg_ctc_srch_ctc_lit__plhd_cust_dcmt_no() {
		return hpg_ctc_srch_ctc_lit__plhd_cust_dcmt_no;
	}
	public void setHpg_ctc_srch_ctc_lit__plhd_cust_dcmt_no(
			String[] hpg_ctc_srch_ctc_lit__plhd_cust_dcmt_no) {
		this.hpg_ctc_srch_ctc_lit__plhd_cust_dcmt_no = hpg_ctc_srch_ctc_lit__plhd_cust_dcmt_no;
	}
	public String[] getHpg_ctc_srch_ctc_lit__ins_cust_dcmt_no() {
		return hpg_ctc_srch_ctc_lit__ins_cust_dcmt_no;
	}
	public void setHpg_ctc_srch_ctc_lit__ins_cust_dcmt_no(
			String[] hpg_ctc_srch_ctc_lit__ins_cust_dcmt_no) {
		this.hpg_ctc_srch_ctc_lit__ins_cust_dcmt_no = hpg_ctc_srch_ctc_lit__ins_cust_dcmt_no;
	}
	public String[] getHpg_ctc_srch_ctc_lit__hdlr_empno() {
		return hpg_ctc_srch_ctc_lit__hdlr_empno;
	}
	public void setHpg_ctc_srch_ctc_lit__hdlr_empno(
			String[] hpg_ctc_srch_ctc_lit__hdlr_empno) {
		this.hpg_ctc_srch_ctc_lit__hdlr_empno = hpg_ctc_srch_ctc_lit__hdlr_empno;
	}
	public String[] getHpg_ctc_srch_ctc_lit__hdlr_nm() {
		return hpg_ctc_srch_ctc_lit__hdlr_nm;
	}
	public void setHpg_ctc_srch_ctc_lit__hdlr_nm(
			String[] hpg_ctc_srch_ctc_lit__hdlr_nm) {
		this.hpg_ctc_srch_ctc_lit__hdlr_nm = hpg_ctc_srch_ctc_lit__hdlr_nm;
	}
	public String[] getHpg_ctc_srch_ctc_lit__agnc_mtu() {
		return hpg_ctc_srch_ctc_lit__agnc_mtu;
	}
	public void setHpg_ctc_srch_ctc_lit__agnc_mtu(
			String[] hpg_ctc_srch_ctc_lit__agnc_mtu) {
		this.hpg_ctc_srch_ctc_lit__agnc_mtu = hpg_ctc_srch_ctc_lit__agnc_mtu;
	}
	public String[] getHpg_ctc_srch_ctc_lit__hdlr_clp_arno() {
		return hpg_ctc_srch_ctc_lit__hdlr_clp_arno;
	}
	public void setHpg_ctc_srch_ctc_lit__hdlr_clp_arno(
			String[] hpg_ctc_srch_ctc_lit__hdlr_clp_arno) {
		this.hpg_ctc_srch_ctc_lit__hdlr_clp_arno = hpg_ctc_srch_ctc_lit__hdlr_clp_arno;
	}
	public String[] getHpg_ctc_srch_ctc_lit__hdlr_clp_ofno() {
		return hpg_ctc_srch_ctc_lit__hdlr_clp_ofno;
	}
	public void setHpg_ctc_srch_ctc_lit__hdlr_clp_ofno(
			String[] hpg_ctc_srch_ctc_lit__hdlr_clp_ofno) {
		this.hpg_ctc_srch_ctc_lit__hdlr_clp_ofno = hpg_ctc_srch_ctc_lit__hdlr_clp_ofno;
	}
	public String[] getHpg_ctc_srch_ctc_lit__hdlr_clp_idvno() {
		return hpg_ctc_srch_ctc_lit__hdlr_clp_idvno;
	}
	public void setHpg_ctc_srch_ctc_lit__hdlr_clp_idvno(
			String[] hpg_ctc_srch_ctc_lit__hdlr_clp_idvno) {
		this.hpg_ctc_srch_ctc_lit__hdlr_clp_idvno = hpg_ctc_srch_ctc_lit__hdlr_clp_idvno;
	}
	public String[] getHpg_ctc_srch_ctc_lit__hdlr_eml_adr() {
		return hpg_ctc_srch_ctc_lit__hdlr_eml_adr;
	}
	public void setHpg_ctc_srch_ctc_lit__hdlr_eml_adr(
			String[] hpg_ctc_srch_ctc_lit__hdlr_eml_adr) {
		this.hpg_ctc_srch_ctc_lit__hdlr_eml_adr = hpg_ctc_srch_ctc_lit__hdlr_eml_adr;
	}
	public String[] getHpg_ctc_srch_ctc_lit__bzlv_no() {
		return hpg_ctc_srch_ctc_lit__bzlv_no;
	}
	public void setHpg_ctc_srch_ctc_lit__bzlv_no(
			String[] hpg_ctc_srch_ctc_lit__bzlv_no) {
		this.hpg_ctc_srch_ctc_lit__bzlv_no = hpg_ctc_srch_ctc_lit__bzlv_no;
	}
	public String[] getHpg_ctc_srch_ctc_lit__bzlv_nm() {
		return hpg_ctc_srch_ctc_lit__bzlv_nm;
	}
	public void setHpg_ctc_srch_ctc_lit__bzlv_nm(
			String[] hpg_ctc_srch_ctc_lit__bzlv_nm) {
		this.hpg_ctc_srch_ctc_lit__bzlv_nm = hpg_ctc_srch_ctc_lit__bzlv_nm;
	}
	public String[] getHpg_ctc_srch_ctc_lit__bh_no() {
		return hpg_ctc_srch_ctc_lit__bh_no;
	}
	public void setHpg_ctc_srch_ctc_lit__bh_no(String[] hpg_ctc_srch_ctc_lit__bh_no) {
		this.hpg_ctc_srch_ctc_lit__bh_no = hpg_ctc_srch_ctc_lit__bh_no;
	}
	public String[] getHpg_ctc_srch_ctc_lit__bh_nm() {
		return hpg_ctc_srch_ctc_lit__bh_nm;
	}
	public void setHpg_ctc_srch_ctc_lit__bh_nm(String[] hpg_ctc_srch_ctc_lit__bh_nm) {
		this.hpg_ctc_srch_ctc_lit__bh_nm = hpg_ctc_srch_ctc_lit__bh_nm;
	}
	public String[] getHpg_ctc_srch_ctc_lit__hdqt_tlp_arno() {
		return hpg_ctc_srch_ctc_lit__hdqt_tlp_arno;
	}
	public void setHpg_ctc_srch_ctc_lit__hdqt_tlp_arno(
			String[] hpg_ctc_srch_ctc_lit__hdqt_tlp_arno) {
		this.hpg_ctc_srch_ctc_lit__hdqt_tlp_arno = hpg_ctc_srch_ctc_lit__hdqt_tlp_arno;
	}
	public String[] getHpg_ctc_srch_ctc_lit__hdqt_tlp_ofno() {
		return hpg_ctc_srch_ctc_lit__hdqt_tlp_ofno;
	}
	public void setHpg_ctc_srch_ctc_lit__hdqt_tlp_ofno(
			String[] hpg_ctc_srch_ctc_lit__hdqt_tlp_ofno) {
		this.hpg_ctc_srch_ctc_lit__hdqt_tlp_ofno = hpg_ctc_srch_ctc_lit__hdqt_tlp_ofno;
	}
	public String[] getHpg_ctc_srch_ctc_lit__hdqt_tlp_idvno() {
		return hpg_ctc_srch_ctc_lit__hdqt_tlp_idvno;
	}
	public void setHpg_ctc_srch_ctc_lit__hdqt_tlp_idvno(
			String[] hpg_ctc_srch_ctc_lit__hdqt_tlp_idvno) {
		this.hpg_ctc_srch_ctc_lit__hdqt_tlp_idvno = hpg_ctc_srch_ctc_lit__hdqt_tlp_idvno;
	}
	public String[] getHpg_ctc_srch_ctc_lit__bzlv_tlp_arno() {
		return hpg_ctc_srch_ctc_lit__bzlv_tlp_arno;
	}
	public void setHpg_ctc_srch_ctc_lit__bzlv_tlp_arno(
			String[] hpg_ctc_srch_ctc_lit__bzlv_tlp_arno) {
		this.hpg_ctc_srch_ctc_lit__bzlv_tlp_arno = hpg_ctc_srch_ctc_lit__bzlv_tlp_arno;
	}
	public String[] getHpg_ctc_srch_ctc_lit__bzlv_tlp_ofno() {
		return hpg_ctc_srch_ctc_lit__bzlv_tlp_ofno;
	}
	public void setHpg_ctc_srch_ctc_lit__bzlv_tlp_ofno(
			String[] hpg_ctc_srch_ctc_lit__bzlv_tlp_ofno) {
		this.hpg_ctc_srch_ctc_lit__bzlv_tlp_ofno = hpg_ctc_srch_ctc_lit__bzlv_tlp_ofno;
	}
	public String[] getHpg_ctc_srch_ctc_lit__bzlv_tlp_idvno() {
		return hpg_ctc_srch_ctc_lit__bzlv_tlp_idvno;
	}
	public void setHpg_ctc_srch_ctc_lit__bzlv_tlp_idvno(
			String[] hpg_ctc_srch_ctc_lit__bzlv_tlp_idvno) {
		this.hpg_ctc_srch_ctc_lit__bzlv_tlp_idvno = hpg_ctc_srch_ctc_lit__bzlv_tlp_idvno;
	}
	public String[] getHpg_ctc_srch_ctc_lit__bh_tlp_arno() {
		return hpg_ctc_srch_ctc_lit__bh_tlp_arno;
	}
	public void setHpg_ctc_srch_ctc_lit__bh_tlp_arno(
			String[] hpg_ctc_srch_ctc_lit__bh_tlp_arno) {
		this.hpg_ctc_srch_ctc_lit__bh_tlp_arno = hpg_ctc_srch_ctc_lit__bh_tlp_arno;
	}
	public String[] getHpg_ctc_srch_ctc_lit__bh_tlp_ofno() {
		return hpg_ctc_srch_ctc_lit__bh_tlp_ofno;
	}
	public void setHpg_ctc_srch_ctc_lit__bh_tlp_ofno(
			String[] hpg_ctc_srch_ctc_lit__bh_tlp_ofno) {
		this.hpg_ctc_srch_ctc_lit__bh_tlp_ofno = hpg_ctc_srch_ctc_lit__bh_tlp_ofno;
	}
	public String[] getHpg_ctc_srch_ctc_lit__bh_tlp_idvno() {
		return hpg_ctc_srch_ctc_lit__bh_tlp_idvno;
	}
	public void setHpg_ctc_srch_ctc_lit__bh_tlp_idvno(
			String[] hpg_ctc_srch_ctc_lit__bh_tlp_idvno) {
		this.hpg_ctc_srch_ctc_lit__bh_tlp_idvno = hpg_ctc_srch_ctc_lit__bh_tlp_idvno;
	}
	public String[] getHpg_ctc_srch_ctc_lit__brc_tlp_arno() {
		return hpg_ctc_srch_ctc_lit__brc_tlp_arno;
	}
	public void setHpg_ctc_srch_ctc_lit__brc_tlp_arno(
			String[] hpg_ctc_srch_ctc_lit__brc_tlp_arno) {
		this.hpg_ctc_srch_ctc_lit__brc_tlp_arno = hpg_ctc_srch_ctc_lit__brc_tlp_arno;
	}
	public String[] getHpg_ctc_srch_ctc_lit__brc_tlp_ofno() {
		return hpg_ctc_srch_ctc_lit__brc_tlp_ofno;
	}
	public void setHpg_ctc_srch_ctc_lit__brc_tlp_ofno(
			String[] hpg_ctc_srch_ctc_lit__brc_tlp_ofno) {
		this.hpg_ctc_srch_ctc_lit__brc_tlp_ofno = hpg_ctc_srch_ctc_lit__brc_tlp_ofno;
	}
	public String[] getHpg_ctc_srch_ctc_lit__brc_tlp_idvno() {
		return hpg_ctc_srch_ctc_lit__brc_tlp_idvno;
	}
	public void setHpg_ctc_srch_ctc_lit__brc_tlp_idvno(
			String[] hpg_ctc_srch_ctc_lit__brc_tlp_idvno) {
		this.hpg_ctc_srch_ctc_lit__brc_tlp_idvno = hpg_ctc_srch_ctc_lit__brc_tlp_idvno;
	}
	public String[] getHpg_ctc_srch_ctc_lit__hdlr_tlp_arno() {
		return hpg_ctc_srch_ctc_lit__hdlr_tlp_arno;
	}
	public void setHpg_ctc_srch_ctc_lit__hdlr_tlp_arno(
			String[] hpg_ctc_srch_ctc_lit__hdlr_tlp_arno) {
		this.hpg_ctc_srch_ctc_lit__hdlr_tlp_arno = hpg_ctc_srch_ctc_lit__hdlr_tlp_arno;
	}
	public String[] getHpg_ctc_srch_ctc_lit__hdlr_tlp_ofno() {
		return hpg_ctc_srch_ctc_lit__hdlr_tlp_ofno;
	}
	public void setHpg_ctc_srch_ctc_lit__hdlr_tlp_ofno(
			String[] hpg_ctc_srch_ctc_lit__hdlr_tlp_ofno) {
		this.hpg_ctc_srch_ctc_lit__hdlr_tlp_ofno = hpg_ctc_srch_ctc_lit__hdlr_tlp_ofno;
	}
	public String[] getHpg_ctc_srch_ctc_lit__hdlr_tlp_idvno() {
		return hpg_ctc_srch_ctc_lit__hdlr_tlp_idvno;
	}
	public void setHpg_ctc_srch_ctc_lit__hdlr_tlp_idvno(
			String[] hpg_ctc_srch_ctc_lit__hdlr_tlp_idvno) {
		this.hpg_ctc_srch_ctc_lit__hdlr_tlp_idvno = hpg_ctc_srch_ctc_lit__hdlr_tlp_idvno;
	}
	public String[] getHpg_ctc_srch_ctc_lit__coll_mtd_cd() {
		return hpg_ctc_srch_ctc_lit__coll_mtd_cd;
	}
	public void setHpg_ctc_srch_ctc_lit__coll_mtd_cd(
			String[] hpg_ctc_srch_ctc_lit__coll_mtd_cd) {
		this.hpg_ctc_srch_ctc_lit__coll_mtd_cd = hpg_ctc_srch_ctc_lit__coll_mtd_cd;
	}
	public String[] getHpg_ctc_srch_ctc_lit__coll_mtd_cd_nm() {
		return hpg_ctc_srch_ctc_lit__coll_mtd_cd_nm;
	}
	public void setHpg_ctc_srch_ctc_lit__coll_mtd_cd_nm(
			String[] hpg_ctc_srch_ctc_lit__coll_mtd_cd_nm) {
		this.hpg_ctc_srch_ctc_lit__coll_mtd_cd_nm = hpg_ctc_srch_ctc_lit__coll_mtd_cd_nm;
	}
	public String[] getHpg_ctc_srch_ctc_lit__fnal_pym_ym() {
		return hpg_ctc_srch_ctc_lit__fnal_pym_ym;
	}
	public void setHpg_ctc_srch_ctc_lit__fnal_pym_ym(
			String[] hpg_ctc_srch_ctc_lit__fnal_pym_ym) {
		this.hpg_ctc_srch_ctc_lit__fnal_pym_ym = hpg_ctc_srch_ctc_lit__fnal_pym_ym;
	}
	public String[] getHpg_ctc_srch_ctc_lit__fnal_pym_nts() {
		return hpg_ctc_srch_ctc_lit__fnal_pym_nts;
	}
	public void setHpg_ctc_srch_ctc_lit__fnal_pym_nts(
			String[] hpg_ctc_srch_ctc_lit__fnal_pym_nts) {
		this.hpg_ctc_srch_ctc_lit__fnal_pym_nts = hpg_ctc_srch_ctc_lit__fnal_pym_nts;
	}
	public String[] getHpg_ctc_srch_ctc_lit__pym_mtd_cd() {
		return hpg_ctc_srch_ctc_lit__pym_mtd_cd;
	}
	public void setHpg_ctc_srch_ctc_lit__pym_mtd_cd(
			String[] hpg_ctc_srch_ctc_lit__pym_mtd_cd) {
		this.hpg_ctc_srch_ctc_lit__pym_mtd_cd = hpg_ctc_srch_ctc_lit__pym_mtd_cd;
	}
	public String[] getHpg_ctc_srch_ctc_lit__pym_mtd_nm() {
		return hpg_ctc_srch_ctc_lit__pym_mtd_nm;
	}
	public void setHpg_ctc_srch_ctc_lit__pym_mtd_nm(
			String[] hpg_ctc_srch_ctc_lit__pym_mtd_nm) {
		this.hpg_ctc_srch_ctc_lit__pym_mtd_nm = hpg_ctc_srch_ctc_lit__pym_mtd_nm;
	}
	public String[] getHpg_ctc_srch_ctc_lit__plus_2_tty_eny_yn() {
		return hpg_ctc_srch_ctc_lit__plus_2_tty_eny_yn;
	}
	public void setHpg_ctc_srch_ctc_lit__plus_2_tty_eny_yn(
			String[] hpg_ctc_srch_ctc_lit__plus_2_tty_eny_yn) {
		this.hpg_ctc_srch_ctc_lit__plus_2_tty_eny_yn = hpg_ctc_srch_ctc_lit__plus_2_tty_eny_yn;
	}
	public String getCust_dcmt_no() {
		return cust_dcmt_no;
	}
	public void setCust_dcmt_no(String cust_dcmt_no) {
		this.cust_dcmt_no = cust_dcmt_no;
	}
	public String getSrch_dvn() {
		return srch_dvn;
	}
	public void setSrch_dvn(String srch_dvn) {
		this.srch_dvn = srch_dvn;
	}
	public String getZ_next_page_exis_yn() {
		return z_next_page_exis_yn;
	}
	public void setZ_next_page_exis_yn(String z_next_page_exis_yn) {
		this.z_next_page_exis_yn = z_next_page_exis_yn;
	}
	public String getZ_user_page_key_set() {
		return z_user_page_key_set;
	}
	public void setZ_user_page_key_set(String z_user_page_key_set) {
		this.z_user_page_key_set = z_user_page_key_set;
	}
	public String getPrev_z_user_page_key_set() {
		return prev_z_user_page_key_set;
	}
	public void setPrev_z_user_page_key_set(String prev_z_user_page_key_set) {
		this.prev_z_user_page_key_set = prev_z_user_page_key_set;
	}
	public String getPage_action_type() {
		return page_action_type;
	}
	public void setPage_action_type(String page_action_type) {
		this.page_action_type = page_action_type;
	}
	public String getZ_rqst_page_no() {
		return z_rqst_page_no;
	}
	public void setZ_rqst_page_no(String z_rqst_page_no) {
		this.z_rqst_page_no = z_rqst_page_no;
	}
	public String getZ_wh_page_cnt() {
		return z_wh_page_cnt;
	}
	public void setZ_wh_page_cnt(String z_wh_page_cnt) {
		this.z_wh_page_cnt = z_wh_page_cnt;
	}
	
	
	//public List<SubKCUS0006> getLIST_DATA() {
	//	return LIST_DATA;
	//}
	//public void setLIST_DATA(List<SubKCUS0006> lIST_DATA) {
	//	LIST_DATA = lIST_DATA;
	//}
	
	public String getCust_hngl_nm() {
		return cust_hngl_nm;
	}

	public void setCust_hngl_nm(String cust_hngl_nm) {
		this.cust_hngl_nm = cust_hngl_nm;
	}

	public String getEvt_ctc_str_dt() {
		return evt_ctc_str_dt;
	}

	public void setEvt_ctc_str_dt(String evt_ctc_str_dt) {
		this.evt_ctc_str_dt = evt_ctc_str_dt;
	}

	public String getEvt_tgt_cust_yn() {
		return evt_tgt_cust_yn;
	}

	public void setEvt_tgt_cust_yn(String evt_tgt_cust_yn) {
		this.evt_tgt_cust_yn = evt_tgt_cust_yn;
	}

}
