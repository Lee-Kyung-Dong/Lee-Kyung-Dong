package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class AACT0019VO extends CMMVO
{
	//전문필드
	public String crd_no = null;		// 카드번호
	public String vlid_trm = null;		// 유효기간
	public String rrno = null;			// 주민번호
	public String msg_cd = null;		// 메시지코드
	public String msg_cn = null;		// 메시지내용
	public String vn_dvn = null;		// VAN사구분
	public String getCrd_no() {
		return crd_no;
	}
	public void setCrd_no(String crd_no) {
		this.crd_no = crd_no;
	}
	public String getVlid_trm() {
		return vlid_trm;
	}
	public void setVlid_trm(String vlid_trm) {
		this.vlid_trm = vlid_trm;
	}
	public String getRrno() {
		return rrno;
	}
	public void setRrno(String rrno) {
		this.rrno = rrno;
	}
	public String getMsg_cd() {
		return msg_cd;
	}
	public void setMsg_cd(String msg_cd) {
		this.msg_cd = msg_cd;
	}
	public String getMsg_cn() {
		return msg_cn;
	}
	public void setMsg_cn(String msg_cn) {
		this.msg_cn = msg_cn;
	}
	public String getVn_dvn() {
		return vn_dvn;
	}
	public void setVn_dvn(String vn_dvn) {
		this.vn_dvn = vn_dvn;
	}
	
	

}
