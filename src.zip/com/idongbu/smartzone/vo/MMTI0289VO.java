package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class MMTI0289VO extends CMMVO{
	
	//전문필드
	public String mbl_snd_no = "";		// [I/O] 모바일발송번호
	public String mbl_bz_dvcd = "";		// [O] 모바일업무구분코드 01:자차추가, 02:계약사진, 35:베이비인카가입서류, 43:차선이탈경고장치
	public String plan_plno_dvcd = "";	// [O] 설계증권번호구분코드
	public String plan_plno = "";		// [O] 설계증권번호
	public String vh_no = "";			// [O] 차량번호
	public String plno = "";			// [O] 증권번호(변경설계시 사용)
	public String mbl_ts_dtl_dvcd = "";	// [O] 모바일전송상세구분코드 01:신규, 03:변경
	
	public String getMbl_snd_no() {
		return mbl_snd_no;
	}
	public void setMbl_snd_no(String mbl_snd_no) {
		this.mbl_snd_no = mbl_snd_no;
	}
	public String getMbl_bz_dvcd() {
		return mbl_bz_dvcd;
	}
	public void setMbl_bz_dvcd(String mbl_bz_dvcd) {
		this.mbl_bz_dvcd = mbl_bz_dvcd;
	}
	public String getPlan_plno_dvcd() {
		return plan_plno_dvcd;
	}
	public void setPlan_plno_dvcd(String plan_plno_dvcd) {
		this.plan_plno_dvcd = plan_plno_dvcd;
	}
	public String getPlan_plno() {
		return plan_plno;
	}
	public void setPlan_plno(String plan_plno) {
		this.plan_plno = plan_plno;
	}
	public String getVh_no() {
		return vh_no;
	}
	public void setVh_no(String vh_no) {
		this.vh_no = vh_no;
	}
	public String getPlno() {
		return plno;
	}
	public void setPlno(String plno) {
		this.plno = plno;
	}
	public String getMbl_ts_dtl_dvcd() {
		return mbl_ts_dtl_dvcd;
	}
	public void setMbl_ts_dtl_dvcd(String mbl_ts_dtl_dvcd) {
		this.mbl_ts_dtl_dvcd = mbl_ts_dtl_dvcd;
	}
	
}
