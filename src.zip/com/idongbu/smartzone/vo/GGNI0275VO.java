package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

/**
 * @author 81500204
 * 
 * 모바일_일반설계상세조회
 */
public class GGNI0275VO extends CMMVO {
	public String plan_no = ""; // 설계번호
	public String plno = ""; // 증권번호
	public String ctrmf_sqno = ""; // 계약변경일련번호
	public String inpd_cd = ""; // 보종코드
	public String pdc_cd = ""; // 상품코드
	public String hdlr_empno = ""; // 취급자사원번호
	public String plhd_rsdn_no = ""; // 계약자주민번호
	public String plhd_nm = ""; // 계약자명

	public String gnrl_plan_dtl_srch_lcpl_if__lcpl_sqno[] = new String[0]; // 일반설계상세조회_소재지정보_소재지일련번호
	public String gnrl_plan_dtl_srch_lcpl_if__lcpl_psno[] = new String[0]; // 일반설계상세조회_소재지정보_소재지우편번호
	public String gnrl_plan_dtl_srch_lcpl_if__lcpl_eta_adr[] = new String[0]; // 일반설계상세조회_소재지정보_소재지기타주소

	public String gnrl_plan_dtl_srch_oj_cvr_if__lcpl_sqno[] = new String[0]; // 일반설계상세조회_목적담보정보_소재지일련번호
	public String gnrl_plan_dtl_srch_oj_cvr_if__cvr_cd[] = new String[0]; // 일반설계상세조회_목적담보정보_담보코드
	public String gnrl_plan_dtl_srch_oj_cvr_if__cvr_nm[] = new String[0]; // 일반설계상세조회_목적담보정보_담보명
	public String gnrl_plan_dtl_srch_oj_cvr_if__arc_inam[] = new String[0]; // 일반설계상세조회_목적담보정보_보험가입금액
	public String gnrl_plan_dtl_srch_oj_cvr_if__prm[] = new String[0]; // 일반설계상세조회_목적담보정보_보험료

	public String errorCode = "";
	public String z_resp_msg = "";

	public String getPlan_no() {
		return plan_no;
	}
	public void setPlan_no(String plan_no) {
		this.plan_no = plan_no;
	}
	public String getPlno() {
		return plno;
	}
	public void setPlno(String plno) {
		this.plno = plno;
	}
	public String getCtrmf_sqno() {
		return ctrmf_sqno;
	}
	public void setCtrmf_sqno(String ctrmf_sqno) {
		this.ctrmf_sqno = ctrmf_sqno;
	}
	public String getInpd_cd() {
		return inpd_cd;
	}
	public void setInpd_cd(String inpd_cd) {
		this.inpd_cd = inpd_cd;
	}
	public String getPdc_cd() {
		return pdc_cd;
	}
	public void setPdc_cd(String pdc_cd) {
		this.pdc_cd = pdc_cd;
	}
	public String getHdlr_empno() {
		return hdlr_empno;
	}
	public void setHdlr_empno(String hdlr_empno) {
		this.hdlr_empno = hdlr_empno;
	}
	public String getPlhd_rsdn_no() {
		return plhd_rsdn_no;
	}
	public void setPlhd_rsdn_no(String plhd_rsdn_no) {
		this.plhd_rsdn_no = plhd_rsdn_no;
	}
	public String getPlhd_nm() {
		return plhd_nm;
	}
	public void setPlhd_nm(String plhd_nm) {
		this.plhd_nm = plhd_nm;
	}
	public String[] getGnrl_plan_dtl_srch_lcpl_if__lcpl_sqno() {
		return gnrl_plan_dtl_srch_lcpl_if__lcpl_sqno;
	}
	public void setGnrl_plan_dtl_srch_lcpl_if__lcpl_sqno(
			String[] gnrl_plan_dtl_srch_lcpl_if__lcpl_sqno) {
		this.gnrl_plan_dtl_srch_lcpl_if__lcpl_sqno = gnrl_plan_dtl_srch_lcpl_if__lcpl_sqno;
	}
	public String[] getGnrl_plan_dtl_srch_lcpl_if__lcpl_psno() {
		return gnrl_plan_dtl_srch_lcpl_if__lcpl_psno;
	}
	public void setGnrl_plan_dtl_srch_lcpl_if__lcpl_psno(
			String[] gnrl_plan_dtl_srch_lcpl_if__lcpl_psno) {
		this.gnrl_plan_dtl_srch_lcpl_if__lcpl_psno = gnrl_plan_dtl_srch_lcpl_if__lcpl_psno;
	}
	public String[] getGnrl_plan_dtl_srch_lcpl_if__lcpl_eta_adr() {
		return gnrl_plan_dtl_srch_lcpl_if__lcpl_eta_adr;
	}
	public void setGnrl_plan_dtl_srch_lcpl_if__lcpl_eta_adr(
			String[] gnrl_plan_dtl_srch_lcpl_if__lcpl_eta_adr) {
		this.gnrl_plan_dtl_srch_lcpl_if__lcpl_eta_adr = gnrl_plan_dtl_srch_lcpl_if__lcpl_eta_adr;
	}
	public String[] getGnrl_plan_dtl_srch_oj_cvr_if__lcpl_sqno() {
		return gnrl_plan_dtl_srch_oj_cvr_if__lcpl_sqno;
	}
	public void setGnrl_plan_dtl_srch_oj_cvr_if__lcpl_sqno(
			String[] gnrl_plan_dtl_srch_oj_cvr_if__lcpl_sqno) {
		this.gnrl_plan_dtl_srch_oj_cvr_if__lcpl_sqno = gnrl_plan_dtl_srch_oj_cvr_if__lcpl_sqno;
	}
	public String[] getGnrl_plan_dtl_srch_oj_cvr_if__cvr_cd() {
		return gnrl_plan_dtl_srch_oj_cvr_if__cvr_cd;
	}
	public void setGnrl_plan_dtl_srch_oj_cvr_if__cvr_cd(
			String[] gnrl_plan_dtl_srch_oj_cvr_if__cvr_cd) {
		this.gnrl_plan_dtl_srch_oj_cvr_if__cvr_cd = gnrl_plan_dtl_srch_oj_cvr_if__cvr_cd;
	}
	public String[] getGnrl_plan_dtl_srch_oj_cvr_if__cvr_nm() {
		return gnrl_plan_dtl_srch_oj_cvr_if__cvr_nm;
	}
	public void setGnrl_plan_dtl_srch_oj_cvr_if__cvr_nm(
			String[] gnrl_plan_dtl_srch_oj_cvr_if__cvr_nm) {
		this.gnrl_plan_dtl_srch_oj_cvr_if__cvr_nm = gnrl_plan_dtl_srch_oj_cvr_if__cvr_nm;
	}
	public String[] getGnrl_plan_dtl_srch_oj_cvr_if__arc_inam() {
		return gnrl_plan_dtl_srch_oj_cvr_if__arc_inam;
	}
	public void setGnrl_plan_dtl_srch_oj_cvr_if__arc_inam(
			String[] gnrl_plan_dtl_srch_oj_cvr_if__arc_inam) {
		this.gnrl_plan_dtl_srch_oj_cvr_if__arc_inam = gnrl_plan_dtl_srch_oj_cvr_if__arc_inam;
	}
	public String[] getGnrl_plan_dtl_srch_oj_cvr_if__prm() {
		return gnrl_plan_dtl_srch_oj_cvr_if__prm;
	}
	public void setGnrl_plan_dtl_srch_oj_cvr_if__prm(
			String[] gnrl_plan_dtl_srch_oj_cvr_if__prm) {
		this.gnrl_plan_dtl_srch_oj_cvr_if__prm = gnrl_plan_dtl_srch_oj_cvr_if__prm;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getZ_resp_msg() {
		return z_resp_msg;
	}
	public void setZ_resp_msg(String z_resp_msg) {
		this.z_resp_msg = z_resp_msg;
	}
}
