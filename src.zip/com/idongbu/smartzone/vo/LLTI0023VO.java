package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class LLTI0023VO extends CMMVO {

	//전문필드
		public String plhd_rrno = "";  //[I] 계약자주민등록번호 JJ_GY_JUMIN 계약자주민번호
		public String plhd_nm = "";  //[O] 계약자명 HJ_GY_NM 계약자명
		public String[] ctc_if__plno = new String[0];  //[O] 계약정보_증권번호 JJ_POLI_NO 증권번호
		public String[] ctc_if__pdc_cd = new String[0];  //[O] 계약정보_상품코드 JJ_BJ_CD 보종코드
		public String[] ctc_if__inpd_nm = new String[0];  //[O] 계약정보_보종명 HJ_BJ_NM 보종명
		public String[] ctc_if__arc_pd_dt = new String[0];  //[O] 계약정보_보험시기일자 JJ_GIGAN_SYMD 보험시기
		public String[] ctc_if__arc_fin_dt = new String[0];  //[O] 계약정보_보험종료일자 JJ_GIGAN_EYMD 보험종료일
		public String[] ctc_if__arc_trm_cd = new String[0];  //[O] 계약정보_보험기간코드 JJ_GIGAN_CD 보험기간코드
		public String[] ctc_if__arc_trm_nm = new String[0];  //[O] 계약정보_보험기간명 HJ_GIGAN_NM 보험기간명
		public String[] ctc_if__fnal_pym_mon = new String[0];  //[O] 계약정보_최종납입월 JJ_LAST_NAPIP_YM 최종납입월도
		public String[] ctc_if__fnal_pym_orr = new String[0];  //[O] 계약정보_최종납입회차 JJ_LAST_NAPIP_CNT 최종납입회차
		public String[] ctc_if__nstl_mtd = new String[0];  //[O] 계약정보_분납방법 JJ_NAPBANG_CD 분납방법
		public String[] ctc_if__nstl_mtd_nm = new String[0];  //[O] 계약정보_분납방법명 HJ_NAPBANG_NM 분납방법명
		public String[] ctc_if__ctc_stat_cd = new String[0];  //[O] 계약정보_계약상태코드 JJ_SANGTE_CD 계약상태코드
		public String[] ctc_if__ctc_stat_nm = new String[0];  //[O] 계약정보_계약상태명 HJ_GYE_SANGTE 계약상태명
		public String[] ctc_if__wthd_acc_cd = new String[0];  //[O] 계약정보_출금계좌번호 JJ_GYEJWA_NO 출금계좌번호
		public String[] ctc_if__dpsr_rrno = new String[0];  //[O] 계약정보_예금주주민등록번호 JJ_YEGMJU_JUMINNO 예금주주민번호
		public String[] ctc_if__dpsr_nm = new String[0];  //[O] 계약정보_예금주명 HJ_YEGMJU_NAME 예금주명
		public String[] ctc_if__dpsr_rlt = new String[0];  //[O] 계약정보_예금주관계 JJ_ICHE_GWANCD 예금주관계
		public String[] ctc_if__bank_cd = new String[0];  //[O] 계약정보_은행코드 JJ_BANK_CD 은행코드
		public String[] ctc_if__bank_nm = new String[0];  //[O] 계약정보_은행명 HJ_BANK_NAME 은형명
		public String[] ctc_if__coll_ormm_nm = new String[0];  //[O] 계약정보_수금조직원명 HJ-SUGUMJA-NAME  수금조직원명
		public String[] ctc_if__coll_ormm_no = new String[0];  //[O] 계약정보_수금조직원번호 JJ-SUGUMJA-CD 수금조직원코드
		public String[] ctc_if__coll_bh_no = new String[0];  //[O] 계약정보_수금지점번호 JJ-SUGUM-JIJUM-CD 수금지점코드
		public String[] ctc_if__coll_brn_no = new String[0];  //[O] 계약정보_수금지부번호 JJ-SUGUM-JIBU-CD 수금지부코드
		public String[] ctc_if__rpm_aply_yn = new String[0];  //[O] 계약정보_상환신청여부 JJ_SINCHERNG_RST 상환신청여부
		public String z_next_page_exis_yn = null;	//다음페이지 유무
		public String z_wh_page_cnt = null;
		public String z_wh_cnum = null;
		public String z_user_page_key_set = null;
		
		public String getZ_wh_page_cnt() {
			return z_wh_page_cnt;
		}
		public void setZ_wh_page_cnt(String z_wh_page_cnt) {
			this.z_wh_page_cnt = z_wh_page_cnt;
		}
		public String getZ_wh_cnum() {
			return z_wh_cnum;
		}
		public void setZ_wh_cnum(String z_wh_cnum) {
			this.z_wh_cnum = z_wh_cnum;
		}
		public String getZ_user_page_key_set() {
			return z_user_page_key_set;
		}
		public void setZ_user_page_key_set(String z_user_page_key_set) {
			this.z_user_page_key_set = z_user_page_key_set;
		}
		public String getZ_next_page_exis_yn() {
			return z_next_page_exis_yn;
		}
		public void setZ_next_page_exis_yn(String z_next_page_exis_yn) {
			this.z_next_page_exis_yn = z_next_page_exis_yn;
		}
		public String getPlhd_rrno() {
			return plhd_rrno;
		}
		public void setPlhd_rrno(String plhd_rrno) {
			this.plhd_rrno = plhd_rrno;
		}
		public String getPlhd_nm() {
			return plhd_nm;
		}
		public void setPlhd_nm(String plhd_nm) {
			this.plhd_nm = plhd_nm;
		}
		public String[] getCtc_if__plno() {
			return ctc_if__plno;
		}
		public void setCtc_if__plno(String[] ctc_if__plno) {
			this.ctc_if__plno = ctc_if__plno;
		}
		public String[] getCtc_if__pdc_cd() {
			return ctc_if__pdc_cd;
		}
		public void setCtc_if__pdc_cd(String[] ctc_if__pdc_cd) {
			this.ctc_if__pdc_cd = ctc_if__pdc_cd;
		}
		public String[] getCtc_if__inpd_nm() {
			return ctc_if__inpd_nm;
		}
		public void setCtc_if__inpd_nm(String[] ctc_if__inpd_nm) {
			this.ctc_if__inpd_nm = ctc_if__inpd_nm;
		}
		public String[] getCtc_if__arc_pd_dt() {
			return ctc_if__arc_pd_dt;
		}
		public void setCtc_if__arc_pd_dt(String[] ctc_if__arc_pd_dt) {
			this.ctc_if__arc_pd_dt = ctc_if__arc_pd_dt;
		}
		public String[] getCtc_if__arc_fin_dt() {
			return ctc_if__arc_fin_dt;
		}
		public void setCtc_if__arc_fin_dt(String[] ctc_if__arc_fin_dt) {
			this.ctc_if__arc_fin_dt = ctc_if__arc_fin_dt;
		}
		public String[] getCtc_if__arc_trm_cd() {
			return ctc_if__arc_trm_cd;
		}
		public void setCtc_if__arc_trm_cd(String[] ctc_if__arc_trm_cd) {
			this.ctc_if__arc_trm_cd = ctc_if__arc_trm_cd;
		}
		public String[] getCtc_if__arc_trm_nm() {
			return ctc_if__arc_trm_nm;
		}
		public void setCtc_if__arc_trm_nm(String[] ctc_if__arc_trm_nm) {
			this.ctc_if__arc_trm_nm = ctc_if__arc_trm_nm;
		}
		public String[] getCtc_if__fnal_pym_mon() {
			return ctc_if__fnal_pym_mon;
		}
		public void setCtc_if__fnal_pym_mon(String[] ctc_if__fnal_pym_mon) {
			this.ctc_if__fnal_pym_mon = ctc_if__fnal_pym_mon;
		}
		public String[] getCtc_if__fnal_pym_orr() {
			return ctc_if__fnal_pym_orr;
		}
		public void setCtc_if__fnal_pym_orr(String[] ctc_if__fnal_pym_orr) {
			this.ctc_if__fnal_pym_orr = ctc_if__fnal_pym_orr;
		}
		public String[] getCtc_if__nstl_mtd() {
			return ctc_if__nstl_mtd;
		}
		public void setCtc_if__nstl_mtd(String[] ctc_if__nstl_mtd) {
			this.ctc_if__nstl_mtd = ctc_if__nstl_mtd;
		}
		public String[] getCtc_if__nstl_mtd_nm() {
			return ctc_if__nstl_mtd_nm;
		}
		public void setCtc_if__nstl_mtd_nm(String[] ctc_if__nstl_mtd_nm) {
			this.ctc_if__nstl_mtd_nm = ctc_if__nstl_mtd_nm;
		}
		public String[] getCtc_if__ctc_stat_cd() {
			return ctc_if__ctc_stat_cd;
		}
		public void setCtc_if__ctc_stat_cd(String[] ctc_if__ctc_stat_cd) {
			this.ctc_if__ctc_stat_cd = ctc_if__ctc_stat_cd;
		}
		public String[] getCtc_if__ctc_stat_nm() {
			return ctc_if__ctc_stat_nm;
		}
		public void setCtc_if__ctc_stat_nm(String[] ctc_if__ctc_stat_nm) {
			this.ctc_if__ctc_stat_nm = ctc_if__ctc_stat_nm;
		}
		public String[] getCtc_if__wthd_acc_cd() {
			return ctc_if__wthd_acc_cd;
		}
		public void setCtc_if__wthd_acc_cd(String[] ctc_if__wthd_acc_cd) {
			this.ctc_if__wthd_acc_cd = ctc_if__wthd_acc_cd;
		}
		public String[] getCtc_if__dpsr_rrno() {
			return ctc_if__dpsr_rrno;
		}
		public void setCtc_if__dpsr_rrno(String[] ctc_if__dpsr_rrno) {
			this.ctc_if__dpsr_rrno = ctc_if__dpsr_rrno;
		}
		public String[] getCtc_if__dpsr_nm() {
			return ctc_if__dpsr_nm;
		}
		public void setCtc_if__dpsr_nm(String[] ctc_if__dpsr_nm) {
			this.ctc_if__dpsr_nm = ctc_if__dpsr_nm;
		}
		public String[] getCtc_if__dpsr_rlt() {
			return ctc_if__dpsr_rlt;
		}
		public void setCtc_if__dpsr_rlt(String[] ctc_if__dpsr_rlt) {
			this.ctc_if__dpsr_rlt = ctc_if__dpsr_rlt;
		}
		public String[] getCtc_if__bank_cd() {
			return ctc_if__bank_cd;
		}
		public void setCtc_if__bank_cd(String[] ctc_if__bank_cd) {
			this.ctc_if__bank_cd = ctc_if__bank_cd;
		}
		public String[] getCtc_if__bank_nm() {
			return ctc_if__bank_nm;
		}
		public void setCtc_if__bank_nm(String[] ctc_if__bank_nm) {
			this.ctc_if__bank_nm = ctc_if__bank_nm;
		}
		public String[] getCtc_if__coll_ormm_nm() {
			return ctc_if__coll_ormm_nm;
		}
		public void setCtc_if__coll_ormm_nm(String[] ctc_if__coll_ormm_nm) {
			this.ctc_if__coll_ormm_nm = ctc_if__coll_ormm_nm;
		}
		public String[] getCtc_if__coll_ormm_no() {
			return ctc_if__coll_ormm_no;
		}
		public void setCtc_if__coll_ormm_no(String[] ctc_if__coll_ormm_no) {
			this.ctc_if__coll_ormm_no = ctc_if__coll_ormm_no;
		}
		public String[] getCtc_if__coll_bh_no() {
			return ctc_if__coll_bh_no;
		}
		public void setCtc_if__coll_bh_no(String[] ctc_if__coll_bh_no) {
			this.ctc_if__coll_bh_no = ctc_if__coll_bh_no;
		}
		public String[] getCtc_if__coll_brn_no() {
			return ctc_if__coll_brn_no;
		}
		public void setCtc_if__coll_brn_no(String[] ctc_if__coll_brn_no) {
			this.ctc_if__coll_brn_no = ctc_if__coll_brn_no;
		}
		public String[] getCtc_if__rpm_aply_yn() {
			return ctc_if__rpm_aply_yn;
		}
		public void setCtc_if__rpm_aply_yn(String[] ctc_if__rpm_aply_yn) {
			this.ctc_if__rpm_aply_yn = ctc_if__rpm_aply_yn;
		}
}
