package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class EAST0011VO extends CMMVO{
	//전문필드
		public String funt_key = "";  //[I] 기능키 CC_FUN_KEY 기능키
		public String rsdn_no = "";  //[I] 주민번호 JJ_JUMIN_NO 주민번호
		public String cust_bse_ln_pss_yn = "";		//[O] 고객기준 대출가능여부 0 : 대출진행불가(추후24시간 대출운영시 CMS 작업중이면, 진행불가로 처리함), 1 : 대출진행가능
		public String cust_bse_ln_imsb_msg = "";	//[O] 고객기준 대출불가 메세지
		public String cust_bank_cd = "";			//[O] 고객송금계좌-은행코드	2016.03.14 추가
		public String cust_bank_nm = "";			//[O] 고객송금계좌-은행명		2016.03.14 추가
		public String cust_acc_no = "";				//[O] 고객송금계좌-계좌번호	2016.03.14 추가
		public String cust_dpsr_nm = "";			//[O] 고객송금계좌-예금주명	2016.03.14 추가
		public String[] inet_arc_ctc_ln_pss_srch_lit__inpd_nm = new String[0];  //[O] _보종명 HJ_BJ_NM 보종명
		public String[] inet_arc_ctc_ln_pss_srch_lit__inpd_cd = new String[0];  //[O] _보종코드  
		public String[] inet_arc_ctc_ln_pss_srch_lit__plno = new String[0];  //[O] _증권번호 JJ_POLI_NO 증권번호
		public String[] inet_arc_ctc_ln_pss_srch_lit__ins_lcpl_dvcd = new String[0];  //[O] _피보험자소재지구분코드  
		public String[] inet_arc_ctc_ln_pss_srch_lit__ply_sqno = new String[0];  //[O] _증권일련번호  
		public String[] inet_arc_ctc_ln_pss_srch_lit__stat_nm = new String[0];  //[O] _상태명 HJ_SANGTE_NM 상태명
		public String[] inet_arc_ctc_ln_pss_srch_lit__rckn_amt = new String[0];  //[O] _기산금액 JJ_GISAN_GM 기산금
		public String[] inet_arc_ctc_ln_pss_srch_lit__pym_dd = new String[0];  //[O] _납입일 JJ_NAPIP_YMD 납입일
		public String[] inet_arc_ctc_ln_pss_srch_lit__irt = new String[0];  //[O] _이율 JJ_IYUL 이율
		public String[] inet_arc_ctc_ln_pss_srch_lit__stln_pss_dvn = new String[0];  //[O] _약대가능구분 JJ_GANUNG_GB 약대가능구분
		public String[] inet_arc_ctc_ln_pss_srch_lit__stln_pss_dvn_2 = new String[0];		 	 //[O]_ 약대가능구분2 JJ_S_GANUNG_GB 약대가능구분2
		public String[] inet_arc_ctc_ln_pss_srch_lit__add_regt_bank_cd = new String[0];  //[O] 고객추가등록 은행코드  JJ_S_BANK_CD 고객추가등록 은행코드 
		public String[] inet_arc_ctc_ln_pss_srch_lit__add_regt_acc_no = new String[0];  //[O] 고객추가등록 계좌번호  JJ_S_GYEJWA_NO 고객추가등록 계좌번호 
		public String[] inet_arc_ctc_ln_pss_srch_lit__add_regt_bank_nm = new String[0];  //[O] 고객추가등록 은행명 HJ_S_BANK_NM 고객추가등록 은행명
		public String[] inet_arc_ctc_ln_pss_srch_lit__stln_pss_amt = new String[0];  //[O] _약대가능금액 JJ_GANUNG_GM 약대가능금액
		public String[] inet_arc_ctc_ln_pss_srch_lit__crdd_ln_ocr_sm_amt = new String[0];  //[O] _당일 대출발생 합계금액 2015.09.10 추가
		public String[] inet_arc_ctc_ln_pss_srch_lit__tsfr_dd = new String[0];  //[O] _이체일 JJ_ICHE_D 이체일
		public String[] inet_arc_ctc_ln_pss_srch_lit__bank_cd = new String[0];  //[O] _은행코드 JJ_BANK_CD 은행코드
		public String[] inet_arc_ctc_ln_pss_srch_lit__acc_no = new String[0];  //[O] _계좌번호 JJ_GYEJWA_NO 계좌번호
		public String[] inet_arc_ctc_ln_pss_srch_lit__bank_nm = new String[0];  //[O] _은행명 HJ_BANK_NM 은행명
		public String[] inet_arc_ctc_ln_pss_srch_lit__pyn_bank_cd = new String[0];  //[O] _지급은행코드 JJ_IJ_BANK_CD 지급은행코드
		public String[] inet_arc_ctc_ln_pss_srch_lit__pyn_acc_no = new String[0];  //[O] _지급계좌번호 JJ_IJ_GYEJWA_NO 지급계좌번호
		public String[] inet_arc_ctc_ln_pss_srch_lit__pyn_bank_nm = new String[0];  //[O] _지급은행명 HJ_IJ_BANK_NM 지급은행명
		public String[] inet_arc_ctc_ln_pss_srch_lit__n3belw_bank_cd = new String[0];  		//[O] _비연속3회미만계좌-은행코드	2016.03.14 추가
		public String[] inet_arc_ctc_ln_pss_srch_lit__n3belw_bank_nm = new String[0];  		//[O] _비연속3회미만계좌-은행명		2016.03.14 추가
		public String[] inet_arc_ctc_ln_pss_srch_lit__n3belw_acc_no = new String[0];  		//[O] _비연속3회미만계좌-계좌번호	2016.03.14 추가
		public String[] inet_arc_ctc_ln_pss_srch_lit__n3belw_dpsr_rlt_cd = new String[0];  	//[O] _비연속3회미만계좌-예금주관계코드	2016.03.14 추가
		public String[] inet_arc_ctc_ln_pss_srch_lit__n3belw_dpsr_nm = new String[0];  		//[O] _비연속3회미만계좌-예금주명	2016.03.14 추가
		public String[] inet_arc_ctc_ln_pss_srch_lit__n3belw_dpsr_rsdn_no = new String[0];  //[O] _비연속3회미만계좌-예금주주민번호	2016.03.14 추가
		public String[] inet_arc_ctc_ln_pss_srch_lit__n3belw_tsfr_dt = new String[0];  		//[O] _비연속3회미만계좌-이체일자	2016.03.14 추가		
		public String ctf_yn = "";  //[I] 인증여부 JJ_INJNG 인증여부
		public String staf_pa_dvn = "";  //[I] 직원PA구분 JJ_JIKWON_PA 직원PA구분
		public String srch_plno = "";  //[I] 조회증권번호 UU_INQ_POLI_NO 조회증번
		public String srch_ins_lcpl_dvcd = "";  //[I] 조회증권일련번호  
		public String srch_ply_sqno = "";  //[I] 조회피보험자소재지구분코드  
		public String str_plno = "";  //[I] 시작증권번호 UU_F_POLI_NO 시작증번
		public String str_ins_lcpl_dvcd = "";  //[I] 시작피보험자소재지구분코드  
		public String str_ply_sqno = "";  //[I] 시작증권일련번호  
		public String fin_plno = "";  //[I] 종료증권번호 UU_L_POLI_NO 종료증번
		public String fin_ins_lcpl_dvcd = "";  //[I] 종료피보험자소재지구분코드  
		public String fin_ply_sqno = "";  //[I] 종료증권일련번호  
		public String errorCode = "";  //에러코드
		
		public String getFunt_key() {
			return funt_key;
		}
		public void setFunt_key(String funt_key) {
			this.funt_key = funt_key;
		}		
		public String getCust_bse_ln_pss_yn() {
			return cust_bse_ln_pss_yn;
		}
		public void setCust_bse_ln_pss_yn(String cust_bse_ln_pss_yn) {
			this.cust_bse_ln_pss_yn = cust_bse_ln_pss_yn;
		}
		public String getCust_bse_ln_imsb_msg() {
			return cust_bse_ln_imsb_msg;
		}
		public void setCust_bse_ln_imsb_msg(String cust_bse_ln_imsb_msg) {
			this.cust_bse_ln_imsb_msg = cust_bse_ln_imsb_msg;
		}
		public String getRsdn_no() {
			return rsdn_no;
		}
		public void setRsdn_no(String rsdn_no) {
			this.rsdn_no = rsdn_no;
		}
		public String[] getInet_arc_ctc_ln_pss_srch_lit__inpd_nm() {
			return inet_arc_ctc_ln_pss_srch_lit__inpd_nm;
		}
		public void setInet_arc_ctc_ln_pss_srch_lit__inpd_nm(
				String[] inet_arc_ctc_ln_pss_srch_lit__inpd_nm) {
			this.inet_arc_ctc_ln_pss_srch_lit__inpd_nm = inet_arc_ctc_ln_pss_srch_lit__inpd_nm;
		}
		public String[] getInet_arc_ctc_ln_pss_srch_lit__inpd_cd() {
			return inet_arc_ctc_ln_pss_srch_lit__inpd_cd;
		}
		public void setInet_arc_ctc_ln_pss_srch_lit__inpd_cd(
				String[] inet_arc_ctc_ln_pss_srch_lit__inpd_cd) {
			this.inet_arc_ctc_ln_pss_srch_lit__inpd_cd = inet_arc_ctc_ln_pss_srch_lit__inpd_cd;
		}
		public String[] getInet_arc_ctc_ln_pss_srch_lit__plno() {
			return inet_arc_ctc_ln_pss_srch_lit__plno;
		}
		public void setInet_arc_ctc_ln_pss_srch_lit__plno(
				String[] inet_arc_ctc_ln_pss_srch_lit__plno) {
			this.inet_arc_ctc_ln_pss_srch_lit__plno = inet_arc_ctc_ln_pss_srch_lit__plno;
		}
		public String[] getInet_arc_ctc_ln_pss_srch_lit__ins_lcpl_dvcd() {
			return inet_arc_ctc_ln_pss_srch_lit__ins_lcpl_dvcd;
		}
		public void setInet_arc_ctc_ln_pss_srch_lit__ins_lcpl_dvcd(
				String[] inet_arc_ctc_ln_pss_srch_lit__ins_lcpl_dvcd) {
			this.inet_arc_ctc_ln_pss_srch_lit__ins_lcpl_dvcd = inet_arc_ctc_ln_pss_srch_lit__ins_lcpl_dvcd;
		}
		public String[] getInet_arc_ctc_ln_pss_srch_lit__ply_sqno() {
			return inet_arc_ctc_ln_pss_srch_lit__ply_sqno;
		}
		public void setInet_arc_ctc_ln_pss_srch_lit__ply_sqno(
				String[] inet_arc_ctc_ln_pss_srch_lit__ply_sqno) {
			this.inet_arc_ctc_ln_pss_srch_lit__ply_sqno = inet_arc_ctc_ln_pss_srch_lit__ply_sqno;
		}
		public String[] getInet_arc_ctc_ln_pss_srch_lit__stat_nm() {
			return inet_arc_ctc_ln_pss_srch_lit__stat_nm;
		}
		public void setInet_arc_ctc_ln_pss_srch_lit__stat_nm(
				String[] inet_arc_ctc_ln_pss_srch_lit__stat_nm) {
			this.inet_arc_ctc_ln_pss_srch_lit__stat_nm = inet_arc_ctc_ln_pss_srch_lit__stat_nm;
		}
		public String[] getInet_arc_ctc_ln_pss_srch_lit__rckn_amt() {
			return inet_arc_ctc_ln_pss_srch_lit__rckn_amt;
		}
		public void setInet_arc_ctc_ln_pss_srch_lit__rckn_amt(
				String[] inet_arc_ctc_ln_pss_srch_lit__rckn_amt) {
			this.inet_arc_ctc_ln_pss_srch_lit__rckn_amt = inet_arc_ctc_ln_pss_srch_lit__rckn_amt;
		}
		public String[] getInet_arc_ctc_ln_pss_srch_lit__pym_dd() {
			return inet_arc_ctc_ln_pss_srch_lit__pym_dd;
		}
		public void setInet_arc_ctc_ln_pss_srch_lit__pym_dd(
				String[] inet_arc_ctc_ln_pss_srch_lit__pym_dd) {
			this.inet_arc_ctc_ln_pss_srch_lit__pym_dd = inet_arc_ctc_ln_pss_srch_lit__pym_dd;
		}
		public String[] getInet_arc_ctc_ln_pss_srch_lit__irt() {
			return inet_arc_ctc_ln_pss_srch_lit__irt;
		}
		public void setInet_arc_ctc_ln_pss_srch_lit__irt(
				String[] inet_arc_ctc_ln_pss_srch_lit__irt) {
			this.inet_arc_ctc_ln_pss_srch_lit__irt = inet_arc_ctc_ln_pss_srch_lit__irt;
		}
		public String[] getInet_arc_ctc_ln_pss_srch_lit__stln_pss_dvn() {
			return inet_arc_ctc_ln_pss_srch_lit__stln_pss_dvn;
		}
		public void setInet_arc_ctc_ln_pss_srch_lit__stln_pss_dvn(
				String[] inet_arc_ctc_ln_pss_srch_lit__stln_pss_dvn) {
			this.inet_arc_ctc_ln_pss_srch_lit__stln_pss_dvn = inet_arc_ctc_ln_pss_srch_lit__stln_pss_dvn;
		}
		public String[] getInet_arc_ctc_ln_pss_srch_lit__stln_pss_dvn_2() {
			return inet_arc_ctc_ln_pss_srch_lit__stln_pss_dvn_2;
		}
		public void setInet_arc_ctc_ln_pss_srch_lit__stln_pss_dvn_2(
				String[] inet_arc_ctc_ln_pss_srch_lit__stln_pss_dvn_2) {
			this.inet_arc_ctc_ln_pss_srch_lit__stln_pss_dvn_2 = inet_arc_ctc_ln_pss_srch_lit__stln_pss_dvn_2;
		}
		public String[] getInet_arc_ctc_ln_pss_srch_lit__add_regt_bank_cd() {
			return inet_arc_ctc_ln_pss_srch_lit__add_regt_bank_cd;
		}
		public void setInet_arc_ctc_ln_pss_srch_lit__add_regt_bank_cd(
				String[] inet_arc_ctc_ln_pss_srch_lit__add_regt_bank_cd) {
			this.inet_arc_ctc_ln_pss_srch_lit__add_regt_bank_cd = inet_arc_ctc_ln_pss_srch_lit__add_regt_bank_cd;
		}
		public String[] getInet_arc_ctc_ln_pss_srch_lit__add_regt_acc_no() {
			return inet_arc_ctc_ln_pss_srch_lit__add_regt_acc_no;
		}
		public void setInet_arc_ctc_ln_pss_srch_lit__add_regt_acc_no(
				String[] inet_arc_ctc_ln_pss_srch_lit__add_regt_acc_no) {
			this.inet_arc_ctc_ln_pss_srch_lit__add_regt_acc_no = inet_arc_ctc_ln_pss_srch_lit__add_regt_acc_no;
		}
		public String[] getInet_arc_ctc_ln_pss_srch_lit__add_regt_bank_nm() {
			return inet_arc_ctc_ln_pss_srch_lit__add_regt_bank_nm;
		}
		public void setInet_arc_ctc_ln_pss_srch_lit__add_regt_bank_nm(
				String[] inet_arc_ctc_ln_pss_srch_lit__add_regt_bank_nm) {
			this.inet_arc_ctc_ln_pss_srch_lit__add_regt_bank_nm = inet_arc_ctc_ln_pss_srch_lit__add_regt_bank_nm;
		}
		public String[] getInet_arc_ctc_ln_pss_srch_lit__stln_pss_amt() {
			return inet_arc_ctc_ln_pss_srch_lit__stln_pss_amt;
		}
		public void setInet_arc_ctc_ln_pss_srch_lit__stln_pss_amt(
				String[] inet_arc_ctc_ln_pss_srch_lit__stln_pss_amt) {
			this.inet_arc_ctc_ln_pss_srch_lit__stln_pss_amt = inet_arc_ctc_ln_pss_srch_lit__stln_pss_amt;
		}		
		public String[] getInet_arc_ctc_ln_pss_srch_lit__crdd_ln_ocr_sm_amt() {
			return inet_arc_ctc_ln_pss_srch_lit__crdd_ln_ocr_sm_amt;
		}
		public void setInet_arc_ctc_ln_pss_srch_lit__crdd_ln_ocr_sm_amt(
				String[] inet_arc_ctc_ln_pss_srch_lit__crdd_ln_ocr_sm_amt) {
			this.inet_arc_ctc_ln_pss_srch_lit__crdd_ln_ocr_sm_amt = inet_arc_ctc_ln_pss_srch_lit__crdd_ln_ocr_sm_amt;
		}
		public String[] getInet_arc_ctc_ln_pss_srch_lit__tsfr_dd() {
			return inet_arc_ctc_ln_pss_srch_lit__tsfr_dd;
		}
		public void setInet_arc_ctc_ln_pss_srch_lit__tsfr_dd(
				String[] inet_arc_ctc_ln_pss_srch_lit__tsfr_dd) {
			this.inet_arc_ctc_ln_pss_srch_lit__tsfr_dd = inet_arc_ctc_ln_pss_srch_lit__tsfr_dd;
		}
		public String[] getInet_arc_ctc_ln_pss_srch_lit__bank_cd() {
			return inet_arc_ctc_ln_pss_srch_lit__bank_cd;
		}
		public void setInet_arc_ctc_ln_pss_srch_lit__bank_cd(
				String[] inet_arc_ctc_ln_pss_srch_lit__bank_cd) {
			this.inet_arc_ctc_ln_pss_srch_lit__bank_cd = inet_arc_ctc_ln_pss_srch_lit__bank_cd;
		}
		public String[] getInet_arc_ctc_ln_pss_srch_lit__acc_no() {
			return inet_arc_ctc_ln_pss_srch_lit__acc_no;
		}
		public void setInet_arc_ctc_ln_pss_srch_lit__acc_no(
				String[] inet_arc_ctc_ln_pss_srch_lit__acc_no) {
			this.inet_arc_ctc_ln_pss_srch_lit__acc_no = inet_arc_ctc_ln_pss_srch_lit__acc_no;
		}
		public String[] getInet_arc_ctc_ln_pss_srch_lit__bank_nm() {
			return inet_arc_ctc_ln_pss_srch_lit__bank_nm;
		}
		public void setInet_arc_ctc_ln_pss_srch_lit__bank_nm(
				String[] inet_arc_ctc_ln_pss_srch_lit__bank_nm) {
			this.inet_arc_ctc_ln_pss_srch_lit__bank_nm = inet_arc_ctc_ln_pss_srch_lit__bank_nm;
		}
		public String[] getInet_arc_ctc_ln_pss_srch_lit__pyn_bank_cd() {
			return inet_arc_ctc_ln_pss_srch_lit__pyn_bank_cd;
		}
		public void setInet_arc_ctc_ln_pss_srch_lit__pyn_bank_cd(
				String[] inet_arc_ctc_ln_pss_srch_lit__pyn_bank_cd) {
			this.inet_arc_ctc_ln_pss_srch_lit__pyn_bank_cd = inet_arc_ctc_ln_pss_srch_lit__pyn_bank_cd;
		}
		public String[] getInet_arc_ctc_ln_pss_srch_lit__pyn_acc_no() {
			return inet_arc_ctc_ln_pss_srch_lit__pyn_acc_no;
		}
		public void setInet_arc_ctc_ln_pss_srch_lit__pyn_acc_no(
				String[] inet_arc_ctc_ln_pss_srch_lit__pyn_acc_no) {
			this.inet_arc_ctc_ln_pss_srch_lit__pyn_acc_no = inet_arc_ctc_ln_pss_srch_lit__pyn_acc_no;
		}
		public String[] getInet_arc_ctc_ln_pss_srch_lit__pyn_bank_nm() {
			return inet_arc_ctc_ln_pss_srch_lit__pyn_bank_nm;
		}
		public void setInet_arc_ctc_ln_pss_srch_lit__pyn_bank_nm(
				String[] inet_arc_ctc_ln_pss_srch_lit__pyn_bank_nm) {
			this.inet_arc_ctc_ln_pss_srch_lit__pyn_bank_nm = inet_arc_ctc_ln_pss_srch_lit__pyn_bank_nm;
		}
		public String getCtf_yn() {
			return ctf_yn;
		}
		public void setCtf_yn(String ctf_yn) {
			this.ctf_yn = ctf_yn;
		}
		public String getStaf_pa_dvn() {
			return staf_pa_dvn;
		}
		public void setStaf_pa_dvn(String staf_pa_dvn) {
			this.staf_pa_dvn = staf_pa_dvn;
		}
		public String getSrch_plno() {
			return srch_plno;
		}
		public void setSrch_plno(String srch_plno) {
			this.srch_plno = srch_plno;
		}
		public String getSrch_ins_lcpl_dvcd() {
			return srch_ins_lcpl_dvcd;
		}
		public void setSrch_ins_lcpl_dvcd(String srch_ins_lcpl_dvcd) {
			this.srch_ins_lcpl_dvcd = srch_ins_lcpl_dvcd;
		}
		public String getSrch_ply_sqno() {
			return srch_ply_sqno;
		}
		public void setSrch_ply_sqno(String srch_ply_sqno) {
			this.srch_ply_sqno = srch_ply_sqno;
		}
		public String getStr_plno() {
			return str_plno;
		}
		public void setStr_plno(String str_plno) {
			this.str_plno = str_plno;
		}
		public String getStr_ins_lcpl_dvcd() {
			return str_ins_lcpl_dvcd;
		}
		public void setStr_ins_lcpl_dvcd(String str_ins_lcpl_dvcd) {
			this.str_ins_lcpl_dvcd = str_ins_lcpl_dvcd;
		}
		public String getStr_ply_sqno() {
			return str_ply_sqno;
		}
		public void setStr_ply_sqno(String str_ply_sqno) {
			this.str_ply_sqno = str_ply_sqno;
		}
		public String getFin_plno() {
			return fin_plno;
		}
		public void setFin_plno(String fin_plno) {
			this.fin_plno = fin_plno;
		}
		public String getFin_ins_lcpl_dvcd() {
			return fin_ins_lcpl_dvcd;
		}
		public void setFin_ins_lcpl_dvcd(String fin_ins_lcpl_dvcd) {
			this.fin_ins_lcpl_dvcd = fin_ins_lcpl_dvcd;
		}
		public String getFin_ply_sqno() {
			return fin_ply_sqno;
		}
		public void setFin_ply_sqno(String fin_ply_sqno) {
			this.fin_ply_sqno = fin_ply_sqno;
		}
		public String getErrorCode() {
			return errorCode;
		}
		public void setErrorCode(String errorCode) {
			this.errorCode = errorCode;
		}
		public String getCust_bank_cd() {
			return cust_bank_cd;
		}
		public void setCust_bank_cd(String cust_bank_cd) {
			this.cust_bank_cd = cust_bank_cd;
		}
		public String getCust_bank_nm() {
			return cust_bank_nm;
		}
		public void setCust_bank_nm(String cust_bank_nm) {
			this.cust_bank_nm = cust_bank_nm;
		}
		public String getCust_acc_no() {
			return cust_acc_no;
		}
		public void setCust_acc_no(String cust_acc_no) {
			this.cust_acc_no = cust_acc_no;
		}
		public String getCust_dpsr_nm() {
			return cust_dpsr_nm;
		}
		public void setCust_dpsr_nm(String cust_dpsr_nm) {
			this.cust_dpsr_nm = cust_dpsr_nm;
		}
		public String[] getInet_arc_ctc_ln_pss_srch_lit__n3belw_bank_cd() {
			return inet_arc_ctc_ln_pss_srch_lit__n3belw_bank_cd;
		}
		public void setInet_arc_ctc_ln_pss_srch_lit__n3belw_bank_cd(String[] inet_arc_ctc_ln_pss_srch_lit__n3belw_bank_cd) {
			this.inet_arc_ctc_ln_pss_srch_lit__n3belw_bank_cd = inet_arc_ctc_ln_pss_srch_lit__n3belw_bank_cd;
		}
		public String[] getInet_arc_ctc_ln_pss_srch_lit__n3belw_bank_nm() {
			return inet_arc_ctc_ln_pss_srch_lit__n3belw_bank_nm;
		}
		public void setInet_arc_ctc_ln_pss_srch_lit__n3belw_bank_nm(String[] inet_arc_ctc_ln_pss_srch_lit__n3belw_bank_nm) {
			this.inet_arc_ctc_ln_pss_srch_lit__n3belw_bank_nm = inet_arc_ctc_ln_pss_srch_lit__n3belw_bank_nm;
		}
		public String[] getInet_arc_ctc_ln_pss_srch_lit__n3belw_acc_no() {
			return inet_arc_ctc_ln_pss_srch_lit__n3belw_acc_no;
		}
		public void setInet_arc_ctc_ln_pss_srch_lit__n3belw_acc_no(String[] inet_arc_ctc_ln_pss_srch_lit__n3belw_acc_no) {
			this.inet_arc_ctc_ln_pss_srch_lit__n3belw_acc_no = inet_arc_ctc_ln_pss_srch_lit__n3belw_acc_no;
		}
		public String[] getInet_arc_ctc_ln_pss_srch_lit__n3belw_dpsr_rlt_cd() {
			return inet_arc_ctc_ln_pss_srch_lit__n3belw_dpsr_rlt_cd;
		}
		public void setInet_arc_ctc_ln_pss_srch_lit__n3belw_dpsr_rlt_cd(
				String[] inet_arc_ctc_ln_pss_srch_lit__n3belw_dpsr_rlt_cd) {
			this.inet_arc_ctc_ln_pss_srch_lit__n3belw_dpsr_rlt_cd = inet_arc_ctc_ln_pss_srch_lit__n3belw_dpsr_rlt_cd;
		}
		public String[] getInet_arc_ctc_ln_pss_srch_lit__n3belw_dpsr_nm() {
			return inet_arc_ctc_ln_pss_srch_lit__n3belw_dpsr_nm;
		}
		public void setInet_arc_ctc_ln_pss_srch_lit__n3belw_dpsr_nm(String[] inet_arc_ctc_ln_pss_srch_lit__n3belw_dpsr_nm) {
			this.inet_arc_ctc_ln_pss_srch_lit__n3belw_dpsr_nm = inet_arc_ctc_ln_pss_srch_lit__n3belw_dpsr_nm;
		}
		public String[] getInet_arc_ctc_ln_pss_srch_lit__n3belw_dpsr_rsdn_no() {
			return inet_arc_ctc_ln_pss_srch_lit__n3belw_dpsr_rsdn_no;
		}
		public void setInet_arc_ctc_ln_pss_srch_lit__n3belw_dpsr_rsdn_no(
				String[] inet_arc_ctc_ln_pss_srch_lit__n3belw_dpsr_rsdn_no) {
			this.inet_arc_ctc_ln_pss_srch_lit__n3belw_dpsr_rsdn_no = inet_arc_ctc_ln_pss_srch_lit__n3belw_dpsr_rsdn_no;
		}
		public String[] getInet_arc_ctc_ln_pss_srch_lit__n3belw_tsfr_dt() {
			return inet_arc_ctc_ln_pss_srch_lit__n3belw_tsfr_dt;
		}
		public void setInet_arc_ctc_ln_pss_srch_lit__n3belw_tsfr_dt(String[] inet_arc_ctc_ln_pss_srch_lit__n3belw_tsfr_dt) {
			this.inet_arc_ctc_ln_pss_srch_lit__n3belw_tsfr_dt = inet_arc_ctc_ln_pss_srch_lit__n3belw_tsfr_dt;
		}
		
		
}
