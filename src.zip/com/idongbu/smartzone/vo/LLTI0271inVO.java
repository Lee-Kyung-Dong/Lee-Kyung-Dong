package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class LLTI0271inVO extends CMMVO{
	//전문필드
		public String proc_dvn = null;  //[I] 처리구분 CC-FUN-KEY 기능키
		public String cust_rsdn_no = null;  //[I] 고객주민번호 JJ-GOGEK-NO 고객주민번호

		public String coll_if___slc_yn = null;  //[I] 선택여부 JJ-NO 일련번호
		public String coll_if___plno = null;  //[I/O] 증권번호 JJ-POLI-NO 증권번호
		
		public String funt_key = null;  //[I] 기능키  
		public String coll_mtd_cd_1 = null;  //[I] 수금방법코드1 JJ-SUKUM-BANGCD 수금방법코드
		public String bank_cd_1 = null;  //[I] 은행코드1 JJ-BANK-CD 은행코드
		public String acc_no_1 = null;  //[I] 계좌번호1 JJ-GYEJWA-NO 계좌번호
		public String tsfr_dd_1 = null;  //[I] 이체일1 JJ-ICHE-D 이체일
		public String ctc_rlt_cd = null;  //[I] 계약관계코드 JJ-GWANGYE-CD 계약관계코드
		public String dpsr_nm_1 = null;  //[I] 예금주명1 HJ-YEGMJU-NM 예금주이름
		public String dpsr_rsdn_no = null;  //[I] 예금주주민등록번호 JJ-YEGMJU-NO 예금주주민번호
		public String dpsr_tlno = null;  //[I] 예금주전화번호 JJ-YEGMJU-TEL 예금주전화번호
		public String crdt_crd_no = null;  //[I] 신용카드번호  
		public String crd_ownr_no = null;  //[I] 카드소유자번호  
		public String crd_vlid_trm_yy = null;  //[I] 카드유효기간년 JJ-JUK-YY 카드유효기간년
		public String crd_vlid_trm_mon = null;  //[I] 카드유효기간월 JJ-JUK-MM 카드유효기간월
		public String crd_ctf_cnfm = null;  //[I] 카드인증확인 HJ-REMARK 주석
		public String coll_if___wthd_csn_evd_dat_dvcd = ""; // [I] 출금동의증빙자료구분코드
		public String coll_if___wthd_csn_evd_dat_inpt_dvcd = ""; // [I] 출금동의증빙자료입력구분코드
		public String coll_if___wthd_csn_evd_dat_val = ""; // [I] 출금동의증빙자료값
		
		public String getProc_dvn() {
			return proc_dvn;
		}
		public void setProc_dvn(String proc_dvn) {
			this.proc_dvn = proc_dvn;
		}
		public String getCust_rsdn_no() {
			return cust_rsdn_no;
		}
		public void setCust_rsdn_no(String cust_rsdn_no) {
			this.cust_rsdn_no = cust_rsdn_no;
		}

		public String getColl_if___slc_yn() {
			return coll_if___slc_yn;
		}
		public void setColl_if___slc_yn(String coll_if___slc_yn) {
			this.coll_if___slc_yn = coll_if___slc_yn;
		}
		public String getColl_if___plno() {
			return coll_if___plno;
		}
		public void setColl_if___plno(String coll_if___plno) {
			this.coll_if___plno = coll_if___plno;
		}
		
		
		
		public String getFunt_key() {
			return funt_key;
		}
		public void setFunt_key(String funt_key) {
			this.funt_key = funt_key;
		}
		public String getColl_mtd_cd_1() {
			return coll_mtd_cd_1;
		}
		public void setColl_mtd_cd_1(String coll_mtd_cd_1) {
			this.coll_mtd_cd_1 = coll_mtd_cd_1;
		}
		public String getBank_cd_1() {
			return bank_cd_1;
		}
		public void setBank_cd_1(String bank_cd_1) {
			this.bank_cd_1 = bank_cd_1;
		}		
		public String getAcc_no_1() {
			return acc_no_1;
		}
		public void setAcc_no_1(String acc_no_1) {
			this.acc_no_1 = acc_no_1;
		}
		public String getTsfr_dd_1() {
			return tsfr_dd_1;
		}
		public void setTsfr_dd_1(String tsfr_dd_1) {
			this.tsfr_dd_1 = tsfr_dd_1;
		}
		public String getCtc_rlt_cd() {
			return ctc_rlt_cd;
		}
		public void setCtc_rlt_cd(String ctc_rlt_cd) {
			this.ctc_rlt_cd = ctc_rlt_cd;
		}		
		public String getDpsr_nm_1() {
			return dpsr_nm_1;
		}
		public void setDpsr_nm_1(String dpsr_nm_1) {
			this.dpsr_nm_1 = dpsr_nm_1;
		}
		public String getDpsr_rsdn_no() {
			return dpsr_rsdn_no;
		}
		public void setDpsr_rsdn_no(String dpsr_rsdn_no) {
			this.dpsr_rsdn_no = dpsr_rsdn_no;
		}
		public String getDpsr_tlno() {
			return dpsr_tlno;
		}
		public void setDpsr_tlno(String dpsr_tlno) {
			this.dpsr_tlno = dpsr_tlno;
		}
		public String getCrdt_crd_no() {
			return crdt_crd_no;
		}
		public void setCrdt_crd_no(String crdt_crd_no) {
			this.crdt_crd_no = crdt_crd_no;
		}
		public String getCrd_ownr_no() {
			return crd_ownr_no;
		}
		public void setCrd_ownr_no(String crd_ownr_no) {
			this.crd_ownr_no = crd_ownr_no;
		}
		public String getCrd_vlid_trm_yy() {
			return crd_vlid_trm_yy;
		}
		public void setCrd_vlid_trm_yy(String crd_vlid_trm_yy) {
			this.crd_vlid_trm_yy = crd_vlid_trm_yy;
		}
		public String getCrd_vlid_trm_mon() {
			return crd_vlid_trm_mon;
		}
		public void setCrd_vlid_trm_mon(String crd_vlid_trm_mon) {
			this.crd_vlid_trm_mon = crd_vlid_trm_mon;
		}
		public String getCrd_ctf_cnfm() {
			return crd_ctf_cnfm;
		}
		public void setCrd_ctf_cnfm(String crd_ctf_cnfm) {
			this.crd_ctf_cnfm = crd_ctf_cnfm;
		}
		public String getColl_if___wthd_csn_evd_dat_dvcd() {
			return coll_if___wthd_csn_evd_dat_dvcd;
		}
		public void setColl_if___wthd_csn_evd_dat_dvcd(String coll_if___wthd_csn_evd_dat_dvcd) {
			this.coll_if___wthd_csn_evd_dat_dvcd = coll_if___wthd_csn_evd_dat_dvcd;
		}
		public String getColl_if___wthd_csn_evd_dat_inpt_dvcd() {
			return coll_if___wthd_csn_evd_dat_inpt_dvcd;
		}
		public void setColl_if___wthd_csn_evd_dat_inpt_dvcd(String coll_if___wthd_csn_evd_dat_inpt_dvcd) {
			this.coll_if___wthd_csn_evd_dat_inpt_dvcd = coll_if___wthd_csn_evd_dat_inpt_dvcd;
		}
		public String getColl_if___wthd_csn_evd_dat_val() {
			return coll_if___wthd_csn_evd_dat_val;
		}
		public void setColl_if___wthd_csn_evd_dat_val(String coll_if___wthd_csn_evd_dat_val) {
			this.coll_if___wthd_csn_evd_dat_val = coll_if___wthd_csn_evd_dat_val;
		}

}
