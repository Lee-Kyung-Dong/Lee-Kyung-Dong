package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

// 실시간메일발송
public class XEMS0002VO extends CMMVO
{
	public String ems_if_id = "";		// [I/O] EMS ID
	public String mail_code = "";		// [I/O] 메일코드
	public String to_id = "";			// [I/O] 수신자 고객번호: 생년월일 + 성별 (7자리)
	public String to_email = "";		// [I/O] 수신자 메일주소
	public String to_name = "";			// [I/O] 수신자 이름
	public String from_email = "";		// [I/O] 발신자 메일주소
	public String from_name = "";		// [I/O] 발신자명
	public String subject = "";			// [I/O] 메일제목
	public String secure_flag = "";		// [I/O] 보안구분
	public String secure_no = "";		// [I/O] 보안번호
	public String target_flag = "";		// [I/O] 타게팅 구분
	public String target_date = "";		// [I/O] 타게팅 일자
	public String reg_date = "";		// [I/O] 작업일
	public String map_content = "";		// [I/O] 매핑 내용
	public String map1 = "";			// [I/O] 매핑값 1
	public String map2 = "";			// [I/O] 매핑값 2
	public String map3 = "";			// [I/O] 매핑값 3
	public String map4 = "";			// [I/O] 매핑값 4
	public String map5 = "";			// [I/O] 매핑값 5
	public String map6 = "";			// [I/O] 매핑값 6
	public String map7 = "";			// [I/O] 매핑값 7
	public String map8 = "";			// [I/O] 매핑값 8
	public String map9 = "";			// [I/O] 매핑값 9
	public String map10 = "";			// [I/O] 매핑값 10
	public String map11 = "";			// [I/O] 매핑값 11
	public String map12 = "";			// [I/O] 매핑값 12
	public String map13 = "";			// [I/O] 매핑값 13
	public String map14 = "";			// [I/O] 매핑값 14
	public String map15 = "";			// [I/O] 매핑값 15
	public String map16 = "";			// [I/O] 매핑값 16
	public String map17 = "";			// [I/O] 매핑값 17
	public String map18 = "";			// [I/O] 매핑값 18
	public String map19 = "";			// [I/O] 매핑값 19
	public String map20 = "";			// [I/O] 매핑값 20
	public String map21 = "";			// [I/O] 매핑값 21
	public String map22 = "";			// [I/O] 매핑값 22
	public String map23 = "";			// [I/O] 매핑값 23
	public String map24 = "";			// [I/O] 매핑값 24
	public String map25 = "";			// [I/O] 매핑값 25
	public String map26 = "";			// [I/O] 매핑값 26
	public String map27 = "";			// [I/O] 매핑값 27
	public String map28 = "";			// [I/O] 매핑값 28
	public String map29 = "";			// [I/O] 매핑값 29
	public String map30 = "";			// [I/O] 매핑값 30
	public String map31 = "";			// [I/O] 매핑값 31
	public String map32 = "";			// [I/O] 매핑값 32
	public String map33 = "";			// [I/O] 매핑값 33
	public String map34 = "";			// [I/O] 매핑값 34
	public String map35 = "";			// [I/O] 매핑값 35
	public String map36 = "";			// [I/O] 매핑값 36
	public String map37 = "";			// [I/O] 매핑값 37
	public String map38 = "";			// [I/O] 매핑값 38
	public String map39 = "";			// [I/O] 매핑값 39
	public String map40 = "";			// [I/O] 매핑값 40
	public String map41 = "";			// [I/O] 매핑값 41
	public String map42 = "";			// [I/O] 매핑값 42
	public String map43 = "";			// [I/O] 매핑값 43
	public String map44 = "";			// [I/O] 매핑값 44
	public String map45 = "";			// [I/O] 매핑값 45
	public String map46 = "";			// [I/O] 매핑값 46
	public String map47 = "";			// [I/O] 매핑값 47
	public String map48 = "";			// [I/O] 매핑값 48
	public String map49 = "";			// [I/O] 매핑값 49
	public String map50 = "";			// [I/O] 매핑값 50
	public String attach01 = "";		// [I/O] 첨부파일1
	public String attach01_name = "";	// [I/O] 첨부파일명1
	public String attach02 = "";		// [I/O] 첨부파일2
	public String attach02_name = "";	// [I/O] 첨부파일명2
	public String map_list = "";		// [I/O] 매핑 배열값
	public String errorCode = "";		// [O] 에러코드: 0=정상, 1=에러
	public String z_msg_cd = "";		// [O] 에러메시지코드: 04~99
	public String returnMessage = "";	// [O] 에러메시지: 04=to_email빈값, 05=to_name빈값, 06=from_email빈값, 07=from_name빈값, 08=subject빈값, 09=map_content빈값, 10=secure_no빈값, 11=DB INSERT실패, 99=기타오류
}
