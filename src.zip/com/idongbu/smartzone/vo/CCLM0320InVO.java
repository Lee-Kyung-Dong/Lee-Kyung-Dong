package com.idongbu.smartzone.vo;

import java.util.List;
import java.util.Map;

import com.idongbu.common.vo.CMMVO;

public class CCLM0320InVO extends CMMVO{

	public String bsc_if___proc_dvcd = null;  //[I/O] 기본정보_처리구분코드  
	public String bsc_if___msg_cd = null;  //[O] 기본정보_메시지코드  
	public String bsc_if___srch_val = null;  //[I/O] 기본정보_조회값 SS_JOGUN_NO 조건값
	public String bsc_if___ins_cust_no = null;  //[I/O] 기본정보_피보험자고객번호 SS_GOGEK_NO 고객번호
	public String bsc_if___ins_rsdn_btpy_no = null;  //[I/O] 기본정보_피보험자주민사업자번호  
	public String bsc_if___ins_nm = null;  //[I/O] 기본정보_피보험자명 HS_GOGEK_NM 고객명
	public String bsc_if___ins_ag = null;  //[I/O] 기본정보_피보험자연령 SS_GOGEK_AGE 고객나이
	public String bsc_if___accd_ocr_dt = null;  //[I/O] 기본정보_사고발생일자 SS_SAGO_YMD 사고년월일
	public String bsc_if___accd_ocr_tm = null;  //[I/O] 기본정보_사고발생시각 SS_SAGO_HM 사고시간
	public String bsc_if___accd_rpt_no = null;  //[I/O] 기본정보_사고접수번호 SS_SAGO_JUBSU_NO 사고접수번호
	public String bsc_if___ins_cntp_dvcd = null;  //[O] 기본정보_피보험자연락처구분코드  
	public String bsc_if___sms_ts_nd_yn = null;  //[I/O] 기본정보_SMS전송필요여부  
	public String bsc_if___ins_tlp_ofno = null;  //[I/O] 기본정보_피보험자전화국번호  
	public String bsc_if___ins_tlno = null;  //[I/O] 기본정보_피보험자전화번호 SS_GOGEK_TEL 고객전화번호
	public String bsc_if___ins_tlp_arno = null;  //[I/O] 기본정보_피보험자전화지역번호  
	public String bsc_if___arc_dvcd = null;  //[I/O] 기본정보_보험구분코드 SS_BOJ_GB 보종구분
	public String bsc_if___nn_plno = null;  //[I/O] 기본정보_미확인증권번호  
	public String bsc_if___ctc_nn_cnfm_rs_cd = null;  //[I/O] 기본정보_계약미확인사유코드 SS_MIWHAKIN_CD 계약미확인구분
	public String bsc_if___clam_proc_tpcd = null;  //[I/O] 기본정보_보상처리유형코드 BB_GF_GB GF구분
	public String bsc_if___accd_typ_lgcg_cd = null;  //[I/O] 기본정보_사고유형대분류코드 SS_TYPE_CD 사고유형
	public String bsc_if___accd_typ_lgcg_cd_nm = null;  //[I/O] 기본정보_사고유형대분류코드명  
	public String bsc_if___accd_typ_mdcg_cd = null;  //[I/O] 기본정보_사고유형중분류코드 SS_WONIN_CD 사고원인
	public String bsc_if___accd_typ_mdcg_cd_nm = null;  //[I/O] 기본정보_사고유형중분류코드명  
	public String bsc_if___accd_typ_smcg_cd = null;  //[I/O] 기본정보_사고유형소분류코드  
	public String bsc_if___accd_typ_smcg_cd_nm = null;  //[I/O] 기본정보_사고유형소분류코드명  
	public String bsc_if___oprt_vh_lgcg_cd = null;  //[I/O] 기본정보_운행차량대분류코드 SS_UNHENG_CD1 운행차종1
	public String bsc_if___oprt_vh_smcg_cd = null;  //[I/O] 기본정보_운행차량소분류코드 SS_UNHENG_CD2 운행차종2
	public String bsc_if___ps_proc_iscp_cd = null;  //[I/O] 기본정보_기처리보험사코드 SS_CHURI_OFFICE 보험처리회사
	public String bsc_if___ps_proc_arc_cd = null;  //[I/O] 기본정보_기처리보험코드 SS_CHURI_CD 보험처리코드
	public String bsc_if___rsid_dvcd = null;  //[I/O] 기본정보_거주지구분코드 SS_GUJUGI 거주지구분
	public String bsc_if___rsid_dvcd_nm = null;  //[I/O] 기본정보_거주지구분코드명  
	public String bsc_if___nwod_adr_dvcd = null;  //[I/O] 기본정보_신구주소구분코드 SS_SAGO_ZIP_GB 우편번호 신구구분
	public String bsc_if___accd_plc_psno = null;  //[I/O] 기본정보_사고장소우편번호 SS_SAGO_ZIP (구)우편번호
	public String bsc_if___accd_plc_psno_adr = null;  //[I/O] 기본정보_사고장소우편번호주소 HS_SAGO_ZIP (구)우편번호명
	public String bsc_if___accd_plc_dtl_adr = null;  //[I/O] 기본정보_사고장소상세주소 HS_SAGO_JANGSO (구)사고장소명
	public String bsc_if___accd_ocr_plc_dvcd = null;  //[I/O] 기본정보_사고발생장소구분코드 SS_SAGO_JANGSO_GB 사고장소구분
	public String bsc_if___accd_ocr_plc_dvcd_nm = null;  //[I/O] 기본정보_사고발생장소구분코드명  
	public String bsc_if___rpr_inv_org_cd = null;  //[I/O] 기본정보_신고조사기관코드 SS_SINGO_CD 조사기관
	public String bsc_if___uns_mtt_memo_cn = null;  //[I/O] 기본정보_특이사항메모내용 HS-TUKGI-SAHANG 특이사항
	public String bsc_if___accd_plc_secg_cd = null;  //[I] 기본정보_사고장소세분류코드
	public String bsc_if___nn_cnfm_plno = null;  //[I] 기본정보_미확인증권번호
	public String bsc_if___ctc_nn_cnfm_yn = null;  //[

	public String accd_typ_comm_dtl___accd_plc_secg_cd = null;  //[I/O] 사고유형공통_상세_사고장소세분류코드  
	public String accd_typ_comm_dtl___accd_plc_secg_cd_nm = null;  //[I/O] 사고유형공통_상세_사고장소세분류코드명  
	public String accd_typ_comm_dtl___eta_pst_road_nm_adr = null;  //[I/O] 사고유형공통_상세_기타우편도로명주소  
	
	public String accd_rpt_if___accd_oj_rnk = null;  //[I/O] 사고접수정보_사고목적서열  
	public String accd_rpt_if___chng_sqno = null;  //[I/O] 사고접수정보_변경일련번호  
	public String accd_rpt_if___iner_accd_rpt_srch_ref_orr = null;  //[I/O] 사고접수정보_통합사고접수조회참조회차  
	public String accd_rpt_if___iner_accd_dmg_rpt_srch_ref_orr = null;  //[I/O] 사고접수정보_통합사고피해접수조회참조회차  
	public String accd_rpt_if___rptr_rlt_dvcd = null;  //[I/O] 사고접수정보_통보자관계구분코드 SS_TONGBOJA_GWANGYE 통보자관계
	public String accd_rpt_if___rptr_nm = null;  //[I/O] 사고접수정보_통보자명 HS_TONGBOJA_NM 통보자명
	public String accd_rpt_if___rptr_clam_rlps_sqno = null;  //[I/O] 사고접수정보_통보자보상관련자일련번호  
	public String accd_rpt_if___rptr_cntp_dvcd = null;  //[I/O] 사고접수정보_통보자연락처구분코드  
	public String accd_rpt_if___rptr_cntp_ofno = null;  //[I/O] 사고접수정보_통보자연락처국번호  
	public String accd_rpt_if___rptr_cntp_sqno = null;  //[I/O] 사고접수정보_통보자연락처일련번호  
	public String accd_rpt_if___rptr_cntp_tlno = null;  //[I/O] 사고접수정보_통보자연락처전화번호 SS_TONGBOJA_TEL 통보자전화번호
	public String accd_rpt_if___rptr_cntp_arno = null;  //[I/O] 사고접수정보_통보자연락처지역번호  
	public String accd_rpt_if___ins_rlt_cd = null;  //[O] 사고접수정보_피보험자관계코드  
	public String accd_rpt_if___ins_cntp_dvcd = null;  //[O] 사고접수정보_피보험자연락처구분코드  
	public String accd_rpt_if___ins_cntp_ofno = null;  //[O] 사고접수정보_피보험자연락처국번호  
	public String accd_rpt_if___ins_cntp_tlno = null;  //[O] 사고접수정보_피보험자연락처전화번호  
	public String accd_rpt_if___ins_cntp_arno = null;  //[O] 사고접수정보_피보험자연락처지역번호  
	public String accd_rpt_if___accd_cn = null;  //[I/O] 사고접수정보_사고내용 HS_SAGO_NEYONG 사고내용
	public String accd_rpt_if___accd_rpt_tm = null;  //[I/O] 사고접수정보_사고접수시각 SS_JUBSU_HM 접수시간
	public String accd_rpt_if___accd_rpt_dt = null;  //[I/O] 사고접수정보_사고접수일자 SS_JUBSU_YMD 접수년월일
	public String accd_rpt_if___accd_rcvr_cntr_cd = null;  //[I/O] 사고접수정보_사고접수자센터코드  
	public String accd_rpt_if___accd_rcvr_team_cd = null;  //[I/O] 사고접수정보_사고접수자팀코드  	
	public String accd_rpt_if___accd_rcvr_nm = null;  //[I/O] 사고접수정보_사고접수자명 HS_JUBSUJA_NM 접수자명	
	public String accd_rpt_if___accd_rcvr_empno = null;  //[I/O] 사고접수정보_사고접수자사원번호 SS_JUBSUJA 접수자	
	public String accd_rpt_if___imag_exis_yn = null;  //[I/O] 사고접수정보_이미지존재여부 SS_B_IMAGE 이미지구분
	public String accd_rpt_if___memo_ntft_yn = null;  //[I/O] 사고접수정보_메모알림여부 SS_B_MEMO 메모구분
	public String accd_rpt_if___accd_rpt_cplt_yn = null;  //[I/O] 사고접수정보_접수완료여부 SS_WALRYO_YN 완료구분
	public String accd_rpt_if___accd_prg_crs_cd = null;  //[I/O] 사고접수정보_사고진행과정코드 BB_PROTECT_YN 사고조사, 보상종결건구분
	public String accd_rpt_if___accd_prg_crs_cd_nm = null;  //[I/O] 사고접수정보_사고진행과정코드명  
	public String accd_rpt_if___accd_rpt_chn_dvcd = null;  //[I/O] 사고접수정보_사고접수채널구분코드 SS_JUBSU_CHANNEL 접수채널
	public String accd_rpt_if___dcu_prs_mtd_cd = null;  //[I/O] 사고접수정보_서류제출방법코드 SS_SERYU_GB 서류제출구분
	public String accd_rpt_if___dcu_prs_cd = null;  //[I/O] 사고접수정보_서류제출코드 SS_SERYU_CD 서류제출코드
	public String accd_rpt_if___bnf_rmn_acc_acc_dvcd = null;  //[I/O] 사고접수정보_보험금송금계좌계좌구분코드 SS_GYEJWA_YN 계좌번호입력유무
	public String accd_rpt_if___bnf_rmn_acc_acc_dvcd_nm = null;  //[I/O] 사고접수정보_보험금송금계좌계좌구분코드명  
	public String accd_rpt_if___bnf_rmn_acc_acc_no = null;  //[I/O] 사고접수정보_보험금송금계좌계좌번호 SS_GYEJWA_NO 계좌번호
	public String accd_rpt_if___bnf_rmn_acc_dpsr = null;  //[I/O] 사고접수정보_보험금송금계좌예금주  
	public String accd_rpt_if___bnf_rmn_acc_bank_cd = null;  //[I/O] 사고접수정보_보험금송금계좌은행코드 SS_BANK_CD 은행코드
	public String accd_rpt_if___bnf_rmn_acc_bank_cd_nm = null;  //[I/O] 사고접수정보_보험금송금계좌은행코드명  
	public String accd_rpt_if___bnf_rmn_acc_cnfm_dvcd = null;  //[I/O] 사고접수정보_보험금송금계좌확인구분코드  
	public String accd_rpt_if___bnf_rmn_acc_cnfm_dvcd_nm = null;  //[I/O] 사고접수정보_보험금송금계좌확인구분코드명  
	public String accd_rpt_if___expt_lsat_cd = null;  //[I/O] 사고접수정보_예상손해액  
	public String accd_rpt_if___clam_psic_nm = null;  //[O] 사고접수정보_보상담당자명  
	public String accd_rpt_if___clam_psic_empno = null;  //[O] 사고접수정보_보상담당자사원번호  
	public String accd_rpt_if___clam_psic_id = null;  //[O] 사고접수정보_보상담당자id  
	public String accd_rpt_if___if_psic_nm = null;  //[O] 사고접수정보_정보입력자명  
	public String accd_rpt_if___if_psic_empno = null;  //[O] 사고접수정보_정보입력자사원번호  
	public String accd_rpt_if___if_psic_id = null;  //[O] 사고접수정보_정보입력자id  
	public String accd_rpt_if___plno = null;  //[I] 사고접수정보_증권번호  
	public String accd_rpt_if___rptr_sms_snd_yn = null;  //[I] 사고접수정보_통보자SMS발송여부  
	public String accd_rpt_if___ins_sms_snd_yn = null;  //[I] 사고접수정보_피보험자SMS발송여부
	
	public String dmg_cn_if___ltm_dmg_cn_grp_cd = null;  //[I/O] 피해내용정보_장기피해내용그룹코드  
	public String dmg_cn_if___ltm_dmg_cn_cd = null;  //[I/O] 피해내용정보_장기피해내용코드  
	public String dmg_cn_if___accd_oj_rnk = null;  //[I/O] 피해내용정보_사고목적서열  
	public String dmg_cn_if___chng_sqno = null;  //[I/O] 피해내용정보_변경일련번호 
	public String errorCode = null;  //[I/O] 에러코드
	public String accd_rpt_if___clam_psic_tlp_ofno = null;  //[O] 사고접수정보_보상담당자전화국번호
	public String Accd_rpt_if___clam_psic_tlno = null;  //[O] 사고접수정보_보상담당자전화국번호
	public String Accd_rpt_if___clam_psic_tlp_arno = null;  //[O] 사고접수정보_보상담당자전화국번호
	
	public String bsc_if___accd_oj_dvcd = null;
	public String bsc_if___accd_oj_rnk = null;
	
	public String getBsc_if___ctc_nn_cnfm_yn() {
		return bsc_if___ctc_nn_cnfm_yn;
	}
	public void setBsc_if___ctc_nn_cnfm_yn(String bsc_if___ctc_nn_cnfm_yn) {
		this.bsc_if___ctc_nn_cnfm_yn = bsc_if___ctc_nn_cnfm_yn;
	}
	public String getBsc_if___nn_cnfm_plno() {
		return bsc_if___nn_cnfm_plno;
	}
	public void setBsc_if___nn_cnfm_plno(String bsc_if___nn_cnfm_plno) {
		this.bsc_if___nn_cnfm_plno = bsc_if___nn_cnfm_plno;
	}
	public String getAccd_rpt_if___clam_psic_tlp_arno() {
		return Accd_rpt_if___clam_psic_tlp_arno;
	}
	public void setAccd_rpt_if___clam_psic_tlp_arno(
			String accd_rpt_if___clam_psic_tlp_arno) {
		Accd_rpt_if___clam_psic_tlp_arno = accd_rpt_if___clam_psic_tlp_arno;
	}
	public String getAccd_rpt_if___clam_psic_tlno() {
		return Accd_rpt_if___clam_psic_tlno;
	}
	public void setAccd_rpt_if___clam_psic_tlno(String accd_rpt_if___clam_psic_tlno) {
		Accd_rpt_if___clam_psic_tlno = accd_rpt_if___clam_psic_tlno;
	}
	public String getAccd_rpt_if___clam_psic_tlp_ofno() {
		return accd_rpt_if___clam_psic_tlp_ofno;
	}
	public void setAccd_rpt_if___clam_psic_tlp_ofno(
			String accd_rpt_if___clam_psic_tlp_ofno) {
		this.accd_rpt_if___clam_psic_tlp_ofno = accd_rpt_if___clam_psic_tlp_ofno;
	}
	public String getBsc_if___proc_dvcd() {
		return bsc_if___proc_dvcd;
	}
	public void setBsc_if___proc_dvcd(String bsc_if___proc_dvcd) {
		this.bsc_if___proc_dvcd = bsc_if___proc_dvcd;
	}
	public String getBsc_if___msg_cd() {
		return bsc_if___msg_cd;
	}
	public void setBsc_if___msg_cd(String bsc_if___msg_cd) {
		this.bsc_if___msg_cd = bsc_if___msg_cd;
	}
	public String getBsc_if___srch_val() {
		return bsc_if___srch_val;
	}
	public void setBsc_if___srch_val(String bsc_if___srch_val) {
		this.bsc_if___srch_val = bsc_if___srch_val;
	}
	public String getBsc_if___ins_cust_no() {
		return bsc_if___ins_cust_no;
	}
	public void setBsc_if___ins_cust_no(String bsc_if___ins_cust_no) {
		this.bsc_if___ins_cust_no = bsc_if___ins_cust_no;
	}
	public String getBsc_if___ins_rsdn_btpy_no() {
		return bsc_if___ins_rsdn_btpy_no;
	}
	public void setBsc_if___ins_rsdn_btpy_no(String bsc_if___ins_rsdn_btpy_no) {
		this.bsc_if___ins_rsdn_btpy_no = bsc_if___ins_rsdn_btpy_no;
	}
	public String getBsc_if___ins_nm() {
		return bsc_if___ins_nm;
	}
	public void setBsc_if___ins_nm(String bsc_if___ins_nm) {
		this.bsc_if___ins_nm = bsc_if___ins_nm;
	}
	public String getBsc_if___ins_ag() {
		return bsc_if___ins_ag;
	}
	public void setBsc_if___ins_ag(String bsc_if___ins_ag) {
		this.bsc_if___ins_ag = bsc_if___ins_ag;
	}
	public String getBsc_if___accd_ocr_dt() {
		return bsc_if___accd_ocr_dt;
	}
	public void setBsc_if___accd_ocr_dt(String bsc_if___accd_ocr_dt) {
		this.bsc_if___accd_ocr_dt = bsc_if___accd_ocr_dt;
	}
	public String getBsc_if___accd_ocr_tm() {
		return bsc_if___accd_ocr_tm;
	}
	public void setBsc_if___accd_ocr_tm(String bsc_if___accd_ocr_tm) {
		this.bsc_if___accd_ocr_tm = bsc_if___accd_ocr_tm;
	}
	public String getBsc_if___accd_rpt_no() {
		return bsc_if___accd_rpt_no;
	}
	public void setBsc_if___accd_rpt_no(String bsc_if___accd_rpt_no) {
		this.bsc_if___accd_rpt_no = bsc_if___accd_rpt_no;
	}
	public String getBsc_if___ins_cntp_dvcd() {
		return bsc_if___ins_cntp_dvcd;
	}
	public void setBsc_if___ins_cntp_dvcd(String bsc_if___ins_cntp_dvcd) {
		this.bsc_if___ins_cntp_dvcd = bsc_if___ins_cntp_dvcd;
	}
	public String getBsc_if___sms_ts_nd_yn() {
		return bsc_if___sms_ts_nd_yn;
	}
	public void setBsc_if___sms_ts_nd_yn(String bsc_if___sms_ts_nd_yn) {
		this.bsc_if___sms_ts_nd_yn = bsc_if___sms_ts_nd_yn;
	}
	public String getBsc_if___ins_tlp_ofno() {
		return bsc_if___ins_tlp_ofno;
	}
	public void setBsc_if___ins_tlp_ofno(String bsc_if___ins_tlp_ofno) {
		this.bsc_if___ins_tlp_ofno = bsc_if___ins_tlp_ofno;
	}
	public String getBsc_if___ins_tlno() {
		return bsc_if___ins_tlno;
	}
	public void setBsc_if___ins_tlno(String bsc_if___ins_tlno) {
		this.bsc_if___ins_tlno = bsc_if___ins_tlno;
	}
	public String getBsc_if___ins_tlp_arno() {
		return bsc_if___ins_tlp_arno;
	}
	public void setBsc_if___ins_tlp_arno(String bsc_if___ins_tlp_arno) {
		this.bsc_if___ins_tlp_arno = bsc_if___ins_tlp_arno;
	}
	public String getBsc_if___arc_dvcd() {
		return bsc_if___arc_dvcd;
	}
	public void setBsc_if___arc_dvcd(String bsc_if___arc_dvcd) {
		this.bsc_if___arc_dvcd = bsc_if___arc_dvcd;
	}
	public String getBsc_if___nn_plno() {
		return bsc_if___nn_plno;
	}
	public void setBsc_if___nn_plno(String bsc_if___nn_plno) {
		this.bsc_if___nn_plno = bsc_if___nn_plno;
	}
	public String getBsc_if___ctc_nn_cnfm_rs_cd() {
		return bsc_if___ctc_nn_cnfm_rs_cd;
	}
	public void setBsc_if___ctc_nn_cnfm_rs_cd(String bsc_if___ctc_nn_cnfm_rs_cd) {
		this.bsc_if___ctc_nn_cnfm_rs_cd = bsc_if___ctc_nn_cnfm_rs_cd;
	}
	public String getBsc_if___clam_proc_tpcd() {
		return bsc_if___clam_proc_tpcd;
	}
	public void setBsc_if___clam_proc_tpcd(String bsc_if___clam_proc_tpcd) {
		this.bsc_if___clam_proc_tpcd = bsc_if___clam_proc_tpcd;
	}
	public String getBsc_if___accd_typ_lgcg_cd() {
		return bsc_if___accd_typ_lgcg_cd;
	}
	public void setBsc_if___accd_typ_lgcg_cd(String bsc_if___accd_typ_lgcg_cd) {
		this.bsc_if___accd_typ_lgcg_cd = bsc_if___accd_typ_lgcg_cd;
	}
	public String getBsc_if___accd_typ_lgcg_cd_nm() {
		return bsc_if___accd_typ_lgcg_cd_nm;
	}
	public void setBsc_if___accd_typ_lgcg_cd_nm(String bsc_if___accd_typ_lgcg_cd_nm) {
		this.bsc_if___accd_typ_lgcg_cd_nm = bsc_if___accd_typ_lgcg_cd_nm;
	}
	public String getBsc_if___accd_typ_mdcg_cd() {
		return bsc_if___accd_typ_mdcg_cd;
	}
	public void setBsc_if___accd_typ_mdcg_cd(String bsc_if___accd_typ_mdcg_cd) {
		this.bsc_if___accd_typ_mdcg_cd = bsc_if___accd_typ_mdcg_cd;
	}
	public String getBsc_if___accd_typ_mdcg_cd_nm() {
		return bsc_if___accd_typ_mdcg_cd_nm;
	}
	public void setBsc_if___accd_typ_mdcg_cd_nm(String bsc_if___accd_typ_mdcg_cd_nm) {
		this.bsc_if___accd_typ_mdcg_cd_nm = bsc_if___accd_typ_mdcg_cd_nm;
	}
	public String getBsc_if___accd_typ_smcg_cd() {
		return bsc_if___accd_typ_smcg_cd;
	}
	public void setBsc_if___accd_typ_smcg_cd(String bsc_if___accd_typ_smcg_cd) {
		this.bsc_if___accd_typ_smcg_cd = bsc_if___accd_typ_smcg_cd;
	}
	public String getBsc_if___accd_typ_smcg_cd_nm() {
		return bsc_if___accd_typ_smcg_cd_nm;
	}
	public void setBsc_if___accd_typ_smcg_cd_nm(String bsc_if___accd_typ_smcg_cd_nm) {
		this.bsc_if___accd_typ_smcg_cd_nm = bsc_if___accd_typ_smcg_cd_nm;
	}
	public String getBsc_if___oprt_vh_lgcg_cd() {
		return bsc_if___oprt_vh_lgcg_cd;
	}
	public void setBsc_if___oprt_vh_lgcg_cd(String bsc_if___oprt_vh_lgcg_cd) {
		this.bsc_if___oprt_vh_lgcg_cd = bsc_if___oprt_vh_lgcg_cd;
	}
	public String getBsc_if___oprt_vh_smcg_cd() {
		return bsc_if___oprt_vh_smcg_cd;
	}
	public void setBsc_if___oprt_vh_smcg_cd(String bsc_if___oprt_vh_smcg_cd) {
		this.bsc_if___oprt_vh_smcg_cd = bsc_if___oprt_vh_smcg_cd;
	}
	public String getBsc_if___ps_proc_iscp_cd() {
		return bsc_if___ps_proc_iscp_cd;
	}
	public void setBsc_if___ps_proc_iscp_cd(String bsc_if___ps_proc_iscp_cd) {
		this.bsc_if___ps_proc_iscp_cd = bsc_if___ps_proc_iscp_cd;
	}
	public String getBsc_if___ps_proc_arc_cd() {
		return bsc_if___ps_proc_arc_cd;
	}
	public void setBsc_if___ps_proc_arc_cd(String bsc_if___ps_proc_arc_cd) {
		this.bsc_if___ps_proc_arc_cd = bsc_if___ps_proc_arc_cd;
	}
	public String getBsc_if___rsid_dvcd() {
		return bsc_if___rsid_dvcd;
	}
	public void setBsc_if___rsid_dvcd(String bsc_if___rsid_dvcd) {
		this.bsc_if___rsid_dvcd = bsc_if___rsid_dvcd;
	}
	public String getBsc_if___rsid_dvcd_nm() {
		return bsc_if___rsid_dvcd_nm;
	}
	public void setBsc_if___rsid_dvcd_nm(String bsc_if___rsid_dvcd_nm) {
		this.bsc_if___rsid_dvcd_nm = bsc_if___rsid_dvcd_nm;
	}
	public String getBsc_if___nwod_adr_dvcd() {
		return bsc_if___nwod_adr_dvcd;
	}
	public void setBsc_if___nwod_adr_dvcd(String bsc_if___nwod_adr_dvcd) {
		this.bsc_if___nwod_adr_dvcd = bsc_if___nwod_adr_dvcd;
	}
	public String getBsc_if___accd_plc_psno() {
		return bsc_if___accd_plc_psno;
	}
	public void setBsc_if___accd_plc_psno(String bsc_if___accd_plc_psno) {
		this.bsc_if___accd_plc_psno = bsc_if___accd_plc_psno;
	}
	public String getBsc_if___accd_plc_psno_adr() {
		return bsc_if___accd_plc_psno_adr;
	}
	public void setBsc_if___accd_plc_psno_adr(String bsc_if___accd_plc_psno_adr) {
		this.bsc_if___accd_plc_psno_adr = bsc_if___accd_plc_psno_adr;
	}
	public String getBsc_if___accd_plc_dtl_adr() {
		return bsc_if___accd_plc_dtl_adr;
	}
	public void setBsc_if___accd_plc_dtl_adr(String bsc_if___accd_plc_dtl_adr) {
		this.bsc_if___accd_plc_dtl_adr = bsc_if___accd_plc_dtl_adr;
	}
	public String getBsc_if___accd_ocr_plc_dvcd() {
		return bsc_if___accd_ocr_plc_dvcd;
	}
	public void setBsc_if___accd_ocr_plc_dvcd(String bsc_if___accd_ocr_plc_dvcd) {
		this.bsc_if___accd_ocr_plc_dvcd = bsc_if___accd_ocr_plc_dvcd;
	}
	public String getBsc_if___accd_ocr_plc_dvcd_nm() {
		return bsc_if___accd_ocr_plc_dvcd_nm;
	}
	public void setBsc_if___accd_ocr_plc_dvcd_nm(
			String bsc_if___accd_ocr_plc_dvcd_nm) {
		this.bsc_if___accd_ocr_plc_dvcd_nm = bsc_if___accd_ocr_plc_dvcd_nm;
	}
	public String getBsc_if___rpr_inv_org_cd() {
		return bsc_if___rpr_inv_org_cd;
	}
	public void setBsc_if___rpr_inv_org_cd(String bsc_if___rpr_inv_org_cd) {
		this.bsc_if___rpr_inv_org_cd = bsc_if___rpr_inv_org_cd;
	}
	public String getBsc_if___uns_mtt_memo_cn() {
		return bsc_if___uns_mtt_memo_cn;
	}
	public void setBsc_if___uns_mtt_memo_cn(String bsc_if___uns_mtt_memo_cn) {
		this.bsc_if___uns_mtt_memo_cn = bsc_if___uns_mtt_memo_cn;
	}
	public String getAccd_typ_comm_dtl___accd_plc_secg_cd() {
		return accd_typ_comm_dtl___accd_plc_secg_cd;
	}
	public void setAccd_typ_comm_dtl___accd_plc_secg_cd(
			String accd_typ_comm_dtl___accd_plc_secg_cd) {
		this.accd_typ_comm_dtl___accd_plc_secg_cd = accd_typ_comm_dtl___accd_plc_secg_cd;
	}
	public String getAccd_typ_comm_dtl___accd_plc_secg_cd_nm() {
		return accd_typ_comm_dtl___accd_plc_secg_cd_nm;
	}
	public void setAccd_typ_comm_dtl___accd_plc_secg_cd_nm(
			String accd_typ_comm_dtl___accd_plc_secg_cd_nm) {
		this.accd_typ_comm_dtl___accd_plc_secg_cd_nm = accd_typ_comm_dtl___accd_plc_secg_cd_nm;
	}
	public String getAccd_typ_comm_dtl___eta_pst_road_nm_adr() {
		return accd_typ_comm_dtl___eta_pst_road_nm_adr;
	}
	public void setAccd_typ_comm_dtl___eta_pst_road_nm_adr(
			String accd_typ_comm_dtl___eta_pst_road_nm_adr) {
		this.accd_typ_comm_dtl___eta_pst_road_nm_adr = accd_typ_comm_dtl___eta_pst_road_nm_adr;
	}
	public String getAccd_rpt_if___accd_oj_rnk() {
		return accd_rpt_if___accd_oj_rnk;
	}
	public void setAccd_rpt_if___accd_oj_rnk(String accd_rpt_if___accd_oj_rnk) {
		this.accd_rpt_if___accd_oj_rnk = accd_rpt_if___accd_oj_rnk;
	}
	public String getAccd_rpt_if___chng_sqno() {
		return accd_rpt_if___chng_sqno;
	}
	public void setAccd_rpt_if___chng_sqno(String accd_rpt_if___chng_sqno) {
		this.accd_rpt_if___chng_sqno = accd_rpt_if___chng_sqno;
	}
	public String getAccd_rpt_if___iner_accd_rpt_srch_ref_orr() {
		return accd_rpt_if___iner_accd_rpt_srch_ref_orr;
	}
	public void setAccd_rpt_if___iner_accd_rpt_srch_ref_orr(
			String accd_rpt_if___iner_accd_rpt_srch_ref_orr) {
		this.accd_rpt_if___iner_accd_rpt_srch_ref_orr = accd_rpt_if___iner_accd_rpt_srch_ref_orr;
	}
	public String getAccd_rpt_if___iner_accd_dmg_rpt_srch_ref_orr() {
		return accd_rpt_if___iner_accd_dmg_rpt_srch_ref_orr;
	}
	public void setAccd_rpt_if___iner_accd_dmg_rpt_srch_ref_orr(
			String accd_rpt_if___iner_accd_dmg_rpt_srch_ref_orr) {
		this.accd_rpt_if___iner_accd_dmg_rpt_srch_ref_orr = accd_rpt_if___iner_accd_dmg_rpt_srch_ref_orr;
	}
	public String getAccd_rpt_if___rptr_rlt_dvcd() {
		return accd_rpt_if___rptr_rlt_dvcd;
	}
	public void setAccd_rpt_if___rptr_rlt_dvcd(String accd_rpt_if___rptr_rlt_dvcd) {
		this.accd_rpt_if___rptr_rlt_dvcd = accd_rpt_if___rptr_rlt_dvcd;
	}
	public String getAccd_rpt_if___rptr_nm() {
		return accd_rpt_if___rptr_nm;
	}
	public void setAccd_rpt_if___rptr_nm(String accd_rpt_if___rptr_nm) {
		this.accd_rpt_if___rptr_nm = accd_rpt_if___rptr_nm;
	}
	public String getAccd_rpt_if___rptr_clam_rlps_sqno() {
		return accd_rpt_if___rptr_clam_rlps_sqno;
	}
	public void setAccd_rpt_if___rptr_clam_rlps_sqno(
			String accd_rpt_if___rptr_clam_rlps_sqno) {
		this.accd_rpt_if___rptr_clam_rlps_sqno = accd_rpt_if___rptr_clam_rlps_sqno;
	}
	public String getAccd_rpt_if___rptr_cntp_dvcd() {
		return accd_rpt_if___rptr_cntp_dvcd;
	}
	public void setAccd_rpt_if___rptr_cntp_dvcd(String accd_rpt_if___rptr_cntp_dvcd) {
		this.accd_rpt_if___rptr_cntp_dvcd = accd_rpt_if___rptr_cntp_dvcd;
	}
	public String getAccd_rpt_if___rptr_cntp_ofno() {
		return accd_rpt_if___rptr_cntp_ofno;
	}
	public void setAccd_rpt_if___rptr_cntp_ofno(String accd_rpt_if___rptr_cntp_ofno) {
		this.accd_rpt_if___rptr_cntp_ofno = accd_rpt_if___rptr_cntp_ofno;
	}
	public String getAccd_rpt_if___rptr_cntp_sqno() {
		return accd_rpt_if___rptr_cntp_sqno;
	}
	public void setAccd_rpt_if___rptr_cntp_sqno(String accd_rpt_if___rptr_cntp_sqno) {
		this.accd_rpt_if___rptr_cntp_sqno = accd_rpt_if___rptr_cntp_sqno;
	}
	public String getAccd_rpt_if___rptr_cntp_tlno() {
		return accd_rpt_if___rptr_cntp_tlno;
	}
	public void setAccd_rpt_if___rptr_cntp_tlno(String accd_rpt_if___rptr_cntp_tlno) {
		this.accd_rpt_if___rptr_cntp_tlno = accd_rpt_if___rptr_cntp_tlno;
	}
	public String getAccd_rpt_if___rptr_cntp_arno() {
		return accd_rpt_if___rptr_cntp_arno;
	}
	public void setAccd_rpt_if___rptr_cntp_arno(String accd_rpt_if___rptr_cntp_arno) {
		this.accd_rpt_if___rptr_cntp_arno = accd_rpt_if___rptr_cntp_arno;
	}
	public String getAccd_rpt_if___ins_rlt_cd() {
		return accd_rpt_if___ins_rlt_cd;
	}
	public void setAccd_rpt_if___ins_rlt_cd(String accd_rpt_if___ins_rlt_cd) {
		this.accd_rpt_if___ins_rlt_cd = accd_rpt_if___ins_rlt_cd;
	}
	public String getAccd_rpt_if___ins_cntp_dvcd() {
		return accd_rpt_if___ins_cntp_dvcd;
	}
	public void setAccd_rpt_if___ins_cntp_dvcd(String accd_rpt_if___ins_cntp_dvcd) {
		this.accd_rpt_if___ins_cntp_dvcd = accd_rpt_if___ins_cntp_dvcd;
	}
	public String getAccd_rpt_if___ins_cntp_ofno() {
		return accd_rpt_if___ins_cntp_ofno;
	}
	public void setAccd_rpt_if___ins_cntp_ofno(String accd_rpt_if___ins_cntp_ofno) {
		this.accd_rpt_if___ins_cntp_ofno = accd_rpt_if___ins_cntp_ofno;
	}
	public String getAccd_rpt_if___ins_cntp_tlno() {
		return accd_rpt_if___ins_cntp_tlno;
	}
	public void setAccd_rpt_if___ins_cntp_tlno(String accd_rpt_if___ins_cntp_tlno) {
		this.accd_rpt_if___ins_cntp_tlno = accd_rpt_if___ins_cntp_tlno;
	}
	public String getAccd_rpt_if___ins_cntp_arno() {
		return accd_rpt_if___ins_cntp_arno;
	}
	public void setAccd_rpt_if___ins_cntp_arno(String accd_rpt_if___ins_cntp_arno) {
		this.accd_rpt_if___ins_cntp_arno = accd_rpt_if___ins_cntp_arno;
	}
	public String getAccd_rpt_if___accd_cn() {
		return accd_rpt_if___accd_cn;
	}
	public void setAccd_rpt_if___accd_cn(String accd_rpt_if___accd_cn) {
		this.accd_rpt_if___accd_cn = accd_rpt_if___accd_cn;
	}
	public String getAccd_rpt_if___accd_rpt_tm() {
		return accd_rpt_if___accd_rpt_tm;
	}
	public void setAccd_rpt_if___accd_rpt_tm(String accd_rpt_if___accd_rpt_tm) {
		this.accd_rpt_if___accd_rpt_tm = accd_rpt_if___accd_rpt_tm;
	}
	public String getAccd_rpt_if___accd_rpt_dt() {
		return accd_rpt_if___accd_rpt_dt;
	}
	public void setAccd_rpt_if___accd_rpt_dt(String accd_rpt_if___accd_rpt_dt) {
		this.accd_rpt_if___accd_rpt_dt = accd_rpt_if___accd_rpt_dt;
	}
	public String getAccd_rpt_if___accd_rcvr_cntr_cd() {
		return accd_rpt_if___accd_rcvr_cntr_cd;
	}
	public void setAccd_rpt_if___accd_rcvr_cntr_cd(
			String accd_rpt_if___accd_rcvr_cntr_cd) {
		this.accd_rpt_if___accd_rcvr_cntr_cd = accd_rpt_if___accd_rcvr_cntr_cd;
	}
	public String getAccd_rpt_if___accd_rcvr_team_cd() {
		return accd_rpt_if___accd_rcvr_team_cd;
	}
	public void setAccd_rpt_if___accd_rcvr_team_cd(
			String accd_rpt_if___accd_rcvr_team_cd) {
		this.accd_rpt_if___accd_rcvr_team_cd = accd_rpt_if___accd_rcvr_team_cd;
	}
	public String getAccd_rpt_if___accd_rcvr_nm() {
		return accd_rpt_if___accd_rcvr_nm;
	}
	public void setAccd_rpt_if___accd_rcvr_nm(String accd_rpt_if___accd_rcvr_nm) {
		this.accd_rpt_if___accd_rcvr_nm = accd_rpt_if___accd_rcvr_nm;
	}
	public String getAccd_rpt_if___accd_rcvr_empno() {
		return accd_rpt_if___accd_rcvr_empno;
	}
	public void setAccd_rpt_if___accd_rcvr_empno(
			String accd_rpt_if___accd_rcvr_empno) {
		this.accd_rpt_if___accd_rcvr_empno = accd_rpt_if___accd_rcvr_empno;
	}
	public String getAccd_rpt_if___imag_exis_yn() {
		return accd_rpt_if___imag_exis_yn;
	}
	public void setAccd_rpt_if___imag_exis_yn(String accd_rpt_if___imag_exis_yn) {
		this.accd_rpt_if___imag_exis_yn = accd_rpt_if___imag_exis_yn;
	}
	public String getAccd_rpt_if___memo_ntft_yn() {
		return accd_rpt_if___memo_ntft_yn;
	}
	public void setAccd_rpt_if___memo_ntft_yn(String accd_rpt_if___memo_ntft_yn) {
		this.accd_rpt_if___memo_ntft_yn = accd_rpt_if___memo_ntft_yn;
	}
	public String getAccd_rpt_if___accd_rpt_cplt_yn() {
		return accd_rpt_if___accd_rpt_cplt_yn;
	}
	public void setAccd_rpt_if___accd_rpt_cplt_yn(
			String accd_rpt_if___accd_rpt_cplt_yn) {
		this.accd_rpt_if___accd_rpt_cplt_yn = accd_rpt_if___accd_rpt_cplt_yn;
	}
	public String getAccd_rpt_if___accd_prg_crs_cd() {
		return accd_rpt_if___accd_prg_crs_cd;
	}
	public void setAccd_rpt_if___accd_prg_crs_cd(
			String accd_rpt_if___accd_prg_crs_cd) {
		this.accd_rpt_if___accd_prg_crs_cd = accd_rpt_if___accd_prg_crs_cd;
	}
	public String getAccd_rpt_if___accd_prg_crs_cd_nm() {
		return accd_rpt_if___accd_prg_crs_cd_nm;
	}
	public void setAccd_rpt_if___accd_prg_crs_cd_nm(
			String accd_rpt_if___accd_prg_crs_cd_nm) {
		this.accd_rpt_if___accd_prg_crs_cd_nm = accd_rpt_if___accd_prg_crs_cd_nm;
	}
	public String getAccd_rpt_if___accd_rpt_chn_dvcd() {
		return accd_rpt_if___accd_rpt_chn_dvcd;
	}
	public void setAccd_rpt_if___accd_rpt_chn_dvcd(
			String accd_rpt_if___accd_rpt_chn_dvcd) {
		this.accd_rpt_if___accd_rpt_chn_dvcd = accd_rpt_if___accd_rpt_chn_dvcd;
	}
	public String getAccd_rpt_if___dcu_prs_mtd_cd() {
		return accd_rpt_if___dcu_prs_mtd_cd;
	}
	public void setAccd_rpt_if___dcu_prs_mtd_cd(String accd_rpt_if___dcu_prs_mtd_cd) {
		this.accd_rpt_if___dcu_prs_mtd_cd = accd_rpt_if___dcu_prs_mtd_cd;
	}
	public String getAccd_rpt_if___dcu_prs_cd() {
		return accd_rpt_if___dcu_prs_cd;
	}
	public void setAccd_rpt_if___dcu_prs_cd(String accd_rpt_if___dcu_prs_cd) {
		this.accd_rpt_if___dcu_prs_cd = accd_rpt_if___dcu_prs_cd;
	}
	public String getAccd_rpt_if___bnf_rmn_acc_acc_dvcd() {
		return accd_rpt_if___bnf_rmn_acc_acc_dvcd;
	}
	public void setAccd_rpt_if___bnf_rmn_acc_acc_dvcd(
			String accd_rpt_if___bnf_rmn_acc_acc_dvcd) {
		this.accd_rpt_if___bnf_rmn_acc_acc_dvcd = accd_rpt_if___bnf_rmn_acc_acc_dvcd;
	}
	public String getAccd_rpt_if___bnf_rmn_acc_acc_dvcd_nm() {
		return accd_rpt_if___bnf_rmn_acc_acc_dvcd_nm;
	}
	public void setAccd_rpt_if___bnf_rmn_acc_acc_dvcd_nm(
			String accd_rpt_if___bnf_rmn_acc_acc_dvcd_nm) {
		this.accd_rpt_if___bnf_rmn_acc_acc_dvcd_nm = accd_rpt_if___bnf_rmn_acc_acc_dvcd_nm;
	}
	public String getAccd_rpt_if___bnf_rmn_acc_acc_no() {
		return accd_rpt_if___bnf_rmn_acc_acc_no;
	}
	public void setAccd_rpt_if___bnf_rmn_acc_acc_no(
			String accd_rpt_if___bnf_rmn_acc_acc_no) {
		this.accd_rpt_if___bnf_rmn_acc_acc_no = accd_rpt_if___bnf_rmn_acc_acc_no;
	}
	public String getAccd_rpt_if___bnf_rmn_acc_dpsr() {
		return accd_rpt_if___bnf_rmn_acc_dpsr;
	}
	public void setAccd_rpt_if___bnf_rmn_acc_dpsr(
			String accd_rpt_if___bnf_rmn_acc_dpsr) {
		this.accd_rpt_if___bnf_rmn_acc_dpsr = accd_rpt_if___bnf_rmn_acc_dpsr;
	}
	public String getAccd_rpt_if___bnf_rmn_acc_bank_cd() {
		return accd_rpt_if___bnf_rmn_acc_bank_cd;
	}
	public void setAccd_rpt_if___bnf_rmn_acc_bank_cd(
			String accd_rpt_if___bnf_rmn_acc_bank_cd) {
		this.accd_rpt_if___bnf_rmn_acc_bank_cd = accd_rpt_if___bnf_rmn_acc_bank_cd;
	}
	public String getAccd_rpt_if___bnf_rmn_acc_bank_cd_nm() {
		return accd_rpt_if___bnf_rmn_acc_bank_cd_nm;
	}
	public void setAccd_rpt_if___bnf_rmn_acc_bank_cd_nm(
			String accd_rpt_if___bnf_rmn_acc_bank_cd_nm) {
		this.accd_rpt_if___bnf_rmn_acc_bank_cd_nm = accd_rpt_if___bnf_rmn_acc_bank_cd_nm;
	}
	public String getAccd_rpt_if___bnf_rmn_acc_cnfm_dvcd() {
		return accd_rpt_if___bnf_rmn_acc_cnfm_dvcd;
	}
	public void setAccd_rpt_if___bnf_rmn_acc_cnfm_dvcd(
			String accd_rpt_if___bnf_rmn_acc_cnfm_dvcd) {
		this.accd_rpt_if___bnf_rmn_acc_cnfm_dvcd = accd_rpt_if___bnf_rmn_acc_cnfm_dvcd;
	}
	public String getAccd_rpt_if___bnf_rmn_acc_cnfm_dvcd_nm() {
		return accd_rpt_if___bnf_rmn_acc_cnfm_dvcd_nm;
	}
	public void setAccd_rpt_if___bnf_rmn_acc_cnfm_dvcd_nm(
			String accd_rpt_if___bnf_rmn_acc_cnfm_dvcd_nm) {
		this.accd_rpt_if___bnf_rmn_acc_cnfm_dvcd_nm = accd_rpt_if___bnf_rmn_acc_cnfm_dvcd_nm;
	}
	public String getAccd_rpt_if___expt_lsat_cd() {
		return accd_rpt_if___expt_lsat_cd;
	}
	public void setAccd_rpt_if___expt_lsat_cd(String accd_rpt_if___expt_lsat_cd) {
		this.accd_rpt_if___expt_lsat_cd = accd_rpt_if___expt_lsat_cd;
	}
	public String getAccd_rpt_if___clam_psic_nm() {
		return accd_rpt_if___clam_psic_nm;
	}
	public void setAccd_rpt_if___clam_psic_nm(String accd_rpt_if___clam_psic_nm) {
		this.accd_rpt_if___clam_psic_nm = accd_rpt_if___clam_psic_nm;
	}
	public String getAccd_rpt_if___clam_psic_empno() {
		return accd_rpt_if___clam_psic_empno;
	}
	public void setAccd_rpt_if___clam_psic_empno(
			String accd_rpt_if___clam_psic_empno) {
		this.accd_rpt_if___clam_psic_empno = accd_rpt_if___clam_psic_empno;
	}
	public String getAccd_rpt_if___clam_psic_id() {
		return accd_rpt_if___clam_psic_id;
	}
	public void setAccd_rpt_if___clam_psic_id(String accd_rpt_if___clam_psic_id) {
		this.accd_rpt_if___clam_psic_id = accd_rpt_if___clam_psic_id;
	}
	public String getAccd_rpt_if___if_psic_nm() {
		return accd_rpt_if___if_psic_nm;
	}
	public void setAccd_rpt_if___if_psic_nm(String accd_rpt_if___if_psic_nm) {
		this.accd_rpt_if___if_psic_nm = accd_rpt_if___if_psic_nm;
	}
	public String getAccd_rpt_if___if_psic_empno() {
		return accd_rpt_if___if_psic_empno;
	}
	public void setAccd_rpt_if___if_psic_empno(String accd_rpt_if___if_psic_empno) {
		this.accd_rpt_if___if_psic_empno = accd_rpt_if___if_psic_empno;
	}
	public String getAccd_rpt_if___if_psic_id() {
		return accd_rpt_if___if_psic_id;
	}
	public void setAccd_rpt_if___if_psic_id(String accd_rpt_if___if_psic_id) {
		this.accd_rpt_if___if_psic_id = accd_rpt_if___if_psic_id;
	}
	public String getAccd_rpt_if___plno() {
		return accd_rpt_if___plno;
	}
	public void setAccd_rpt_if___plno(String accd_rpt_if___plno) {
		this.accd_rpt_if___plno = accd_rpt_if___plno;
	}
	public String getAccd_rpt_if___rptr_sms_snd_yn() {
		return accd_rpt_if___rptr_sms_snd_yn;
	}
	public void setAccd_rpt_if___rptr_sms_snd_yn(
			String accd_rpt_if___rptr_sms_snd_yn) {
		this.accd_rpt_if___rptr_sms_snd_yn = accd_rpt_if___rptr_sms_snd_yn;
	}
	public String getAccd_rpt_if___ins_sms_snd_yn() {
		return accd_rpt_if___ins_sms_snd_yn;
	}
	public void setAccd_rpt_if___ins_sms_snd_yn(String accd_rpt_if___ins_sms_snd_yn) {
		this.accd_rpt_if___ins_sms_snd_yn = accd_rpt_if___ins_sms_snd_yn;
	}
	public String getBsc_if___accd_plc_secg_cd() {
		return bsc_if___accd_plc_secg_cd;
	}
	public void setBsc_if___accd_plc_secg_cd(String bsc_if___accd_plc_secg_cd) {
		this.bsc_if___accd_plc_secg_cd = bsc_if___accd_plc_secg_cd;
	}
	public String getDmg_cn_if___ltm_dmg_cn_grp_cd() {
		return dmg_cn_if___ltm_dmg_cn_grp_cd;
	}
	public void setDmg_cn_if___ltm_dmg_cn_grp_cd(
			String dmg_cn_if___ltm_dmg_cn_grp_cd) {
		this.dmg_cn_if___ltm_dmg_cn_grp_cd = dmg_cn_if___ltm_dmg_cn_grp_cd;
	}
	public String getDmg_cn_if___ltm_dmg_cn_cd() {
		return dmg_cn_if___ltm_dmg_cn_cd;
	}
	public void setDmg_cn_if___ltm_dmg_cn_cd(String dmg_cn_if___ltm_dmg_cn_cd) {
		this.dmg_cn_if___ltm_dmg_cn_cd = dmg_cn_if___ltm_dmg_cn_cd;
	}
	public String getDmg_cn_if___accd_oj_rnk() {
		return dmg_cn_if___accd_oj_rnk;
	}
	public void setDmg_cn_if___accd_oj_rnk(String dmg_cn_if___accd_oj_rnk) {
		this.dmg_cn_if___accd_oj_rnk = dmg_cn_if___accd_oj_rnk;
	}
	public String getDmg_cn_if___chng_sqno() {
		return dmg_cn_if___chng_sqno;
	}
	public void setDmg_cn_if___chng_sqno(String dmg_cn_if___chng_sqno) {
		this.dmg_cn_if___chng_sqno = dmg_cn_if___chng_sqno;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	
	/**
	 * @return the bsc_if___accd_oj_dvcd
	 */
	public String getBsc_if___accd_oj_dvcd() {
		return bsc_if___accd_oj_dvcd;
	}
	/**
	 * @param bsc_if___accd_oj_dvcd the bsc_if___accd_oj_dvcd to set
	 */
	public void setBsc_if___accd_oj_dvcd(String bsc_if___accd_oj_dvcd) {
		this.bsc_if___accd_oj_dvcd = bsc_if___accd_oj_dvcd;
	}
	/**
	 * @return the bsc_if___accd_oj_rnk
	 */
	public String getBsc_if___accd_oj_rnk() {
		return bsc_if___accd_oj_rnk;
	}
	/**
	 * @param bsc_if___accd_oj_rnk the bsc_if___accd_oj_rnk to set
	 */
	public void setBsc_if___accd_oj_rnk(String bsc_if___accd_oj_rnk) {
		this.bsc_if___accd_oj_rnk = bsc_if___accd_oj_rnk;
	}
}
