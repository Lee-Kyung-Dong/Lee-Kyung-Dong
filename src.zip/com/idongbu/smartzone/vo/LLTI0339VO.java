package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

/**
 * @author 81500204
 * 
 * 장기설계 상세조회
 */
public class LLTI0339VO extends CMMVO {
	public String plan_no = ""; // 설계번호

	public String plan_rlps_if__ctc_rlps_rsdn_no[] = new String[0]; // 설계관련자_계약자관련주민번호
	public String plan_rlps_if__ctc_rlps_dvcd[] = new String[0]; // 설계관련자_계약관련자구분코드 (01:계약자)
	public String plan_rlps_if__ctc_rlps_nm[] = new String[0]; // 설계관련자_계약관련자명

	public String lcpl_ctc_if__plan_sqno[] = new String[0]; // 소재지계약정보_설계일련번호
	public String lcpl_ctc_if__plan_id[] = new String[0]; // 소재지계약정보_설계ID

	public String lcpl_fir_dag_cvr_if__plan_id[] = new String[0]; // 소재지화재손해담보정보_설계ID
	public String lcpl_fir_dag_cvr_if__ojt_cd[] = new String[0]; // 소재지화재손해담보정보_목적물코드
	public String lcpl_fir_dag_cvr_if__ojt_nm[] = new String[0]; // 소재지화재손해담보정보_목적물명
	public String lcpl_fir_dag_cvr_if__arc_inam[] = new String[0]; // 소재지화재손해담보정보_보험가입금액
	public String lcpl_fir_dag_cvr_if__bsc_prm[] = new String[0]; // 소재지화재손해담보정보_기본보험료

	public String plan_lcpl_if__lcpl_sqno[] = new String[0]; // 설계소재지정보_소재지일련번호
	public String plan_lcpl_if__lcpl_psno[] = new String[0]; // 설계소재지정보_소재지우편번호
	public String plan_lcpl_if__lcpl_psno_adr[] = new String[0]; // 설계소재지정보_소재지우편번호주소
	public String plan_lcpl_if__lcpl_eta_adr[] = new String[0]; // 설계소재지정보_소재지기타주소

	public String errorCode = "";
	public String z_resp_msg = "";

	public String getPlan_no() {
		return plan_no;
	}
	public void setPlan_no(String plan_no) {
		this.plan_no = plan_no;
	}
	public String[] getPlan_rlps_if__ctc_rlps_rsdn_no() {
		return plan_rlps_if__ctc_rlps_rsdn_no;
	}
	public void setPlan_rlps_if__ctc_rlps_rsdn_no(
			String[] plan_rlps_if__ctc_rlps_rsdn_no) {
		this.plan_rlps_if__ctc_rlps_rsdn_no = plan_rlps_if__ctc_rlps_rsdn_no;
	}
	public String[] getPlan_rlps_if__ctc_rlps_dvcd() {
		return plan_rlps_if__ctc_rlps_dvcd;
	}
	public void setPlan_rlps_if__ctc_rlps_dvcd(String[] plan_rlps_if__ctc_rlps_dvcd) {
		this.plan_rlps_if__ctc_rlps_dvcd = plan_rlps_if__ctc_rlps_dvcd;
	}
	public String[] getPlan_rlps_if__ctc_rlps_nm() {
		return plan_rlps_if__ctc_rlps_nm;
	}
	public void setPlan_rlps_if__ctc_rlps_nm(String[] plan_rlps_if__ctc_rlps_nm) {
		this.plan_rlps_if__ctc_rlps_nm = plan_rlps_if__ctc_rlps_nm;
	}
	public String[] getLcpl_ctc_if__plan_sqno() {
		return lcpl_ctc_if__plan_sqno;
	}
	public void setLcpl_ctc_if__plan_sqno(String[] lcpl_ctc_if__plan_sqno) {
		this.lcpl_ctc_if__plan_sqno = lcpl_ctc_if__plan_sqno;
	}
	public String[] getLcpl_ctc_if__plan_id() {
		return lcpl_ctc_if__plan_id;
	}
	public void setLcpl_ctc_if__plan_id(String[] lcpl_ctc_if__plan_id) {
		this.lcpl_ctc_if__plan_id = lcpl_ctc_if__plan_id;
	}
	public String[] getLcpl_fir_dag_cvr_if__plan_id() {
		return lcpl_fir_dag_cvr_if__plan_id;
	}
	public void setLcpl_fir_dag_cvr_if__plan_id(
			String[] lcpl_fir_dag_cvr_if__plan_id) {
		this.lcpl_fir_dag_cvr_if__plan_id = lcpl_fir_dag_cvr_if__plan_id;
	}
	public String[] getLcpl_fir_dag_cvr_if__ojt_cd() {
		return lcpl_fir_dag_cvr_if__ojt_cd;
	}
	public void setLcpl_fir_dag_cvr_if__ojt_cd(String[] lcpl_fir_dag_cvr_if__ojt_cd) {
		this.lcpl_fir_dag_cvr_if__ojt_cd = lcpl_fir_dag_cvr_if__ojt_cd;
	}
	public String[] getLcpl_fir_dag_cvr_if__ojt_nm() {
		return lcpl_fir_dag_cvr_if__ojt_nm;
	}
	public void setLcpl_fir_dag_cvr_if__ojt_nm(String[] lcpl_fir_dag_cvr_if__ojt_nm) {
		this.lcpl_fir_dag_cvr_if__ojt_nm = lcpl_fir_dag_cvr_if__ojt_nm;
	}
	public String[] getLcpl_fir_dag_cvr_if__arc_inam() {
		return lcpl_fir_dag_cvr_if__arc_inam;
	}
	public void setLcpl_fir_dag_cvr_if__arc_inam(
			String[] lcpl_fir_dag_cvr_if__arc_inam) {
		this.lcpl_fir_dag_cvr_if__arc_inam = lcpl_fir_dag_cvr_if__arc_inam;
	}
	public String[] getLcpl_fir_dag_cvr_if__bsc_prm() {
		return lcpl_fir_dag_cvr_if__bsc_prm;
	}
	public void setLcpl_fir_dag_cvr_if__bsc_prm(
			String[] lcpl_fir_dag_cvr_if__bsc_prm) {
		this.lcpl_fir_dag_cvr_if__bsc_prm = lcpl_fir_dag_cvr_if__bsc_prm;
	}
	public String[] getPlan_lcpl_if__lcpl_sqno() {
		return plan_lcpl_if__lcpl_sqno;
	}
	public void setPlan_lcpl_if__lcpl_sqno(String[] plan_lcpl_if__lcpl_sqno) {
		this.plan_lcpl_if__lcpl_sqno = plan_lcpl_if__lcpl_sqno;
	}
	public String[] getPlan_lcpl_if__lcpl_psno() {
		return plan_lcpl_if__lcpl_psno;
	}
	public void setPlan_lcpl_if__lcpl_psno(String[] plan_lcpl_if__lcpl_psno) {
		this.plan_lcpl_if__lcpl_psno = plan_lcpl_if__lcpl_psno;
	}
	public String[] getPlan_lcpl_if__lcpl_psno_adr() {
		return plan_lcpl_if__lcpl_psno_adr;
	}
	public void setPlan_lcpl_if__lcpl_psno_adr(String[] plan_lcpl_if__lcpl_psno_adr) {
		this.plan_lcpl_if__lcpl_psno_adr = plan_lcpl_if__lcpl_psno_adr;
	}
	public String[] getPlan_lcpl_if__lcpl_eta_adr() {
		return plan_lcpl_if__lcpl_eta_adr;
	}
	public void setPlan_lcpl_if__lcpl_eta_adr(String[] plan_lcpl_if__lcpl_eta_adr) {
		this.plan_lcpl_if__lcpl_eta_adr = plan_lcpl_if__lcpl_eta_adr;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getZ_resp_msg() {
		return z_resp_msg;
	}
	public void setZ_resp_msg(String z_resp_msg) {
		this.z_resp_msg = z_resp_msg;
	}
}
