package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class MMTI0214VO extends CMMVO{
	
	public String phgp_cnfm_dt = null;
	public String phgp_strg_yn = null;
	public String bz_dvn = null;
	public String proc_dvn = null;
	public String plan_ply_dvn = null;
	public String plan_plno = null;
	public String trv_dstc_cnfm_dt = null;
	public String trv_dstc = null;
	public String cnfr_blg_nm = null;
	public String cnfr_nm = null;
	public String cnfr_no = null;
	public String cnfr_ofc_tlno = null;
	public String cnfr_clpno = null;
	public String cnfr_fx_no = null;
	public String rpt_no = null;
	public String pbox_no = null;
	public String apcn_str_dt = null;

	public String errorCode = null;
	
	public String getPhgp_cnfm_dt() {
		return phgp_cnfm_dt;
	}
	public void setPhgp_cnfm_dt(String phgp_cnfm_dt) {
		this.phgp_cnfm_dt = phgp_cnfm_dt;
	}
	public String getPhgp_strg_yn() {
		return phgp_strg_yn;
	}
	public void setPhgp_strg_yn(String phgp_strg_yn) {
		this.phgp_strg_yn = phgp_strg_yn;
	}
	public String getBz_dvn() {
		return bz_dvn;
	}
	public void setBz_dvn(String bz_dvn) {
		this.bz_dvn = bz_dvn;
	}
	public String getProc_dvn() {
		return proc_dvn;
	}
	public void setProc_dvn(String proc_dvn) {
		this.proc_dvn = proc_dvn;
	}
	public String getPlan_ply_dvn() {
		return plan_ply_dvn;
	}
	public void setPlan_ply_dvn(String plan_ply_dvn) {
		this.plan_ply_dvn = plan_ply_dvn;
	}
	public String getPlan_plno() {
		return plan_plno;
	}
	public void setPlan_plno(String plan_plno) {
		this.plan_plno = plan_plno;
	}
	public String getTrv_dstc_cnfm_dt() {
		return trv_dstc_cnfm_dt;
	}
	public void setTrv_dstc_cnfm_dt(String trv_dstc_cnfm_dt) {
		this.trv_dstc_cnfm_dt = trv_dstc_cnfm_dt;
	}
	public String getCnfr_blg_nm() {
		return cnfr_blg_nm;
	}
	public void setCnfr_blg_nm(String cnfr_blg_nm) {
		this.cnfr_blg_nm = cnfr_blg_nm;
	}
	public String getCnfr_nm() {
		return cnfr_nm;
	}
	public void setCnfr_nm(String cnfr_nm) {
		this.cnfr_nm = cnfr_nm;
	}
	public String getCnfr_no() {
		return cnfr_no;
	}
	public void setCnfr_no(String cnfr_no) {
		this.cnfr_no = cnfr_no;
	}
	public String getCnfr_ofc_tlno() {
		return cnfr_ofc_tlno;
	}
	public void setCnfr_ofc_tlno(String cnfr_ofc_tlno) {
		this.cnfr_ofc_tlno = cnfr_ofc_tlno;
	}
	public String getCnfr_clpno() {
		return cnfr_clpno;
	}
	public void setCnfr_clpno(String cnfr_clpno) {
		this.cnfr_clpno = cnfr_clpno;
	}
	public String getCnfr_fx_no() {
		return cnfr_fx_no;
	}
	public void setCnfr_fx_no(String cnfr_fx_no) {
		this.cnfr_fx_no = cnfr_fx_no;
	}
	public String getRpt_no() {
		return rpt_no;
	}
	public void setRpt_no(String rpt_no) {
		this.rpt_no = rpt_no;
	}
	public String getPbox_no() {
		return pbox_no;
	}
	public void setPbox_no(String pbox_no) {
		this.pbox_no = pbox_no;
	}
	public String getApcn_str_dt() {
		return apcn_str_dt;
	}
	public void setApcn_str_dt(String apcn_str_dt) {
		this.apcn_str_dt = apcn_str_dt;
	}
	
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getTrv_dstc() {
		return trv_dstc;
	}
	public void setTrv_dstc(String trv_dstc) {
		this.trv_dstc = trv_dstc;
	}
	

	
	
	
}
