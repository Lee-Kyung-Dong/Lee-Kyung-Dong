package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

// KCUS0165: 손비처리용ARS납입증명서 발급

public class KCUS0165VO extends CMMVO {

	public String cust_dcmt_no	= ""; // [I] 고객식별번호
	public String bse_yy		= ""; // [I] 기준년
	public String cust_nm	 	= ""; // [O] 고객명
	public String rsdn_no		= ""; // [O] 주민번호
	public String psno			= ""; // [O] 우편번호
	public String psno_nm		= ""; // [O] 우편번호명
	public String eta_adr	 	= ""; // [O] 기타주소
	
	// 자동차납입증명목록
	public String[] btpy_ars_pym_crtf_isu_at__plno						= new String[0]; // [O] 자보증권번호
	public String[] btpy_ars_pym_crtf_isu_at__ins_nm					= new String[0]; // [O] 자보피보험자명
	public String[] btpy_ars_pym_crtf_isu_at__ins_rlt					= new String[0]; // [O] 자보피보험자관계
	public String[] btpy_ars_pym_crtf_isu_at__inpd_cd					= new String[0]; // [O] 자보보종코드
	public String[] btpy_ars_pym_crtf_isu_at__inpd_nm					= new String[0]; // [O] 자보보종명
	public String[] btpy_ars_pym_crtf_isu_at__pym_mtd_cd				= new String[0]; // [O] 자보납입방법코드
	public String[] btpy_ars_pym_crtf_isu_at__pym_mtd_nm				= new String[0]; // [O] 자보납입방법명
	public String[] btpy_ars_pym_crtf_isu_at__fnal_pym_ym				= new String[0]; // [O] 자보최종납입년월
	public String[] btpy_ars_pym_crtf_isu_at__pym_nts					= new String[0]; // [O] 자보납입횟수
	public String[] btpy_ars_pym_crtf_isu_at__vh_no						= new String[0]; // [O] 자보차량번호
	public String[] btpy_ars_pym_crtf_isu_at__icdd_tgt_asrt_prm			= new String[0]; // [O] 소득공제대상보장성보험료
	public String[] btpy_ars_pym_crtf_isu_at__icdd_tgt_dsab_asrt_prm	= new String[0]; // [O] 소득공제대상장애인보장성보험료
	public String[] btpy_ars_pym_crtf_isu_at__ctc_stat_cd				= new String[0]; // [O] 계약상태코드
	public String[] btpy_ars_pym_crtf_isu_at__ctc_stat_nm				= new String[0]; // [O] 계약상태명
	public String[] btpy_ars_pym_crtf_isu_at__arc_trm_str_dt			= new String[0]; // [O] 보험기간시작일자
	public String[] btpy_ars_pym_crtf_isu_at__arc_trm_fin_dt			= new String[0]; // [O] 보험기간종료일자
	
	// 장기납입증명목록
	public String[] btpy_ars_pym_crtf_isu_ltm__plno							= new String[0]; // [O] 장기증권번호
	public String[] btpy_ars_pym_crtf_isu_ltm__ins_nm						= new String[0]; // [O] 장기피보험자명
	public String[] btpy_ars_pym_crtf_isu_ltm__inpd_cd						= new String[0]; // [O] 장기보종코드
	public String[] btpy_ars_pym_crtf_isu_ltm__inpd_nm						= new String[0]; // [O] 장기보종명
	public String[] btpy_ars_pym_crtf_isu_ltm__pym_mtd_cd					= new String[0]; // [O] 장기납입방법코드
	public String[] btpy_ars_pym_crtf_isu_ltm__pym_mtd_nm					= new String[0]; // [O] 장기납입방법명
	public String[] btpy_ars_pym_crtf_isu_ltm__fnal_pym_ym					= new String[0]; // [O] 장기최종납입년월
	public String[] btpy_ars_pym_crtf_isu_ltm__pym_nts						= new String[0]; // [O] 장기최종납입횟수
	public String[] btpy_ars_pym_crtf_isu_ltm__sm_prm						= new String[0]; // [O] 합계보험료
	public String[] btpy_ars_pym_crtf_isu_ltm__vh_no						= new String[0]; // [O] 장기차량번호
	public String[] btpy_ars_pym_crtf_isu_ltm__ltm_icdd_tgt_asrt_prm		= new String[0]; // [O] 장기적립순보험료
	public String[] btpy_ars_pym_crtf_isu_ltm__ltm_icdd_tgt_prn_pnn_prm		= new String[0]; // [O] 장기소득공제대상개인연금보험료
	public String[] btpy_ars_pym_crtf_isu_ltm__ltm_icdd_tgt_pnn_svi_prm		= new String[0]; // [O] 장기소득공제대상연금저축보험료
	public String[] btpy_ars_pym_crtf_isu_ltm__ltm_icdd_tgt_hse_prep_prm	= new String[0]; // [O] 장기소득공제대상주택마련보험료
	public String[] btpy_ars_pym_crtf_isu_ltm__eta_prm						= new String[0]; // [O] 기타보험료
	public String[] btpy_ars_pym_crtf_isu_ltm__accu_nprm					= new String[0]; // [O] 적립순보험료
	public String[] btpy_ars_pym_crtf_isu_ltm__ctc_stat_cd					= new String[0]; // [O] 계약상태코드
	public String[] btpy_ars_pym_crtf_isu_ltm__ctc_stat_nm					= new String[0]; // [O] 계약상태명
	public String[] btpy_ars_pym_crtf_isu_ltm__plhd_nm						= new String[0]; // [O] 계약자명
	public String[] btpy_ars_pym_crtf_isu_ltm__pdc_nm						= new String[0]; // [O] 상품명
	public String[] btpy_ars_pym_crtf_isu_ltm__arc_trm_str_dt				= new String[0]; // [O] 보험기간시작일자
	public String[] btpy_ars_pym_crtf_isu_ltm__arc_trm_fin_dt				= new String[0]; // [O] 보험기간종료일자
	
	public String errorCode		= ""; // 에러코드
	public String z_msg_cd		= ""; // 메시지 코드
	public String returnMessage	= ""; // 메시지 내용
	
	public String getCust_dcmt_no() {
		return cust_dcmt_no;
	}
	public void setCust_dcmt_no(String cust_dcmt_no) {
		this.cust_dcmt_no = cust_dcmt_no;
	}
	public String getBse_yy() {
		return bse_yy;
	}
	public void setBse_yy(String bse_yy) {
		this.bse_yy = bse_yy;
	}
	public String getCust_nm() {
		return cust_nm;
	}
	public void setCust_nm(String cust_nm) {
		this.cust_nm = cust_nm;
	}
	public String getRsdn_no() {
		return rsdn_no;
	}
	public void setRsdn_no(String rsdn_no) {
		this.rsdn_no = rsdn_no;
	}
	public String getPsno() {
		return psno;
	}
	public void setPsno(String psno) {
		this.psno = psno;
	}
	public String getPsno_nm() {
		return psno_nm;
	}
	public void setPsno_nm(String psno_nm) {
		this.psno_nm = psno_nm;
	}
	public String getEta_adr() {
		return eta_adr;
	}
	public void setEta_adr(String eta_adr) {
		this.eta_adr = eta_adr;
	}
	public String[] getBtpy_ars_pym_crtf_isu_at__plno() {
		return btpy_ars_pym_crtf_isu_at__plno;
	}
	public void setBtpy_ars_pym_crtf_isu_at__plno(String[] btpy_ars_pym_crtf_isu_at__plno) {
		this.btpy_ars_pym_crtf_isu_at__plno = btpy_ars_pym_crtf_isu_at__plno;
	}
	public String[] getBtpy_ars_pym_crtf_isu_at__ins_nm() {
		return btpy_ars_pym_crtf_isu_at__ins_nm;
	}
	public void setBtpy_ars_pym_crtf_isu_at__ins_nm(String[] btpy_ars_pym_crtf_isu_at__ins_nm) {
		this.btpy_ars_pym_crtf_isu_at__ins_nm = btpy_ars_pym_crtf_isu_at__ins_nm;
	}
	public String[] getBtpy_ars_pym_crtf_isu_at__ins_rlt() {
		return btpy_ars_pym_crtf_isu_at__ins_rlt;
	}
	public void setBtpy_ars_pym_crtf_isu_at__ins_rlt(String[] btpy_ars_pym_crtf_isu_at__ins_rlt) {
		this.btpy_ars_pym_crtf_isu_at__ins_rlt = btpy_ars_pym_crtf_isu_at__ins_rlt;
	}
	public String[] getBtpy_ars_pym_crtf_isu_at__inpd_cd() {
		return btpy_ars_pym_crtf_isu_at__inpd_cd;
	}
	public void setBtpy_ars_pym_crtf_isu_at__inpd_cd(String[] btpy_ars_pym_crtf_isu_at__inpd_cd) {
		this.btpy_ars_pym_crtf_isu_at__inpd_cd = btpy_ars_pym_crtf_isu_at__inpd_cd;
	}
	public String[] getBtpy_ars_pym_crtf_isu_at__inpd_nm() {
		return btpy_ars_pym_crtf_isu_at__inpd_nm;
	}
	public void setBtpy_ars_pym_crtf_isu_at__inpd_nm(String[] btpy_ars_pym_crtf_isu_at__inpd_nm) {
		this.btpy_ars_pym_crtf_isu_at__inpd_nm = btpy_ars_pym_crtf_isu_at__inpd_nm;
	}
	public String[] getBtpy_ars_pym_crtf_isu_at__pym_mtd_cd() {
		return btpy_ars_pym_crtf_isu_at__pym_mtd_cd;
	}
	public void setBtpy_ars_pym_crtf_isu_at__pym_mtd_cd(String[] btpy_ars_pym_crtf_isu_at__pym_mtd_cd) {
		this.btpy_ars_pym_crtf_isu_at__pym_mtd_cd = btpy_ars_pym_crtf_isu_at__pym_mtd_cd;
	}
	public String[] getBtpy_ars_pym_crtf_isu_at__pym_mtd_nm() {
		return btpy_ars_pym_crtf_isu_at__pym_mtd_nm;
	}
	public void setBtpy_ars_pym_crtf_isu_at__pym_mtd_nm(String[] btpy_ars_pym_crtf_isu_at__pym_mtd_nm) {
		this.btpy_ars_pym_crtf_isu_at__pym_mtd_nm = btpy_ars_pym_crtf_isu_at__pym_mtd_nm;
	}
	public String[] getBtpy_ars_pym_crtf_isu_at__fnal_pym_ym() {
		return btpy_ars_pym_crtf_isu_at__fnal_pym_ym;
	}
	public void setBtpy_ars_pym_crtf_isu_at__fnal_pym_ym(String[] btpy_ars_pym_crtf_isu_at__fnal_pym_ym) {
		this.btpy_ars_pym_crtf_isu_at__fnal_pym_ym = btpy_ars_pym_crtf_isu_at__fnal_pym_ym;
	}
	public String[] getBtpy_ars_pym_crtf_isu_at__pym_nts() {
		return btpy_ars_pym_crtf_isu_at__pym_nts;
	}
	public void setBtpy_ars_pym_crtf_isu_at__pym_nts(String[] btpy_ars_pym_crtf_isu_at__pym_nts) {
		this.btpy_ars_pym_crtf_isu_at__pym_nts = btpy_ars_pym_crtf_isu_at__pym_nts;
	}
	public String[] getBtpy_ars_pym_crtf_isu_at__vh_no() {
		return btpy_ars_pym_crtf_isu_at__vh_no;
	}
	public void setBtpy_ars_pym_crtf_isu_at__vh_no(String[] btpy_ars_pym_crtf_isu_at__vh_no) {
		this.btpy_ars_pym_crtf_isu_at__vh_no = btpy_ars_pym_crtf_isu_at__vh_no;
	}
	public String[] getBtpy_ars_pym_crtf_isu_at__icdd_tgt_asrt_prm() {
		return btpy_ars_pym_crtf_isu_at__icdd_tgt_asrt_prm;
	}
	public void setBtpy_ars_pym_crtf_isu_at__icdd_tgt_asrt_prm(String[] btpy_ars_pym_crtf_isu_at__icdd_tgt_asrt_prm) {
		this.btpy_ars_pym_crtf_isu_at__icdd_tgt_asrt_prm = btpy_ars_pym_crtf_isu_at__icdd_tgt_asrt_prm;
	}
	public String[] getBtpy_ars_pym_crtf_isu_at__icdd_tgt_dsab_asrt_prm() {
		return btpy_ars_pym_crtf_isu_at__icdd_tgt_dsab_asrt_prm;
	}
	public void setBtpy_ars_pym_crtf_isu_at__icdd_tgt_dsab_asrt_prm(
			String[] btpy_ars_pym_crtf_isu_at__icdd_tgt_dsab_asrt_prm) {
		this.btpy_ars_pym_crtf_isu_at__icdd_tgt_dsab_asrt_prm = btpy_ars_pym_crtf_isu_at__icdd_tgt_dsab_asrt_prm;
	}
	public String[] getBtpy_ars_pym_crtf_isu_at__ctc_stat_cd() {
		return btpy_ars_pym_crtf_isu_at__ctc_stat_cd;
	}
	public void setBtpy_ars_pym_crtf_isu_at__ctc_stat_cd(String[] btpy_ars_pym_crtf_isu_at__ctc_stat_cd) {
		this.btpy_ars_pym_crtf_isu_at__ctc_stat_cd = btpy_ars_pym_crtf_isu_at__ctc_stat_cd;
	}
	public String[] getBtpy_ars_pym_crtf_isu_at__ctc_stat_nm() {
		return btpy_ars_pym_crtf_isu_at__ctc_stat_nm;
	}
	public void setBtpy_ars_pym_crtf_isu_at__ctc_stat_nm(String[] btpy_ars_pym_crtf_isu_at__ctc_stat_nm) {
		this.btpy_ars_pym_crtf_isu_at__ctc_stat_nm = btpy_ars_pym_crtf_isu_at__ctc_stat_nm;
	}
	public String[] getBtpy_ars_pym_crtf_isu_at__arc_trm_str_dt() {
		return btpy_ars_pym_crtf_isu_at__arc_trm_str_dt;
	}
	public void setBtpy_ars_pym_crtf_isu_at__arc_trm_str_dt(String[] btpy_ars_pym_crtf_isu_at__arc_trm_str_dt) {
		this.btpy_ars_pym_crtf_isu_at__arc_trm_str_dt = btpy_ars_pym_crtf_isu_at__arc_trm_str_dt;
	}
	public String[] getBtpy_ars_pym_crtf_isu_at__arc_trm_fin_dt() {
		return btpy_ars_pym_crtf_isu_at__arc_trm_fin_dt;
	}
	public void setBtpy_ars_pym_crtf_isu_at__arc_trm_fin_dt(String[] btpy_ars_pym_crtf_isu_at__arc_trm_fin_dt) {
		this.btpy_ars_pym_crtf_isu_at__arc_trm_fin_dt = btpy_ars_pym_crtf_isu_at__arc_trm_fin_dt;
	}
	public String[] getBtpy_ars_pym_crtf_isu_ltm__plno() {
		return btpy_ars_pym_crtf_isu_ltm__plno;
	}
	public void setBtpy_ars_pym_crtf_isu_ltm__plno(String[] btpy_ars_pym_crtf_isu_ltm__plno) {
		this.btpy_ars_pym_crtf_isu_ltm__plno = btpy_ars_pym_crtf_isu_ltm__plno;
	}
	public String[] getBtpy_ars_pym_crtf_isu_ltm__ins_nm() {
		return btpy_ars_pym_crtf_isu_ltm__ins_nm;
	}
	public void setBtpy_ars_pym_crtf_isu_ltm__ins_nm(String[] btpy_ars_pym_crtf_isu_ltm__ins_nm) {
		this.btpy_ars_pym_crtf_isu_ltm__ins_nm = btpy_ars_pym_crtf_isu_ltm__ins_nm;
	}
	public String[] getBtpy_ars_pym_crtf_isu_ltm__inpd_cd() {
		return btpy_ars_pym_crtf_isu_ltm__inpd_cd;
	}
	public void setBtpy_ars_pym_crtf_isu_ltm__inpd_cd(String[] btpy_ars_pym_crtf_isu_ltm__inpd_cd) {
		this.btpy_ars_pym_crtf_isu_ltm__inpd_cd = btpy_ars_pym_crtf_isu_ltm__inpd_cd;
	}
	public String[] getBtpy_ars_pym_crtf_isu_ltm__inpd_nm() {
		return btpy_ars_pym_crtf_isu_ltm__inpd_nm;
	}
	public void setBtpy_ars_pym_crtf_isu_ltm__inpd_nm(String[] btpy_ars_pym_crtf_isu_ltm__inpd_nm) {
		this.btpy_ars_pym_crtf_isu_ltm__inpd_nm = btpy_ars_pym_crtf_isu_ltm__inpd_nm;
	}
	public String[] getBtpy_ars_pym_crtf_isu_ltm__pym_mtd_cd() {
		return btpy_ars_pym_crtf_isu_ltm__pym_mtd_cd;
	}
	public void setBtpy_ars_pym_crtf_isu_ltm__pym_mtd_cd(String[] btpy_ars_pym_crtf_isu_ltm__pym_mtd_cd) {
		this.btpy_ars_pym_crtf_isu_ltm__pym_mtd_cd = btpy_ars_pym_crtf_isu_ltm__pym_mtd_cd;
	}
	public String[] getBtpy_ars_pym_crtf_isu_ltm__pym_mtd_nm() {
		return btpy_ars_pym_crtf_isu_ltm__pym_mtd_nm;
	}
	public void setBtpy_ars_pym_crtf_isu_ltm__pym_mtd_nm(String[] btpy_ars_pym_crtf_isu_ltm__pym_mtd_nm) {
		this.btpy_ars_pym_crtf_isu_ltm__pym_mtd_nm = btpy_ars_pym_crtf_isu_ltm__pym_mtd_nm;
	}
	public String[] getBtpy_ars_pym_crtf_isu_ltm__fnal_pym_ym() {
		return btpy_ars_pym_crtf_isu_ltm__fnal_pym_ym;
	}
	public void setBtpy_ars_pym_crtf_isu_ltm__fnal_pym_ym(String[] btpy_ars_pym_crtf_isu_ltm__fnal_pym_ym) {
		this.btpy_ars_pym_crtf_isu_ltm__fnal_pym_ym = btpy_ars_pym_crtf_isu_ltm__fnal_pym_ym;
	}
	public String[] getBtpy_ars_pym_crtf_isu_ltm__pym_nts() {
		return btpy_ars_pym_crtf_isu_ltm__pym_nts;
	}
	public void setBtpy_ars_pym_crtf_isu_ltm__pym_nts(String[] btpy_ars_pym_crtf_isu_ltm__pym_nts) {
		this.btpy_ars_pym_crtf_isu_ltm__pym_nts = btpy_ars_pym_crtf_isu_ltm__pym_nts;
	}
	public String[] getBtpy_ars_pym_crtf_isu_ltm__sm_prm() {
		return btpy_ars_pym_crtf_isu_ltm__sm_prm;
	}
	public void setBtpy_ars_pym_crtf_isu_ltm__sm_prm(String[] btpy_ars_pym_crtf_isu_ltm__sm_prm) {
		this.btpy_ars_pym_crtf_isu_ltm__sm_prm = btpy_ars_pym_crtf_isu_ltm__sm_prm;
	}
	public String[] getBtpy_ars_pym_crtf_isu_ltm__vh_no() {
		return btpy_ars_pym_crtf_isu_ltm__vh_no;
	}
	public void setBtpy_ars_pym_crtf_isu_ltm__vh_no(String[] btpy_ars_pym_crtf_isu_ltm__vh_no) {
		this.btpy_ars_pym_crtf_isu_ltm__vh_no = btpy_ars_pym_crtf_isu_ltm__vh_no;
	}
	public String[] getBtpy_ars_pym_crtf_isu_ltm__ltm_icdd_tgt_asrt_prm() {
		return btpy_ars_pym_crtf_isu_ltm__ltm_icdd_tgt_asrt_prm;
	}
	public void setBtpy_ars_pym_crtf_isu_ltm__ltm_icdd_tgt_asrt_prm(
			String[] btpy_ars_pym_crtf_isu_ltm__ltm_icdd_tgt_asrt_prm) {
		this.btpy_ars_pym_crtf_isu_ltm__ltm_icdd_tgt_asrt_prm = btpy_ars_pym_crtf_isu_ltm__ltm_icdd_tgt_asrt_prm;
	}
	public String[] getBtpy_ars_pym_crtf_isu_ltm__ltm_icdd_tgt_prn_pnn_prm() {
		return btpy_ars_pym_crtf_isu_ltm__ltm_icdd_tgt_prn_pnn_prm;
	}
	public void setBtpy_ars_pym_crtf_isu_ltm__ltm_icdd_tgt_prn_pnn_prm(
			String[] btpy_ars_pym_crtf_isu_ltm__ltm_icdd_tgt_prn_pnn_prm) {
		this.btpy_ars_pym_crtf_isu_ltm__ltm_icdd_tgt_prn_pnn_prm = btpy_ars_pym_crtf_isu_ltm__ltm_icdd_tgt_prn_pnn_prm;
	}
	public String[] getBtpy_ars_pym_crtf_isu_ltm__ltm_icdd_tgt_pnn_svi_prm() {
		return btpy_ars_pym_crtf_isu_ltm__ltm_icdd_tgt_pnn_svi_prm;
	}
	public void setBtpy_ars_pym_crtf_isu_ltm__ltm_icdd_tgt_pnn_svi_prm(
			String[] btpy_ars_pym_crtf_isu_ltm__ltm_icdd_tgt_pnn_svi_prm) {
		this.btpy_ars_pym_crtf_isu_ltm__ltm_icdd_tgt_pnn_svi_prm = btpy_ars_pym_crtf_isu_ltm__ltm_icdd_tgt_pnn_svi_prm;
	}
	public String[] getBtpy_ars_pym_crtf_isu_ltm__ltm_icdd_tgt_hse_prep_prm() {
		return btpy_ars_pym_crtf_isu_ltm__ltm_icdd_tgt_hse_prep_prm;
	}
	public void setBtpy_ars_pym_crtf_isu_ltm__ltm_icdd_tgt_hse_prep_prm(
			String[] btpy_ars_pym_crtf_isu_ltm__ltm_icdd_tgt_hse_prep_prm) {
		this.btpy_ars_pym_crtf_isu_ltm__ltm_icdd_tgt_hse_prep_prm = btpy_ars_pym_crtf_isu_ltm__ltm_icdd_tgt_hse_prep_prm;
	}
	public String[] getBtpy_ars_pym_crtf_isu_ltm__eta_prm() {
		return btpy_ars_pym_crtf_isu_ltm__eta_prm;
	}
	public void setBtpy_ars_pym_crtf_isu_ltm__eta_prm(String[] btpy_ars_pym_crtf_isu_ltm__eta_prm) {
		this.btpy_ars_pym_crtf_isu_ltm__eta_prm = btpy_ars_pym_crtf_isu_ltm__eta_prm;
	}
	public String[] getBtpy_ars_pym_crtf_isu_ltm__accu_nprm() {
		return btpy_ars_pym_crtf_isu_ltm__accu_nprm;
	}
	public void setBtpy_ars_pym_crtf_isu_ltm__accu_nprm(String[] btpy_ars_pym_crtf_isu_ltm__accu_nprm) {
		this.btpy_ars_pym_crtf_isu_ltm__accu_nprm = btpy_ars_pym_crtf_isu_ltm__accu_nprm;
	}
	public String[] getBtpy_ars_pym_crtf_isu_ltm__ctc_stat_cd() {
		return btpy_ars_pym_crtf_isu_ltm__ctc_stat_cd;
	}
	public void setBtpy_ars_pym_crtf_isu_ltm__ctc_stat_cd(String[] btpy_ars_pym_crtf_isu_ltm__ctc_stat_cd) {
		this.btpy_ars_pym_crtf_isu_ltm__ctc_stat_cd = btpy_ars_pym_crtf_isu_ltm__ctc_stat_cd;
	}
	public String[] getBtpy_ars_pym_crtf_isu_ltm__ctc_stat_nm() {
		return btpy_ars_pym_crtf_isu_ltm__ctc_stat_nm;
	}
	public void setBtpy_ars_pym_crtf_isu_ltm__ctc_stat_nm(String[] btpy_ars_pym_crtf_isu_ltm__ctc_stat_nm) {
		this.btpy_ars_pym_crtf_isu_ltm__ctc_stat_nm = btpy_ars_pym_crtf_isu_ltm__ctc_stat_nm;
	}
	public String[] getBtpy_ars_pym_crtf_isu_ltm__plhd_nm() {
		return btpy_ars_pym_crtf_isu_ltm__plhd_nm;
	}
	public void setBtpy_ars_pym_crtf_isu_ltm__plhd_nm(String[] btpy_ars_pym_crtf_isu_ltm__plhd_nm) {
		this.btpy_ars_pym_crtf_isu_ltm__plhd_nm = btpy_ars_pym_crtf_isu_ltm__plhd_nm;
	}
	public String[] getBtpy_ars_pym_crtf_isu_ltm__pdc_nm() {
		return btpy_ars_pym_crtf_isu_ltm__pdc_nm;
	}
	public void setBtpy_ars_pym_crtf_isu_ltm__pdc_nm(String[] btpy_ars_pym_crtf_isu_ltm__pdc_nm) {
		this.btpy_ars_pym_crtf_isu_ltm__pdc_nm = btpy_ars_pym_crtf_isu_ltm__pdc_nm;
	}
	public String[] getBtpy_ars_pym_crtf_isu_ltm__arc_trm_str_dt() {
		return btpy_ars_pym_crtf_isu_ltm__arc_trm_str_dt;
	}
	public void setBtpy_ars_pym_crtf_isu_ltm__arc_trm_str_dt(String[] btpy_ars_pym_crtf_isu_ltm__arc_trm_str_dt) {
		this.btpy_ars_pym_crtf_isu_ltm__arc_trm_str_dt = btpy_ars_pym_crtf_isu_ltm__arc_trm_str_dt;
	}
	public String[] getBtpy_ars_pym_crtf_isu_ltm__arc_trm_fin_dt() {
		return btpy_ars_pym_crtf_isu_ltm__arc_trm_fin_dt;
	}
	public void setBtpy_ars_pym_crtf_isu_ltm__arc_trm_fin_dt(String[] btpy_ars_pym_crtf_isu_ltm__arc_trm_fin_dt) {
		this.btpy_ars_pym_crtf_isu_ltm__arc_trm_fin_dt = btpy_ars_pym_crtf_isu_ltm__arc_trm_fin_dt;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getZ_msg_cd() {
		return z_msg_cd;
	}
	public void setZ_msg_cd(String z_msg_cd) {
		this.z_msg_cd = z_msg_cd;
	}
	public String getReturnMessage() {
		return returnMessage;
	}
	public void setReturnMessage(String returnMessage) {
		this.returnMessage = returnMessage;
	}
	
}
