package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class CCLM0062VO extends CMMVO{
	//전문필드
		public String msg_cd = "";  //[O] 메세지코드 LK-MSG-CD2 메세지코드2
		public String msg = "";  //[O] 메시지 H-LK-MESSAGE2 메시지2
		public String pat_dvn_1 = "";  //[I/O] 파트구분1 LK-PART-GB1 파트구분1
		public String pat_dvn_2 = "";  //[I/O] 파트구분2 LK-PART-GB2 파트구분2
		public String bz_dvn_1 = "";  //[I/O] 업무구분1 LK-UPMU-CD1 업무구분1
		public String bz_dvn_2 = "";  //[I/O] 업무구분2 LK-UPMU-CD2 업무구분2
		public String bz_dvn_3 = "";  //[I/O] 업무구분3 LK-UPMU-CD3 업무구분3
		public String accd_rpt_no = "";  //[I/O] 사고접수번호          LK-I-SAGO-NO 사고접수번호         
		public String accd_oj_dvn = "";  //[I/O] 사고목적구분      LK-I-SAGO-GB 사고목적구분     
		public String accd_oj_sqno = "";  //[I/O] 사고목적일련번호  LK-I-SAGO-SEQ 사고목적일련번호 
		public String accd_no = "";  //[O] 사고번호 LK-SAGO-NO 사고번호
		public String vh_no = "";  //[O] 차량번호 LK-CAR-NO 차량번호
		public String vh_nm = "";  //[O] 차량명 LK-CAR-NAME 차량명
		public String cmpn_amt = "";  //[O] 부품금액 LK-BUPUM-GMEK 부품금액
		public String clab = "";  //[O] 공임 LK-GONGIM-GMEK 공임
		public String tty_nm_1 = "";  //[O] 특약명1 LK-TKYAK-NAME1 특약명１
		public String tty_amt_1 = "";  //[O] 특약금액1 LK-TKYAK-PL-CMT1 특약금액１
		public String tty_nm_2 = "";  //[O] 특약명2 LK-TKYAK-NAME2 특약명２
		public String tty_amt_2 = "";  //[O] 특약금액2 LK-TKYAK-PL-CMT2 특약금액２
		public String tty_nm_3 = "";  //[O] 특약명3 LK-TKYAK-NAME3 특약명３
		public String tty_amt_3 = "";  //[O] 특약금액3 LK-TKYAK-PL-CMT3 특약금액３
		public String tty_nm_4 = "";  //[O] 특약명4 LK-TKYAK-NAME4 특약명４
		public String tty_amt_4 = "";  //[O] 특약금액4 LK-TKYAK-PL-CMT4 특약금액４
		public String tty_nm_5 = "";  //[O] 특약명5 LK-TKYAK-NAME5 특약명５
		public String tty_amt_5 = "";  //[O] 특약금액5 LK-TKYAK-PL-CMT5 특약금액５
		public String tty_nm_6 = "";  //[O] 특약명6 LK-TKYAK-NAME6 특약명６
		public String tty_amt_6 = "";  //[O] 특약금액6 LK-TKYAK-PL-CMT6 특약금액６
		public String tty_eta_cnum = "";  //[O] 특약기타건수 LK-TKYAK-CNT 특약６건외건수
		public String tty_amtt = "";  //[O] 특약금액합계 LK-TKYAK-TOT-PL-CMT 특약금액합계
		public String tot_pyn_bnf = "";  //[O] 총지급보험금  LK-PL-CMT 총지급보험금 
		public String damg_prtn_1 = "";  //[O] 파손부위1 LK-PASON-BUWIE-NAME1 파손부위１
		public String damg_prtn_2 = "";  //[O] 파손부위2 LK-PASON-BUWIE-NAME2 파손부위２
		public String damg_prtn_3 = "";  //[O] 파손부위3 LK-PASON-BUWIE-NAME3 파손부위３
		public String damg_prtn_4 = "";  //[O] 파손부위4 LK-PASON-BUWIE-NAME4 파손부위４
		public String damg_prtn_5 = "";  //[O] 파손부위5 LK-PASON-BUWIE-NAME5 파손부위５
		public String damg_prtn_6 = "";  //[O] 파손부위6 LK-PASON-BUWIE-NAME6 파손부위６
		public String damg_prtn_7 = "";  //[O] 파손부위7 LK-PASON-BUWIE-NAME7 파손부위７
		public String damg_prtn_8 = "";  //[O] 파손부위8 LK-PASON-BUWIE-NAME8 파손부위８
		public String damg_prtn_9 = "";  //[O] 파손부위9 LK-PASON-BUWIE-NAME9 파손부위９
		public String damg_prtn_10 = "";  //[O] 파손부위10 LK-PASON-BUWIE-NAME10 파손부위１０
		public String damg_prtn_11 = "";  //[O] 파손부위11 LK-PASON-BUWIE-NAME11 파손부위１１
		public String damg_prtn_12 = "";  //[O] 파손부위12 LK-PASON-BUWIE-NAME12 파손부위１２
		public String damg_prtn_13 = "";  //[O] 파손부위13  
		public String damg_prtn_14 = "";  //[O] 파손부위14  
		public String damg_prtn_15 = "";  //[O] 파손부위15  
		public String damg_prtn_16 = "";  //[O] 파손부위16  
		public String repa_ntp = "";  //[O] 수리업체 LK-SURICHEO-NAME 수리업체
		public String psic = "";  //[O] 담당자  LK-DAMDANGJA-NAME 담당자 
		public String psic_tlno = "";  //[O] 담당자전화번호  LK-DAMDANGJA-TEL 담당자전화번호 
		public String rut_1 = "";  //[O] 경로1 LK-IMAGE-PATH1 경로１
		public String rut_2 = "";  //[O] 경로2 LK-IMAGE-PATH2 경로２
		public String getMsg_cd() {
			return msg_cd;
		}
		public void setMsg_cd(String msg_cd) {
			this.msg_cd = msg_cd;
		}
		public String getMsg() {
			return msg;
		}
		public void setMsg(String msg) {
			this.msg = msg;
		}
		public String getPat_dvn_1() {
			return pat_dvn_1;
		}
		public void setPat_dvn_1(String pat_dvn_1) {
			this.pat_dvn_1 = pat_dvn_1;
		}
		public String getPat_dvn_2() {
			return pat_dvn_2;
		}
		public void setPat_dvn_2(String pat_dvn_2) {
			this.pat_dvn_2 = pat_dvn_2;
		}
		public String getBz_dvn_1() {
			return bz_dvn_1;
		}
		public void setBz_dvn_1(String bz_dvn_1) {
			this.bz_dvn_1 = bz_dvn_1;
		}
		public String getBz_dvn_2() {
			return bz_dvn_2;
		}
		public void setBz_dvn_2(String bz_dvn_2) {
			this.bz_dvn_2 = bz_dvn_2;
		}
		public String getBz_dvn_3() {
			return bz_dvn_3;
		}
		public void setBz_dvn_3(String bz_dvn_3) {
			this.bz_dvn_3 = bz_dvn_3;
		}
		public String getAccd_rpt_no() {
			return accd_rpt_no;
		}
		public void setAccd_rpt_no(String accd_rpt_no) {
			this.accd_rpt_no = accd_rpt_no;
		}
		public String getAccd_oj_dvn() {
			return accd_oj_dvn;
		}
		public void setAccd_oj_dvn(String accd_oj_dvn) {
			this.accd_oj_dvn = accd_oj_dvn;
		}
		public String getAccd_oj_sqno() {
			return accd_oj_sqno;
		}
		public void setAccd_oj_sqno(String accd_oj_sqno) {
			this.accd_oj_sqno = accd_oj_sqno;
		}
		public String getAccd_no() {
			return accd_no;
		}
		public void setAccd_no(String accd_no) {
			this.accd_no = accd_no;
		}
		public String getVh_no() {
			return vh_no;
		}
		public void setVh_no(String vh_no) {
			this.vh_no = vh_no;
		}
		public String getVh_nm() {
			return vh_nm;
		}
		public void setVh_nm(String vh_nm) {
			this.vh_nm = vh_nm;
		}
		public String getCmpn_amt() {
			return cmpn_amt;
		}
		public void setCmpn_amt(String cmpn_amt) {
			this.cmpn_amt = cmpn_amt;
		}
		public String getClab() {
			return clab;
		}
		public void setClab(String clab) {
			this.clab = clab;
		}
		public String getTty_nm_1() {
			return tty_nm_1;
		}
		public void setTty_nm_1(String tty_nm_1) {
			this.tty_nm_1 = tty_nm_1;
		}
		public String getTty_amt_1() {
			return tty_amt_1;
		}
		public void setTty_amt_1(String tty_amt_1) {
			this.tty_amt_1 = tty_amt_1;
		}
		public String getTty_nm_2() {
			return tty_nm_2;
		}
		public void setTty_nm_2(String tty_nm_2) {
			this.tty_nm_2 = tty_nm_2;
		}
		public String getTty_amt_2() {
			return tty_amt_2;
		}
		public void setTty_amt_2(String tty_amt_2) {
			this.tty_amt_2 = tty_amt_2;
		}
		public String getTty_nm_3() {
			return tty_nm_3;
		}
		public void setTty_nm_3(String tty_nm_3) {
			this.tty_nm_3 = tty_nm_3;
		}
		public String getTty_amt_3() {
			return tty_amt_3;
		}
		public void setTty_amt_3(String tty_amt_3) {
			this.tty_amt_3 = tty_amt_3;
		}
		public String getTty_nm_4() {
			return tty_nm_4;
		}
		public void setTty_nm_4(String tty_nm_4) {
			this.tty_nm_4 = tty_nm_4;
		}
		public String getTty_amt_4() {
			return tty_amt_4;
		}
		public void setTty_amt_4(String tty_amt_4) {
			this.tty_amt_4 = tty_amt_4;
		}
		public String getTty_nm_5() {
			return tty_nm_5;
		}
		public void setTty_nm_5(String tty_nm_5) {
			this.tty_nm_5 = tty_nm_5;
		}
		public String getTty_amt_5() {
			return tty_amt_5;
		}
		public void setTty_amt_5(String tty_amt_5) {
			this.tty_amt_5 = tty_amt_5;
		}
		public String getTty_nm_6() {
			return tty_nm_6;
		}
		public void setTty_nm_6(String tty_nm_6) {
			this.tty_nm_6 = tty_nm_6;
		}
		public String getTty_amt_6() {
			return tty_amt_6;
		}
		public void setTty_amt_6(String tty_amt_6) {
			this.tty_amt_6 = tty_amt_6;
		}
		public String getTty_eta_cnum() {
			return tty_eta_cnum;
		}
		public void setTty_eta_cnum(String tty_eta_cnum) {
			this.tty_eta_cnum = tty_eta_cnum;
		}
		public String getTty_amtt() {
			return tty_amtt;
		}
		public void setTty_amtt(String tty_amtt) {
			this.tty_amtt = tty_amtt;
		}
		public String getTot_pyn_bnf() {
			return tot_pyn_bnf;
		}
		public void setTot_pyn_bnf(String tot_pyn_bnf) {
			this.tot_pyn_bnf = tot_pyn_bnf;
		}
		public String getDamg_prtn_1() {
			return damg_prtn_1;
		}
		public void setDamg_prtn_1(String damg_prtn_1) {
			this.damg_prtn_1 = damg_prtn_1;
		}
		public String getDamg_prtn_2() {
			return damg_prtn_2;
		}
		public void setDamg_prtn_2(String damg_prtn_2) {
			this.damg_prtn_2 = damg_prtn_2;
		}
		public String getDamg_prtn_3() {
			return damg_prtn_3;
		}
		public void setDamg_prtn_3(String damg_prtn_3) {
			this.damg_prtn_3 = damg_prtn_3;
		}
		public String getDamg_prtn_4() {
			return damg_prtn_4;
		}
		public void setDamg_prtn_4(String damg_prtn_4) {
			this.damg_prtn_4 = damg_prtn_4;
		}
		public String getDamg_prtn_5() {
			return damg_prtn_5;
		}
		public void setDamg_prtn_5(String damg_prtn_5) {
			this.damg_prtn_5 = damg_prtn_5;
		}
		public String getDamg_prtn_6() {
			return damg_prtn_6;
		}
		public void setDamg_prtn_6(String damg_prtn_6) {
			this.damg_prtn_6 = damg_prtn_6;
		}
		public String getDamg_prtn_7() {
			return damg_prtn_7;
		}
		public void setDamg_prtn_7(String damg_prtn_7) {
			this.damg_prtn_7 = damg_prtn_7;
		}
		public String getDamg_prtn_8() {
			return damg_prtn_8;
		}
		public void setDamg_prtn_8(String damg_prtn_8) {
			this.damg_prtn_8 = damg_prtn_8;
		}
		public String getDamg_prtn_9() {
			return damg_prtn_9;
		}
		public void setDamg_prtn_9(String damg_prtn_9) {
			this.damg_prtn_9 = damg_prtn_9;
		}
		public String getDamg_prtn_10() {
			return damg_prtn_10;
		}
		public void setDamg_prtn_10(String damg_prtn_10) {
			this.damg_prtn_10 = damg_prtn_10;
		}
		public String getDamg_prtn_11() {
			return damg_prtn_11;
		}
		public void setDamg_prtn_11(String damg_prtn_11) {
			this.damg_prtn_11 = damg_prtn_11;
		}
		public String getDamg_prtn_12() {
			return damg_prtn_12;
		}
		public void setDamg_prtn_12(String damg_prtn_12) {
			this.damg_prtn_12 = damg_prtn_12;
		}
		public String getDamg_prtn_13() {
			return damg_prtn_13;
		}
		public void setDamg_prtn_13(String damg_prtn_13) {
			this.damg_prtn_13 = damg_prtn_13;
		}
		public String getDamg_prtn_14() {
			return damg_prtn_14;
		}
		public void setDamg_prtn_14(String damg_prtn_14) {
			this.damg_prtn_14 = damg_prtn_14;
		}
		public String getDamg_prtn_15() {
			return damg_prtn_15;
		}
		public void setDamg_prtn_15(String damg_prtn_15) {
			this.damg_prtn_15 = damg_prtn_15;
		}
		public String getDamg_prtn_16() {
			return damg_prtn_16;
		}
		public void setDamg_prtn_16(String damg_prtn_16) {
			this.damg_prtn_16 = damg_prtn_16;
		}
		public String getRepa_ntp() {
			return repa_ntp;
		}
		public void setRepa_ntp(String repa_ntp) {
			this.repa_ntp = repa_ntp;
		}
		public String getPsic() {
			return psic;
		}
		public void setPsic(String psic) {
			this.psic = psic;
		}
		public String getPsic_tlno() {
			return psic_tlno;
		}
		public void setPsic_tlno(String psic_tlno) {
			this.psic_tlno = psic_tlno;
		}
		public String getRut_1() {
			return rut_1;
		}
		public void setRut_1(String rut_1) {
			this.rut_1 = rut_1;
		}
		public String getRut_2() {
			return rut_2;
		}
		public void setRut_2(String rut_2) {
			this.rut_2 = rut_2;
		}
		
		
}
