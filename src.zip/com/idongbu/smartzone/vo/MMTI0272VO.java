package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class MMTI0272VO extends CMMVO{
	//전문필드
	public String cust_dcmt_no = null;     //[I/O] 고객식별번호
	public String vh_no = null;            //[I/O] 차량번호    
	public String bz_dvn = null;           //[I/O] 업무구분    
	public String proc_dvn = null;         //[I/O] 처리구분    
	public String auth_yn = null;          //[I/O] 권한여부    
	public String ormm_cd = null;          //[I/O] 조직원코드  
	public String proc_auth_yn = null;     //[O] 처리권한여부
	public String[] scr_sulgye_occ__plno_test = new String[0];						//[O] 설계번호
		
	public String getCust_dcmt_no() {
		return cust_dcmt_no;
	}
	public void setCust_dcmt_no(String cust_dcmt_no) {
		this.cust_dcmt_no = cust_dcmt_no;
	}
	public String getVh_no() {
		return vh_no;
	}
	public void setVh_no(String vh_no) {
		this.vh_no = vh_no;
	}
	public String getBz_dvn() {
		return bz_dvn;
	}
	public void setBz_dvn(String bz_dvn) {
		this.bz_dvn = bz_dvn;
	}
	public String getProc_dvn() {
		return proc_dvn;
	}
	public void setProc_dvn(String proc_dvn) {
		this.proc_dvn = proc_dvn;
	}
	public String getAuth_yn() {
		return auth_yn;
	}
	public void setAuth_yn(String auth_yn) {
		this.auth_yn = auth_yn;
	}
	public String getOrmm_cd() {
		return ormm_cd;
	}
	public void setOrmm_cd(String ormm_cd) {
		this.ormm_cd = ormm_cd;
	}
	public String getProc_auth_yn() {
		return proc_auth_yn;
	}
	public void setProc_auth_yn(String proc_auth_yn) {
		this.proc_auth_yn = proc_auth_yn;
	}
	public String[] getScr_sulgye_occ__plno_test() {
		return scr_sulgye_occ__plno_test;
	}
	public void setScr_sulgye_occ__plno_test(
			String[] scr_sulgye_occ__plno_test) {
		this.scr_sulgye_occ__plno_test = scr_sulgye_occ__plno_test;
	}
}
