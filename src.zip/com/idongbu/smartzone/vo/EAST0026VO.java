package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class EAST0026VO extends CMMVO{
	//전문필드
	
		/* ★화면개발시 확인필요
		(EAST0026(FUC3335R-실시간이체 상환처리) 기능구분 키 정의) - 2012.09.18 : 서주희 대리
		
		채널			기능구분		CC-CHANNEL	CC_PROC_GB		CC_FUN_KEY		기타 
		콜센터			조회			2					1 　 　 
						처리			2					1					11 　 
		I-DONGBU	조회			3					0 　 　 
						처리			3					1					11					처리이후 이체 확인 전문 송신 
																									* 실시간이체 확인 전문 -FUA6016R(EAST0015) 
																									* EAST0015 관리자용은 실시간 이체 내역만 조회 
		*실시간이체 취소 미존재       
		*/
		 
		public String outp_atl = "";  //[O] 출력항목 CC_TS_ITEM 
		public String fom_id = "";  //[O] 폼ID CC_FORM_ID 
		public String dvn = "";  //[I] 구분 CC_PRT_GB 
		public String csn_yn = "";  //[I] 동의여부 CC_AGREEMENT 
		public String outp_yn = "";  //[] 출력여부 CC_PRINT_GB 
		public String prnt_type = "";  //[] 프린터타입 CC_PRINT_TYPE 
		public String plno = "";  //[I] 증권번호 JJ_POLI_NO 증권번호
		// 차세대 2차 전환 시작 필드 추가 (김도연 2014.02.14)
		public String ins_lcpl_dvcd = "";  //[I] 피보험자소재지구분코드  
		public String ply_sqno = "";  //[I] 증권일련번호  
		// 차세대 2차 전환 종료 필드 추가 (김도연 2014.02.14) 
		public String bh_cd = "";  //[I] 지점코드 JJ_JIJUM_CD 지점코드
		public String bh_nm = "";  //[O] 지점명 HJ_JIJUM_NAME 지점명
		public String empno = "";  //[I] 사원번호 JJ_SAWON_NO 사원번호
		public String ep_nm = "";  //[O] 사원명 HJ_SAWON_NAME 사원명
		public String inpd_cd = "";  //[O] 보종코드 JJ_BJ_CD 보종코드
		public String inpd_nm = "";  //[O] 보종명 HJ_BJ_NAME 보종명
		public String inpd_type = "";  //[O] 보종타입 JJ_BJ_TYPE 보종타입
		public String stat_nm = "";  //[O] 상태명 HJ_SANGTE_NAME 상태명
		public String stat_bh = "";  //[O] 상태지점 JJ_SANGTE_JIJUM 상태지점
		public String stat_dt = "";  //[O] 상태일자 JJ_SANGTE_YMD 상태일자
		public String plhd_nm = "";  //[O] 계약자명 HJ_GYEYAKJA_NAME 계약자명
		public String shr_dvn = "";  //[O] 지분구분 JJ_GEBUPIN_GUBUN 
		public String plhd_id = "";  //[O] 계약자ID JJ_GYEYAKJA_ID 계약자ID
		public String arc_bgn_dd = "";  //[O] 보험개시일 JJ_BOHUM_SYMD 보험개시일
		public String arc_fin_dd = "";  //[O] 보험종료일 JJ_BOHUM_EYMD 보험종료일
		public String pym_ycnt = "";  //[O] 납입년수 JJ_NAPIP_YCNT 납입년수
		public String dfmt_ycnt = "";  //[O] 거치년수 JJ_GUCHI_YCNT 거치년수
		public String exp_ycnt = "";  //[O] 만기년수 JJ_MANGI_YCNT 만기년수
		public String coll_mtd = "";  //[O] 수금방법 JJ_SUGUM_BANGBUP 수금방법
		public String fnal_pym_ym = "";  //[O] 최종납입년월 JJ_LAST_NAPIP_YM 최종납입년월
		public String pym_mtd_hngl_nm = "";  //[O] 납입방법한글명 HJ_NAPBANG_NAME 납방명
		public String pym_prm = "";  //[O] 납입보험료 JJ_NAPIPHAL_PRM 납입할보험료
		public String tot_pym_orr = "";  //[O] 총납입회차 JJ_TOTAL_NAPIP_CNT 총납입회차
		public String fnal_pym_orr = "";  //[O] 최종납입회차 JJ_LAST_NAPIP_CNT 최종납입회차
		public String tot_pym_prm = "";  //[O] 총납입보험료 JJ_TOTAL_NAPIP_PRM 총납입보험료
		public String ln_bh_cd = "";  //[O] 대출지점코드 JJ_DECHUL_JIJUM_CD 대출지점코드
		public String ln_bh_nm = "";  //[O] 대출지점명 HJ_DECHUL_JIJUM_NM 대출지점명
		public String ln_shp = "";  //[O] 대출형태 HJ_DECHUL_TYPE 대출형태
		public String ln_coll_mtd = "";  //[O] 대출수금방법 HJ_DECHUL_SUBANG 대출수금방법
		public String coll_bh_cd = "";  //[O] 수금지점코드 JJ_SUGUM_JIJUM_CD 수급지점코드
		public String coll_brn_cd = "";  //[O] 수금지부코드 JJ_SUGUM_JIBU_CD 수금지부코드
		public String coll_ep = "";  //[O] 수금사원 JJ_SUGUM_SAWON_NO 수금사원
		public String coll_bh_nm = "";  //[O] 수금지점명 HJ_SUGUM_JIJUM_NAME 수급지점명
		public String coll_brn_nm = "";  //[O] 수금지부명 HJ_SUGUM_JIBU_NAME 수금지부명
		public String coll_ep_nm = "";  //[O] 수금사원명 HJ_SUGUM_SAWON_NAME 수금사원명
		public String coll_agnc_main = "";  //[O] 수금대리점주 HJ_SUGUM_DERIJUMJU 수금대리점주
		public String coll_tlno = "";  //[O] 수금전화번호 JJ_SUGUM_TEL_NO 수금전화번호
		public String nn_ed_proc_detl = "";  //[O] 미종결처리내역 HJ_PROC_NAME 미종결처리내역
		public String rqst_no = "";  //[O] 요청번호 JJ_YOC_NO 요청번호
		public String rckd = "";  //[O] 기산일 JJ_GISAN_YMD 기산일
		public String rckn_amt = "";  //[O] 기산금액 JJ_GISAN_GM 기산금액
		public String rpm_prpl = "";  //[O] 상환원금 JJ_SANGHWAN_WONGM 상환원금
		public String npt_dt = "";  //[O] 미납일자 JJ_MINAP_YMD 미납일자
		public String npt_inte = "";  //[O] 미납이자 JJ_MINAP_IJA 미납이자
		public String rpm_inte = "";  //[O] 상환이자 JJ_SANGHWAN_IJA 상환이자
		public String pcpit_dt = "";  //[O] 원리금일자 JJ_WONLIGM_YMD 원리금일자
		public String pcpit = "";  //[O] 원리금 JJ_WONLIGM 원리금
		public String rpm_pcpit = "";  //[I] 상환원리금 JJ_SANGHWAN_WONLIGM 상환원리금
		public String bank_cd = "";  //[I] 은행코드 JJ_BANK_CD 은행코드
		public String bank_nm = "";  //[O] 은행명 HJ_BANK_NAME 은행명
		public String acc_no = "";  //[I] 계좌번호 JJ_GYEJWA_NO 계좌번호
		public String clpno = "";  //[I] 휴대폰번호 JJ_HAND_PHONE 핸드폰번호
		public String dpsr_nm = "";  //[I] 예금주명 HJ_YEGMJU_NAME 예금주명
		public String dpsr_id = "";  //[I] 예금주ID JJ_YEGMJU_ID 예금주ID
		public String dpsr_chek = "";  //[I] 예금주체크 JJ_YEGMJU_CHECK 예금주체크
		public String rmk = "";  //[O] 비고 HJ_REMARK 비고
		public String err_dvcd = "";  //[O] 에러구분코드 JJ_SYS_RC 
		public String inte_pd_1 = "";  //[O] 이자시기1 JJ_JUNG_F1 정1이자시기
		public String inte_et_1 = "";  //[O] 이자종기1 JJ_JUNG_T1 정1이자종기
		public String inte_dcnt_1 = "";  //[O] 이자일수1 JJ_JUNG_ILSU1 정1이자일수
		public String inte_amt_1 = "";  //[O] 이자금액1 JJ_JUNG_IJA1 정1이자금액
		public String inte_pd_2 = "";  //[O] 이자시기2 JJ_JUNG_F2 정2이자시기
		public String inte_et_2 = "";  //[O] 이자종기2 JJ_JUNG_T2 정2이자종기
		public String inte_dcnt_2 = "";  //[O] 이자일수2 JJ_JUNG_ILSU2 정2이자일수
		public String inte_amt_2 = "";  //[O] 이자금액2 JJ_JUNG_IJA2 정2이자금액
		public String inte_ovdu_1_pd = "";  //[O] 이자연체1시기 JJ_YUNC_F1 이자연체시기1
		public String inte_ovdu_fscl_ps = "";  //[O] 이자연체1종기 JJ_YUNC_T1 이자연체종기1
		public String inte_ovdu_day1_cnt = "";  //[O] 이자연체1일수 JJ_YUNC_ILSU1 이자연체일수1
		public String inte_ovdu_1_amt = "";  //[O] 이자연체1금액 JJ_YUNC_IJA1 이자연체금액1
		public String inte_ovdu_2_pd = "";  //[O] 이자연체2시기 JJ_YUNC_F2 이자연체시기2
		public String inte_ovdu_sccl_ps = "";  //[O] 이자연체2종기 JJ_YUNC_T2 이자연체종기2
		public String inte_ovdu_dy2_cnt = "";  //[O] 이자연체2일수 JJ_YUNC_ILSU2 이자연체일수2
		public String inte_ovdu_2_amt = "";  //[O] 이자연체2금액 JJ_YUNC_IJA2 이자연체금액2
		public String urnd_inte_pd = "";  //[O] 미경과이자시기 JJ_MIGU_F 미경과이자시기
		public String urnd_inte_et = "";  //[O] 미경과이자종기 JJ_MIGU_T 미경과이자종기
		public String urnd_inte_dcnt = "";  //[O] 미경과이자일수 JJ_MIGU_ILSU 미경과이자일수
		public String urnd_inte_amt = "";  //[O] 미경과이자금액 JJ_MIGU_IJA 미경과이자금액
		public String mprt_dvn = "";  //[O] 과오구분 HJ_GWAO_NM 과오구분
		public String mprt_amt = "";  //[O] 과오금액 JJ_GWAO_GM 과오금액
		public String prnt_fom = "";  //[O] 프린터폼 JJ_PRINT_FORM 프린트폼
		public String prnt_dta = "";  //[O] 프린터데이터 JJ_PRINT_DATA 프린트데이타
		public String imag_yn = "";  //[O] 이미지여부 JJ_IMAGE_YN 이미지여부
		public String imag_sno = "";  //[O] 이미지순번 JJ_IMAGE_SEQ 이미지순번
		public String imag_yn_1 = "";  //[O] 이미지여부1 JJ_JU_IMAGE_YN 
		public String imag_sno_1 = "";  //[O] 이미지순번1 JJ_JU_IMAGE_SEQ 
		public String plno1 = "";  //[O] 증권번호1 UU_POLI_NO 증권번호
		public String ins_lcpl_dvcd_1 = "";  //[O] 피보험자소재지구분코드1  
		public String ply_sqno_1 = "";  //[O] 증권일련번호1  
		public String ply_outp_yn = "";  //[O] 증권출력여부 RD_POLICY_YN 
		public String oupt_cpy_yn = "";  //[O] 출력물복사여부 RD_COPY_YN 
		public String oupt_grn_yn = "";  //[O] 출력물녹색여부 RD_GREEN_YN 
		public String oupt_ecde_yn = "";  //[O] 출력물암호화여부 RD_ENCRYPT_YN 
		public String oupt_ecde_key = "";  //[O] 출력물암호화키 RD_ENCRYPT_KEY 
		public String oupt_bz_dvn = "";  //[O] 출력물업무구분 RD_UPMU_GB 
		public String oupt_mea_dvn = "";  //[O] 출력물도구구분 RD_DOCU_GB 
		public String oupt_sign_key = "";  //[O] 출력물부호키 RD_SIGN_KEY 
		public String fom_dvn = "";  //[O] 폼구분 RD_FORM_GB 
		public String errorCode = "";  //[O] 에러코드
		public String returnMessage = "";
		public String z_resp_msg = "";
		
		public String wthd_csn_evd_dat_dvcd = ""; // [I] 출금동의증빙자료구분코드
		public String wthd_csn_evd_dat_inpt_dvcd = ""; // [I] 출금동의증빙자료입력구분코드
		public String wthd_csn_evd_dat_val = ""; // [I] 출금동의증빙자료값

		public String getErrorCode() {
			return errorCode;
		}
		public void setErrorCode(String errorCode) {
			this.errorCode = errorCode;
		}
		public String getOutp_atl() {
			return outp_atl;
		}
		public void setOutp_atl(String outp_atl) {
			this.outp_atl = outp_atl;
		}
		public String getFom_id() {
			return fom_id;
		}
		public void setFom_id(String fom_id) {
			this.fom_id = fom_id;
		}
		public String getDvn() {
			return dvn;
		}
		public void setDvn(String dvn) {
			this.dvn = dvn;
		}
		public String getCsn_yn() {
			return csn_yn;
		}
		public void setCsn_yn(String csn_yn) {
			this.csn_yn = csn_yn;
		}
		public String getOutp_yn() {
			return outp_yn;
		}
		public void setOutp_yn(String outp_yn) {
			this.outp_yn = outp_yn;
		}
		public String getPrnt_type() {
			return prnt_type;
		}
		public void setPrnt_type(String prnt_type) {
			this.prnt_type = prnt_type;
		}
		public String getPlno() {
			return plno;
		}
		public void setPlno(String plno) {
			this.plno = plno;
		}
		public String getIns_lcpl_dvcd() {
			return ins_lcpl_dvcd;
		}
		public void setIns_lcpl_dvcd(String ins_lcpl_dvcd) {
			this.ins_lcpl_dvcd = ins_lcpl_dvcd;
		}
		public String getPly_sqno() {
			return ply_sqno;
		}
		public void setPly_sqno(String ply_sqno) {
			this.ply_sqno = ply_sqno;
		}
		public String getBh_cd() {
			return bh_cd;
		}
		public void setBh_cd(String bh_cd) {
			this.bh_cd = bh_cd;
		}
		public String getBh_nm() {
			return bh_nm;
		}
		public void setBh_nm(String bh_nm) {
			this.bh_nm = bh_nm;
		}
		public String getEmpno() {
			return empno;
		}
		public void setEmpno(String empno) {
			this.empno = empno;
		}
		public String getEp_nm() {
			return ep_nm;
		}
		public void setEp_nm(String ep_nm) {
			this.ep_nm = ep_nm;
		}
		public String getInpd_cd() {
			return inpd_cd;
		}
		public void setInpd_cd(String inpd_cd) {
			this.inpd_cd = inpd_cd;
		}
		public String getInpd_nm() {
			return inpd_nm;
		}
		public void setInpd_nm(String inpd_nm) {
			this.inpd_nm = inpd_nm;
		}
		public String getInpd_type() {
			return inpd_type;
		}
		public void setInpd_type(String inpd_type) {
			this.inpd_type = inpd_type;
		}
		public String getStat_nm() {
			return stat_nm;
		}
		public void setStat_nm(String stat_nm) {
			this.stat_nm = stat_nm;
		}
		public String getStat_bh() {
			return stat_bh;
		}
		public void setStat_bh(String stat_bh) {
			this.stat_bh = stat_bh;
		}
		public String getStat_dt() {
			return stat_dt;
		}
		public void setStat_dt(String stat_dt) {
			this.stat_dt = stat_dt;
		}
		public String getPlhd_nm() {
			return plhd_nm;
		}
		public void setPlhd_nm(String plhd_nm) {
			this.plhd_nm = plhd_nm;
		}
		public String getShr_dvn() {
			return shr_dvn;
		}
		public void setShr_dvn(String shr_dvn) {
			this.shr_dvn = shr_dvn;
		}
		public String getPlhd_id() {
			return plhd_id;
		}
		public void setPlhd_id(String plhd_id) {
			this.plhd_id = plhd_id;
		}
		public String getArc_bgn_dd() {
			return arc_bgn_dd;
		}
		public void setArc_bgn_dd(String arc_bgn_dd) {
			this.arc_bgn_dd = arc_bgn_dd;
		}
		public String getArc_fin_dd() {
			return arc_fin_dd;
		}
		public void setArc_fin_dd(String arc_fin_dd) {
			this.arc_fin_dd = arc_fin_dd;
		}
		public String getPym_ycnt() {
			return pym_ycnt;
		}
		public void setPym_ycnt(String pym_ycnt) {
			this.pym_ycnt = pym_ycnt;
		}
		public String getDfmt_ycnt() {
			return dfmt_ycnt;
		}
		public void setDfmt_ycnt(String dfmt_ycnt) {
			this.dfmt_ycnt = dfmt_ycnt;
		}
		public String getExp_ycnt() {
			return exp_ycnt;
		}
		public void setExp_ycnt(String exp_ycnt) {
			this.exp_ycnt = exp_ycnt;
		}
		public String getColl_mtd() {
			return coll_mtd;
		}
		public void setColl_mtd(String coll_mtd) {
			this.coll_mtd = coll_mtd;
		}
		public String getFnal_pym_ym() {
			return fnal_pym_ym;
		}
		public void setFnal_pym_ym(String fnal_pym_ym) {
			this.fnal_pym_ym = fnal_pym_ym;
		}
		public String getPym_mtd_hngl_nm() {
			return pym_mtd_hngl_nm;
		}
		public void setPym_mtd_hngl_nm(String pym_mtd_hngl_nm) {
			this.pym_mtd_hngl_nm = pym_mtd_hngl_nm;
		}
		public String getPym_prm() {
			return pym_prm;
		}
		public void setPym_prm(String pym_prm) {
			this.pym_prm = pym_prm;
		}
		public String getTot_pym_orr() {
			return tot_pym_orr;
		}
		public void setTot_pym_orr(String tot_pym_orr) {
			this.tot_pym_orr = tot_pym_orr;
		}
		public String getFnal_pym_orr() {
			return fnal_pym_orr;
		}
		public void setFnal_pym_orr(String fnal_pym_orr) {
			this.fnal_pym_orr = fnal_pym_orr;
		}
		public String getTot_pym_prm() {
			return tot_pym_prm;
		}
		public void setTot_pym_prm(String tot_pym_prm) {
			this.tot_pym_prm = tot_pym_prm;
		}
		public String getLn_bh_cd() {
			return ln_bh_cd;
		}
		public void setLn_bh_cd(String ln_bh_cd) {
			this.ln_bh_cd = ln_bh_cd;
		}
		public String getLn_bh_nm() {
			return ln_bh_nm;
		}
		public void setLn_bh_nm(String ln_bh_nm) {
			this.ln_bh_nm = ln_bh_nm;
		}
		public String getLn_shp() {
			return ln_shp;
		}
		public void setLn_shp(String ln_shp) {
			this.ln_shp = ln_shp;
		}
		public String getLn_coll_mtd() {
			return ln_coll_mtd;
		}
		public void setLn_coll_mtd(String ln_coll_mtd) {
			this.ln_coll_mtd = ln_coll_mtd;
		}
		public String getColl_bh_cd() {
			return coll_bh_cd;
		}
		public void setColl_bh_cd(String coll_bh_cd) {
			this.coll_bh_cd = coll_bh_cd;
		}
		public String getColl_brn_cd() {
			return coll_brn_cd;
		}
		public void setColl_brn_cd(String coll_brn_cd) {
			this.coll_brn_cd = coll_brn_cd;
		}
		public String getColl_ep() {
			return coll_ep;
		}
		public void setColl_ep(String coll_ep) {
			this.coll_ep = coll_ep;
		}
		public String getColl_bh_nm() {
			return coll_bh_nm;
		}
		public void setColl_bh_nm(String coll_bh_nm) {
			this.coll_bh_nm = coll_bh_nm;
		}
		public String getColl_brn_nm() {
			return coll_brn_nm;
		}
		public void setColl_brn_nm(String coll_brn_nm) {
			this.coll_brn_nm = coll_brn_nm;
		}
		public String getColl_ep_nm() {
			return coll_ep_nm;
		}
		public void setColl_ep_nm(String coll_ep_nm) {
			this.coll_ep_nm = coll_ep_nm;
		}
		public String getColl_agnc_main() {
			return coll_agnc_main;
		}
		public void setColl_agnc_main(String coll_agnc_main) {
			this.coll_agnc_main = coll_agnc_main;
		}
		public String getColl_tlno() {
			return coll_tlno;
		}
		public void setColl_tlno(String coll_tlno) {
			this.coll_tlno = coll_tlno;
		}
		public String getNn_ed_proc_detl() {
			return nn_ed_proc_detl;
		}
		public void setNn_ed_proc_detl(String nn_ed_proc_detl) {
			this.nn_ed_proc_detl = nn_ed_proc_detl;
		}
		public String getRqst_no() {
			return rqst_no;
		}
		public void setRqst_no(String rqst_no) {
			this.rqst_no = rqst_no;
		}
		public String getRckd() {
			return rckd;
		}
		public void setRckd(String rckd) {
			this.rckd = rckd;
		}
		public String getRckn_amt() {
			return rckn_amt;
		}
		public void setRckn_amt(String rckn_amt) {
			this.rckn_amt = rckn_amt;
		}
		public String getRpm_prpl() {
			return rpm_prpl;
		}
		public void setRpm_prpl(String rpm_prpl) {
			this.rpm_prpl = rpm_prpl;
		}
		public String getNpt_dt() {
			return npt_dt;
		}
		public void setNpt_dt(String npt_dt) {
			this.npt_dt = npt_dt;
		}
		public String getNpt_inte() {
			return npt_inte;
		}
		public void setNpt_inte(String npt_inte) {
			this.npt_inte = npt_inte;
		}
		public String getRpm_inte() {
			return rpm_inte;
		}
		public void setRpm_inte(String rpm_inte) {
			this.rpm_inte = rpm_inte;
		}
		public String getPcpit_dt() {
			return pcpit_dt;
		}
		public void setPcpit_dt(String pcpit_dt) {
			this.pcpit_dt = pcpit_dt;
		}
		public String getPcpit() {
			return pcpit;
		}
		public void setPcpit(String pcpit) {
			this.pcpit = pcpit;
		}
		public String getRpm_pcpit() {
			return rpm_pcpit;
		}
		public void setRpm_pcpit(String rpm_pcpit) {
			this.rpm_pcpit = rpm_pcpit;
		}
		public String getBank_cd() {
			return bank_cd;
		}
		public void setBank_cd(String bank_cd) {
			this.bank_cd = bank_cd;
		}
		public String getBank_nm() {
			return bank_nm;
		}
		public void setBank_nm(String bank_nm) {
			this.bank_nm = bank_nm;
		}
		public String getAcc_no() {
			return acc_no;
		}
		public void setAcc_no(String acc_no) {
			this.acc_no = acc_no;
		}
		public String getClpno() {
			return clpno;
		}
		public void setClpno(String clpno) {
			this.clpno = clpno;
		}
		public String getDpsr_nm() {
			return dpsr_nm;
		}
		public void setDpsr_nm(String dpsr_nm) {
			this.dpsr_nm = dpsr_nm;
		}
		public String getDpsr_id() {
			return dpsr_id;
		}
		public void setDpsr_id(String dpsr_id) {
			this.dpsr_id = dpsr_id;
		}
		public String getDpsr_chek() {
			return dpsr_chek;
		}
		public void setDpsr_chek(String dpsr_chek) {
			this.dpsr_chek = dpsr_chek;
		}
		public String getRmk() {
			return rmk;
		}
		public void setRmk(String rmk) {
			this.rmk = rmk;
		}
		public String getErr_dvcd() {
			return err_dvcd;
		}
		public void setErr_dvcd(String err_dvcd) {
			this.err_dvcd = err_dvcd;
		}
		public String getInte_pd_1() {
			return inte_pd_1;
		}
		public void setInte_pd_1(String inte_pd_1) {
			this.inte_pd_1 = inte_pd_1;
		}
		public String getInte_et_1() {
			return inte_et_1;
		}
		public void setInte_et_1(String inte_et_1) {
			this.inte_et_1 = inte_et_1;
		}
		public String getInte_dcnt_1() {
			return inte_dcnt_1;
		}
		public void setInte_dcnt_1(String inte_dcnt_1) {
			this.inte_dcnt_1 = inte_dcnt_1;
		}
		public String getInte_amt_1() {
			return inte_amt_1;
		}
		public void setInte_amt_1(String inte_amt_1) {
			this.inte_amt_1 = inte_amt_1;
		}
		public String getInte_pd_2() {
			return inte_pd_2;
		}
		public void setInte_pd_2(String inte_pd_2) {
			this.inte_pd_2 = inte_pd_2;
		}
		public String getInte_et_2() {
			return inte_et_2;
		}
		public void setInte_et_2(String inte_et_2) {
			this.inte_et_2 = inte_et_2;
		}
		public String getInte_dcnt_2() {
			return inte_dcnt_2;
		}
		public void setInte_dcnt_2(String inte_dcnt_2) {
			this.inte_dcnt_2 = inte_dcnt_2;
		}
		public String getInte_amt_2() {
			return inte_amt_2;
		}
		public void setInte_amt_2(String inte_amt_2) {
			this.inte_amt_2 = inte_amt_2;
		}
		public String getInte_ovdu_1_pd() {
			return inte_ovdu_1_pd;
		}
		public void setInte_ovdu_1_pd(String inte_ovdu_1_pd) {
			this.inte_ovdu_1_pd = inte_ovdu_1_pd;
		}
		public String getInte_ovdu_fscl_ps() {
			return inte_ovdu_fscl_ps;
		}
		public void setInte_ovdu_fscl_ps(String inte_ovdu_fscl_ps) {
			this.inte_ovdu_fscl_ps = inte_ovdu_fscl_ps;
		}
		public String getInte_ovdu_day1_cnt() {
			return inte_ovdu_day1_cnt;
		}
		public void setInte_ovdu_day1_cnt(String inte_ovdu_day1_cnt) {
			this.inte_ovdu_day1_cnt = inte_ovdu_day1_cnt;
		}
		public String getInte_ovdu_1_amt() {
			return inte_ovdu_1_amt;
		}
		public void setInte_ovdu_1_amt(String inte_ovdu_1_amt) {
			this.inte_ovdu_1_amt = inte_ovdu_1_amt;
		}
		public String getInte_ovdu_2_pd() {
			return inte_ovdu_2_pd;
		}
		public void setInte_ovdu_2_pd(String inte_ovdu_2_pd) {
			this.inte_ovdu_2_pd = inte_ovdu_2_pd;
		}
		public String getInte_ovdu_sccl_ps() {
			return inte_ovdu_sccl_ps;
		}
		public void setInte_ovdu_sccl_ps(String inte_ovdu_sccl_ps) {
			this.inte_ovdu_sccl_ps = inte_ovdu_sccl_ps;
		}
		public String getInte_ovdu_dy2_cnt() {
			return inte_ovdu_dy2_cnt;
		}
		public void setInte_ovdu_dy2_cnt(String inte_ovdu_dy2_cnt) {
			this.inte_ovdu_dy2_cnt = inte_ovdu_dy2_cnt;
		}
		public String getInte_ovdu_2_amt() {
			return inte_ovdu_2_amt;
		}
		public void setInte_ovdu_2_amt(String inte_ovdu_2_amt) {
			this.inte_ovdu_2_amt = inte_ovdu_2_amt;
		}
		public String getUrnd_inte_pd() {
			return urnd_inte_pd;
		}
		public void setUrnd_inte_pd(String urnd_inte_pd) {
			this.urnd_inte_pd = urnd_inte_pd;
		}
		public String getUrnd_inte_et() {
			return urnd_inte_et;
		}
		public void setUrnd_inte_et(String urnd_inte_et) {
			this.urnd_inte_et = urnd_inte_et;
		}
		public String getUrnd_inte_dcnt() {
			return urnd_inte_dcnt;
		}
		public void setUrnd_inte_dcnt(String urnd_inte_dcnt) {
			this.urnd_inte_dcnt = urnd_inte_dcnt;
		}
		public String getUrnd_inte_amt() {
			return urnd_inte_amt;
		}
		public void setUrnd_inte_amt(String urnd_inte_amt) {
			this.urnd_inte_amt = urnd_inte_amt;
		}
		public String getMprt_dvn() {
			return mprt_dvn;
		}
		public void setMprt_dvn(String mprt_dvn) {
			this.mprt_dvn = mprt_dvn;
		}
		public String getMprt_amt() {
			return mprt_amt;
		}
		public void setMprt_amt(String mprt_amt) {
			this.mprt_amt = mprt_amt;
		}
		public String getPrnt_fom() {
			return prnt_fom;
		}
		public void setPrnt_fom(String prnt_fom) {
			this.prnt_fom = prnt_fom;
		}
		public String getPrnt_dta() {
			return prnt_dta;
		}
		public void setPrnt_dta(String prnt_dta) {
			this.prnt_dta = prnt_dta;
		}
		public String getImag_yn() {
			return imag_yn;
		}
		public void setImag_yn(String imag_yn) {
			this.imag_yn = imag_yn;
		}
		public String getImag_sno() {
			return imag_sno;
		}
		public void setImag_sno(String imag_sno) {
			this.imag_sno = imag_sno;
		}
		public String getImag_yn_1() {
			return imag_yn_1;
		}
		public void setImag_yn_1(String imag_yn_1) {
			this.imag_yn_1 = imag_yn_1;
		}
		public String getImag_sno_1() {
			return imag_sno_1;
		}
		public void setImag_sno_1(String imag_sno_1) {
			this.imag_sno_1 = imag_sno_1;
		}
		public String getPlno1() {
			return plno1;
		}
		public void setPlno1(String plno1) {
			this.plno1 = plno1;
		}
		public String getIns_lcpl_dvcd_1() {
			return ins_lcpl_dvcd_1;
		}
		public void setIns_lcpl_dvcd_1(String ins_lcpl_dvcd_1) {
			this.ins_lcpl_dvcd_1 = ins_lcpl_dvcd_1;
		}
		public String getPly_sqno_1() {
			return ply_sqno_1;
		}
		public void setPly_sqno_1(String ply_sqno_1) {
			this.ply_sqno_1 = ply_sqno_1;
		}
		public String getPly_outp_yn() {
			return ply_outp_yn;
		}
		public void setPly_outp_yn(String ply_outp_yn) {
			this.ply_outp_yn = ply_outp_yn;
		}
		public String getOupt_cpy_yn() {
			return oupt_cpy_yn;
		}
		public void setOupt_cpy_yn(String oupt_cpy_yn) {
			this.oupt_cpy_yn = oupt_cpy_yn;
		}
		public String getOupt_grn_yn() {
			return oupt_grn_yn;
		}
		public void setOupt_grn_yn(String oupt_grn_yn) {
			this.oupt_grn_yn = oupt_grn_yn;
		}
		public String getOupt_ecde_yn() {
			return oupt_ecde_yn;
		}
		public void setOupt_ecde_yn(String oupt_ecde_yn) {
			this.oupt_ecde_yn = oupt_ecde_yn;
		}
		public String getOupt_ecde_key() {
			return oupt_ecde_key;
		}
		public void setOupt_ecde_key(String oupt_ecde_key) {
			this.oupt_ecde_key = oupt_ecde_key;
		}
		public String getOupt_bz_dvn() {
			return oupt_bz_dvn;
		}
		public void setOupt_bz_dvn(String oupt_bz_dvn) {
			this.oupt_bz_dvn = oupt_bz_dvn;
		}
		public String getOupt_mea_dvn() {
			return oupt_mea_dvn;
		}
		public void setOupt_mea_dvn(String oupt_mea_dvn) {
			this.oupt_mea_dvn = oupt_mea_dvn;
		}
		public String getOupt_sign_key() {
			return oupt_sign_key;
		}
		public void setOupt_sign_key(String oupt_sign_key) {
			this.oupt_sign_key = oupt_sign_key;
		}
		public String getFom_dvn() {
			return fom_dvn;
		}
		public void setFom_dvn(String fom_dvn) {
			this.fom_dvn = fom_dvn;
		}
		
		/**
		 * @return the returnMessage
		 */
		public String getReturnMessage() {
			return returnMessage;
		}
		/**
		 * @param returnMessage the returnMessage to set
		 */
		public void setReturnMessage(String returnMessage) {
			this.returnMessage = returnMessage;
		}		

		/**
		 * @return the z_resp_msg
		 */
		public String getZ_resp_msg() {
			return z_resp_msg;
		}
		/**
		 * @param z_resp_msg the z_resp_msg to set
		 */
		public void setZ_resp_msg(String z_resp_msg) {
			this.z_resp_msg = z_resp_msg;
		}

		public String getWthd_csn_evd_dat_dvcd() {
			return wthd_csn_evd_dat_dvcd;
		}
		public void setWthd_csn_evd_dat_dvcd(String wthd_csn_evd_dat_dvcd) {
			this.wthd_csn_evd_dat_dvcd = wthd_csn_evd_dat_dvcd;
		}
		public String getWthd_csn_evd_dat_inpt_dvcd() {
			return wthd_csn_evd_dat_inpt_dvcd;
		}
		public void setWthd_csn_evd_dat_inpt_dvcd(String wthd_csn_evd_dat_inpt_dvcd) {
			this.wthd_csn_evd_dat_inpt_dvcd = wthd_csn_evd_dat_inpt_dvcd;
		}
		public String getWthd_csn_evd_dat_val() {
			return wthd_csn_evd_dat_val;
		}
		public void setWthd_csn_evd_dat_val(String wthd_csn_evd_dat_val) {
			this.wthd_csn_evd_dat_val = wthd_csn_evd_dat_val;
		}
}
