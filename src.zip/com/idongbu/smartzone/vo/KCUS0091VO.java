package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class KCUS0091VO extends CMMVO{
	
	public String rtun_cd = null;                       //[O]리턴코드
	public String cust_no = null;                       //[I]고객번호
	public String vh_no = null;                         //[I]차량번호
	public String srv_cn = null;                        //[I]서비스내용
	public String mny_vh_yn = null;                     //[O]다수차량여부
	public String vh_no_2 = null;                       //[O]차량번호2
	public String plno = null;                          //[O]증권번호
	public String ins_cd = null;                        //[O]피보험자코드
	public String ins_nm = null;                        //[O]피보험자명
	public String inpd_cd = null;                       //[O]보종코드
	public String inpd_nm = null;                       //[O]보종명
	public String ctp_cd = null;                        //[O]차종코드
	public String ctp_nm = null;                        //[O]차종명
	public String crnm_cd = null;                       //[O]차명코드
	public String crnm = null;                          //[O]차명
	public String benf_nm = null;                       //[O]수혜명
	public String ntrg_rs_cd = null;                    //[O]비대상사유코드
	public String sos_tty_dvcd = null;                  //[O]SOS특약구분코드
	public String tty_nm = null;                        //[O]특약명
	public String shtm_ctc_yn = null;                   //[O]단기계약여부
	public String hdlr_cd = null;                       //[O]취급자코드
	public String chn_cd = null;                        //[O]채널코드
	public String arc_pd = null;                        //[O]보험시기
	public String arc_et = null;                        //[O]보험종기
	public String dbrt_dvn = null;                      //[O]DBRT구분
	public String eltc_dvn = null;                      //[O]전기차구분
	public String eltc_oty = null;                      //[O]전기차출력량
	public String dspl = null;                          //[O]배기량
	public String ld_tns = null;                        //[O]적재톤수
	public String cpct_cnt = null;                      //[O]정원수
	public String aut_rnw_dvn = null;                   //[O]자동갱신구분
	public String dup_yn = null;                        //[O]중복여부
	public String nn_cplt_yn = null;                    //[O]미완료여부
	public String emg_tw_exn_cvr_tty_eny_yn = null;		//[O]긴급견인확대담보특약가입여부
	public String tty_nts = null;                       //[O]특약횟수
	public String tty_eny_nts = null;                   //[O]특약가입횟수
	public String srv_nts = null;                       //[O]서비스횟수
	public String proc_nts = null;                      //[O]처리횟수
	public String tty_nts_2 = null;                     //[O]특약횟수2
	public String crge_repa_tty_yn = null;              //[O]운반수리특약여부
	public String abs_equp_dvn = null;                  //[O]ABS장착구분
	public String aut_yn = null;                        //[O]자동여부
	public String fuln_ofer_yn = null;                  //[O]급유제공여부
	public String ry_yn = null;                         //[O]회수여부
	public String drve_tty_nm = null;                   //[O]운전특약명
	public String drvr_nm = null;                       //[O]운전자명
	public String drvr_rsdn_no = null;                  //[O]운전자주민번호
	public String drve_ag = null;                       //[O]운전연령
	public String drvr_rlt_cd = null;                   //[O]운전자관계코드
	public String drvr_rlt_nm = null;                   //[O]운전자관계명
	public String trv_dstc_tty_eny_yn = null;           //[O]주행거리특약가입여부
	public String trv_dstc_tty_s_m_s_ts_yn = null;      //[O]주행거리특약SMS전송여부

	public String errorCode = null;

	
	
	
	public String getRtun_cd() {
		return rtun_cd;
	}

	public void setRtun_cd(String rtun_cd) {
		this.rtun_cd = rtun_cd;
	}

	public String getCust_no() {
		return cust_no;
	}

	public void setCust_no(String cust_no) {
		this.cust_no = cust_no;
	}

	public String getVh_no() {
		return vh_no;
	}

	public void setVh_no(String vh_no) {
		this.vh_no = vh_no;
	}

	public String getSrv_cn() {
		return srv_cn;
	}

	public void setSrv_cn(String srv_cn) {
		this.srv_cn = srv_cn;
	}

	public String getMny_vh_yn() {
		return mny_vh_yn;
	}

	public void setMny_vh_yn(String mny_vh_yn) {
		this.mny_vh_yn = mny_vh_yn;
	}

	public String getVh_no_2() {
		return vh_no_2;
	}

	public void setVh_no_2(String vh_no_2) {
		this.vh_no_2 = vh_no_2;
	}

	public String getPlno() {
		return plno;
	}

	public void setPlno(String plno) {
		this.plno = plno;
	}

	public String getIns_cd() {
		return ins_cd;
	}

	public void setIns_cd(String ins_cd) {
		this.ins_cd = ins_cd;
	}

	public String getIns_nm() {
		return ins_nm;
	}

	public void setIns_nm(String ins_nm) {
		this.ins_nm = ins_nm;
	}

	public String getInpd_cd() {
		return inpd_cd;
	}

	public void setInpd_cd(String inpd_cd) {
		this.inpd_cd = inpd_cd;
	}

	public String getInpd_nm() {
		return inpd_nm;
	}

	public void setInpd_nm(String inpd_nm) {
		this.inpd_nm = inpd_nm;
	}

	public String getCtp_cd() {
		return ctp_cd;
	}

	public void setCtp_cd(String ctp_cd) {
		this.ctp_cd = ctp_cd;
	}

	public String getCtp_nm() {
		return ctp_nm;
	}

	public void setCtp_nm(String ctp_nm) {
		this.ctp_nm = ctp_nm;
	}

	public String getCrnm_cd() {
		return crnm_cd;
	}

	public void setCrnm_cd(String crnm_cd) {
		this.crnm_cd = crnm_cd;
	}

	public String getCrnm() {
		return crnm;
	}

	public void setCrnm(String crnm) {
		this.crnm = crnm;
	}

	public String getBenf_nm() {
		return benf_nm;
	}

	public void setBenf_nm(String benf_nm) {
		this.benf_nm = benf_nm;
	}

	public String getNtrg_rs_cd() {
		return ntrg_rs_cd;
	}

	public void setNtrg_rs_cd(String ntrg_rs_cd) {
		this.ntrg_rs_cd = ntrg_rs_cd;
	}

	public String getSos_tty_dvcd() {
		return sos_tty_dvcd;
	}

	public void setSos_tty_dvcd(String sos_tty_dvcd) {
		this.sos_tty_dvcd = sos_tty_dvcd;
	}

	public String getTty_nm() {
		return tty_nm;
	}

	public void setTty_nm(String tty_nm) {
		this.tty_nm = tty_nm;
	}

	public String getShtm_ctc_yn() {
		return shtm_ctc_yn;
	}

	public void setShtm_ctc_yn(String shtm_ctc_yn) {
		this.shtm_ctc_yn = shtm_ctc_yn;
	}

	public String getHdlr_cd() {
		return hdlr_cd;
	}

	public void setHdlr_cd(String hdlr_cd) {
		this.hdlr_cd = hdlr_cd;
	}

	public String getChn_cd() {
		return chn_cd;
	}

	public void setChn_cd(String chn_cd) {
		this.chn_cd = chn_cd;
	}

	public String getArc_pd() {
		return arc_pd;
	}

	public void setArc_pd(String arc_pd) {
		this.arc_pd = arc_pd;
	}

	public String getArc_et() {
		return arc_et;
	}

	public void setArc_et(String arc_et) {
		this.arc_et = arc_et;
	}

	public String getDbrt_dvn() {
		return dbrt_dvn;
	}

	public void setDbrt_dvn(String dbrt_dvn) {
		this.dbrt_dvn = dbrt_dvn;
	}

	public String getEltc_dvn() {
		return eltc_dvn;
	}

	public void setEltc_dvn(String eltc_dvn) {
		this.eltc_dvn = eltc_dvn;
	}

	public String getEltc_oty() {
		return eltc_oty;
	}

	public void setEltc_oty(String eltc_oty) {
		this.eltc_oty = eltc_oty;
	}

	public String getDspl() {
		return dspl;
	}

	public void setDspl(String dspl) {
		this.dspl = dspl;
	}

	public String getLd_tns() {
		return ld_tns;
	}

	public void setLd_tns(String ld_tns) {
		this.ld_tns = ld_tns;
	}

	public String getCpct_cnt() {
		return cpct_cnt;
	}

	public void setCpct_cnt(String cpct_cnt) {
		this.cpct_cnt = cpct_cnt;
	}

	public String getAut_rnw_dvn() {
		return aut_rnw_dvn;
	}

	public void setAut_rnw_dvn(String aut_rnw_dvn) {
		this.aut_rnw_dvn = aut_rnw_dvn;
	}

	public String getDup_yn() {
		return dup_yn;
	}

	public void setDup_yn(String dup_yn) {
		this.dup_yn = dup_yn;
	}

	public String getNn_cplt_yn() {
		return nn_cplt_yn;
	}

	public void setNn_cplt_yn(String nn_cplt_yn) {
		this.nn_cplt_yn = nn_cplt_yn;
	}

	public String getEmg_tw_exn_cvr_tty_eny_yn() {
		return emg_tw_exn_cvr_tty_eny_yn;
	}

	public void setEmg_tw_exn_cvr_tty_eny_yn(String emg_tw_exn_cvr_tty_eny_yn) {
		this.emg_tw_exn_cvr_tty_eny_yn = emg_tw_exn_cvr_tty_eny_yn;
	}

	public String getTty_nts() {
		return tty_nts;
	}

	public void setTty_nts(String tty_nts) {
		this.tty_nts = tty_nts;
	}

	public String getTty_eny_nts() {
		return tty_eny_nts;
	}

	public void setTty_eny_nts(String tty_eny_nts) {
		this.tty_eny_nts = tty_eny_nts;
	}

	public String getSrv_nts() {
		return srv_nts;
	}

	public void setSrv_nts(String srv_nts) {
		this.srv_nts = srv_nts;
	}

	public String getProc_nts() {
		return proc_nts;
	}

	public void setProc_nts(String proc_nts) {
		this.proc_nts = proc_nts;
	}

	public String getTty_nts_2() {
		return tty_nts_2;
	}

	public void setTty_nts_2(String tty_nts_2) {
		this.tty_nts_2 = tty_nts_2;
	}

	public String getCrge_repa_tty_yn() {
		return crge_repa_tty_yn;
	}

	public void setCrge_repa_tty_yn(String crge_repa_tty_yn) {
		this.crge_repa_tty_yn = crge_repa_tty_yn;
	}

	public String getAbs_equp_dvn() {
		return abs_equp_dvn;
	}

	public void setAbs_equp_dvn(String abs_equp_dvn) {
		this.abs_equp_dvn = abs_equp_dvn;
	}

	public String getAut_yn() {
		return aut_yn;
	}

	public void setAut_yn(String aut_yn) {
		this.aut_yn = aut_yn;
	}

	public String getFuln_ofer_yn() {
		return fuln_ofer_yn;
	}

	public void setFuln_ofer_yn(String fuln_ofer_yn) {
		this.fuln_ofer_yn = fuln_ofer_yn;
	}

	public String getRy_yn() {
		return ry_yn;
	}

	public void setRy_yn(String ry_yn) {
		this.ry_yn = ry_yn;
	}

	public String getDrve_tty_nm() {
		return drve_tty_nm;
	}

	public void setDrve_tty_nm(String drve_tty_nm) {
		this.drve_tty_nm = drve_tty_nm;
	}

	public String getDrvr_nm() {
		return drvr_nm;
	}

	public void setDrvr_nm(String drvr_nm) {
		this.drvr_nm = drvr_nm;
	}

	public String getDrvr_rsdn_no() {
		return drvr_rsdn_no;
	}

	public void setDrvr_rsdn_no(String drvr_rsdn_no) {
		this.drvr_rsdn_no = drvr_rsdn_no;
	}

	public String getDrve_ag() {
		return drve_ag;
	}

	public void setDrve_ag(String drve_ag) {
		this.drve_ag = drve_ag;
	}

	public String getDrvr_rlt_cd() {
		return drvr_rlt_cd;
	}

	public void setDrvr_rlt_cd(String drvr_rlt_cd) {
		this.drvr_rlt_cd = drvr_rlt_cd;
	}

	public String getDrvr_rlt_nm() {
		return drvr_rlt_nm;
	}

	public void setDrvr_rlt_nm(String drvr_rlt_nm) {
		this.drvr_rlt_nm = drvr_rlt_nm;
	}

	public String getTrv_dstc_tty_eny_yn() {
		return trv_dstc_tty_eny_yn;
	}

	public void setTrv_dstc_tty_eny_yn(String trv_dstc_tty_eny_yn) {
		this.trv_dstc_tty_eny_yn = trv_dstc_tty_eny_yn;
	}

	public String getTrv_dstc_tty_s_m_s_ts_yn() {
		return trv_dstc_tty_s_m_s_ts_yn;
	}

	public void setTrv_dstc_tty_s_m_s_ts_yn(String trv_dstc_tty_s_m_s_ts_yn) {
		this.trv_dstc_tty_s_m_s_ts_yn = trv_dstc_tty_s_m_s_ts_yn;
	}
}
