package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class KCUS0134VO extends CMMVO {

	public String rsdn_no	= "";// 주민번호
	public String cntp_1	= "";// 연락처1
	public String cntp_2	= "";// 연락처2
	public String cntp_3	= "";// 연락처3
	public String cust_nm	= "";// 고객명
	public String plno		= "";// 증권번호

	public String smat_lif_tgt_srch_lit__cust_nm[]	= new String[0];// 고객명
	public String smat_lif_tgt_srch_lit__brth[]		= new String[0];// 생년월일
	public String smat_lif_tgt_srch_lit__plno[]		= new String[0];// 증권번호
	public String smat_lif_tgt_srch_lit__rsdn_no[]	= new String[0];// 주민번호
	public String smat_lif_tgt_srch_lit__clp_1[]	= new String[0];// 휴대폰1
	public String smat_lif_tgt_srch_lit__clp_2[]	= new String[0];// 휴대폰2
	public String smat_lif_tgt_srch_lit__clp_3[]	= new String[0];// 휴대폰3
	public String smat_lif_tgt_srch_lit__pdc_cd[]	= new String[0];// 상품코드
	public String smat_lif_tgt_srch_lit__ctc_stat_cd[]	= new String[0];

	// 임시 시작
	public String errorCode;//에러코드
	public String z_msg_cd;//메시지 코드
	
	public String returnMessage;//메시지 내용
	
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getZ_msg_cd() {
		return z_msg_cd;
	}
	public void setZ_msg_cd(String z_msg_cd) {
		this.z_msg_cd = z_msg_cd;
	}
	public String getReturnMessage() {
		return returnMessage;
	}
	public void setReturnMessage(String returnMessage) {
		this.returnMessage = returnMessage;
	}
	// 임시 끝
	
	public String getRsdn_no() {
		return rsdn_no;
	}
	public void setRsdn_no(String rsdn_no) {
		this.rsdn_no = rsdn_no;
	}
	public String getCust_nm() {
		return cust_nm;
	}
	public void setCust_nm(String cust_nm) {
		this.cust_nm = cust_nm;
	}
	public String getPlno() {
		return plno;
	}
	public void setPlno(String plno) {
		this.plno = plno;
	}
	public String[] getSmat_lif_tgt_srch_lit__cust_nm() {
		return smat_lif_tgt_srch_lit__cust_nm;
	}
	public void setSmat_lif_tgt_srch_lit__cust_nm(
			String[] smat_lif_tgt_srch_lit__cust_nm) {
		this.smat_lif_tgt_srch_lit__cust_nm = smat_lif_tgt_srch_lit__cust_nm;
	}
	public String[] getSmat_lif_tgt_srch_lit__brth() {
		return smat_lif_tgt_srch_lit__brth;
	}
	public void setSmat_lif_tgt_srch_lit__brth(String[] smat_lif_tgt_srch_lit__brth) {
		this.smat_lif_tgt_srch_lit__brth = smat_lif_tgt_srch_lit__brth;
	}
	public String[] getSmat_lif_tgt_srch_lit__plno() {
		return smat_lif_tgt_srch_lit__plno;
	}
	public void setSmat_lif_tgt_srch_lit__plno(String[] smat_lif_tgt_srch_lit__plno) {
		this.smat_lif_tgt_srch_lit__plno = smat_lif_tgt_srch_lit__plno;
	}
	public String[] getSmat_lif_tgt_srch_lit__rsdn_no() {
		return smat_lif_tgt_srch_lit__rsdn_no;
	}
	public void setSmat_lif_tgt_srch_lit__rsdn_no(
			String[] smat_lif_tgt_srch_lit__rsdn_no) {
		this.smat_lif_tgt_srch_lit__rsdn_no = smat_lif_tgt_srch_lit__rsdn_no;
	}
	public String[] getSmat_lif_tgt_srch_lit__clp_1() {
		return smat_lif_tgt_srch_lit__clp_1;
	}
	public void setSmat_lif_tgt_srch_lit__clp_1(
			String[] smat_lif_tgt_srch_lit__clp_1) {
		this.smat_lif_tgt_srch_lit__clp_1 = smat_lif_tgt_srch_lit__clp_1;
	}
	public String[] getSmat_lif_tgt_srch_lit__clp_2() {
		return smat_lif_tgt_srch_lit__clp_2;
	}
	public void setSmat_lif_tgt_srch_lit__clp_2(
			String[] smat_lif_tgt_srch_lit__clp_2) {
		this.smat_lif_tgt_srch_lit__clp_2 = smat_lif_tgt_srch_lit__clp_2;
	}
	public String[] getSmat_lif_tgt_srch_lit__clp_3() {
		return smat_lif_tgt_srch_lit__clp_3;
	}
	public void setSmat_lif_tgt_srch_lit__clp_3(
			String[] smat_lif_tgt_srch_lit__clp_3) {
		this.smat_lif_tgt_srch_lit__clp_3 = smat_lif_tgt_srch_lit__clp_3;
	}
	public String[] getSmat_lif_tgt_srch_lit__pdc_cd() {
		return smat_lif_tgt_srch_lit__pdc_cd;
	}
	public void setSmat_lif_tgt_srch_lit__pdc_cd(
			String[] smat_lif_tgt_srch_lit__pdc_cd) {
		this.smat_lif_tgt_srch_lit__pdc_cd = smat_lif_tgt_srch_lit__pdc_cd;
	}
	
	public String getCntp_1() {
		return cntp_1;
	}

	public void setCntp_1(String cntp_1) {
		this.cntp_1 = cntp_1;
	}

	public String getCntp_2() {
		return cntp_2;
	}

	public void setCntp_2(String cntp_2) {
		this.cntp_2 = cntp_2;
	}

	public String getCntp_3() {
		return cntp_3;
	}

	public void setCntp_3(String cntp_3) {
		this.cntp_3 = cntp_3;
	}	

	public String[] getSmat_lif_tgt_srch_lit__ctc_stat_cd() {
		return smat_lif_tgt_srch_lit__ctc_stat_cd;
	}

	public void setSmat_lif_tgt_srch_lit__ctc_stat_cd(String[] smat_lif_tgt_srch_lit__ctc_stat_cd) {
		this.smat_lif_tgt_srch_lit__ctc_stat_cd = smat_lif_tgt_srch_lit__ctc_stat_cd;
	}

}
