package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class CCLM0060VO extends CMMVO {
	//전문필드
	public String rsdn_no = "";  //[I/O] 주민번호 LK_I_JUMIN_NO 주민번호
	public String msg_cd = "";  //[I/O] 메세지코드 LK_MSG_CD2 메세지코드2
	public String msg_nm = "";  //[I/O] 메시지 H_LK_MESSAGE2 메시지2
	public String pat_dvn_1 = "";  //[I/O] 파트구분1 LK_PART_GB1 파트구분1
	public String pat_dvn_2 = "";  //[I/O] 파트구분2 LK_PART_GB2 파트구분2
	public String bz_dvn_1 = "";  //[I/O] 업무구분1 LK_UPMU_CD1 업무구분1
	public String bz_dvn_2 = "";  //[I/O] 업무구분2 LK_UPMU_CD2 업무구분2
	public String bz_dvn_3 = "";  //[I/O] 업무구분3 LK_UPMU_CD3 업무구분3
	public String accd_rpt_no_1 = "";  //[I/O] 사고접수번호1 LK_SAGO_JUBSU_NO1 사고접수번호1        
	public String accd_oj_dvn_1 = "";  //[I/O] 사고목적구분1 LK_SAGO_MOKJUK_GB1 사고목적구분 1  
	public String accd_oj_sqno_1 = "";  //[I/O] 사고목적일련번호1 LK_SAGO_MOKJUK_SEQ1 사고목적일련번호 1
	public String inpd_nm_1 = "";  //[O] 보종명1 LK_BJ_NM1 보종명1
	public String pdc_nm_1 = "";  //[O] 상품명1 LK_PROD_NM1 상품명1
	public String vtm_nm_1 = "";  //[O] 피해자명1 LK_PIHEJA_NAME1 피해자명1
	public String accd_dttm_1 = "";  //[O] 사고일시1 LK_SAGO_YMDSB1 사고일시1
	public String accd_rpt_no_2 = "";  //[O] 사고접수번호2 LK_SAGO_JUBSU_NO2 사고접수번호2
	public String accd_oj_dvn_2 = "";  //[O] 사고목적구분 2 LK_SAGO_MOKJUK_GB2 사고목적구분 2
	public String accd_oj_sqno_2 = "";  //[O] 사고목적일련번호 2 LK_SAGO_MOKJUK_SEQ2 사고목적일련번호 2
	public String inpd_nm_2 = "";  //[O] 보종명2 LK_BJ_NM2 보종명2
	public String pdc_nm_2 = "";  //[O] 상품명2 LK_PROD_NM2 상품명2
	public String vtm_nm_2 = "";  //[O] 피해자명2 LK_PIHEJA_NAME2 피해자명2
	public String accd_dttm_2 = "";  //[O] 사고일시2 LK_SAGO_YMDSB2 사고일시2
	public String accd_rpt_no_3 = "";  //[O] 사고접수번호3 LK_SAGO_JUBSU_NO3 사고접수번호3
	public String accd_oj_dvn_3 = "";  //[O] 사고목적구분 3 LK_SAGO_MOKJUK_GB3 사고목적구분 3
	public String accd_oj_sqno_3 = "";  //[O] 사고목적일련번호 3 LK_SAGO_MOKJUK_SEQ3 사고목적일련번호 3
	public String inpd_nm_3 = "";  //[O] 보종명3 LK_BJ_NM3 보종명3
	public String pdc_nm_3 = "";  //[O] 상품명3 LK_PROD_NM3 상품명3
	public String vtm_nm_3 = "";  //[O] 피해자명3 LK_PIHEJA_NAME3 피해자명3
	public String accd_dttm_3 = "";  //[O] 사고일시3 LK_SAGO_YMDSB3 사고일시3
	public String accd_rpt_no_4 = "";  //[O] 사고접수번호4 LK_SAGO_JUBSU_NO4 사고접수번호4
	public String accd_oj_dvn_4 = "";  //[O] 사고목적구분 4 LK_SAGO_MOKJUK_GB4 사고목적구분 4
	public String accd_oj_sqno_4 = "";  //[O] 사고목적일련번호 4 LK_SAGO_MOKJUK_SEQ4 사고목적일련번호 4
	public String inpd_nm_4 = "";  //[O] 보종명4 LK_BJ_NM4 보종명4
	public String pdc_nm_4 = "";  //[O] 상품명4 LK_PROD_NM4 상품명4
	public String vtm_nm_4 = "";  //[O] 피해자명4 LK_PIHEJA_NAME4 피해자명4
	public String accd_dttm_4 = "";  //[O] 사고일시4 LK_SAGO_YMDSB4 사고일시4
	public String accd_rpt_no_5 = "";  //[O] 사고접수번호5 LK_SAGO_JUBSU_NO5 사고접수번호5
	public String accd_oj_dvn_5 = "";  //[O] 사고목적구분 5 LK_SAGO_MOKJUK_GB5 사고목적구분 5
	public String accd_oj_sqno_5 = "";  //[O] 사고목적일련번호 5 LK_SAGO_MOKJUK_SEQ5 사고목적일련번호 5
	public String inpd_nm_5 = "";  //[O] 보종명5 LK_BJ_NM5 보종명5
	public String pdc_nm_5 = "";  //[O] 상품명5 LK_PROD_NM5 상품명5
	public String vtm_nm_5 = "";  //[O] 피해자명5 LK_PIHEJA_NAME5 피해자명5
	public String accd_dttm_5 = "";  //[O] 사고일시5 LK_SAGO_YMDSB5 사고일시5
	public String accd_rpt_no_6 = "";  //[O] 사고접수번호6 LK_SAGO_JUBSU_NO6 사고접수번호6
	public String accd_oj_dvn_6 = "";  //[O] 사고목적구분 6 LK_SAGO_MOKJUK_GB6 사고목적구분 6
	public String accd_oj_sqno_6 = "";  //[O] 사고목적일련번호 6 LK_SAGO_MOKJUK_SEQ6 사고목적일련번호 6
	public String inpd_nm_6 = "";  //[O] 보종명6 LK_BJ_NM6 보종명6
	public String pdc_nm_6 = "";  //[O] 상품명6 LK_PROD_NM6 상품명6
	public String vtm_nm_6 = "";  //[O] 피해자명6 LK_PIHEJA_NAME6 피해자명6
	public String accd_dttm_6 = "";  //[O] 사고일시6 LK_SAGO_YMDSB6 사고일시6
	public String accd_rpt_no_7 = "";  //[O] 사고접수번호7 LK_SAGO_JUBSU_NO7 사고접수번호7
	public String accd_oj_dvn_7 = "";  //[O] 사고목적구분 7 LK_SAGO_MOKJUK_GB7 사고목적구분 7
	public String accd_oj_sqno_7 = "";  //[O] 사고목적일련번호 7 LK_SAGO_MOKJUK_SEQ7 사고목적일련번호 7
	public String inpd_nm_7 = "";  //[O] 보종명7 LK_BJ_NM7 보종명7
	public String pdc_nm_7 = "";  //[O] 상품명7 LK_PROD_NM7 상품명7
	public String vtm_nm_7 = "";  //[O] 피해자명7 LK_PIHEJA_NAME7 피해자명7
	public String accd_dttm_7 = "";  //[O] 사고일시7 LK_SAGO_YMDSB7 사고일시7
	public String accd_rpt_no_8 = "";  //[O] 사고접수번호8 LK_SAGO_JUBSU_NO8 사고접수번호8
	public String accd_oj_dvn_8 = "";  //[O] 사고목적구분 8 LK_SAGO_MOKJUK_GB8 사고목적구분 8
	public String accd_oj_sqno_8 = "";  //[O] 사고목적일련번호 8 LK_SAGO_MOKJUK_SEQ8 사고목적일련번호 8
	public String inpd_nm_8 = "";  //[O] 보종명8 LK_BJ_NM8 보종명8
	public String pdc_nm_8 = "";  //[O] 상품명8 LK_PROD_NM8 상품명8
	public String vtm_nm_8 = "";  //[O] 피해자명8 LK_PIHEJA_NAME8 피해자명8
	public String accd_dttm_8 = "";  //[O] 사고일시8 LK_SAGO_YMDSB8 사고일시8
	public String accd_rpt_no_9 = "";  //[O] 사고접수번호9 LK_SAGO_JUBSU_NO9 사고접수번호9
	public String accd_oj_dvn_9 = "";  //[O] 사고목적구분 9 LK_SAGO_MOKJUK_GB9 사고목적구분 9
	public String accd_oj_sqno_9 = "";  //[O] 사고목적일련번호 9 LK_SAGO_MOKJUK_SEQ9 사고목적일련번호 9
	public String inpd_nm_9 = "";  //[O] 보종명9 LK_BJ_NM9 보종명9
	public String pdc_nm_9 = "";  //[O] 상품명9 LK_PROD_NM9 상품명9
	public String vtm_nm_9 = "";  //[O] 피해자명9 LK_PIHEJA_NAME9 피해자명9
	public String accd_dttm_9 = "";  //[O] 사고일시9 LK_SAGO_YMDSB9 사고일시9
	public String accd_rpt_no_10 = "";  //[O] 사고접수번호10 LK_SAGO_JUBSU_NO10 사고접수번호10
	public String accd_oj_dvn_10 = "";  //[O] 사고목적구분 10 LK_SAGO_MOKJUK_GB10 사고목적구분 10
	public String accd_oj_sqno_10 = "";  //[O] 사고목적일련번호 10 LK_SAGO_MOKJUK_SEQ10 사고목적일련번호 10
	public String inpd_nm_10 = "";  //[O] 보종명10 LK_BJ_NM10 보종명10
	public String pdc_nm_10 = "";  //[O] 상품명10 LK_PROD_NM10 상품명10
	public String vtm_nm_10 = "";  //[O] 피해자명10 LK_PIHEJA_NAME10 피해자명10
	public String accd_dttm_10 = "";  //[O] 사고일시10 LK_SAGO_YMDSB10 사고일시10
	public String accd_rpt_no_11 = "";  //[O] 사고접수번호11 LK_SAGO_JUBSU_NO11 사고접수번호11
	public String accd_oj_dvn_11 = "";  //[O] 사고목적구분 11 LK_SAGO_MOKJUK_GB11 사고목적구분 11
	public String accd_oj_sqno_11 = "";  //[O] 사고목적일련번호 11 LK_SAGO_MOKJUK_SEQ11 사고목적일련번호 11
	public String inpd_nm_11 = "";  //[O] 보종명11 LK_BJ_NM11 보종명11
	public String pdc_nm_11 = "";  //[O] 상품명11 LK_PROD_NM11 상품명11
	public String vtm_nm_11 = "";  //[O] 피해자명11 LK_PIHEJA_NAME11 피해자명11
	public String accd_dttm_11 = "";  //[O] 사고일시11 LK_SAGO_YMDSB11 사고일시11
	public String accd_rpt_no_12 = "";  //[O] 사고접수번호12 LK_SAGO_JUBSU_NO12 사고접수번호12
	public String accd_oj_dvn_12 = "";  //[O] 사고목적구분 12 LK_SAGO_MOKJUK_GB12 사고목적구분 12
	public String accd_oj_sqno_12 = "";  //[O] 사고목적일련번호 12 LK_SAGO_MOKJUK_SEQ12 사고목적일련번호 12
	public String inpd_nm_12 = "";  //[O] 보종명12 LK_BJ_NM12 보종명12
	public String pdc_nm_12 = "";  //[O] 상품명12 LK_PROD_NM12 상품명12
	public String vtm_nm_12 = "";  //[O] 피해자명12 LK_PIHEJA_NAME12 피해자명12
	public String accd_dttm_12 = "";  //[O] 사고일시12 LK_SAGO_YMDSB12 사고일시12
	public String accd_rpt_no_13 = "";  //[O] 사고접수번호13 LK_SAGO_JUBSU_NO13 사고접수번호13
	public String accd_oj_dvn_13 = "";  //[O] 사고목적구분 13 LK_SAGO_MOKJUK_GB13 사고목적구분 13
	public String accd_oj_sqno_13 = "";  //[O] 사고목적일련번호 13 LK_SAGO_MOKJUK_SEQ13 사고목적일련번호 13
	public String inpd_nm_13 = "";  //[O] 보종명13 LK_BJ_NM13 보종명13
	public String pdc_nm_13 = "";  //[O] 상품명13 LK_PROD_NM13 상품명13
	public String vtm_nm_13 = "";  //[O] 피해자명13 LK_PIHEJA_NAME13 피해자명13
	public String accd_dttm_13 = "";  //[O] 사고일시13 LK_SAGO_YMDSB13 사고일시13
	public String accd_rpt_no_14 = "";  //[O] 사고접수번호14 LK_SAGO_JUBSU_NO14 사고접수번호14
	public String accd_oj_dvn_14 = "";  //[O] 사고목적구분 14 LK_SAGO_MOKJUK_GB14 사고목적구분 14
	public String accd_oj_sqno_14 = "";  //[O] 사고목적일련번호 14 LK_SAGO_MOKJUK_SEQ14 사고목적일련번호 14
	public String inpd_nm_14 = "";  //[O] 보종명14 LK_BJ_NM14 보종명14
	public String pdc_nm_14 = "";  //[O] 상품명14 LK_PROD_NM14 상품명14
	public String vtm_nm_14 = "";  //[O] 피해자명14 LK_PIHEJA_NAME14 피해자명14
	public String accd_dttm_14 = "";  //[O] 사고일시14 LK_SAGO_YMDSB14 사고일시14
	public String accd_rpt_no_15 = "";  //[O] 사고접수번호15 LK_SAGO_JUBSU_NO15 사고접수번호15
	public String accd_oj_dvn_15 = "";  //[O] 사고목적구분 15 LK_SAGO_MOKJUK_GB15 사고목적구분 15
	public String accd_oj_sqno_15 = "";  //[O] 사고목적일련번호 15 LK_SAGO_MOKJUK_SEQ15 사고목적일련번호 15
	public String inpd_nm_15 = "";  //[O] 보종명15 LK_BJ_NM15 보종명15
	public String pdc_nm_15 = "";  //[O] 상품명15 LK_PROD_NM15 상품명15
	public String vtm_nm_15 = "";  //[O] 피해자명15 LK_PIHEJA_NAME15 피해자명15
	public String accd_dttm_15 = "";  //[O] 사고일시15 LK_SAGO_YMDSB15 사고일시15
	public String accd_rpt_no_16 = "";  //[O] 사고접수번호16 LK_SAGO_JUBSU_NO16 사고접수번호16
	public String accd_oj_dvn_16 = "";  //[O] 사고목적구분 16 LK_SAGO_MOKJUK_GB16 사고목적구분 16
	public String accd_oj_sqno_16 = "";  //[O] 사고목적일련번호 16 LK_SAGO_MOKJUK_SEQ16 사고목적일련번호 16
	public String inpd_nm_16 = "";  //[O] 보종명16 LK_BJ_NM16 보종명16
	public String pdc_nm_16 = "";  //[O] 상품명16 LK_PROD_NM16 상품명16
	public String vtm_nm_16 = "";  //[O] 피해자명16 LK_PIHEJA_NAME16 피해자명16
	public String accd_dttm_16 = "";  //[O] 사고일시16 LK_SAGO_YMDSB16 사고일시16
	public String accd_rpt_no_17 = "";  //[O] 사고접수번호17 LK_SAGO_JUBSU_NO17 사고접수번호17
	public String accd_oj_dvn_17 = "";  //[O] 사고목적구분 17 LK_SAGO_MOKJUK_GB17 사고목적구분 17
	public String accd_oj_sqno_17 = "";  //[O] 사고목적일련번호 17 LK_SAGO_MOKJUK_SEQ17 사고목적일련번호 17
	public String inpd_nm_17 = "";  //[O] 보종명17 LK_BJ_NM17 보종명17
	public String pdc_nm_17 = "";  //[O] 상품명17 LK_PROD_NM17 상품명17
	public String vtm_nm_17 = "";  //[O] 피해자명17 LK_PIHEJA_NAME17 피해자명17
	public String accd_dttm_17 = "";  //[O] 사고일시17 LK_SAGO_YMDSB17 사고일시17
	public String accd_rpt_no_18 = "";  //[O] 사고접수번호18 LK_SAGO_JUBSU_NO18 사고접수번호18
	public String accd_oj_dvn_18 = "";  //[O] 사고목적구분 18 LK_SAGO_MOKJUK_GB18 사고목적구분 18
	public String accd_oj_sqno_18 = "";  //[O] 사고목적일련번호 18 LK_SAGO_MOKJUK_SEQ18 사고목적일련번호 18
	public String inpd_nm_18 = "";  //[O] 보종명18 LK_BJ_NM18 보종명18
	public String pdc_nm_18 = "";  //[O] 상품명18 LK_PROD_NM18 상품명18
	public String vtm_nm_18 = "";  //[O] 피해자명18 LK_PIHEJA_NAME18 피해자명18
	public String accd_dttm_18 = "";  //[O] 사고일시18 LK_SAGO_YMDSB18 사고일시18
	public String accd_rpt_no_19 = "";  //[O] 사고접수번호19 LK_SAGO_JUBSU_NO19 사고접수번호19
	public String accd_oj_dvn_19 = "";  //[O] 사고목적구분 19 LK_SAGO_MOKJUK_GB19 사고목적구분 19
	public String accd_oj_sqno_19 = "";  //[O] 사고목적일련번호 19 LK_SAGO_MOKJUK_SEQ19 사고목적일련번호 19
	public String inpd_nm_19 = "";  //[O] 보종명19 LK_BJ_NM19 보종명19
	public String pdc_nm_19 = "";  //[O] 상품명19 LK_PROD_NM19 상품명19
	public String vtm_nm_19 = "";  //[O] 피해자명19 LK_PIHEJA_NAME19 피해자명19
	public String accd_dttm_19 = "";  //[O] 사고일시19 LK_SAGO_YMDSB19 사고일시19
	public String accd_rpt_no_20 = "";  //[O] 사고접수번호20 LK_SAGO_JUBSU_NO20 사고접수번호20
	public String accd_oj_dvn_20 = "";  //[O] 사고목적구분 20 LK_SAGO_MOKJUK_GB20 사고목적구분 20
	public String accd_oj_sqno_20 = "";  //[O] 사고목적일련번호 20 LK_SAGO_MOKJUK_SEQ20 사고목적일련번호 20
	public String inpd_nm_20 = "";  //[O] 보종명20 LK_BJ_NM20 보종명20
	public String pdc_nm_20 = "";  //[O] 상품명20 LK_PROD_NM20 상품명20
	public String vtm_nm_20 = "";  //[O] 피해자명20 LK_PIHEJA_NAME20 피해자명20
	public String accd_dttm_20 = "";  //[O] 사고일시20 LK_SAGO_YMDSB20 사고일시20
	public String accd_rpt_no_21 = "";  //[O] 사고접수번호21 LK_SAGO_JUBSU_NO21 사고접수번호21
	public String accd_oj_dvn_21 = "";  //[O] 사고목적구분 21 LK_SAGO_MOKJUK_GB21 사고목적구분 21
	public String accd_oj_sqno_21 = "";  //[O] 사고목적일련번호 21 LK_SAGO_MOKJUK_SEQ21 사고목적일련번호 21
	public String inpd_nm_21 = "";  //[O] 보종명21 LK_BJ_NM21 보종명21
	public String pdc_nm_21 = "";  //[O] 상품명21 LK_PROD_NM21 상품명21
	public String vtm_nm_21 = "";  //[O] 피해자명21 LK_PIHEJA_NAME21 피해자명21
	public String accd_dttm_21 = "";  //[O] 사고일시21 LK_SAGO_YMDSB21 사고일시21
	public String accd_rpt_no_22 = "";  //[O] 사고접수번호22 LK_SAGO_JUBSU_NO22 사고접수번호22
	public String accd_oj_dvn_22 = "";  //[O] 사고목적구분 22 LK_SAGO_MOKJUK_GB22 사고목적구분 22
	public String accd_oj_sqno_22 = "";  //[O] 사고목적일련번호 22 LK_SAGO_MOKJUK_SEQ22 사고목적일련번호 22
	public String inpd_nm_22 = "";  //[O] 보종명22 LK_BJ_NM22 보종명22
	public String pdc_nm_22 = "";  //[O] 상품명22 LK_PROD_NM22 상품명22
	public String vtm_nm_22 = "";  //[O] 피해자명22 LK_PIHEJA_NAME22 피해자명22
	public String accd_dttm_22 = "";  //[O] 사고일시22 LK_SAGO_YMDSB22 사고일시22
	public String accd_rpt_no_23 = "";  //[O] 사고접수번호23 LK_SAGO_JUBSU_NO23 사고접수번호23
	public String accd_oj_dvn_23 = "";  //[O] 사고목적구분 23 LK_SAGO_MOKJUK_GB23 사고목적구분 23
	public String accd_oj_sqno_23 = "";  //[O] 사고목적일련번호 23 LK_SAGO_MOKJUK_SEQ23 사고목적일련번호 23
	public String inpd_nm_23 = "";  //[O] 보종명23 LK_BJ_NM23 보종명23
	public String pdc_nm_23 = "";  //[O] 상품명23 LK_PROD_NM23 상품명23
	public String vtm_nm_23 = "";  //[O] 피해자명23 LK_PIHEJA_NAME23 피해자명23
	public String accd_dttm_23 = "";  //[O] 사고일시23 LK_SAGO_YMDSB23 사고일시23
	public String accd_rpt_no_24 = "";  //[O] 사고접수번호24 LK_SAGO_JUBSU_NO24 사고접수번호24
	public String accd_oj_dvn_24 = "";  //[O] 사고목적구분 24 LK_SAGO_MOKJUK_GB24 사고목적구분 24
	public String accd_oj_sqno_24 = "";  //[O] 사고목적일련번호 24 LK_SAGO_MOKJUK_SEQ24 사고목적일련번호 24
	public String inpd_nm_24 = "";  //[O] 보종명24 LK_BJ_NM24 보종명24
	public String pdc_nm_24 = "";  //[O] 상품명24 LK_PROD_NM24 상품명24
	public String vtm_nm_24 = "";  //[O] 피해자명24 LK_PIHEJA_NAME24 피해자명24
	public String accd_dttm_24 = "";  //[O] 사고일시24 LK_SAGO_YMDSB24 사고일시24
	public String accd_rpt_no_25 = "";  //[O] 사고접수번호25 LK_SAGO_JUBSU_NO25 사고접수번호25
	public String accd_oj_dvn_25 = "";  //[O] 사고목적구분 25 LK_SAGO_MOKJUK_GB25 사고목적구분 25
	public String accd_oj_sqno_25 = "";  //[O] 사고목적일련번호 25 LK_SAGO_MOKJUK_SEQ25 사고목적일련번호 25
	public String inpd_nm_25 = "";  //[O] 보종명25 LK_BJ_NM25 보종명25
	public String pdc_nm_25 = "";  //[O] 상품명25 LK_PROD_NM25 상품명25
	public String vtm_nm_25 = "";  //[O] 피해자명25 LK_PIHEJA_NAME25 피해자명25
	public String accd_dttm_25 = "";  //[O] 사고일시25 LK_SAGO_YMDSB25 사고일시25
	public String accd_rpt_no_26 = "";  //[O] 사고접수번호26 LK_SAGO_JUBSU_NO26 사고접수번호26
	public String accd_oj_dvn_26 = "";  //[O] 사고목적구분 26 LK_SAGO_MOKJUK_GB26 사고목적구분 26
	public String accd_oj_sqno_26 = "";  //[O] 사고목적일련번호 26 LK_SAGO_MOKJUK_SEQ26 사고목적일련번호 26
	public String inpd_nm_26 = "";  //[O] 보종명26 LK_BJ_NM26 보종명26
	public String pdc_nm_26 = "";  //[O] 상품명26 LK_PROD_NM26 상품명26
	public String vtm_nm_26 = "";  //[O] 피해자명26 LK_PIHEJA_NAME26 피해자명26
	public String accd_dttm_26 = "";  //[O] 사고일시26 LK_SAGO_YMDSB26 사고일시26
	public String accd_rpt_no_27 = "";  //[O] 사고접수번호27 LK_SAGO_JUBSU_NO27 사고접수번호27
	public String accd_oj_dvn_27 = "";  //[O] 사고목적구분 27 LK_SAGO_MOKJUK_GB27 사고목적구분 27
	public String accd_oj_sqno_27 = "";  //[O] 사고목적일련번호 27 LK_SAGO_MOKJUK_SEQ27 사고목적일련번호 27
	public String inpd_nm_27 = "";  //[O] 보종명27 LK_BJ_NM27 보종명27
	public String pdc_nm_27 = "";  //[O] 상품명27 LK_PROD_NM27 상품명27
	public String vtm_nm_27 = "";  //[O] 피해자명27 LK_PIHEJA_NAME27 피해자명27
	public String accd_dttm_27 = "";  //[O] 사고일시27 LK_SAGO_YMDSB27 사고일시27
	public String accd_rpt_no_28 = "";  //[O] 사고접수번호28 LK_SAGO_JUBSU_NO28 사고접수번호28
	public String accd_oj_dvn_28 = "";  //[O] 사고목적구분 28 LK_SAGO_MOKJUK_GB28 사고목적구분 28
	public String accd_oj_sqno_28 = "";  //[O] 사고목적일련번호 28 LK_SAGO_MOKJUK_SEQ28 사고목적일련번호 28
	public String inpd_nm_28 = "";  //[O] 보종명28 LK_BJ_NM28 보종명28
	public String pdc_nm_28 = "";  //[O] 상품명28 LK_PROD_NM28 상품명28
	public String vtm_nm_28 = "";  //[O] 피해자명28 LK_PIHEJA_NAME28 피해자명28
	public String accd_dttm_28 = "";  //[O] 사고일시28 LK_SAGO_YMDSB28 사고일시28
	public String accd_rpt_no_29 = "";  //[O] 사고접수번호29 LK_SAGO_JUBSU_NO29 사고접수번호29
	public String accd_oj_dvn_29 = "";  //[O] 사고목적구분 29 LK_SAGO_MOKJUK_GB29 사고목적구분 29
	public String accd_oj_sqno_29 = "";  //[O] 사고목적일련번호 29 LK_SAGO_MOKJUK_SEQ29 사고목적일련번호 29
	public String inpd_nm_29 = "";  //[O] 보종명29 LK_BJ_NM29 보종명29
	public String pdc_nm_29 = "";  //[O] 상품명29 LK_PROD_NM29 상품명29
	public String vtm_nm_29 = "";  //[O] 피해자명29 LK_PIHEJA_NAME29 피해자명29
	public String accd_dttm_29 = "";  //[O] 사고일시29 LK_SAGO_YMDSB29 사고일시29
	public String accd_rpt_no_30 = "";  //[O] 사고접수번호30 LK_SAGO_JUBSU_NO30 사고접수번호30
	public String accd_oj_dvn_30 = "";  //[O] 사고목적구분 30 LK_SAGO_MOKJUK_GB30 사고목적구분 30
	public String accd_oj_sqno_30 = "";  //[O] 사고목적일련번호 30 LK_SAGO_MOKJUK_SEQ30 사고목적일련번호 30
	public String inpd_nm_30 = "";  //[O] 보종명30 LK_BJ_NM30 보종명30
	public String pdc_nm_30 = "";  //[O] 상품명30 LK_PROD_NM30 상품명30
	public String vtm_nm_30 = "";  //[O] 피해자명30 LK_PIHEJA_NAME30 피해자명30
	public String accd_dttm_30 = "";  //[O] 사고일시30 LK_SAGO_YMDSB30 사고일시30
	public String hdlr_empno = "";  //[I] 취급자사원번호  
	public String getRsdn_no() {
		return rsdn_no;
	}
	public void setRsdn_no(String rsdn_no) {
		this.rsdn_no = rsdn_no;
	}
	public String getMsg_cd() {
		return msg_cd;
	}
	public void setMsg_cd(String msg_cd) {
		this.msg_cd = msg_cd;
	}
	public String getMsg_nm() {
		return msg_nm;
	}
	public void setMsg_nm(String msg_nm) {
		this.msg_nm = msg_nm;
	}
	public String getPat_dvn_1() {
		return pat_dvn_1;
	}
	public void setPat_dvn_1(String pat_dvn_1) {
		this.pat_dvn_1 = pat_dvn_1;
	}
	public String getPat_dvn_2() {
		return pat_dvn_2;
	}
	public void setPat_dvn_2(String pat_dvn_2) {
		this.pat_dvn_2 = pat_dvn_2;
	}
	public String getBz_dvn_1() {
		return bz_dvn_1;
	}
	public void setBz_dvn_1(String bz_dvn_1) {
		this.bz_dvn_1 = bz_dvn_1;
	}
	public String getBz_dvn_2() {
		return bz_dvn_2;
	}
	public void setBz_dvn_2(String bz_dvn_2) {
		this.bz_dvn_2 = bz_dvn_2;
	}
	public String getBz_dvn_3() {
		return bz_dvn_3;
	}
	public void setBz_dvn_3(String bz_dvn_3) {
		this.bz_dvn_3 = bz_dvn_3;
	}
	public String getAccd_rpt_no_1() {
		return accd_rpt_no_1;
	}
	public void setAccd_rpt_no_1(String accd_rpt_no_1) {
		this.accd_rpt_no_1 = accd_rpt_no_1;
	}
	public String getAccd_oj_dvn_1() {
		return accd_oj_dvn_1;
	}
	public void setAccd_oj_dvn_1(String accd_oj_dvn_1) {
		this.accd_oj_dvn_1 = accd_oj_dvn_1;
	}
	public String getAccd_oj_sqno_1() {
		return accd_oj_sqno_1;
	}
	public void setAccd_oj_sqno_1(String accd_oj_sqno_1) {
		this.accd_oj_sqno_1 = accd_oj_sqno_1;
	}
	public String getInpd_nm_1() {
		return inpd_nm_1;
	}
	public void setInpd_nm_1(String inpd_nm_1) {
		this.inpd_nm_1 = inpd_nm_1;
	}
	public String getPdc_nm_1() {
		return pdc_nm_1;
	}
	public void setPdc_nm_1(String pdc_nm_1) {
		this.pdc_nm_1 = pdc_nm_1;
	}
	public String getVtm_nm_1() {
		return vtm_nm_1;
	}
	public void setVtm_nm_1(String vtm_nm_1) {
		this.vtm_nm_1 = vtm_nm_1;
	}
	public String getAccd_dttm_1() {
		return accd_dttm_1;
	}
	public void setAccd_dttm_1(String accd_dttm_1) {
		this.accd_dttm_1 = accd_dttm_1;
	}
	public String getAccd_rpt_no_2() {
		return accd_rpt_no_2;
	}
	public void setAccd_rpt_no_2(String accd_rpt_no_2) {
		this.accd_rpt_no_2 = accd_rpt_no_2;
	}
	public String getAccd_oj_dvn_2() {
		return accd_oj_dvn_2;
	}
	public void setAccd_oj_dvn_2(String accd_oj_dvn_2) {
		this.accd_oj_dvn_2 = accd_oj_dvn_2;
	}
	public String getAccd_oj_sqno_2() {
		return accd_oj_sqno_2;
	}
	public void setAccd_oj_sqno_2(String accd_oj_sqno_2) {
		this.accd_oj_sqno_2 = accd_oj_sqno_2;
	}
	public String getInpd_nm_2() {
		return inpd_nm_2;
	}
	public void setInpd_nm_2(String inpd_nm_2) {
		this.inpd_nm_2 = inpd_nm_2;
	}
	public String getPdc_nm_2() {
		return pdc_nm_2;
	}
	public void setPdc_nm_2(String pdc_nm_2) {
		this.pdc_nm_2 = pdc_nm_2;
	}
	public String getVtm_nm_2() {
		return vtm_nm_2;
	}
	public void setVtm_nm_2(String vtm_nm_2) {
		this.vtm_nm_2 = vtm_nm_2;
	}
	public String getAccd_dttm_2() {
		return accd_dttm_2;
	}
	public void setAccd_dttm_2(String accd_dttm_2) {
		this.accd_dttm_2 = accd_dttm_2;
	}
	public String getAccd_rpt_no_3() {
		return accd_rpt_no_3;
	}
	public void setAccd_rpt_no_3(String accd_rpt_no_3) {
		this.accd_rpt_no_3 = accd_rpt_no_3;
	}
	public String getAccd_oj_dvn_3() {
		return accd_oj_dvn_3;
	}
	public void setAccd_oj_dvn_3(String accd_oj_dvn_3) {
		this.accd_oj_dvn_3 = accd_oj_dvn_3;
	}
	public String getAccd_oj_sqno_3() {
		return accd_oj_sqno_3;
	}
	public void setAccd_oj_sqno_3(String accd_oj_sqno_3) {
		this.accd_oj_sqno_3 = accd_oj_sqno_3;
	}
	public String getInpd_nm_3() {
		return inpd_nm_3;
	}
	public void setInpd_nm_3(String inpd_nm_3) {
		this.inpd_nm_3 = inpd_nm_3;
	}
	public String getPdc_nm_3() {
		return pdc_nm_3;
	}
	public void setPdc_nm_3(String pdc_nm_3) {
		this.pdc_nm_3 = pdc_nm_3;
	}
	public String getVtm_nm_3() {
		return vtm_nm_3;
	}
	public void setVtm_nm_3(String vtm_nm_3) {
		this.vtm_nm_3 = vtm_nm_3;
	}
	public String getAccd_dttm_3() {
		return accd_dttm_3;
	}
	public void setAccd_dttm_3(String accd_dttm_3) {
		this.accd_dttm_3 = accd_dttm_3;
	}
	public String getAccd_rpt_no_4() {
		return accd_rpt_no_4;
	}
	public void setAccd_rpt_no_4(String accd_rpt_no_4) {
		this.accd_rpt_no_4 = accd_rpt_no_4;
	}
	public String getAccd_oj_dvn_4() {
		return accd_oj_dvn_4;
	}
	public void setAccd_oj_dvn_4(String accd_oj_dvn_4) {
		this.accd_oj_dvn_4 = accd_oj_dvn_4;
	}
	public String getAccd_oj_sqno_4() {
		return accd_oj_sqno_4;
	}
	public void setAccd_oj_sqno_4(String accd_oj_sqno_4) {
		this.accd_oj_sqno_4 = accd_oj_sqno_4;
	}
	public String getInpd_nm_4() {
		return inpd_nm_4;
	}
	public void setInpd_nm_4(String inpd_nm_4) {
		this.inpd_nm_4 = inpd_nm_4;
	}
	public String getPdc_nm_4() {
		return pdc_nm_4;
	}
	public void setPdc_nm_4(String pdc_nm_4) {
		this.pdc_nm_4 = pdc_nm_4;
	}
	public String getVtm_nm_4() {
		return vtm_nm_4;
	}
	public void setVtm_nm_4(String vtm_nm_4) {
		this.vtm_nm_4 = vtm_nm_4;
	}
	public String getAccd_dttm_4() {
		return accd_dttm_4;
	}
	public void setAccd_dttm_4(String accd_dttm_4) {
		this.accd_dttm_4 = accd_dttm_4;
	}
	public String getAccd_rpt_no_5() {
		return accd_rpt_no_5;
	}
	public void setAccd_rpt_no_5(String accd_rpt_no_5) {
		this.accd_rpt_no_5 = accd_rpt_no_5;
	}
	public String getAccd_oj_dvn_5() {
		return accd_oj_dvn_5;
	}
	public void setAccd_oj_dvn_5(String accd_oj_dvn_5) {
		this.accd_oj_dvn_5 = accd_oj_dvn_5;
	}
	public String getAccd_oj_sqno_5() {
		return accd_oj_sqno_5;
	}
	public void setAccd_oj_sqno_5(String accd_oj_sqno_5) {
		this.accd_oj_sqno_5 = accd_oj_sqno_5;
	}
	public String getInpd_nm_5() {
		return inpd_nm_5;
	}
	public void setInpd_nm_5(String inpd_nm_5) {
		this.inpd_nm_5 = inpd_nm_5;
	}
	public String getPdc_nm_5() {
		return pdc_nm_5;
	}
	public void setPdc_nm_5(String pdc_nm_5) {
		this.pdc_nm_5 = pdc_nm_5;
	}
	public String getVtm_nm_5() {
		return vtm_nm_5;
	}
	public void setVtm_nm_5(String vtm_nm_5) {
		this.vtm_nm_5 = vtm_nm_5;
	}
	public String getAccd_dttm_5() {
		return accd_dttm_5;
	}
	public void setAccd_dttm_5(String accd_dttm_5) {
		this.accd_dttm_5 = accd_dttm_5;
	}
	public String getAccd_rpt_no_6() {
		return accd_rpt_no_6;
	}
	public void setAccd_rpt_no_6(String accd_rpt_no_6) {
		this.accd_rpt_no_6 = accd_rpt_no_6;
	}
	public String getAccd_oj_dvn_6() {
		return accd_oj_dvn_6;
	}
	public void setAccd_oj_dvn_6(String accd_oj_dvn_6) {
		this.accd_oj_dvn_6 = accd_oj_dvn_6;
	}
	public String getAccd_oj_sqno_6() {
		return accd_oj_sqno_6;
	}
	public void setAccd_oj_sqno_6(String accd_oj_sqno_6) {
		this.accd_oj_sqno_6 = accd_oj_sqno_6;
	}
	public String getInpd_nm_6() {
		return inpd_nm_6;
	}
	public void setInpd_nm_6(String inpd_nm_6) {
		this.inpd_nm_6 = inpd_nm_6;
	}
	public String getPdc_nm_6() {
		return pdc_nm_6;
	}
	public void setPdc_nm_6(String pdc_nm_6) {
		this.pdc_nm_6 = pdc_nm_6;
	}
	public String getVtm_nm_6() {
		return vtm_nm_6;
	}
	public void setVtm_nm_6(String vtm_nm_6) {
		this.vtm_nm_6 = vtm_nm_6;
	}
	public String getAccd_dttm_6() {
		return accd_dttm_6;
	}
	public void setAccd_dttm_6(String accd_dttm_6) {
		this.accd_dttm_6 = accd_dttm_6;
	}
	public String getAccd_rpt_no_7() {
		return accd_rpt_no_7;
	}
	public void setAccd_rpt_no_7(String accd_rpt_no_7) {
		this.accd_rpt_no_7 = accd_rpt_no_7;
	}
	public String getAccd_oj_dvn_7() {
		return accd_oj_dvn_7;
	}
	public void setAccd_oj_dvn_7(String accd_oj_dvn_7) {
		this.accd_oj_dvn_7 = accd_oj_dvn_7;
	}
	public String getAccd_oj_sqno_7() {
		return accd_oj_sqno_7;
	}
	public void setAccd_oj_sqno_7(String accd_oj_sqno_7) {
		this.accd_oj_sqno_7 = accd_oj_sqno_7;
	}
	public String getInpd_nm_7() {
		return inpd_nm_7;
	}
	public void setInpd_nm_7(String inpd_nm_7) {
		this.inpd_nm_7 = inpd_nm_7;
	}
	public String getPdc_nm_7() {
		return pdc_nm_7;
	}
	public void setPdc_nm_7(String pdc_nm_7) {
		this.pdc_nm_7 = pdc_nm_7;
	}
	public String getVtm_nm_7() {
		return vtm_nm_7;
	}
	public void setVtm_nm_7(String vtm_nm_7) {
		this.vtm_nm_7 = vtm_nm_7;
	}
	public String getAccd_dttm_7() {
		return accd_dttm_7;
	}
	public void setAccd_dttm_7(String accd_dttm_7) {
		this.accd_dttm_7 = accd_dttm_7;
	}
	public String getAccd_rpt_no_8() {
		return accd_rpt_no_8;
	}
	public void setAccd_rpt_no_8(String accd_rpt_no_8) {
		this.accd_rpt_no_8 = accd_rpt_no_8;
	}
	public String getAccd_oj_dvn_8() {
		return accd_oj_dvn_8;
	}
	public void setAccd_oj_dvn_8(String accd_oj_dvn_8) {
		this.accd_oj_dvn_8 = accd_oj_dvn_8;
	}
	public String getAccd_oj_sqno_8() {
		return accd_oj_sqno_8;
	}
	public void setAccd_oj_sqno_8(String accd_oj_sqno_8) {
		this.accd_oj_sqno_8 = accd_oj_sqno_8;
	}
	public String getInpd_nm_8() {
		return inpd_nm_8;
	}
	public void setInpd_nm_8(String inpd_nm_8) {
		this.inpd_nm_8 = inpd_nm_8;
	}
	public String getPdc_nm_8() {
		return pdc_nm_8;
	}
	public void setPdc_nm_8(String pdc_nm_8) {
		this.pdc_nm_8 = pdc_nm_8;
	}
	public String getVtm_nm_8() {
		return vtm_nm_8;
	}
	public void setVtm_nm_8(String vtm_nm_8) {
		this.vtm_nm_8 = vtm_nm_8;
	}
	public String getAccd_dttm_8() {
		return accd_dttm_8;
	}
	public void setAccd_dttm_8(String accd_dttm_8) {
		this.accd_dttm_8 = accd_dttm_8;
	}
	public String getAccd_rpt_no_9() {
		return accd_rpt_no_9;
	}
	public void setAccd_rpt_no_9(String accd_rpt_no_9) {
		this.accd_rpt_no_9 = accd_rpt_no_9;
	}
	public String getAccd_oj_dvn_9() {
		return accd_oj_dvn_9;
	}
	public void setAccd_oj_dvn_9(String accd_oj_dvn_9) {
		this.accd_oj_dvn_9 = accd_oj_dvn_9;
	}
	public String getAccd_oj_sqno_9() {
		return accd_oj_sqno_9;
	}
	public void setAccd_oj_sqno_9(String accd_oj_sqno_9) {
		this.accd_oj_sqno_9 = accd_oj_sqno_9;
	}
	public String getInpd_nm_9() {
		return inpd_nm_9;
	}
	public void setInpd_nm_9(String inpd_nm_9) {
		this.inpd_nm_9 = inpd_nm_9;
	}
	public String getPdc_nm_9() {
		return pdc_nm_9;
	}
	public void setPdc_nm_9(String pdc_nm_9) {
		this.pdc_nm_9 = pdc_nm_9;
	}
	public String getVtm_nm_9() {
		return vtm_nm_9;
	}
	public void setVtm_nm_9(String vtm_nm_9) {
		this.vtm_nm_9 = vtm_nm_9;
	}
	public String getAccd_dttm_9() {
		return accd_dttm_9;
	}
	public void setAccd_dttm_9(String accd_dttm_9) {
		this.accd_dttm_9 = accd_dttm_9;
	}
	public String getAccd_rpt_no_10() {
		return accd_rpt_no_10;
	}
	public void setAccd_rpt_no_10(String accd_rpt_no_10) {
		this.accd_rpt_no_10 = accd_rpt_no_10;
	}
	public String getAccd_oj_dvn_10() {
		return accd_oj_dvn_10;
	}
	public void setAccd_oj_dvn_10(String accd_oj_dvn_10) {
		this.accd_oj_dvn_10 = accd_oj_dvn_10;
	}
	public String getAccd_oj_sqno_10() {
		return accd_oj_sqno_10;
	}
	public void setAccd_oj_sqno_10(String accd_oj_sqno_10) {
		this.accd_oj_sqno_10 = accd_oj_sqno_10;
	}
	public String getInpd_nm_10() {
		return inpd_nm_10;
	}
	public void setInpd_nm_10(String inpd_nm_10) {
		this.inpd_nm_10 = inpd_nm_10;
	}
	public String getPdc_nm_10() {
		return pdc_nm_10;
	}
	public void setPdc_nm_10(String pdc_nm_10) {
		this.pdc_nm_10 = pdc_nm_10;
	}
	public String getVtm_nm_10() {
		return vtm_nm_10;
	}
	public void setVtm_nm_10(String vtm_nm_10) {
		this.vtm_nm_10 = vtm_nm_10;
	}
	public String getAccd_dttm_10() {
		return accd_dttm_10;
	}
	public void setAccd_dttm_10(String accd_dttm_10) {
		this.accd_dttm_10 = accd_dttm_10;
	}
	public String getAccd_rpt_no_11() {
		return accd_rpt_no_11;
	}
	public void setAccd_rpt_no_11(String accd_rpt_no_11) {
		this.accd_rpt_no_11 = accd_rpt_no_11;
	}
	public String getAccd_oj_dvn_11() {
		return accd_oj_dvn_11;
	}
	public void setAccd_oj_dvn_11(String accd_oj_dvn_11) {
		this.accd_oj_dvn_11 = accd_oj_dvn_11;
	}
	public String getAccd_oj_sqno_11() {
		return accd_oj_sqno_11;
	}
	public void setAccd_oj_sqno_11(String accd_oj_sqno_11) {
		this.accd_oj_sqno_11 = accd_oj_sqno_11;
	}
	public String getInpd_nm_11() {
		return inpd_nm_11;
	}
	public void setInpd_nm_11(String inpd_nm_11) {
		this.inpd_nm_11 = inpd_nm_11;
	}
	public String getPdc_nm_11() {
		return pdc_nm_11;
	}
	public void setPdc_nm_11(String pdc_nm_11) {
		this.pdc_nm_11 = pdc_nm_11;
	}
	public String getVtm_nm_11() {
		return vtm_nm_11;
	}
	public void setVtm_nm_11(String vtm_nm_11) {
		this.vtm_nm_11 = vtm_nm_11;
	}
	public String getAccd_dttm_11() {
		return accd_dttm_11;
	}
	public void setAccd_dttm_11(String accd_dttm_11) {
		this.accd_dttm_11 = accd_dttm_11;
	}
	public String getAccd_rpt_no_12() {
		return accd_rpt_no_12;
	}
	public void setAccd_rpt_no_12(String accd_rpt_no_12) {
		this.accd_rpt_no_12 = accd_rpt_no_12;
	}
	public String getAccd_oj_dvn_12() {
		return accd_oj_dvn_12;
	}
	public void setAccd_oj_dvn_12(String accd_oj_dvn_12) {
		this.accd_oj_dvn_12 = accd_oj_dvn_12;
	}
	public String getAccd_oj_sqno_12() {
		return accd_oj_sqno_12;
	}
	public void setAccd_oj_sqno_12(String accd_oj_sqno_12) {
		this.accd_oj_sqno_12 = accd_oj_sqno_12;
	}
	public String getInpd_nm_12() {
		return inpd_nm_12;
	}
	public void setInpd_nm_12(String inpd_nm_12) {
		this.inpd_nm_12 = inpd_nm_12;
	}
	public String getPdc_nm_12() {
		return pdc_nm_12;
	}
	public void setPdc_nm_12(String pdc_nm_12) {
		this.pdc_nm_12 = pdc_nm_12;
	}
	public String getVtm_nm_12() {
		return vtm_nm_12;
	}
	public void setVtm_nm_12(String vtm_nm_12) {
		this.vtm_nm_12 = vtm_nm_12;
	}
	public String getAccd_dttm_12() {
		return accd_dttm_12;
	}
	public void setAccd_dttm_12(String accd_dttm_12) {
		this.accd_dttm_12 = accd_dttm_12;
	}
	public String getAccd_rpt_no_13() {
		return accd_rpt_no_13;
	}
	public void setAccd_rpt_no_13(String accd_rpt_no_13) {
		this.accd_rpt_no_13 = accd_rpt_no_13;
	}
	public String getAccd_oj_dvn_13() {
		return accd_oj_dvn_13;
	}
	public void setAccd_oj_dvn_13(String accd_oj_dvn_13) {
		this.accd_oj_dvn_13 = accd_oj_dvn_13;
	}
	public String getAccd_oj_sqno_13() {
		return accd_oj_sqno_13;
	}
	public void setAccd_oj_sqno_13(String accd_oj_sqno_13) {
		this.accd_oj_sqno_13 = accd_oj_sqno_13;
	}
	public String getInpd_nm_13() {
		return inpd_nm_13;
	}
	public void setInpd_nm_13(String inpd_nm_13) {
		this.inpd_nm_13 = inpd_nm_13;
	}
	public String getPdc_nm_13() {
		return pdc_nm_13;
	}
	public void setPdc_nm_13(String pdc_nm_13) {
		this.pdc_nm_13 = pdc_nm_13;
	}
	public String getVtm_nm_13() {
		return vtm_nm_13;
	}
	public void setVtm_nm_13(String vtm_nm_13) {
		this.vtm_nm_13 = vtm_nm_13;
	}
	public String getAccd_dttm_13() {
		return accd_dttm_13;
	}
	public void setAccd_dttm_13(String accd_dttm_13) {
		this.accd_dttm_13 = accd_dttm_13;
	}
	public String getAccd_rpt_no_14() {
		return accd_rpt_no_14;
	}
	public void setAccd_rpt_no_14(String accd_rpt_no_14) {
		this.accd_rpt_no_14 = accd_rpt_no_14;
	}
	public String getAccd_oj_dvn_14() {
		return accd_oj_dvn_14;
	}
	public void setAccd_oj_dvn_14(String accd_oj_dvn_14) {
		this.accd_oj_dvn_14 = accd_oj_dvn_14;
	}
	public String getAccd_oj_sqno_14() {
		return accd_oj_sqno_14;
	}
	public void setAccd_oj_sqno_14(String accd_oj_sqno_14) {
		this.accd_oj_sqno_14 = accd_oj_sqno_14;
	}
	public String getInpd_nm_14() {
		return inpd_nm_14;
	}
	public void setInpd_nm_14(String inpd_nm_14) {
		this.inpd_nm_14 = inpd_nm_14;
	}
	public String getPdc_nm_14() {
		return pdc_nm_14;
	}
	public void setPdc_nm_14(String pdc_nm_14) {
		this.pdc_nm_14 = pdc_nm_14;
	}
	public String getVtm_nm_14() {
		return vtm_nm_14;
	}
	public void setVtm_nm_14(String vtm_nm_14) {
		this.vtm_nm_14 = vtm_nm_14;
	}
	public String getAccd_dttm_14() {
		return accd_dttm_14;
	}
	public void setAccd_dttm_14(String accd_dttm_14) {
		this.accd_dttm_14 = accd_dttm_14;
	}
	public String getAccd_rpt_no_15() {
		return accd_rpt_no_15;
	}
	public void setAccd_rpt_no_15(String accd_rpt_no_15) {
		this.accd_rpt_no_15 = accd_rpt_no_15;
	}
	public String getAccd_oj_dvn_15() {
		return accd_oj_dvn_15;
	}
	public void setAccd_oj_dvn_15(String accd_oj_dvn_15) {
		this.accd_oj_dvn_15 = accd_oj_dvn_15;
	}
	public String getAccd_oj_sqno_15() {
		return accd_oj_sqno_15;
	}
	public void setAccd_oj_sqno_15(String accd_oj_sqno_15) {
		this.accd_oj_sqno_15 = accd_oj_sqno_15;
	}
	public String getInpd_nm_15() {
		return inpd_nm_15;
	}
	public void setInpd_nm_15(String inpd_nm_15) {
		this.inpd_nm_15 = inpd_nm_15;
	}
	public String getPdc_nm_15() {
		return pdc_nm_15;
	}
	public void setPdc_nm_15(String pdc_nm_15) {
		this.pdc_nm_15 = pdc_nm_15;
	}
	public String getVtm_nm_15() {
		return vtm_nm_15;
	}
	public void setVtm_nm_15(String vtm_nm_15) {
		this.vtm_nm_15 = vtm_nm_15;
	}
	public String getAccd_dttm_15() {
		return accd_dttm_15;
	}
	public void setAccd_dttm_15(String accd_dttm_15) {
		this.accd_dttm_15 = accd_dttm_15;
	}
	public String getAccd_rpt_no_16() {
		return accd_rpt_no_16;
	}
	public void setAccd_rpt_no_16(String accd_rpt_no_16) {
		this.accd_rpt_no_16 = accd_rpt_no_16;
	}
	public String getAccd_oj_dvn_16() {
		return accd_oj_dvn_16;
	}
	public void setAccd_oj_dvn_16(String accd_oj_dvn_16) {
		this.accd_oj_dvn_16 = accd_oj_dvn_16;
	}
	public String getAccd_oj_sqno_16() {
		return accd_oj_sqno_16;
	}
	public void setAccd_oj_sqno_16(String accd_oj_sqno_16) {
		this.accd_oj_sqno_16 = accd_oj_sqno_16;
	}
	public String getInpd_nm_16() {
		return inpd_nm_16;
	}
	public void setInpd_nm_16(String inpd_nm_16) {
		this.inpd_nm_16 = inpd_nm_16;
	}
	public String getPdc_nm_16() {
		return pdc_nm_16;
	}
	public void setPdc_nm_16(String pdc_nm_16) {
		this.pdc_nm_16 = pdc_nm_16;
	}
	public String getVtm_nm_16() {
		return vtm_nm_16;
	}
	public void setVtm_nm_16(String vtm_nm_16) {
		this.vtm_nm_16 = vtm_nm_16;
	}
	public String getAccd_dttm_16() {
		return accd_dttm_16;
	}
	public void setAccd_dttm_16(String accd_dttm_16) {
		this.accd_dttm_16 = accd_dttm_16;
	}
	public String getAccd_rpt_no_17() {
		return accd_rpt_no_17;
	}
	public void setAccd_rpt_no_17(String accd_rpt_no_17) {
		this.accd_rpt_no_17 = accd_rpt_no_17;
	}
	public String getAccd_oj_dvn_17() {
		return accd_oj_dvn_17;
	}
	public void setAccd_oj_dvn_17(String accd_oj_dvn_17) {
		this.accd_oj_dvn_17 = accd_oj_dvn_17;
	}
	public String getAccd_oj_sqno_17() {
		return accd_oj_sqno_17;
	}
	public void setAccd_oj_sqno_17(String accd_oj_sqno_17) {
		this.accd_oj_sqno_17 = accd_oj_sqno_17;
	}
	public String getInpd_nm_17() {
		return inpd_nm_17;
	}
	public void setInpd_nm_17(String inpd_nm_17) {
		this.inpd_nm_17 = inpd_nm_17;
	}
	public String getPdc_nm_17() {
		return pdc_nm_17;
	}
	public void setPdc_nm_17(String pdc_nm_17) {
		this.pdc_nm_17 = pdc_nm_17;
	}
	public String getVtm_nm_17() {
		return vtm_nm_17;
	}
	public void setVtm_nm_17(String vtm_nm_17) {
		this.vtm_nm_17 = vtm_nm_17;
	}
	public String getAccd_dttm_17() {
		return accd_dttm_17;
	}
	public void setAccd_dttm_17(String accd_dttm_17) {
		this.accd_dttm_17 = accd_dttm_17;
	}
	public String getAccd_rpt_no_18() {
		return accd_rpt_no_18;
	}
	public void setAccd_rpt_no_18(String accd_rpt_no_18) {
		this.accd_rpt_no_18 = accd_rpt_no_18;
	}
	public String getAccd_oj_dvn_18() {
		return accd_oj_dvn_18;
	}
	public void setAccd_oj_dvn_18(String accd_oj_dvn_18) {
		this.accd_oj_dvn_18 = accd_oj_dvn_18;
	}
	public String getAccd_oj_sqno_18() {
		return accd_oj_sqno_18;
	}
	public void setAccd_oj_sqno_18(String accd_oj_sqno_18) {
		this.accd_oj_sqno_18 = accd_oj_sqno_18;
	}
	public String getInpd_nm_18() {
		return inpd_nm_18;
	}
	public void setInpd_nm_18(String inpd_nm_18) {
		this.inpd_nm_18 = inpd_nm_18;
	}
	public String getPdc_nm_18() {
		return pdc_nm_18;
	}
	public void setPdc_nm_18(String pdc_nm_18) {
		this.pdc_nm_18 = pdc_nm_18;
	}
	public String getVtm_nm_18() {
		return vtm_nm_18;
	}
	public void setVtm_nm_18(String vtm_nm_18) {
		this.vtm_nm_18 = vtm_nm_18;
	}
	public String getAccd_dttm_18() {
		return accd_dttm_18;
	}
	public void setAccd_dttm_18(String accd_dttm_18) {
		this.accd_dttm_18 = accd_dttm_18;
	}
	public String getAccd_rpt_no_19() {
		return accd_rpt_no_19;
	}
	public void setAccd_rpt_no_19(String accd_rpt_no_19) {
		this.accd_rpt_no_19 = accd_rpt_no_19;
	}
	public String getAccd_oj_dvn_19() {
		return accd_oj_dvn_19;
	}
	public void setAccd_oj_dvn_19(String accd_oj_dvn_19) {
		this.accd_oj_dvn_19 = accd_oj_dvn_19;
	}
	public String getAccd_oj_sqno_19() {
		return accd_oj_sqno_19;
	}
	public void setAccd_oj_sqno_19(String accd_oj_sqno_19) {
		this.accd_oj_sqno_19 = accd_oj_sqno_19;
	}
	public String getInpd_nm_19() {
		return inpd_nm_19;
	}
	public void setInpd_nm_19(String inpd_nm_19) {
		this.inpd_nm_19 = inpd_nm_19;
	}
	public String getPdc_nm_19() {
		return pdc_nm_19;
	}
	public void setPdc_nm_19(String pdc_nm_19) {
		this.pdc_nm_19 = pdc_nm_19;
	}
	public String getVtm_nm_19() {
		return vtm_nm_19;
	}
	public void setVtm_nm_19(String vtm_nm_19) {
		this.vtm_nm_19 = vtm_nm_19;
	}
	public String getAccd_dttm_19() {
		return accd_dttm_19;
	}
	public void setAccd_dttm_19(String accd_dttm_19) {
		this.accd_dttm_19 = accd_dttm_19;
	}
	public String getAccd_rpt_no_20() {
		return accd_rpt_no_20;
	}
	public void setAccd_rpt_no_20(String accd_rpt_no_20) {
		this.accd_rpt_no_20 = accd_rpt_no_20;
	}
	public String getAccd_oj_dvn_20() {
		return accd_oj_dvn_20;
	}
	public void setAccd_oj_dvn_20(String accd_oj_dvn_20) {
		this.accd_oj_dvn_20 = accd_oj_dvn_20;
	}
	public String getAccd_oj_sqno_20() {
		return accd_oj_sqno_20;
	}
	public void setAccd_oj_sqno_20(String accd_oj_sqno_20) {
		this.accd_oj_sqno_20 = accd_oj_sqno_20;
	}
	public String getInpd_nm_20() {
		return inpd_nm_20;
	}
	public void setInpd_nm_20(String inpd_nm_20) {
		this.inpd_nm_20 = inpd_nm_20;
	}
	public String getPdc_nm_20() {
		return pdc_nm_20;
	}
	public void setPdc_nm_20(String pdc_nm_20) {
		this.pdc_nm_20 = pdc_nm_20;
	}
	public String getVtm_nm_20() {
		return vtm_nm_20;
	}
	public void setVtm_nm_20(String vtm_nm_20) {
		this.vtm_nm_20 = vtm_nm_20;
	}
	public String getAccd_dttm_20() {
		return accd_dttm_20;
	}
	public void setAccd_dttm_20(String accd_dttm_20) {
		this.accd_dttm_20 = accd_dttm_20;
	}
	public String getAccd_rpt_no_21() {
		return accd_rpt_no_21;
	}
	public void setAccd_rpt_no_21(String accd_rpt_no_21) {
		this.accd_rpt_no_21 = accd_rpt_no_21;
	}
	public String getAccd_oj_dvn_21() {
		return accd_oj_dvn_21;
	}
	public void setAccd_oj_dvn_21(String accd_oj_dvn_21) {
		this.accd_oj_dvn_21 = accd_oj_dvn_21;
	}
	public String getAccd_oj_sqno_21() {
		return accd_oj_sqno_21;
	}
	public void setAccd_oj_sqno_21(String accd_oj_sqno_21) {
		this.accd_oj_sqno_21 = accd_oj_sqno_21;
	}
	public String getInpd_nm_21() {
		return inpd_nm_21;
	}
	public void setInpd_nm_21(String inpd_nm_21) {
		this.inpd_nm_21 = inpd_nm_21;
	}
	public String getPdc_nm_21() {
		return pdc_nm_21;
	}
	public void setPdc_nm_21(String pdc_nm_21) {
		this.pdc_nm_21 = pdc_nm_21;
	}
	public String getVtm_nm_21() {
		return vtm_nm_21;
	}
	public void setVtm_nm_21(String vtm_nm_21) {
		this.vtm_nm_21 = vtm_nm_21;
	}
	public String getAccd_dttm_21() {
		return accd_dttm_21;
	}
	public void setAccd_dttm_21(String accd_dttm_21) {
		this.accd_dttm_21 = accd_dttm_21;
	}
	public String getAccd_rpt_no_22() {
		return accd_rpt_no_22;
	}
	public void setAccd_rpt_no_22(String accd_rpt_no_22) {
		this.accd_rpt_no_22 = accd_rpt_no_22;
	}
	public String getAccd_oj_dvn_22() {
		return accd_oj_dvn_22;
	}
	public void setAccd_oj_dvn_22(String accd_oj_dvn_22) {
		this.accd_oj_dvn_22 = accd_oj_dvn_22;
	}
	public String getAccd_oj_sqno_22() {
		return accd_oj_sqno_22;
	}
	public void setAccd_oj_sqno_22(String accd_oj_sqno_22) {
		this.accd_oj_sqno_22 = accd_oj_sqno_22;
	}
	public String getInpd_nm_22() {
		return inpd_nm_22;
	}
	public void setInpd_nm_22(String inpd_nm_22) {
		this.inpd_nm_22 = inpd_nm_22;
	}
	public String getPdc_nm_22() {
		return pdc_nm_22;
	}
	public void setPdc_nm_22(String pdc_nm_22) {
		this.pdc_nm_22 = pdc_nm_22;
	}
	public String getVtm_nm_22() {
		return vtm_nm_22;
	}
	public void setVtm_nm_22(String vtm_nm_22) {
		this.vtm_nm_22 = vtm_nm_22;
	}
	public String getAccd_dttm_22() {
		return accd_dttm_22;
	}
	public void setAccd_dttm_22(String accd_dttm_22) {
		this.accd_dttm_22 = accd_dttm_22;
	}
	public String getAccd_rpt_no_23() {
		return accd_rpt_no_23;
	}
	public void setAccd_rpt_no_23(String accd_rpt_no_23) {
		this.accd_rpt_no_23 = accd_rpt_no_23;
	}
	public String getAccd_oj_dvn_23() {
		return accd_oj_dvn_23;
	}
	public void setAccd_oj_dvn_23(String accd_oj_dvn_23) {
		this.accd_oj_dvn_23 = accd_oj_dvn_23;
	}
	public String getAccd_oj_sqno_23() {
		return accd_oj_sqno_23;
	}
	public void setAccd_oj_sqno_23(String accd_oj_sqno_23) {
		this.accd_oj_sqno_23 = accd_oj_sqno_23;
	}
	public String getInpd_nm_23() {
		return inpd_nm_23;
	}
	public void setInpd_nm_23(String inpd_nm_23) {
		this.inpd_nm_23 = inpd_nm_23;
	}
	public String getPdc_nm_23() {
		return pdc_nm_23;
	}
	public void setPdc_nm_23(String pdc_nm_23) {
		this.pdc_nm_23 = pdc_nm_23;
	}
	public String getVtm_nm_23() {
		return vtm_nm_23;
	}
	public void setVtm_nm_23(String vtm_nm_23) {
		this.vtm_nm_23 = vtm_nm_23;
	}
	public String getAccd_dttm_23() {
		return accd_dttm_23;
	}
	public void setAccd_dttm_23(String accd_dttm_23) {
		this.accd_dttm_23 = accd_dttm_23;
	}
	public String getAccd_rpt_no_24() {
		return accd_rpt_no_24;
	}
	public void setAccd_rpt_no_24(String accd_rpt_no_24) {
		this.accd_rpt_no_24 = accd_rpt_no_24;
	}
	public String getAccd_oj_dvn_24() {
		return accd_oj_dvn_24;
	}
	public void setAccd_oj_dvn_24(String accd_oj_dvn_24) {
		this.accd_oj_dvn_24 = accd_oj_dvn_24;
	}
	public String getAccd_oj_sqno_24() {
		return accd_oj_sqno_24;
	}
	public void setAccd_oj_sqno_24(String accd_oj_sqno_24) {
		this.accd_oj_sqno_24 = accd_oj_sqno_24;
	}
	public String getInpd_nm_24() {
		return inpd_nm_24;
	}
	public void setInpd_nm_24(String inpd_nm_24) {
		this.inpd_nm_24 = inpd_nm_24;
	}
	public String getPdc_nm_24() {
		return pdc_nm_24;
	}
	public void setPdc_nm_24(String pdc_nm_24) {
		this.pdc_nm_24 = pdc_nm_24;
	}
	public String getVtm_nm_24() {
		return vtm_nm_24;
	}
	public void setVtm_nm_24(String vtm_nm_24) {
		this.vtm_nm_24 = vtm_nm_24;
	}
	public String getAccd_dttm_24() {
		return accd_dttm_24;
	}
	public void setAccd_dttm_24(String accd_dttm_24) {
		this.accd_dttm_24 = accd_dttm_24;
	}
	public String getAccd_rpt_no_25() {
		return accd_rpt_no_25;
	}
	public void setAccd_rpt_no_25(String accd_rpt_no_25) {
		this.accd_rpt_no_25 = accd_rpt_no_25;
	}
	public String getAccd_oj_dvn_25() {
		return accd_oj_dvn_25;
	}
	public void setAccd_oj_dvn_25(String accd_oj_dvn_25) {
		this.accd_oj_dvn_25 = accd_oj_dvn_25;
	}
	public String getAccd_oj_sqno_25() {
		return accd_oj_sqno_25;
	}
	public void setAccd_oj_sqno_25(String accd_oj_sqno_25) {
		this.accd_oj_sqno_25 = accd_oj_sqno_25;
	}
	public String getInpd_nm_25() {
		return inpd_nm_25;
	}
	public void setInpd_nm_25(String inpd_nm_25) {
		this.inpd_nm_25 = inpd_nm_25;
	}
	public String getPdc_nm_25() {
		return pdc_nm_25;
	}
	public void setPdc_nm_25(String pdc_nm_25) {
		this.pdc_nm_25 = pdc_nm_25;
	}
	public String getVtm_nm_25() {
		return vtm_nm_25;
	}
	public void setVtm_nm_25(String vtm_nm_25) {
		this.vtm_nm_25 = vtm_nm_25;
	}
	public String getAccd_dttm_25() {
		return accd_dttm_25;
	}
	public void setAccd_dttm_25(String accd_dttm_25) {
		this.accd_dttm_25 = accd_dttm_25;
	}
	public String getAccd_rpt_no_26() {
		return accd_rpt_no_26;
	}
	public void setAccd_rpt_no_26(String accd_rpt_no_26) {
		this.accd_rpt_no_26 = accd_rpt_no_26;
	}
	public String getAccd_oj_dvn_26() {
		return accd_oj_dvn_26;
	}
	public void setAccd_oj_dvn_26(String accd_oj_dvn_26) {
		this.accd_oj_dvn_26 = accd_oj_dvn_26;
	}
	public String getAccd_oj_sqno_26() {
		return accd_oj_sqno_26;
	}
	public void setAccd_oj_sqno_26(String accd_oj_sqno_26) {
		this.accd_oj_sqno_26 = accd_oj_sqno_26;
	}
	public String getInpd_nm_26() {
		return inpd_nm_26;
	}
	public void setInpd_nm_26(String inpd_nm_26) {
		this.inpd_nm_26 = inpd_nm_26;
	}
	public String getPdc_nm_26() {
		return pdc_nm_26;
	}
	public void setPdc_nm_26(String pdc_nm_26) {
		this.pdc_nm_26 = pdc_nm_26;
	}
	public String getVtm_nm_26() {
		return vtm_nm_26;
	}
	public void setVtm_nm_26(String vtm_nm_26) {
		this.vtm_nm_26 = vtm_nm_26;
	}
	public String getAccd_dttm_26() {
		return accd_dttm_26;
	}
	public void setAccd_dttm_26(String accd_dttm_26) {
		this.accd_dttm_26 = accd_dttm_26;
	}
	public String getAccd_rpt_no_27() {
		return accd_rpt_no_27;
	}
	public void setAccd_rpt_no_27(String accd_rpt_no_27) {
		this.accd_rpt_no_27 = accd_rpt_no_27;
	}
	public String getAccd_oj_dvn_27() {
		return accd_oj_dvn_27;
	}
	public void setAccd_oj_dvn_27(String accd_oj_dvn_27) {
		this.accd_oj_dvn_27 = accd_oj_dvn_27;
	}
	public String getAccd_oj_sqno_27() {
		return accd_oj_sqno_27;
	}
	public void setAccd_oj_sqno_27(String accd_oj_sqno_27) {
		this.accd_oj_sqno_27 = accd_oj_sqno_27;
	}
	public String getInpd_nm_27() {
		return inpd_nm_27;
	}
	public void setInpd_nm_27(String inpd_nm_27) {
		this.inpd_nm_27 = inpd_nm_27;
	}
	public String getPdc_nm_27() {
		return pdc_nm_27;
	}
	public void setPdc_nm_27(String pdc_nm_27) {
		this.pdc_nm_27 = pdc_nm_27;
	}
	public String getVtm_nm_27() {
		return vtm_nm_27;
	}
	public void setVtm_nm_27(String vtm_nm_27) {
		this.vtm_nm_27 = vtm_nm_27;
	}
	public String getAccd_dttm_27() {
		return accd_dttm_27;
	}
	public void setAccd_dttm_27(String accd_dttm_27) {
		this.accd_dttm_27 = accd_dttm_27;
	}
	public String getAccd_rpt_no_28() {
		return accd_rpt_no_28;
	}
	public void setAccd_rpt_no_28(String accd_rpt_no_28) {
		this.accd_rpt_no_28 = accd_rpt_no_28;
	}
	public String getAccd_oj_dvn_28() {
		return accd_oj_dvn_28;
	}
	public void setAccd_oj_dvn_28(String accd_oj_dvn_28) {
		this.accd_oj_dvn_28 = accd_oj_dvn_28;
	}
	public String getAccd_oj_sqno_28() {
		return accd_oj_sqno_28;
	}
	public void setAccd_oj_sqno_28(String accd_oj_sqno_28) {
		this.accd_oj_sqno_28 = accd_oj_sqno_28;
	}
	public String getInpd_nm_28() {
		return inpd_nm_28;
	}
	public void setInpd_nm_28(String inpd_nm_28) {
		this.inpd_nm_28 = inpd_nm_28;
	}
	public String getPdc_nm_28() {
		return pdc_nm_28;
	}
	public void setPdc_nm_28(String pdc_nm_28) {
		this.pdc_nm_28 = pdc_nm_28;
	}
	public String getVtm_nm_28() {
		return vtm_nm_28;
	}
	public void setVtm_nm_28(String vtm_nm_28) {
		this.vtm_nm_28 = vtm_nm_28;
	}
	public String getAccd_dttm_28() {
		return accd_dttm_28;
	}
	public void setAccd_dttm_28(String accd_dttm_28) {
		this.accd_dttm_28 = accd_dttm_28;
	}
	public String getAccd_rpt_no_29() {
		return accd_rpt_no_29;
	}
	public void setAccd_rpt_no_29(String accd_rpt_no_29) {
		this.accd_rpt_no_29 = accd_rpt_no_29;
	}
	public String getAccd_oj_dvn_29() {
		return accd_oj_dvn_29;
	}
	public void setAccd_oj_dvn_29(String accd_oj_dvn_29) {
		this.accd_oj_dvn_29 = accd_oj_dvn_29;
	}
	public String getAccd_oj_sqno_29() {
		return accd_oj_sqno_29;
	}
	public void setAccd_oj_sqno_29(String accd_oj_sqno_29) {
		this.accd_oj_sqno_29 = accd_oj_sqno_29;
	}
	public String getInpd_nm_29() {
		return inpd_nm_29;
	}
	public void setInpd_nm_29(String inpd_nm_29) {
		this.inpd_nm_29 = inpd_nm_29;
	}
	public String getPdc_nm_29() {
		return pdc_nm_29;
	}
	public void setPdc_nm_29(String pdc_nm_29) {
		this.pdc_nm_29 = pdc_nm_29;
	}
	public String getVtm_nm_29() {
		return vtm_nm_29;
	}
	public void setVtm_nm_29(String vtm_nm_29) {
		this.vtm_nm_29 = vtm_nm_29;
	}
	public String getAccd_dttm_29() {
		return accd_dttm_29;
	}
	public void setAccd_dttm_29(String accd_dttm_29) {
		this.accd_dttm_29 = accd_dttm_29;
	}
	public String getAccd_rpt_no_30() {
		return accd_rpt_no_30;
	}
	public void setAccd_rpt_no_30(String accd_rpt_no_30) {
		this.accd_rpt_no_30 = accd_rpt_no_30;
	}
	public String getAccd_oj_dvn_30() {
		return accd_oj_dvn_30;
	}
	public void setAccd_oj_dvn_30(String accd_oj_dvn_30) {
		this.accd_oj_dvn_30 = accd_oj_dvn_30;
	}
	public String getAccd_oj_sqno_30() {
		return accd_oj_sqno_30;
	}
	public void setAccd_oj_sqno_30(String accd_oj_sqno_30) {
		this.accd_oj_sqno_30 = accd_oj_sqno_30;
	}
	public String getInpd_nm_30() {
		return inpd_nm_30;
	}
	public void setInpd_nm_30(String inpd_nm_30) {
		this.inpd_nm_30 = inpd_nm_30;
	}
	public String getPdc_nm_30() {
		return pdc_nm_30;
	}
	public void setPdc_nm_30(String pdc_nm_30) {
		this.pdc_nm_30 = pdc_nm_30;
	}
	public String getVtm_nm_30() {
		return vtm_nm_30;
	}
	public void setVtm_nm_30(String vtm_nm_30) {
		this.vtm_nm_30 = vtm_nm_30;
	}
	public String getAccd_dttm_30() {
		return accd_dttm_30;
	}
	public void setAccd_dttm_30(String accd_dttm_30) {
		this.accd_dttm_30 = accd_dttm_30;
	}
	public String getHdlr_empno() {
		return hdlr_empno;
	}
	public void setHdlr_empno(String hdlr_empno) {
		this.hdlr_empno = hdlr_empno;
	}
}
