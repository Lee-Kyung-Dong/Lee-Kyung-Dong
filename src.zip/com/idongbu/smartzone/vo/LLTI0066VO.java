package com.idongbu.smartzone.vo;

import java.util.List;
import java.util.Map;

import com.idongbu.common.vo.CMMVO;

public class LLTI0066VO extends CMMVO{

	//전문필드
	public String cust_nm = "";  //[O] 고객명 HJ_P_GOGEK_NAME 고객명
	public String rrno = "";  //[I] 주민등록번호 JJ_P_JUMIN_NO 주민번호
	public String[] pym_if__plno = new String[0];  //[O] 납입정보_증권번호 JJ_P_POLI_NO_O 증권번호
	public String[] pym_if__pdc_cd = new String[0];  //[O] 납입정보_상품코드  
	public String[] pym_if__pym_prm = new String[0];  //[O] 납입정보_납입보험료 JJ_P_NAPIP_PRM_O 납입보험료
	public String[] pym_if__nstl_mtd_cd_nm = new String[0];  //[O] 납입정보_분납방법코드명 HJ_P_BUN_NAME_O 분납방법코드명
	public String[] pym_if__apl_ymd = new String[0];  //[O] 납입정보_청약년월일 JJ_P_GYEYAK_YMD_O 청약년월일
	public String[] pym_if__arc_trm_et_dt = new String[0];  //[O] 납입정보_보험기간종기일자 JJ_P_GYEYAK_EYMD_O 청약사원
	public String[] pym_if__arc_ctc_ln_amt = new String[0];  //[O] 납입정보_보험계약대출금액 JJ_P_YAKGWAN_GM_O 약관대출금합계
	public String[] pym_if__fnal_pym_yr = new String[0];  //[O] 납입정보_최종납입년도 JJ_P_LAST_NAP_Y_O 최종납입년도
	public String[] pym_if__fnal_pym_mon = new String[0];  //[O] 납입정보_최종납입월 JJ_P_LAST_NAP_M_O 최종납입월도
	public String[] pym_if__cltd_dt = new String[0];  //[O] 납입정보_영수일자 JJ_P_NAPIP_YMD_O 영수일자
	public String[] pym_if__inpl_ln_dt = new String[0];  //[O] 납입정보_약관대출일자 JJ_P_DECHUL_YMD_O 약관대출일자
	public String pym_prm_sm = "";  //[O] 납입보험료합계 JJ_P_HAP_NAPIP_PRM 납입보험료합계
	public String inpl_ln_amt_sm = "";  //[O] 약관대출금액합계 JJ_P_HAP_YAKGWAN_GM 약관대출금합계
	public String ise_dt = "";  //[O] 발행일자 JJ_BAL_YMD 
	
	
	public String getCust_nm() {
		return cust_nm;
	}
	public void setCust_nm(String cust_nm) {
		this.cust_nm = cust_nm;
	}
	public String getRrno() {
		return rrno;
	}
	public void setRrno(String rrno) {
		this.rrno = rrno;
	}
	public String[] getPym_if__plno() {
		return pym_if__plno;
	}
	public void setPym_if__plno(String[] pym_if__plno) {
		this.pym_if__plno = pym_if__plno;
	}
	public String[] getPym_if__pdc_cd() {
		return pym_if__pdc_cd;
	}
	public void setPym_if__pdc_cd(String[] pym_if__pdc_cd) {
		this.pym_if__pdc_cd = pym_if__pdc_cd;
	}
	public String[] getPym_if__pym_prm() {
		return pym_if__pym_prm;
	}
	public void setPym_if__pym_prm(String[] pym_if__pym_prm) {
		this.pym_if__pym_prm = pym_if__pym_prm;
	}
	public String[] getPym_if__nstl_mtd_cd_nm() {
		return pym_if__nstl_mtd_cd_nm;
	}
	public void setPym_if__nstl_mtd_cd_nm(String[] pym_if__nstl_mtd_cd_nm) {
		this.pym_if__nstl_mtd_cd_nm = pym_if__nstl_mtd_cd_nm;
	}
	public String[] getPym_if__apl_ymd() {
		return pym_if__apl_ymd;
	}
	public void setPym_if__apl_ymd(String[] pym_if__apl_ymd) {
		this.pym_if__apl_ymd = pym_if__apl_ymd;
	}
	public String[] getPym_if__arc_trm_et_dt() {
		return pym_if__arc_trm_et_dt;
	}
	public void setPym_if__arc_trm_et_dt(String[] pym_if__arc_trm_et_dt) {
		this.pym_if__arc_trm_et_dt = pym_if__arc_trm_et_dt;
	}
	public String[] getPym_if__arc_ctc_ln_amt() {
		return pym_if__arc_ctc_ln_amt;
	}
	public void setPym_if__arc_ctc_ln_amt(String[] pym_if__arc_ctc_ln_amt) {
		this.pym_if__arc_ctc_ln_amt = pym_if__arc_ctc_ln_amt;
	}
	public String[] getPym_if__fnal_pym_yr() {
		return pym_if__fnal_pym_yr;
	}
	public void setPym_if__fnal_pym_yr(String[] pym_if__fnal_pym_yr) {
		this.pym_if__fnal_pym_yr = pym_if__fnal_pym_yr;
	}
	public String[] getPym_if__fnal_pym_mon() {
		return pym_if__fnal_pym_mon;
	}
	public void setPym_if__fnal_pym_mon(String[] pym_if__fnal_pym_mon) {
		this.pym_if__fnal_pym_mon = pym_if__fnal_pym_mon;
	}
	public String[] getPym_if__cltd_dt() {
		return pym_if__cltd_dt;
	}
	public void setPym_if__cltd_dt(String[] pym_if__cltd_dt) {
		this.pym_if__cltd_dt = pym_if__cltd_dt;
	}
	public String[] getPym_if__inpl_ln_dt() {
		return pym_if__inpl_ln_dt;
	}
	public void setPym_if__inpl_ln_dt(String[] pym_if__inpl_ln_dt) {
		this.pym_if__inpl_ln_dt = pym_if__inpl_ln_dt;
	}
	public String getPym_prm_sm() {
		return pym_prm_sm;
	}
	public void setPym_prm_sm(String pym_prm_sm) {
		this.pym_prm_sm = pym_prm_sm;
	}
	public String getInpl_ln_amt_sm() {
		return inpl_ln_amt_sm;
	}
	public void setInpl_ln_amt_sm(String inpl_ln_amt_sm) {
		this.inpl_ln_amt_sm = inpl_ln_amt_sm;
	}
	public String getIse_dt() {
		return ise_dt;
	}
	public void setIse_dt(String ise_dt) {
		this.ise_dt = ise_dt;
	}
	
	
}
