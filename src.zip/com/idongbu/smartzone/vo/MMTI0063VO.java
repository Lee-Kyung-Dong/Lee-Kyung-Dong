package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class MMTI0063VO extends CMMVO{
	//전문필드
		public String proc_dvn = "";  //[I/O] 처리구분  
		public String funt_key = "";  //[I/O] 기능키  
		public String vh_no = "";  //[I/O] 차량번호 H_SCR_MOKJUK_CD 차량번호
		public String cust_dvn_1 = "";  //[I/O] 고객구분1 SCR_PIB_GYE_NO_GB 고객구분1
		public String cust_no_dvn = "";  //[I/O] 고객번호구분 SCR_GOGEK_NO_GB 고객번호구분
		public String cust_no_mngt_no = "";  //[I/O] 고객번호관리번호 SCR_GOGEK_NO 고객번호(관리번호)
		public String insu_cd = "";  //[I/O] 보험자코드 SCR_BOHUMJA_CD 보험자코드
		public String plno = "";  //[I/O] 증권번호 SCR_POLI_NO 증권번호
		public String inpd_cd = "";  //[I/O] 보종코드  
		public String cust_dvn_2 = "";  //[I/O] 고객구분2 SCR_PIB_GYE_NM_GB 고객구분2
		public String ins_nm = "";  //[I/O] 피보험자명 H_SCR_GOGEK_NAME 피보험자명
		public String orc_otcm_dvn = "";  //[I/O] 당사타사구분 SCR_DANGSA_GB 당사타사구분
		public String prn_scy_dvn = "";  //[I/O] 개인단체구분 SCR_GAEIN_GB 개인단체구분
		public String bith_yre_pd = "";  //[I/O] 출생연도시기 SCR_CHUL_SYMD 출생연도FROM
		public String bith_yre_et = "";  //[I/O] 출생연도종기 SCR_CHUL_EYMD 출생연도TO
		public String ormm_cd = "";  //[I/O] 조직원코드 SCR_JOJIKWON_CD 조직원코드
		public String ormm_nm = "";  //[O] 조직원명 H_SCR_JOJIKWON_NM 조직원명
		public String recp_knd_cd = "";  //[I/O] 영수증종류코드 SCR_YUNGSU_JONGRYU_CD 영수증종류코드
		public String recp_no = "";  //[I/O] 영수증번호 SCR_YUNGSUJNG_NO 영수증번호
		public String cbdy_no_dvn = "";  //[I/O] 차대번호구분 SCR_CHADE_NO_GB 차대번호구분
		public String cbdy_no = "";  //[I/O] 차대번호 SCR_CHADE_NO 차대번호구분
		public String bse_dd = "";  //[I/O] 기준일 SCR_GIJUN_YMD 기준일
		public String bz_dvn = "";  //[I/O] 업무구분 SCR_UPMU_GB 업무구분
		public String clp_1 = "";  //[I/O] 휴대폰1 SCR_HP_N01 핸드폰1
		public String clp_2 = "";  //[I/O] 휴대폰2 SCR_HP_N02 핸드폰2
		public String clp_3 = "";  //[I/O] 휴대폰3 SCR_HP_N03 핸드폰3
		public String clp_rsdn_no = "";  //[I/O] 휴대폰주민번호 SCR_JUMIN_NO 핸드폰주민번호
		public String dvn = "";  //[I/O] 구분 SCR_GUBUN 구분
		public String[] ctc_det_srch_mngt_ctc_mtt__slc = new String[0];  //[O] 계약명세조회관리_계약사항_선택 SCR_OC_SELECT_GB 선택
		public String[] ctc_det_srch_mngt_ctc_mtt__ins_nm_arrm = new String[0];  //[O] 계약명세조회관리_계약사항_피보험자명배열 H_SCR_OC_P_GOGEK_NAME 피보험자명
		public String[] ctc_det_srch_mngt_ctc_mtt__ins_dvcd_mngt_no = new String[0];  //[O] 계약명세조회관리_계약사항_피보험자구분코드관리번호 SCR_OC_P_GOGEK_NO_GB 피보험자구분코드(관리번호)
		public String[] ctc_det_srch_mngt_ctc_mtt__ins_cd_mngt_no = new String[0];  //[O] 계약명세조회관리_계약사항_피보험자코드관리번호 SCR_OC_P_GOGEK_NO 피보험자코드(관리번호)
		public String[] ctc_det_srch_mngt_ctc_mtt__plhd_nm = new String[0];  //[O] 계약명세조회관리_계약사항_계약자명 H_SCR_OC_G_GOGEK_NAME 계약자명
		public String[] ctc_det_srch_mngt_ctc_mtt__plhd_dvcd_mngt_no = new String[0];  //[O] 계약명세조회관리_계약사항_계약자구분코드관리번호 SCR_OC_G_GOGEK_NO_GB 계약자구분코드(관리번호)
		public String[] ctc_det_srch_mngt_ctc_mtt__plhd_cd_mngt_no = new String[0];  //[O] 계약명세조회관리_계약사항_계약자코드관리번호 SCR_OC_G_GOGEK_NO 계약자코드(관리번호)
		public String[] ctc_det_srch_mngt_ctc_mtt__vh_no_arrm = new String[0];  //[O] 계약명세조회관리_계약사항_차량번호배열 H_SCR_OC_MOKJUK_CD 차량번호
		public String[] ctc_det_srch_mngt_ctc_mtt__ctp = new String[0];  //[O] 계약명세조회관리_계약사항_차종 H_SCR_OC_CHAJONG_CD 차종
		public String[] ctc_det_srch_mngt_ctc_mtt__arc_pd = new String[0];  //[O] 계약명세조회관리_계약사항_보험시기 SCR_OC_GIGAN_SYMD 보험시기
		public String[] ctc_det_srch_mngt_ctc_mtt__arc_et = new String[0];  //[O] 계약명세조회관리_계약사항_보험종기 SCR_OC_GIGAN_EYMD 보험종기
		public String[] ctc_det_srch_mngt_ctc_mtt__inpd = new String[0];  //[O] 계약명세조회관리_계약사항_보종 H_SCR_OC_BJ_CD 보종
		public String[] ctc_det_srch_mngt_ctc_mtt__insu_cd_arrm = new String[0];  //[O] 계약명세조회관리_계약사항_보험자코드배열 SCR_OC_BOHUMJA_CD 보험자코드
		public String[] ctc_det_srch_mngt_ctc_mtt__plno_arrm = new String[0];  //[O] 계약명세조회관리_계약사항_증권번호배열 SCR_OC_POLI_NO 증권번호
		public String[] ctc_det_srch_mngt_ctc_mtt__ctrmf_yn = new String[0];  //[O] 계약명세조회관리_계약사항_계약변경유무 H_SCR_OC_BESU_GB 배서유무
		public String[] ctc_det_srch_mngt_ctc_mtt__accd_yn = new String[0];  //[O] 계약명세조회관리_계약사항_사고유무 H_SCR_OC_SAGO_GB 사고유무
		public String[] ctc_det_srch_mngt_ctc_mtt__sbcp = new String[0];  //[O] 계약명세조회관리_계약사항_가입사 H_SCR_OC_BOHUMJA_CD 가입사
		public String[] ctc_det_srch_mngt_ctc_mtt__bh = new String[0];  //[O] 계약명세조회관리_계약사항_지점 H_SCR_OC_JIJUM_CD 지점
		public String[] ctc_det_srch_mngt_ctc_mtt__eny_carr_rt = new String[0];  //[O] 계약명세조회관리_계약사항_가입경력율 SCR_OC_GYUNGRUK_YUL 가입경력율
		public String[] ctc_det_srch_mngt_ctc_mtt__stdd_trt = new String[0];  //[O] 계약명세조회관리_계약사항_표준요율 SCR_OC_PYOJUN_YUL 표준요율
		public String[] ctc_det_srch_mngt_ctc_mtt__gr = new String[0];  //[O] 계약명세조회관리_계약사항_등급 SCR_OC_PYOJUN_DUNGGUP 등급
		public String[] ctc_det_srch_mngt_ctc_mtt__cust_no_bvan = new String[0];  //[O] 계약명세조회관리_계약사항_고객번호채번 SCR_OC_BUNGI_GOGEK_NO 고객번호(채번)
		public String[] ctc_det_srch_mngt_ctc_mtt__inpd_cd = new String[0];  //[O] 계약명세조회관리_계약사항_보종코드 SCR_OC_BUNGI_BJ_CD 보종코드
		public String[] ctc_det_srch_mngt_ctc_mtt__ocd = new String[0];  //[O] 계약명세조회관리_계약사항_관코드 SCR_OC_BUNGI_GWAN_CD 관코드
		public String[] ctc_det_srch_mngt_ctc_mtt__vh_no_cd = new String[0];  //[O] 계약명세조회관리_계약사항_차량번호코드 SCR_OC_BUNGI_MOKJUK_CD 차량번호(코드)
		public String[] ctc_det_srch_mngt_ctc_mtt__hd_trdr_dvn = new String[0];  //[O] 계약명세조회관리_계약사항_취급업자구분 SCR_OC_BUNGI_CHIGP_GB 취급업자구분
		public String[] ctc_det_srch_mngt_ctc_mtt__sme_ply_yn_clcnt = new String[0];  //[O] 계약명세조회관리_계약사항_동일증권여부콜센터 SCR_DONGIL_POLI_YN 동일증권여부(콜센터용)
		public String[] ctc_det_srch_mngt_ctc_mtt__crnm_clcnt = new String[0];  //[O] 계약명세조회관리_계약사항_차명콜센터 H_SCR_CAR_NAME 차명(콜센터용)
		public String eph_scrn = "";  //[O] 강조화면 SCR_BRIGHT_MAP FIELD BRIGHT MAP 
		public String eph_lcn = "";  //[O] 강조위치 SCR_BRIGHT_POS FIELD BRIGHT POSITION
		public String err_eph = "";  //[O] 에러강조 SCR_BRIGHT_FOS 
		public String[] ctc_det_srch_mngt_eph_nm__eph_nm = new String[0];  //[O] 계약명세조회관리_강조명_강조명 SCR_BRIGHT_NAME 
		public String getProc_dvn() {
			return proc_dvn;
		}
		public void setProc_dvn(String proc_dvn) {
			this.proc_dvn = proc_dvn;
		}
		public String getFunt_key() {
			return funt_key;
		}
		public void setFunt_key(String funt_key) {
			this.funt_key = funt_key;
		}
		public String getVh_no() {
			return vh_no;
		}
		public void setVh_no(String vh_no) {
			this.vh_no = vh_no;
		}
		public String getCust_dvn_1() {
			return cust_dvn_1;
		}
		public void setCust_dvn_1(String cust_dvn_1) {
			this.cust_dvn_1 = cust_dvn_1;
		}
		public String getCust_no_dvn() {
			return cust_no_dvn;
		}
		public void setCust_no_dvn(String cust_no_dvn) {
			this.cust_no_dvn = cust_no_dvn;
		}
		public String getCust_no_mngt_no() {
			return cust_no_mngt_no;
		}
		public void setCust_no_mngt_no(String cust_no_mngt_no) {
			this.cust_no_mngt_no = cust_no_mngt_no;
		}
		public String getInsu_cd() {
			return insu_cd;
		}
		public void setInsu_cd(String insu_cd) {
			this.insu_cd = insu_cd;
		}
		public String getPlno() {
			return plno;
		}
		public void setPlno(String plno) {
			this.plno = plno;
		}
		public String getInpd_cd() {
			return inpd_cd;
		}
		public void setInpd_cd(String inpd_cd) {
			this.inpd_cd = inpd_cd;
		}
		public String getCust_dvn_2() {
			return cust_dvn_2;
		}
		public void setCust_dvn_2(String cust_dvn_2) {
			this.cust_dvn_2 = cust_dvn_2;
		}
		public String getIns_nm() {
			return ins_nm;
		}
		public void setIns_nm(String ins_nm) {
			this.ins_nm = ins_nm;
		}
		public String getOrc_otcm_dvn() {
			return orc_otcm_dvn;
		}
		public void setOrc_otcm_dvn(String orc_otcm_dvn) {
			this.orc_otcm_dvn = orc_otcm_dvn;
		}
		public String getPrn_scy_dvn() {
			return prn_scy_dvn;
		}
		public void setPrn_scy_dvn(String prn_scy_dvn) {
			this.prn_scy_dvn = prn_scy_dvn;
		}
		public String getBith_yre_pd() {
			return bith_yre_pd;
		}
		public void setBith_yre_pd(String bith_yre_pd) {
			this.bith_yre_pd = bith_yre_pd;
		}
		public String getBith_yre_et() {
			return bith_yre_et;
		}
		public void setBith_yre_et(String bith_yre_et) {
			this.bith_yre_et = bith_yre_et;
		}
		public String getOrmm_cd() {
			return ormm_cd;
		}
		public void setOrmm_cd(String ormm_cd) {
			this.ormm_cd = ormm_cd;
		}
		public String getOrmm_nm() {
			return ormm_nm;
		}
		public void setOrmm_nm(String ormm_nm) {
			this.ormm_nm = ormm_nm;
		}
		public String getRecp_knd_cd() {
			return recp_knd_cd;
		}
		public void setRecp_knd_cd(String recp_knd_cd) {
			this.recp_knd_cd = recp_knd_cd;
		}
		public String getRecp_no() {
			return recp_no;
		}
		public void setRecp_no(String recp_no) {
			this.recp_no = recp_no;
		}
		public String getCbdy_no_dvn() {
			return cbdy_no_dvn;
		}
		public void setCbdy_no_dvn(String cbdy_no_dvn) {
			this.cbdy_no_dvn = cbdy_no_dvn;
		}
		public String getCbdy_no() {
			return cbdy_no;
		}
		public void setCbdy_no(String cbdy_no) {
			this.cbdy_no = cbdy_no;
		}
		public String getBse_dd() {
			return bse_dd;
		}
		public void setBse_dd(String bse_dd) {
			this.bse_dd = bse_dd;
		}
		public String getBz_dvn() {
			return bz_dvn;
		}
		public void setBz_dvn(String bz_dvn) {
			this.bz_dvn = bz_dvn;
		}
		public String getClp_1() {
			return clp_1;
		}
		public void setClp_1(String clp_1) {
			this.clp_1 = clp_1;
		}
		public String getClp_2() {
			return clp_2;
		}
		public void setClp_2(String clp_2) {
			this.clp_2 = clp_2;
		}
		public String getClp_3() {
			return clp_3;
		}
		public void setClp_3(String clp_3) {
			this.clp_3 = clp_3;
		}
		public String getClp_rsdn_no() {
			return clp_rsdn_no;
		}
		public void setClp_rsdn_no(String clp_rsdn_no) {
			this.clp_rsdn_no = clp_rsdn_no;
		}
		public String getDvn() {
			return dvn;
		}
		public void setDvn(String dvn) {
			this.dvn = dvn;
		}
		public String[] getCtc_det_srch_mngt_ctc_mtt__slc() {
			return ctc_det_srch_mngt_ctc_mtt__slc;
		}
		public void setCtc_det_srch_mngt_ctc_mtt__slc(
				String[] ctc_det_srch_mngt_ctc_mtt__slc) {
			this.ctc_det_srch_mngt_ctc_mtt__slc = ctc_det_srch_mngt_ctc_mtt__slc;
		}
		public String[] getCtc_det_srch_mngt_ctc_mtt__ins_nm_arrm() {
			return ctc_det_srch_mngt_ctc_mtt__ins_nm_arrm;
		}
		public void setCtc_det_srch_mngt_ctc_mtt__ins_nm_arrm(
				String[] ctc_det_srch_mngt_ctc_mtt__ins_nm_arrm) {
			this.ctc_det_srch_mngt_ctc_mtt__ins_nm_arrm = ctc_det_srch_mngt_ctc_mtt__ins_nm_arrm;
		}
		public String[] getCtc_det_srch_mngt_ctc_mtt__ins_dvcd_mngt_no() {
			return ctc_det_srch_mngt_ctc_mtt__ins_dvcd_mngt_no;
		}
		public void setCtc_det_srch_mngt_ctc_mtt__ins_dvcd_mngt_no(
				String[] ctc_det_srch_mngt_ctc_mtt__ins_dvcd_mngt_no) {
			this.ctc_det_srch_mngt_ctc_mtt__ins_dvcd_mngt_no = ctc_det_srch_mngt_ctc_mtt__ins_dvcd_mngt_no;
		}
		public String[] getCtc_det_srch_mngt_ctc_mtt__ins_cd_mngt_no() {
			return ctc_det_srch_mngt_ctc_mtt__ins_cd_mngt_no;
		}
		public void setCtc_det_srch_mngt_ctc_mtt__ins_cd_mngt_no(
				String[] ctc_det_srch_mngt_ctc_mtt__ins_cd_mngt_no) {
			this.ctc_det_srch_mngt_ctc_mtt__ins_cd_mngt_no = ctc_det_srch_mngt_ctc_mtt__ins_cd_mngt_no;
		}
		public String[] getCtc_det_srch_mngt_ctc_mtt__plhd_nm() {
			return ctc_det_srch_mngt_ctc_mtt__plhd_nm;
		}
		public void setCtc_det_srch_mngt_ctc_mtt__plhd_nm(
				String[] ctc_det_srch_mngt_ctc_mtt__plhd_nm) {
			this.ctc_det_srch_mngt_ctc_mtt__plhd_nm = ctc_det_srch_mngt_ctc_mtt__plhd_nm;
		}
		public String[] getCtc_det_srch_mngt_ctc_mtt__plhd_dvcd_mngt_no() {
			return ctc_det_srch_mngt_ctc_mtt__plhd_dvcd_mngt_no;
		}
		public void setCtc_det_srch_mngt_ctc_mtt__plhd_dvcd_mngt_no(
				String[] ctc_det_srch_mngt_ctc_mtt__plhd_dvcd_mngt_no) {
			this.ctc_det_srch_mngt_ctc_mtt__plhd_dvcd_mngt_no = ctc_det_srch_mngt_ctc_mtt__plhd_dvcd_mngt_no;
		}
		public String[] getCtc_det_srch_mngt_ctc_mtt__plhd_cd_mngt_no() {
			return ctc_det_srch_mngt_ctc_mtt__plhd_cd_mngt_no;
		}
		public void setCtc_det_srch_mngt_ctc_mtt__plhd_cd_mngt_no(
				String[] ctc_det_srch_mngt_ctc_mtt__plhd_cd_mngt_no) {
			this.ctc_det_srch_mngt_ctc_mtt__plhd_cd_mngt_no = ctc_det_srch_mngt_ctc_mtt__plhd_cd_mngt_no;
		}
		public String[] getCtc_det_srch_mngt_ctc_mtt__vh_no_arrm() {
			return ctc_det_srch_mngt_ctc_mtt__vh_no_arrm;
		}
		public void setCtc_det_srch_mngt_ctc_mtt__vh_no_arrm(
				String[] ctc_det_srch_mngt_ctc_mtt__vh_no_arrm) {
			this.ctc_det_srch_mngt_ctc_mtt__vh_no_arrm = ctc_det_srch_mngt_ctc_mtt__vh_no_arrm;
		}
		public String[] getCtc_det_srch_mngt_ctc_mtt__ctp() {
			return ctc_det_srch_mngt_ctc_mtt__ctp;
		}
		public void setCtc_det_srch_mngt_ctc_mtt__ctp(
				String[] ctc_det_srch_mngt_ctc_mtt__ctp) {
			this.ctc_det_srch_mngt_ctc_mtt__ctp = ctc_det_srch_mngt_ctc_mtt__ctp;
		}
		public String[] getCtc_det_srch_mngt_ctc_mtt__arc_pd() {
			return ctc_det_srch_mngt_ctc_mtt__arc_pd;
		}
		public void setCtc_det_srch_mngt_ctc_mtt__arc_pd(
				String[] ctc_det_srch_mngt_ctc_mtt__arc_pd) {
			this.ctc_det_srch_mngt_ctc_mtt__arc_pd = ctc_det_srch_mngt_ctc_mtt__arc_pd;
		}
		public String[] getCtc_det_srch_mngt_ctc_mtt__arc_et() {
			return ctc_det_srch_mngt_ctc_mtt__arc_et;
		}
		public void setCtc_det_srch_mngt_ctc_mtt__arc_et(
				String[] ctc_det_srch_mngt_ctc_mtt__arc_et) {
			this.ctc_det_srch_mngt_ctc_mtt__arc_et = ctc_det_srch_mngt_ctc_mtt__arc_et;
		}
		public String[] getCtc_det_srch_mngt_ctc_mtt__inpd() {
			return ctc_det_srch_mngt_ctc_mtt__inpd;
		}
		public void setCtc_det_srch_mngt_ctc_mtt__inpd(
				String[] ctc_det_srch_mngt_ctc_mtt__inpd) {
			this.ctc_det_srch_mngt_ctc_mtt__inpd = ctc_det_srch_mngt_ctc_mtt__inpd;
		}
		public String[] getCtc_det_srch_mngt_ctc_mtt__insu_cd_arrm() {
			return ctc_det_srch_mngt_ctc_mtt__insu_cd_arrm;
		}
		public void setCtc_det_srch_mngt_ctc_mtt__insu_cd_arrm(
				String[] ctc_det_srch_mngt_ctc_mtt__insu_cd_arrm) {
			this.ctc_det_srch_mngt_ctc_mtt__insu_cd_arrm = ctc_det_srch_mngt_ctc_mtt__insu_cd_arrm;
		}
		public String[] getCtc_det_srch_mngt_ctc_mtt__plno_arrm() {
			return ctc_det_srch_mngt_ctc_mtt__plno_arrm;
		}
		public void setCtc_det_srch_mngt_ctc_mtt__plno_arrm(
				String[] ctc_det_srch_mngt_ctc_mtt__plno_arrm) {
			this.ctc_det_srch_mngt_ctc_mtt__plno_arrm = ctc_det_srch_mngt_ctc_mtt__plno_arrm;
		}
		public String[] getCtc_det_srch_mngt_ctc_mtt__ctrmf_yn() {
			return ctc_det_srch_mngt_ctc_mtt__ctrmf_yn;
		}
		public void setCtc_det_srch_mngt_ctc_mtt__ctrmf_yn(
				String[] ctc_det_srch_mngt_ctc_mtt__ctrmf_yn) {
			this.ctc_det_srch_mngt_ctc_mtt__ctrmf_yn = ctc_det_srch_mngt_ctc_mtt__ctrmf_yn;
		}
		public String[] getCtc_det_srch_mngt_ctc_mtt__accd_yn() {
			return ctc_det_srch_mngt_ctc_mtt__accd_yn;
		}
		public void setCtc_det_srch_mngt_ctc_mtt__accd_yn(
				String[] ctc_det_srch_mngt_ctc_mtt__accd_yn) {
			this.ctc_det_srch_mngt_ctc_mtt__accd_yn = ctc_det_srch_mngt_ctc_mtt__accd_yn;
		}
		public String[] getCtc_det_srch_mngt_ctc_mtt__sbcp() {
			return ctc_det_srch_mngt_ctc_mtt__sbcp;
		}
		public void setCtc_det_srch_mngt_ctc_mtt__sbcp(
				String[] ctc_det_srch_mngt_ctc_mtt__sbcp) {
			this.ctc_det_srch_mngt_ctc_mtt__sbcp = ctc_det_srch_mngt_ctc_mtt__sbcp;
		}
		public String[] getCtc_det_srch_mngt_ctc_mtt__bh() {
			return ctc_det_srch_mngt_ctc_mtt__bh;
		}
		public void setCtc_det_srch_mngt_ctc_mtt__bh(
				String[] ctc_det_srch_mngt_ctc_mtt__bh) {
			this.ctc_det_srch_mngt_ctc_mtt__bh = ctc_det_srch_mngt_ctc_mtt__bh;
		}
		public String[] getCtc_det_srch_mngt_ctc_mtt__eny_carr_rt() {
			return ctc_det_srch_mngt_ctc_mtt__eny_carr_rt;
		}
		public void setCtc_det_srch_mngt_ctc_mtt__eny_carr_rt(
				String[] ctc_det_srch_mngt_ctc_mtt__eny_carr_rt) {
			this.ctc_det_srch_mngt_ctc_mtt__eny_carr_rt = ctc_det_srch_mngt_ctc_mtt__eny_carr_rt;
		}
		public String[] getCtc_det_srch_mngt_ctc_mtt__stdd_trt() {
			return ctc_det_srch_mngt_ctc_mtt__stdd_trt;
		}
		public void setCtc_det_srch_mngt_ctc_mtt__stdd_trt(
				String[] ctc_det_srch_mngt_ctc_mtt__stdd_trt) {
			this.ctc_det_srch_mngt_ctc_mtt__stdd_trt = ctc_det_srch_mngt_ctc_mtt__stdd_trt;
		}
		public String[] getCtc_det_srch_mngt_ctc_mtt__gr() {
			return ctc_det_srch_mngt_ctc_mtt__gr;
		}
		public void setCtc_det_srch_mngt_ctc_mtt__gr(
				String[] ctc_det_srch_mngt_ctc_mtt__gr) {
			this.ctc_det_srch_mngt_ctc_mtt__gr = ctc_det_srch_mngt_ctc_mtt__gr;
		}
		public String[] getCtc_det_srch_mngt_ctc_mtt__cust_no_bvan() {
			return ctc_det_srch_mngt_ctc_mtt__cust_no_bvan;
		}
		public void setCtc_det_srch_mngt_ctc_mtt__cust_no_bvan(
				String[] ctc_det_srch_mngt_ctc_mtt__cust_no_bvan) {
			this.ctc_det_srch_mngt_ctc_mtt__cust_no_bvan = ctc_det_srch_mngt_ctc_mtt__cust_no_bvan;
		}
		public String[] getCtc_det_srch_mngt_ctc_mtt__inpd_cd() {
			return ctc_det_srch_mngt_ctc_mtt__inpd_cd;
		}
		public void setCtc_det_srch_mngt_ctc_mtt__inpd_cd(
				String[] ctc_det_srch_mngt_ctc_mtt__inpd_cd) {
			this.ctc_det_srch_mngt_ctc_mtt__inpd_cd = ctc_det_srch_mngt_ctc_mtt__inpd_cd;
		}
		public String[] getCtc_det_srch_mngt_ctc_mtt__ocd() {
			return ctc_det_srch_mngt_ctc_mtt__ocd;
		}
		public void setCtc_det_srch_mngt_ctc_mtt__ocd(
				String[] ctc_det_srch_mngt_ctc_mtt__ocd) {
			this.ctc_det_srch_mngt_ctc_mtt__ocd = ctc_det_srch_mngt_ctc_mtt__ocd;
		}
		public String[] getCtc_det_srch_mngt_ctc_mtt__vh_no_cd() {
			return ctc_det_srch_mngt_ctc_mtt__vh_no_cd;
		}
		public void setCtc_det_srch_mngt_ctc_mtt__vh_no_cd(
				String[] ctc_det_srch_mngt_ctc_mtt__vh_no_cd) {
			this.ctc_det_srch_mngt_ctc_mtt__vh_no_cd = ctc_det_srch_mngt_ctc_mtt__vh_no_cd;
		}
		public String[] getCtc_det_srch_mngt_ctc_mtt__hd_trdr_dvn() {
			return ctc_det_srch_mngt_ctc_mtt__hd_trdr_dvn;
		}
		public void setCtc_det_srch_mngt_ctc_mtt__hd_trdr_dvn(
				String[] ctc_det_srch_mngt_ctc_mtt__hd_trdr_dvn) {
			this.ctc_det_srch_mngt_ctc_mtt__hd_trdr_dvn = ctc_det_srch_mngt_ctc_mtt__hd_trdr_dvn;
		}
		public String[] getCtc_det_srch_mngt_ctc_mtt__sme_ply_yn_clcnt() {
			return ctc_det_srch_mngt_ctc_mtt__sme_ply_yn_clcnt;
		}
		public void setCtc_det_srch_mngt_ctc_mtt__sme_ply_yn_clcnt(
				String[] ctc_det_srch_mngt_ctc_mtt__sme_ply_yn_clcnt) {
			this.ctc_det_srch_mngt_ctc_mtt__sme_ply_yn_clcnt = ctc_det_srch_mngt_ctc_mtt__sme_ply_yn_clcnt;
		}
		public String[] getCtc_det_srch_mngt_ctc_mtt__crnm_clcnt() {
			return ctc_det_srch_mngt_ctc_mtt__crnm_clcnt;
		}
		public void setCtc_det_srch_mngt_ctc_mtt__crnm_clcnt(
				String[] ctc_det_srch_mngt_ctc_mtt__crnm_clcnt) {
			this.ctc_det_srch_mngt_ctc_mtt__crnm_clcnt = ctc_det_srch_mngt_ctc_mtt__crnm_clcnt;
		}
		public String getEph_scrn() {
			return eph_scrn;
		}
		public void setEph_scrn(String eph_scrn) {
			this.eph_scrn = eph_scrn;
		}
		public String getEph_lcn() {
			return eph_lcn;
		}
		public void setEph_lcn(String eph_lcn) {
			this.eph_lcn = eph_lcn;
		}
		public String getErr_eph() {
			return err_eph;
		}
		public void setErr_eph(String err_eph) {
			this.err_eph = err_eph;
		}
		public String[] getCtc_det_srch_mngt_eph_nm__eph_nm() {
			return ctc_det_srch_mngt_eph_nm__eph_nm;
		}
		public void setCtc_det_srch_mngt_eph_nm__eph_nm(
				String[] ctc_det_srch_mngt_eph_nm__eph_nm) {
			this.ctc_det_srch_mngt_eph_nm__eph_nm = ctc_det_srch_mngt_eph_nm__eph_nm;
		}
		
		
		
}
