package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class KCUS0149VO extends CMMVO {

	public String clp_tlcno	= "";	// 휴대폰통신사번호
	public String clp_ofno	= "";	// 휴대폰국번호
	public String clp_idvno	= "";	// 휴대폰개별번호
	public String brth		= "";	// 생년월일

	public String mbl_emg_mvt_tgt_vh_no_srch_detl__hngl_vh_no[]	= new String[0];// 한글차량번호
	public String mbl_emg_mvt_tgt_vh_no_srch_detl__plno[]		= new String[0];// 증권번호
	public String mbl_emg_mvt_tgt_vh_no_srch_detl__rrno[]		= new String[0];// 주민번호
	public String mbl_emg_mvt_tgt_vh_no_srch_detl__cust_nm[]	= new String[0];// 고객명
	
	
	public String getClp_tlcno() {
		return clp_tlcno;
	}
	public void setClp_tlcno(String clp_tlcno) {
		this.clp_tlcno = clp_tlcno;
	}
	public String getClp_ofno() {
		return clp_ofno;
	}
	public void setClp_ofno(String clp_ofno) {
		this.clp_ofno = clp_ofno;
	}
	public String getClp_idvno() {
		return clp_idvno;
	}
	public void setClp_idvno(String clp_idvno) {
		this.clp_idvno = clp_idvno;
	}
	public String getBrth() {
		return brth;
	}
	public void setBrth(String brth) {
		this.brth = brth;
	}
	public String[] getMbl_emg_mvt_tgt_vh_no_srch_detl__hngl_vh_no() {
		return mbl_emg_mvt_tgt_vh_no_srch_detl__hngl_vh_no;
	}
	public void setMbl_emg_mvt_tgt_vh_no_srch_detl__hngl_vh_no(
			String[] mbl_emg_mvt_tgt_vh_no_srch_detl__hngl_vh_no) {
		this.mbl_emg_mvt_tgt_vh_no_srch_detl__hngl_vh_no = mbl_emg_mvt_tgt_vh_no_srch_detl__hngl_vh_no;
	}
	public String[] getMbl_emg_mvt_tgt_vh_no_srch_detl__plno() {
		return mbl_emg_mvt_tgt_vh_no_srch_detl__plno;
	}
	public void setMbl_emg_mvt_tgt_vh_no_srch_detl__plno(
			String[] mbl_emg_mvt_tgt_vh_no_srch_detl__plno) {
		this.mbl_emg_mvt_tgt_vh_no_srch_detl__plno = mbl_emg_mvt_tgt_vh_no_srch_detl__plno;
	}
	public String[] getMbl_emg_mvt_tgt_vh_no_srch_detl__rrno() {
		return mbl_emg_mvt_tgt_vh_no_srch_detl__rrno;
	}
	public void setMbl_emg_mvt_tgt_vh_no_srch_detl__rrno(
			String[] mbl_emg_mvt_tgt_vh_no_srch_detl__rrno) {
		this.mbl_emg_mvt_tgt_vh_no_srch_detl__rrno = mbl_emg_mvt_tgt_vh_no_srch_detl__rrno;
	}
	public String[] getMbl_emg_mvt_tgt_vh_no_srch_detl__cust_nm() {
		return mbl_emg_mvt_tgt_vh_no_srch_detl__cust_nm;
	}
	public void setMbl_emg_mvt_tgt_vh_no_srch_detl__cust_nm(
			String[] mbl_emg_mvt_tgt_vh_no_srch_detl__cust_nm) {
		this.mbl_emg_mvt_tgt_vh_no_srch_detl__cust_nm = mbl_emg_mvt_tgt_vh_no_srch_detl__cust_nm;
	}
	

}
