package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class EAST0022VO extends CMMVO{
	//전문필드
		public String funt_key = "";  //[I] 기능키 CC_FUN_KEY 기능키
		public String last_dat_yn = "";  //[I] 마지막자료여부 CC_LAST_FLAG 마지막자료여부
		public String bh_cd = "";  //[I] 지점코드 JJ_JIJUM 지점코드
		public String bh_nm = "";  //[I] 지점명 HJ_JIJUM 지점명
		public String empno = "";  //[I] 사원번호 JJ_SAWON 사원번호
		public String ep_nm = "";  //[I] 사원명 HJ_SAWON 사원명
		public String pw = "";  //[I] 비밀번호 JJ_PASSWORD 패스워드
		public String inpt_rsdn_no = "";  //[I] 입력주민번호 JJ_JUMIN_NO 입력주민번호
		public String plhd_nm = "";  //[I] 계약자명 HJ_GY_NM 계약자명
		public String proc_dvn = "";  //[I] 처리구분 JJ_GUBUN 처리구분
		public String ln_dt = "";  //[I] 대출일자 JJ_DATE 대출시기
		public String[] arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__slc_dvn = new String[0];  //[I/O] 선택구분 JJ_SUNTAK 선택구분
		public String[] arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__plno = new String[0];  //[I/O] 증권번호 JJ_POLI_NO 증권번호
		// 차세대 2차 전환 시작 필드 추가 (김도연 2014.02.14)
		public String[] arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__ins_lcpl_dvcd = new String[0];  //[I/O] 피보험자소재지구분코드  
		public String[] arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__ply_sqno = new String[0];  //[I/O] 증권일련번호  
		public String[] arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__inpd_cd = new String[0];  //[I/O] 보종코드 추가 보종코드
		// 차세대 2차 전환 종료 필드 추가 (김도연 2014.02.14) 
		public String[] arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__ln_pd = new String[0];  //[I/O] 대출시기 JJ_DE_DATE 대출시기
		public String[] arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__coll_mtd_nm = new String[0];  //[I/O] 수금방법명 HJ_SUGUM 수금방법명
		public String[] arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__tsfr_dd = new String[0];  //[I/O] 이체일 HJ_ICHE 이체일
		public String[] arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__bank_nm = new String[0];  //[I/O] 은행명 HJ_BANK 은행명
		public String[] arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__bank_cd = new String[0];  //[I/O] 은행코드 차세대이후 추가
		public String[] arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__aut_tsfr_dpsr_nm_1 = new String[0];  //[I/O] 자동이체예금주명1 HJ_YEGMJU1 자동이체예금주명
		public String[] arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__acc_no = new String[0];  //[I/O] 계좌번호 JJ_GYEJWA 계좌번호
		public String[] arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__aply_yn = new String[0];  //[I/O] 신청여부 HJ_JE_CG 신청여부
		public String[] arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__pym_dt = new String[0];  //[I/O] 납입일자 JJ_NAPIP_YMD 납입일자
		public String[] arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__inpd_nm = new String[0];  //[I/O] 보종명 HJ_BJ_NM 보종명
		public String slc_dvn_1 = "";  //[I] 선택구분1 JJ_SUNTAK1 선택구분
		public String coll_mtd_nm_2 = "";  //[I] 수금방법명2 HJ_SUGUM_NM 수금방법명
		public String tsfr_dd_2 = "";  //[I] 이체일2 HJ_ICHE_NM 이체일
		public String bank_nm_2 = "";  //[I] 은행명2 HJ_BANK_NM 은행명
		public String aut_tsfr_dpsr_nm_2 = "";  //[I] 자동이체예금주명2 HJ_YEGMJU_NM 자동이체예금주명
		public String acc_no_1 = "";  //[I] 계좌번호1 JJ_GYEJWA_NO 계좌번호
		public String coll_mtd_cd = "";  //[I] 수금방법코드 JJ_SUGUM 수금방법명
		public String coll_mtd_nm_1 = "";  //[I] 수금방법명1 HJ_SUGUM1 수금방법명
		public String bank_cd = "";  //[I] 은행코드 JJ_BANK 은행명
		public String bank_nm_1 = "";  //[I] 은행명1 HJ_BANK1 은행명
		public String acc_no_2 = "";  //[I] 계좌번호2 JJ_GYEJWA1 계좌번호
		public String aut_tsfr_dpsr_rlt = "";  //[I] 자동이체예금주관계 JJ_YEGMJU 자동이체예금주명
		public String aut_tsfr_dpsr_nm = "";  //[I] 자동이체예금주명 HJ_YEGMJU 자동이체예금주명
		public String aut_tsfr_dpsr_nm_3 = "";  //[I] 자동이체예금주명3 HJ_YEGMJU2 자동이체예금주명
		public String aut_tsfr_dpsr_rsdn_no = "";  //[I] 자동이체예금주주민번호 JJ_YE_JUMIN 자동이체예금주주민번호
		public String dpsr_tlno = "";  //[I] 예금주전화번호 JJ_YEGMJU_TEL 예금주　전화번호
		public String tsfr_dd_1 = "";  //[I] 이체일1 JJ_ICHE 이체일
		public String bgn_mthl = "";  //[I] 개시월도 JJ_JUKY_YM 개시월도
		public String wn_vis_tpcd_cnfm = "";  //[I] 창구방문유형코드확인 JJ_VIS_CD 창구방문유형코드확인
		public String inpt_rsdn_no_2 = "";  //[I] 입력주민번호2 UU_JUMIN_NO 자동이체예금주주민번호
		public String proc_rsl_cd = "";  //[I/O] 처리결과코드  
		public String plno_1 = "";  //[I] 증권번호1 UUC_INQ_POLI_NO 증권번호
		// 차세대 2차 전환 시작 필드 추가 (김도연 2014.02.14)
		public String ins_lcpl_dvcd = "";  //[I] 피보험자소재지구분코드  
		public String ply_sqno = "";  //[I] 증권일련번호  
		// 차세대 2차 전환 종료 필드 추가 (김도연 2014.02.14)
		public String inpt_dt = "";  //[I] 입력일자 UUC_INQ_YMD 입력일자
		public String inpt_time = "";  //[I] 입력시간 UUC_INQ_HMS 입력시간
		public String errorCode = ""; // 에러코드

		public String z_user_page_key_set = ""; // 사용자 키 방식의 페이지 처리
		public String z_next_page_exis_yn = ""; // 다음페이지 존재여부
		public String z_wh_page_cnt = ""; // 총 페이지
		public String z_row_cnt_per_page = ""; // 페이지 당 row 수
		public String z_wh_cnum = ""; // 전체 건 수

		public String wthd_csn_evd_dat_dvcd = ""; // [I] 출금동의증빙자료구분코드
		public String wthd_csn_evd_dat_inpt_dvcd = ""; // [I] 출금동의증빙자료입력구분코드
		public String wthd_csn_evd_dat_val = ""; // [I] 출금동의증빙자료값
		
		public String getFunt_key() {
			return funt_key;
		}
		public void setFunt_key(String funt_key) {
			this.funt_key = funt_key;
		}
		public String getLast_dat_yn() {
			return last_dat_yn;
		}
		public void setLast_dat_yn(String last_dat_yn) {
			this.last_dat_yn = last_dat_yn;
		}
		public String getBh_cd() {
			return bh_cd;
		}
		public void setBh_cd(String bh_cd) {
			this.bh_cd = bh_cd;
		}
		public String getBh_nm() {
			return bh_nm;
		}
		public void setBh_nm(String bh_nm) {
			this.bh_nm = bh_nm;
		}
		public String getEmpno() {
			return empno;
		}
		public void setEmpno(String empno) {
			this.empno = empno;
		}
		public String getEp_nm() {
			return ep_nm;
		}
		public void setEp_nm(String ep_nm) {
			this.ep_nm = ep_nm;
		}
		public String getPw() {
			return pw;
		}
		public void setPw(String pw) {
			this.pw = pw;
		}
		public String getInpt_rsdn_no() {
			return inpt_rsdn_no;
		}
		public void setInpt_rsdn_no(String inpt_rsdn_no) {
			this.inpt_rsdn_no = inpt_rsdn_no;
		}
		public String getPlhd_nm() {
			return plhd_nm;
		}
		public void setPlhd_nm(String plhd_nm) {
			this.plhd_nm = plhd_nm;
		}
		public String getProc_dvn() {
			return proc_dvn;
		}
		public void setProc_dvn(String proc_dvn) {
			this.proc_dvn = proc_dvn;
		}
		public String getLn_dt() {
			return ln_dt;
		}
		public void setLn_dt(String ln_dt) {
			this.ln_dt = ln_dt;
		}
		public String[] getArc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__slc_dvn() {
			return arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__slc_dvn;
		}
		public void setArc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__slc_dvn(
				String[] arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__slc_dvn) {
			this.arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__slc_dvn = arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__slc_dvn;
		}
		public String[] getArc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__plno() {
			return arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__plno;
		}
		public void setArc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__plno(
				String[] arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__plno) {
			this.arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__plno = arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__plno;
		}
		public String[] getArc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__ins_lcpl_dvcd() {
			return arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__ins_lcpl_dvcd;
		}
		public void setArc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__ins_lcpl_dvcd(
				String[] arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__ins_lcpl_dvcd) {
			this.arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__ins_lcpl_dvcd = arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__ins_lcpl_dvcd;
		}
		public String[] getArc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__ply_sqno() {
			return arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__ply_sqno;
		}
		public void setArc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__ply_sqno(
				String[] arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__ply_sqno) {
			this.arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__ply_sqno = arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__ply_sqno;
		}
		public String[] getArc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__inpd_cd() {
			return arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__inpd_cd;
		}
		public void setArc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__inpd_cd(
				String[] arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__inpd_cd) {
			this.arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__inpd_cd = arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__inpd_cd;
		}
		public String[] getArc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__ln_pd() {
			return arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__ln_pd;
		}
		public void setArc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__ln_pd(
				String[] arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__ln_pd) {
			this.arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__ln_pd = arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__ln_pd;
		}
		public String[] getArc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__coll_mtd_nm() {
			return arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__coll_mtd_nm;
		}
		public void setArc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__coll_mtd_nm(
				String[] arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__coll_mtd_nm) {
			this.arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__coll_mtd_nm = arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__coll_mtd_nm;
		}
		public String[] getArc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__tsfr_dd() {
			return arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__tsfr_dd;
		}
		public void setArc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__tsfr_dd(
				String[] arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__tsfr_dd) {
			this.arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__tsfr_dd = arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__tsfr_dd;
		}
		public String[] getArc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__bank_nm() {
			return arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__bank_nm;
		}
		public void setArc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__bank_nm(
				String[] arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__bank_nm) {
			this.arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__bank_nm = arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__bank_nm;
		}
		public String[] getArc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__bank_cd() {
			return arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__bank_cd;
		}
		public void setArc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__bank_cd(
				String[] arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__bank_cd) {
			this.arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__bank_cd = arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__bank_cd;
		}
		public String[] getArc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__aut_tsfr_dpsr_nm_1() {
			return arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__aut_tsfr_dpsr_nm_1;
		}
		public void setArc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__aut_tsfr_dpsr_nm_1(
				String[] arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__aut_tsfr_dpsr_nm_1) {
			this.arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__aut_tsfr_dpsr_nm_1 = arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__aut_tsfr_dpsr_nm_1;
		}
		public String[] getArc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__acc_no() {
			return arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__acc_no;
		}
		public void setArc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__acc_no(
				String[] arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__acc_no) {
			this.arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__acc_no = arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__acc_no;
		}
		public String[] getArc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__aply_yn() {
			return arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__aply_yn;
		}
		public void setArc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__aply_yn(
				String[] arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__aply_yn) {
			this.arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__aply_yn = arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__aply_yn;
		}
		public String[] getArc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__pym_dt() {
			return arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__pym_dt;
		}
		public void setArc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__pym_dt(
				String[] arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__pym_dt) {
			this.arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__pym_dt = arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__pym_dt;
		}
		public String[] getArc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__inpd_nm() {
			return arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__inpd_nm;
		}
		public void setArc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__inpd_nm(
				String[] arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__inpd_nm) {
			this.arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__inpd_nm = arc_ctc_ln_coll_mtd_each_cnsi_regt_mngt_lit__inpd_nm;
		}
		public String getSlc_dvn_1() {
			return slc_dvn_1;
		}
		public void setSlc_dvn_1(String slc_dvn_1) {
			this.slc_dvn_1 = slc_dvn_1;
		}
		public String getColl_mtd_nm_2() {
			return coll_mtd_nm_2;
		}
		public void setColl_mtd_nm_2(String coll_mtd_nm_2) {
			this.coll_mtd_nm_2 = coll_mtd_nm_2;
		}
		public String getTsfr_dd_2() {
			return tsfr_dd_2;
		}
		public void setTsfr_dd_2(String tsfr_dd_2) {
			this.tsfr_dd_2 = tsfr_dd_2;
		}
		public String getBank_nm_2() {
			return bank_nm_2;
		}
		public void setBank_nm_2(String bank_nm_2) {
			this.bank_nm_2 = bank_nm_2;
		}
		public String getAut_tsfr_dpsr_nm_2() {
			return aut_tsfr_dpsr_nm_2;
		}
		public void setAut_tsfr_dpsr_nm_2(String aut_tsfr_dpsr_nm_2) {
			this.aut_tsfr_dpsr_nm_2 = aut_tsfr_dpsr_nm_2;
		}
		public String getAcc_no_1() {
			return acc_no_1;
		}
		public void setAcc_no_1(String acc_no_1) {
			this.acc_no_1 = acc_no_1;
		}
		public String getColl_mtd_cd() {
			return coll_mtd_cd;
		}
		public void setColl_mtd_cd(String coll_mtd_cd) {
			this.coll_mtd_cd = coll_mtd_cd;
		}
		public String getColl_mtd_nm_1() {
			return coll_mtd_nm_1;
		}
		public void setColl_mtd_nm_1(String coll_mtd_nm_1) {
			this.coll_mtd_nm_1 = coll_mtd_nm_1;
		}
		public String getBank_cd() {
			return bank_cd;
		}
		public void setBank_cd(String bank_cd) {
			this.bank_cd = bank_cd;
		}
		public String getBank_nm_1() {
			return bank_nm_1;
		}
		public void setBank_nm_1(String bank_nm_1) {
			this.bank_nm_1 = bank_nm_1;
		}
		public String getAcc_no_2() {
			return acc_no_2;
		}
		public void setAcc_no_2(String acc_no_2) {
			this.acc_no_2 = acc_no_2;
		}
		public String getAut_tsfr_dpsr_rlt() {
			return aut_tsfr_dpsr_rlt;
		}
		public void setAut_tsfr_dpsr_rlt(String aut_tsfr_dpsr_rlt) {
			this.aut_tsfr_dpsr_rlt = aut_tsfr_dpsr_rlt;
		}
		public String getAut_tsfr_dpsr_nm() {
			return aut_tsfr_dpsr_nm;
		}
		public void setAut_tsfr_dpsr_nm(String aut_tsfr_dpsr_nm) {
			this.aut_tsfr_dpsr_nm = aut_tsfr_dpsr_nm;
		}
		public String getAut_tsfr_dpsr_nm_3() {
			return aut_tsfr_dpsr_nm_3;
		}
		public void setAut_tsfr_dpsr_nm_3(String aut_tsfr_dpsr_nm_3) {
			this.aut_tsfr_dpsr_nm_3 = aut_tsfr_dpsr_nm_3;
		}
		public String getAut_tsfr_dpsr_rsdn_no() {
			return aut_tsfr_dpsr_rsdn_no;
		}
		public void setAut_tsfr_dpsr_rsdn_no(String aut_tsfr_dpsr_rsdn_no) {
			this.aut_tsfr_dpsr_rsdn_no = aut_tsfr_dpsr_rsdn_no;
		}
		public String getDpsr_tlno() {
			return dpsr_tlno;
		}
		public void setDpsr_tlno(String dpsr_tlno) {
			this.dpsr_tlno = dpsr_tlno;
		}
		public String getTsfr_dd_1() {
			return tsfr_dd_1;
		}
		public void setTsfr_dd_1(String tsfr_dd_1) {
			this.tsfr_dd_1 = tsfr_dd_1;
		}
		public String getBgn_mthl() {
			return bgn_mthl;
		}
		public void setBgn_mthl(String bgn_mthl) {
			this.bgn_mthl = bgn_mthl;
		}
		public String getWn_vis_tpcd_cnfm() {
			return wn_vis_tpcd_cnfm;
		}
		public void setWn_vis_tpcd_cnfm(String wn_vis_tpcd_cnfm) {
			this.wn_vis_tpcd_cnfm = wn_vis_tpcd_cnfm;
		}
		public String getInpt_rsdn_no_2() {
			return inpt_rsdn_no_2;
		}
		public void setInpt_rsdn_no_2(String inpt_rsdn_no_2) {
			this.inpt_rsdn_no_2 = inpt_rsdn_no_2;
		}
		public String getProc_rsl_cd() {
			return proc_rsl_cd;
		}
		public void setProc_rsl_cd(String proc_rsl_cd) {
			this.proc_rsl_cd = proc_rsl_cd;
		}
		public String getPlno_1() {
			return plno_1;
		}
		public void setPlno_1(String plno_1) {
			this.plno_1 = plno_1;
		}
		public String getIns_lcpl_dvcd() {
			return ins_lcpl_dvcd;
		}
		public void setIns_lcpl_dvcd(String ins_lcpl_dvcd) {
			this.ins_lcpl_dvcd = ins_lcpl_dvcd;
		}
		public String getPly_sqno() {
			return ply_sqno;
		}
		public void setPly_sqno(String ply_sqno) {
			this.ply_sqno = ply_sqno;
		}
		public String getInpt_dt() {
			return inpt_dt;
		}
		public void setInpt_dt(String inpt_dt) {
			this.inpt_dt = inpt_dt;
		}
		public String getInpt_time() {
			return inpt_time;
		}
		public void setInpt_time(String inpt_time) {
			this.inpt_time = inpt_time;
		}
		public String getErrorCode() {
			return errorCode;
		}
		public void setErrorCode(String errorCode) {
			this.errorCode = errorCode;
		}
		
		/**
		 * @return the z_user_page_key_set
		 */
		public String getZ_user_page_key_set() {
			return z_user_page_key_set;
		}
		/**
		 * @param z_user_page_key_set the z_user_page_key_set to set
		 */
		public void setZ_user_page_key_set(String z_user_page_key_set) {
			this.z_user_page_key_set = z_user_page_key_set;
		}
		/**
		 * @return the z_next_page_exis_yn
		 */
		public String getZ_next_page_exis_yn() {
			return z_next_page_exis_yn;
		}
		/**
		 * @param z_next_page_exis_yn the z_next_page_exis_yn to set
		 */
		public void setZ_next_page_exis_yn(String z_next_page_exis_yn) {
			this.z_next_page_exis_yn = z_next_page_exis_yn;
		}

		/**
		 * @return the z_wh_page_cnt
		 */
		public String getZ_wh_page_cnt() {
			return z_wh_page_cnt;
		}
		/**
		 * @param z_wh_page_cnt the z_wh_page_cnt to set
		 */
		public void setZ_wh_page_cnt(String z_wh_page_cnt) {
			this.z_wh_page_cnt = z_wh_page_cnt;
		}
		/**
		 * @return the z_row_cnt_per_page
		 */
		public String getZ_row_cnt_per_page() {
			return z_row_cnt_per_page;
		}
		/**
		 * @param z_row_cnt_per_page the z_row_cnt_per_page to set
		 */
		public void setZ_row_cnt_per_page(String z_row_cnt_per_page) {
			this.z_row_cnt_per_page = z_row_cnt_per_page;
		}
		/**
		 * @return the z_wh_cnum
		 */
		public String getZ_wh_cnum() {
			return z_wh_cnum;
		}
		/**
		 * @param z_wh_cnum the z_wh_cnum to set
		 */
		public void setZ_wh_cnum(String z_wh_cnum) {
			this.z_wh_cnum = z_wh_cnum;
		}

		public String getWthd_csn_evd_dat_dvcd() {
			return wthd_csn_evd_dat_dvcd;
		}
		public void setWthd_csn_evd_dat_dvcd(String wthd_csn_evd_dat_dvcd) {
			this.wthd_csn_evd_dat_dvcd = wthd_csn_evd_dat_dvcd;
		}
		public String getWthd_csn_evd_dat_inpt_dvcd() {
			return wthd_csn_evd_dat_inpt_dvcd;
		}
		public void setWthd_csn_evd_dat_inpt_dvcd(String wthd_csn_evd_dat_inpt_dvcd) {
			this.wthd_csn_evd_dat_inpt_dvcd = wthd_csn_evd_dat_inpt_dvcd;
		}
		public String getWthd_csn_evd_dat_val() {
			return wthd_csn_evd_dat_val;
		}
		public void setWthd_csn_evd_dat_val(String wthd_csn_evd_dat_val) {
			this.wthd_csn_evd_dat_val = wthd_csn_evd_dat_val;
		}
}
