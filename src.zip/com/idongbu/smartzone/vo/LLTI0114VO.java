package com.idongbu.smartzone.vo;
import com.idongbu.common.vo.CMMVO;
public class LLTI0114VO extends CMMVO{
	//전문필드
		public String rrno = "";  //[I] 주민등록번호 JJ_JUMIN_NO 주민번호
		public String bcst_nm = "";  //[O] 우수고객명 HJ_WOOSU_GOGEK 우수고객명
		public String[] ctc_if__plno = new String[0];  //[O] 계약정보_증권번호 JJ_POLI_NO 증권번호
		public String[] ctc_if__ins_lcpl_dvcd = new String[0];  //[O] 피보험자소재지구분코드  
		public String[] ctc_if__ply_sqno = new String[0];  //[O] 증권일련번호  
		public String[] ctc_if__pdc_cd = new String[0];  //[O] 계약정보_상품코드 JJ_BJ_CD 상품코드
		public String[] ctc_if__plhd_nm = new String[0];  //[O] 계약정보_계약자명 HJ_GYEYAK_NM 계약자명
		public String[] ctc_if__arc_trm_fin_dt = new String[0];  //[O] 계약정보_보험종료일자 JJ_BOHUM_EYMD 보험종료일
		public String[] ctc_if__ctc_stat = new String[0];  //[O] 계약정보_계약상태명 HJ_SANGTE_NM 계약상태
		public String[] ctc_if__irt = new String[0];  //[O] 계약정보_이율 JJ_IYUL 이율
		public String[] ctc_if__hdlr_cd = new String[0];  //[O] 계약정보_취급자코드 JJ_CHUGPJA_CD 취급자코드
		public String[] ctc_if__plg_cn = new String[0];  //[O] 계약정보_질권내용 HJ_JILGWUN 질권내용
		public String[] ctc_if__arc_ctc_ln_rpm_ovdu_yn = new String[0];  //[O] 계약정보_연채여부명 HJ_SUNAP_NM 연체여부명
		public String[] ctc_if__tsfr_dd = new String[0];  //[O] 계약정보_이체일 HJ_ICHE_NM 이체일자명
		public String[] ctc_if__ps_ln_bal = new String[0];  //[O] 계약정보_기대출잔액 JJ_DECHUL_KUM 기대출잔액
		public String[] ctc_if__fnal_proc_dt = new String[0];  //[O] 계약정보_최종처리일자 JJ_LAST_YMD 최종처리일자
		public String[] ctc_if__trmt_rprm = new String[0];  //[O] 계약정보_해지환급금 JJ_HEJI_KUM 해지환급금
		public String[] ctc_if__inpl_ln_pss_amt = new String[0];  //[O] 계약정보_약관대출가능금액 JJ_GANUNG_KUM 약관대출가능액
		public String[] ctc_if__pdc_nm = new String[0];  //[O] 계약정보_상품명 HJ_BJ_NAME 상품명
		public String[] ctc_if__accu_prm = new String[0];  //[O] 계약정보_적립금액 JJ_JUKRIP_KUM 적립금액
		public String[] ctc_if__asr_prm = new String[0];  //[O] 계약정보_보장금액 JJ_BOJANG_KUM 보장금액
		public String tot_ps_ln_bal = "";  //[I/O] 총기대출잔액 JJ_DECHUL_T_KUM 총기대출잔액
		public String tot_trmt_rprm = "";  //[I/O] 총해지환급금 JJ_HEJI_T_KUM 총해지환급금
		public String tot_ln_pss_amt = "";  //[I/O] 총대출가능금액 JJ_GANUNG_T_KUM 총약관대출가능액
		public String relv_lit_tot_ps_ln_bal = "";  //[O] 해당목록총기대출잔액 JJ_DECHUL_TL_KUM 해당리스트총기대출잔액
		public String relv_lit_tot_trmt_rprm = "";  //[O] 해당목록총해지환급금 JJ_HEJI_TL_KUM   해당리스트총총해지환급금
		public String relv_lit_tot_inpl_ln_pss_aot = "";  //[O] 해당목록총약관대출가능액 JJ_GANUNG_TL_KUM 해당리스트총총약관대출가능액
		public String str_plno = "";  //[I] 최초증권번호 UUC_F_POLI_NO FIRST증권번호
		public String last_plno = "";  //[O] 마지막증권번호 UUC_L_POLI_NO LAST증권번호
		public String errorCode = "";  
		public String getRrno() {
			return rrno;
		}
		public void setRrno(String rrno) {
			this.rrno = rrno;
		}
		public String getBcst_nm() {
			return bcst_nm;
		}
		public void setBcst_nm(String bcst_nm) {
			this.bcst_nm = bcst_nm;
		}
		public String[] getCtc_if__plno() {
			return ctc_if__plno;
		}
		public void setCtc_if__plno(String[] ctc_if__plno) {
			this.ctc_if__plno = ctc_if__plno;
		}
		public String[] getCtc_if__ins_lcpl_dvcd() {
			return ctc_if__ins_lcpl_dvcd;
		}
		public void setCtc_if__ins_lcpl_dvcd(String[] ctc_if__ins_lcpl_dvcd) {
			this.ctc_if__ins_lcpl_dvcd = ctc_if__ins_lcpl_dvcd;
		}
		public String[] getCtc_if__ply_sqno() {
			return ctc_if__ply_sqno;
		}
		public void setCtc_if__ply_sqno(String[] ctc_if__ply_sqno) {
			this.ctc_if__ply_sqno = ctc_if__ply_sqno;
		}
		public String[] getCtc_if__pdc_cd() {
			return ctc_if__pdc_cd;
		}
		public void setCtc_if__pdc_cd(String[] ctc_if__pdc_cd) {
			this.ctc_if__pdc_cd = ctc_if__pdc_cd;
		}
		public String[] getCtc_if__plhd_nm() {
			return ctc_if__plhd_nm;
		}
		public void setCtc_if__plhd_nm(String[] ctc_if__plhd_nm) {
			this.ctc_if__plhd_nm = ctc_if__plhd_nm;
		}
		public String[] getCtc_if__arc_trm_fin_dt() {
			return ctc_if__arc_trm_fin_dt;
		}
		public void setCtc_if__arc_trm_fin_dt(String[] ctc_if__arc_trm_fin_dt) {
			this.ctc_if__arc_trm_fin_dt = ctc_if__arc_trm_fin_dt;
		}
		public String[] getCtc_if__ctc_stat() {
			return ctc_if__ctc_stat;
		}
		public void setCtc_if__ctc_stat(String[] ctc_if__ctc_stat) {
			this.ctc_if__ctc_stat = ctc_if__ctc_stat;
		}
		public String[] getCtc_if__irt() {
			return ctc_if__irt;
		}
		public void setCtc_if__irt(String[] ctc_if__irt) {
			this.ctc_if__irt = ctc_if__irt;
		}
		public String[] getCtc_if__hdlr_cd() {
			return ctc_if__hdlr_cd;
		}
		public void setCtc_if__hdlr_cd(String[] ctc_if__hdlr_cd) {
			this.ctc_if__hdlr_cd = ctc_if__hdlr_cd;
		}
		public String[] getCtc_if__plg_cn() {
			return ctc_if__plg_cn;
		}
		public void setCtc_if__plg_cn(String[] ctc_if__plg_cn) {
			this.ctc_if__plg_cn = ctc_if__plg_cn;
		}
		public String[] getCtc_if__arc_ctc_ln_rpm_ovdu_yn() {
			return ctc_if__arc_ctc_ln_rpm_ovdu_yn;
		}
		public void setCtc_if__arc_ctc_ln_rpm_ovdu_yn(
				String[] ctc_if__arc_ctc_ln_rpm_ovdu_yn) {
			this.ctc_if__arc_ctc_ln_rpm_ovdu_yn = ctc_if__arc_ctc_ln_rpm_ovdu_yn;
		}
		public String[] getCtc_if__tsfr_dd() {
			return ctc_if__tsfr_dd;
		}
		public void setCtc_if__tsfr_dd(String[] ctc_if__tsfr_dd) {
			this.ctc_if__tsfr_dd = ctc_if__tsfr_dd;
		}
		public String[] getCtc_if__ps_ln_bal() {
			return ctc_if__ps_ln_bal;
		}
		public void setCtc_if__ps_ln_bal(String[] ctc_if__ps_ln_bal) {
			this.ctc_if__ps_ln_bal = ctc_if__ps_ln_bal;
		}
		public String[] getCtc_if__fnal_proc_dt() {
			return ctc_if__fnal_proc_dt;
		}
		public void setCtc_if__fnal_proc_dt(String[] ctc_if__fnal_proc_dt) {
			this.ctc_if__fnal_proc_dt = ctc_if__fnal_proc_dt;
		}
		public String[] getCtc_if__trmt_rprm() {
			return ctc_if__trmt_rprm;
		}
		public void setCtc_if__trmt_rprm(String[] ctc_if__trmt_rprm) {
			this.ctc_if__trmt_rprm = ctc_if__trmt_rprm;
		}
		public String[] getCtc_if__inpl_ln_pss_amt() {
			return ctc_if__inpl_ln_pss_amt;
		}
		public void setCtc_if__inpl_ln_pss_amt(String[] ctc_if__inpl_ln_pss_amt) {
			this.ctc_if__inpl_ln_pss_amt = ctc_if__inpl_ln_pss_amt;
		}
		public String[] getCtc_if__pdc_nm() {
			return ctc_if__pdc_nm;
		}
		public void setCtc_if__pdc_nm(String[] ctc_if__pdc_nm) {
			this.ctc_if__pdc_nm = ctc_if__pdc_nm;
		}
		public String[] getCtc_if__accu_prm() {
			return ctc_if__accu_prm;
		}
		public void setCtc_if__accu_prm(String[] ctc_if__accu_prm) {
			this.ctc_if__accu_prm = ctc_if__accu_prm;
		}
		public String[] getCtc_if__asr_prm() {
			return ctc_if__asr_prm;
		}
		public void setCtc_if__asr_prm(String[] ctc_if__asr_prm) {
			this.ctc_if__asr_prm = ctc_if__asr_prm;
		}
		public String getTot_ps_ln_bal() {
			return tot_ps_ln_bal;
		}
		public void setTot_ps_ln_bal(String tot_ps_ln_bal) {
			this.tot_ps_ln_bal = tot_ps_ln_bal;
		}
		public String getTot_trmt_rprm() {
			return tot_trmt_rprm;
		}
		public void setTot_trmt_rprm(String tot_trmt_rprm) {
			this.tot_trmt_rprm = tot_trmt_rprm;
		}
		public String getTot_ln_pss_amt() {
			return tot_ln_pss_amt;
		}
		public void setTot_ln_pss_amt(String tot_ln_pss_amt) {
			this.tot_ln_pss_amt = tot_ln_pss_amt;
		}
		public String getRelv_lit_tot_ps_ln_bal() {
			return relv_lit_tot_ps_ln_bal;
		}
		public void setRelv_lit_tot_ps_ln_bal(String relv_lit_tot_ps_ln_bal) {
			this.relv_lit_tot_ps_ln_bal = relv_lit_tot_ps_ln_bal;
		}
		public String getRelv_lit_tot_trmt_rprm() {
			return relv_lit_tot_trmt_rprm;
		}
		public void setRelv_lit_tot_trmt_rprm(String relv_lit_tot_trmt_rprm) {
			this.relv_lit_tot_trmt_rprm = relv_lit_tot_trmt_rprm;
		}
		public String getRelv_lit_tot_inpl_ln_pss_aot() {
			return relv_lit_tot_inpl_ln_pss_aot;
		}
		public void setRelv_lit_tot_inpl_ln_pss_aot(String relv_lit_tot_inpl_ln_pss_aot) {
			this.relv_lit_tot_inpl_ln_pss_aot = relv_lit_tot_inpl_ln_pss_aot;
		}
		public String getStr_plno() {
			return str_plno;
		}
		public void setStr_plno(String str_plno) {
			this.str_plno = str_plno;
		}
		public String getLast_plno() {
			return last_plno;
		}
		public void setLast_plno(String last_plno) {
			this.last_plno = last_plno;
		}
		
		
		
}
