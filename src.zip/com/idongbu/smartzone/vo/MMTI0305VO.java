package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class MMTI0305VO extends CMMVO {

	public String srch_cnd__proc_dvn = "";					// [I/O] 조회조건_처리구분 (01:조회, 02:주행거리처리(변경/정산), 03:확정처리)
	public String srch_cnd__vh_no = "";						// [I/O] 조회조건_차량번호 (암호화대상)
	public String srch_cnd__plno = "";						// [I/O] 조회조건_증권번호
	public String srch_cnd__plan_no = "";					// [I/O] 조회조건_설계번호
	public String srch_cnd__bse_dt = "";					// [I/O] 조회조건_기준일자
	public String srch_cnd__trv_dstc_proc_dvcd = "";		// [I/O] 조회조건_주행거리처리구분코드
	public String srch_cnd__hdlr_empno = "";				// [I/O] 조회조건_취급자사원번호 (챗봇 확정사번: 81000176)
	
	public String srch_rsl__rtun_cd = "";					// [O] 조회결과_리턴코드
	public String srch_rsl__rtun_msg = "";					// [O] 조회결과_리턴메시지
	public String srch_rsl__plno = "";						// [O] 조회결과_증권번호
	public String srch_rsl__plan_no = "";					// [O] 조회결과_설계번호
	public String srch_rsl__pdgr_cd = "";					// [O] 조회결과_상품군코드
	public String srch_rsl__arc_pd = "";					// [O] 조회결과_보험시기
	public String srch_rsl__arc_et = "";					// [O] 조회결과_보험종기
	public String srch_rsl__plhd_cust_no_dvcd = "";			// [O] 조회결과_계약자고객번호구분코드
	public String srch_rsl__plhd_cust_no = "";				// [O] 조회결과_계약자고객번호
	public String srch_rsl__plhd_cust_dcmt_no = "";			// [O] 조회결과_계약자고객식별번호 (암호화대상)
	public String srch_rsl__plhd_nm = "";					// [O] 조회결과_계약자명
	public String srch_rsl__plhd_tlno_1 = "";				// [O] 조회결과_계약자전화번호1
	public String srch_rsl__plhd_tlno_2 = "";				// [O] 조회결과_계약자전화번호2
	public String srch_rsl__plhd_tlno_3 = "";				// [O] 조회결과_계약자전화번호3
	public String srch_rsl__plhd_dcmt_no = "";				// [O] 조회결과_계약자식별번호
	public String srch_rsl__ins_nm = "";					// [O] 조회결과_피보험자명
	public String srch_rsl__tty_eny_yn = "";				// [O] 조회결과_특약가입여부
	public String srch_rsl__frst_trv_dstc = "";				// [O] 조회결과_최초주행거리
	public String srch_rsl__frst_trv_dstc_cnfm_dd = "";		// [O] 조회결과_최초주행거리확인일
	public String srch_rsl__fnal_trv_dstc = "";				// [O] 조회결과_최종주행거리
	public String srch_rsl__fnal_trv_dstc_cnfm_dd = "";		// [O] 조회결과_최종주행거리확인일
	public String srch_rsl__exca_yn = "";					// [O] 조회결과_정산여부
	public String srch_rsl__url_if = "";					// [O] 조회결과_URL 정보
	public String srch_rsl__pbox_no = "";					// [O] 조회결과_사서함번호
	public String srch_rsl__dcs_dt = "";					// [O] 조회결과_확정일자
	public String srch_rsl__dcs_time = "";					// [O] 조회결과_확정시간
	public String srch_rsl__exp_exca_tgt_yn = "";			// [O] 조회결과_만기정산대상여부
	
	public String z_tlg_sp_cd = "";
	public String z_trns_org_cd = "";
	public String z_trns_org_dvcd = "";
	public String z_trsc_id = "";
	public String z_resp_cd = "";
	public String z_resp_msg = "";
	
	
	public String getSrch_cnd__proc_dvn() {
		return srch_cnd__proc_dvn;
	}
	public void setSrch_cnd__proc_dvn(String srch_cnd__proc_dvn) {
		this.srch_cnd__proc_dvn = srch_cnd__proc_dvn;
	}
	public String getSrch_cnd__vh_no() {
		return srch_cnd__vh_no;
	}
	public void setSrch_cnd__vh_no(String srch_cnd__vh_no) {
		this.srch_cnd__vh_no = srch_cnd__vh_no;
	}
	public String getSrch_cnd__plno() {
		return srch_cnd__plno;
	}
	public void setSrch_cnd__plno(String srch_cnd__plno) {
		this.srch_cnd__plno = srch_cnd__plno;
	}
	public String getSrch_cnd__plan_no() {
		return srch_cnd__plan_no;
	}
	public void setSrch_cnd__plan_no(String srch_cnd__plan_no) {
		this.srch_cnd__plan_no = srch_cnd__plan_no;
	}
	public String getSrch_cnd__bse_dt() {
		return srch_cnd__bse_dt;
	}
	public void setSrch_cnd__bse_dt(String srch_cnd__bse_dt) {
		this.srch_cnd__bse_dt = srch_cnd__bse_dt;
	}
	public String getSrch_cnd__trv_dstc_proc_dvcd() {
		return srch_cnd__trv_dstc_proc_dvcd;
	}
	public void setSrch_cnd__trv_dstc_proc_dvcd(String srch_cnd__trv_dstc_proc_dvcd) {
		this.srch_cnd__trv_dstc_proc_dvcd = srch_cnd__trv_dstc_proc_dvcd;
	}
	public String getSrch_cnd__hdlr_empno() {
		return srch_cnd__hdlr_empno;
	}
	public void setSrch_cnd__hdlr_empno(String srch_cnd__hdlr_empno) {
		this.srch_cnd__hdlr_empno = srch_cnd__hdlr_empno;
	}
	public String getSrch_rsl__rtun_cd() {
		return srch_rsl__rtun_cd;
	}
	public void setSrch_rsl__rtun_cd(String srch_rsl__rtun_cd) {
		this.srch_rsl__rtun_cd = srch_rsl__rtun_cd;
	}
	public String getSrch_rsl__rtun_msg() {
		return srch_rsl__rtun_msg;
	}
	public void setSrch_rsl__rtun_msg(String srch_rsl__rtun_msg) {
		this.srch_rsl__rtun_msg = srch_rsl__rtun_msg;
	}
	public String getSrch_rsl__plno() {
		return srch_rsl__plno;
	}
	public void setSrch_rsl__plno(String srch_rsl__plno) {
		this.srch_rsl__plno = srch_rsl__plno;
	}
	public String getSrch_rsl__plan_no() {
		return srch_rsl__plan_no;
	}
	public void setSrch_rsl__plan_no(String srch_rsl__plan_no) {
		this.srch_rsl__plan_no = srch_rsl__plan_no;
	}
	public String getSrch_rsl__pdgr_cd() {
		return srch_rsl__pdgr_cd;
	}
	public void setSrch_rsl__pdgr_cd(String srch_rsl__pdgr_cd) {
		this.srch_rsl__pdgr_cd = srch_rsl__pdgr_cd;
	}
	public String getSrch_rsl__arc_pd() {
		return srch_rsl__arc_pd;
	}
	public void setSrch_rsl__arc_pd(String srch_rsl__arc_pd) {
		this.srch_rsl__arc_pd = srch_rsl__arc_pd;
	}
	public String getSrch_rsl__arc_et() {
		return srch_rsl__arc_et;
	}
	public void setSrch_rsl__arc_et(String srch_rsl__arc_et) {
		this.srch_rsl__arc_et = srch_rsl__arc_et;
	}
	public String getSrch_rsl__plhd_cust_no_dvcd() {
		return srch_rsl__plhd_cust_no_dvcd;
	}
	public void setSrch_rsl__plhd_cust_no_dvcd(String srch_rsl__plhd_cust_no_dvcd) {
		this.srch_rsl__plhd_cust_no_dvcd = srch_rsl__plhd_cust_no_dvcd;
	}
	public String getSrch_rsl__plhd_cust_no() {
		return srch_rsl__plhd_cust_no;
	}
	public void setSrch_rsl__plhd_cust_no(String srch_rsl__plhd_cust_no) {
		this.srch_rsl__plhd_cust_no = srch_rsl__plhd_cust_no;
	}
	public String getSrch_rsl__plhd_cust_dcmt_no() {
		return srch_rsl__plhd_cust_dcmt_no;
	}
	public void setSrch_rsl__plhd_cust_dcmt_no(String srch_rsl__plhd_cust_dcmt_no) {
		this.srch_rsl__plhd_cust_dcmt_no = srch_rsl__plhd_cust_dcmt_no;
	}
	public String getSrch_rsl__plhd_nm() {
		return srch_rsl__plhd_nm;
	}
	public void setSrch_rsl__plhd_nm(String srch_rsl__plhd_nm) {
		this.srch_rsl__plhd_nm = srch_rsl__plhd_nm;
	}
	public String getSrch_rsl__plhd_tlno_1() {
		return srch_rsl__plhd_tlno_1;
	}
	public void setSrch_rsl__plhd_tlno_1(String srch_rsl__plhd_tlno_1) {
		this.srch_rsl__plhd_tlno_1 = srch_rsl__plhd_tlno_1;
	}
	public String getSrch_rsl__plhd_tlno_2() {
		return srch_rsl__plhd_tlno_2;
	}
	public void setSrch_rsl__plhd_tlno_2(String srch_rsl__plhd_tlno_2) {
		this.srch_rsl__plhd_tlno_2 = srch_rsl__plhd_tlno_2;
	}
	public String getSrch_rsl__plhd_tlno_3() {
		return srch_rsl__plhd_tlno_3;
	}
	public void setSrch_rsl__plhd_tlno_3(String srch_rsl__plhd_tlno_3) {
		this.srch_rsl__plhd_tlno_3 = srch_rsl__plhd_tlno_3;
	}
	public String getSrch_rsl__plhd_dcmt_no() {
		return srch_rsl__plhd_dcmt_no;
	}
	public void setSrch_rsl__plhd_dcmt_no(String srch_rsl__plhd_dcmt_no) {
		this.srch_rsl__plhd_dcmt_no = srch_rsl__plhd_dcmt_no;
	}
	public String getSrch_rsl__ins_nm() {
		return srch_rsl__ins_nm;
	}
	public void setSrch_rsl__ins_nm(String srch_rsl__ins_nm) {
		this.srch_rsl__ins_nm = srch_rsl__ins_nm;
	}
	public String getSrch_rsl__tty_eny_yn() {
		return srch_rsl__tty_eny_yn;
	}
	public void setSrch_rsl__tty_eny_yn(String srch_rsl__tty_eny_yn) {
		this.srch_rsl__tty_eny_yn = srch_rsl__tty_eny_yn;
	}
	public String getSrch_rsl__frst_trv_dstc() {
		return srch_rsl__frst_trv_dstc;
	}
	public void setSrch_rsl__frst_trv_dstc(String srch_rsl__frst_trv_dstc) {
		this.srch_rsl__frst_trv_dstc = srch_rsl__frst_trv_dstc;
	}
	public String getSrch_rsl__frst_trv_dstc_cnfm_dd() {
		return srch_rsl__frst_trv_dstc_cnfm_dd;
	}
	public void setSrch_rsl__frst_trv_dstc_cnfm_dd(String srch_rsl__frst_trv_dstc_cnfm_dd) {
		this.srch_rsl__frst_trv_dstc_cnfm_dd = srch_rsl__frst_trv_dstc_cnfm_dd;
	}
	public String getSrch_rsl__fnal_trv_dstc() {
		return srch_rsl__fnal_trv_dstc;
	}
	public void setSrch_rsl__fnal_trv_dstc(String srch_rsl__fnal_trv_dstc) {
		this.srch_rsl__fnal_trv_dstc = srch_rsl__fnal_trv_dstc;
	}
	public String getSrch_rsl__fnal_trv_dstc_cnfm_dd() {
		return srch_rsl__fnal_trv_dstc_cnfm_dd;
	}
	public void setSrch_rsl__fnal_trv_dstc_cnfm_dd(String srch_rsl__fnal_trv_dstc_cnfm_dd) {
		this.srch_rsl__fnal_trv_dstc_cnfm_dd = srch_rsl__fnal_trv_dstc_cnfm_dd;
	}
	public String getSrch_rsl__exca_yn() {
		return srch_rsl__exca_yn;
	}
	public void setSrch_rsl__exca_yn(String srch_rsl__exca_yn) {
		this.srch_rsl__exca_yn = srch_rsl__exca_yn;
	}
	public String getSrch_rsl__url_if() {
		return srch_rsl__url_if;
	}
	public void setSrch_rsl__url_if(String srch_rsl__url_if) {
		this.srch_rsl__url_if = srch_rsl__url_if;
	}
	public String getSrch_rsl__pbox_no() {
		return srch_rsl__pbox_no;
	}
	public void setSrch_rsl__pbox_no(String srch_rsl__pbox_no) {
		this.srch_rsl__pbox_no = srch_rsl__pbox_no;
	}
	public String getSrch_rsl__dcs_dt() {
		return srch_rsl__dcs_dt;
	}
	public void setSrch_rsl__dcs_dt(String srch_rsl__dcs_dt) {
		this.srch_rsl__dcs_dt = srch_rsl__dcs_dt;
	}
	public String getSrch_rsl__dcs_time() {
		return srch_rsl__dcs_time;
	}
	public void setSrch_rsl__dcs_time(String srch_rsl__dcs_time) {
		this.srch_rsl__dcs_time = srch_rsl__dcs_time;
	}
	public String getSrch_rsl__exp_exca_tgt_yn() {
		return srch_rsl__exp_exca_tgt_yn;
	}
	public void setSrch_rsl__exp_exca_tgt_yn(String srch_rsl__exp_exca_tgt_yn) {
		this.srch_rsl__exp_exca_tgt_yn = srch_rsl__exp_exca_tgt_yn;
	}
	public String getZ_tlg_sp_cd() {
		return z_tlg_sp_cd;
	}
	public void setZ_tlg_sp_cd(String z_tlg_sp_cd) {
		this.z_tlg_sp_cd = z_tlg_sp_cd;
	}
	public String getZ_trns_org_cd() {
		return z_trns_org_cd;
	}
	public void setZ_trns_org_cd(String z_trns_org_cd) {
		this.z_trns_org_cd = z_trns_org_cd;
	}
	public String getZ_trns_org_dvcd() {
		return z_trns_org_dvcd;
	}
	public void setZ_trns_org_dvcd(String z_trns_org_dvcd) {
		this.z_trns_org_dvcd = z_trns_org_dvcd;
	}
	public String getZ_trsc_id() {
		return z_trsc_id;
	}
	public void setZ_trsc_id(String z_trsc_id) {
		this.z_trsc_id = z_trsc_id;
	}
	public String getZ_resp_cd() {
		return z_resp_cd;
	}
	public void setZ_resp_cd(String z_resp_cd) {
		this.z_resp_cd = z_resp_cd;
	}
	public String getZ_resp_msg() {
		return z_resp_msg;
	}
	public void setZ_resp_msg(String z_resp_msg) {
		this.z_resp_msg = z_resp_msg;
	}
	
}
