package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class LLTI0250VO extends CMMVO{
	
	public String outp_slc = "";			//[I]출력선택
	public String plno = "";				//[I]증권번호
	public String ins_lcpl_dvcd = "";				//[I]증권번호
	public String ply_sqno = "";				//[I]증권번호
	public String fom_nm = "";				//[O]폼명
	public String apl_dt_str = "";			//[I]청약일자시작
	public String apl_dt_last = "";			//[I]청약일자마지막
	public String bzlv_no = "";				//[I]사업단번호
	public String bh_no = "";				//[I]지점번호
	public String pdc_cd = "";				//[I]상품코드
	public String ipmn_empno = "";			//[I]입력자사원번호
	public String outp_dta_last_dvn = "";	//[O]출력데이터마지막구분
	public String rei_dvn = "";				//[I]재발급구분
	public String ply_yn = "";				//[O]증권여부
	public String cpy_yn = "";				//[O]복사여부
	public String grn_yn = "";				//[O]녹색여부
	public String ecde_yn = "";				//[O]암호화여부
	public String ecde_key = "";			//[O]암호화키
	public String bz_dvn = "";				//[O]업무구분
	public String doc_dvn = "";				//[O]문서구분
	public String sig_key = "";				//[O]서명키
	public String fom_dvn = "";				//[O]폼구분
	
	public String errorCode = "";
	public String returnMessage = "";
	
	
	
	public String getIns_lcpl_dvcd() {
		return ins_lcpl_dvcd;
	}
	public void setIns_lcpl_dvcd(String ins_lcpl_dvcd) {
		this.ins_lcpl_dvcd = ins_lcpl_dvcd;
	}
	public String getPly_sqno() {
		return ply_sqno;
	}
	public void setPly_sqno(String ply_sqno) {
		this.ply_sqno = ply_sqno;
	}
	public String getOutp_slc() {
		return outp_slc;
	}
	public void setOutp_slc(String outp_slc) {
		this.outp_slc = outp_slc;
	}
	public String getPlno() {
		return plno;
	}
	public void setPlno(String plno) {
		this.plno = plno;
	}
	public String getFom_nm() {
		return fom_nm;
	}
	public void setFom_nm(String fom_nm) {
		this.fom_nm = fom_nm;
	}
	public String getApl_dt_str() {
		return apl_dt_str;
	}
	public void setApl_dt_str(String apl_dt_str) {
		this.apl_dt_str = apl_dt_str;
	}
	public String getApl_dt_last() {
		return apl_dt_last;
	}
	public void setApl_dt_last(String apl_dt_last) {
		this.apl_dt_last = apl_dt_last;
	}
	public String getBzlv_no() {
		return bzlv_no;
	}
	public void setBzlv_no(String bzlv_no) {
		this.bzlv_no = bzlv_no;
	}
	public String getBh_no() {
		return bh_no;
	}
	public void setBh_no(String bh_no) {
		this.bh_no = bh_no;
	}
	public String getPdc_cd() {
		return pdc_cd;
	}
	public void setPdc_cd(String pdc_cd) {
		this.pdc_cd = pdc_cd;
	}
	public String getIpmn_empno() {
		return ipmn_empno;
	}
	public void setIpmn_empno(String ipmn_empno) {
		this.ipmn_empno = ipmn_empno;
	}
	public String getOutp_dta_last_dvn() {
		return outp_dta_last_dvn;
	}
	public void setOutp_dta_last_dvn(String outp_dta_last_dvn) {
		this.outp_dta_last_dvn = outp_dta_last_dvn;
	}
	public String getRei_dvn() {
		return rei_dvn;
	}
	public void setRei_dvn(String rei_dvn) {
		this.rei_dvn = rei_dvn;
	}
	public String getPly_yn() {
		return ply_yn;
	}
	public void setPly_yn(String ply_yn) {
		this.ply_yn = ply_yn;
	}
	public String getCpy_yn() {
		return cpy_yn;
	}
	public void setCpy_yn(String cpy_yn) {
		this.cpy_yn = cpy_yn;
	}
	public String getGrn_yn() {
		return grn_yn;
	}
	public void setGrn_yn(String grn_yn) {
		this.grn_yn = grn_yn;
	}
	public String getEcde_yn() {
		return ecde_yn;
	}
	public void setEcde_yn(String ecde_yn) {
		this.ecde_yn = ecde_yn;
	}
	public String getEcde_key() {
		return ecde_key;
	}
	public void setEcde_key(String ecde_key) {
		this.ecde_key = ecde_key;
	}
	public String getBz_dvn() {
		return bz_dvn;
	}
	public void setBz_dvn(String bz_dvn) {
		this.bz_dvn = bz_dvn;
	}
	public String getDoc_dvn() {
		return doc_dvn;
	}
	public void setDoc_dvn(String doc_dvn) {
		this.doc_dvn = doc_dvn;
	}
	public String getSig_key() {
		return sig_key;
	}
	public void setSig_key(String sig_key) {
		this.sig_key = sig_key;
	}
	public String getFom_dvn() {
		return fom_dvn;
	}
	public void setFom_dvn(String fom_dvn) {
		this.fom_dvn = fom_dvn;
	}
	
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getReturnMessage() {
		return returnMessage;
	}
	public void setReturnMessage(String returnMessage) {
		this.returnMessage = returnMessage;
	}
	
	
}
