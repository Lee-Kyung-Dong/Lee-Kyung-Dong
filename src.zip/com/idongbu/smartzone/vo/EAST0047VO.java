package com.idongbu.smartzone.vo;

import java.util.ArrayList;

import com.idongbu.common.vo.CMMVO;

public class EAST0047VO extends CMMVO{
		public String bz_dvn = "";
		public String chn_dvcd = "";
		public String cust_nm = "";
		public String rrno = "";
		public String proc_dvn = "";
		public String oupr_nm = "";
		public String oupr_empno = "";
		public String oupr_bh_cd = "";
		public String cltd_yr = "";
		public String cltd_mon = "";
		public String cltd_dd = "";
		public String rsdn_btpy_no2 = "";
		public String ln_aply_amtt = "";
		public String real_pyms_aot_sm = "";
		public String rmn_bank_nm = "";
		public String rmn_acc_no = "";
		public String rmn_dpsr_nm = "";
		public String rmn_cust_rsdn_no = "";
		public String coll_bank_nm = "";
		public String coll_acc_no = "";
		public String coll_dpsr_nm = "";
		public String coll_cust_rsdn_no = "";
		public String coll_tsfr_dd = "";
		public String aplc = "";
		public String bcd = "";
		
		public String[] arc_ctc_ln_aply_pyn_mngt_lit__plno = new String[0];
		public String[] arc_ctc_ln_aply_pyn_mngt_lit__ins_lcpl_dvcd = new String[0];
		public String[] arc_ctc_ln_aply_pyn_mngt_lit__ply_sqno = new String[0];
		public String[] arc_ctc_ln_aply_pyn_mngt_lit__ins_lcpl_ply_sqno = new String[0];
		public String[] arc_ctc_ln_aply_pyn_mngt_lit__pdc_nm = new String[0];
		public String[] arc_ctc_ln_aply_pyn_mngt_lit__ln_irt = new String[0];
		public String[] arc_ctc_ln_aply_pyn_mngt_lit__irate_dvn = new String[0];
		public String[] arc_ctc_ln_aply_pyn_mngt_lit__ps_ln_amt = new String[0];
		public String[] arc_ctc_ln_aply_pyn_mngt_lit__ln_aply_amt = new String[0];
		public String[] arc_ctc_ln_aply_pyn_mngt_lit__rcog_tx_nn_incn_dct_inte = new String[0];
		public String[] arc_ctc_ln_aply_pyn_mngt_lit__rcog_tx = new String[0];
		public String[] arc_ctc_ln_aply_pyn_mngt_lit__real_pyat = new String[0];
		public String[] arc_ctc_ln_aply_pyn_mngt_lit__ln_af_pss_bal = new String[0];
		public String[] arc_ctc_ln_aply_pyn_mngt_lit__slp_no = new String[0];
		public String getBz_dvn() {
			return bz_dvn;
		}
		public void setBz_dvn(String bz_dvn) {
			this.bz_dvn = bz_dvn;
		}
		public String getChn_dvcd() {
			return chn_dvcd;
		}
		public void setChn_dvcd(String chn_dvcd) {
			this.chn_dvcd = chn_dvcd;
		}
		public String getCust_nm() {
			return cust_nm;
		}
		public void setCust_nm(String cust_nm) {
			this.cust_nm = cust_nm;
		}
		public String getRrno() {
			return rrno;
		}
		public void setRrno(String rrno) {
			this.rrno = rrno;
		}
		public String getProc_dvn() {
			return proc_dvn;
		}
		public void setProc_dvn(String proc_dvn) {
			this.proc_dvn = proc_dvn;
		}
		public String getOupr_nm() {
			return oupr_nm;
		}
		public void setOupr_nm(String oupr_nm) {
			this.oupr_nm = oupr_nm;
		}
		public String getOupr_empno() {
			return oupr_empno;
		}
		public void setOupr_empno(String oupr_empno) {
			this.oupr_empno = oupr_empno;
		}
		public String getOupr_bh_cd() {
			return oupr_bh_cd;
		}
		public void setOupr_bh_cd(String oupr_bh_cd) {
			this.oupr_bh_cd = oupr_bh_cd;
		}
		public String getCltd_yr() {
			return cltd_yr;
		}
		public void setCltd_yr(String cltd_yr) {
			this.cltd_yr = cltd_yr;
		}
		public String getCltd_mon() {
			return cltd_mon;
		}
		public void setCltd_mon(String cltd_mon) {
			this.cltd_mon = cltd_mon;
		}
		public String getCltd_dd() {
			return cltd_dd;
		}
		public void setCltd_dd(String cltd_dd) {
			this.cltd_dd = cltd_dd;
		}
		public String getRsdn_btpy_no2() {
			return rsdn_btpy_no2;
		}
		public void setRsdn_btpy_no2(String rsdn_btpy_no2) {
			this.rsdn_btpy_no2 = rsdn_btpy_no2;
		}
		public String getLn_aply_amtt() {
			return ln_aply_amtt;
		}
		public void setLn_aply_amtt(String ln_aply_amtt) {
			this.ln_aply_amtt = ln_aply_amtt;
		}
		public String getReal_pyms_aot_sm() {
			return real_pyms_aot_sm;
		}
		public void setReal_pyms_aot_sm(String real_pyms_aot_sm) {
			this.real_pyms_aot_sm = real_pyms_aot_sm;
		}
		public String getRmn_bank_nm() {
			return rmn_bank_nm;
		}
		public void setRmn_bank_nm(String rmn_bank_nm) {
			this.rmn_bank_nm = rmn_bank_nm;
		}
		public String getRmn_acc_no() {
			return rmn_acc_no;
		}
		public void setRmn_acc_no(String rmn_acc_no) {
			this.rmn_acc_no = rmn_acc_no;
		}
		public String getRmn_dpsr_nm() {
			return rmn_dpsr_nm;
		}
		public void setRmn_dpsr_nm(String rmn_dpsr_nm) {
			this.rmn_dpsr_nm = rmn_dpsr_nm;
		}
		public String getRmn_cust_rsdn_no() {
			return rmn_cust_rsdn_no;
		}
		public void setRmn_cust_rsdn_no(String rmn_cust_rsdn_no) {
			this.rmn_cust_rsdn_no = rmn_cust_rsdn_no;
		}
		public String getColl_bank_nm() {
			return coll_bank_nm;
		}
		public void setColl_bank_nm(String coll_bank_nm) {
			this.coll_bank_nm = coll_bank_nm;
		}
		public String getColl_acc_no() {
			return coll_acc_no;
		}
		public void setColl_acc_no(String coll_acc_no) {
			this.coll_acc_no = coll_acc_no;
		}
		public String getColl_dpsr_nm() {
			return coll_dpsr_nm;
		}
		public void setColl_dpsr_nm(String coll_dpsr_nm) {
			this.coll_dpsr_nm = coll_dpsr_nm;
		}
		public String getColl_cust_rsdn_no() {
			return coll_cust_rsdn_no;
		}
		public void setColl_cust_rsdn_no(String coll_cust_rsdn_no) {
			this.coll_cust_rsdn_no = coll_cust_rsdn_no;
		}
		public String getColl_tsfr_dd() {
			return coll_tsfr_dd;
		}
		public void setColl_tsfr_dd(String coll_tsfr_dd) {
			this.coll_tsfr_dd = coll_tsfr_dd;
		}
		public String getAplc() {
			return aplc;
		}
		public void setAplc(String aplc) {
			this.aplc = aplc;
		}
		public String getBcd() {
			return bcd;
		}
		public void setBcd(String bcd) {
			this.bcd = bcd;
		}
		public String[] getArc_ctc_ln_aply_pyn_mngt_lit__plno() {
			return arc_ctc_ln_aply_pyn_mngt_lit__plno;
		}
		public void setArc_ctc_ln_aply_pyn_mngt_lit__plno(
				String[] arc_ctc_ln_aply_pyn_mngt_lit__plno) {
			this.arc_ctc_ln_aply_pyn_mngt_lit__plno = arc_ctc_ln_aply_pyn_mngt_lit__plno;
		}
		public String[] getArc_ctc_ln_aply_pyn_mngt_lit__ins_lcpl_dvcd() {
			return arc_ctc_ln_aply_pyn_mngt_lit__ins_lcpl_dvcd;
		}
		public void setArc_ctc_ln_aply_pyn_mngt_lit__ins_lcpl_dvcd(
				String[] arc_ctc_ln_aply_pyn_mngt_lit__ins_lcpl_dvcd) {
			this.arc_ctc_ln_aply_pyn_mngt_lit__ins_lcpl_dvcd = arc_ctc_ln_aply_pyn_mngt_lit__ins_lcpl_dvcd;
		}
		public String[] getArc_ctc_ln_aply_pyn_mngt_lit__ply_sqno() {
			return arc_ctc_ln_aply_pyn_mngt_lit__ply_sqno;
		}
		public void setArc_ctc_ln_aply_pyn_mngt_lit__ply_sqno(
				String[] arc_ctc_ln_aply_pyn_mngt_lit__ply_sqno) {
			this.arc_ctc_ln_aply_pyn_mngt_lit__ply_sqno = arc_ctc_ln_aply_pyn_mngt_lit__ply_sqno;
		}
		public String[] getArc_ctc_ln_aply_pyn_mngt_lit__ins_lcpl_ply_sqno() {
			return arc_ctc_ln_aply_pyn_mngt_lit__ins_lcpl_ply_sqno;
		}
		public void setArc_ctc_ln_aply_pyn_mngt_lit__ins_lcpl_ply_sqno(
				String[] arc_ctc_ln_aply_pyn_mngt_lit__ins_lcpl_ply_sqno) {
			this.arc_ctc_ln_aply_pyn_mngt_lit__ins_lcpl_ply_sqno = arc_ctc_ln_aply_pyn_mngt_lit__ins_lcpl_ply_sqno;
		}
		public String[] getArc_ctc_ln_aply_pyn_mngt_lit__pdc_nm() {
			return arc_ctc_ln_aply_pyn_mngt_lit__pdc_nm;
		}
		public void setArc_ctc_ln_aply_pyn_mngt_lit__pdc_nm(
				String[] arc_ctc_ln_aply_pyn_mngt_lit__pdc_nm) {
			this.arc_ctc_ln_aply_pyn_mngt_lit__pdc_nm = arc_ctc_ln_aply_pyn_mngt_lit__pdc_nm;
		}
		public String[] getArc_ctc_ln_aply_pyn_mngt_lit__ln_irt() {
			return arc_ctc_ln_aply_pyn_mngt_lit__ln_irt;
		}
		public void setArc_ctc_ln_aply_pyn_mngt_lit__ln_irt(
				String[] arc_ctc_ln_aply_pyn_mngt_lit__ln_irt) {
			this.arc_ctc_ln_aply_pyn_mngt_lit__ln_irt = arc_ctc_ln_aply_pyn_mngt_lit__ln_irt;
		}
		public String[] getArc_ctc_ln_aply_pyn_mngt_lit__irate_dvn() {
			return arc_ctc_ln_aply_pyn_mngt_lit__irate_dvn;
		}
		public void setArc_ctc_ln_aply_pyn_mngt_lit__irate_dvn(
				String[] arc_ctc_ln_aply_pyn_mngt_lit__irate_dvn) {
			this.arc_ctc_ln_aply_pyn_mngt_lit__irate_dvn = arc_ctc_ln_aply_pyn_mngt_lit__irate_dvn;
		}
		public String[] getArc_ctc_ln_aply_pyn_mngt_lit__ps_ln_amt() {
			return arc_ctc_ln_aply_pyn_mngt_lit__ps_ln_amt;
		}
		public void setArc_ctc_ln_aply_pyn_mngt_lit__ps_ln_amt(
				String[] arc_ctc_ln_aply_pyn_mngt_lit__ps_ln_amt) {
			this.arc_ctc_ln_aply_pyn_mngt_lit__ps_ln_amt = arc_ctc_ln_aply_pyn_mngt_lit__ps_ln_amt;
		}
		public String[] getArc_ctc_ln_aply_pyn_mngt_lit__ln_aply_amt() {
			return arc_ctc_ln_aply_pyn_mngt_lit__ln_aply_amt;
		}
		public void setArc_ctc_ln_aply_pyn_mngt_lit__ln_aply_amt(
				String[] arc_ctc_ln_aply_pyn_mngt_lit__ln_aply_amt) {
			this.arc_ctc_ln_aply_pyn_mngt_lit__ln_aply_amt = arc_ctc_ln_aply_pyn_mngt_lit__ln_aply_amt;
		}
		public String[] getArc_ctc_ln_aply_pyn_mngt_lit__rcog_tx_nn_incn_dct_inte() {
			return arc_ctc_ln_aply_pyn_mngt_lit__rcog_tx_nn_incn_dct_inte;
		}
		public void setArc_ctc_ln_aply_pyn_mngt_lit__rcog_tx_nn_incn_dct_inte(
				String[] arc_ctc_ln_aply_pyn_mngt_lit__rcog_tx_nn_incn_dct_inte) {
			this.arc_ctc_ln_aply_pyn_mngt_lit__rcog_tx_nn_incn_dct_inte = arc_ctc_ln_aply_pyn_mngt_lit__rcog_tx_nn_incn_dct_inte;
		}
		public String[] getArc_ctc_ln_aply_pyn_mngt_lit__rcog_tx() {
			return arc_ctc_ln_aply_pyn_mngt_lit__rcog_tx;
		}
		public void setArc_ctc_ln_aply_pyn_mngt_lit__rcog_tx(
				String[] arc_ctc_ln_aply_pyn_mngt_lit__rcog_tx) {
			this.arc_ctc_ln_aply_pyn_mngt_lit__rcog_tx = arc_ctc_ln_aply_pyn_mngt_lit__rcog_tx;
		}
		public String[] getArc_ctc_ln_aply_pyn_mngt_lit__real_pyat() {
			return arc_ctc_ln_aply_pyn_mngt_lit__real_pyat;
		}
		public void setArc_ctc_ln_aply_pyn_mngt_lit__real_pyat(
				String[] arc_ctc_ln_aply_pyn_mngt_lit__real_pyat) {
			this.arc_ctc_ln_aply_pyn_mngt_lit__real_pyat = arc_ctc_ln_aply_pyn_mngt_lit__real_pyat;
		}
		public String[] getArc_ctc_ln_aply_pyn_mngt_lit__ln_af_pss_bal() {
			return arc_ctc_ln_aply_pyn_mngt_lit__ln_af_pss_bal;
		}
		public void setArc_ctc_ln_aply_pyn_mngt_lit__ln_af_pss_bal(
				String[] arc_ctc_ln_aply_pyn_mngt_lit__ln_af_pss_bal) {
			this.arc_ctc_ln_aply_pyn_mngt_lit__ln_af_pss_bal = arc_ctc_ln_aply_pyn_mngt_lit__ln_af_pss_bal;
		}
		public String[] getArc_ctc_ln_aply_pyn_mngt_lit__slp_no() {
			return arc_ctc_ln_aply_pyn_mngt_lit__slp_no;
		}
		public void setArc_ctc_ln_aply_pyn_mngt_lit__slp_no(
				String[] arc_ctc_ln_aply_pyn_mngt_lit__slp_no) {
			this.arc_ctc_ln_aply_pyn_mngt_lit__slp_no = arc_ctc_ln_aply_pyn_mngt_lit__slp_no;
		}
		
		
		
		
		
		
		
		
}
