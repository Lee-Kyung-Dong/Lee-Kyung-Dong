package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class MMTI0101VO extends CMMVO{
	
	public String blco_bz_proc_dvn = null;			// 경계업무처리구분
	public String funt_key = null;					// 기능키
	public String plno = null;						// 증번
	public String ctrmf_rs_dvn_rsvn_chng = null;	// 계약변경사유구분정정변경
	public String ctrmf_bse_dd = null;				// 계약변경기준일
	public String bsec_chng_fin_dt = null;			// 구간변경종료일자
	
	public String inpd_nm = null;					// 보종명
	public String hngl_vh_no = null;				// 한글차량번호
	public String arc_pd = null;					// 보험시기
	public String arc_et = null;					// 보험종기
	public String ctc_stat_nm = null;				// 계약상태명
	public String ins_nm = null;					// 피보험자명
	public String plhd_cust_nm = null;				// 계약자명
	
	public String drvr_rstc_tty_cd = null;			// 운전자한정특약코드
	public String ag_tty_cd = null;					// 연령특약코드
	
	public String uw_ap_dvn = null;					// 인수심사승인구분
	public String adc_prm = null;					// 추징보험료
	public String adc_rtrn_dvn = null;				// 추징환급구분
	
	public String ctrmf_plan_no = null;				// 계약변경설계번호
	public String dsgn_cd = null;					// 설계자사번
	
	public String errorCode = null;
	public String z_msg_cd = null;
	public String z_resp_msg = null;
	public String returnMesssage = null;
	public String z_resp_cd = null;

	
	public String getBlco_bz_proc_dvn() {
		return blco_bz_proc_dvn;
	}
	public void setBlco_bz_proc_dvn(String blco_bz_proc_dvn) {
		this.blco_bz_proc_dvn = blco_bz_proc_dvn;
	}
	public String getFunt_key() {
		return funt_key;
	}
	public void setFunt_key(String funt_key) {
		this.funt_key = funt_key;
	}
	public String getPlno() {
		return plno;
	}
	public void setPlno(String plno) {
		this.plno = plno;
	}
	public String getInpd_nm() {
		return inpd_nm;
	}
	public void setInpd_nm(String inpd_nm) {
		this.inpd_nm = inpd_nm;
	}
	public String getHngl_vh_no() {
		return hngl_vh_no;
	}
	public void setHngl_vh_no(String hngl_vh_no) {
		this.hngl_vh_no = hngl_vh_no;
	}
	public String getArc_pd() {
		return arc_pd;
	}
	public void setArc_pd(String arc_pd) {
		this.arc_pd = arc_pd;
	}
	public String getArc_et() {
		return arc_et;
	}
	public void setArc_et(String arc_et) {
		this.arc_et = arc_et;
	}
	public String getCtc_stat_nm() {
		return ctc_stat_nm;
	}
	public void setCtc_stat_nm(String ctc_stat_nm) {
		this.ctc_stat_nm = ctc_stat_nm;
	}
	public String getIns_nm() {
		return ins_nm;
	}
	public void setIns_nm(String ins_nm) {
		this.ins_nm = ins_nm;
	}
	public String getPlhd_cust_nm() {
		return plhd_cust_nm;
	}
	public void setPlhd_cust_nm(String plhd_cust_nm) {
		this.plhd_cust_nm = plhd_cust_nm;
	}
	public String getDrvr_rstc_tty_cd() {
		return drvr_rstc_tty_cd;
	}
	public void setDrvr_rstc_tty_cd(String drvr_rstc_tty_cd) {
		this.drvr_rstc_tty_cd = drvr_rstc_tty_cd;
	}
	public String getAg_tty_cd() {
		return ag_tty_cd;
	}
	public void setAg_tty_cd(String ag_tty_cd) {
		this.ag_tty_cd = ag_tty_cd;
	}
	public String getCtrmf_rs_dvn_rsvn_chng() {
		return ctrmf_rs_dvn_rsvn_chng;
	}
	public void setCtrmf_rs_dvn_rsvn_chng(String ctrmf_rs_dvn_rsvn_chng) {
		this.ctrmf_rs_dvn_rsvn_chng = ctrmf_rs_dvn_rsvn_chng;
	}
	public String getCtrmf_bse_dd() {
		return ctrmf_bse_dd;
	}
	public void setCtrmf_bse_dd(String ctrmf_bse_dd) {
		this.ctrmf_bse_dd = ctrmf_bse_dd;
	}
	public String getBsec_chng_fin_dt() {
		return bsec_chng_fin_dt;
	}
	public void setBsec_chng_fin_dt(String bsec_chng_fin_dt) {
		this.bsec_chng_fin_dt = bsec_chng_fin_dt;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getZ_msg_cd() {
		return z_msg_cd;
	}
	public void setZ_msg_cd(String z_msg_cd) {
		this.z_msg_cd = z_msg_cd;
	}
	public String getZ_resp_msg() {
		return z_resp_msg;
	}
	public void setZ_resp_msg(String z_resp_msg) {
		this.z_resp_msg = z_resp_msg;
	}
	public String getReturnMesssage() {
		return returnMesssage;
	}
	public void setReturnMesssage(String returnMesssage) {
		this.returnMesssage = returnMesssage;
	}
	public String getUw_ap_dvn() {
		return uw_ap_dvn;
	}
	public void setUw_ap_dvn(String uw_ap_dvn) {
		this.uw_ap_dvn = uw_ap_dvn;
	}
	public String getAdc_prm() {
		return adc_prm;
	}
	public void setAdc_prm(String adc_prm) {
		this.adc_prm = adc_prm;
	}
	public String getAdc_rtrn_dvn() {
		return adc_rtrn_dvn;
	}
	public void setAdc_rtrn_dvn(String adc_rtrn_dvn) {
		this.adc_rtrn_dvn = adc_rtrn_dvn;
	}
	public String getCtrmf_plan_no() {
		return ctrmf_plan_no;
	}
	public void setCtrmf_plan_no(String ctrmf_plan_no) {
		this.ctrmf_plan_no = ctrmf_plan_no;
	}
	public String getDsgn_cd() {
		return dsgn_cd;
	}
	public void setDsgn_cd(String dsgn_cd) {
		this.dsgn_cd = dsgn_cd;
	}
	public String getZ_resp_cd() {
		return z_resp_cd;
	}
	public void setZ_resp_cd(String z_resp_cd) {
		this.z_resp_cd = z_resp_cd;
	}
	
}
