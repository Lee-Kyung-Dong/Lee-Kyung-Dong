package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class MMTI0220VO extends CMMVO{
	//전문필드
		public String slc_dvn = "";  //[I/O] 선택구분 SCR_SELECT_GB    
		public String crtf_knd = "";  //[I/O] 증명서종류 SCR_GUBUN        증명서종류
		public String vh_no = "";  //[I/O] 차량번호 H_SCR_CAR_NO     차량번호
		public String ins_cd = "";  //[I/O] 피보험자코드 SCR_PIBOHUMJA_CD 피보험자코드
		public String plan_no = "";  //[I/O] 설계번호 SCR_SULGYE_NO    설계번호
		public String plno = "";  //[I/O] 증권번호 SCR_POLI_NO      증권번호
		public String seal_yn = "";  //[I/O] 직인여부 SCR_JIKIN_YN     
		public String adr_yn = "";  //[I/O] 주소여부 SCR_JUSO_YN      
		public String trt_yn = "";  //[I/O] 요율여부 SCR_YOYUL_YN     
		public String prm_yn = "";  //[I/O] 보험료여부 SCR_PRM_YN 
		public String tty_yn = "";  //[I/O] 특약여부 SCR_TUKYAK_YN    
		public String prnt = "";  //[O] 프린터 SCR_PRINTER      
		public String ins_nm = "";  //[O] 피보험자명 H_SCR_GOGEK_NAME 피보험자
		public String arc_trm_pd = "";  //[O] 보험기간시기 SCR_BOHUM_SYMD   보험기간시기
		public String arc_trm_et = "";  //[O] 보험기간종기 SCR_BOHUM_EYMD   보험기간종기
		public String arc_tp = "";  //[O] 보험종목 H_SCR_BJ_NAME    보험종목
		public String chn_cd = "";  //[O] 채널코드 SCR_CHANNEL_CD   채널코드
		public String cust_no_dvn = "";  //[O] 고객번호구분 SCR_GOGEK_NO_GB  고객번호구분
		public String cust_no = "";  //[O] 고객번호 SCR_GOGEK_NO     고객번호
		public String plhd_ml_adr = "";  //[O] 계약자메일주소 SCR_GYE_E_MAIL   계약자 이메일주소
		public String ins_ml_adr = "";  //[O] 피보험자메일주소 SCR_PIB_E_MAIL   피보험자 이메일주소
		public String plhd_nm = "";  //[O] 계약자명 H_SCR_GYEYK_NAME 계약자명
		public String getSlc_dvn() {
			return slc_dvn;
		}
		public void setSlc_dvn(String slc_dvn) {
			this.slc_dvn = slc_dvn;
		}
		public String getCrtf_knd() {
			return crtf_knd;
		}
		public void setCrtf_knd(String crtf_knd) {
			this.crtf_knd = crtf_knd;
		}
		public String getVh_no() {
			return vh_no;
		}
		public void setVh_no(String vh_no) {
			this.vh_no = vh_no;
		}
		public String getIns_cd() {
			return ins_cd;
		}
		public void setIns_cd(String ins_cd) {
			this.ins_cd = ins_cd;
		}
		public String getPlan_no() {
			return plan_no;
		}
		public void setPlan_no(String plan_no) {
			this.plan_no = plan_no;
		}
		public String getPlno() {
			return plno;
		}
		public void setPlno(String plno) {
			this.plno = plno;
		}
		public String getSeal_yn() {
			return seal_yn;
		}
		public void setSeal_yn(String seal_yn) {
			this.seal_yn = seal_yn;
		}
		public String getAdr_yn() {
			return adr_yn;
		}
		public void setAdr_yn(String adr_yn) {
			this.adr_yn = adr_yn;
		}
		public String getTrt_yn() {
			return trt_yn;
		}
		public void setTrt_yn(String trt_yn) {
			this.trt_yn = trt_yn;
		}
		public String getPrm_yn() {
			return prm_yn;
		}
		public void setPrm_yn(String prm_yn) {
			this.prm_yn = prm_yn;
		}
		public String getTty_yn() {
			return tty_yn;
		}
		public void setTty_yn(String tty_yn) {
			this.tty_yn = tty_yn;
		}
		public String getPrnt() {
			return prnt;
		}
		public void setPrnt(String prnt) {
			this.prnt = prnt;
		}
		public String getIns_nm() {
			return ins_nm;
		}
		public void setIns_nm(String ins_nm) {
			this.ins_nm = ins_nm;
		}
		public String getArc_trm_pd() {
			return arc_trm_pd;
		}
		public void setArc_trm_pd(String arc_trm_pd) {
			this.arc_trm_pd = arc_trm_pd;
		}
		public String getArc_trm_et() {
			return arc_trm_et;
		}
		public void setArc_trm_et(String arc_trm_et) {
			this.arc_trm_et = arc_trm_et;
		}
		public String getArc_tp() {
			return arc_tp;
		}
		public void setArc_tp(String arc_tp) {
			this.arc_tp = arc_tp;
		}
		public String getChn_cd() {
			return chn_cd;
		}
		public void setChn_cd(String chn_cd) {
			this.chn_cd = chn_cd;
		}
		public String getCust_no_dvn() {
			return cust_no_dvn;
		}
		public void setCust_no_dvn(String cust_no_dvn) {
			this.cust_no_dvn = cust_no_dvn;
		}
		public String getCust_no() {
			return cust_no;
		}
		public void setCust_no(String cust_no) {
			this.cust_no = cust_no;
		}
		public String getPlhd_ml_adr() {
			return plhd_ml_adr;
		}
		public void setPlhd_ml_adr(String plhd_ml_adr) {
			this.plhd_ml_adr = plhd_ml_adr;
		}
		public String getIns_ml_adr() {
			return ins_ml_adr;
		}
		public void setIns_ml_adr(String ins_ml_adr) {
			this.ins_ml_adr = ins_ml_adr;
		}
		public String getPlhd_nm() {
			return plhd_nm;
		}
		public void setPlhd_nm(String plhd_nm) {
			this.plhd_nm = plhd_nm;
		}
		
		

}
