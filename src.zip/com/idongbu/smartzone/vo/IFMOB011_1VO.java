package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class IFMOB011_1VO extends CMMVO {
    public String webM = "IF_MOB_011_1";

    // 입력
    public String I_SSN = null;				        // 주민번호
    public String I_CUST_NM = null;			        // 고객명
    public String I_APY_YMD = null;			        // 평가일자
    public String I_PICD = null;			        // 상품코드
    public String I_COLL_KCD = null;		        // 담보분류	- 고정값 : 20(신용)
    public String I_COLL_ATT_CD = null;		        // 담보세분류 - 고정값 : 21(신용)
    public String I_INCM_PRF = null; 		        // 증빙소득금액
    public String I_CRD_AGR_1 = null;		        // 개인(신용)정보 수집/이용/처리 동의
    public String I_CRD_AGR_2 = null;		        // 개인(신용)정보 제공/조회/처리 동의
    public String I_EVAL_GB = null;			        // CSS평가구분(1:상담조회, 2:심사조회)
    public String I_CRD_AGR_3 = null;               // 필수 금융거래설정 개인정보 수집/이용 동의
    public String I_CRD_AGR_4 = null;               // 필수 금융거래설정 개인정보 제공 동의
    public String I_CRD_AGR_5 = null;               // 필수 상품별 개인정보 수집/이용 동의
    public String I_CRD_AGR_6 = null;               // 선택 금융거래설정 개인정보 수집/이용 동의
    public String I_MKT_AGR_1 = null;               // 상품서비스안내 동의(수집/이용)
    public String I_MKT_AGR_2 = null;               // 상품서비스안내 동의(제공)
    public String I_MKT_MTD_1 = null;               // 상품서비스안내 수단_전체
    public String I_MKT_MTD_2 = null;               // 상품서비스안내 수단_문자메세지
    public String I_MKT_MTD_3 = null;               // 상품서비스안내 수단_이메일
    public String I_MKT_MTD_4 = null;               // 상품서비스안내 수단_전화
    public String I_MKT_MTD_5 = null;               // 상품서비스안내 수단_우편

    // 출력
    public String O_RET_CD = null;			        // 결과코드 - 00:정상 , 10:입력값 누락, 11:입력값 오류, 99:시스템오류
    public String O_RET_MSG = null;			        // 결과메시지

}
