package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class CCLM0107VO extends CMMVO{

	//전문필드
		public String msg = "";  //[I/O] 메시지 LK_MSG_CD2 사용자 에러코드
		public String msg_cd = "";  //[I/O] 메시지코드 H_LK_MESSAGE2 사용자 에러명
		public String accd_rpt_no = "";  //[I/O] 사고접수번호 LK_SAGO_NO 사고접수번호
		public String[] clam_prg_srch_dtl__accd_oj_dvn = new String[0];  //[I/O] 보상진행조회_상세_사고목적구분 LK_MOKJUK_GB 사고목적구분
		public String[] clam_prg_srch_dtl__accd_oj_sqno = new String[0];  //[I/O] 보상진행조회_상세_사고목적일련번호 LK_MOKJUK_SEQ 사고목적일련번호
		public String[] clam_prg_srch_dtl__ins_nm = new String[0];  //[I/O] 보상진행조회_상세_피보험자명 LK_PIBO_NM 피보험자명
		public String[] clam_prg_srch_dtl__ins_rsdn_no = new String[0];  //[I/O] 보상진행조회_상세_피보험자주민번호 LK_PIBO_JUMIN_NO 피보험자 주민번호
		public String[] clam_prg_srch_dtl__accd_prg_crs_cd = new String[0];  //[I/O] 보상진행조회_상세_사고진행과정코드 LK_JINHENG_GUAJUNG 사고진행과정코드
		public String[] clam_prg_srch_dtl__accd_prg_stat_nm = new String[0];  //[I/O] 보상진행조회_상세_사고진행상태명 LK_JINHENG_STAT 사고진행상태명
		public String[] clam_prg_srch_dtl__clam_ormm_empno = new String[0];  //[I/O] 보상진행조회_상세_보상조직원사원번호 LK_JOJIKWON_CD 보상조직원 사번
		public String[] clam_prg_srch_dtl__clam_ormm_nm = new String[0];  //[I/O] 보상진행조회_상세_보상조직원명 LK_DAMDANGJA 보상조직원 명
		public String[] clam_prg_srch_dtl__tlno = new String[0];  //[I/O] 보상진행조회_상세_전화번호 LK_TEL_NO 전화번호
		public String[] clam_prg_srch_dtl__ofc_tlno = new String[0];  //[I/O] 보상진행조회_상세_사무실전화번호 LK_OFF_TEL_NO 사무실 전화번호
		
		public String getMsg() {
			return msg;
		}
		public void setMsg(String msg) {
			this.msg = msg;
		}
		public String getMsg_cd() {
			return msg_cd;
		}
		public void setMsg_cd(String msg_cd) {
			this.msg_cd = msg_cd;
		}
		public String getAccd_rpt_no() {
			return accd_rpt_no;
		}
		public void setAccd_rpt_no(String accd_rpt_no) {
			this.accd_rpt_no = accd_rpt_no;
		}
		public String[] getClam_prg_srch_dtl__accd_oj_dvn() {
			return clam_prg_srch_dtl__accd_oj_dvn;
		}
		public void setClam_prg_srch_dtl__accd_oj_dvn(
				String[] clam_prg_srch_dtl__accd_oj_dvn) {
			this.clam_prg_srch_dtl__accd_oj_dvn = clam_prg_srch_dtl__accd_oj_dvn;
		}
		public String[] getClam_prg_srch_dtl__accd_oj_sqno() {
			return clam_prg_srch_dtl__accd_oj_sqno;
		}
		public void setClam_prg_srch_dtl__accd_oj_sqno(
				String[] clam_prg_srch_dtl__accd_oj_sqno) {
			this.clam_prg_srch_dtl__accd_oj_sqno = clam_prg_srch_dtl__accd_oj_sqno;
		}
		public String[] getClam_prg_srch_dtl__ins_nm() {
			return clam_prg_srch_dtl__ins_nm;
		}
		public void setClam_prg_srch_dtl__ins_nm(String[] clam_prg_srch_dtl__ins_nm) {
			this.clam_prg_srch_dtl__ins_nm = clam_prg_srch_dtl__ins_nm;
		}
		public String[] getClam_prg_srch_dtl__ins_rsdn_no() {
			return clam_prg_srch_dtl__ins_rsdn_no;
		}
		public void setClam_prg_srch_dtl__ins_rsdn_no(
				String[] clam_prg_srch_dtl__ins_rsdn_no) {
			this.clam_prg_srch_dtl__ins_rsdn_no = clam_prg_srch_dtl__ins_rsdn_no;
		}
		public String[] getClam_prg_srch_dtl__accd_prg_crs_cd() {
			return clam_prg_srch_dtl__accd_prg_crs_cd;
		}
		public void setClam_prg_srch_dtl__accd_prg_crs_cd(
				String[] clam_prg_srch_dtl__accd_prg_crs_cd) {
			this.clam_prg_srch_dtl__accd_prg_crs_cd = clam_prg_srch_dtl__accd_prg_crs_cd;
		}
		public String[] getClam_prg_srch_dtl__accd_prg_stat_nm() {
			return clam_prg_srch_dtl__accd_prg_stat_nm;
		}
		public void setClam_prg_srch_dtl__accd_prg_stat_nm(
				String[] clam_prg_srch_dtl__accd_prg_stat_nm) {
			this.clam_prg_srch_dtl__accd_prg_stat_nm = clam_prg_srch_dtl__accd_prg_stat_nm;
		}
		public String[] getClam_prg_srch_dtl__clam_ormm_empno() {
			return clam_prg_srch_dtl__clam_ormm_empno;
		}
		public void setClam_prg_srch_dtl__clam_ormm_empno(
				String[] clam_prg_srch_dtl__clam_ormm_empno) {
			this.clam_prg_srch_dtl__clam_ormm_empno = clam_prg_srch_dtl__clam_ormm_empno;
		}
		public String[] getClam_prg_srch_dtl__clam_ormm_nm() {
			return clam_prg_srch_dtl__clam_ormm_nm;
		}
		public void setClam_prg_srch_dtl__clam_ormm_nm(
				String[] clam_prg_srch_dtl__clam_ormm_nm) {
			this.clam_prg_srch_dtl__clam_ormm_nm = clam_prg_srch_dtl__clam_ormm_nm;
		}
		public String[] getClam_prg_srch_dtl__tlno() {
			return clam_prg_srch_dtl__tlno;
		}
		public void setClam_prg_srch_dtl__tlno(String[] clam_prg_srch_dtl__tlno) {
			this.clam_prg_srch_dtl__tlno = clam_prg_srch_dtl__tlno;
		}
		public String[] getClam_prg_srch_dtl__ofc_tlno() {
			return clam_prg_srch_dtl__ofc_tlno;
		}
		public void setClam_prg_srch_dtl__ofc_tlno(String[] clam_prg_srch_dtl__ofc_tlno) {
			this.clam_prg_srch_dtl__ofc_tlno = clam_prg_srch_dtl__ofc_tlno;
		}
}
