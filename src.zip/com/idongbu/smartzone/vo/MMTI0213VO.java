package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class MMTI0213VO extends CMMVO{
	
	public String sms_ts_bvan = "";					// [I/O] SMS전송채번
	public String proc_dvn = "";					// [O] 처리구분: 01.신규,02.증권(긴출,현출),03.변경(차량대체),04.변경(해지정산),05.변경(가입변경),06.정산요청,07.정산SMS,08.만기정산
	public String plan_no = "";						// [O] 설계번호
	public String plno = "";						// [O] 증권번호
	public String chng_plan_no = "";				// [O] 변경설계번호
	public String ntft_srv_rc_ormm_cd = "";			// [O] 알림서비스수신조직원코드
	public String pbox_no_dvcd = "";				// [O] 사서함번호구분코드: 1.주행거리,2.블랙박스
	public String vh_no = "";						// [O] 차량번호
	public String cm_yn = "";						// [O] CM여부
	public String trv_dstc_exp_exca_dvcd = "";	
	public String aut_cgnt_nn_apcn_yn = "";		
	public String errorCode = "";
	public String trv_dstc_chng_aply_dvn = "";		// 08: 신청완료, 08 이외는 미신청
	public String hdlr_fire_yn = "";				// 0:부(해촉 안됨), 1: 여(해촉됨)
	public String z_resp_cd = "";
	public String z_resp_msg = "";
	public String acc_yn = "";						// [O] 계좌여부: 0:계좌없음버튼비활성, 1:계좌없음버튼활성
	public String trv_dstc_splc_exca_yn = "";		// [O] 주행거리간편정산여부 1:미환급
	public String rnw_plno = "";					// [O] 갱신증권번호
	public String o_c_r_cecd_yn = "";				// [O] OCR 판독여부
	public String trv_dstc_tty_exca_tgt_yn = "";	// [O] 주행거리특약정산대상여부
	public String ctc_plno = "";					// [O] 계약증권번호(전계약증번) 
	public String pdgr_cd = "";                 	// [O] 상품군코드 
	public String pdc_cd = "";                 		// [O] 상품코드
	public String mtcc_yn = "";						// [O] 이륜차여부(1:이륜차) 
	public String z_tlg_sp_cd = "";
	public String z_trns_org_cd = "";
	public String z_trns_org_dvcd = "";
	public String z_trsc_id = "";
	
	
	public String getSms_ts_bvan() {
		return sms_ts_bvan;
	}
	public void setSms_ts_bvan(String sms_ts_bvan) {
		this.sms_ts_bvan = sms_ts_bvan;
	}
	public String getProc_dvn() {
		return proc_dvn;
	}
	public void setProc_dvn(String proc_dvn) {
		this.proc_dvn = proc_dvn;
	}
	public String getPlan_no() {
		return plan_no;
	}
	public void setPlan_no(String plan_no) {
		this.plan_no = plan_no;
	}
	public String getPlno() {
		return plno;
	}
	public void setPlno(String plno) {
		this.plno = plno;
	}
	public String getChng_plan_no() {
		return chng_plan_no;
	}
	public void setChng_plan_no(String chng_plan_no) {
		this.chng_plan_no = chng_plan_no;
	}
	public String getNtft_srv_rc_ormm_cd() {
		return ntft_srv_rc_ormm_cd;
	}
	public void setNtft_srv_rc_ormm_cd(String ntft_srv_rc_ormm_cd) {
		this.ntft_srv_rc_ormm_cd = ntft_srv_rc_ormm_cd;
	}
	public String getPbox_no_dvcd() {
		return pbox_no_dvcd;
	}
	public void setPbox_no_dvcd(String pbox_no_dvcd) {
		this.pbox_no_dvcd = pbox_no_dvcd;
	}
	public String getVh_no() {
		return vh_no;
	}
	public void setVh_no(String vh_no) {
		this.vh_no = vh_no;
	}
	public String getCm_yn() {
		return cm_yn;
	}
	public void setCm_yn(String cm_yn) {
		this.cm_yn = cm_yn;
	}
	public String getTrv_dstc_exp_exca_dvcd() {
		return trv_dstc_exp_exca_dvcd;
	}
	public void setTrv_dstc_exp_exca_dvcd(String trv_dstc_exp_exca_dvcd) {
		this.trv_dstc_exp_exca_dvcd = trv_dstc_exp_exca_dvcd;
	}
	public String getAut_cgnt_nn_apcn_yn() {
		return aut_cgnt_nn_apcn_yn;
	}
	public void setAut_cgnt_nn_apcn_yn(String aut_cgnt_nn_apcn_yn) {
		this.aut_cgnt_nn_apcn_yn = aut_cgnt_nn_apcn_yn;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getTrv_dstc_chng_aply_dvn() {
		return trv_dstc_chng_aply_dvn;
	}
	public void setTrv_dstc_chng_aply_dvn(String trv_dstc_chng_aply_dvn) {
		this.trv_dstc_chng_aply_dvn = trv_dstc_chng_aply_dvn;
	}
	public String getHdlr_fire_yn() {
		return hdlr_fire_yn;
	}
	public void setHdlr_fire_yn(String hdlr_fire_yn) {
		this.hdlr_fire_yn = hdlr_fire_yn;
	}
	public String getZ_resp_cd() {
		return z_resp_cd;
	}
	public void setZ_resp_cd(String z_resp_cd) {
		this.z_resp_cd = z_resp_cd;
	}
	public String getZ_resp_msg() {
		return z_resp_msg;
	}
	public void setZ_resp_msg(String z_resp_msg) {
		this.z_resp_msg = z_resp_msg;
	}
	public String getAcc_yn() {
		return acc_yn;
	}
	public void setAcc_yn(String acc_yn) {
		this.acc_yn = acc_yn;
	}
	public String getTrv_dstc_splc_exca_yn() {
		return trv_dstc_splc_exca_yn;
	}
	public void setTrv_dstc_splc_exca_yn(String trv_dstc_splc_exca_yn) {
		this.trv_dstc_splc_exca_yn = trv_dstc_splc_exca_yn;
	}
	public String getRnw_plno() {
		return rnw_plno;
	}
	public void setRnw_plno(String rnw_plno) {
		this.rnw_plno = rnw_plno;
	}
	public String getO_c_r_cecd_yn() {
		return o_c_r_cecd_yn;
	}
	public void setO_c_r_cecd_yn(String o_c_r_cecd_yn) {
		this.o_c_r_cecd_yn = o_c_r_cecd_yn;
	}
	public String getTrv_dstc_tty_exca_tgt_yn() {
		return trv_dstc_tty_exca_tgt_yn;
	}
	public void setTrv_dstc_tty_exca_tgt_yn(String trv_dstc_tty_exca_tgt_yn) {
		this.trv_dstc_tty_exca_tgt_yn = trv_dstc_tty_exca_tgt_yn;
	}
	public String getCtc_plno() {
		return ctc_plno;
	}
	public void setCtc_plno(String ctc_plno) {
		this.ctc_plno = ctc_plno;
	}
	public String getPdgr_cd() {
		return pdgr_cd;
	}
	public void setPdgr_cd(String pdgr_cd) {
		this.pdgr_cd = pdgr_cd;
	}
	public String getPdc_cd() {
		return pdc_cd;
	}
	public void setPdc_cd(String pdc_cd) {
		this.pdc_cd = pdc_cd;
	}
	public String getMtcc_yn() {
		return mtcc_yn;
	}
	public void setMtcc_yn(String mtcc_yn) {
		this.mtcc_yn = mtcc_yn;
	}
	public String getZ_tlg_sp_cd() {
		return z_tlg_sp_cd;
	}
	public void setZ_tlg_sp_cd(String z_tlg_sp_cd) {
		this.z_tlg_sp_cd = z_tlg_sp_cd;
	}
	public String getZ_trns_org_cd() {
		return z_trns_org_cd;
	}
	public void setZ_trns_org_cd(String z_trns_org_cd) {
		this.z_trns_org_cd = z_trns_org_cd;
	}
	public String getZ_trns_org_dvcd() {
		return z_trns_org_dvcd;
	}
	public void setZ_trns_org_dvcd(String z_trns_org_dvcd) {
		this.z_trns_org_dvcd = z_trns_org_dvcd;
	}
	public String getZ_trsc_id() {
		return z_trsc_id;
	}
	public void setZ_trsc_id(String z_trsc_id) {
		this.z_trsc_id = z_trsc_id;
	}
	
}
