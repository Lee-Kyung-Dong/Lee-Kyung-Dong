package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class GGNI0001VO extends CMMVO{
	//전문필드
		public String pdc_cd = "";  //[I] 상품코드 COMM_BOJONG_CD 보종코드
		public String ctc_stat = "";  //[I] 계약상태 H_COMM_GEYAK_SANGTAE 계약상태
		public String ormm_cd = "";  //[I] 조직원코드 COMM_JOJIKWON_CD 조직원코드
		public String plno = "";  //[I] 증권번호 COMM_POLI_NO1 증권번호1
		public String chng_no = "";  //[I] 변경번호 COMM_BESU_NO 배서번호
		public String plan_no = "";  //[O] 설계번호 COMM_SULGYE_NO 설계번호
		public String bsc_mtt_if_bsc_if___arc_trm_str_dt= "";//보험기간시작일자    
		public String bsc_mtt_if_bsc_if___arc_trm_str_tm= "";//보험기간시작시각    
		public String bsc_mtt_if_bsc_if___arc_trm_fin_dt= "";//보험기간종료일자    
		public String bsc_mtt_if_bsc_if___arc_trm_fin_tm= "";//보험기간종료시각    

		public String getPdc_cd() {
			return pdc_cd;
		}
		public void setPdc_cd(String pdc_cd) {
			this.pdc_cd = pdc_cd;
		}
		public String getCtc_stat() {
			return ctc_stat;
		}
		public void setCtc_stat(String ctc_stat) {
			this.ctc_stat = ctc_stat;
		}
		public String getOrmm_cd() {
			return ormm_cd;
		}
		public void setOrmm_cd(String ormm_cd) {
			this.ormm_cd = ormm_cd;
		}
		public String getPlno() {
			return plno;
		}
		public void setPlno(String plno) {
			this.plno = plno;
		}
		public String getChng_no() {
			return chng_no;
		}
		public void setChng_no(String chng_no) {
			this.chng_no = chng_no;
		}
		public String getPlan_no() {
			return plan_no;
		}
		public void setPlan_no(String plan_no) {
			this.plan_no = plan_no;
		}
		public String getBsc_mtt_if_bsc_if___arc_trm_str_dt() {
			return bsc_mtt_if_bsc_if___arc_trm_str_dt;
		}
		public void setBsc_mtt_if_bsc_if___arc_trm_str_dt(
				String bsc_mtt_if_bsc_if___arc_trm_str_dt) {
			this.bsc_mtt_if_bsc_if___arc_trm_str_dt = bsc_mtt_if_bsc_if___arc_trm_str_dt;
		}
		public String getBsc_mtt_if_bsc_if___arc_trm_str_tm() {
			return bsc_mtt_if_bsc_if___arc_trm_str_tm;
		}
		public void setBsc_mtt_if_bsc_if___arc_trm_str_tm(
				String bsc_mtt_if_bsc_if___arc_trm_str_tm) {
			this.bsc_mtt_if_bsc_if___arc_trm_str_tm = bsc_mtt_if_bsc_if___arc_trm_str_tm;
		}
		public String getBsc_mtt_if_bsc_if___arc_trm_fin_dt() {
			return bsc_mtt_if_bsc_if___arc_trm_fin_dt;
		}
		public void setBsc_mtt_if_bsc_if___arc_trm_fin_dt(
				String bsc_mtt_if_bsc_if___arc_trm_fin_dt) {
			this.bsc_mtt_if_bsc_if___arc_trm_fin_dt = bsc_mtt_if_bsc_if___arc_trm_fin_dt;
		}
		public String getBsc_mtt_if_bsc_if___arc_trm_fin_tm() {
			return bsc_mtt_if_bsc_if___arc_trm_fin_tm;
		}
		public void setBsc_mtt_if_bsc_if___arc_trm_fin_tm(
				String bsc_mtt_if_bsc_if___arc_trm_fin_tm) {
			this.bsc_mtt_if_bsc_if___arc_trm_fin_tm = bsc_mtt_if_bsc_if___arc_trm_fin_tm;
		}
}
