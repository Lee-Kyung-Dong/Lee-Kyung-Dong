package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class LLTI0019VO extends CMMVO{
	//전문필드
		public String errorCode = null;  //[I] 화면ID JJ_MAP_ID 화면ID
		public String scrn_id = null;  //[I] 화면ID JJ_MAP_ID 화면ID
		public String pdc_cd = null;  //[I] 상품코드  
		public String plno = null;  //[I] 증권번호 JJ_POLI_NO 증권번호
		public String ins_lcpl_dvcd = null;//[I]피보험자소재지구분코드
		public String ply_sqno = null;	 	//[I]증권일련번호
		public String plhd_rrno = null;  //[I] 계약자주민등록번호 JJ_GY_JUMIN_NO 계약자주민번호
		public String tot_pge_cnt = null;  //[O] 총페이지수 JJ_PAGE_TOT_CNT 계약자 가입 전체건수
		public String tot_pge_no = null;  //[O] 총페이지번호 JJ_PAGE_TOT_NO 전체체이지수
		public String pge_no = null;  //[O] 페이지번호 JJ_PAGE_NO 현재페이지번호
		public String plhd_nm_1 = null;  //[O] 계약자명1 LK_GYEY_NM 계약자명
		
		public String[] outp_if__outp_plno = new String[0];  //[O] 출력정보_출력증권번호 LK_POLI_NO 증권번호
		public String[] outp_if__outp_pdc_cd = new String[0];  //[O] 출력정보_상품코드  
		public String[] outp_if__outp_arc_pdc_nm = new String[0];  //[O] 출력정보_출력보험상품명 LK_BJ_NM 보험상품명
		public String[] outp_if__outp_arc_pd_dt = new String[0];  //[O] 출력정보_출력보험시기일자 LK_BOHUM_SYMD 보험시기
		public String[] outp_if__outp_arc_et_dt = new String[0];  //[O] 출력정보_출력보험종기일자 LK_BOHUM_EYMD 보험종기
		public String[] outp_if__outp_ctc_stat_nm = new String[0];  //[O] 출력정보_출력계약상태명 LK-SANGTE-NM 계약상태명
		public String[] outp_if__outp_ins_nm = new String[0];  //[O] 출력정보_출력피보험자명 LK-PIBO-NM 피보험자명
		
		public String ctc_arc_pdc_nm = null;  //[O] 계약보험상품명 LK_BJ_NM 보험상품명
		public String ctc_arc_trm_nm = null;  //[O] 계약보험기간명 LK_BOHUM_GIGAN_NM 보험기간명
		public String ctc_arc_pd_dt = null;  //[O] 계약보험시기일자 LK_BOHUM_SYMD 보험시기
		public String ctc_arc_et_dt = null;  //[O] 계약보험종기일자 LK_BOHUM_EYMD 보험종기
		public String plhd_nm_2 = null;  //[O] 계약자명2 LK_GYEY_NM 계약자명
		public String plhd_adr_nm = null;  //[O] 계약자주소명 LK_GYEY_ADDR 계약자주소1
		public String plhd_eta_adr = null;  //[O] 계약자기타주소 LK_GYEY_GITA 계약자주소2
		public String sm_prm = null;  //[O] 합계보험료 LK_NAPIP_PRM 합계보험료
		public String eny_typ_nm = null;  //[O] 가입유형명 LK_GAIP1_NM 가입유형명
		public String pym_mtd_nm = null;  //[O] 납입방법명 LK_BUNNAP_NM 납입방법명
		public String fnal_pym_ym_1 = null;  //[O] 최종납입년월1 LK-NAPIP-YM 최종납입월
		public String gnrl_ln_yn = null;  //[O] 일반대출여부 LK_ILBAN 일반대출유무
		public String inpl_ln_yn = null;  //[O] 약관대출여부 LK_YAKGWAN 약관대출유무
		public String hdlr_nm = null;  //[O] 취급자명 LK_JOJIKWON_NM 취급자명
		public String hdlr_tlno = null;  //[O] 취급자전화번호 LK_JOJIKWON_TEL 취급자전화번호
		public String ctc_stat_nm = null;  //[O] 계약상태명 LK_SANGTE_NM 계약상태명
		public String ins_nm = null;  //[O] 피보험자명 LK_PIBO_NM 피보험자명
		public String fnal_pym_orr = null;  //[O] 최종납입회차 LK_L_NAPIP_CNT 최종납입회차
		public String cbl_trmt_csn_yn = null;  //[O] 유선해지동의여부 LK_HEJI_YN 유선해지동의여부
		//차세대 2차 변환 이슬기 ins_rrono=> ins_rron
		
		public String ins_rrono = null;  //[O] 피보험자주민등록번호 LK_PIBO_CD 피보험자주민번호
		
		public String ins_rrno = null;  //[O] 피보험자주민등록번호 LK_PIBO_CD 피보험자주민번호
		//차세대 2차 변환 종료
		public String cvr_arc_pdc_nm = null;  //[O] 담보보험상품명 LK_BJ_NM 보험상품명
		public String[] cvr_if__cvr_cd = new String[0];  //[O] 담보정보_담보코드 LK_DAMBO_CD 담보코드
		public String[] cvr_if__cvr_nm = new String[0];  //[O] 담보정보_담보명  LK_DAMBO_NM 담보명
		public String[] cvr_if__inam = new String[0];  //[O] 담보정보_가입금액 LK_GAIP_GMEK 가입금액
		
		
		public String coll_arc_pdc_nm = null;  //[O] 수금보험상품명 LK_BJ_NM 보험상품명
		public String[] coll_if__coll_mtd_nm = new String[0];  //[O] 수금정보_수금방법명 LK_BUNNAP_NM 수금방법명
		public String[] coll_if__tsfr_dd = new String[0];  //[O] 수금정보_이체일 LK_ICHE_DD 이체일
		public String[] coll_if__bank_nm = new String[0];  //[O] 수금정보_은행명 LK_BANK_NM 은행명
		public String[] coll_if__acc_no = new String[0];  //[O] 수금정보_계좌번호 LK_GYEJWA_NO 계좌번호
		public String[] coll_if__dpsr_nm = new String[0];  //[O] 수금정보_예금주명 LK_YEGMJU_NM 예금주명
		
		public String[] pym_if__nstl_orr = new String[0];  //[O] 납입정보_분납회차 LK_BUNNAP_CNT 분납회차
		public String[] pym_if__coll_mtd_nm = new String[0];  //[O] 납입정보_수금방법명 LK_BANG_CD 수금방법명
		public String[] pym_if__fnal_pym_ym_2 = new String[0];  //[O] 납입정보_최종납입년월2 LK-NAPIP-YM 최종납입월
		public String[] pym_if__cltd_dt_1 = new String[0];  //[O] 납입정보_영수일자1 LK-YUNG-YMD 영수일자
		public String[] pym_if__cltd_prm = new String[0];  //[O] 납입정보_영수보험료 LK-YUNG-PRM 영수보험료
		public String[] pym_if__cltd_dt_2 = new String[0];  //[O] 납입정보_영수일자2 DD_YUNG_YMD 영수일자
		public String tot_nstl_prm = null;  //[O] 총분납보험료 LK_SUM_BUNNAP 총분납보험료*/
		public String getScrn_id() {
			return scrn_id;
		}
		public void setScrn_id(String scrn_id) {
			this.scrn_id = scrn_id;
		}
		public String getPdc_cd() {
			return pdc_cd;
		}
		public void setPdc_cd(String pdc_cd) {
			this.pdc_cd = pdc_cd;
		}
		public String getPlno() {
			return plno;
		}
		public void setPlno(String plno) {
			this.plno = plno;
		}
		public String getIns_lcpl_dvcd() {
			return ins_lcpl_dvcd;
		}
		public void setIns_lcpl_dvcd(String ins_lcpl_dvcd) {
			this.ins_lcpl_dvcd = ins_lcpl_dvcd;
		}
		public String getPly_sqno() {
			return ply_sqno;
		}
		public void setPly_sqno(String ply_sqno) {
			this.ply_sqno = ply_sqno;
		}
		public String getPlhd_rrno() {
			return plhd_rrno;
		}
		public void setPlhd_rrno(String plhd_rrno) {
			this.plhd_rrno = plhd_rrno;
		}
		public String getTot_pge_cnt() {
			return tot_pge_cnt;
		}
		public void setTot_pge_cnt(String tot_pge_cnt) {
			this.tot_pge_cnt = tot_pge_cnt;
		}
		public String getTot_pge_no() {
			return tot_pge_no;
		}
		public void setTot_pge_no(String tot_pge_no) {
			this.tot_pge_no = tot_pge_no;
		}
		public String getPge_no() {
			return pge_no;
		}
		public void setPge_no(String pge_no) {
			this.pge_no = pge_no;
		}
		public String getPlhd_nm_1() {
			return plhd_nm_1;
		}
		public void setPlhd_nm_1(String plhd_nm_1) {
			this.plhd_nm_1 = plhd_nm_1;
		}
		public String[] getOutp_if__outp_plno() {
			return outp_if__outp_plno;
		}
		public void setOutp_if__outp_plno(String[] outp_if__outp_plno) {
			this.outp_if__outp_plno = outp_if__outp_plno;
		}
		public String[] getOutp_if__outp_pdc_cd() {
			return outp_if__outp_pdc_cd;
		}
		public void setOutp_if__outp_pdc_cd(String[] outp_if__outp_pdc_cd) {
			this.outp_if__outp_pdc_cd = outp_if__outp_pdc_cd;
		}
		public String[] getOutp_if__outp_arc_pdc_nm() {
			return outp_if__outp_arc_pdc_nm;
		}
		public void setOutp_if__outp_arc_pdc_nm(String[] outp_if__outp_arc_pdc_nm) {
			this.outp_if__outp_arc_pdc_nm = outp_if__outp_arc_pdc_nm;
		}
		public String[] getOutp_if__outp_arc_pd_dt() {
			return outp_if__outp_arc_pd_dt;
		}
		public void setOutp_if__outp_arc_pd_dt(String[] outp_if__outp_arc_pd_dt) {
			this.outp_if__outp_arc_pd_dt = outp_if__outp_arc_pd_dt;
		}
		public String[] getOutp_if__outp_arc_et_dt() {
			return outp_if__outp_arc_et_dt;
		}
		public void setOutp_if__outp_arc_et_dt(String[] outp_if__outp_arc_et_dt) {
			this.outp_if__outp_arc_et_dt = outp_if__outp_arc_et_dt;
		}
		public String[] getOutp_if__outp_ctc_stat_nm() {
			return outp_if__outp_ctc_stat_nm;
		}
		public void setOutp_if__outp_ctc_stat_nm(String[] outp_if__outp_ctc_stat_nm) {
			this.outp_if__outp_ctc_stat_nm = outp_if__outp_ctc_stat_nm;
		}
		public String[] getOutp_if__outp_ins_nm() {
			return outp_if__outp_ins_nm;
		}
		public void setOutp_if__outp_ins_nm(String[] outp_if__outp_ins_nm) {
			this.outp_if__outp_ins_nm = outp_if__outp_ins_nm;
		}
		public String getCtc_arc_pdc_nm() {
			return ctc_arc_pdc_nm;
		}
		public void setCtc_arc_pdc_nm(String ctc_arc_pdc_nm) {
			this.ctc_arc_pdc_nm = ctc_arc_pdc_nm;
		}
		public String getCtc_arc_trm_nm() {
			return ctc_arc_trm_nm;
		}
		public void setCtc_arc_trm_nm(String ctc_arc_trm_nm) {
			this.ctc_arc_trm_nm = ctc_arc_trm_nm;
		}
		public String getCtc_arc_pd_dt() {
			return ctc_arc_pd_dt;
		}
		public void setCtc_arc_pd_dt(String ctc_arc_pd_dt) {
			this.ctc_arc_pd_dt = ctc_arc_pd_dt;
		}
		public String getCtc_arc_et_dt() {
			return ctc_arc_et_dt;
		}
		public void setCtc_arc_et_dt(String ctc_arc_et_dt) {
			this.ctc_arc_et_dt = ctc_arc_et_dt;
		}
		public String getPlhd_nm_2() {
			return plhd_nm_2;
		}
		public void setPlhd_nm_2(String plhd_nm_2) {
			this.plhd_nm_2 = plhd_nm_2;
		}
		public String getPlhd_adr_nm() {
			return plhd_adr_nm;
		}
		public void setPlhd_adr_nm(String plhd_adr_nm) {
			this.plhd_adr_nm = plhd_adr_nm;
		}
		public String getPlhd_eta_adr() {
			return plhd_eta_adr;
		}
		public void setPlhd_eta_adr(String plhd_eta_adr) {
			this.plhd_eta_adr = plhd_eta_adr;
		}
		public String getSm_prm() {
			return sm_prm;
		}
		public void setSm_prm(String sm_prm) {
			this.sm_prm = sm_prm;
		}
		public String getEny_typ_nm() {
			return eny_typ_nm;
		}
		public void setEny_typ_nm(String eny_typ_nm) {
			this.eny_typ_nm = eny_typ_nm;
		}
		public String getPym_mtd_nm() {
			return pym_mtd_nm;
		}
		public void setPym_mtd_nm(String pym_mtd_nm) {
			this.pym_mtd_nm = pym_mtd_nm;
		}
		public String getFnal_pym_ym_1() {
			return fnal_pym_ym_1;
		}
		public void setFnal_pym_ym_1(String fnal_pym_ym_1) {
			this.fnal_pym_ym_1 = fnal_pym_ym_1;
		}
		public String getGnrl_ln_yn() {
			return gnrl_ln_yn;
		}
		public void setGnrl_ln_yn(String gnrl_ln_yn) {
			this.gnrl_ln_yn = gnrl_ln_yn;
		}
		public String getInpl_ln_yn() {
			return inpl_ln_yn;
		}
		public void setInpl_ln_yn(String inpl_ln_yn) {
			this.inpl_ln_yn = inpl_ln_yn;
		}
		public String getHdlr_nm() {
			return hdlr_nm;
		}
		public void setHdlr_nm(String hdlr_nm) {
			this.hdlr_nm = hdlr_nm;
		}
		public String getHdlr_tlno() {
			return hdlr_tlno;
		}
		public void setHdlr_tlno(String hdlr_tlno) {
			this.hdlr_tlno = hdlr_tlno;
		}
		public String getCtc_stat_nm() {
			return ctc_stat_nm;
		}
		public void setCtc_stat_nm(String ctc_stat_nm) {
			this.ctc_stat_nm = ctc_stat_nm;
		}
		public String getIns_nm() {
			return ins_nm;
		}
		public void setIns_nm(String ins_nm) {
			this.ins_nm = ins_nm;
		}
		public String getFnal_pym_orr() {
			return fnal_pym_orr;
		}
		public void setFnal_pym_orr(String fnal_pym_orr) {
			this.fnal_pym_orr = fnal_pym_orr;
		}
		public String getCbl_trmt_csn_yn() {
			return cbl_trmt_csn_yn;
		}
		public void setCbl_trmt_csn_yn(String cbl_trmt_csn_yn) {
			this.cbl_trmt_csn_yn = cbl_trmt_csn_yn;
		}
		public String getIns_rrno() {
			return ins_rrno;
		}
		public void setIns_rrno(String ins_rrno) {
			this.ins_rrno = ins_rrno;
		}
		public String getCvr_arc_pdc_nm() {
			return cvr_arc_pdc_nm;
		}
		public void setCvr_arc_pdc_nm(String cvr_arc_pdc_nm) {
			this.cvr_arc_pdc_nm = cvr_arc_pdc_nm;
		}
		public String[] getCvr_if__cvr_cd() {
			return cvr_if__cvr_cd;
		}
		public void setCvr_if__cvr_cd(String[] cvr_if__cvr_cd) {
			this.cvr_if__cvr_cd = cvr_if__cvr_cd;
		}
		public String[] getCvr_if__cvr_nm() {
			return cvr_if__cvr_nm;
		}
		public void setCvr_if__cvr_nm(String[] cvr_if__cvr_nm) {
			this.cvr_if__cvr_nm = cvr_if__cvr_nm;
		}
		public String[] getCvr_if__inam() {
			return cvr_if__inam;
		}
		public void setCvr_if__inam(String[] cvr_if__inam) {
			this.cvr_if__inam = cvr_if__inam;
		}
		public String getColl_arc_pdc_nm() {
			return coll_arc_pdc_nm;
		}
		public void setColl_arc_pdc_nm(String coll_arc_pdc_nm) {
			this.coll_arc_pdc_nm = coll_arc_pdc_nm;
		}
		public String[] getColl_if__coll_mtd_nm() {
			return coll_if__coll_mtd_nm;
		}
		public void setColl_if__coll_mtd_nm(String[] coll_if__coll_mtd_nm) {
			this.coll_if__coll_mtd_nm = coll_if__coll_mtd_nm;
		}
		public String[] getColl_if__tsfr_dd() {
			return coll_if__tsfr_dd;
		}
		public void setColl_if__tsfr_dd(String[] coll_if__tsfr_dd) {
			this.coll_if__tsfr_dd = coll_if__tsfr_dd;
		}
		public String[] getColl_if__bank_nm() {
			return coll_if__bank_nm;
		}
		public void setColl_if__bank_nm(String[] coll_if__bank_nm) {
			this.coll_if__bank_nm = coll_if__bank_nm;
		}
		public String[] getColl_if__acc_no() {
			return coll_if__acc_no;
		}
		public void setColl_if__acc_no(String[] coll_if__acc_no) {
			this.coll_if__acc_no = coll_if__acc_no;
		}
		public String[] getColl_if__dpsr_nm() {
			return coll_if__dpsr_nm;
		}
		public void setColl_if__dpsr_nm(String[] coll_if__dpsr_nm) {
			this.coll_if__dpsr_nm = coll_if__dpsr_nm;
		}
		public String[] getPym_if__nstl_orr() {
			return pym_if__nstl_orr;
		}
		public void setPym_if__nstl_orr(String[] pym_if__nstl_orr) {
			this.pym_if__nstl_orr = pym_if__nstl_orr;
		}
		public String[] getPym_if__coll_mtd_nm() {
			return pym_if__coll_mtd_nm;
		}
		public void setPym_if__coll_mtd_nm(String[] pym_if__coll_mtd_nm) {
			this.pym_if__coll_mtd_nm = pym_if__coll_mtd_nm;
		}
		public String[] getPym_if__fnal_pym_ym_2() {
			return pym_if__fnal_pym_ym_2;
		}
		public void setPym_if__fnal_pym_ym_2(String[] pym_if__fnal_pym_ym_2) {
			this.pym_if__fnal_pym_ym_2 = pym_if__fnal_pym_ym_2;
		}
		public String[] getPym_if__cltd_dt_1() {
			return pym_if__cltd_dt_1;
		}
		public void setPym_if__cltd_dt_1(String[] pym_if__cltd_dt_1) {
			this.pym_if__cltd_dt_1 = pym_if__cltd_dt_1;
		}
		public String[] getPym_if__cltd_prm() {
			return pym_if__cltd_prm;
		}
		public void setPym_if__cltd_prm(String[] pym_if__cltd_prm) {
			this.pym_if__cltd_prm = pym_if__cltd_prm;
		}
		public String[] getPym_if__cltd_dt_2() {
			return pym_if__cltd_dt_2;
		}
		public void setPym_if__cltd_dt_2(String[] pym_if__cltd_dt_2) {
			this.pym_if__cltd_dt_2 = pym_if__cltd_dt_2;
		}
		public String getTot_nstl_prm() {
			return tot_nstl_prm;
		}
		public void setTot_nstl_prm(String tot_nstl_prm) {
			this.tot_nstl_prm = tot_nstl_prm;
		}
		
		
}
