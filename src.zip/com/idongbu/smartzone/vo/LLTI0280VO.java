package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class LLTI0280VO  extends CMMVO{

	//전문필드
		public String funt_key = "";  //[I/O] 기능키 CC-FUN-KEY 기능키
		public String dpsr_rsdn_no = "";  //[I] 예금주주민번호 JJ-YEGMJU-JUMINNO 예금주주민번호
		public String[] ctc_if_srch__plhd_rsdn_no = new String[0];  //[O] 계약정보조회_계약자주민번호 JJ-GYEYAK-JMNO 계약자주민번호
		public String[] ctc_if_srch__plhd_nm = new String[0];  //[O] 계약정보조회_계약자명 HJ-GYEYAK-NM 계약자명
		public String[] ctc_if_srch__ins_rsdn_no = new String[0];  //[O] 계약정보조회_피보험자주민번호 JJ-PIBO-JMNO 피보험자주민번호
		public String[] ctc_if_srch__ins_nm = new String[0];  //[O] 계약정보조회_피보험자명 HJ-PIBO-NM 피보험자명
		public String[] ctc_if_srch__pdc_nm = new String[0];  //[O] 계약정보조회_상품명 HJ-BJ-NM 보종명
		public String[] ctc_if_srch__plno = new String[0];  //[O] 계약정보조회_증권번호 JJ-POLI-NO 증권번호
		public String[] ctc_if_srch__pdc_cd = new String[0];  //[O] 계약정보조회_상품코드   
		public String[] ctc_if_srch__arc_trm_str_dt = new String[0];  //[O] 계약정보조회_보험기간시작일자 JJ-BOHUM-GIGAN-S 보험시기
		public String[] ctc_if_srch__arc_trm_fin_dt = new String[0];  //[O] 계약정보조회_보험기간종료일자 JJ-BOHUM-GIGAN-E 보험종기
		public String[] ctc_if_srch__ctc_stat_cd = new String[0];  //[O] 계약정보조회_계약상태코드 JJ-GYEYAK-SANGTE 계약상태코드
		public String[] ctc_if_srch__ctc_stat = new String[0];  //[O] 계약정보조회_계약상태 HJ-BIGO 계약상태명
		public String[] ctc_if_srch__hdlr_nm = new String[0];  //[O] 계약정보조회_취급자명 HJ-CHIGUB-NM 취급자명
		public String[] ctc_if_srch__hdlr_tlno = new String[0];  //[O] 계약정보조회_취급자전화번호 JJ-CHIGUB-TEL 취급자전화번호
		public String[] ctc_if_srch__hdlr_cd = new String[0];  //[O] 계약정보조회_취급자코드 JJ-CHIGUB 취급자코드
		public String[] ctc_if_srch__sl_pan_cd = new String[0];  //[O] 계약정보조회_판매플랜코드 JJ-GAIP-TYPE1 가입유형1
		public String[] ctc_if_srch__pytr_dvcd = new String[0];  //[O] 계약정보조회_납기구분코드  
		public String[] ctc_if_srch__pytr_val = new String[0];  //[O] 계약정보조회_납기값 JJ-BOHUM-GIGANCD 보험기간코드
		public String[] ctc_if_srch__exp_dvcd = new String[0];  //[O] 계약정보조회_만기구분코드  
		public String[] ctc_if_srch__exp_val = new String[0];  //[O] 계약정보조회_만기값  
		public String[] ctc_if_srch__fnal_pym_nts = new String[0];  //[O] 계약정보조회_최종납입횟수 JJ-NAPIP-CNT 납입횟수
		public String[] ctc_if_srch__pym_mtd_nm = new String[0];  //[O] 계약정보조회_납입방법명 HJ-BUNNAP-NM 납입방법명
		public String[] ctc_if_srch__fnal_pym_ym = new String[0];  //[O] 계약정보조회_최종납입년월 JJ-LAST-NAPIP-YM 최종납입월도
		public String[] ctc_if_srch__pym_mtd_cd = new String[0];  //[O] 계약정보조회_납입방법코드 JJ-BUNNAP-BANGCD 분납방법코드
		public String[] ctc_if_srch__aut_tsfr_dd = new String[0];  //[O] 계약정보조회_자동이체일 JJ-ICHE-ILSU 자동이체일
		public String[] ctc_if_srch__coll_mtd_cd = new String[0];  //[O] 계약정보조회_수금방법코드 JJ-SU-BANGBAP 입출금방법코드
		public String[] ctc_if_srch__coll_mtd_nm = new String[0];  //[O] 계약정보조회_수금방법명 HJ-SU-BANGBAP 입출금방법명
		public String str_plno = "";  //[I] 시작증권번호 UU-F-POLI-NO FIRST-증권번호
		public String last_plno = "";  //[O] 마지막증권번호 UU-L-POLI-NO LAST-증권번호
		 
		public String errorCode = "";
		
		
		public String getFunt_key() {
			return funt_key;
		}
		public void setFunt_key(String funt_key) {
			this.funt_key = funt_key;
		}
		public String getDpsr_rsdn_no() {
			return dpsr_rsdn_no;
		}
		public void setDpsr_rsdn_no(String dpsr_rsdn_no) {
			this.dpsr_rsdn_no = dpsr_rsdn_no;
		}
		public String[] getCtc_if_srch__plhd_rsdn_no() {
			return ctc_if_srch__plhd_rsdn_no;
		}
		public void setCtc_if_srch__plhd_rsdn_no(String[] ctc_if_srch__plhd_rsdn_no) {
			this.ctc_if_srch__plhd_rsdn_no = ctc_if_srch__plhd_rsdn_no;
		}
		public String[] getCtc_if_srch__plhd_nm() {
			return ctc_if_srch__plhd_nm;
		}
		public void setCtc_if_srch__plhd_nm(String[] ctc_if_srch__plhd_nm) {
			this.ctc_if_srch__plhd_nm = ctc_if_srch__plhd_nm;
		}
		public String[] getCtc_if_srch__ins_rsdn_no() {
			return ctc_if_srch__ins_rsdn_no;
		}
		public void setCtc_if_srch__ins_rsdn_no(String[] ctc_if_srch__ins_rsdn_no) {
			this.ctc_if_srch__ins_rsdn_no = ctc_if_srch__ins_rsdn_no;
		}
		public String[] getCtc_if_srch__ins_nm() {
			return ctc_if_srch__ins_nm;
		}
		public void setCtc_if_srch__ins_nm(String[] ctc_if_srch__ins_nm) {
			this.ctc_if_srch__ins_nm = ctc_if_srch__ins_nm;
		}
		public String[] getCtc_if_srch__pdc_nm() {
			return ctc_if_srch__pdc_nm;
		}
		public void setCtc_if_srch__pdc_nm(String[] ctc_if_srch__pdc_nm) {
			this.ctc_if_srch__pdc_nm = ctc_if_srch__pdc_nm;
		}
		public String[] getCtc_if_srch__plno() {
			return ctc_if_srch__plno;
		}
		public void setCtc_if_srch__plno(String[] ctc_if_srch__plno) {
			this.ctc_if_srch__plno = ctc_if_srch__plno;
		}
		public String[] getCtc_if_srch__pdc_cd() {
			return ctc_if_srch__pdc_cd;
		}
		public void setCtc_if_srch__pdc_cd(String[] ctc_if_srch__pdc_cd) {
			this.ctc_if_srch__pdc_cd = ctc_if_srch__pdc_cd;
		}
		public String[] getCtc_if_srch__arc_trm_str_dt() {
			return ctc_if_srch__arc_trm_str_dt;
		}
		public void setCtc_if_srch__arc_trm_str_dt(String[] ctc_if_srch__arc_trm_str_dt) {
			this.ctc_if_srch__arc_trm_str_dt = ctc_if_srch__arc_trm_str_dt;
		}
		public String[] getCtc_if_srch__arc_trm_fin_dt() {
			return ctc_if_srch__arc_trm_fin_dt;
		}
		public void setCtc_if_srch__arc_trm_fin_dt(String[] ctc_if_srch__arc_trm_fin_dt) {
			this.ctc_if_srch__arc_trm_fin_dt = ctc_if_srch__arc_trm_fin_dt;
		}
		public String[] getCtc_if_srch__ctc_stat_cd() {
			return ctc_if_srch__ctc_stat_cd;
		}
		public void setCtc_if_srch__ctc_stat_cd(String[] ctc_if_srch__ctc_stat_cd) {
			this.ctc_if_srch__ctc_stat_cd = ctc_if_srch__ctc_stat_cd;
		}
		public String[] getCtc_if_srch__ctc_stat() {
			return ctc_if_srch__ctc_stat;
		}
		public void setCtc_if_srch__ctc_stat(String[] ctc_if_srch__ctc_stat) {
			this.ctc_if_srch__ctc_stat = ctc_if_srch__ctc_stat;
		}
		public String[] getCtc_if_srch__hdlr_nm() {
			return ctc_if_srch__hdlr_nm;
		}
		public void setCtc_if_srch__hdlr_nm(String[] ctc_if_srch__hdlr_nm) {
			this.ctc_if_srch__hdlr_nm = ctc_if_srch__hdlr_nm;
		}
		public String[] getCtc_if_srch__hdlr_tlno() {
			return ctc_if_srch__hdlr_tlno;
		}
		public void setCtc_if_srch__hdlr_tlno(String[] ctc_if_srch__hdlr_tlno) {
			this.ctc_if_srch__hdlr_tlno = ctc_if_srch__hdlr_tlno;
		}
		public String[] getCtc_if_srch__hdlr_cd() {
			return ctc_if_srch__hdlr_cd;
		}
		public void setCtc_if_srch__hdlr_cd(String[] ctc_if_srch__hdlr_cd) {
			this.ctc_if_srch__hdlr_cd = ctc_if_srch__hdlr_cd;
		}
		public String[] getCtc_if_srch__sl_pan_cd() {
			return ctc_if_srch__sl_pan_cd;
		}
		public void setCtc_if_srch__sl_pan_cd(String[] ctc_if_srch__sl_pan_cd) {
			this.ctc_if_srch__sl_pan_cd = ctc_if_srch__sl_pan_cd;
		}
		public String[] getCtc_if_srch__pytr_dvcd() {
			return ctc_if_srch__pytr_dvcd;
		}
		public void setCtc_if_srch__pytr_dvcd(String[] ctc_if_srch__pytr_dvcd) {
			this.ctc_if_srch__pytr_dvcd = ctc_if_srch__pytr_dvcd;
		}
		public String[] getCtc_if_srch__pytr_val() {
			return ctc_if_srch__pytr_val;
		}
		public void setCtc_if_srch__pytr_val(String[] ctc_if_srch__pytr_val) {
			this.ctc_if_srch__pytr_val = ctc_if_srch__pytr_val;
		}
		public String[] getCtc_if_srch__exp_dvcd() {
			return ctc_if_srch__exp_dvcd;
		}
		public void setCtc_if_srch__exp_dvcd(String[] ctc_if_srch__exp_dvcd) {
			this.ctc_if_srch__exp_dvcd = ctc_if_srch__exp_dvcd;
		}
		public String[] getCtc_if_srch__exp_val() {
			return ctc_if_srch__exp_val;
		}
		public void setCtc_if_srch__exp_val(String[] ctc_if_srch__exp_val) {
			this.ctc_if_srch__exp_val = ctc_if_srch__exp_val;
		}
		public String[] getCtc_if_srch__fnal_pym_nts() {
			return ctc_if_srch__fnal_pym_nts;
		}
		public void setCtc_if_srch__fnal_pym_nts(String[] ctc_if_srch__fnal_pym_nts) {
			this.ctc_if_srch__fnal_pym_nts = ctc_if_srch__fnal_pym_nts;
		}
		public String[] getCtc_if_srch__pym_mtd_nm() {
			return ctc_if_srch__pym_mtd_nm;
		}
		public void setCtc_if_srch__pym_mtd_nm(String[] ctc_if_srch__pym_mtd_nm) {
			this.ctc_if_srch__pym_mtd_nm = ctc_if_srch__pym_mtd_nm;
		}
		public String[] getCtc_if_srch__fnal_pym_ym() {
			return ctc_if_srch__fnal_pym_ym;
		}
		public void setCtc_if_srch__fnal_pym_ym(String[] ctc_if_srch__fnal_pym_ym) {
			this.ctc_if_srch__fnal_pym_ym = ctc_if_srch__fnal_pym_ym;
		}
		public String[] getCtc_if_srch__pym_mtd_cd() {
			return ctc_if_srch__pym_mtd_cd;
		}
		public void setCtc_if_srch__pym_mtd_cd(String[] ctc_if_srch__pym_mtd_cd) {
			this.ctc_if_srch__pym_mtd_cd = ctc_if_srch__pym_mtd_cd;
		}
		public String[] getCtc_if_srch__aut_tsfr_dd() {
			return ctc_if_srch__aut_tsfr_dd;
		}
		public void setCtc_if_srch__aut_tsfr_dd(String[] ctc_if_srch__aut_tsfr_dd) {
			this.ctc_if_srch__aut_tsfr_dd = ctc_if_srch__aut_tsfr_dd;
		}
		public String[] getCtc_if_srch__coll_mtd_cd() {
			return ctc_if_srch__coll_mtd_cd;
		}
		public void setCtc_if_srch__coll_mtd_cd(String[] ctc_if_srch__coll_mtd_cd) {
			this.ctc_if_srch__coll_mtd_cd = ctc_if_srch__coll_mtd_cd;
		}
		public String[] getCtc_if_srch__coll_mtd_nm() {
			return ctc_if_srch__coll_mtd_nm;
		}
		public void setCtc_if_srch__coll_mtd_nm(String[] ctc_if_srch__coll_mtd_nm) {
			this.ctc_if_srch__coll_mtd_nm = ctc_if_srch__coll_mtd_nm;
		}
		public String getStr_plno() {
			return str_plno;
		}
		public void setStr_plno(String str_plno) {
			this.str_plno = str_plno;
		}
		public String getLast_plno() {
			return last_plno;
		}
		public void setLast_plno(String last_plno) {
			this.last_plno = last_plno;
		}
		public String getErrorCode() {
			return errorCode;
		}
		public void setErrorCode(String errorCode) {
			this.errorCode = errorCode;
		}
}
