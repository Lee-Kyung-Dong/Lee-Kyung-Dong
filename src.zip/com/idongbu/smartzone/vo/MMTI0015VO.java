package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class MMTI0015VO extends CMMVO {

	// 주행거리 미정산 건(변경확정신청까지만 된 경우) TM통합시스템에 계약정보 적재 요청(2020.09.23 김영민 과장)
	// 변경설계번호로 고객정보 가져오기 위한 전문
	
	// [IN]
	public String funt_key = "";					// 기능키("00")
	public String plan_no = "";						// 설계번호
	
	// [OUT]
	public String plhd__cust_dcmt_no = "";			// 계약자_고객식별번호
	public String plhd__cust_no = "";				// 계약자_고객번호	
	public String plhd__cust_nm = "";				// 계약자_고객명
	public String plhd__eml = "";					// 계약자_이메일
	public String plhd_cntp_if__tlp_arno = "";		// 계약자연락처정보_전화지역번호	(XTEM0021 - clp_tlcno)
	public String plhd_cntp_if__tlp_ofno = "";		// 계약자연락처정보_전화국번호		(XTEM0021 - clp_ofno)
	public String plhd_cntp_if__tlp_idvno = "";		// 계약자연락처정보_전화개별번호	(XTEM0021 - clp_idvno) 
	
	
	public String getFunt_key() {
		return funt_key;
	}
	public void setFunt_key(String funt_key) {
		this.funt_key = funt_key;
	}
	public String getPlan_no() {
		return plan_no;
	}
	public void setPlan_no(String plan_no) {
		this.plan_no = plan_no;
	}
	public String getPlhd__cust_dcmt_no() {
		return plhd__cust_dcmt_no;
	}
	public void setPlhd__cust_dcmt_no(String plhd__cust_dcmt_no) {
		this.plhd__cust_dcmt_no = plhd__cust_dcmt_no;
	}
	public String getPlhd__cust_no() {
		return plhd__cust_no;
	}
	public void setPlhd__cust_no(String plhd__cust_no) {
		this.plhd__cust_no = plhd__cust_no;
	}
	public String getPlhd__cust_nm() {
		return plhd__cust_nm;
	}
	public void setPlhd__cust_nm(String plhd__cust_nm) {
		this.plhd__cust_nm = plhd__cust_nm;
	}
	public String getPlhd__eml() {
		return plhd__eml;
	}
	public void setPlhd__eml(String plhd__eml) {
		this.plhd__eml = plhd__eml;
	}
	public String getPlhd_cntp_if__tlp_arno() {
		return plhd_cntp_if__tlp_arno;
	}
	public void setPlhd_cntp_if__tlp_arno(String plhd_cntp_if__tlp_arno) {
		this.plhd_cntp_if__tlp_arno = plhd_cntp_if__tlp_arno;
	}
	public String getPlhd_cntp_if__tlp_ofno() {
		return plhd_cntp_if__tlp_ofno;
	}
	public void setPlhd_cntp_if__tlp_ofno(String plhd_cntp_if__tlp_ofno) {
		this.plhd_cntp_if__tlp_ofno = plhd_cntp_if__tlp_ofno;
	}
	public String getPlhd_cntp_if__tlp_idvno() {
		return plhd_cntp_if__tlp_idvno;
	}
	public void setPlhd_cntp_if__tlp_idvno(String plhd_cntp_if__tlp_idvno) {
		this.plhd_cntp_if__tlp_idvno = plhd_cntp_if__tlp_idvno;
	}
	
	
	
}
