package com.idongbu.smartzone.vo;
import com.idongbu.common.vo.CMMVO;
public class LLTI0109VO extends CMMVO{
	//전문필드
	public String plno = null;                //[I]증권번호              
	public String proc_dt = null;             //[I]처리일자              
	public String proc_dvcd = null;           //[I]처리구분코드          
	public String bh_cd = null;               //[I]지점코드              
	public String bh_nm = null;               //[I]지점명                
	public String empno = null;               //[I]사원번호              
	public String ep_nm = null;               //[I]사원명                
	public String pw = null;                  //[I]비밀번호              
	public String slp_no = null;              //[O]전표번호              
	public String rpt_bh_cd = null;           //[O]접수지점코드          
	public String rpt_bh_nm = null;           //[O]접수지점명            
	public String rpt_empno = null;           //[O]접수사원번호          
	public String rpt_ep_nm = null;           //[O]접수사원명            
	public String pdc_cd = null;              //[O]상품코드              
	public String pdc_nm = null;              //[O]상품명                
	public String arc_knd_nm = null;          //[O]보험종류명            
	public String ctc_stat_nm = null;         //[O]계약상태명            
	public String ctc_stat_bh = null;         //[O]계약상태지점          
	public String ctc_stat_dt = null;         //[O]계약상태일자          
	public String ctc_stat_dtnm = null;       //[ ]계약상태세부명        
	public String plhd_nm = null;             //[O]계약자명              
	public String psco_dvn = null;            //[O]개인법인구분          
	public String rrno = null;                //[O]주민등록번호          
	public String exp_bnfc = null;            //[O]만기수익자            
	public String exp_bnfc_rrno = null;       //[O]만기수익자주민등록번호
	public String ins_nm = null;              //[O]피보험자명            
	public String ins_rrno = null;            //[O]피보험자주민등록번호  
	public String arc_pd_dt = null;           //[O]보험시기일자          
	public String arc_et_dt = null;           //[O]보험종기일자          
	public String pym_ycnt = null;            //[O]납입년수              
	public String dfmt_ycnt = null;           //[O]거치년수              
	public String exp_ycnt = null;            //[O]만기년수              
	public String tot_pyms = null;            //[O]총지급금              
	public String fnal_pym_ym = null;         //[O]최종납입년월          
	public String pym_mtd_nm = null;          //[O]납입방법명            
	public String pym_epct_prm = null;        //[O]납입예정보험료        
	public String tot_pym_nts = null;         //[O]총납입횟수            
	public String fnal_pym_nts = null;        //[O]최종납입횟수          
	public String tot_pym_prm = null;         //[O]총납입보험료          
	public String coll_bh_cd = null;          //[O]수금지점코드          
	public String coll_brn_cd = null;         //[O]수금지부코드          
	public String coll_empno = null;          //[O]수금사원번호          
	public String coll_bh_nm = null;          //[O]수금지점명            
	public String coll_brn_nm = null;         //[O]수금지부명            
	public String coll_ep_nm = null;          //[O]수금사원명            
	public String coll_agnc_nm = null;        //[O]수금대리점명          
	public String coll_tlno = null;           //[O]수금전화번호          
	public String wdra_nts = null;            //[O]인출횟수              
	public String spcf_trm_wdra_nts = null;	//[O]특정기간인출횟수      
	public String lmt_bse_nts = null;         //[O]한도기준횟수          
	public String tot_wdra_nts = null;        //[O]총인출횟수            
	public String ymd_dvn = null;             //[O]년월일구분            
	public String exp_amt = null;             //[O]만기금액              
	public String exp_rt = null;              //[O]만기율                
	public String lmt_amt = null;             //[O]한도금액              
	public String rqst_amt = null;            //[I]요청금액              
	public String sprc_amt = null;            //[I]가수금액              
	public String real_pyms = null;           //[I]실지급금              
	public String dprv = null;                //[I]예수금                
	public String sprc_bh = null;             //[I]가수지점              
	public String rlt_cd = null;              //[I]관계코드              
	public String rlt_cd_nm = null;           //[I]관계코드명            
	public String real_revr_nm = null;        //[I]실수령자명            
	public String real_revr_rrno = null;      //[I]실수령자주민등록번호  
	public String slf_dlg_yn = null;          //[I]본인위임여부          
	public String yn_dvcd = null;             //[I]유무구분코드          
	public String pyn_cnpr_sbj_dvn = null;    //[I]지급상대과목구분      
	public String pyn_cnpr_sbj_nm = null;     //[I]지급상대과목명        
	public String dpsr_nm = null;             //[I]예금주명              
	public String dpsr_rrno = null;           //[I]예금주주민등록번호    
	public String dpsr_sme_yn = null;         //[I]예금주동일여부        
	public String sme_yn_dvn = null;          //[I]동일여부구분          
	public String bank_cd = null;             //[I]은행코드              
	public String bank_nm = null;             //[I]은행명                
	public String acc_no = null;              //[I]계좌번호              
	public String dpsr_nrm_cnfm_yn = null;    //[I]예금주정상확인여부    
	public String pyn_dttm = null;            //[I]지급일시              
	public String pyn_time = null;            //[O]지급시간              
	public String pyn_bh_cd = null;           //[O]지급지점코드          
	public String pyn_bh_nm = null;           //[O]지급지점명            
	public String pyn_empno = null;           //[O]지급사원번호          
	public String pyn_ep_nm = null;           //[O]지급사원명            
	public String rmk = null;                 //[O]비고                  
	public String wn_vis_tpcd = null;         //[O]창구방문유형코드      
	public String mang_chek = null;           //[O]운영체크              
	//public String  = null;                    //[ ]                      
	public String plno_1 = null;              //[O]증권번호1             
	public String pdc_cd_1 = null;            //[O]상품코드1             
	public String outp_proc = null;           //[O]출력처리              
	public String outp_dta_fcln = null;       //[O]출력데이터고객용      
	public String outp_dta_uosr = null;       //[O]출력데이터보관용      
	public String outp_dta_cmy_uosr = null;   //[O]출력데이터회사보관용  
	public String ins_lcpl_dvcd = null;       //[O]피보험자소재지구분코드
	public String ply_sqno = null;            //[O]증권일련번호   
	
	public String errorCode = null;
	public String z_msg_cd = null;
	public String returnMessage = null;
	public String z_resp_msg = null;
	
	
	public String getPlno() {
		return plno;
	}
	public void setPlno(String plno) {
		this.plno = plno;
	}
	public String getProc_dt() {
		return proc_dt;
	}
	public void setProc_dt(String proc_dt) {
		this.proc_dt = proc_dt;
	}
	public String getProc_dvcd() {
		return proc_dvcd;
	}
	public void setProc_dvcd(String proc_dvcd) {
		this.proc_dvcd = proc_dvcd;
	}
	public String getBh_cd() {
		return bh_cd;
	}
	public void setBh_cd(String bh_cd) {
		this.bh_cd = bh_cd;
	}
	public String getBh_nm() {
		return bh_nm;
	}
	public void setBh_nm(String bh_nm) {
		this.bh_nm = bh_nm;
	}
	public String getEmpno() {
		return empno;
	}
	public void setEmpno(String empno) {
		this.empno = empno;
	}
	public String getEp_nm() {
		return ep_nm;
	}
	public void setEp_nm(String ep_nm) {
		this.ep_nm = ep_nm;
	}
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}
	public String getSlp_no() {
		return slp_no;
	}
	public void setSlp_no(String slp_no) {
		this.slp_no = slp_no;
	}
	public String getRpt_bh_cd() {
		return rpt_bh_cd;
	}
	public void setRpt_bh_cd(String rpt_bh_cd) {
		this.rpt_bh_cd = rpt_bh_cd;
	}
	public String getRpt_bh_nm() {
		return rpt_bh_nm;
	}
	public void setRpt_bh_nm(String rpt_bh_nm) {
		this.rpt_bh_nm = rpt_bh_nm;
	}
	public String getRpt_empno() {
		return rpt_empno;
	}
	public void setRpt_empno(String rpt_empno) {
		this.rpt_empno = rpt_empno;
	}
	public String getRpt_ep_nm() {
		return rpt_ep_nm;
	}
	public void setRpt_ep_nm(String rpt_ep_nm) {
		this.rpt_ep_nm = rpt_ep_nm;
	}
	public String getPdc_cd() {
		return pdc_cd;
	}
	public void setPdc_cd(String pdc_cd) {
		this.pdc_cd = pdc_cd;
	}
	public String getPdc_nm() {
		return pdc_nm;
	}
	public void setPdc_nm(String pdc_nm) {
		this.pdc_nm = pdc_nm;
	}
	public String getArc_knd_nm() {
		return arc_knd_nm;
	}
	public void setArc_knd_nm(String arc_knd_nm) {
		this.arc_knd_nm = arc_knd_nm;
	}
	public String getCtc_stat_nm() {
		return ctc_stat_nm;
	}
	public void setCtc_stat_nm(String ctc_stat_nm) {
		this.ctc_stat_nm = ctc_stat_nm;
	}
	public String getCtc_stat_bh() {
		return ctc_stat_bh;
	}
	public void setCtc_stat_bh(String ctc_stat_bh) {
		this.ctc_stat_bh = ctc_stat_bh;
	}
	public String getCtc_stat_dt() {
		return ctc_stat_dt;
	}
	public void setCtc_stat_dt(String ctc_stat_dt) {
		this.ctc_stat_dt = ctc_stat_dt;
	}
	public String getCtc_stat_dtnm() {
		return ctc_stat_dtnm;
	}
	public void setCtc_stat_dtnm(String ctc_stat_dtnm) {
		this.ctc_stat_dtnm = ctc_stat_dtnm;
	}
	public String getPlhd_nm() {
		return plhd_nm;
	}
	public void setPlhd_nm(String plhd_nm) {
		this.plhd_nm = plhd_nm;
	}
	public String getPsco_dvn() {
		return psco_dvn;
	}
	public void setPsco_dvn(String psco_dvn) {
		this.psco_dvn = psco_dvn;
	}
	public String getRrno() {
		return rrno;
	}
	public void setRrno(String rrno) {
		this.rrno = rrno;
	}
	public String getExp_bnfc() {
		return exp_bnfc;
	}
	public void setExp_bnfc(String exp_bnfc) {
		this.exp_bnfc = exp_bnfc;
	}
	public String getExp_bnfc_rrno() {
		return exp_bnfc_rrno;
	}
	public void setExp_bnfc_rrno(String exp_bnfc_rrno) {
		this.exp_bnfc_rrno = exp_bnfc_rrno;
	}
	public String getIns_nm() {
		return ins_nm;
	}
	public void setIns_nm(String ins_nm) {
		this.ins_nm = ins_nm;
	}
	public String getIns_rrno() {
		return ins_rrno;
	}
	public void setIns_rrno(String ins_rrno) {
		this.ins_rrno = ins_rrno;
	}
	public String getArc_pd_dt() {
		return arc_pd_dt;
	}
	public void setArc_pd_dt(String arc_pd_dt) {
		this.arc_pd_dt = arc_pd_dt;
	}
	public String getArc_et_dt() {
		return arc_et_dt;
	}
	public void setArc_et_dt(String arc_et_dt) {
		this.arc_et_dt = arc_et_dt;
	}
	public String getPym_ycnt() {
		return pym_ycnt;
	}
	public void setPym_ycnt(String pym_ycnt) {
		this.pym_ycnt = pym_ycnt;
	}
	public String getDfmt_ycnt() {
		return dfmt_ycnt;
	}
	public void setDfmt_ycnt(String dfmt_ycnt) {
		this.dfmt_ycnt = dfmt_ycnt;
	}
	public String getExp_ycnt() {
		return exp_ycnt;
	}
	public void setExp_ycnt(String exp_ycnt) {
		this.exp_ycnt = exp_ycnt;
	}
	public String getTot_pyms() {
		return tot_pyms;
	}
	public void setTot_pyms(String tot_pyms) {
		this.tot_pyms = tot_pyms;
	}
	public String getFnal_pym_ym() {
		return fnal_pym_ym;
	}
	public void setFnal_pym_ym(String fnal_pym_ym) {
		this.fnal_pym_ym = fnal_pym_ym;
	}
	public String getPym_mtd_nm() {
		return pym_mtd_nm;
	}
	public void setPym_mtd_nm(String pym_mtd_nm) {
		this.pym_mtd_nm = pym_mtd_nm;
	}
	public String getPym_epct_prm() {
		return pym_epct_prm;
	}
	public void setPym_epct_prm(String pym_epct_prm) {
		this.pym_epct_prm = pym_epct_prm;
	}
	public String getTot_pym_nts() {
		return tot_pym_nts;
	}
	public void setTot_pym_nts(String tot_pym_nts) {
		this.tot_pym_nts = tot_pym_nts;
	}
	public String getFnal_pym_nts() {
		return fnal_pym_nts;
	}
	public void setFnal_pym_nts(String fnal_pym_nts) {
		this.fnal_pym_nts = fnal_pym_nts;
	}
	public String getTot_pym_prm() {
		return tot_pym_prm;
	}
	public void setTot_pym_prm(String tot_pym_prm) {
		this.tot_pym_prm = tot_pym_prm;
	}
	public String getColl_bh_cd() {
		return coll_bh_cd;
	}
	public void setColl_bh_cd(String coll_bh_cd) {
		this.coll_bh_cd = coll_bh_cd;
	}
	public String getColl_brn_cd() {
		return coll_brn_cd;
	}
	public void setColl_brn_cd(String coll_brn_cd) {
		this.coll_brn_cd = coll_brn_cd;
	}
	public String getColl_empno() {
		return coll_empno;
	}
	public void setColl_empno(String coll_empno) {
		this.coll_empno = coll_empno;
	}
	public String getColl_bh_nm() {
		return coll_bh_nm;
	}
	public void setColl_bh_nm(String coll_bh_nm) {
		this.coll_bh_nm = coll_bh_nm;
	}
	public String getColl_brn_nm() {
		return coll_brn_nm;
	}
	public void setColl_brn_nm(String coll_brn_nm) {
		this.coll_brn_nm = coll_brn_nm;
	}
	public String getColl_ep_nm() {
		return coll_ep_nm;
	}
	public void setColl_ep_nm(String coll_ep_nm) {
		this.coll_ep_nm = coll_ep_nm;
	}
	public String getColl_agnc_nm() {
		return coll_agnc_nm;
	}
	public void setColl_agnc_nm(String coll_agnc_nm) {
		this.coll_agnc_nm = coll_agnc_nm;
	}
	public String getColl_tlno() {
		return coll_tlno;
	}
	public void setColl_tlno(String coll_tlno) {
		this.coll_tlno = coll_tlno;
	}
	public String getWdra_nts() {
		return wdra_nts;
	}
	public void setWdra_nts(String wdra_nts) {
		this.wdra_nts = wdra_nts;
	}
	public String getSpcf_trm_wdra_nts() {
		return spcf_trm_wdra_nts;
	}
	public void setSpcf_trm_wdra_nts(String spcf_trm_wdra_nts) {
		this.spcf_trm_wdra_nts = spcf_trm_wdra_nts;
	}
	public String getLmt_bse_nts() {
		return lmt_bse_nts;
	}
	public void setLmt_bse_nts(String lmt_bse_nts) {
		this.lmt_bse_nts = lmt_bse_nts;
	}
	public String getTot_wdra_nts() {
		return tot_wdra_nts;
	}
	public void setTot_wdra_nts(String tot_wdra_nts) {
		this.tot_wdra_nts = tot_wdra_nts;
	}
	public String getYmd_dvn() {
		return ymd_dvn;
	}
	public void setYmd_dvn(String ymd_dvn) {
		this.ymd_dvn = ymd_dvn;
	}
	public String getExp_amt() {
		return exp_amt;
	}
	public void setExp_amt(String exp_amt) {
		this.exp_amt = exp_amt;
	}
	public String getExp_rt() {
		return exp_rt;
	}
	public void setExp_rt(String exp_rt) {
		this.exp_rt = exp_rt;
	}
	public String getLmt_amt() {
		return lmt_amt;
	}
	public void setLmt_amt(String lmt_amt) {
		this.lmt_amt = lmt_amt;
	}
	public String getRqst_amt() {
		return rqst_amt;
	}
	public void setRqst_amt(String rqst_amt) {
		this.rqst_amt = rqst_amt;
	}
	public String getSprc_amt() {
		return sprc_amt;
	}
	public void setSprc_amt(String sprc_amt) {
		this.sprc_amt = sprc_amt;
	}
	public String getReal_pyms() {
		return real_pyms;
	}
	public void setReal_pyms(String real_pyms) {
		this.real_pyms = real_pyms;
	}
	public String getDprv() {
		return dprv;
	}
	public void setDprv(String dprv) {
		this.dprv = dprv;
	}
	public String getSprc_bh() {
		return sprc_bh;
	}
	public void setSprc_bh(String sprc_bh) {
		this.sprc_bh = sprc_bh;
	}
	public String getRlt_cd() {
		return rlt_cd;
	}
	public void setRlt_cd(String rlt_cd) {
		this.rlt_cd = rlt_cd;
	}
	public String getRlt_cd_nm() {
		return rlt_cd_nm;
	}
	public void setRlt_cd_nm(String rlt_cd_nm) {
		this.rlt_cd_nm = rlt_cd_nm;
	}
	public String getReal_revr_nm() {
		return real_revr_nm;
	}
	public void setReal_revr_nm(String real_revr_nm) {
		this.real_revr_nm = real_revr_nm;
	}
	public String getReal_revr_rrno() {
		return real_revr_rrno;
	}
	public void setReal_revr_rrno(String real_revr_rrno) {
		this.real_revr_rrno = real_revr_rrno;
	}
	public String getSlf_dlg_yn() {
		return slf_dlg_yn;
	}
	public void setSlf_dlg_yn(String slf_dlg_yn) {
		this.slf_dlg_yn = slf_dlg_yn;
	}
	public String getYn_dvcd() {
		return yn_dvcd;
	}
	public void setYn_dvcd(String yn_dvcd) {
		this.yn_dvcd = yn_dvcd;
	}
	public String getPyn_cnpr_sbj_dvn() {
		return pyn_cnpr_sbj_dvn;
	}
	public void setPyn_cnpr_sbj_dvn(String pyn_cnpr_sbj_dvn) {
		this.pyn_cnpr_sbj_dvn = pyn_cnpr_sbj_dvn;
	}
	public String getPyn_cnpr_sbj_nm() {
		return pyn_cnpr_sbj_nm;
	}
	public void setPyn_cnpr_sbj_nm(String pyn_cnpr_sbj_nm) {
		this.pyn_cnpr_sbj_nm = pyn_cnpr_sbj_nm;
	}
	public String getDpsr_nm() {
		return dpsr_nm;
	}
	public void setDpsr_nm(String dpsr_nm) {
		this.dpsr_nm = dpsr_nm;
	}
	public String getDpsr_rrno() {
		return dpsr_rrno;
	}
	public void setDpsr_rrno(String dpsr_rrno) {
		this.dpsr_rrno = dpsr_rrno;
	}
	public String getDpsr_sme_yn() {
		return dpsr_sme_yn;
	}
	public void setDpsr_sme_yn(String dpsr_sme_yn) {
		this.dpsr_sme_yn = dpsr_sme_yn;
	}
	public String getSme_yn_dvn() {
		return sme_yn_dvn;
	}
	public void setSme_yn_dvn(String sme_yn_dvn) {
		this.sme_yn_dvn = sme_yn_dvn;
	}
	public String getBank_cd() {
		return bank_cd;
	}
	public void setBank_cd(String bank_cd) {
		this.bank_cd = bank_cd;
	}
	public String getBank_nm() {
		return bank_nm;
	}
	public void setBank_nm(String bank_nm) {
		this.bank_nm = bank_nm;
	}
	public String getAcc_no() {
		return acc_no;
	}
	public void setAcc_no(String acc_no) {
		this.acc_no = acc_no;
	}
	public String getDpsr_nrm_cnfm_yn() {
		return dpsr_nrm_cnfm_yn;
	}
	public void setDpsr_nrm_cnfm_yn(String dpsr_nrm_cnfm_yn) {
		this.dpsr_nrm_cnfm_yn = dpsr_nrm_cnfm_yn;
	}
	public String getPyn_dttm() {
		return pyn_dttm;
	}
	public void setPyn_dttm(String pyn_dttm) {
		this.pyn_dttm = pyn_dttm;
	}
	public String getPyn_time() {
		return pyn_time;
	}
	public void setPyn_time(String pyn_time) {
		this.pyn_time = pyn_time;
	}
	public String getPyn_bh_cd() {
		return pyn_bh_cd;
	}
	public void setPyn_bh_cd(String pyn_bh_cd) {
		this.pyn_bh_cd = pyn_bh_cd;
	}
	public String getPyn_bh_nm() {
		return pyn_bh_nm;
	}
	public void setPyn_bh_nm(String pyn_bh_nm) {
		this.pyn_bh_nm = pyn_bh_nm;
	}
	public String getPyn_empno() {
		return pyn_empno;
	}
	public void setPyn_empno(String pyn_empno) {
		this.pyn_empno = pyn_empno;
	}
	public String getPyn_ep_nm() {
		return pyn_ep_nm;
	}
	public void setPyn_ep_nm(String pyn_ep_nm) {
		this.pyn_ep_nm = pyn_ep_nm;
	}
	public String getRmk() {
		return rmk;
	}
	public void setRmk(String rmk) {
		this.rmk = rmk;
	}
	public String getWn_vis_tpcd() {
		return wn_vis_tpcd;
	}
	public void setWn_vis_tpcd(String wn_vis_tpcd) {
		this.wn_vis_tpcd = wn_vis_tpcd;
	}
	public String getMang_chek() {
		return mang_chek;
	}
	public void setMang_chek(String mang_chek) {
		this.mang_chek = mang_chek;
	}
	public String getPlno_1() {
		return plno_1;
	}
	public void setPlno_1(String plno_1) {
		this.plno_1 = plno_1;
	}
	public String getPdc_cd_1() {
		return pdc_cd_1;
	}
	public void setPdc_cd_1(String pdc_cd_1) {
		this.pdc_cd_1 = pdc_cd_1;
	}
	public String getOutp_proc() {
		return outp_proc;
	}
	public void setOutp_proc(String outp_proc) {
		this.outp_proc = outp_proc;
	}
	public String getOutp_dta_fcln() {
		return outp_dta_fcln;
	}
	public void setOutp_dta_fcln(String outp_dta_fcln) {
		this.outp_dta_fcln = outp_dta_fcln;
	}
	public String getOutp_dta_uosr() {
		return outp_dta_uosr;
	}
	public void setOutp_dta_uosr(String outp_dta_uosr) {
		this.outp_dta_uosr = outp_dta_uosr;
	}
	public String getOutp_dta_cmy_uosr() {
		return outp_dta_cmy_uosr;
	}
	public void setOutp_dta_cmy_uosr(String outp_dta_cmy_uosr) {
		this.outp_dta_cmy_uosr = outp_dta_cmy_uosr;
	}
	public String getIns_lcpl_dvcd() {
		return ins_lcpl_dvcd;
	}
	public void setIns_lcpl_dvcd(String ins_lcpl_dvcd) {
		this.ins_lcpl_dvcd = ins_lcpl_dvcd;
	}
	public String getPly_sqno() {
		return ply_sqno;
	}
	public void setPly_sqno(String ply_sqno) {
		this.ply_sqno = ply_sqno;
	}
		
}
