// 경계주행거리특약가입처리

package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class MMTI0294VO extends CMMVO{
	
	public String trv_dstc_exca_mtt__plno = "";						// [I/O] 증권번호
	public String trv_dstc_exca_mtt__plan_no = "";					// [I/O] 설계번호
	public String trv_dstc_exca_mtt__plan_dt = "";					// [I/O] 설계일자
	public String trv_dstc_exca_mtt__rnw_plno = "";					// [I/O] 갱신증권번호
	public String trv_dstc_exca_mtt__hdlr_empno = "";				// [I/O] 취급자사원번호
	public String trv_dstc_exca_mtt__rnw_plan_no = "";				// [I/O] 갱신설계번호
	public String trv_dstc_exca_mtt__ins_cust_nm = "";				// [I/O] 피보험자고객명
	public String trv_dstc_exca_mtt__ins_cust_dcmt_no = "";			// [I/O] 피보험자고객식별번호
	public String trv_dstc_exca_mtt__arc_trm_str_dt = "";			// [I/O] 보험기간시작일자
	public String trv_dstc_exca_mtt__arc_trm_fin_dt = "";			// [I/O] 보험기간종료일자
	public String trv_dstc_exca_mtt__hngl_vh_no = "";				// [I/O] 한글차량번호
	public String trv_dstc_exca_mtt__ctp_nm = "";					// [I/O] 차종명
	public String trv_dstc_exca_mtt__frst_trv_dstc = "";			// [I/O] 최초주행거리
	public String trv_dstc_exca_mtt__dst_mtd = "";					// [I/O] 할인방법
	public String trv_dstc_exca_mtt__ctt_dstc = "";					// [I/O] 약정거리
	public String trv_dstc_exca_mtt__phgp_rcod_dt = "";				// [I/O] 사진등재일자
	public String trv_dstc_exca_mtt__tty_eny_dt = "";				//
	public String errorCode = "";
	public String z_resp_msg = "";
	public String z_resp_cd = "";
	
	public String getTrv_dstc_exca_mtt__plno() {
		return trv_dstc_exca_mtt__plno;
	}
	public void setTrv_dstc_exca_mtt__plno(String trv_dstc_exca_mtt__plno) {
		this.trv_dstc_exca_mtt__plno = trv_dstc_exca_mtt__plno;
	}
	public String getTrv_dstc_exca_mtt__plan_no() {
		return trv_dstc_exca_mtt__plan_no;
	}
	public void setTrv_dstc_exca_mtt__plan_no(String trv_dstc_exca_mtt__plan_no) {
		this.trv_dstc_exca_mtt__plan_no = trv_dstc_exca_mtt__plan_no;
	}
	public String getTrv_dstc_exca_mtt__plan_dt() {
		return trv_dstc_exca_mtt__plan_dt;
	}
	public void setTrv_dstc_exca_mtt__plan_dt(String trv_dstc_exca_mtt__plan_dt) {
		this.trv_dstc_exca_mtt__plan_dt = trv_dstc_exca_mtt__plan_dt;
	}
	public String getTrv_dstc_exca_mtt__rnw_plno() {
		return trv_dstc_exca_mtt__rnw_plno;
	}
	public void setTrv_dstc_exca_mtt__rnw_plno(String trv_dstc_exca_mtt__rnw_plno) {
		this.trv_dstc_exca_mtt__rnw_plno = trv_dstc_exca_mtt__rnw_plno;
	}
	public String getTrv_dstc_exca_mtt__hdlr_empno() {
		return trv_dstc_exca_mtt__hdlr_empno;
	}
	public void setTrv_dstc_exca_mtt__hdlr_empno(String trv_dstc_exca_mtt__hdlr_empno) {
		this.trv_dstc_exca_mtt__hdlr_empno = trv_dstc_exca_mtt__hdlr_empno;
	}
	public String getTrv_dstc_exca_mtt__rnw_plan_no() {
		return trv_dstc_exca_mtt__rnw_plan_no;
	}
	public void setTrv_dstc_exca_mtt__rnw_plan_no(String trv_dstc_exca_mtt__rnw_plan_no) {
		this.trv_dstc_exca_mtt__rnw_plan_no = trv_dstc_exca_mtt__rnw_plan_no;
	}
	public String getTrv_dstc_exca_mtt__ins_cust_nm() {
		return trv_dstc_exca_mtt__ins_cust_nm;
	}
	public void setTrv_dstc_exca_mtt__ins_cust_nm(String trv_dstc_exca_mtt__ins_cust_nm) {
		this.trv_dstc_exca_mtt__ins_cust_nm = trv_dstc_exca_mtt__ins_cust_nm;
	}
	public String getTrv_dstc_exca_mtt__ins_cust_dcmt_no() {
		return trv_dstc_exca_mtt__ins_cust_dcmt_no;
	}
	public void setTrv_dstc_exca_mtt__ins_cust_dcmt_no(String trv_dstc_exca_mtt__ins_cust_dcmt_no) {
		this.trv_dstc_exca_mtt__ins_cust_dcmt_no = trv_dstc_exca_mtt__ins_cust_dcmt_no;
	}
	public String getTrv_dstc_exca_mtt__arc_trm_str_dt() {
		return trv_dstc_exca_mtt__arc_trm_str_dt;
	}
	public void setTrv_dstc_exca_mtt__arc_trm_str_dt(String trv_dstc_exca_mtt__arc_trm_str_dt) {
		this.trv_dstc_exca_mtt__arc_trm_str_dt = trv_dstc_exca_mtt__arc_trm_str_dt;
	}
	public String getTrv_dstc_exca_mtt__arc_trm_fin_dt() {
		return trv_dstc_exca_mtt__arc_trm_fin_dt;
	}
	public void setTrv_dstc_exca_mtt__arc_trm_fin_dt(String trv_dstc_exca_mtt__arc_trm_fin_dt) {
		this.trv_dstc_exca_mtt__arc_trm_fin_dt = trv_dstc_exca_mtt__arc_trm_fin_dt;
	}
	public String getTrv_dstc_exca_mtt__hngl_vh_no() {
		return trv_dstc_exca_mtt__hngl_vh_no;
	}
	public void setTrv_dstc_exca_mtt__hngl_vh_no(String trv_dstc_exca_mtt__hngl_vh_no) {
		this.trv_dstc_exca_mtt__hngl_vh_no = trv_dstc_exca_mtt__hngl_vh_no;
	}
	public String getTrv_dstc_exca_mtt__ctp_nm() {
		return trv_dstc_exca_mtt__ctp_nm;
	}
	public void setTrv_dstc_exca_mtt__ctp_nm(String trv_dstc_exca_mtt__ctp_nm) {
		this.trv_dstc_exca_mtt__ctp_nm = trv_dstc_exca_mtt__ctp_nm;
	}
	public String getTrv_dstc_exca_mtt__frst_trv_dstc() {
		return trv_dstc_exca_mtt__frst_trv_dstc;
	}
	public void setTrv_dstc_exca_mtt__frst_trv_dstc(String trv_dstc_exca_mtt__frst_trv_dstc) {
		this.trv_dstc_exca_mtt__frst_trv_dstc = trv_dstc_exca_mtt__frst_trv_dstc;
	}
	public String getTrv_dstc_exca_mtt__dst_mtd() {
		return trv_dstc_exca_mtt__dst_mtd;
	}
	public void setTrv_dstc_exca_mtt__dst_mtd(String trv_dstc_exca_mtt__dst_mtd) {
		this.trv_dstc_exca_mtt__dst_mtd = trv_dstc_exca_mtt__dst_mtd;
	}
	public String getTrv_dstc_exca_mtt__ctt_dstc() {
		return trv_dstc_exca_mtt__ctt_dstc;
	}
	public void setTrv_dstc_exca_mtt__ctt_dstc(String trv_dstc_exca_mtt__ctt_dstc) {
		this.trv_dstc_exca_mtt__ctt_dstc = trv_dstc_exca_mtt__ctt_dstc;
	}
	public String getTrv_dstc_exca_mtt__phgp_rcod_dt() {
		return trv_dstc_exca_mtt__phgp_rcod_dt;
	}
	public void setTrv_dstc_exca_mtt__phgp_rcod_dt(String trv_dstc_exca_mtt__phgp_rcod_dt) {
		this.trv_dstc_exca_mtt__phgp_rcod_dt = trv_dstc_exca_mtt__phgp_rcod_dt;
	}
	public String getTrv_dstc_exca_mtt__tty_eny_dt() {
		return trv_dstc_exca_mtt__tty_eny_dt;
	}
	public void setTrv_dstc_exca_mtt__tty_eny_dt(String trv_dstc_exca_mtt__tty_eny_dt) {
		this.trv_dstc_exca_mtt__tty_eny_dt = trv_dstc_exca_mtt__tty_eny_dt;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getZ_resp_msg() {
		return z_resp_msg;
	}
	public void setZ_resp_msg(String z_resp_msg) {
		this.z_resp_msg = z_resp_msg;
	}
	public String getZ_resp_cd() {
		return z_resp_cd;
	}
	public void setZ_resp_cd(String z_resp_cd) {
		this.z_resp_cd = z_resp_cd;
	}
	
}
