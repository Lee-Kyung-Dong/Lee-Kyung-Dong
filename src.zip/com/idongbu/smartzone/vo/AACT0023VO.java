package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class AACT0023VO extends CMMVO{
	//전문필드
		public String bank_cd = "";  //[I] 은행코드 RE_BANK_CD 은행코드
		public String bank_nm = "";  //[I] 은행명 H_RE_BANK_NM 은행명
		public String acc_no = "";  //[I] 계좌번호 RE_GYEJWA_NO 계좌번호
		public String cust_rsdn_no = "";  //[I] 고객주민번호 RE_GOGEK_NO 고객주민번호
		public String dpsr_nm = "";  //[O] 예금주명 H_RE_YEGMJU_NM 예금주명
		public String returnMessage = "";  //[O] 메시지 H_RE_MESSAGE_NM 메시지
		public String resp_cd = "";  //[O] 응답코드 RE_RETURN_CD 응답코드
		public String bz_dvn = "";  //[I] 업무구분 RE_UPMU_GUBUN 업무구분
		public String pyr_no = "";  //[I] 납부자번호 RE_NAPBUJA_CD 납부자번호
		public String regt_dvn = "";  //[O] 등록구분 RE_ASSIGN_GBN 등록구분
		public String regt_rsl = "";  //[O] 등록결과 RE_RETURN_CD_AS 등록결과
		public String scrn_fld_ctl = "";  //[O] 화면필드제어 SE_DERR_FBRT_PGM 화면 BRIGHT
		public String scrn_er_fld = "";  //[O] 화면오류필드 SE_DERR_FLD 오류 FIELD
		public String scrn_pg = "";  //[O] 화면프로그램 SE_PROTECT_PGM 프로텍트PGM
		public String scrn_fld = "";  //[O] 화면필드 SE_PROTECT_FLD 프로텍트 FIELD 
		public String errorCode = "";  //[O] 에러코드
		public String msg = "";  //[O] 메시지 H_RE_MESSAGE_NM 메시지
		public String z_resp_msg = "";
		
		
		
		public String getErrorCode() {
			return errorCode;
		}
		public void setErrorCode(String errorCode) {
			this.errorCode = errorCode;
		}
		public String getMsg() {
			return msg;
		}
		public void setMsg(String msg) {
			this.msg = msg;
		}
		public String getBank_cd() {
			return bank_cd;
		}
		public void setBank_cd(String bank_cd) {
			this.bank_cd = bank_cd;
		}
		public String getBank_nm() {
			return bank_nm;
		}
		public void setBank_nm(String bank_nm) {
			this.bank_nm = bank_nm;
		}
		public String getAcc_no() {
			return acc_no;
		}
		public void setAcc_no(String acc_no) {
			this.acc_no = acc_no;
		}
		public String getCust_rsdn_no() {
			return cust_rsdn_no;
		}
		public void setCust_rsdn_no(String cust_rsdn_no) {
			this.cust_rsdn_no = cust_rsdn_no;
		}
		public String getDpsr_nm() {
			return dpsr_nm;
		}
		public void setDpsr_nm(String dpsr_nm) {
			this.dpsr_nm = dpsr_nm;
		}
		public String getReturnMessage() {
			return returnMessage;
		}
		public void setReturnMessage(String returnMessage) {
			this.returnMessage = returnMessage;
		}
		public String getResp_cd() {
			return resp_cd;
		}
		public void setResp_cd(String resp_cd) {
			this.resp_cd = resp_cd;
		}
		public String getBz_dvn() {
			return bz_dvn;
		}
		public void setBz_dvn(String bz_dvn) {
			this.bz_dvn = bz_dvn;
		}
		public String getPyr_no() {
			return pyr_no;
		}
		public void setPyr_no(String pyr_no) {
			this.pyr_no = pyr_no;
		}
		public String getRegt_dvn() {
			return regt_dvn;
		}
		public void setRegt_dvn(String regt_dvn) {
			this.regt_dvn = regt_dvn;
		}
		public String getRegt_rsl() {
			return regt_rsl;
		}
		public void setRegt_rsl(String regt_rsl) {
			this.regt_rsl = regt_rsl;
		}
		public String getScrn_fld_ctl() {
			return scrn_fld_ctl;
		}
		public void setScrn_fld_ctl(String scrn_fld_ctl) {
			this.scrn_fld_ctl = scrn_fld_ctl;
		}
		public String getScrn_er_fld() {
			return scrn_er_fld;
		}
		public void setScrn_er_fld(String scrn_er_fld) {
			this.scrn_er_fld = scrn_er_fld;
		}
		public String getScrn_pg() {
			return scrn_pg;
		}
		public void setScrn_pg(String scrn_pg) {
			this.scrn_pg = scrn_pg;
		}
		public String getScrn_fld() {
			return scrn_fld;
		}
		public void setScrn_fld(String scrn_fld) {
			this.scrn_fld = scrn_fld;
		}
		
		/**
		 * @return the z_resp_msg
		 */
		public String getZ_resp_msg() {
			return z_resp_msg;
		}
		/**
		 * @param z_resp_msg the z_resp_msg to set
		 */
		public void setZ_resp_msg(String z_resp_msg) {
			this.z_resp_msg = z_resp_msg;
		}

		
}
