package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

// CCLM0505 보험금지급내역관리
public class CCLM0505VO extends CMMVO{

	//전문필드
	public String accd_rpt_no = "";			//[I] 사고접수번호
	public String accd_oj_dvcd = "";		//[I] 사고목적구분코드
	public String accd_oj_rnk = "";			//[I] 사고목적서열
	public String ost_ds_sqno = "";			//[I] 추산결정일련번호
	public String clam_cvr_cd = "";			//[I] 보상담보코드
	public String pyn_atl_lgcg_cd = "";		//[I] 지급항목대분류코드
	
	public String[] ecvr_pyn__pyn_sno = new String[0];			//[O] 지급순번
	public String[] ecvr_pyn__accd_rpt_no = new String[0];		//[O] 사고접수번호
	public String[] ecvr_pyn__accd_oj_dvcd = new String[0];		//[O] 사고목적구분코드
	public String[] ecvr_pyn__accd_oj_rnk = new String[0];		//[O] 사고목적서열
	public String[] ecvr_pyn__askg_cn = new String[0];			//[O] 청구내용
	public String[] ecvr_pyn__askg_typ = new String[0];			//[O] 청구유형
	public String[] ecvr_pyn__askg_amt = new String[0];			//[O] 청구금액
	public String[] ecvr_pyn__clam_xpt_amt = new String[0];		//[O] 보상제외금액
	public String[] ecvr_pyn__clam_xpt_rs = new String[0];		//[O] 보상제외사유
	public String[] ecvr_pyn__dct_amt = new String[0];			//[O] 공제금액
	public String[] ecvr_pyn__pyn_bnf = new String[0];			//[O] 지급보험금
	public String[] ecvr_pyn__pron_sar_yn = new String[0];		//[O] 비례분담여부
	
	public String getAccd_rpt_no() {
		return accd_rpt_no;
	}
	public void setAccd_rpt_no(String accd_rpt_no) {
		this.accd_rpt_no = accd_rpt_no;
	}
	public String getAccd_oj_dvcd() {
		return accd_oj_dvcd;
	}
	public void setAccd_oj_dvcd(String accd_oj_dvcd) {
		this.accd_oj_dvcd = accd_oj_dvcd;
	}
	public String getAccd_oj_rnk() {
		return accd_oj_rnk;
	}
	public void setAccd_oj_rnk(String accd_oj_rnk) {
		this.accd_oj_rnk = accd_oj_rnk;
	}
	public String getOst_ds_sqno() {
		return ost_ds_sqno;
	}
	public void setOst_ds_sqno(String ost_ds_sqno) {
		this.ost_ds_sqno = ost_ds_sqno;
	}
	public String getClam_cvr_cd() {
		return clam_cvr_cd;
	}
	public void setClam_cvr_cd(String clam_cvr_cd) {
		this.clam_cvr_cd = clam_cvr_cd;
	}
	public String getPyn_atl_lgcg_cd() {
		return pyn_atl_lgcg_cd;
	}
	public void setPyn_atl_lgcg_cd(String pyn_atl_lgcg_cd) {
		this.pyn_atl_lgcg_cd = pyn_atl_lgcg_cd;
	}
	public String[] getEcvr_pyn__pyn_sno() {
		return ecvr_pyn__pyn_sno;
	}
	public void setEcvr_pyn__pyn_sno(String[] ecvr_pyn__pyn_sno) {
		this.ecvr_pyn__pyn_sno = ecvr_pyn__pyn_sno;
	}
	public String[] getEcvr_pyn__accd_rpt_no() {
		return ecvr_pyn__accd_rpt_no;
	}
	public void setEcvr_pyn__accd_rpt_no(String[] ecvr_pyn__accd_rpt_no) {
		this.ecvr_pyn__accd_rpt_no = ecvr_pyn__accd_rpt_no;
	}
	public String[] getEcvr_pyn__accd_oj_dvcd() {
		return ecvr_pyn__accd_oj_dvcd;
	}
	public void setEcvr_pyn__accd_oj_dvcd(String[] ecvr_pyn__accd_oj_dvcd) {
		this.ecvr_pyn__accd_oj_dvcd = ecvr_pyn__accd_oj_dvcd;
	}
	public String[] getEcvr_pyn__accd_oj_rnk() {
		return ecvr_pyn__accd_oj_rnk;
	}
	public void setEcvr_pyn__accd_oj_rnk(String[] ecvr_pyn__accd_oj_rnk) {
		this.ecvr_pyn__accd_oj_rnk = ecvr_pyn__accd_oj_rnk;
	}
	public String[] getEcvr_pyn__askg_cn() {
		return ecvr_pyn__askg_cn;
	}
	public void setEcvr_pyn__askg_cn(String[] ecvr_pyn__askg_cn) {
		this.ecvr_pyn__askg_cn = ecvr_pyn__askg_cn;
	}
	public String[] getEcvr_pyn__askg_typ() {
		return ecvr_pyn__askg_typ;
	}
	public void setEcvr_pyn__askg_typ(String[] ecvr_pyn__askg_typ) {
		this.ecvr_pyn__askg_typ = ecvr_pyn__askg_typ;
	}
	public String[] getEcvr_pyn__askg_amt() {
		return ecvr_pyn__askg_amt;
	}
	public void setEcvr_pyn__askg_amt(String[] ecvr_pyn__askg_amt) {
		this.ecvr_pyn__askg_amt = ecvr_pyn__askg_amt;
	}
	public String[] getEcvr_pyn__clam_xpt_amt() {
		return ecvr_pyn__clam_xpt_amt;
	}
	public void setEcvr_pyn__clam_xpt_amt(String[] ecvr_pyn__clam_xpt_amt) {
		this.ecvr_pyn__clam_xpt_amt = ecvr_pyn__clam_xpt_amt;
	}
	public String[] getEcvr_pyn__clam_xpt_rs() {
		return ecvr_pyn__clam_xpt_rs;
	}
	public void setEcvr_pyn__clam_xpt_rs(String[] ecvr_pyn__clam_xpt_rs) {
		this.ecvr_pyn__clam_xpt_rs = ecvr_pyn__clam_xpt_rs;
	}
	public String[] getEcvr_pyn__dct_amt() {
		return ecvr_pyn__dct_amt;
	}
	public void setEcvr_pyn__dct_amt(String[] ecvr_pyn__dct_amt) {
		this.ecvr_pyn__dct_amt = ecvr_pyn__dct_amt;
	}
	public String[] getEcvr_pyn__pyn_bnf() {
		return ecvr_pyn__pyn_bnf;
	}
	public void setEcvr_pyn__pyn_bnf(String[] ecvr_pyn__pyn_bnf) {
		this.ecvr_pyn__pyn_bnf = ecvr_pyn__pyn_bnf;
	}
	public String[] getEcvr_pyn__pron_sar_yn() {
		return ecvr_pyn__pron_sar_yn;
	}
	public void setEcvr_pyn__pron_sar_yn(String[] ecvr_pyn__pron_sar_yn) {
		this.ecvr_pyn__pron_sar_yn = ecvr_pyn__pron_sar_yn;
	}

}
