package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class EAST0039VO extends CMMVO{
	//전문필드
		public String funt_key = "";  //[I] 기능키 CC_FUN_KEY 기능키
		public String plno = "";  //[I] 증권번호 JJ_POLI_NO 증권번호
		// 차세대 2차 전환 시작 필드 추가 (김도연 2014.02.14)
		public String ins_lcpl_dvcd = "";  //[I] 피보험자소재지구분코드  
		public String ply_sqno = "";  //[I] 증권일련번호  
		// 차세대 2차 전환 종료 필드 추가 (김도연 2014.02.14) 
		public String inpd_nm = "";  //[O] 보종명 HJ_BJ_NAME 보종명
		public String inpd_cd = "";  //[O] 보종코드 inpd_cd 보종코드
		public String proc_bh = "";  //[I] 처리지점 JJ_CHERI_JIJUM 처리지점
		public String proc_empno = "";  //[I] 처리사원번호 JJ_CHERI_SAWON 처리사원번호
		public String pw = "";  //[I] 비밀번호 JJ_PASSWORD 비밀번호
		public String plhd_nm = "";  //[O] 계약자명 HJ_GYEYAK_NM 계약자명
		public String plhd_rsdn_no = "";  //[O] 계약자주민번호 JJ_GYEYAK_NO 계약자 주민번호
		public String fnal_rckn_dt = "";  //[O] 최종기산일자 JJ_LAST_GISAN_YMD 최종 기산일자
		public String crd_coll_yn = "";  //[O] 카드수금여부 JJ_CARD_SUKUM 카드수금여부
		public String re_askg_nm = "";  //[O] 재청구명 HJ_JE_CHUNGGU_NM 재청구명
		public String coll_mtd_cd = "";  //[I/O] 수금방법코드 JJ_SUKUM_BANGCD 수금방법코드
		public String coll_mtd_nm = "";  //[O] 수금방법명 HJ_SUKUM_BANGNM 수금방법명
		public String proc_slc = "";  //[I] 처리선택 JJ_SUNTAK_CD 처리선택
		public String bank_cd = "";  //[I/O] 은행코드 JJ_BANK_CD 은행코드
		public String bank_nm = "";  //[O] 은행명 HJ_BANK_NM 은행명
		public String acc_no = "";  //[I/O] 계좌번호 JJ_GYEJWA_NO 계좌번호
		public String dpsr_rlt_cd = "";  //[I/O] 예금주관계코드 JJ_YE_GWANGE_CD 예금주 관계코드
		public String dpsr_rlt_nm = "";  //[I/O] 예금주관계명 HJ_YE_GWANGE_NM 예금주 관계명
		public String dpsr_nm = "";  //[I/O] 예금주명 HJ_YEGMJU_NM 예금주명
		public String dpsr_rsdn_no = "";  //[I/O] 예금주주민번호 JJ_YE_JUMIN 예금주 주민번호
		public String dpsr_tlno = "";  //[I/O] 예금주전화번호 JJ_YEGMJU_TEL 예금주 전화번호
		public String tsfr_dd = "";  //[I/O] 이체일 JJ_ICHE_SDD 이체일
		public String tsfr_dd_yy = "";  //[I] 이체일년 JJ_ICHE_SYY 이체일 년
		public String tsfr_dd_mon = "";  //[I] 이체일월 JJ_ICHE_SMM 이체일 월
		public String wn_vis_tpcd = "";  //[I] 창구방문유형코드 JJ_VIS_CD 창구방문유형코드
		public String errorCode = "";  // 에러코드
		
		public String wthd_csn_evd_dat_dvcd = ""; // [I] 출금동의증빙자료구분코드
		public String wthd_csn_evd_dat_inpt_dvcd = ""; // [I] 출금동의증빙자료입력구분코드
		public String wthd_csn_evd_dat_val = ""; // [I] 출금동의증빙자료값
		
		public String getFunt_key() {
			return funt_key;
		}
		public void setFunt_key(String funt_key) {
			this.funt_key = funt_key;
		}
		public String getPlno() {
			return plno;
		}
		public void setPlno(String plno) {
			this.plno = plno;
		}
		public String getIns_lcpl_dvcd() {
			return ins_lcpl_dvcd;
		}
		public void setIns_lcpl_dvcd(String ins_lcpl_dvcd) {
			this.ins_lcpl_dvcd = ins_lcpl_dvcd;
		}
		public String getPly_sqno() {
			return ply_sqno;
		}
		public void setPly_sqno(String ply_sqno) {
			this.ply_sqno = ply_sqno;
		}
		public String getInpd_nm() {
			return inpd_nm;
		}
		public void setInpd_nm(String inpd_nm) {
			this.inpd_nm = inpd_nm;
		}
		public String getInpd_cd() {
			return inpd_cd;
		}
		public void setInpd_cd(String inpd_cd) {
			this.inpd_cd = inpd_cd;
		}
		public String getProc_bh() {
			return proc_bh;
		}
		public void setProc_bh(String proc_bh) {
			this.proc_bh = proc_bh;
		}
		public String getProc_empno() {
			return proc_empno;
		}
		public void setProc_empno(String proc_empno) {
			this.proc_empno = proc_empno;
		}
		public String getPw() {
			return pw;
		}
		public void setPw(String pw) {
			this.pw = pw;
		}
		public String getPlhd_nm() {
			return plhd_nm;
		}
		public void setPlhd_nm(String plhd_nm) {
			this.plhd_nm = plhd_nm;
		}
		public String getPlhd_rsdn_no() {
			return plhd_rsdn_no;
		}
		public void setPlhd_rsdn_no(String plhd_rsdn_no) {
			this.plhd_rsdn_no = plhd_rsdn_no;
		}
		public String getFnal_rckn_dt() {
			return fnal_rckn_dt;
		}
		public void setFnal_rckn_dt(String fnal_rckn_dt) {
			this.fnal_rckn_dt = fnal_rckn_dt;
		}
		public String getCrd_coll_yn() {
			return crd_coll_yn;
		}
		public void setCrd_coll_yn(String crd_coll_yn) {
			this.crd_coll_yn = crd_coll_yn;
		}
		public String getRe_askg_nm() {
			return re_askg_nm;
		}
		public void setRe_askg_nm(String re_askg_nm) {
			this.re_askg_nm = re_askg_nm;
		}
		public String getColl_mtd_cd() {
			return coll_mtd_cd;
		}
		public void setColl_mtd_cd(String coll_mtd_cd) {
			this.coll_mtd_cd = coll_mtd_cd;
		}
		public String getColl_mtd_nm() {
			return coll_mtd_nm;
		}
		public void setColl_mtd_nm(String coll_mtd_nm) {
			this.coll_mtd_nm = coll_mtd_nm;
		}
		public String getProc_slc() {
			return proc_slc;
		}
		public void setProc_slc(String proc_slc) {
			this.proc_slc = proc_slc;
		}
		public String getBank_cd() {
			return bank_cd;
		}
		public void setBank_cd(String bank_cd) {
			this.bank_cd = bank_cd;
		}
		public String getBank_nm() {
			return bank_nm;
		}
		public void setBank_nm(String bank_nm) {
			this.bank_nm = bank_nm;
		}
		public String getAcc_no() {
			return acc_no;
		}
		public void setAcc_no(String acc_no) {
			this.acc_no = acc_no;
		}
		public String getDpsr_rlt_cd() {
			return dpsr_rlt_cd;
		}
		public void setDpsr_rlt_cd(String dpsr_rlt_cd) {
			this.dpsr_rlt_cd = dpsr_rlt_cd;
		}
		public String getDpsr_rlt_nm() {
			return dpsr_rlt_nm;
		}
		public void setDpsr_rlt_nm(String dpsr_rlt_nm) {
			this.dpsr_rlt_nm = dpsr_rlt_nm;
		}
		public String getDpsr_nm() {
			return dpsr_nm;
		}
		public void setDpsr_nm(String dpsr_nm) {
			this.dpsr_nm = dpsr_nm;
		}
		public String getDpsr_rsdn_no() {
			return dpsr_rsdn_no;
		}
		public void setDpsr_rsdn_no(String dpsr_rsdn_no) {
			this.dpsr_rsdn_no = dpsr_rsdn_no;
		}
		public String getDpsr_tlno() {
			return dpsr_tlno;
		}
		public void setDpsr_tlno(String dpsr_tlno) {
			this.dpsr_tlno = dpsr_tlno;
		}
		public String getTsfr_dd() {
			return tsfr_dd;
		}
		public void setTsfr_dd(String tsfr_dd) {
			this.tsfr_dd = tsfr_dd;
		}
		public String getTsfr_dd_yy() {
			return tsfr_dd_yy;
		}
		public void setTsfr_dd_yy(String tsfr_dd_yy) {
			this.tsfr_dd_yy = tsfr_dd_yy;
		}
		public String getTsfr_dd_mon() {
			return tsfr_dd_mon;
		}
		public void setTsfr_dd_mon(String tsfr_dd_mon) {
			this.tsfr_dd_mon = tsfr_dd_mon;
		}
		public String getWn_vis_tpcd() {
			return wn_vis_tpcd;
		}
		public void setWn_vis_tpcd(String wn_vis_tpcd) {
			this.wn_vis_tpcd = wn_vis_tpcd;
		}
		
		public String getWthd_csn_evd_dat_dvcd() {
			return wthd_csn_evd_dat_dvcd;
		}
		public void setWthd_csn_evd_dat_dvcd(String wthd_csn_evd_dat_dvcd) {
			this.wthd_csn_evd_dat_dvcd = wthd_csn_evd_dat_dvcd;
		}
		public String getWthd_csn_evd_dat_inpt_dvcd() {
			return wthd_csn_evd_dat_inpt_dvcd;
		}
		public void setWthd_csn_evd_dat_inpt_dvcd(String wthd_csn_evd_dat_inpt_dvcd) {
			this.wthd_csn_evd_dat_inpt_dvcd = wthd_csn_evd_dat_inpt_dvcd;
		}
		public String getWthd_csn_evd_dat_val() {
			return wthd_csn_evd_dat_val;
		}
		public void setWthd_csn_evd_dat_val(String wthd_csn_evd_dat_val) {
			this.wthd_csn_evd_dat_val = wthd_csn_evd_dat_val;
		}		
}
