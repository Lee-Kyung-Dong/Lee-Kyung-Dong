package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class CCLM0009VO extends CMMVO{
	public String rsdn_no = "";  //[I] 주민번호 LK_I_GOGEK_NO 고객번호
	public String accd_dt_1 = "";  //[I] 사고일자1 LK_I_SAGO_FROM 사고번호FROM
	public String accd_dt_2 = "";  //[I] 사고일자2 LK_I_SAGO_TO 사고번TO
	public String bdnp_dvn = "";  //[I] 인물구분 LK_INMUL_GB 인물구분
	
	public String[] rpt_if__bdnp_dvn = new String[0];  //[O] 접수정보_인물구분 LK_INMUL_GB 인물구분
	public String[] rpt_if__accd_rpt_no = new String[0];  //[O] 접수정보_사고접수번호 LK_SAGO_JUBSU_NO 사고접수번호
	public String[] rpt_if__accd_oj_dvcd = new String[0];  //[] 접수정보_사고목적구분코드  
	public String[] rpt_if__accd_oj_rnk = new String[0];  //[] 접수정보_사고목적서열  
	public String[] rpt_if__accd_typ_lgcg_cd = new String[0];  //[O] 접수정보_사고유형대분류코드 LK_SAGO_TYPE_CD 사고접수TYPE
	public String[] rpt_if__accd_typ_lgcg_nm = new String[0];  //[O] 접수정보_사고유형대분류명 LK_H_SAGO_TYPE_NM 사고접수TYPE명
	public String[] rpt_if__accd_typ_mdcg_cd = new String[0];  //[O] 접수정보_사고유형중분류코드 LK_SAGO_WONIN_CD 사고원인
	public String[] rpt_if__accd_typ_mdcg_nm = new String[0];  //[O] 접수정보_사고유형중분류명  
	public String[] rpt_if__cnsl_no = new String[0];  //[O] 접수정보_상담번호 LK_SANGDAM_NO 상담번호
	public String[] rpt_if__accd_dttm = new String[0];  //[O] 접수정보_사고일시 LK_SAGO_YMDSB 사고일시
	public String[] rpt_if__accd_prg_crs_cd = new String[0];  //[O] 접수정보_사고진행과정코드 LK_JINHANG_GB 진행구분
	public String[] rpt_if__accd_prg_crs_nm = new String[0];  //[O] 접수정보_사고진행과정명 LK_H_JINHANG_GB 진행구분명
	public String[] rpt_if__accd_rpt_dt = new String[0]; //[O] 최종접수일
	
	public String getRsdn_no() {
		return rsdn_no;
	}
	public void setRsdn_no(String rsdn_no) {
		this.rsdn_no = rsdn_no;
	}
	public String getAccd_dt_1() {
		return accd_dt_1;
	}
	public void setAccd_dt_1(String accd_dt_1) {
		this.accd_dt_1 = accd_dt_1;
	}
	public String getAccd_dt_2() {
		return accd_dt_2;
	}
	public void setAccd_dt_2(String accd_dt_2) {
		this.accd_dt_2 = accd_dt_2;
	}
	public String getBdnp_dvn() {
		return bdnp_dvn;
	}
	public void setBdnp_dvn(String bdnp_dvn) {
		this.bdnp_dvn = bdnp_dvn;
	}
	public String[] getRpt_if__bdnp_dvn() {
		return rpt_if__bdnp_dvn;
	}
	public void setRpt_if__bdnp_dvn(String[] rpt_if__bdnp_dvn) {
		this.rpt_if__bdnp_dvn = rpt_if__bdnp_dvn;
	}
	public String[] getRpt_if__accd_rpt_no() {
		return rpt_if__accd_rpt_no;
	}
	public void setRpt_if__accd_rpt_no(String[] rpt_if__accd_rpt_no) {
		this.rpt_if__accd_rpt_no = rpt_if__accd_rpt_no;
	}
	public String[] getRpt_if__accd_oj_dvcd() {
		return rpt_if__accd_oj_dvcd;
	}
	public void setRpt_if__accd_oj_dvcd(String[] rpt_if__accd_oj_dvcd) {
		this.rpt_if__accd_oj_dvcd = rpt_if__accd_oj_dvcd;
	}
	public String[] getRpt_if__accd_oj_rnk() {
		return rpt_if__accd_oj_rnk;
	}
	public void setRpt_if__accd_oj_rnk(String[] rpt_if__accd_oj_rnk) {
		this.rpt_if__accd_oj_rnk = rpt_if__accd_oj_rnk;
	}
	public String[] getRpt_if__accd_typ_lgcg_cd() {
		return rpt_if__accd_typ_lgcg_cd;
	}
	public void setRpt_if__accd_typ_lgcg_cd(String[] rpt_if__accd_typ_lgcg_cd) {
		this.rpt_if__accd_typ_lgcg_cd = rpt_if__accd_typ_lgcg_cd;
	}
	public String[] getRpt_if__accd_typ_lgcg_nm() {
		return rpt_if__accd_typ_lgcg_nm;
	}
	public void setRpt_if__accd_typ_lgcg_nm(String[] rpt_if__accd_typ_lgcg_nm) {
		this.rpt_if__accd_typ_lgcg_nm = rpt_if__accd_typ_lgcg_nm;
	}
	public String[] getRpt_if__accd_typ_mdcg_cd() {
		return rpt_if__accd_typ_mdcg_cd;
	}
	public void setRpt_if__accd_typ_mdcg_cd(String[] rpt_if__accd_typ_mdcg_cd) {
		this.rpt_if__accd_typ_mdcg_cd = rpt_if__accd_typ_mdcg_cd;
	}
	public String[] getRpt_if__accd_typ_mdcg_nm() {
		return rpt_if__accd_typ_mdcg_nm;
	}
	public void setRpt_if__accd_typ_mdcg_nm(String[] rpt_if__accd_typ_mdcg_nm) {
		this.rpt_if__accd_typ_mdcg_nm = rpt_if__accd_typ_mdcg_nm;
	}
	public String[] getRpt_if__cnsl_no() {
		return rpt_if__cnsl_no;
	}
	public void setRpt_if__cnsl_no(String[] rpt_if__cnsl_no) {
		this.rpt_if__cnsl_no = rpt_if__cnsl_no;
	}
	public String[] getRpt_if__accd_dttm() {
		return rpt_if__accd_dttm;
	}
	public void setRpt_if__accd_dttm(String[] rpt_if__accd_dttm) {
		this.rpt_if__accd_dttm = rpt_if__accd_dttm;
	}
	public String[] getRpt_if__accd_prg_crs_cd() {
		return rpt_if__accd_prg_crs_cd;
	}
	public void setRpt_if__accd_prg_crs_cd(String[] rpt_if__accd_prg_crs_cd) {
		this.rpt_if__accd_prg_crs_cd = rpt_if__accd_prg_crs_cd;
	}
	public String[] getRpt_if__accd_prg_crs_nm() {
		return rpt_if__accd_prg_crs_nm;
	}
	public void setRpt_if__accd_prg_crs_nm(String[] rpt_if__accd_prg_crs_nm) {
		this.rpt_if__accd_prg_crs_nm = rpt_if__accd_prg_crs_nm;
	}
	
	/**
	 * @return the rpt_if__accd_rpt_dt
	 */
	public String[] getRpt_if__accd_rpt_dt() {
		return rpt_if__accd_rpt_dt;
	}
	/**
	 * @param rpt_if__accd_rpt_dt the rpt_if__accd_rpt_dt to set
	 */
	public void setRpt_if__accd_rpt_dt(String[] rpt_if__accd_rpt_dt) {
		this.rpt_if__accd_rpt_dt = rpt_if__accd_rpt_dt;
	}	
	
}
