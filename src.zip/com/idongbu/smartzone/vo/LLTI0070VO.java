package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class LLTI0070VO extends CMMVO{
	
	//전문필드
		public String plno = "";  //[I] 증권번호 JJ_POLI_NO 증권번호
		public String ctrmf_sqno = "";  //[I] 계약변경일련번호 JJ_BESU_SEQ 배서번호
		public String dvn = "";  //[I] 구분 JJ_SEL_GB 구분
		public String ctc_id = "";  //[O] 계약id  
		public String pdc_cd = "";  //[O] 상품코드 JJ_BJ_CD 보종코드
		public String scy_dvn = "";  //[O] 단체구분 JJ_DANCHE_GB 단체구분
		public String inpd_nm = "";  //[O] 보종명 HJ_BJ_NAME 보종명
		public String pdc_dvn = "";  //[O] 상품구분 HJ_BJ_GBN 보종구분
		public String cust_dvn = "";  //[O] 고객구분 JJ_GOGEK_GB 고객구분
		public String arc_pd_dt = "";  //[O] 보험시기일자 JJ_BH_SYMD 보험시기
		public String arc_et_dt = "";  //[O] 보험종기일자 JJ_BH_EYMD 보험종기
		public String arc_trm_nm = "";  //[O] 보험기간명 HJ_BH_NM 보험기간명
		public String apl_dt = "";  //[O] 청약일자 JJ_CHUNG_YMD 청약일
		public String plhd_nm = "";  //[O] 계약자명 HJ_GYE_NAME 계약자명
		public String plhd_rrno = "";  //[O] 계약자주민등록번호 JJ_GYE_JUMIN 계약자주민번호
		public String plhd_tlno_1 = "";  //[O] 계약자전화번호1 JJ_GYE_TEL1 게약자전화번호1
		public String plhd_tlno_2 = "";  //[O] 계약자전화번호2 JJ_GYE_TEL2 게약자전화번호2
		public String plhd_tlno_3 = "";  //[O] 계약자전화번호3 JJ_GYE_TEL3 게약자전화번호3
		public String ctry_nm = "";  //[O] 국가명 HJ_GUKGA_NM 국가명
		public String plhd_psno_1 = "";  //[O] 계약자우편번호1 JJ_GYE_ZIP1 계약자우편번호1
		public String plhd_psno_2 = "";  //[O] 계약자우편번호2 JJ_GYE_ZIP2 계약자우편번호2
		public String plhd_adr_1 = "";  //[O] 계약자주소1 HJ_GYE_ADDR1 계약자주소1
		public String plhd_adr_2 = "";  //[O] 계약자주소2 HJ_GYE_ADDR2 계약자주소2
		public String nwod_adr_dvcd = "";  //[O] 신구주소구분코드 JJ-G-SINGU-GB 신구주소구분
		public String isu_dvn = "";  //[O] 발급구분 JJ_BALGUP_GB 발급구분
		public String isu_nm = "";  //[O] 발급명 HJ_BALGUP_NM 발급명
		public String[] ctc_if__plno = new String[0];  //[O] 계약정보_증권번호  
		public String[] ctc_if__ctc_id = new String[0];  //[O] 계약정보_계약id  
		public String[] ctc_if__ins_lcpl_dvcd = new String[0];  //[O] 계약정보_피보험자소재지구분코드  
		public String[] ctc_if__ply_sqno = new String[0];  //[O] 계약정보_증권일련번호  
		public String[] ctc_if__pdc_cd = new String[0];  //[O] 계약정보_상품코드1  
		public String[] ctc_if__pdc_nm = new String[0];  //[O] 계약정보_상품명  
		public String[] ctc_if__arc_pd_dt = new String[0];  //[O] 계약정보_보험시기일자  
		public String[] ctc_if__arc_et_dt = new String[0];  //[O] 계약정보_보험종기일자  
		public String[] ctc_if__plhd_cust_dcmt_no = new String[0];  //[O] 계약정보_계약자고객식별번호  
		public String[] ctc_if__pym_prm = new String[0];  //[O] 계약정보_납입보험료  
		public String[] ctc_if__ctc_stat_cd_nm = new String[0];  //[O] 계약정보_계약상태코드명  
		public String[] ctc_if__ctc_stat_ptl_cd_nm = new String[0];  //[O] 계약정보_계약세부상태코드명  
		public String[] ctc_if__ins_nm = new String[0];  //[O] 계약정보_피보험자명  
		public String[] ctc_if__hdlr_ormm_no = new String[0];  //[O] 계약정보_취급자조직원번호  
		public String[] ctc_if__coll_bzlv_nm = new String[0];  //[O] 계약정보_수금사업단명  
		public String[] ctc_if__pym_nts = new String[0];  //[O] 계약정보_납입횟수  
		public String[] ctc_if__pym_mtd_hngl_nm = new String[0];  //[O] 계약정보_납입방법한글명  
		public String[] ctc_if__fnal_pym_ym = new String[0];  //[O] 계약정보_최종납입년월  
		public String[] ctc_if__sl_pan_cd = new String[0];  //[O] 계약정보_판매플랜코드  
		public String[] ctc_if__pytr_val = new String[0];  //[O] 계약정보_납기값  
		public String[] ctc_if__pytr_dvcd = new String[0];  //[] 계약정보_납기구분코드  
		public String[] ctc_if__pym_mtd_cd = new String[0];  //[O] 계약정보_납입방법코드  
		public String[] ctc_if__tsfr_dd = new String[0];  //[O] 계약정보_이체일  
		public String[] ctc_if__coll_mtd_cd = new String[0];  //[O] 계약정보_수금방법코드  
		public String[] ctc_if__coll_mtd_nm = new String[0];  //[O] 계약정보_수금방법명  
		public String[] ctc_if__ins_cust_dcmt_no = new String[0];  //[O] 계약정보_피보험자고객식별번호  
		public String[] ctc_if__aut_tsfr_acc_no = new String[0];  //[O] 계약정보_자동이체계좌번호  
		public String[] ctc_if__aut_tsfr_bank_nm = new String[0];  //[O] 계약정보_자동이체은행명  
		public String[] ctc_if__aut_tsfr_acc_dpsr_nm = new String[0];  //[O] 계약정보_자동이체계좌예금주명  
		public String[] ctc_if__rprm_pyn_aply_yn = new String[0];  //[O] 계약정보_환급금지급신청여부  
		public String[] ctc_if__coll_bh_nm = new String[0];  //[O] 계약정보_수금지점명  
		public String[] ctc_if__coll_hdlr_nm = new String[0];  //[O] 계약정보_수금취급자명  
		public String[] ctc_if__coll_bzlv_no = new String[0];  //[O] 계약정보_수금사업단번호  
		public String[] ctc_if__coll_bh_no = new String[0];  //[O] 계약정보_수금지점번호  
		public String[] ctc_if__clmn_empno = new String[0];  //[O] 계약정보_수금자사원번호  
		public String[] ctc_if__ctc_stat_dt = new String[0];  //[O] 계약정보_계약상태일자  
		public String[] vh_if__vh_plno = new String[0];  //[O] 차량정보_차량증권번호 JJ_CAR_POLI_NO 차량증권번호
		public String[] vh_if__vh_rlt = new String[0];  //[O] 차량정보_차량관계 HJ_CAR_GWANGE 차량관계
		public String[] vh_if__vh_no = new String[0];  //[O] 차량정보_차량번호 HJ_CAR_NO 차량번호
		public String[] vh_if__vh_cust_rrno = new String[0];  //[O] 차량정보_차량고객주민등록번호 JJ_CAR_JUMIN 차량고객주민번호
		public String[] vh_if__vh_apl_dt = new String[0];  //[O] 차량정보_차량청약일자 JJ_CAR_SANGTE_YMD 차량계약일
		public String[] vh_if__vh_prm = new String[0];  //[O] 차량정보_차량보험료 JJ_CAR_TOTAL_PRM 차량합계보험료
		public String gnrl_plno = "";  //[O] 일반증권번호 JJ_ILBAN_POLI_NO 일반-증권번호
		public String gnrl_ins_lcpl_dvcd = "";  //[O] 일반피보험자소재지구분코드  
		public String gnrl_ply_sqno = "";  //[O] 일반증권일련번호  
		public String gnrl_ins_nm = "";  //[O] 일반피보험자명 HJ_ILBAN_PIBO_NM 일반-피보험자명
		public String gnrl_ins_rrno = "";  //[O] 일반피보험자주민등록번호 JJ_ILBAN_PIBO_JUMIN 일반-피보험자주민번호
		public String gnrl_inpd_nm = "";  //[O] 일반보종명 JJ_ILBAN_BJ_NM 일반-보험종목명
		public String gnrl_arc_pd_dt = "";  //[O] 일반보험시기일자 JJ_ILBAN_BOHUM_SYMD 일반-보험시기
		public String gnrl_arc_et_dt = "";  //[O] 일반보험종기일자 JJ_ILBAN_BOHUM_EYMD 일반-보험종기
		public String gnrl_prm = "";  //[O] 일반보험료 JJ_ILBAN_JUKYONG_PRM 일반-보험료
		public String ctc_stat_cd_nm = "";  //[O] 계약상태코드명 HJ_GYE_SANGTE 계약상태
		public String ctc_stat_ptl_cd_nm = "";  //[O] 계약상태세부코드명  
		public String stat_dt = "";  //[O] 상태일자 JJ_SANGTE_YMD 상태일자
		public String proc_bzlv_cd = "";  //[O] 처리사업단코드 JJ_C_JIJUM_CD 지점코드
		public String proc_bzlv_nm = "";  //[O] 처리사업단명 HJ_C_JIJUM_NM 지점명
		public String stat_amt = "";  //[O] 상태금액 JJ_C_GMEK 상태금액
		public String unt_indt = "";  //[O] 단위표시 HJ_C_NM 원표시
		public String bsc_prm = "";  //[O] 기본보험료 JJ_GIBON_PRM 기본보험료
		public String aut_tsfr_prm = "";  //[O] 자동이체보험료 JJ_JADONG_CHUNGU_PRM 자동이체보험료
		public String asr_prm = "";  //[O] 보장보험료 JJ_BOJANG_PRM 보장보험료
		public String accu_prm = "";  //[O] 적립보험료 JJ_JUKRIP_BUMUN_PRM 적립보험료
		public String pym_yr = "";  //[O] 납입년도 JJ_L_NAPIP_YY 납입년도
		public String pym_mon = "";  //[O] 납입월 JJ_L_NAPIP_MM 납입월
		public String pym_nts = "";  //[O] 납입횟수 JJ_NAPIP_CNT 납입횟수
		public String appr_yr = "";  //[O] 인정년도 JJ_INJUNG_YY 인정년도
		public String appr_mon = "";  //[O] 인정월 JJ_INJUNG_MM 인정월
		public String pym_mtd = "";  //[O] 납입방법 HJ_BUNNAP_NM 납입방법
		public String coll_mtd_nm = "";  //[O] 수금방법명 HJ_SU_BANGBAP 수금방법명
		public String tsfr_bank = "";  //[O] 이체은행 HJ_BANK_NM 이체은행
		public String tsfr_dd_cnt = "";  //[O] 이체일수 JJ_ICHE_ILSU 이체일수
		public String acc_no = "";  //[O] 계좌번호 JJ_GYEJA_NO 계약자명
		public String dpsr_nm = "";  //[O] 예금주명 HJ_YEGUM_JU 예금주명
		public String ctrmf_yn_indt = "";  //[O] 계약변경유무표시 HJ_BE_NM 배서유무표시
		public String ctrmf_nts = "";  //[O] 계약변경횟수 JJ_BE_CNT 배서횟수
		public String inpl_ln_indt = "";  //[O] 약관대출표시 HJ_YAKGWAN 약관대출표시
		public String pmpt_indt = "";  //[O] 납입면제표시 HJ_M_REM 납입면제표시
		public String pmpt_dt = "";  //[O] 납입면제일자 JJ_M_YMD 납입면제일
		public String aut_ln_indt = "";  //[O] 자동대출표시 HJ_JADONG 자동대출표시
		public String aut_ln_dt = "";  //[O] 자동대출일자 JJ_J_YMD 자동대출일
		public String plg_tszr_indt = "";  //[O] 질권가압류표시 HJ_JIL_GA 질권가압류표시
		public String accd_yn_indt = "";  //[O] 사고유무표시 HJ_SAGO_NM 사고유무표시
		public String accd_nts = "";  //[O] 사고횟수 JJ_SAGO_CNT 사고횟수
		public String accd_dt_1 = "";  //[O] 사고일자1 JJ_SAGO_YMD1 사고일자1
		public String accd_dt_2 = "";  //[O] 사고일자2 JJ_SAGO_YMD2 사고일자2
		public String accd_dt_3 = "";  //[O] 사고일자3 JJ_SAGO_YMD3 사고일자3
		public String ustk_prg_indt = "";  //[O] 인수진행표시 HJ_INSU_PUMI 인수진행표시
		public String isu_nts = "";  //[O] 발급횟수 JJ_BALGB_CNT 발급횟수
		public String isu_dt = "";  //[O] 발급일자 JJ_BALGB_YMD 발급일
		public String hmcr_srv = "";  //[O] 홈케어서비스 HJ_HOME_SER 홈케어서비스
		public String cbl_trmt_csn_yn = "";  //[O] 유선해지동의여부 JJ_HEJI_YN 유선해지동의여부
		public String cbl_trmt_csn_nm = "";  //[O] 유선해지동의명 HJ_HEJI_YN 유선해지동의명
		public String cllt_bzlv_nm = "";  //[O] 모집사업단명 HJ_M_JIJUM_NM 지점명
		public String cllt_bh_nm = "";  //[O] 모집지점명 HJ_M_JIBU_NM 지부명
		public String cllt_ormm_nm = "";  //[O] 모집조직원명 HJ_M_JOJIK_NM 조직원명
		public String cllt_bzlv_cd = "";  //[O] 모집사업단코드 JJ_M_JIJUM_CD 지점코드
		public String cllt_bh_cd = "";  //[O] 모집지점코드 JJ_M_JIBU_CD 지부코드
		
		public String cllt_ormm_cd = "";  //[O] 모집조직원명 JJ_M_JOJIK_CD 조직코드
		
		public String ply_sqno = "";  //[O] 모집조직원명 JJ_M_JOJIK_CD 조직코드
		
		public String coll_bzlv_nm = "";  //[O] 수금사업단명 HJ_S_JIJUM_NM 수금사업단명
		public String coll_bh_nm = "";  //[O] 수금지점명 HJ_S_JIBU_NM 수금지점명
		public String coll_ormm_nm = "";  //[O] 수금조직원명 HJ_S_JOJIK_NM 수금조직원명
		public String coll_bzlv_cd = "";  //[O] 수금사업단코드 JJ_S_JIJUM_CD 수금사업단코드
		public String coll_bh_cd = "";  //[O] 수금지점코드 JJ_S_JIBU_CD 수금지점코드
		public String coll_ormm_cd = "";  //[O] 수금조직원코드 JJ_S_JOJIK_CD 수금조직원코드
		public String sprt_ply_dvn = "";  //[O] 분리증권구분 JJ_BUNLI_MARK 새대정보
		public String sprt_plno = "";  //[O] 분리증권번호 JJ_BUNLI_POLI 새대증번
		
		
		
		public String getPly_sqno() {
			return ply_sqno;
		}
		public void setPly_sqno(String ply_sqno) {
			this.ply_sqno = ply_sqno;
		}
		public String getPlno() {
			return plno;
		}
		public void setPlno(String plno) {
			this.plno = plno;
		}
		public String getCtrmf_sqno() {
			return ctrmf_sqno;
		}
		public void setCtrmf_sqno(String ctrmf_sqno) {
			this.ctrmf_sqno = ctrmf_sqno;
		}
		public String getDvn() {
			return dvn;
		}
		public void setDvn(String dvn) {
			this.dvn = dvn;
		}
		public String getCtc_id() {
			return ctc_id;
		}
		public void setCtc_id(String ctc_id) {
			this.ctc_id = ctc_id;
		}
		public String getPdc_cd() {
			return pdc_cd;
		}
		public void setPdc_cd(String pdc_cd) {
			this.pdc_cd = pdc_cd;
		}
		public String getScy_dvn() {
			return scy_dvn;
		}
		public void setScy_dvn(String scy_dvn) {
			this.scy_dvn = scy_dvn;
		}
		public String getInpd_nm() {
			return inpd_nm;
		}
		public void setInpd_nm(String inpd_nm) {
			this.inpd_nm = inpd_nm;
		}
		public String getPdc_dvn() {
			return pdc_dvn;
		}
		public void setPdc_dvn(String pdc_dvn) {
			this.pdc_dvn = pdc_dvn;
		}
		public String getCust_dvn() {
			return cust_dvn;
		}
		public void setCust_dvn(String cust_dvn) {
			this.cust_dvn = cust_dvn;
		}
		public String getArc_pd_dt() {
			return arc_pd_dt;
		}
		public void setArc_pd_dt(String arc_pd_dt) {
			this.arc_pd_dt = arc_pd_dt;
		}
		public String getArc_et_dt() {
			return arc_et_dt;
		}
		public void setArc_et_dt(String arc_et_dt) {
			this.arc_et_dt = arc_et_dt;
		}
		public String getArc_trm_nm() {
			return arc_trm_nm;
		}
		public void setArc_trm_nm(String arc_trm_nm) {
			this.arc_trm_nm = arc_trm_nm;
		}
		public String getApl_dt() {
			return apl_dt;
		}
		public void setApl_dt(String apl_dt) {
			this.apl_dt = apl_dt;
		}
		public String getPlhd_nm() {
			return plhd_nm;
		}
		public void setPlhd_nm(String plhd_nm) {
			this.plhd_nm = plhd_nm;
		}
		public String getPlhd_rrno() {
			return plhd_rrno;
		}
		public void setPlhd_rrno(String plhd_rrno) {
			this.plhd_rrno = plhd_rrno;
		}
		public String getPlhd_tlno_1() {
			return plhd_tlno_1;
		}
		public void setPlhd_tlno_1(String plhd_tlno_1) {
			this.plhd_tlno_1 = plhd_tlno_1;
		}
		public String getPlhd_tlno_2() {
			return plhd_tlno_2;
		}
		public void setPlhd_tlno_2(String plhd_tlno_2) {
			this.plhd_tlno_2 = plhd_tlno_2;
		}
		public String getPlhd_tlno_3() {
			return plhd_tlno_3;
		}
		public void setPlhd_tlno_3(String plhd_tlno_3) {
			this.plhd_tlno_3 = plhd_tlno_3;
		}
		public String getCtry_nm() {
			return ctry_nm;
		}
		public void setCtry_nm(String ctry_nm) {
			this.ctry_nm = ctry_nm;
		}
		public String getPlhd_psno_1() {
			return plhd_psno_1;
		}
		public void setPlhd_psno_1(String plhd_psno_1) {
			this.plhd_psno_1 = plhd_psno_1;
		}
		public String getPlhd_psno_2() {
			return plhd_psno_2;
		}
		public void setPlhd_psno_2(String plhd_psno_2) {
			this.plhd_psno_2 = plhd_psno_2;
		}
		public String getPlhd_adr_1() {
			return plhd_adr_1;
		}
		public void setPlhd_adr_1(String plhd_adr_1) {
			this.plhd_adr_1 = plhd_adr_1;
		}
		public String getPlhd_adr_2() {
			return plhd_adr_2;
		}
		public void setPlhd_adr_2(String plhd_adr_2) {
			this.plhd_adr_2 = plhd_adr_2;
		}
		public String getNwod_adr_dvcd() {
			return nwod_adr_dvcd;
		}
		public void setNwod_adr_dvcd(String nwod_adr_dvcd) {
			this.nwod_adr_dvcd = nwod_adr_dvcd;
		}
		public String getIsu_dvn() {
			return isu_dvn;
		}
		public void setIsu_dvn(String isu_dvn) {
			this.isu_dvn = isu_dvn;
		}
		public String getIsu_nm() {
			return isu_nm;
		}
		public void setIsu_nm(String isu_nm) {
			this.isu_nm = isu_nm;
		}
		public String[] getCtc_if__plno() {
			return ctc_if__plno;
		}
		public void setCtc_if__plno(String[] ctc_if__plno) {
			this.ctc_if__plno = ctc_if__plno;
		}
		public String[] getCtc_if__ctc_id() {
			return ctc_if__ctc_id;
		}
		public void setCtc_if__ctc_id(String[] ctc_if__ctc_id) {
			this.ctc_if__ctc_id = ctc_if__ctc_id;
		}
		public String[] getCtc_if__ins_lcpl_dvcd() {
			return ctc_if__ins_lcpl_dvcd;
		}
		public void setCtc_if__ins_lcpl_dvcd(String[] ctc_if__ins_lcpl_dvcd) {
			this.ctc_if__ins_lcpl_dvcd = ctc_if__ins_lcpl_dvcd;
		}
		public String[] getCtc_if__ply_sqno() {
			return ctc_if__ply_sqno;
		}
		public void setCtc_if__ply_sqno(String[] ctc_if__ply_sqno) {
			this.ctc_if__ply_sqno = ctc_if__ply_sqno;
		}
		public String[] getCtc_if__pdc_cd() {
			return ctc_if__pdc_cd;
		}
		public void setCtc_if__pdc_cd(String[] ctc_if__pdc_cd) {
			this.ctc_if__pdc_cd = ctc_if__pdc_cd;
		}
		public String[] getCtc_if__pdc_nm() {
			return ctc_if__pdc_nm;
		}
		public void setCtc_if__pdc_nm(String[] ctc_if__pdc_nm) {
			this.ctc_if__pdc_nm = ctc_if__pdc_nm;
		}
		public String[] getCtc_if__arc_pd_dt() {
			return ctc_if__arc_pd_dt;
		}
		public void setCtc_if__arc_pd_dt(String[] ctc_if__arc_pd_dt) {
			this.ctc_if__arc_pd_dt = ctc_if__arc_pd_dt;
		}
		public String[] getCtc_if__arc_et_dt() {
			return ctc_if__arc_et_dt;
		}
		public void setCtc_if__arc_et_dt(String[] ctc_if__arc_et_dt) {
			this.ctc_if__arc_et_dt = ctc_if__arc_et_dt;
		}
		public String[] getCtc_if__plhd_cust_dcmt_no() {
			return ctc_if__plhd_cust_dcmt_no;
		}
		public void setCtc_if__plhd_cust_dcmt_no(String[] ctc_if__plhd_cust_dcmt_no) {
			this.ctc_if__plhd_cust_dcmt_no = ctc_if__plhd_cust_dcmt_no;
		}
		public String[] getCtc_if__pym_prm() {
			return ctc_if__pym_prm;
		}
		public void setCtc_if__pym_prm(String[] ctc_if__pym_prm) {
			this.ctc_if__pym_prm = ctc_if__pym_prm;
		}
		public String[] getCtc_if__ctc_stat_cd_nm() {
			return ctc_if__ctc_stat_cd_nm;
		}
		public void setCtc_if__ctc_stat_cd_nm(String[] ctc_if__ctc_stat_cd_nm) {
			this.ctc_if__ctc_stat_cd_nm = ctc_if__ctc_stat_cd_nm;
		}
		public String[] getCtc_if__ctc_stat_ptl_cd_nm() {
			return ctc_if__ctc_stat_ptl_cd_nm;
		}
		public void setCtc_if__ctc_stat_ptl_cd_nm(String[] ctc_if__ctc_stat_ptl_cd_nm) {
			this.ctc_if__ctc_stat_ptl_cd_nm = ctc_if__ctc_stat_ptl_cd_nm;
		}
		public String[] getCtc_if__ins_nm() {
			return ctc_if__ins_nm;
		}
		public void setCtc_if__ins_nm(String[] ctc_if__ins_nm) {
			this.ctc_if__ins_nm = ctc_if__ins_nm;
		}
		public String[] getCtc_if__hdlr_ormm_no() {
			return ctc_if__hdlr_ormm_no;
		}
		public void setCtc_if__hdlr_ormm_no(String[] ctc_if__hdlr_ormm_no) {
			this.ctc_if__hdlr_ormm_no = ctc_if__hdlr_ormm_no;
		}
		public String[] getCtc_if__coll_bzlv_nm() {
			return ctc_if__coll_bzlv_nm;
		}
		public void setCtc_if__coll_bzlv_nm(String[] ctc_if__coll_bzlv_nm) {
			this.ctc_if__coll_bzlv_nm = ctc_if__coll_bzlv_nm;
		}
		public String[] getCtc_if__pym_nts() {
			return ctc_if__pym_nts;
		}
		public void setCtc_if__pym_nts(String[] ctc_if__pym_nts) {
			this.ctc_if__pym_nts = ctc_if__pym_nts;
		}
		public String[] getCtc_if__pym_mtd_hngl_nm() {
			return ctc_if__pym_mtd_hngl_nm;
		}
		public void setCtc_if__pym_mtd_hngl_nm(String[] ctc_if__pym_mtd_hngl_nm) {
			this.ctc_if__pym_mtd_hngl_nm = ctc_if__pym_mtd_hngl_nm;
		}
		public String[] getCtc_if__fnal_pym_ym() {
			return ctc_if__fnal_pym_ym;
		}
		public void setCtc_if__fnal_pym_ym(String[] ctc_if__fnal_pym_ym) {
			this.ctc_if__fnal_pym_ym = ctc_if__fnal_pym_ym;
		}
		public String[] getCtc_if__sl_pan_cd() {
			return ctc_if__sl_pan_cd;
		}
		public void setCtc_if__sl_pan_cd(String[] ctc_if__sl_pan_cd) {
			this.ctc_if__sl_pan_cd = ctc_if__sl_pan_cd;
		}
		public String[] getCtc_if__pytr_val() {
			return ctc_if__pytr_val;
		}
		public void setCtc_if__pytr_val(String[] ctc_if__pytr_val) {
			this.ctc_if__pytr_val = ctc_if__pytr_val;
		}
		public String[] getCtc_if__pytr_dvcd() {
			return ctc_if__pytr_dvcd;
		}
		public void setCtc_if__pytr_dvcd(String[] ctc_if__pytr_dvcd) {
			this.ctc_if__pytr_dvcd = ctc_if__pytr_dvcd;
		}
		public String[] getCtc_if__pym_mtd_cd() {
			return ctc_if__pym_mtd_cd;
		}
		public void setCtc_if__pym_mtd_cd(String[] ctc_if__pym_mtd_cd) {
			this.ctc_if__pym_mtd_cd = ctc_if__pym_mtd_cd;
		}
		public String[] getCtc_if__tsfr_dd() {
			return ctc_if__tsfr_dd;
		}
		public void setCtc_if__tsfr_dd(String[] ctc_if__tsfr_dd) {
			this.ctc_if__tsfr_dd = ctc_if__tsfr_dd;
		}
		public String[] getCtc_if__coll_mtd_cd() {
			return ctc_if__coll_mtd_cd;
		}
		public void setCtc_if__coll_mtd_cd(String[] ctc_if__coll_mtd_cd) {
			this.ctc_if__coll_mtd_cd = ctc_if__coll_mtd_cd;
		}
		public String[] getCtc_if__coll_mtd_nm() {
			return ctc_if__coll_mtd_nm;
		}
		public void setCtc_if__coll_mtd_nm(String[] ctc_if__coll_mtd_nm) {
			this.ctc_if__coll_mtd_nm = ctc_if__coll_mtd_nm;
		}
		public String[] getCtc_if__ins_cust_dcmt_no() {
			return ctc_if__ins_cust_dcmt_no;
		}
		public void setCtc_if__ins_cust_dcmt_no(String[] ctc_if__ins_cust_dcmt_no) {
			this.ctc_if__ins_cust_dcmt_no = ctc_if__ins_cust_dcmt_no;
		}
		public String[] getCtc_if__aut_tsfr_acc_no() {
			return ctc_if__aut_tsfr_acc_no;
		}
		public void setCtc_if__aut_tsfr_acc_no(String[] ctc_if__aut_tsfr_acc_no) {
			this.ctc_if__aut_tsfr_acc_no = ctc_if__aut_tsfr_acc_no;
		}
		public String[] getCtc_if__aut_tsfr_bank_nm() {
			return ctc_if__aut_tsfr_bank_nm;
		}
		public void setCtc_if__aut_tsfr_bank_nm(String[] ctc_if__aut_tsfr_bank_nm) {
			this.ctc_if__aut_tsfr_bank_nm = ctc_if__aut_tsfr_bank_nm;
		}
		public String[] getCtc_if__aut_tsfr_acc_dpsr_nm() {
			return ctc_if__aut_tsfr_acc_dpsr_nm;
		}
		public void setCtc_if__aut_tsfr_acc_dpsr_nm(
				String[] ctc_if__aut_tsfr_acc_dpsr_nm) {
			this.ctc_if__aut_tsfr_acc_dpsr_nm = ctc_if__aut_tsfr_acc_dpsr_nm;
		}
		public String[] getCtc_if__rprm_pyn_aply_yn() {
			return ctc_if__rprm_pyn_aply_yn;
		}
		public void setCtc_if__rprm_pyn_aply_yn(String[] ctc_if__rprm_pyn_aply_yn) {
			this.ctc_if__rprm_pyn_aply_yn = ctc_if__rprm_pyn_aply_yn;
		}
		public String[] getCtc_if__coll_bh_nm() {
			return ctc_if__coll_bh_nm;
		}
		public void setCtc_if__coll_bh_nm(String[] ctc_if__coll_bh_nm) {
			this.ctc_if__coll_bh_nm = ctc_if__coll_bh_nm;
		}
		public String[] getCtc_if__coll_hdlr_nm() {
			return ctc_if__coll_hdlr_nm;
		}
		public void setCtc_if__coll_hdlr_nm(String[] ctc_if__coll_hdlr_nm) {
			this.ctc_if__coll_hdlr_nm = ctc_if__coll_hdlr_nm;
		}
		public String[] getCtc_if__coll_bzlv_no() {
			return ctc_if__coll_bzlv_no;
		}
		public void setCtc_if__coll_bzlv_no(String[] ctc_if__coll_bzlv_no) {
			this.ctc_if__coll_bzlv_no = ctc_if__coll_bzlv_no;
		}
		public String[] getCtc_if__coll_bh_no() {
			return ctc_if__coll_bh_no;
		}
		public void setCtc_if__coll_bh_no(String[] ctc_if__coll_bh_no) {
			this.ctc_if__coll_bh_no = ctc_if__coll_bh_no;
		}
		public String[] getCtc_if__clmn_empno() {
			return ctc_if__clmn_empno;
		}
		public void setCtc_if__clmn_empno(String[] ctc_if__clmn_empno) {
			this.ctc_if__clmn_empno = ctc_if__clmn_empno;
		}
		public String[] getCtc_if__ctc_stat_dt() {
			return ctc_if__ctc_stat_dt;
		}
		public void setCtc_if__ctc_stat_dt(String[] ctc_if__ctc_stat_dt) {
			this.ctc_if__ctc_stat_dt = ctc_if__ctc_stat_dt;
		}
		public String[] getVh_if__vh_plno() {
			return vh_if__vh_plno;
		}
		public void setVh_if__vh_plno(String[] vh_if__vh_plno) {
			this.vh_if__vh_plno = vh_if__vh_plno;
		}
		public String[] getVh_if__vh_rlt() {
			return vh_if__vh_rlt;
		}
		public void setVh_if__vh_rlt(String[] vh_if__vh_rlt) {
			this.vh_if__vh_rlt = vh_if__vh_rlt;
		}
		public String[] getVh_if__vh_no() {
			return vh_if__vh_no;
		}
		public void setVh_if__vh_no(String[] vh_if__vh_no) {
			this.vh_if__vh_no = vh_if__vh_no;
		}
		public String[] getVh_if__vh_cust_rrno() {
			return vh_if__vh_cust_rrno;
		}
		public void setVh_if__vh_cust_rrno(String[] vh_if__vh_cust_rrno) {
			this.vh_if__vh_cust_rrno = vh_if__vh_cust_rrno;
		}
		public String[] getVh_if__vh_apl_dt() {
			return vh_if__vh_apl_dt;
		}
		public void setVh_if__vh_apl_dt(String[] vh_if__vh_apl_dt) {
			this.vh_if__vh_apl_dt = vh_if__vh_apl_dt;
		}
		public String[] getVh_if__vh_prm() {
			return vh_if__vh_prm;
		}
		public void setVh_if__vh_prm(String[] vh_if__vh_prm) {
			this.vh_if__vh_prm = vh_if__vh_prm;
		}
		public String getGnrl_plno() {
			return gnrl_plno;
		}
		public void setGnrl_plno(String gnrl_plno) {
			this.gnrl_plno = gnrl_plno;
		}
		public String getGnrl_ins_lcpl_dvcd() {
			return gnrl_ins_lcpl_dvcd;
		}
		public void setGnrl_ins_lcpl_dvcd(String gnrl_ins_lcpl_dvcd) {
			this.gnrl_ins_lcpl_dvcd = gnrl_ins_lcpl_dvcd;
		}
		public String getGnrl_ply_sqno() {
			return gnrl_ply_sqno;
		}
		public void setGnrl_ply_sqno(String gnrl_ply_sqno) {
			this.gnrl_ply_sqno = gnrl_ply_sqno;
		}
		public String getGnrl_ins_nm() {
			return gnrl_ins_nm;
		}
		public void setGnrl_ins_nm(String gnrl_ins_nm) {
			this.gnrl_ins_nm = gnrl_ins_nm;
		}
		public String getGnrl_ins_rrno() {
			return gnrl_ins_rrno;
		}
		public void setGnrl_ins_rrno(String gnrl_ins_rrno) {
			this.gnrl_ins_rrno = gnrl_ins_rrno;
		}
		public String getGnrl_inpd_nm() {
			return gnrl_inpd_nm;
		}
		public void setGnrl_inpd_nm(String gnrl_inpd_nm) {
			this.gnrl_inpd_nm = gnrl_inpd_nm;
		}
		public String getGnrl_arc_pd_dt() {
			return gnrl_arc_pd_dt;
		}
		public void setGnrl_arc_pd_dt(String gnrl_arc_pd_dt) {
			this.gnrl_arc_pd_dt = gnrl_arc_pd_dt;
		}
		public String getGnrl_arc_et_dt() {
			return gnrl_arc_et_dt;
		}
		public void setGnrl_arc_et_dt(String gnrl_arc_et_dt) {
			this.gnrl_arc_et_dt = gnrl_arc_et_dt;
		}
		public String getGnrl_prm() {
			return gnrl_prm;
		}
		public void setGnrl_prm(String gnrl_prm) {
			this.gnrl_prm = gnrl_prm;
		}
		public String getCtc_stat_cd_nm() {
			return ctc_stat_cd_nm;
		}
		public void setCtc_stat_cd_nm(String ctc_stat_cd_nm) {
			this.ctc_stat_cd_nm = ctc_stat_cd_nm;
		}
		public String getCtc_stat_ptl_cd_nm() {
			return ctc_stat_ptl_cd_nm;
		}
		public void setCtc_stat_ptl_cd_nm(String ctc_stat_ptl_cd_nm) {
			this.ctc_stat_ptl_cd_nm = ctc_stat_ptl_cd_nm;
		}
		public String getStat_dt() {
			return stat_dt;
		}
		public void setStat_dt(String stat_dt) {
			this.stat_dt = stat_dt;
		}
		public String getProc_bzlv_cd() {
			return proc_bzlv_cd;
		}
		public void setProc_bzlv_cd(String proc_bzlv_cd) {
			this.proc_bzlv_cd = proc_bzlv_cd;
		}
		public String getProc_bzlv_nm() {
			return proc_bzlv_nm;
		}
		public void setProc_bzlv_nm(String proc_bzlv_nm) {
			this.proc_bzlv_nm = proc_bzlv_nm;
		}
		public String getStat_amt() {
			return stat_amt;
		}
		public void setStat_amt(String stat_amt) {
			this.stat_amt = stat_amt;
		}
		public String getUnt_indt() {
			return unt_indt;
		}
		public void setUnt_indt(String unt_indt) {
			this.unt_indt = unt_indt;
		}
		public String getBsc_prm() {
			return bsc_prm;
		}
		public void setBsc_prm(String bsc_prm) {
			this.bsc_prm = bsc_prm;
		}
		public String getAut_tsfr_prm() {
			return aut_tsfr_prm;
		}
		public void setAut_tsfr_prm(String aut_tsfr_prm) {
			this.aut_tsfr_prm = aut_tsfr_prm;
		}
		public String getAsr_prm() {
			return asr_prm;
		}
		public void setAsr_prm(String asr_prm) {
			this.asr_prm = asr_prm;
		}
		public String getAccu_prm() {
			return accu_prm;
		}
		public void setAccu_prm(String accu_prm) {
			this.accu_prm = accu_prm;
		}
		public String getPym_yr() {
			return pym_yr;
		}
		public void setPym_yr(String pym_yr) {
			this.pym_yr = pym_yr;
		}
		public String getPym_mon() {
			return pym_mon;
		}
		public void setPym_mon(String pym_mon) {
			this.pym_mon = pym_mon;
		}
		public String getPym_nts() {
			return pym_nts;
		}
		public void setPym_nts(String pym_nts) {
			this.pym_nts = pym_nts;
		}
		public String getAppr_yr() {
			return appr_yr;
		}
		public void setAppr_yr(String appr_yr) {
			this.appr_yr = appr_yr;
		}
		public String getAppr_mon() {
			return appr_mon;
		}
		public void setAppr_mon(String appr_mon) {
			this.appr_mon = appr_mon;
		}
		public String getPym_mtd() {
			return pym_mtd;
		}
		public void setPym_mtd(String pym_mtd) {
			this.pym_mtd = pym_mtd;
		}
		public String getColl_mtd_nm() {
			return coll_mtd_nm;
		}
		public void setColl_mtd_nm(String coll_mtd_nm) {
			this.coll_mtd_nm = coll_mtd_nm;
		}
		public String getTsfr_bank() {
			return tsfr_bank;
		}
		public void setTsfr_bank(String tsfr_bank) {
			this.tsfr_bank = tsfr_bank;
		}
		public String getTsfr_dd_cnt() {
			return tsfr_dd_cnt;
		}
		public void setTsfr_dd_cnt(String tsfr_dd_cnt) {
			this.tsfr_dd_cnt = tsfr_dd_cnt;
		}
		public String getAcc_no() {
			return acc_no;
		}
		public void setAcc_no(String acc_no) {
			this.acc_no = acc_no;
		}
		public String getDpsr_nm() {
			return dpsr_nm;
		}
		public void setDpsr_nm(String dpsr_nm) {
			this.dpsr_nm = dpsr_nm;
		}
		public String getCtrmf_yn_indt() {
			return ctrmf_yn_indt;
		}
		public void setCtrmf_yn_indt(String ctrmf_yn_indt) {
			this.ctrmf_yn_indt = ctrmf_yn_indt;
		}
		public String getCtrmf_nts() {
			return ctrmf_nts;
		}
		public void setCtrmf_nts(String ctrmf_nts) {
			this.ctrmf_nts = ctrmf_nts;
		}
		public String getInpl_ln_indt() {
			return inpl_ln_indt;
		}
		public void setInpl_ln_indt(String inpl_ln_indt) {
			this.inpl_ln_indt = inpl_ln_indt;
		}
		public String getPmpt_indt() {
			return pmpt_indt;
		}
		public void setPmpt_indt(String pmpt_indt) {
			this.pmpt_indt = pmpt_indt;
		}
		public String getPmpt_dt() {
			return pmpt_dt;
		}
		public void setPmpt_dt(String pmpt_dt) {
			this.pmpt_dt = pmpt_dt;
		}
		public String getAut_ln_indt() {
			return aut_ln_indt;
		}
		public void setAut_ln_indt(String aut_ln_indt) {
			this.aut_ln_indt = aut_ln_indt;
		}
		public String getAut_ln_dt() {
			return aut_ln_dt;
		}
		public void setAut_ln_dt(String aut_ln_dt) {
			this.aut_ln_dt = aut_ln_dt;
		}
		public String getPlg_tszr_indt() {
			return plg_tszr_indt;
		}
		public void setPlg_tszr_indt(String plg_tszr_indt) {
			this.plg_tszr_indt = plg_tszr_indt;
		}
		public String getAccd_yn_indt() {
			return accd_yn_indt;
		}
		public void setAccd_yn_indt(String accd_yn_indt) {
			this.accd_yn_indt = accd_yn_indt;
		}
		public String getAccd_nts() {
			return accd_nts;
		}
		public void setAccd_nts(String accd_nts) {
			this.accd_nts = accd_nts;
		}
		public String getAccd_dt_1() {
			return accd_dt_1;
		}
		public void setAccd_dt_1(String accd_dt_1) {
			this.accd_dt_1 = accd_dt_1;
		}
		public String getAccd_dt_2() {
			return accd_dt_2;
		}
		public void setAccd_dt_2(String accd_dt_2) {
			this.accd_dt_2 = accd_dt_2;
		}
		public String getAccd_dt_3() {
			return accd_dt_3;
		}
		public void setAccd_dt_3(String accd_dt_3) {
			this.accd_dt_3 = accd_dt_3;
		}
		public String getUstk_prg_indt() {
			return ustk_prg_indt;
		}
		public void setUstk_prg_indt(String ustk_prg_indt) {
			this.ustk_prg_indt = ustk_prg_indt;
		}
		public String getIsu_nts() {
			return isu_nts;
		}
		public void setIsu_nts(String isu_nts) {
			this.isu_nts = isu_nts;
		}
		public String getIsu_dt() {
			return isu_dt;
		}
		public void setIsu_dt(String isu_dt) {
			this.isu_dt = isu_dt;
		}
		public String getHmcr_srv() {
			return hmcr_srv;
		}
		public void setHmcr_srv(String hmcr_srv) {
			this.hmcr_srv = hmcr_srv;
		}
		public String getCbl_trmt_csn_yn() {
			return cbl_trmt_csn_yn;
		}
		public void setCbl_trmt_csn_yn(String cbl_trmt_csn_yn) {
			this.cbl_trmt_csn_yn = cbl_trmt_csn_yn;
		}
		public String getCbl_trmt_csn_nm() {
			return cbl_trmt_csn_nm;
		}
		public void setCbl_trmt_csn_nm(String cbl_trmt_csn_nm) {
			this.cbl_trmt_csn_nm = cbl_trmt_csn_nm;
		}
		public String getCllt_bzlv_nm() {
			return cllt_bzlv_nm;
		}
		public void setCllt_bzlv_nm(String cllt_bzlv_nm) {
			this.cllt_bzlv_nm = cllt_bzlv_nm;
		}
		public String getCllt_bh_nm() {
			return cllt_bh_nm;
		}
		public void setCllt_bh_nm(String cllt_bh_nm) {
			this.cllt_bh_nm = cllt_bh_nm;
		}
		public String getCllt_ormm_nm() {
			return cllt_ormm_nm;
		}
		public void setCllt_ormm_nm(String cllt_ormm_nm) {
			this.cllt_ormm_nm = cllt_ormm_nm;
		}
		public String getCllt_bzlv_cd() {
			return cllt_bzlv_cd;
		}
		public void setCllt_bzlv_cd(String cllt_bzlv_cd) {
			this.cllt_bzlv_cd = cllt_bzlv_cd;
		}
		public String getCllt_bh_cd() {
			return cllt_bh_cd;
		}
		public void setCllt_bh_cd(String cllt_bh_cd) {
			this.cllt_bh_cd = cllt_bh_cd;
		}
		public String getCllt_ormm_cd() {
			return cllt_ormm_cd;
		}
		public void setCllt_ormm_cd(String cllt_ormm_cd) {
			this.cllt_ormm_cd = cllt_ormm_cd;
		}
		public String getColl_bzlv_nm() {
			return coll_bzlv_nm;
		}
		public void setColl_bzlv_nm(String coll_bzlv_nm) {
			this.coll_bzlv_nm = coll_bzlv_nm;
		}
		public String getColl_bh_nm() {
			return coll_bh_nm;
		}
		public void setColl_bh_nm(String coll_bh_nm) {
			this.coll_bh_nm = coll_bh_nm;
		}
		public String getColl_ormm_nm() {
			return coll_ormm_nm;
		}
		public void setColl_ormm_nm(String coll_ormm_nm) {
			this.coll_ormm_nm = coll_ormm_nm;
		}
		public String getColl_bzlv_cd() {
			return coll_bzlv_cd;
		}
		public void setColl_bzlv_cd(String coll_bzlv_cd) {
			this.coll_bzlv_cd = coll_bzlv_cd;
		}
		public String getColl_bh_cd() {
			return coll_bh_cd;
		}
		public void setColl_bh_cd(String coll_bh_cd) {
			this.coll_bh_cd = coll_bh_cd;
		}
		public String getColl_ormm_cd() {
			return coll_ormm_cd;
		}
		public void setColl_ormm_cd(String coll_ormm_cd) {
			this.coll_ormm_cd = coll_ormm_cd;
		}
		public String getSprt_ply_dvn() {
			return sprt_ply_dvn;
		}
		public void setSprt_ply_dvn(String sprt_ply_dvn) {
			this.sprt_ply_dvn = sprt_ply_dvn;
		}
		public String getSprt_plno() {
			return sprt_plno;
		}
		public void setSprt_plno(String sprt_plno) {
			this.sprt_plno = sprt_plno;
		}
		
		
		
}
