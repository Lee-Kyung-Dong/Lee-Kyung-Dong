package com.idongbu.smartzone.vo;

import java.util.List;
import java.util.Map;

import com.idongbu.common.vo.CMMVO;

public class CCLM0006VO extends CMMVO{

	//전문필드
	public String[] bsc_if__accd_rpt_no = new String[0];  //[O] 기본정보_사고접수번호 SS_SAGO_JUBSU_NO 사고접수번호
	public String[] bsc_if__chng_sqno = new String[0];  //[O] 기본정보_변경일련번호 SS_SAGO_JUBSU_SEQ 사고접수일련번호
	public String[] bsc_if__accd_oj_dvcd = new String[0];  //[O] 기본정보_사고목적구분코드 SS_SAGO_MOKJUK_GB 사고목적구분
	public String[] bsc_if__accd_oj_rnk = new String[0];  //[O] 기본정보_사고목적서열 SS_SAGO_MOKJUK_SEQ 사고목적일련번호
	public String[] bsc_if__accd_ocr_dt = new String[0];  //[I/O] 기본정보_사고발생일자  
	public String[] bsc_if__accd_ocr_tm = new String[0];  //[I/O] 기본정보_사고발생일시  
	public String[] bsc_if__srch_val = new String[0];  //[I/O] 기본정보_조회값 SS_JOGUN_NO 조건값
	public String[] bsc_if__msg_cd = new String[0];  //[O] 기본정보_메세지코드  
	public String[] ctc_if_dtl__plno = new String[0];  //[O] 계약정보상세_증권번호 SS_POLI_NO 증권번호
	public String[] ctc_if_dtl__ctc_id = new String[0];  //[O] 계약정보상세_계약ID  
	public String[] ctc_if_dtl__ins_cust_no = new String[0];  //[O] 계약정보상세_피보험자고객번호  
	public String[] ctc_if_dtl__ctrmf_sqno = new String[0];  //[O] 계약정보상세_계약변경일련번호 SS_BESU_NO 배서일련번호
	public String[] ctc_if_dtl__pdc_cd = new String[0];  //[O] 계약정보상세_상품코드 SS_BJ_CD 보종코드
	public String[] ctc_if_dtl__pdc_cd_nm = new String[0];  //[O] 계약정보상세_상품코드명 HS_BJ_NM 보종명
	public String[] ctc_if_dtl__ncvr_yn = new String[0];  //[O] 계약정보상세_부담보여부 SS_SUB_DAMBO_YN 서브담보여부
	public String[] ctc_if_dtl__coll_hdqt_no = new String[0];  //[O] 계약정보상세_수금본부번호  
	public String[] ctc_if_dtl__clmn_nm = new String[0];  //[O] 계약정보상세_수금자명 HS_JOJIKWON 수금조직원명
	public String[] ctc_if_dtl__clmn_empno = new String[0];  //[O] 계약정보상세_수금자사원번호 SS_JOJIKWON 수금조직원코드
	public String[] ctc_if_dtl__clmn_bh_no = new String[0];  //[O] 계약정보상세_수금자지점번호 HS_GYEYAK_JIJUM 계약지점
	public String[] ctc_if_dtl__inpd_dvcd = new String[0];  //[O] 계약정보상세_보종구분코드 SS_BOJ_GB 보종구분(1=일반 2=장기)
	public String[] ctc_if_dtl__arc_trm_str_dt = new String[0];  //[O] 계약정보상세_보험기간시작일자 SS_BOHUM_S_DATE 보험시기
	public String[] ctc_if_dtl__arc_trm_str_tm = new String[0];  //[O] 계약정보상세_보험기간시작시각  
	public String[] ctc_if_dtl__arc_trm_fin_dt = new String[0];  //[O] 계약정보상세_보험기간시작일자 SS_BOHUM_E_DATE 보험종기
	public String[] ctc_if_dtl__arc_trm_fin_tm = new String[0];  //[O] 계약정보상세_보험기간시작시각  
	public String[] ctc_if_dtl__coll_bh_no = new String[0];  //[O] 계약정보상세_보험기간시작시각  

	public String bsc_if___accd_ocr_dt = null;  //[I/O] 기본정보_사고발생일자  
	public String bsc_if___accd_ocr_tm = null;  //[I/O] 기본정보_사고발생일시  
	public String bsc_if___srch_val = null;  //[I/O] 기본정보_조회값 SS_JOGUN_NO 조건값
	public String errorCode = null;  //[I/O] 에러코드
	
	
	public String[] getCtc_if_dtl__coll_bh_no() {
		return ctc_if_dtl__coll_bh_no;
	}
	public void setCtc_if_dtl__coll_bh_no(String[] ctc_if_dtl__coll_bh_no) {
		this.ctc_if_dtl__coll_bh_no = ctc_if_dtl__coll_bh_no;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String[] getBsc_if__accd_rpt_no() {
		return bsc_if__accd_rpt_no;
	}
	public void setBsc_if__accd_rpt_no(String[] bsc_if__accd_rpt_no) {
		this.bsc_if__accd_rpt_no = bsc_if__accd_rpt_no;
	}
	public String[] getBsc_if__chng_sqno() {
		return bsc_if__chng_sqno;
	}
	public void setBsc_if__chng_sqno(String[] bsc_if__chng_sqno) {
		this.bsc_if__chng_sqno = bsc_if__chng_sqno;
	}
	public String[] getBsc_if__accd_oj_dvcd() {
		return bsc_if__accd_oj_dvcd;
	}
	public void setBsc_if__accd_oj_dvcd(String[] bsc_if__accd_oj_dvcd) {
		this.bsc_if__accd_oj_dvcd = bsc_if__accd_oj_dvcd;
	}
	public String[] getBsc_if__accd_oj_rnk() {
		return bsc_if__accd_oj_rnk;
	}
	public void setBsc_if__accd_oj_rnk(String[] bsc_if__accd_oj_rnk) {
		this.bsc_if__accd_oj_rnk = bsc_if__accd_oj_rnk;
	}
	public String[] getBsc_if__accd_ocr_dt() {
		return bsc_if__accd_ocr_dt;
	}
	public void setBsc_if__accd_ocr_dt(String[] bsc_if__accd_ocr_dt) {
		this.bsc_if__accd_ocr_dt = bsc_if__accd_ocr_dt;
	}
	public String[] getBsc_if__accd_ocr_tm() {
		return bsc_if__accd_ocr_tm;
	}
	public void setBsc_if__accd_ocr_tm(String[] bsc_if__accd_ocr_tm) {
		this.bsc_if__accd_ocr_tm = bsc_if__accd_ocr_tm;
	}
	public String[] getBsc_if__srch_val() {
		return bsc_if__srch_val;
	}
	public void setBsc_if__srch_val(String[] bsc_if__srch_val) {
		this.bsc_if__srch_val = bsc_if__srch_val;
	}
	public String[] getBsc_if__msg_cd() {
		return bsc_if__msg_cd;
	}
	public void setBsc_if__msg_cd(String[] bsc_if__msg_cd) {
		this.bsc_if__msg_cd = bsc_if__msg_cd;
	}
	public String[] getCtc_if_dtl__plno() {
		return ctc_if_dtl__plno;
	}
	public void setCtc_if_dtl__plno(String[] ctc_if_dtl__plno) {
		this.ctc_if_dtl__plno = ctc_if_dtl__plno;
	}
	public String[] getCtc_if_dtl__ctc_id() {
		return ctc_if_dtl__ctc_id;
	}
	public void setCtc_if_dtl__ctc_id(String[] ctc_if_dtl__ctc_id) {
		this.ctc_if_dtl__ctc_id = ctc_if_dtl__ctc_id;
	}
	public String[] getCtc_if_dtl__ins_cust_no() {
		return ctc_if_dtl__ins_cust_no;
	}
	public void setCtc_if_dtl__ins_cust_no(String[] ctc_if_dtl__ins_cust_no) {
		this.ctc_if_dtl__ins_cust_no = ctc_if_dtl__ins_cust_no;
	}
	public String[] getCtc_if_dtl__ctrmf_sqno() {
		return ctc_if_dtl__ctrmf_sqno;
	}
	public void setCtc_if_dtl__ctrmf_sqno(String[] ctc_if_dtl__ctrmf_sqno) {
		this.ctc_if_dtl__ctrmf_sqno = ctc_if_dtl__ctrmf_sqno;
	}
	public String[] getCtc_if_dtl__pdc_cd() {
		return ctc_if_dtl__pdc_cd;
	}
	public void setCtc_if_dtl__pdc_cd(String[] ctc_if_dtl__pdc_cd) {
		this.ctc_if_dtl__pdc_cd = ctc_if_dtl__pdc_cd;
	}
	public String[] getCtc_if_dtl__pdc_cd_nm() {
		return ctc_if_dtl__pdc_cd_nm;
	}
	public void setCtc_if_dtl__pdc_cd_nm(String[] ctc_if_dtl__pdc_cd_nm) {
		this.ctc_if_dtl__pdc_cd_nm = ctc_if_dtl__pdc_cd_nm;
	}
	public String[] getCtc_if_dtl__ncvr_yn() {
		return ctc_if_dtl__ncvr_yn;
	}
	public void setCtc_if_dtl__ncvr_yn(String[] ctc_if_dtl__ncvr_yn) {
		this.ctc_if_dtl__ncvr_yn = ctc_if_dtl__ncvr_yn;
	}
	public String[] getCtc_if_dtl__coll_hdqt_no() {
		return ctc_if_dtl__coll_hdqt_no;
	}
	public void setCtc_if_dtl__coll_hdqt_no(String[] ctc_if_dtl__coll_hdqt_no) {
		this.ctc_if_dtl__coll_hdqt_no = ctc_if_dtl__coll_hdqt_no;
	}
	public String[] getCtc_if_dtl__clmn_nm() {
		return ctc_if_dtl__clmn_nm;
	}
	public void setCtc_if_dtl__clmn_nm(String[] ctc_if_dtl__clmn_nm) {
		this.ctc_if_dtl__clmn_nm = ctc_if_dtl__clmn_nm;
	}
	public String[] getCtc_if_dtl__clmn_empno() {
		return ctc_if_dtl__clmn_empno;
	}
	public void setCtc_if_dtl__clmn_empno(String[] ctc_if_dtl__clmn_empno) {
		this.ctc_if_dtl__clmn_empno = ctc_if_dtl__clmn_empno;
	}
	public String[] getCtc_if_dtl__clmn_bh_no() {
		return ctc_if_dtl__clmn_bh_no;
	}
	public void setCtc_if_dtl__clmn_bh_no(String[] ctc_if_dtl__clmn_bh_no) {
		this.ctc_if_dtl__clmn_bh_no = ctc_if_dtl__clmn_bh_no;
	}
	public String[] getCtc_if_dtl__inpd_dvcd() {
		return ctc_if_dtl__inpd_dvcd;
	}
	public void setCtc_if_dtl__inpd_dvcd(String[] ctc_if_dtl__inpd_dvcd) {
		this.ctc_if_dtl__inpd_dvcd = ctc_if_dtl__inpd_dvcd;
	}
	public String[] getCtc_if_dtl__arc_trm_str_dt() {
		return ctc_if_dtl__arc_trm_str_dt;
	}
	public void setCtc_if_dtl__arc_trm_str_dt(String[] ctc_if_dtl__arc_trm_str_dt) {
		this.ctc_if_dtl__arc_trm_str_dt = ctc_if_dtl__arc_trm_str_dt;
	}
	public String[] getCtc_if_dtl__arc_trm_str_tm() {
		return ctc_if_dtl__arc_trm_str_tm;
	}
	public void setCtc_if_dtl__arc_trm_str_tm(String[] ctc_if_dtl__arc_trm_str_tm) {
		this.ctc_if_dtl__arc_trm_str_tm = ctc_if_dtl__arc_trm_str_tm;
	}
	public String[] getCtc_if_dtl__arc_trm_fin_dt() {
		return ctc_if_dtl__arc_trm_fin_dt;
	}
	public void setCtc_if_dtl__arc_trm_fin_dt(String[] ctc_if_dtl__arc_trm_fin_dt) {
		this.ctc_if_dtl__arc_trm_fin_dt = ctc_if_dtl__arc_trm_fin_dt;
	}
	public String[] getCtc_if_dtl__arc_trm_fin_tm() {
		return ctc_if_dtl__arc_trm_fin_tm;
	}
	public void setCtc_if_dtl__arc_trm_fin_tm(String[] ctc_if_dtl__arc_trm_fin_tm) {
		this.ctc_if_dtl__arc_trm_fin_tm = ctc_if_dtl__arc_trm_fin_tm;
	}
	
	
	
	
	public String getBsc_if___accd_ocr_dt() {
		return bsc_if___accd_ocr_dt;
	}
	public void setBsc_if___accd_ocr_dt(String bsc_if___accd_ocr_dt) {
		this.bsc_if___accd_ocr_dt = bsc_if___accd_ocr_dt;
	}
	public String getBsc_if___accd_ocr_tm() {
		return bsc_if___accd_ocr_tm;
	}
	public void setBsc_if___accd_ocr_tm(String bsc_if___accd_ocr_tm) {
		this.bsc_if___accd_ocr_tm = bsc_if___accd_ocr_tm;
	}
	public String getBsc_if___srch_val() {
		return bsc_if___srch_val;
	}
	public void setBsc_if___srch_val(String bsc_if___srch_val) {
		this.bsc_if___srch_val = bsc_if___srch_val;
	}
	
	
}
