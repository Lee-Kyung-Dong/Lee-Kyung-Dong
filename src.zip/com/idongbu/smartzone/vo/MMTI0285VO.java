package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class MMTI0285VO extends CMMVO {

	public String funt_key = null;
	public String plno = null;
	public String bse_dd = null;
	public String arc_trm_str_dt = null;
	public String arc_trm_fin_dt = null;
	
	public String[] plan_tty_mtt__drvr_rstc_tty_cd = new String[0];  			//[O] 설계특약사항_운전자한정특약코드
	public String[] plan_tty_mtt__drvr_rstc_tty_nm = new String[0]; 			//[O] 설계특약사항_운전자한정특약명
	public String[] plan_tty_mtt__ag_rstc_tty_cd = new String[0];  				//[O] 설계특약사항_연령한정특약코드
	public String[] plan_tty_mtt__ag_rstc_tty_nm = new String[0];  				//[O] 설계특약사항_연령한정특약명
	
	public String[] plan_ftr_tty_drvr_mtt__apcn_bgn_dt = new String[0];  		//[O] 설계미래특약운전자사항_적용개시일자
	public String[] plan_ftr_tty_drvr_mtt__apcn_fin_dt = new String[0]; 	 	//[O] 설계미래특약운전자사항_적용종료일자
	public String[] plan_ftr_tty_drvr_mtt__drvr_rstc_tty_cd = new String[0];  	//[O] 설계미래특약운전자사항_운전자한정특약코드
	public String[] plan_ftr_tty_drvr_mtt__drvr_rstc_tty_nm = new String[0];  	//[O] 설계미래특약운전자사항_운전자한정특약명
	
	public String[] plan_ftr_tty_ag_mtt__apcn_bgn_dt = new String[0];  			//[O] 설계미래특약연령사항_적용개시일자
	public String[] plan_ftr_tty_ag_mtt__apcn_fin_dt = new String[0];		  	//[O] 설계미래특약연령사항_운전자한정특약명
	public String[] plan_ftr_tty_ag_mtt__ag_rstc_tty_cd = new String[0];  		//[O] 설계미래특약연령사항_연령한정특약코드
	public String[] plan_ftr_tty_ag_mtt__ag_rstc_tty_nm = new String[0];  		//[O] 설계미래특약연령사항_연령한정특약명
	public String[] plan_ftr_tty_ag_mtt__ag_aut_chng_yn = new String[0];  		//[O] 설계미래특약연령사항_연령자동변경여부
	public String getFunt_key() {
		return funt_key;
	}
	public void setFunt_key(String funt_key) {
		this.funt_key = funt_key;
	}
	public String getPlno() {
		return plno;
	}
	public void setPlno(String plno) {
		this.plno = plno;
	}
	public String getBse_dd() {
		return bse_dd;
	}
	public void setBse_dd(String bse_dd) {
		this.bse_dd = bse_dd;
	}
	public String getArc_trm_str_dt() {
		return arc_trm_str_dt;
	}
	public void setArc_trm_str_dt(String arc_trm_str_dt) {
		this.arc_trm_str_dt = arc_trm_str_dt;
	}
	public String getArc_trm_fin_dt() {
		return arc_trm_fin_dt;
	}
	public void setArc_trm_fin_dt(String arc_trm_fin_dt) {
		this.arc_trm_fin_dt = arc_trm_fin_dt;
	}
	public String[] getPlan_tty_mtt__drvr_rstc_tty_cd() {
		return plan_tty_mtt__drvr_rstc_tty_cd;
	}
	public void setPlan_tty_mtt__drvr_rstc_tty_cd(String[] plan_tty_mtt__drvr_rstc_tty_cd) {
		this.plan_tty_mtt__drvr_rstc_tty_cd = plan_tty_mtt__drvr_rstc_tty_cd;
	}
	public String[] getPlan_tty_mtt__drvr_rstc_tty_nm() {
		return plan_tty_mtt__drvr_rstc_tty_nm;
	}
	public void setPlan_tty_mtt__drvr_rstc_tty_nm(String[] plan_tty_mtt__drvr_rstc_tty_nm) {
		this.plan_tty_mtt__drvr_rstc_tty_nm = plan_tty_mtt__drvr_rstc_tty_nm;
	}
	public String[] getPlan_tty_mtt__ag_rstc_tty_cd() {
		return plan_tty_mtt__ag_rstc_tty_cd;
	}
	public void setPlan_tty_mtt__ag_rstc_tty_cd(String[] plan_tty_mtt__ag_rstc_tty_cd) {
		this.plan_tty_mtt__ag_rstc_tty_cd = plan_tty_mtt__ag_rstc_tty_cd;
	}
	public String[] getPlan_tty_mtt__ag_rstc_tty_nm() {
		return plan_tty_mtt__ag_rstc_tty_nm;
	}
	public void setPlan_tty_mtt__ag_rstc_tty_nm(String[] plan_tty_mtt__ag_rstc_tty_nm) {
		this.plan_tty_mtt__ag_rstc_tty_nm = plan_tty_mtt__ag_rstc_tty_nm;
	}
	public String[] getPlan_ftr_tty_drvr_mtt__apcn_bgn_dt() {
		return plan_ftr_tty_drvr_mtt__apcn_bgn_dt;
	}
	public void setPlan_ftr_tty_drvr_mtt__apcn_bgn_dt(String[] plan_ftr_tty_drvr_mtt__apcn_bgn_dt) {
		this.plan_ftr_tty_drvr_mtt__apcn_bgn_dt = plan_ftr_tty_drvr_mtt__apcn_bgn_dt;
	}
	public String[] getPlan_ftr_tty_drvr_mtt__apcn_fin_dt() {
		return plan_ftr_tty_drvr_mtt__apcn_fin_dt;
	}
	public void setPlan_ftr_tty_drvr_mtt__apcn_fin_dt(String[] plan_ftr_tty_drvr_mtt__apcn_fin_dt) {
		this.plan_ftr_tty_drvr_mtt__apcn_fin_dt = plan_ftr_tty_drvr_mtt__apcn_fin_dt;
	}
	public String[] getPlan_ftr_tty_drvr_mtt__drvr_rstc_tty_cd() {
		return plan_ftr_tty_drvr_mtt__drvr_rstc_tty_cd;
	}
	public void setPlan_ftr_tty_drvr_mtt__drvr_rstc_tty_cd(String[] plan_ftr_tty_drvr_mtt__drvr_rstc_tty_cd) {
		this.plan_ftr_tty_drvr_mtt__drvr_rstc_tty_cd = plan_ftr_tty_drvr_mtt__drvr_rstc_tty_cd;
	}
	public String[] getPlan_ftr_tty_drvr_mtt__drvr_rstc_tty_nm() {
		return plan_ftr_tty_drvr_mtt__drvr_rstc_tty_nm;
	}
	public void setPlan_ftr_tty_drvr_mtt__drvr_rstc_tty_nm(String[] plan_ftr_tty_drvr_mtt__drvr_rstc_tty_nm) {
		this.plan_ftr_tty_drvr_mtt__drvr_rstc_tty_nm = plan_ftr_tty_drvr_mtt__drvr_rstc_tty_nm;
	}
	public String[] getPlan_ftr_tty_ag_mtt__apcn_bgn_dt() {
		return plan_ftr_tty_ag_mtt__apcn_bgn_dt;
	}
	public void setPlan_ftr_tty_ag_mtt__apcn_bgn_dt(String[] plan_ftr_tty_ag_mtt__apcn_bgn_dt) {
		this.plan_ftr_tty_ag_mtt__apcn_bgn_dt = plan_ftr_tty_ag_mtt__apcn_bgn_dt;
	}
	public String[] getPlan_ftr_tty_ag_mtt__apcn_fin_dt() {
		return plan_ftr_tty_ag_mtt__apcn_fin_dt;
	}
	public void setPlan_ftr_tty_ag_mtt__apcn_fin_dt(String[] plan_ftr_tty_ag_mtt__apcn_fin_dt) {
		this.plan_ftr_tty_ag_mtt__apcn_fin_dt = plan_ftr_tty_ag_mtt__apcn_fin_dt;
	}
	public String[] getPlan_ftr_tty_ag_mtt__ag_rstc_tty_cd() {
		return plan_ftr_tty_ag_mtt__ag_rstc_tty_cd;
	}
	public void setPlan_ftr_tty_ag_mtt__ag_rstc_tty_cd(String[] plan_ftr_tty_ag_mtt__ag_rstc_tty_cd) {
		this.plan_ftr_tty_ag_mtt__ag_rstc_tty_cd = plan_ftr_tty_ag_mtt__ag_rstc_tty_cd;
	}
	public String[] getPlan_ftr_tty_ag_mtt__ag_rstc_tty_nm() {
		return plan_ftr_tty_ag_mtt__ag_rstc_tty_nm;
	}
	public void setPlan_ftr_tty_ag_mtt__ag_rstc_tty_nm(String[] plan_ftr_tty_ag_mtt__ag_rstc_tty_nm) {
		this.plan_ftr_tty_ag_mtt__ag_rstc_tty_nm = plan_ftr_tty_ag_mtt__ag_rstc_tty_nm;
	}
	public String[] getPlan_ftr_tty_ag_mtt__ag_aut_chng_yn() {
		return plan_ftr_tty_ag_mtt__ag_aut_chng_yn;
	}
	public void setPlan_ftr_tty_ag_mtt__ag_aut_chng_yn(String[] plan_ftr_tty_ag_mtt__ag_aut_chng_yn) {
		this.plan_ftr_tty_ag_mtt__ag_aut_chng_yn = plan_ftr_tty_ag_mtt__ag_aut_chng_yn;
	}
	

	
}
