package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class LLTI0049VO extends CMMVO{
	//전문필드
		public String plno_1 = "";  //[I] 증권번호1 JJ_POLI_NO 증권번호
		public String srch_dvn = "";	//[I]	조회구분 ''1'현재계약, '2'배서, '3'배서이력, '4'원계약
		public String ctrmf_sqno = "";  //[I] 계약변경일련번호 JJ_BESU_SEQ 배서코드
		public String pdc_cd = "";  //[O] 상품코드 JJ_BJ_CD 보종코드
		public String pdc_nm = "";  //[O] 상품명 HJ_BJ_NAME 상품명
		public String pdc_dvn = "";  //[O] 상품구분 HJ_BJ_GBN 상품군코드
		public String ins_nm = "";  //[O] 피보험자명 HJ_PI_NAME1 피보험자명
		public String ins_rrno = "";  //[O] 피보험자주민등록번호 JJ_PI_JUMIN1 피보험자주민번호
		public String arc_trm_pd_ymd = "";  //[O] 보험기간시기년월일 JJ_BH_SYMD 보험기간시기일자
		public String arc_trm_et_ymd = "";  //[O] 보험기간종기년월일 JJ_BH_EYMD 보험기간종기일자
		public String pytr_val = "";  //[O] 납기값 JJ_BOHUM_GIGANCD  보험기간코드
		public String pytr_dvcd = "";  //[O] 납기구분코드  
		public String pytr_dvcd_nm = "";  //[O] 납기구분코드명 HJ_BH_NM 보험기간명
		public String pym_mtd_hngl_nm = "";  //[O] 납입방법한글명 HJ_BUNNAP_NM1 납입방법한글명
		public String ins_inj_rtg = "";  //[O] 피보험자상해급수 JJ_GBSU_CD1 피보험자상해급수
		public String ins_ag = "";  //[O] 피보험자연령 JJ_PIBO_AGE1 피보험자연령
		public String drve_yn_hngl_nm = "";  //[O] 운전여부한글명 HJ_CAR_UNHENG_NM 운전여부한글명
		public String smok_yn_hngl_nm = "";  //[O] 흡연여부한글명 HJ_MULGUN_GUBUN 흡연여부한글명
		public String mtcc_ncvr_eny_yn_hngl_nm = "";  //[O] 이륜차부담보가입여부한글명 HJ_SANGHE_CD15 이륜차부담보가입여부한글명
		public String sl_pan_cd = "";  //[O] 판매플랜코드 JJ_GAIP_TYPE1  가입유형1
		public String sl_pan_nm = "";  //[O] 판매플랜명 HJ_TYPE1_NM 가입유형1한글명
		public String exp_tpcd_nm = "";  //[O] 만기유형코드명 HJ_TYPE2_NM 가입유형2한글명
		public String aiba_equp_yn_hngl_nm = "";  //[O] 에어백장착여부한글명 HJ_MULGUN_GUBUNNM 에어백장착여부한글명
		public String exp_rprm_sp_cd_hngl_nm = "";  //[O] 만기환급금종별코드한글명 HJ_JONG_NM 만기종별한글명
		public String spcf_prtn_ncvr_eny_yn_hngl_nm = "";  //[O] 특정부위부담보가입여부한글명 HJ_TKYAK_MANGI 특정부위부담보가입여부
		public String pyn_trm = "";  //[O] 지급기간 JJ_JIGUB_GIGAN 지급기간
		public String ins_nm_2 = "";  //[O] 피보험자명2 HJ_PI_NAME2 피보험자명2
		public String ins_rrno_2 = "";  //[O] 피보험자주민등록번호2 JJ_PI_JUMIN2 피보험자주민번호2
		public String pym_mtd_hngl_nm_2 = "";  //[O] 납입방법한글명2 HJ_BUNNAP_NM2 납입방법명2
		public String ins_ag_2 = "";  //[O] 피보험자연령2 JJ_PIBO_AGE2 피보험자연령2
		public String ins_inj_rtg_2 = "";  //[O] 피보험자상해급수2 JJ_GBSU_CD2 피보험자상해급수2
		public String pytr_dvcd_nm_2 = "";  //[O] 납기구분코드명_2 HJ_BOHUM_GG_NM 보험기간명2
		public String dfmt_ycnt = "";  //[O] 거치년수 JJ_GUCHI_YCNT 거치년수
		public String arc_trm_pd_ymd_2 = "";  //[O] 보험기간시기년월일2 JJ_BOHUM_SYMD 보험기간시기년월일2
		public String arc_trm_et_ymd_2 = "";  //[O] 보험기간종기년월일2 JJ_BOHUM_EYMD 보험기간종기년월일2
		public String exp_rprm_sp_cd = "";  //[O] 만기환급금종별코드 JJ_JONGBYL_CD 만기종별코드
		public String fs_arc_trm_pd_dt = "";  //[O] 제1보험기간시기일자 JJ_1BOHUM_SYMD 제1보험기간시기일자
		public String fs_arc_trm_et_dt = "";  //[O] 제1보험기간종기일자 JJ_1BOHUM_EYMD 제1보험기간종기일자
		public String fs_arc_trm_ycnt = "";  //[O] 제1보험기간년수 JJ_1BOHUM_YY 제1보험기간년수
		public String fs_tty_trm_nm = "";  //[O] 제1특약기간명 HJ_1BOHUM_MANGI 제1특약기간명
		public String scd_arc_trm_pd_dt = "";  //[O] 제2보험기간시기일자 JJ_2BOHUM_SYMD 제2보험기간시기일자
		public String scd_arc_trm_et_dt = "";  //[O] 제2보험기간종기일자 JJ_2BOHUM_EYMD 제2보험기간종기일자
		public String scd_arc_trm_ycnt = "";  //[O] 제2보험기간년수 JJ_2BOHUM_YY 제2보험기간년수
		public String scd_tty_trm_nm = "";  //[O] 제2특약기간명 HJ_2BOHUM_MANGI 제2특약기간명
		public String pnn_bgn_ag_hngl_nm = "";  //[O] 연금개시연령한글명 HJ_GESI_AGE_NM 연금개시연령한글명
		public String pnn_pyn_mtd_hngl_nm = "";  //[O] 연금지급방법한글명 HJ_JIGP_BB_NM 연금지급방법한글명
		public String pnn_pyn_trm_hngl_nm = "";  //[O] 연금지급기간한글명 HJ_JIGP_YCNT_NM 연금지급기간한글명
		public String pnn_pyn_shp_hngl_nm = "";  //[O] 연금지급형태한글명 HJ_JIGP_GB_NM 연금지급형태한글명
		public String grn_lice_yn_hngl_nm = "";  //[O] 녹색면허여부한글명 HJ_DRIV_LICENSENM 녹색면허여부한글명
		public String plno_2 = "";  //[O] 증권번호2 JJ-POLI-NO-2  증권번호2
		public String pdc_nm_2 = "";  //[O] 상품명2 HJ-BJ-NAME-2 상품명2
		public String spcf_prtn_ncvr_nm_1 = "";  //[O] 특정부위부담보명1 HJ_TUKJU_1 특정부위부담보명 1
		public String spcf_prtn_ncvr_nm_2 = "";  //[O] 특정부위부담보명2 HJ_TUKJU_2 특정부위부담보명 2
		public String spcf_prtn_ncvr_nm_3 = "";  //[O] 특정부위부담보명 3 HJ_TUKJU_3 특정부위부담보명 3
		public String spcf_prtn_ncvr_nm_4 = "";  //[O] 특정부위부담보명 4 HJ_TUKJU_4 특정부위부담보명 4
		public String spcf_prtn_ncvr_trm_1 = "";  //[O] 특정부위부담보기간1 HJ_TUKJU_GIGAN 특정부위부담보기간 1
		public String spcf_prtn_ncvr_trm_2 = "";  //[O] 특정부위부담보기간2 HJ_TUKJU_GIGAN2 특정부위부담보기간 2
		public String spcf_prtn_ncvr_trm_3 = "";  //[O] 특정부위부담보기간 3 HJ_TUKJU_GIGAN3 특정부위부담보기간 3
		public String spcf_prtn_ncvr_trm_4 = "";  //[O] 특정부위부담보기간 4 HJ_TUKJU_GIGAN4 특정부위부담보기간 4
		public String prm_xtr_gr_hngl_nm = "";  //[O] 보험료할증등급한글명 HJ_HAL_LEV 보험료할증등급한글명
		public String prm_ctbk_trm_hngl_nm = "";  //[O] 보험료삭감기간한글명 HJ_SAK_GIGAN 보험료삭감기간한글명
		public String xtr_prm = "";  //[O] 할증보험료 JJ_HAL_PRM 할증보험료
		public String ins_oprt_vh_nm = "";  //[O] 피보험자운행차량명 HJ_CAR_M 피보험자운행차량명
		public String apti_ipt_aply_yn_hngl_nm = "";  //[O] 적성검사신청여부한글명 HJ_JUKSUNG 적성검사신청여부한글명
		public String cmy_no = "";  //[O] 회사번호 JJ_GIUP_CD 1000대기업코드
		public String cmy_nm = "";  //[O] 회사명 HJ_GIUP_NM 1000대기업명
		public String accu_irt_hngl_nm = "";  //[O] 적립이율한글명 HJ-JUKRIP-IYUL  적립이율한글명
		public String inte_pyn_mtd_hngl_nm = "";  //[O] 이자지급방법한글명 HJ-JIGP-NM 이자지급방법한글명
		public String[] cvr_eny_if_cvr_hngl_nm = new String[0];  //[O] 담보가입정보_담보한글명 HJ_DAMBO_NAME 담보한글명
		public String[] cvr_eny_if_cvr_inam = new String[0];  //[O] 담보가입정보_담보가입금액 JJ_GAIP_GMEK 담보가입금액
		public String[] cvr_eny_if_cvr_bsc_prm = new String[0];  //[O] 담보가입정보_담보기본보험료 JJ_GIBON_PRM 담보기본보험료
		public String[] cvr_eny_if_cvr_cd = new String[0];  //[O] 담보가입정보_담보코드 JJ_DAMBO_CD 담보코드
		public String[] cvr_eny_if_on_altm = new String[0];  //[O] 담보가입정보_자기부담금 JJ-APER-GAIP-GMEK 자기부담금
		public String[] cvr_eny_if_rnw_cvr_yn = new String[0];  //[O] 담보가입정보_갱신담보여부 JJ-GENGSIN-YN  갱신담보여부
		public String[] cvr_eny_if_spc_cdnl_hngl_nm = new String[0];  //[O] 담보가입정보_특별조건부한글명 HJ-JOB-CDNM    특별조건부한글명
		public String fmy_cvr_yn = "";  //[O] 가족담보유무 JJ_GAJOK_YN 가족담보유무
		public String fmy_prm_sm = "";  //[O] 가족보험료합계 JJ_GAJOK_TOT 가족보험료합계
		public String asr_prm = "";  //[O] 보장보험료 JJ_BOJANG_PRM 보장보험료
		public String accu_prm = "";  //[O] 적립보험료 JJ_JUKRIP_BUMUN_PRM 적립보험료
		public String prt_spr_accu_prm = "";  //[O] 일부일시납적립보험료 JJ_JUKRIP_BUMUN_PRM1 일부일시납적립보험료
		public String sm_prm = "";  //[O] 합계보험료 JJ_SUM_PRM 합계보험료
		public String pym_epct_prm = "";  //[O] 납입예정보험료 JJ_NAPIPHAL_PRM 받을보험료
		public String ppry_prm = "";  //[O] 재물보험료 JJ_MULGUNL_PRM 재물보험료
		public String ltm_trt = "";  //[O] 요율이력번호 JJ_SIGI_GUBUN 요율이력번호
		public String ply_rcpl_dvcd = "";  //[O] 증권수령처구분코드 JJ-BALGUP-GB 증권수령처구분코드
		public String ply_rcpl_hngl_nm = "";  //[O] 증권수령처한글명 HJ-BALGUP-NM 증권수령처구분한글명
		public String pnn_dfmt_trm_hngl_nm = "";  //[O] 연금거치기간한글명 HJ-GUCHI-CNT  연금거치기간한글명
		public String[] pym_if_pym_sqno = new String[0];  //[O] 납입정보_납입일련번호 JJ_3212_SEQ 납입일련번호
		public String[] pym_if_pym_tgt_yy = new String[0];  //[O] 납입정보_납입대상년 JJ_3212_YYYY 납입대상년
		public String[] pym_if_pym_amt = new String[0];  //[O] 납입정보_납입금액 JJ_3212_NAPIP_PRM 납입금액
		public String[] pym_if_pym_crtf_isu_amt = new String[0];  //[O] 납입정보_납입증명서발급금액 JJ_3212_BALGB_PRM 납입증명서발급금액
		public String prvs_pnn_pym_cmtt_amt = "";  //[O] 이전연금납입누계금액 JJ_3212_NUGYE 入이전연금납입누계액
		public String prvs_pnn_txn_tgt_mpf = "";  //[O] 이전연금과세대상차익 JJ_3212_CHAIK 入이전연금과세대상차익
		public String sos_vh_ownr_nm = "";  //[O] SOS차량소유자명 HJ_SOYU SOS차량소유자명
		public String vh_no_hngl_nm = "";  //[O] 차량번호한글명 HJ_CAR 차량번호한글명
		public String vh_ipt_epct_dt = "";  //[O] 차량검사예정일자 JJ_GEOMSA 차량검사예정일
		public String chd_dipp_cvr_eny_psct = "";  //[O] 자녀실종담보가입인원수 JJ_283_SU 자녀실종담보가입인원수
		public String fmy_cnt = "";  //[O] 가족수 JJ_GAJOK_SU 가족수
		public String chd_cnt = "";  //[O] 자녀수 JJ_GAJOK_JA 자녀수
		public String chd_nme = "";  //[O] 자녀성명 HJ_JANYU_NAME 자녀성명
		public String chd_rrno = "";  //[O] 자녀주민등록번호 JJ_JA_JUMIN 자녀주민번호
		public String chd_dipp_bsc_prm = "";  //[O] 자녀실종기본보험료 JJ_PRM_282 자녀실종기본보험료
		public String trvl_trm_str_dt = "";  //[O] 여행기간시작일자 JJ_TOUR_FROM 여행기간시작일자
		public String trvl_trm_fin_dt = "";  //[O] 여행기간종료일자 JJ_TOUR_TO 여행기간종료일자
		public String trvl_trm_dvcd_hngl_nm = "";  //[O] 여행기간구분코드한글명 HJ_TOUR_NAME 여행기간구분코드명
		public String spos_nm = "";  //[O] 배우자명 HJ_3219_JANYU_NAME 배우자연인명
		public String spos_brth = "";  //[O] 배우자생년월일 JJ_3219_JANYU_YMD 배우자생년월일
		public String msv_trm_mcnt = "";  //[O] 군복무기간월수 JJ_ARMY_WOL 군복무기간월수
		public String ownr_nm = "";  //[O] 소유자명 HJ_SO_NM 소유자명
		public String ownr_rrno = "";  //[O] 소유자주민등록번호 JJ_SO_JUMIN 소유자 주민번호
		public String lcpl_psno = "";  //[O] 소재지우편번호 JJ_SO_ZIP 소재지우편번호
		public String lcpl_adr = "";  //[O] 소재지주소 HJ_SO_ADDR 소재지주소
		public String lcpl_eta_adr = "";  //[O] 소재지기타주소 HJ_SO_GITA 소재지기타주소
		public String lcpl_nwod_adr_dvcd = "";  //[O] 소재지신구주소구분코드 JJ-SO-SINGU-GB  소재지신구주소구분코드
		public String crrn_bstp_cd = "";  //[O] 영위업종코드 JJ_JOB_JIK 영위직작업코드
		public String apcn_bstp_cd = "";  //[O] 적용업종코드 JJ_YOYUL_JIK 적용요율직작업코드
		public String bd_stru_rtg_cd = "";  //[O] 건물구조급수코드 JJ_GUJO_GBSU 건물구조급수
		public String[] ojt_if_ojt_cd = new String[0];  //[O] 목적물정보_목적물코드 JJ_MOKJUK 목적물코드
		public String[] ojt_if_ojt_rtg_cd = new String[0];  //[O] 목적물정보_목적물급수코드 JJ_MOKJUK_GBSU 목적물급수코드
		public String[] ojt_if_ojt_bd_sqar = new String[0];  //[O] 목적물정보_목적물건물면적 JJ_MYUNJUK 목적물건물면적
		public String[] ojt_if_ojt_inam = new String[0];  //[O] 목적물정보_목적물가입금액 JJ_GAIP 목적물가입금액
		public String[] ojt_if_ojt_bsc_prm = new String[0];  //[O] 목적물정보_목적물기본보험료 JJ_PRM 목적물기본보험료
		public String[] ojt_if_ojt_stru_cn_nm = new String[0];  //[O] 목적물정보_목적물구조내용명 HJ_GUJO 목적물건물구조내용명
		public String acdt_plc_mn1 = "";  //[O] 수용장소1명 HJ_SUYONG1 수용장소1명
		public String fclt_ownr_lbt_eny_yn = "";  //[O] 시설소유자배상책임가입여부 JJ-S4-YN         시설소유자배상책임가입여부
		public String fclt_ownr_lbt_inam_1 = "";  //[O] 시설소유자배상책임가입금액1 JJ-S4-GAIP1      시설소유자배상책임가입금액1
		public String fclt_ownr_lbt_inam_2 = "";  //[O] 시설소유자배상책임가입금액2 JJ-S4-GAIP2      시설소유자배상책임가입금액2
		public String fclt_ownr_lbt_bstp = "";  //[O] 시설소유자배상책임업종 JJ-S4-UPJONG     시설소유자배상책임업종
		public String fclt_ownr_lbt_fclt_scl = "";  //[O] 시설소유자배상책임시설규모 JJ-S4-GYUMO      시설소유자배상책임시설규모
		public String fclt_ownr_lbt_fclt_sqar = "";  //[O] 시설소유자배상책임시설면적 JJ-S4-MYUNJUK    시설소유자배상책임시설면적
		public String fclt_ownr_lbt_eny_typ = "";  //[O] 시설소유자배상책임가입유형 JJ-S4-TYPE-CD    시설소유자배상책임가입유형
		public String fclt_ownr_lbt_on_chrg_dvn = "";  //[O] 시설소유자배상책임자기부담구분 JJ-S4-BUDAM-GB   시설소유자배상책임자기부담구분
		public String food_lbt_eny_yn = "";  //[O] 음식물 배상책임가입여부 JJ-S5-YN          음식물 배상책임가입여부
		public String food_lbt_inam_1 = "";  //[O] 음식물 배상책임가입금액1 JJ-S5-GAIP1       음식물 배상책임가입금액1
		public String food_lbt_inam_2 = "";  //[O] 음식물 배상책임가입금액2 JJ-S5-GAIP2       음식물 배상책임가입금액2
		public String food_lbt_bstp = "";  //[O] 음식물 배상책임업종 JJ-S5-UPJONG      음식물 배상책임업종
		public String food_lbt_bstp_hngl_nm = "";  //[O] 음식물 배상책임업종한글명 HJ-S5-UPJONG      음식물 배상책임업종한글명
		public String food_lbt_rvnu_aot = "";  //[O] 음식물 배상책임매출액 JJ-S5-MECHUL-GM   음식물 배상책임매출액
		public String bdy_dag_lbt_eny_yn = "";  //[O] 신체손해배상책임가입여부 JJ-S3-YN         신체손해배상책임가입여부
		public String bdy_dag_lbt_inam = "";  //[O] 신체손해배상책임가입금액 JJ-S3-GAIP       신체손해배상책임가입금액
		public String bdy_dag_lbt_dst_rt_cd = "";  //[O] 신체손해배상책임할인률코드 JJ-S3-HALIN      신체손해배상책임할인률코드
		public String bdy_dag_lbt_dst_rt_hngl_nm = "";  //[O] 신체손해배상책임할인율한글명 HJ-S3-HALIN      신체손해배상책임할인율한글명
		public String bdy_dag_lbt_bstp = "";  //[O] 신체손해배상책임업종 JJ-S3-UPJONG     신체손해배상책임업종
		public String bdy_dag_lbt_bstp_hngl_nm = "";  //[O] 신체손해배상책임업종한글명 HJ-S3-UPJONG     신체손해배상책임업종한글명
		public String not_spl_bd_gomc_re_dag_eny_yn = "";  //[O] 비특수건물풍수재손해가입여부 JJ-S6-YN        비특수건물풍수재손해가입여부
		public String not_spl_bd_gomc_re_dag_undg_yn = "";  //[O] 비특수건물풍수재손해지하여부 JJ-S6-JIHA-YN   비특수건물풍수재손해지하여부
		public String chd_edu_fd_det_ag = "";  //[O] 자녀교육자금명세연령 JJ-S7-AGE     자녀교육자금명세연령
		public String chd_edu_fd_det_nme = "";  //[O] 자녀교육자금명세성명 HJ-S7-NM      자녀교육자금명세성명
		public String chd_edu_fd_det_rsdn_no = "";  //[O] 자녀교육자금명세주민번호 JJ-S7-JUMIN   자녀교육자금명세주민번호
		public String mvgn_pnn_pvs_eny_ognm = "";  //[O] 전입연금기존가입기관명 HJ-I-YUNGM-COMP-NM 전입연금기존가입기관명
		public String mvgn_pnn_frst_eny_dt = "";  //[O] 전입연금최초가입일자 JJ-I-YUNGM-GAIPIL 전입연금최초가입일자
		public String mvgn_pnn_prvs_prm = "";  //[O] 전입연금이전보험료 JJ-I-YUNGM-PRM 전입연금이전보험료
		public String ctc_id = "";  //[O] 계약ID  
		public String ins_cust_no = "";  //[O] 피보험자고객번호  
		public String errorCode = "";  //[O] 피보험자고객번호  
		
		
		public String getPlno_1() {
			return plno_1;
		}
		public void setPlno_1(String plno_1) {
			this.plno_1 = plno_1;
		}
		public String getSrch_dvn() {
			return srch_dvn;
		}
		public void setSrch_dvn(String srch_dvn) {
			this.srch_dvn = srch_dvn;
		}
		public String getCtrmf_sqno() {
			return ctrmf_sqno;
		}
		public void setCtrmf_sqno(String ctrmf_sqno) {
			this.ctrmf_sqno = ctrmf_sqno;
		}
		public String getPdc_cd() {
			return pdc_cd;
		}
		public void setPdc_cd(String pdc_cd) {
			this.pdc_cd = pdc_cd;
		}
		public String getPdc_nm() {
			return pdc_nm;
		}
		public void setPdc_nm(String pdc_nm) {
			this.pdc_nm = pdc_nm;
		}
		public String getPdc_dvn() {
			return pdc_dvn;
		}
		public void setPdc_dvn(String pdc_dvn) {
			this.pdc_dvn = pdc_dvn;
		}
		public String getIns_nm() {
			return ins_nm;
		}
		public void setIns_nm(String ins_nm) {
			this.ins_nm = ins_nm;
		}
		public String getIns_rrno() {
			return ins_rrno;
		}
		public void setIns_rrno(String ins_rrno) {
			this.ins_rrno = ins_rrno;
		}
		public String getArc_trm_pd_ymd() {
			return arc_trm_pd_ymd;
		}
		public void setArc_trm_pd_ymd(String arc_trm_pd_ymd) {
			this.arc_trm_pd_ymd = arc_trm_pd_ymd;
		}
		public String getArc_trm_et_ymd() {
			return arc_trm_et_ymd;
		}
		public void setArc_trm_et_ymd(String arc_trm_et_ymd) {
			this.arc_trm_et_ymd = arc_trm_et_ymd;
		}
		public String getPytr_val() {
			return pytr_val;
		}
		public void setPytr_val(String pytr_val) {
			this.pytr_val = pytr_val;
		}
		public String getPytr_dvcd() {
			return pytr_dvcd;
		}
		public void setPytr_dvcd(String pytr_dvcd) {
			this.pytr_dvcd = pytr_dvcd;
		}
		public String getPytr_dvcd_nm() {
			return pytr_dvcd_nm;
		}
		public void setPytr_dvcd_nm(String pytr_dvcd_nm) {
			this.pytr_dvcd_nm = pytr_dvcd_nm;
		}
		public String getPym_mtd_hngl_nm() {
			return pym_mtd_hngl_nm;
		}
		public void setPym_mtd_hngl_nm(String pym_mtd_hngl_nm) {
			this.pym_mtd_hngl_nm = pym_mtd_hngl_nm;
		}
		public String getIns_inj_rtg() {
			return ins_inj_rtg;
		}
		public void setIns_inj_rtg(String ins_inj_rtg) {
			this.ins_inj_rtg = ins_inj_rtg;
		}
		public String getIns_ag() {
			return ins_ag;
		}
		public void setIns_ag(String ins_ag) {
			this.ins_ag = ins_ag;
		}
		public String getDrve_yn_hngl_nm() {
			return drve_yn_hngl_nm;
		}
		public void setDrve_yn_hngl_nm(String drve_yn_hngl_nm) {
			this.drve_yn_hngl_nm = drve_yn_hngl_nm;
		}
		public String getSmok_yn_hngl_nm() {
			return smok_yn_hngl_nm;
		}
		public void setSmok_yn_hngl_nm(String smok_yn_hngl_nm) {
			this.smok_yn_hngl_nm = smok_yn_hngl_nm;
		}
		public String getMtcc_ncvr_eny_yn_hngl_nm() {
			return mtcc_ncvr_eny_yn_hngl_nm;
		}
		public void setMtcc_ncvr_eny_yn_hngl_nm(String mtcc_ncvr_eny_yn_hngl_nm) {
			this.mtcc_ncvr_eny_yn_hngl_nm = mtcc_ncvr_eny_yn_hngl_nm;
		}
		public String getSl_pan_cd() {
			return sl_pan_cd;
		}
		public void setSl_pan_cd(String sl_pan_cd) {
			this.sl_pan_cd = sl_pan_cd;
		}
		public String getSl_pan_nm() {
			return sl_pan_nm;
		}
		public void setSl_pan_nm(String sl_pan_nm) {
			this.sl_pan_nm = sl_pan_nm;
		}
		public String getExp_tpcd_nm() {
			return exp_tpcd_nm;
		}
		public void setExp_tpcd_nm(String exp_tpcd_nm) {
			this.exp_tpcd_nm = exp_tpcd_nm;
		}
		public String getAiba_equp_yn_hngl_nm() {
			return aiba_equp_yn_hngl_nm;
		}
		public void setAiba_equp_yn_hngl_nm(String aiba_equp_yn_hngl_nm) {
			this.aiba_equp_yn_hngl_nm = aiba_equp_yn_hngl_nm;
		}
		public String getExp_rprm_sp_cd_hngl_nm() {
			return exp_rprm_sp_cd_hngl_nm;
		}
		public void setExp_rprm_sp_cd_hngl_nm(String exp_rprm_sp_cd_hngl_nm) {
			this.exp_rprm_sp_cd_hngl_nm = exp_rprm_sp_cd_hngl_nm;
		}
		public String getSpcf_prtn_ncvr_eny_yn_hngl_nm() {
			return spcf_prtn_ncvr_eny_yn_hngl_nm;
		}
		public void setSpcf_prtn_ncvr_eny_yn_hngl_nm(
				String spcf_prtn_ncvr_eny_yn_hngl_nm) {
			this.spcf_prtn_ncvr_eny_yn_hngl_nm = spcf_prtn_ncvr_eny_yn_hngl_nm;
		}
		public String getPyn_trm() {
			return pyn_trm;
		}
		public void setPyn_trm(String pyn_trm) {
			this.pyn_trm = pyn_trm;
		}
		public String getIns_nm_2() {
			return ins_nm_2;
		}
		public void setIns_nm_2(String ins_nm_2) {
			this.ins_nm_2 = ins_nm_2;
		}
		public String getIns_rrno_2() {
			return ins_rrno_2;
		}
		public void setIns_rrno_2(String ins_rrno_2) {
			this.ins_rrno_2 = ins_rrno_2;
		}
		public String getPym_mtd_hngl_nm_2() {
			return pym_mtd_hngl_nm_2;
		}
		public void setPym_mtd_hngl_nm_2(String pym_mtd_hngl_nm_2) {
			this.pym_mtd_hngl_nm_2 = pym_mtd_hngl_nm_2;
		}
		public String getIns_ag_2() {
			return ins_ag_2;
		}
		public void setIns_ag_2(String ins_ag_2) {
			this.ins_ag_2 = ins_ag_2;
		}
		public String getIns_inj_rtg_2() {
			return ins_inj_rtg_2;
		}
		public void setIns_inj_rtg_2(String ins_inj_rtg_2) {
			this.ins_inj_rtg_2 = ins_inj_rtg_2;
		}
		public String getPytr_dvcd_nm_2() {
			return pytr_dvcd_nm_2;
		}
		public void setPytr_dvcd_nm_2(String pytr_dvcd_nm_2) {
			this.pytr_dvcd_nm_2 = pytr_dvcd_nm_2;
		}
		public String getDfmt_ycnt() {
			return dfmt_ycnt;
		}
		public void setDfmt_ycnt(String dfmt_ycnt) {
			this.dfmt_ycnt = dfmt_ycnt;
		}
		public String getArc_trm_pd_ymd_2() {
			return arc_trm_pd_ymd_2;
		}
		public void setArc_trm_pd_ymd_2(String arc_trm_pd_ymd_2) {
			this.arc_trm_pd_ymd_2 = arc_trm_pd_ymd_2;
		}
		public String getArc_trm_et_ymd_2() {
			return arc_trm_et_ymd_2;
		}
		public void setArc_trm_et_ymd_2(String arc_trm_et_ymd_2) {
			this.arc_trm_et_ymd_2 = arc_trm_et_ymd_2;
		}
		public String getExp_rprm_sp_cd() {
			return exp_rprm_sp_cd;
		}
		public void setExp_rprm_sp_cd(String exp_rprm_sp_cd) {
			this.exp_rprm_sp_cd = exp_rprm_sp_cd;
		}
		public String getFs_arc_trm_pd_dt() {
			return fs_arc_trm_pd_dt;
		}
		public void setFs_arc_trm_pd_dt(String fs_arc_trm_pd_dt) {
			this.fs_arc_trm_pd_dt = fs_arc_trm_pd_dt;
		}
		public String getFs_arc_trm_et_dt() {
			return fs_arc_trm_et_dt;
		}
		public void setFs_arc_trm_et_dt(String fs_arc_trm_et_dt) {
			this.fs_arc_trm_et_dt = fs_arc_trm_et_dt;
		}
		public String getFs_arc_trm_ycnt() {
			return fs_arc_trm_ycnt;
		}
		public void setFs_arc_trm_ycnt(String fs_arc_trm_ycnt) {
			this.fs_arc_trm_ycnt = fs_arc_trm_ycnt;
		}
		public String getFs_tty_trm_nm() {
			return fs_tty_trm_nm;
		}
		public void setFs_tty_trm_nm(String fs_tty_trm_nm) {
			this.fs_tty_trm_nm = fs_tty_trm_nm;
		}
		public String getScd_arc_trm_pd_dt() {
			return scd_arc_trm_pd_dt;
		}
		public void setScd_arc_trm_pd_dt(String scd_arc_trm_pd_dt) {
			this.scd_arc_trm_pd_dt = scd_arc_trm_pd_dt;
		}
		public String getScd_arc_trm_et_dt() {
			return scd_arc_trm_et_dt;
		}
		public void setScd_arc_trm_et_dt(String scd_arc_trm_et_dt) {
			this.scd_arc_trm_et_dt = scd_arc_trm_et_dt;
		}
		public String getScd_arc_trm_ycnt() {
			return scd_arc_trm_ycnt;
		}
		public void setScd_arc_trm_ycnt(String scd_arc_trm_ycnt) {
			this.scd_arc_trm_ycnt = scd_arc_trm_ycnt;
		}
		public String getScd_tty_trm_nm() {
			return scd_tty_trm_nm;
		}
		public void setScd_tty_trm_nm(String scd_tty_trm_nm) {
			this.scd_tty_trm_nm = scd_tty_trm_nm;
		}
		public String getPnn_bgn_ag_hngl_nm() {
			return pnn_bgn_ag_hngl_nm;
		}
		public void setPnn_bgn_ag_hngl_nm(String pnn_bgn_ag_hngl_nm) {
			this.pnn_bgn_ag_hngl_nm = pnn_bgn_ag_hngl_nm;
		}
		public String getPnn_pyn_mtd_hngl_nm() {
			return pnn_pyn_mtd_hngl_nm;
		}
		public void setPnn_pyn_mtd_hngl_nm(String pnn_pyn_mtd_hngl_nm) {
			this.pnn_pyn_mtd_hngl_nm = pnn_pyn_mtd_hngl_nm;
		}
		public String getPnn_pyn_trm_hngl_nm() {
			return pnn_pyn_trm_hngl_nm;
		}
		public void setPnn_pyn_trm_hngl_nm(String pnn_pyn_trm_hngl_nm) {
			this.pnn_pyn_trm_hngl_nm = pnn_pyn_trm_hngl_nm;
		}
		public String getPnn_pyn_shp_hngl_nm() {
			return pnn_pyn_shp_hngl_nm;
		}
		public void setPnn_pyn_shp_hngl_nm(String pnn_pyn_shp_hngl_nm) {
			this.pnn_pyn_shp_hngl_nm = pnn_pyn_shp_hngl_nm;
		}
		public String getGrn_lice_yn_hngl_nm() {
			return grn_lice_yn_hngl_nm;
		}
		public void setGrn_lice_yn_hngl_nm(String grn_lice_yn_hngl_nm) {
			this.grn_lice_yn_hngl_nm = grn_lice_yn_hngl_nm;
		}
		public String getPlno_2() {
			return plno_2;
		}
		public void setPlno_2(String plno_2) {
			this.plno_2 = plno_2;
		}
		public String getPdc_nm_2() {
			return pdc_nm_2;
		}
		public void setPdc_nm_2(String pdc_nm_2) {
			this.pdc_nm_2 = pdc_nm_2;
		}
		public String getSpcf_prtn_ncvr_nm_1() {
			return spcf_prtn_ncvr_nm_1;
		}
		public void setSpcf_prtn_ncvr_nm_1(String spcf_prtn_ncvr_nm_1) {
			this.spcf_prtn_ncvr_nm_1 = spcf_prtn_ncvr_nm_1;
		}
		public String getSpcf_prtn_ncvr_nm_2() {
			return spcf_prtn_ncvr_nm_2;
		}
		public void setSpcf_prtn_ncvr_nm_2(String spcf_prtn_ncvr_nm_2) {
			this.spcf_prtn_ncvr_nm_2 = spcf_prtn_ncvr_nm_2;
		}
		public String getSpcf_prtn_ncvr_nm_3() {
			return spcf_prtn_ncvr_nm_3;
		}
		public void setSpcf_prtn_ncvr_nm_3(String spcf_prtn_ncvr_nm_3) {
			this.spcf_prtn_ncvr_nm_3 = spcf_prtn_ncvr_nm_3;
		}
		public String getSpcf_prtn_ncvr_nm_4() {
			return spcf_prtn_ncvr_nm_4;
		}
		public void setSpcf_prtn_ncvr_nm_4(String spcf_prtn_ncvr_nm_4) {
			this.spcf_prtn_ncvr_nm_4 = spcf_prtn_ncvr_nm_4;
		}
		public String getSpcf_prtn_ncvr_trm_1() {
			return spcf_prtn_ncvr_trm_1;
		}
		public void setSpcf_prtn_ncvr_trm_1(String spcf_prtn_ncvr_trm_1) {
			this.spcf_prtn_ncvr_trm_1 = spcf_prtn_ncvr_trm_1;
		}
		public String getSpcf_prtn_ncvr_trm_2() {
			return spcf_prtn_ncvr_trm_2;
		}
		public void setSpcf_prtn_ncvr_trm_2(String spcf_prtn_ncvr_trm_2) {
			this.spcf_prtn_ncvr_trm_2 = spcf_prtn_ncvr_trm_2;
		}
		public String getSpcf_prtn_ncvr_trm_3() {
			return spcf_prtn_ncvr_trm_3;
		}
		public void setSpcf_prtn_ncvr_trm_3(String spcf_prtn_ncvr_trm_3) {
			this.spcf_prtn_ncvr_trm_3 = spcf_prtn_ncvr_trm_3;
		}
		public String getSpcf_prtn_ncvr_trm_4() {
			return spcf_prtn_ncvr_trm_4;
		}
		public void setSpcf_prtn_ncvr_trm_4(String spcf_prtn_ncvr_trm_4) {
			this.spcf_prtn_ncvr_trm_4 = spcf_prtn_ncvr_trm_4;
		}
		public String getPrm_xtr_gr_hngl_nm() {
			return prm_xtr_gr_hngl_nm;
		}
		public void setPrm_xtr_gr_hngl_nm(String prm_xtr_gr_hngl_nm) {
			this.prm_xtr_gr_hngl_nm = prm_xtr_gr_hngl_nm;
		}
		public String getPrm_ctbk_trm_hngl_nm() {
			return prm_ctbk_trm_hngl_nm;
		}
		public void setPrm_ctbk_trm_hngl_nm(String prm_ctbk_trm_hngl_nm) {
			this.prm_ctbk_trm_hngl_nm = prm_ctbk_trm_hngl_nm;
		}
		public String getXtr_prm() {
			return xtr_prm;
		}
		public void setXtr_prm(String xtr_prm) {
			this.xtr_prm = xtr_prm;
		}
		public String getIns_oprt_vh_nm() {
			return ins_oprt_vh_nm;
		}
		public void setIns_oprt_vh_nm(String ins_oprt_vh_nm) {
			this.ins_oprt_vh_nm = ins_oprt_vh_nm;
		}
		public String getApti_ipt_aply_yn_hngl_nm() {
			return apti_ipt_aply_yn_hngl_nm;
		}
		public void setApti_ipt_aply_yn_hngl_nm(String apti_ipt_aply_yn_hngl_nm) {
			this.apti_ipt_aply_yn_hngl_nm = apti_ipt_aply_yn_hngl_nm;
		}
		public String getCmy_no() {
			return cmy_no;
		}
		public void setCmy_no(String cmy_no) {
			this.cmy_no = cmy_no;
		}
		public String getCmy_nm() {
			return cmy_nm;
		}
		public void setCmy_nm(String cmy_nm) {
			this.cmy_nm = cmy_nm;
		}
		public String getAccu_irt_hngl_nm() {
			return accu_irt_hngl_nm;
		}
		public void setAccu_irt_hngl_nm(String accu_irt_hngl_nm) {
			this.accu_irt_hngl_nm = accu_irt_hngl_nm;
		}
		public String getInte_pyn_mtd_hngl_nm() {
			return inte_pyn_mtd_hngl_nm;
		}
		public void setInte_pyn_mtd_hngl_nm(String inte_pyn_mtd_hngl_nm) {
			this.inte_pyn_mtd_hngl_nm = inte_pyn_mtd_hngl_nm;
		}
		public String[] getCvr_eny_if_cvr_hngl_nm() {
			return cvr_eny_if_cvr_hngl_nm;
		}
		public void setCvr_eny_if_cvr_hngl_nm(String[] cvr_eny_if_cvr_hngl_nm) {
			this.cvr_eny_if_cvr_hngl_nm = cvr_eny_if_cvr_hngl_nm;
		}
		public String[] getCvr_eny_if_cvr_inam() {
			return cvr_eny_if_cvr_inam;
		}
		public void setCvr_eny_if_cvr_inam(String[] cvr_eny_if_cvr_inam) {
			this.cvr_eny_if_cvr_inam = cvr_eny_if_cvr_inam;
		}
		public String[] getCvr_eny_if_cvr_bsc_prm() {
			return cvr_eny_if_cvr_bsc_prm;
		}
		public void setCvr_eny_if_cvr_bsc_prm(String[] cvr_eny_if_cvr_bsc_prm) {
			this.cvr_eny_if_cvr_bsc_prm = cvr_eny_if_cvr_bsc_prm;
		}
		public String[] getCvr_eny_if_cvr_cd() {
			return cvr_eny_if_cvr_cd;
		}
		public void setCvr_eny_if_cvr_cd(String[] cvr_eny_if_cvr_cd) {
			this.cvr_eny_if_cvr_cd = cvr_eny_if_cvr_cd;
		}
		public String[] getCvr_eny_if_on_altm() {
			return cvr_eny_if_on_altm;
		}
		public void setCvr_eny_if_on_altm(String[] cvr_eny_if_on_altm) {
			this.cvr_eny_if_on_altm = cvr_eny_if_on_altm;
		}
		public String[] getCvr_eny_if_rnw_cvr_yn() {
			return cvr_eny_if_rnw_cvr_yn;
		}
		public void setCvr_eny_if_rnw_cvr_yn(String[] cvr_eny_if_rnw_cvr_yn) {
			this.cvr_eny_if_rnw_cvr_yn = cvr_eny_if_rnw_cvr_yn;
		}
		public String[] getCvr_eny_if_spc_cdnl_hngl_nm() {
			return cvr_eny_if_spc_cdnl_hngl_nm;
		}
		public void setCvr_eny_if_spc_cdnl_hngl_nm(String[] cvr_eny_if_spc_cdnl_hngl_nm) {
			this.cvr_eny_if_spc_cdnl_hngl_nm = cvr_eny_if_spc_cdnl_hngl_nm;
		}
		public String getFmy_cvr_yn() {
			return fmy_cvr_yn;
		}
		public void setFmy_cvr_yn(String fmy_cvr_yn) {
			this.fmy_cvr_yn = fmy_cvr_yn;
		}
		public String getFmy_prm_sm() {
			return fmy_prm_sm;
		}
		public void setFmy_prm_sm(String fmy_prm_sm) {
			this.fmy_prm_sm = fmy_prm_sm;
		}
		public String getAsr_prm() {
			return asr_prm;
		}
		public void setAsr_prm(String asr_prm) {
			this.asr_prm = asr_prm;
		}
		public String getAccu_prm() {
			return accu_prm;
		}
		public void setAccu_prm(String accu_prm) {
			this.accu_prm = accu_prm;
		}
		public String getPrt_spr_accu_prm() {
			return prt_spr_accu_prm;
		}
		public void setPrt_spr_accu_prm(String prt_spr_accu_prm) {
			this.prt_spr_accu_prm = prt_spr_accu_prm;
		}
		public String getSm_prm() {
			return sm_prm;
		}
		public void setSm_prm(String sm_prm) {
			this.sm_prm = sm_prm;
		}
		public String getPym_epct_prm() {
			return pym_epct_prm;
		}
		public void setPym_epct_prm(String pym_epct_prm) {
			this.pym_epct_prm = pym_epct_prm;
		}
		public String getPpry_prm() {
			return ppry_prm;
		}
		public void setPpry_prm(String ppry_prm) {
			this.ppry_prm = ppry_prm;
		}
		public String getLtm_trt() {
			return ltm_trt;
		}
		public void setLtm_trt(String ltm_trt) {
			this.ltm_trt = ltm_trt;
		}
		public String getPly_rcpl_dvcd() {
			return ply_rcpl_dvcd;
		}
		public void setPly_rcpl_dvcd(String ply_rcpl_dvcd) {
			this.ply_rcpl_dvcd = ply_rcpl_dvcd;
		}
		public String getPly_rcpl_hngl_nm() {
			return ply_rcpl_hngl_nm;
		}
		public void setPly_rcpl_hngl_nm(String ply_rcpl_hngl_nm) {
			this.ply_rcpl_hngl_nm = ply_rcpl_hngl_nm;
		}
		public String getPnn_dfmt_trm_hngl_nm() {
			return pnn_dfmt_trm_hngl_nm;
		}
		public void setPnn_dfmt_trm_hngl_nm(String pnn_dfmt_trm_hngl_nm) {
			this.pnn_dfmt_trm_hngl_nm = pnn_dfmt_trm_hngl_nm;
		}
		public String[] getPym_if_pym_sqno() {
			return pym_if_pym_sqno;
		}
		public void setPym_if_pym_sqno(String[] pym_if_pym_sqno) {
			this.pym_if_pym_sqno = pym_if_pym_sqno;
		}
		public String[] getPym_if_pym_tgt_yy() {
			return pym_if_pym_tgt_yy;
		}
		public void setPym_if_pym_tgt_yy(String[] pym_if_pym_tgt_yy) {
			this.pym_if_pym_tgt_yy = pym_if_pym_tgt_yy;
		}
		public String[] getPym_if_pym_amt() {
			return pym_if_pym_amt;
		}
		public void setPym_if_pym_amt(String[] pym_if_pym_amt) {
			this.pym_if_pym_amt = pym_if_pym_amt;
		}
		public String[] getPym_if_pym_crtf_isu_amt() {
			return pym_if_pym_crtf_isu_amt;
		}
		public void setPym_if_pym_crtf_isu_amt(String[] pym_if_pym_crtf_isu_amt) {
			this.pym_if_pym_crtf_isu_amt = pym_if_pym_crtf_isu_amt;
		}
		public String getPrvs_pnn_pym_cmtt_amt() {
			return prvs_pnn_pym_cmtt_amt;
		}
		public void setPrvs_pnn_pym_cmtt_amt(String prvs_pnn_pym_cmtt_amt) {
			this.prvs_pnn_pym_cmtt_amt = prvs_pnn_pym_cmtt_amt;
		}
		public String getPrvs_pnn_txn_tgt_mpf() {
			return prvs_pnn_txn_tgt_mpf;
		}
		public void setPrvs_pnn_txn_tgt_mpf(String prvs_pnn_txn_tgt_mpf) {
			this.prvs_pnn_txn_tgt_mpf = prvs_pnn_txn_tgt_mpf;
		}
		public String getSos_vh_ownr_nm() {
			return sos_vh_ownr_nm;
		}
		public void setSos_vh_ownr_nm(String sos_vh_ownr_nm) {
			this.sos_vh_ownr_nm = sos_vh_ownr_nm;
		}
		public String getVh_no_hngl_nm() {
			return vh_no_hngl_nm;
		}
		public void setVh_no_hngl_nm(String vh_no_hngl_nm) {
			this.vh_no_hngl_nm = vh_no_hngl_nm;
		}
		public String getVh_ipt_epct_dt() {
			return vh_ipt_epct_dt;
		}
		public void setVh_ipt_epct_dt(String vh_ipt_epct_dt) {
			this.vh_ipt_epct_dt = vh_ipt_epct_dt;
		}
		public String getChd_dipp_cvr_eny_psct() {
			return chd_dipp_cvr_eny_psct;
		}
		public void setChd_dipp_cvr_eny_psct(String chd_dipp_cvr_eny_psct) {
			this.chd_dipp_cvr_eny_psct = chd_dipp_cvr_eny_psct;
		}
		public String getFmy_cnt() {
			return fmy_cnt;
		}
		public void setFmy_cnt(String fmy_cnt) {
			this.fmy_cnt = fmy_cnt;
		}
		public String getChd_cnt() {
			return chd_cnt;
		}
		public void setChd_cnt(String chd_cnt) {
			this.chd_cnt = chd_cnt;
		}
		public String getChd_nme() {
			return chd_nme;
		}
		public void setChd_nme(String chd_nme) {
			this.chd_nme = chd_nme;
		}
		public String getChd_rrno() {
			return chd_rrno;
		}
		public void setChd_rrno(String chd_rrno) {
			this.chd_rrno = chd_rrno;
		}
		public String getChd_dipp_bsc_prm() {
			return chd_dipp_bsc_prm;
		}
		public void setChd_dipp_bsc_prm(String chd_dipp_bsc_prm) {
			this.chd_dipp_bsc_prm = chd_dipp_bsc_prm;
		}
		public String getTrvl_trm_str_dt() {
			return trvl_trm_str_dt;
		}
		public void setTrvl_trm_str_dt(String trvl_trm_str_dt) {
			this.trvl_trm_str_dt = trvl_trm_str_dt;
		}
		public String getTrvl_trm_fin_dt() {
			return trvl_trm_fin_dt;
		}
		public void setTrvl_trm_fin_dt(String trvl_trm_fin_dt) {
			this.trvl_trm_fin_dt = trvl_trm_fin_dt;
		}
		public String getTrvl_trm_dvcd_hngl_nm() {
			return trvl_trm_dvcd_hngl_nm;
		}
		public void setTrvl_trm_dvcd_hngl_nm(String trvl_trm_dvcd_hngl_nm) {
			this.trvl_trm_dvcd_hngl_nm = trvl_trm_dvcd_hngl_nm;
		}
		public String getSpos_nm() {
			return spos_nm;
		}
		public void setSpos_nm(String spos_nm) {
			this.spos_nm = spos_nm;
		}
		public String getSpos_brth() {
			return spos_brth;
		}
		public void setSpos_brth(String spos_brth) {
			this.spos_brth = spos_brth;
		}
		public String getMsv_trm_mcnt() {
			return msv_trm_mcnt;
		}
		public void setMsv_trm_mcnt(String msv_trm_mcnt) {
			this.msv_trm_mcnt = msv_trm_mcnt;
		}
		public String getOwnr_nm() {
			return ownr_nm;
		}
		public void setOwnr_nm(String ownr_nm) {
			this.ownr_nm = ownr_nm;
		}
		public String getOwnr_rrno() {
			return ownr_rrno;
		}
		public void setOwnr_rrno(String ownr_rrno) {
			this.ownr_rrno = ownr_rrno;
		}
		public String getLcpl_psno() {
			return lcpl_psno;
		}
		public void setLcpl_psno(String lcpl_psno) {
			this.lcpl_psno = lcpl_psno;
		}
		public String getLcpl_adr() {
			return lcpl_adr;
		}
		public void setLcpl_adr(String lcpl_adr) {
			this.lcpl_adr = lcpl_adr;
		}
		public String getLcpl_eta_adr() {
			return lcpl_eta_adr;
		}
		public void setLcpl_eta_adr(String lcpl_eta_adr) {
			this.lcpl_eta_adr = lcpl_eta_adr;
		}
		public String getLcpl_nwod_adr_dvcd() {
			return lcpl_nwod_adr_dvcd;
		}
		public void setLcpl_nwod_adr_dvcd(String lcpl_nwod_adr_dvcd) {
			this.lcpl_nwod_adr_dvcd = lcpl_nwod_adr_dvcd;
		}
		public String getCrrn_bstp_cd() {
			return crrn_bstp_cd;
		}
		public void setCrrn_bstp_cd(String crrn_bstp_cd) {
			this.crrn_bstp_cd = crrn_bstp_cd;
		}
		public String getApcn_bstp_cd() {
			return apcn_bstp_cd;
		}
		public void setApcn_bstp_cd(String apcn_bstp_cd) {
			this.apcn_bstp_cd = apcn_bstp_cd;
		}
		public String getBd_stru_rtg_cd() {
			return bd_stru_rtg_cd;
		}
		public void setBd_stru_rtg_cd(String bd_stru_rtg_cd) {
			this.bd_stru_rtg_cd = bd_stru_rtg_cd;
		}
		public String[] getOjt_if_ojt_cd() {
			return ojt_if_ojt_cd;
		}
		public void setOjt_if_ojt_cd(String[] ojt_if_ojt_cd) {
			this.ojt_if_ojt_cd = ojt_if_ojt_cd;
		}
		public String[] getOjt_if_ojt_rtg_cd() {
			return ojt_if_ojt_rtg_cd;
		}
		public void setOjt_if_ojt_rtg_cd(String[] ojt_if_ojt_rtg_cd) {
			this.ojt_if_ojt_rtg_cd = ojt_if_ojt_rtg_cd;
		}
		public String[] getOjt_if_ojt_bd_sqar() {
			return ojt_if_ojt_bd_sqar;
		}
		public void setOjt_if_ojt_bd_sqar(String[] ojt_if_ojt_bd_sqar) {
			this.ojt_if_ojt_bd_sqar = ojt_if_ojt_bd_sqar;
		}
		public String[] getOjt_if_ojt_inam() {
			return ojt_if_ojt_inam;
		}
		public void setOjt_if_ojt_inam(String[] ojt_if_ojt_inam) {
			this.ojt_if_ojt_inam = ojt_if_ojt_inam;
		}
		public String[] getOjt_if_ojt_bsc_prm() {
			return ojt_if_ojt_bsc_prm;
		}
		public void setOjt_if_ojt_bsc_prm(String[] ojt_if_ojt_bsc_prm) {
			this.ojt_if_ojt_bsc_prm = ojt_if_ojt_bsc_prm;
		}
		public String[] getOjt_if_ojt_stru_cn_nm() {
			return ojt_if_ojt_stru_cn_nm;
		}
		public void setOjt_if_ojt_stru_cn_nm(String[] ojt_if_ojt_stru_cn_nm) {
			this.ojt_if_ojt_stru_cn_nm = ojt_if_ojt_stru_cn_nm;
		}
		public String getAcdt_plc_mn1() {
			return acdt_plc_mn1;
		}
		public void setAcdt_plc_mn1(String acdt_plc_mn1) {
			this.acdt_plc_mn1 = acdt_plc_mn1;
		}
		public String getFclt_ownr_lbt_eny_yn() {
			return fclt_ownr_lbt_eny_yn;
		}
		public void setFclt_ownr_lbt_eny_yn(String fclt_ownr_lbt_eny_yn) {
			this.fclt_ownr_lbt_eny_yn = fclt_ownr_lbt_eny_yn;
		}
		public String getFclt_ownr_lbt_inam_1() {
			return fclt_ownr_lbt_inam_1;
		}
		public void setFclt_ownr_lbt_inam_1(String fclt_ownr_lbt_inam_1) {
			this.fclt_ownr_lbt_inam_1 = fclt_ownr_lbt_inam_1;
		}
		public String getFclt_ownr_lbt_inam_2() {
			return fclt_ownr_lbt_inam_2;
		}
		public void setFclt_ownr_lbt_inam_2(String fclt_ownr_lbt_inam_2) {
			this.fclt_ownr_lbt_inam_2 = fclt_ownr_lbt_inam_2;
		}
		public String getFclt_ownr_lbt_bstp() {
			return fclt_ownr_lbt_bstp;
		}
		public void setFclt_ownr_lbt_bstp(String fclt_ownr_lbt_bstp) {
			this.fclt_ownr_lbt_bstp = fclt_ownr_lbt_bstp;
		}
		public String getFclt_ownr_lbt_fclt_scl() {
			return fclt_ownr_lbt_fclt_scl;
		}
		public void setFclt_ownr_lbt_fclt_scl(String fclt_ownr_lbt_fclt_scl) {
			this.fclt_ownr_lbt_fclt_scl = fclt_ownr_lbt_fclt_scl;
		}
		public String getFclt_ownr_lbt_fclt_sqar() {
			return fclt_ownr_lbt_fclt_sqar;
		}
		public void setFclt_ownr_lbt_fclt_sqar(String fclt_ownr_lbt_fclt_sqar) {
			this.fclt_ownr_lbt_fclt_sqar = fclt_ownr_lbt_fclt_sqar;
		}
		public String getFclt_ownr_lbt_eny_typ() {
			return fclt_ownr_lbt_eny_typ;
		}
		public void setFclt_ownr_lbt_eny_typ(String fclt_ownr_lbt_eny_typ) {
			this.fclt_ownr_lbt_eny_typ = fclt_ownr_lbt_eny_typ;
		}
		public String getFclt_ownr_lbt_on_chrg_dvn() {
			return fclt_ownr_lbt_on_chrg_dvn;
		}
		public void setFclt_ownr_lbt_on_chrg_dvn(String fclt_ownr_lbt_on_chrg_dvn) {
			this.fclt_ownr_lbt_on_chrg_dvn = fclt_ownr_lbt_on_chrg_dvn;
		}
		public String getFood_lbt_eny_yn() {
			return food_lbt_eny_yn;
		}
		public void setFood_lbt_eny_yn(String food_lbt_eny_yn) {
			this.food_lbt_eny_yn = food_lbt_eny_yn;
		}
		public String getFood_lbt_inam_1() {
			return food_lbt_inam_1;
		}
		public void setFood_lbt_inam_1(String food_lbt_inam_1) {
			this.food_lbt_inam_1 = food_lbt_inam_1;
		}
		public String getFood_lbt_inam_2() {
			return food_lbt_inam_2;
		}
		public void setFood_lbt_inam_2(String food_lbt_inam_2) {
			this.food_lbt_inam_2 = food_lbt_inam_2;
		}
		public String getFood_lbt_bstp() {
			return food_lbt_bstp;
		}
		public void setFood_lbt_bstp(String food_lbt_bstp) {
			this.food_lbt_bstp = food_lbt_bstp;
		}
		public String getFood_lbt_bstp_hngl_nm() {
			return food_lbt_bstp_hngl_nm;
		}
		public void setFood_lbt_bstp_hngl_nm(String food_lbt_bstp_hngl_nm) {
			this.food_lbt_bstp_hngl_nm = food_lbt_bstp_hngl_nm;
		}
		public String getFood_lbt_rvnu_aot() {
			return food_lbt_rvnu_aot;
		}
		public void setFood_lbt_rvnu_aot(String food_lbt_rvnu_aot) {
			this.food_lbt_rvnu_aot = food_lbt_rvnu_aot;
		}
		public String getBdy_dag_lbt_eny_yn() {
			return bdy_dag_lbt_eny_yn;
		}
		public void setBdy_dag_lbt_eny_yn(String bdy_dag_lbt_eny_yn) {
			this.bdy_dag_lbt_eny_yn = bdy_dag_lbt_eny_yn;
		}
		public String getBdy_dag_lbt_inam() {
			return bdy_dag_lbt_inam;
		}
		public void setBdy_dag_lbt_inam(String bdy_dag_lbt_inam) {
			this.bdy_dag_lbt_inam = bdy_dag_lbt_inam;
		}
		public String getBdy_dag_lbt_dst_rt_cd() {
			return bdy_dag_lbt_dst_rt_cd;
		}
		public void setBdy_dag_lbt_dst_rt_cd(String bdy_dag_lbt_dst_rt_cd) {
			this.bdy_dag_lbt_dst_rt_cd = bdy_dag_lbt_dst_rt_cd;
		}
		public String getBdy_dag_lbt_dst_rt_hngl_nm() {
			return bdy_dag_lbt_dst_rt_hngl_nm;
		}
		public void setBdy_dag_lbt_dst_rt_hngl_nm(String bdy_dag_lbt_dst_rt_hngl_nm) {
			this.bdy_dag_lbt_dst_rt_hngl_nm = bdy_dag_lbt_dst_rt_hngl_nm;
		}
		public String getBdy_dag_lbt_bstp() {
			return bdy_dag_lbt_bstp;
		}
		public void setBdy_dag_lbt_bstp(String bdy_dag_lbt_bstp) {
			this.bdy_dag_lbt_bstp = bdy_dag_lbt_bstp;
		}
		public String getBdy_dag_lbt_bstp_hngl_nm() {
			return bdy_dag_lbt_bstp_hngl_nm;
		}
		public void setBdy_dag_lbt_bstp_hngl_nm(String bdy_dag_lbt_bstp_hngl_nm) {
			this.bdy_dag_lbt_bstp_hngl_nm = bdy_dag_lbt_bstp_hngl_nm;
		}
		public String getNot_spl_bd_gomc_re_dag_eny_yn() {
			return not_spl_bd_gomc_re_dag_eny_yn;
		}
		public void setNot_spl_bd_gomc_re_dag_eny_yn(
				String not_spl_bd_gomc_re_dag_eny_yn) {
			this.not_spl_bd_gomc_re_dag_eny_yn = not_spl_bd_gomc_re_dag_eny_yn;
		}
		public String getNot_spl_bd_gomc_re_dag_undg_yn() {
			return not_spl_bd_gomc_re_dag_undg_yn;
		}
		public void setNot_spl_bd_gomc_re_dag_undg_yn(
				String not_spl_bd_gomc_re_dag_undg_yn) {
			this.not_spl_bd_gomc_re_dag_undg_yn = not_spl_bd_gomc_re_dag_undg_yn;
		}
		public String getChd_edu_fd_det_ag() {
			return chd_edu_fd_det_ag;
		}
		public void setChd_edu_fd_det_ag(String chd_edu_fd_det_ag) {
			this.chd_edu_fd_det_ag = chd_edu_fd_det_ag;
		}
		public String getChd_edu_fd_det_nme() {
			return chd_edu_fd_det_nme;
		}
		public void setChd_edu_fd_det_nme(String chd_edu_fd_det_nme) {
			this.chd_edu_fd_det_nme = chd_edu_fd_det_nme;
		}
		public String getChd_edu_fd_det_rsdn_no() {
			return chd_edu_fd_det_rsdn_no;
		}
		public void setChd_edu_fd_det_rsdn_no(String chd_edu_fd_det_rsdn_no) {
			this.chd_edu_fd_det_rsdn_no = chd_edu_fd_det_rsdn_no;
		}
		public String getMvgn_pnn_pvs_eny_ognm() {
			return mvgn_pnn_pvs_eny_ognm;
		}
		public void setMvgn_pnn_pvs_eny_ognm(String mvgn_pnn_pvs_eny_ognm) {
			this.mvgn_pnn_pvs_eny_ognm = mvgn_pnn_pvs_eny_ognm;
		}
		public String getMvgn_pnn_frst_eny_dt() {
			return mvgn_pnn_frst_eny_dt;
		}
		public void setMvgn_pnn_frst_eny_dt(String mvgn_pnn_frst_eny_dt) {
			this.mvgn_pnn_frst_eny_dt = mvgn_pnn_frst_eny_dt;
		}
		public String getMvgn_pnn_prvs_prm() {
			return mvgn_pnn_prvs_prm;
		}
		public void setMvgn_pnn_prvs_prm(String mvgn_pnn_prvs_prm) {
			this.mvgn_pnn_prvs_prm = mvgn_pnn_prvs_prm;
		}
		public String getCtc_id() {
			return ctc_id;
		}
		public void setCtc_id(String ctc_id) {
			this.ctc_id = ctc_id;
		}
		public String getIns_cust_no() {
			return ins_cust_no;
		}
		public void setIns_cust_no(String ins_cust_no) {
			this.ins_cust_no = ins_cust_no;
		}
		
		
}
