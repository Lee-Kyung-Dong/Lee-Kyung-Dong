package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class MMTI0044VO extends CMMVO {

	public String plno = "";					// 증번
	public String ins_nme = "";					// 피보험자성명
	public String ins_cryg_tlno_2 = "";			// 피보험자휴대전화번호2
	public String ins_cd = "";					// 피보험자주민번호(암호)
	public String plhd_nme = "";				// 계약자성명
	public String plhd_tlno_2 = "";				// 계약자전화번호2
	public String plhd_cd = "";					// 계약자주민번호(암호)
	public String getPlno() {
		return plno;
	}
	public void setPlno(String plno) {
		this.plno = plno;
	}
	public String getIns_nme() {
		return ins_nme;
	}
	public void setIns_nme(String ins_nme) {
		this.ins_nme = ins_nme;
	}
	public String getIns_cryg_tlno_2() {
		return ins_cryg_tlno_2;
	}
	public void setIns_cryg_tlno_2(String ins_cryg_tlno_2) {
		this.ins_cryg_tlno_2 = ins_cryg_tlno_2;
	}
	public String getIns_cd() {
		return ins_cd;
	}
	public void setIns_cd(String ins_cd) {
		this.ins_cd = ins_cd;
	}
	public String getPlhd_nme() {
		return plhd_nme;
	}
	public void setPlhd_nme(String plhd_nme) {
		this.plhd_nme = plhd_nme;
	}
	public String getPlhd_tlno_2() {
		return plhd_tlno_2;
	}
	public void setPlhd_tlno_2(String plhd_tlno_2) {
		this.plhd_tlno_2 = plhd_tlno_2;
	}
	public String getPlhd_cd() {
		return plhd_cd;
	}
	public void setPlhd_cd(String plhd_cd) {
		this.plhd_cd = plhd_cd;
	}

	
	
}
