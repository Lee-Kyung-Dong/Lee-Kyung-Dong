package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class IFMOB011_2VO extends CMMVO {

    public String webM = "IF_MOB_011_2";

    // 입력
    public String I_SSN = null;				        // 주민번호
    public String I_CUST_NM = null;			        // 고객명
    public String I_APY_YMD = null;			        // 평가일자
    public String I_PICD = null;			        // 상품코드
    public String I_COLL_KCD = null;		        // 담보분류	- 고정값 : 20(신용)
    public String I_COLL_ATT_CD = null;		        // 담보세분류 - 고정값 : 21(신용)
    public String I_EVAL_GB = null;			        // CSS평가구분(1:상담조회, 2:심사조회)
    public String I_CRD_AGR_3 = null;               // 필수 금융거래설정 개인정보 수집/이용 동의
    public String I_CRD_AGR_4 = null;               // 필수 금융거래설정 개인정보 제공 동의
    public String I_CRD_AGR_5 = null;               // 필수 상품별 개인정보 수집/이용 동의
    public String I_CRD_AGR_6 = null;               // 선택 금융거래설정 개인정보 수집/이용 동의
    public String I_MKT_AGR_1 = null;               // 상품서비스안내 동의(수집/이용)
    public String I_MKT_AGR_2 = null;               // 상품서비스안내 동의(제공)
    public String I_MKT_MTD_1 = null;               // 상품서비스안내 수단_전체
    public String I_MKT_MTD_2 = null;               // 상품서비스안내 수단_문자메세지
    public String I_MKT_MTD_3 = null;               // 상품서비스안내 수단_이메일
    public String I_MKT_MTD_4 = null;               // 상품서비스안내 수단_전화
    public String I_MKT_MTD_5 = null;               // 상품서비스안내 수단_우편

    // 출력
    public String O_RET_CD = null;			        // 결과코드 - 00:정상 , 10:입력값 누락, 11:입력값 오류, 99:시스템오류
    public String O_RET_MSG = null;			        // 결과메시지
    public String O_LN_ID = null;			        // 대출약정번호
    public String O_DEC_RT = null;			        // 판정결과 - 10:승인, 20:조건부승인, 30:거절(진행중단)
    public String O_DEC_RT_MSG = null;		        // 판정결과메시지
    public String O_LM_GD = null;			        // 한도등급
    public String O_LM = null;				        // 대출가능한도
    public String O_RAT_GD = null;			        // 금리등급
    public String O_RAT = null;				        // 대출가능금리
    public String[] O_LOAN_BCD =  new String[0];    // 지급/이자납입 계좌 은행코드
    public String[] O_LOAN_ACNO = new String[0];    // 지급/이자납입 계좌번호
    
    // 내부변환용
    public String[] bankName = new String[0];		// 은행명
}
