package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class KCUS0034VO extends CMMVO {

	//전문필드
		public String proc_dvn = "";  //[I] 처리구분 SI_GUBUN 구분
		public String cust_dcmt_no = "";  //[I] 고객식별번호 SI_GOGEK_NO 고객번호
		public String cust_hngl_nm = "";  //[I/O] 고객한글명 HO_GOGEK_NM 고객명
		public String hm_adr_psno_cur_adr = "";  //[I/O] 자택주소우편번호현주소 SI_H_ZIP 자택우편번호
		public String hm_adr_pst_road_nm_adr_cur_adr = "";  //[I/O] 자택주소우편도로명주소현주소 HO_H_JUSO 자택주소
		public String hm_adr_eta_adr_cur_adr = "";  //[I/O] 자택주소기타주소현주소 HI_H_ADDR 자택번지
		public String hm_adr_dvn_cur_adr = "";  //[I] 자택주소구분현주소 SO_H_GBN 자택주소구분
		public String wpc_adr_psno_cur_adr = "";  //[I/O] 직장주소우편번호현주소 SI_J_ZIP 직장우편번호
		public String wpc_adr_pst_road_nm_adr_cur_adr = "";  //[I/O] 직장주소우편도로명주소현주소 HO_J_JUSO 직장주소
		public String wpc_adr_eta_adr_cur_adr = "";  //[I/O] 직장주소기타주소현주소 HI_J_ADDR 직장번지
		public String wpc_adr_dvn_cur_adr = "";  //[I] 직장주소구분현주소 SO_J_GBN 직장주소구분
		public String eta_adr_psno_cur_adr = "";  //[I/O] 기타주소우편번호현주소 SI_G_ZIP 기타우편번호
		public String eta_adr_pst_road_nm_adr_cur_adr = "";  //[I/O] 기타주소우편도로명주소현주소 HO_G_JUSO 기타주소
		public String eta_adr_eta_adr_cur_adr = "";  //[I/O] 기타주소기타주소현주소 HI_G_ADDR 기타번지
		public String eta_adr_dvn_cur_adr = "";  //[I] 기타주소구분현주소 SO_G_GBN 기타주소구분
		public String clp_arno = "";  //[I/O] 휴대폰지역번호 SI_HP_TEL1 휴대폰번호
		public String clp_ofno = "";  //[I/O] 휴대폰국번호 SI_HP_TEL2 휴대폰번호
		public String clp_idvno = "";  //[I/O] 휴대폰개별번호 SI_HP_TEL3 휴대폰번호
		public String clp_dvn = "";  //[I] 휴대폰구분 SO_HP_GBN 휴대폰번호구분
		public String hm_tlp_arno = "";  //[I/O] 자택전화지역번호 SI_H_TEL1 자택전화번호
		public String hm_tlp_ofno = "";  //[I/O] 자택전화국번호 SI_H_TEL2 자택전화번호
		public String hm_tlp_idvno = "";  //[I/O] 자택전화개별번호 SI_H_TEL3 자택전화번호
		public String hm_tlp_dvn = "";  //[I] 자택전화구분 SO_HT_GBN 자택전화구분
		public String wpc_tlp_arno = "";  //[I/O] 직장전화지역번호 SI_J_TEL1 직장전화번호
		public String wpc_tlp_ofno = "";  //[I/O] 직장전화국번호 SI_J_TEL2 직장전화번호
		public String wpc_tlp_idvno = "";  //[I/O] 직장전화개별번호 SI_J_TEL3 직장전화번호
		public String wpc_tlp_dvn = "";  //[I] 직장전화구분 SO_JT_GBN 직장전화번호구분
		public String eml_adr = "";  //[I/O] 이메일주소 SI_EMAIL_ID 이메일ID
		public String eml_rc_rejt_yn = "";  //[I/O] 이메일수신거부여부 SI_EMAIL_SUSIN_YN 이메일수신여부
		public String eml_rejt_cnl_dt = "";  //[O] 이메일거부해제일자 SO_EMAIL_SUSIN_YMD 이메일수신일자
		public String istr_eml_alt_aply_yn = "";  //[I/O] 안내문이메일대체신청여부 SI_EMAIL_DM_YN 이메일수신동의
		public String elrn_ml_dvn = "";  //[I] 전자메일구분 SO_E_GBN 전자메일구분
		public String sms_rc_rejt_yn = "";  //[I/O] SMS수신거부여부 SI-SMS-SUSIN-YN    SMS수신여부
		public String hm_adr_psno_nadr = "";  //[I/O] 자택주소우편번호새주소 SI-ST-H-ZIP        핸폰우편번호
		public String hm_adr_pst_road_nm_adr_nadr = "";  //[I/O] 자택주소우편도로명주소새주소 HI-ST-H-ADDR       주소
		public String hm_adr_eta_adr_nadr = "";  //[I/O] 자택주소기타주소새주소 HI-ST-H-GITA       기타번지
		public String hm_adr_dvn_nadr = "";  //[I] 자택주소구분새주소 SO-ST-H-GBN        주소구분
		public String wpc_adr_psno_nadr = "";  //[I/O] 직장주소우편번호새주소 SI-ST-J-ZIP        우편번호
		public String wpc_adr_pst_road_nm_adr_nadr = "";  //[I/O] 직장주소우편도로명주소새주소 HI-ST-J-ADDR       주소
		public String wpc_adr_eta_adr_nadr = "";  //[I/O] 직장주소기타주소새주소 HI-ST-J-GITA       기타주소
		public String wpc_adr_dvn_nadr = "";  //[I] 직장주소구분새주소 SO-ST-J-GBN        주소구분
		public String eta_adr_psno_nadr = "";  //[I/O] 기타주소우편번호새주소 SI-ST-G-ZIP        우편번호
		public String eta_adr_pst_road_nm_adr_nadr = "";  //[I/O] 기타주소우편도로명주소새주소 HI-ST-G-ADDR       주소
		public String eta_adr_eta_adr_nadr = "";  //[I/O] 기타주소기타주소새주소 HI-ST-G-GITA       기타주소
		public String eta_adr_dvn_nadr = "";  //[I] 기타주소구분새주소 SO-ST-G-GBN        주소구분
		
		public String errorCode = "";
		
		
		public String getProc_dvn() {
			return proc_dvn;
		}
		public void setProc_dvn(String proc_dvn) {
			this.proc_dvn = proc_dvn;
		}
		public String getCust_dcmt_no() {
			return cust_dcmt_no;
		}
		public void setCust_dcmt_no(String cust_dcmt_no) {
			this.cust_dcmt_no = cust_dcmt_no;
		}
		public String getCust_hngl_nm() {
			return cust_hngl_nm;
		}
		public void setCust_hngl_nm(String cust_hngl_nm) {
			this.cust_hngl_nm = cust_hngl_nm;
		}
		public String getHm_adr_psno_cur_adr() {
			return hm_adr_psno_cur_adr;
		}
		public void setHm_adr_psno_cur_adr(String hm_adr_psno_cur_adr) {
			this.hm_adr_psno_cur_adr = hm_adr_psno_cur_adr;
		}
		public String getHm_adr_pst_road_nm_adr_cur_adr() {
			return hm_adr_pst_road_nm_adr_cur_adr;
		}
		public void setHm_adr_pst_road_nm_adr_cur_adr(
				String hm_adr_pst_road_nm_adr_cur_adr) {
			this.hm_adr_pst_road_nm_adr_cur_adr = hm_adr_pst_road_nm_adr_cur_adr;
		}
		public String getHm_adr_eta_adr_cur_adr() {
			return hm_adr_eta_adr_cur_adr;
		}
		public void setHm_adr_eta_adr_cur_adr(String hm_adr_eta_adr_cur_adr) {
			this.hm_adr_eta_adr_cur_adr = hm_adr_eta_adr_cur_adr;
		}
		public String getHm_adr_dvn_cur_adr() {
			return hm_adr_dvn_cur_adr;
		}
		public void setHm_adr_dvn_cur_adr(String hm_adr_dvn_cur_adr) {
			this.hm_adr_dvn_cur_adr = hm_adr_dvn_cur_adr;
		}
		public String getWpc_adr_psno_cur_adr() {
			return wpc_adr_psno_cur_adr;
		}
		public void setWpc_adr_psno_cur_adr(String wpc_adr_psno_cur_adr) {
			this.wpc_adr_psno_cur_adr = wpc_adr_psno_cur_adr;
		}
		public String getWpc_adr_pst_road_nm_adr_cur_adr() {
			return wpc_adr_pst_road_nm_adr_cur_adr;
		}
		public void setWpc_adr_pst_road_nm_adr_cur_adr(
				String wpc_adr_pst_road_nm_adr_cur_adr) {
			this.wpc_adr_pst_road_nm_adr_cur_adr = wpc_adr_pst_road_nm_adr_cur_adr;
		}
		public String getWpc_adr_eta_adr_cur_adr() {
			return wpc_adr_eta_adr_cur_adr;
		}
		public void setWpc_adr_eta_adr_cur_adr(String wpc_adr_eta_adr_cur_adr) {
			this.wpc_adr_eta_adr_cur_adr = wpc_adr_eta_adr_cur_adr;
		}
		public String getWpc_adr_dvn_cur_adr() {
			return wpc_adr_dvn_cur_adr;
		}
		public void setWpc_adr_dvn_cur_adr(String wpc_adr_dvn_cur_adr) {
			this.wpc_adr_dvn_cur_adr = wpc_adr_dvn_cur_adr;
		}
		public String getEta_adr_psno_cur_adr() {
			return eta_adr_psno_cur_adr;
		}
		public void setEta_adr_psno_cur_adr(String eta_adr_psno_cur_adr) {
			this.eta_adr_psno_cur_adr = eta_adr_psno_cur_adr;
		}
		public String getEta_adr_pst_road_nm_adr_cur_adr() {
			return eta_adr_pst_road_nm_adr_cur_adr;
		}
		public void setEta_adr_pst_road_nm_adr_cur_adr(
				String eta_adr_pst_road_nm_adr_cur_adr) {
			this.eta_adr_pst_road_nm_adr_cur_adr = eta_adr_pst_road_nm_adr_cur_adr;
		}
		public String getEta_adr_eta_adr_cur_adr() {
			return eta_adr_eta_adr_cur_adr;
		}
		public void setEta_adr_eta_adr_cur_adr(String eta_adr_eta_adr_cur_adr) {
			this.eta_adr_eta_adr_cur_adr = eta_adr_eta_adr_cur_adr;
		}
		public String getEta_adr_dvn_cur_adr() {
			return eta_adr_dvn_cur_adr;
		}
		public void setEta_adr_dvn_cur_adr(String eta_adr_dvn_cur_adr) {
			this.eta_adr_dvn_cur_adr = eta_adr_dvn_cur_adr;
		}
		public String getClp_arno() {
			return clp_arno;
		}
		public void setClp_arno(String clp_arno) {
			this.clp_arno = clp_arno;
		}
		public String getClp_ofno() {
			return clp_ofno;
		}
		public void setClp_ofno(String clp_ofno) {
			this.clp_ofno = clp_ofno;
		}
		public String getClp_idvno() {
			return clp_idvno;
		}
		public void setClp_idvno(String clp_idvno) {
			this.clp_idvno = clp_idvno;
		}
		public String getClp_dvn() {
			return clp_dvn;
		}
		public void setClp_dvn(String clp_dvn) {
			this.clp_dvn = clp_dvn;
		}
		public String getHm_tlp_arno() {
			return hm_tlp_arno;
		}
		public void setHm_tlp_arno(String hm_tlp_arno) {
			this.hm_tlp_arno = hm_tlp_arno;
		}
		public String getHm_tlp_ofno() {
			return hm_tlp_ofno;
		}
		public void setHm_tlp_ofno(String hm_tlp_ofno) {
			this.hm_tlp_ofno = hm_tlp_ofno;
		}
		public String getHm_tlp_idvno() {
			return hm_tlp_idvno;
		}
		public void setHm_tlp_idvno(String hm_tlp_idvno) {
			this.hm_tlp_idvno = hm_tlp_idvno;
		}
		public String getHm_tlp_dvn() {
			return hm_tlp_dvn;
		}
		public void setHm_tlp_dvn(String hm_tlp_dvn) {
			this.hm_tlp_dvn = hm_tlp_dvn;
		}
		public String getWpc_tlp_arno() {
			return wpc_tlp_arno;
		}
		public void setWpc_tlp_arno(String wpc_tlp_arno) {
			this.wpc_tlp_arno = wpc_tlp_arno;
		}
		public String getWpc_tlp_ofno() {
			return wpc_tlp_ofno;
		}
		public void setWpc_tlp_ofno(String wpc_tlp_ofno) {
			this.wpc_tlp_ofno = wpc_tlp_ofno;
		}
		public String getWpc_tlp_idvno() {
			return wpc_tlp_idvno;
		}
		public void setWpc_tlp_idvno(String wpc_tlp_idvno) {
			this.wpc_tlp_idvno = wpc_tlp_idvno;
		}
		public String getWpc_tlp_dvn() {
			return wpc_tlp_dvn;
		}
		public void setWpc_tlp_dvn(String wpc_tlp_dvn) {
			this.wpc_tlp_dvn = wpc_tlp_dvn;
		}
		public String getEml_adr() {
			return eml_adr;
		}
		public void setEml_adr(String eml_adr) {
			this.eml_adr = eml_adr;
		}
		public String getEml_rc_rejt_yn() {
			return eml_rc_rejt_yn;
		}
		public void setEml_rc_rejt_yn(String eml_rc_rejt_yn) {
			this.eml_rc_rejt_yn = eml_rc_rejt_yn;
		}
		public String getEml_rejt_cnl_dt() {
			return eml_rejt_cnl_dt;
		}
		public void setEml_rejt_cnl_dt(String eml_rejt_cnl_dt) {
			this.eml_rejt_cnl_dt = eml_rejt_cnl_dt;
		}
		public String getIstr_eml_alt_aply_yn() {
			return istr_eml_alt_aply_yn;
		}
		public void setIstr_eml_alt_aply_yn(String istr_eml_alt_aply_yn) {
			this.istr_eml_alt_aply_yn = istr_eml_alt_aply_yn;
		}
		public String getElrn_ml_dvn() {
			return elrn_ml_dvn;
		}
		public void setElrn_ml_dvn(String elrn_ml_dvn) {
			this.elrn_ml_dvn = elrn_ml_dvn;
		}
		public String getSms_rc_rejt_yn() {
			return sms_rc_rejt_yn;
		}
		public void setSms_rc_rejt_yn(String sms_rc_rejt_yn) {
			this.sms_rc_rejt_yn = sms_rc_rejt_yn;
		}
		public String getHm_adr_psno_nadr() {
			return hm_adr_psno_nadr;
		}
		public void setHm_adr_psno_nadr(String hm_adr_psno_nadr) {
			this.hm_adr_psno_nadr = hm_adr_psno_nadr;
		}
		public String getHm_adr_pst_road_nm_adr_nadr() {
			return hm_adr_pst_road_nm_adr_nadr;
		}
		public void setHm_adr_pst_road_nm_adr_nadr(String hm_adr_pst_road_nm_adr_nadr) {
			this.hm_adr_pst_road_nm_adr_nadr = hm_adr_pst_road_nm_adr_nadr;
		}
		public String getHm_adr_eta_adr_nadr() {
			return hm_adr_eta_adr_nadr;
		}
		public void setHm_adr_eta_adr_nadr(String hm_adr_eta_adr_nadr) {
			this.hm_adr_eta_adr_nadr = hm_adr_eta_adr_nadr;
		}
		public String getHm_adr_dvn_nadr() {
			return hm_adr_dvn_nadr;
		}
		public void setHm_adr_dvn_nadr(String hm_adr_dvn_nadr) {
			this.hm_adr_dvn_nadr = hm_adr_dvn_nadr;
		}
		public String getWpc_adr_psno_nadr() {
			return wpc_adr_psno_nadr;
		}
		public void setWpc_adr_psno_nadr(String wpc_adr_psno_nadr) {
			this.wpc_adr_psno_nadr = wpc_adr_psno_nadr;
		}
		public String getWpc_adr_pst_road_nm_adr_nadr() {
			return wpc_adr_pst_road_nm_adr_nadr;
		}
		public void setWpc_adr_pst_road_nm_adr_nadr(String wpc_adr_pst_road_nm_adr_nadr) {
			this.wpc_adr_pst_road_nm_adr_nadr = wpc_adr_pst_road_nm_adr_nadr;
		}
		public String getWpc_adr_eta_adr_nadr() {
			return wpc_adr_eta_adr_nadr;
		}
		public void setWpc_adr_eta_adr_nadr(String wpc_adr_eta_adr_nadr) {
			this.wpc_adr_eta_adr_nadr = wpc_adr_eta_adr_nadr;
		}
		public String getWpc_adr_dvn_nadr() {
			return wpc_adr_dvn_nadr;
		}
		public void setWpc_adr_dvn_nadr(String wpc_adr_dvn_nadr) {
			this.wpc_adr_dvn_nadr = wpc_adr_dvn_nadr;
		}
		public String getEta_adr_psno_nadr() {
			return eta_adr_psno_nadr;
		}
		public void setEta_adr_psno_nadr(String eta_adr_psno_nadr) {
			this.eta_adr_psno_nadr = eta_adr_psno_nadr;
		}
		public String getEta_adr_pst_road_nm_adr_nadr() {
			return eta_adr_pst_road_nm_adr_nadr;
		}
		public void setEta_adr_pst_road_nm_adr_nadr(String eta_adr_pst_road_nm_adr_nadr) {
			this.eta_adr_pst_road_nm_adr_nadr = eta_adr_pst_road_nm_adr_nadr;
		}
		public String getEta_adr_eta_adr_nadr() {
			return eta_adr_eta_adr_nadr;
		}
		public void setEta_adr_eta_adr_nadr(String eta_adr_eta_adr_nadr) {
			this.eta_adr_eta_adr_nadr = eta_adr_eta_adr_nadr;
		}
		public String getEta_adr_dvn_nadr() {
			return eta_adr_dvn_nadr;
		}
		public void setEta_adr_dvn_nadr(String eta_adr_dvn_nadr) {
			this.eta_adr_dvn_nadr = eta_adr_dvn_nadr;
		}
}
