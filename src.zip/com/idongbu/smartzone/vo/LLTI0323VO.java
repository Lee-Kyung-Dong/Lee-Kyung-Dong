package com.idongbu.smartzone.vo;

import com.idongbu.common.vo.CMMVO;

public class LLTI0323VO extends CMMVO {

	//전문필드
	public String 	plhd_rsdn_no = ""; 							// [I] 주민번호
	public String[] outp_arrm__plno = new String[0];  			// [O] 증권번호
	public String[] outp_arrm__arc_pd = new String[0];  		// [O] 보험시기일자
	public String[] outp_arrm__arc_et = new String[0];  		// [O] 보험종기일자
	public String[] outp_arrm__plhd_nm = new String[0];  		// [O] 계약자명
	public String[] outp_arrm__pdc_nm = new String[0];  		// [O] 상품명
	public String[] outp_arrm__fnal_pym_mon = new String[0];  	// [O] 최종납입월
	public String[] outp_arrm__coll_ormm = new String[0];  		// [O] 수금조직원 사번
	public String[] outp_arrm__coll_ormm_nm = new String[0];  	// [O] 수금조직원명
	public String[] outp_arrm__ormm_cntp = new String[0];  		// [O] 조직원연착처
	public String	plno_1 = ""; 	 							// [I] 증권번호1
	public String	ins_rsdn_no = "";  							// [I] 피보험자주민번호	
	public String 	ins_nm	= "";  								// [I] 피보험자명
	public String 	rprm = "";  								// [O] 환급금
	public String 	sm_prm = "";  								// [O] 합계보험료	
	public String 	rtrn_adc_dvn   = ""; 						// [O] 환추징구분	
	public String 	bank_cd = "";  					// [I] 은행코드
	public String 	bank_nm = "";  					// [I] 은행명
	public String 	acc_no = "";  						// [I] 계좌번호
	public String 	dpsr_cust_no = ""; 							// [I] 예금주고객번호 
	public String 	dpsr_nm = "";  					// [I] 예금주명	
	public String 	tsfr_dd = "";  					// [I] 이체일
	public String 	ctc_rlt_cd = "";  							// [I] 계약관계코드
	public String 	dpsr_tlno = "";  							// [I] 예금주전화번호	
	public String 	proc_dvn = "";  							// [I] 처리구분  코드 -- 11: 태아보험조회, 12: 고객등록,환급금산출, 13: 확정 
	public String 	plan_no = "";								// [I/O] 설계번호
	
	public String z_resp_msg = "";					//채널헤더의 에러 메세지
	public String errorCode = "";					//비즈헤더의 에러코드
	
	/**
	 * @return the plhd_rsdn_no
	 */
	public String getPlhd_rsdn_no() {
		return plhd_rsdn_no;
	}
	/**
	 * @param plhd_rsdn_no the plhd_rsdn_no to set
	 */
	public void setPlhd_rsdn_no(String plhd_rsdn_no) {
		this.plhd_rsdn_no = plhd_rsdn_no;
	}
	/**
	 * @return the outp_arrm__plno
	 */
	public String[] getOutp_arrm__plno() {
		return outp_arrm__plno;
	}
	/**
	 * @param outp_arrm__plno the outp_arrm__plno to set
	 */
	public void setOutp_arrm__plno(String[] outp_arrm__plno) {
		this.outp_arrm__plno = outp_arrm__plno;
	}
	/**
	 * @return the outp_arrm__arc_pd
	 */
	public String[] getOutp_arrm__arc_pd() {
		return outp_arrm__arc_pd;
	}
	/**
	 * @param outp_arrm__arc_pd the outp_arrm__arc_pd to set
	 */
	public void setOutp_arrm__arc_pd(String[] outp_arrm__arc_pd) {
		this.outp_arrm__arc_pd = outp_arrm__arc_pd;
	}
	/**
	 * @return the outp_arrm__arc_et
	 */
	public String[] getOutp_arrm__arc_et() {
		return outp_arrm__arc_et;
	}
	/**
	 * @param outp_arrm__arc_et the outp_arrm__arc_et to set
	 */
	public void setOutp_arrm__arc_et(String[] outp_arrm__arc_et) {
		this.outp_arrm__arc_et = outp_arrm__arc_et;
	}
	/**
	 * @return the outp_arrm__plhd_nm
	 */
	public String[] getOutp_arrm__plhd_nm() {
		return outp_arrm__plhd_nm;
	}
	/**
	 * @param outp_arrm__plhd_nm the outp_arrm__plhd_nm to set
	 */
	public void setOutp_arrm__plhd_nm(String[] outp_arrm__plhd_nm) {
		this.outp_arrm__plhd_nm = outp_arrm__plhd_nm;
	}
	/**
	 * @return the outp_arrm__pdc_nm
	 */
	public String[] getOutp_arrm__pdc_nm() {
		return outp_arrm__pdc_nm;
	}
	/**
	 * @param outp_arrm__pdc_nm the outp_arrm__pdc_nm to set
	 */
	public void setOutp_arrm__pdc_nm(String[] outp_arrm__pdc_nm) {
		this.outp_arrm__pdc_nm = outp_arrm__pdc_nm;
	}
	/**
	 * @return the outp_arrm__fnal_pym_mon
	 */
	public String[] getOutp_arrm__fnal_pym_mon() {
		return outp_arrm__fnal_pym_mon;
	}
	/**
	 * @param outp_arrm__fnal_pym_mon the outp_arrm__fnal_pym_mon to set
	 */
	public void setOutp_arrm__fnal_pym_mon(String[] outp_arrm__fnal_pym_mon) {
		this.outp_arrm__fnal_pym_mon = outp_arrm__fnal_pym_mon;
	}
	/**
	 * @return the outp_arrm__coll_ormm
	 */
	public String[] getOutp_arrm__coll_ormm() {
		return outp_arrm__coll_ormm;
	}
	/**
	 * @param outp_arrm__coll_ormm the outp_arrm__coll_ormm to set
	 */
	public void setOutp_arrm__coll_ormm(String[] outp_arrm__coll_ormm) {
		this.outp_arrm__coll_ormm = outp_arrm__coll_ormm;
	}
	/**
	 * @return the outp_arrm__coll_ormm_nm
	 */
	public String[] getOutp_arrm__coll_ormm_nm() {
		return outp_arrm__coll_ormm_nm;
	}
	/**
	 * @param outp_arrm__coll_ormm_nm the outp_arrm__coll_ormm_nm to set
	 */
	public void setOutp_arrm__coll_ormm_nm(String[] outp_arrm__coll_ormm_nm) {
		this.outp_arrm__coll_ormm_nm = outp_arrm__coll_ormm_nm;
	}
	/**
	 * @return the outp_arrm__ormm_cntp
	 */
	public String[] getOutp_arrm__ormm_cntp() {
		return outp_arrm__ormm_cntp;
	}
	/**
	 * @param outp_arrm__ormm_cntp the outp_arrm__ormm_cntp to set
	 */
	public void setOutp_arrm__ormm_cntp(String[] outp_arrm__ormm_cntp) {
		this.outp_arrm__ormm_cntp = outp_arrm__ormm_cntp;
	}
	/**
	 * @return the plno_1
	 */
	public String getPlno_1() {
		return plno_1;
	}
	/**
	 * @param plno_1 the plno_1 to set
	 */
	public void setPlno_1(String plno_1) {
		this.plno_1 = plno_1;
	}
	/**
	 * @return the ins_rsdn_no
	 */
	public String getIns_rsdn_no() {
		return ins_rsdn_no;
	}
	/**
	 * @param ins_rsdn_no the ins_rsdn_no to set
	 */
	public void setIns_rsdn_no(String ins_rsdn_no) {
		this.ins_rsdn_no = ins_rsdn_no;
	}
	/**
	 * @return the ins_nm
	 */
	public String getIns_nm() {
		return ins_nm;
	}
	/**
	 * @param ins_nm the ins_nm to set
	 */
	public void setIns_nm(String ins_nm) {
		this.ins_nm = ins_nm;
	}
	/**
	 * @return the rprm
	 */
	public String getRprm() {
		return rprm;
	}
	/**
	 * @param rprm the rprm to set
	 */
	public void setRprm(String rprm) {
		this.rprm = rprm;
	}
	/**
	 * @return the sm_prm
	 */
	public String getSm_prm() {
		return sm_prm;
	}
	/**
	 * @param sm_prm the sm_prm to set
	 */
	public void setSm_prm(String sm_prm) {
		this.sm_prm = sm_prm;
	}
	/**
	 * @return the rtrn_adc_dvn
	 */
	public String getRtrn_adc_dvn() {
		return rtrn_adc_dvn;
	}
	/**
	 * @param rtrn_adc_dvn the rtrn_adc_dvn to set
	 */
	public void setRtrn_adc_dvn(String rtrn_adc_dvn) {
		this.rtrn_adc_dvn = rtrn_adc_dvn;
	}
	/**
	 * @return the bank_cd
	 */
	public String getBank_cd() {
		return bank_cd;
	}
	/**
	 * @param bank_cd the bank_cd to set
	 */
	public void setBank_cd(String bank_cd) {
		this.bank_cd = bank_cd;
	}
	/**
	 * @return the bank_nm
	 */
	public String getBank_nm() {
		return bank_nm;
	}
	/**
	 * @param bank_nm the bank_nm to set
	 */
	public void setBank_nm(String bank_nm) {
		this.bank_nm = bank_nm;
	}
	/**
	 * @return the acc_no
	 */
	public String getAcc_no() {
		return acc_no;
	}
	/**
	 * @param acc_no the acc_no to set
	 */
	public void setAcc_no(String acc_no) {
		this.acc_no = acc_no;
	}
	/**
	 * @return the dpsr_cust_no
	 */
	public String getDpsr_cust_no() {
		return dpsr_cust_no;
	}
	/**
	 * @param dpsr_cust_no the dpsr_cust_no to set
	 */
	public void setDpsr_cust_no(String dpsr_cust_no) {
		this.dpsr_cust_no = dpsr_cust_no;
	}
	/**
	 * @return the dpsr_nm
	 */
	public String getDpsr_nm() {
		return dpsr_nm;
	}
	/**
	 * @param dpsr_nm the dpsr_nm to set
	 */
	public void setDpsr_nm(String dpsr_nm) {
		this.dpsr_nm = dpsr_nm;
	}
	/**
	 * @return the tsfr_dd
	 */
	public String getTsfr_dd() {
		return tsfr_dd;
	}
	/**
	 * @param tsfr_dd the tsfr_dd to set
	 */
	public void setTsfr_dd(String tsfr_dd) {
		this.tsfr_dd = tsfr_dd;
	}
	/**
	 * @return the ctc_rlt_cd
	 */
	public String getCtc_rlt_cd() {
		return ctc_rlt_cd;
	}
	/**
	 * @param ctc_rlt_cd the ctc_rlt_cd to set
	 */
	public void setCtc_rlt_cd(String ctc_rlt_cd) {
		this.ctc_rlt_cd = ctc_rlt_cd;
	}
	/**
	 * @return the dpsr_tlno
	 */
	public String getDpsr_tlno() {
		return dpsr_tlno;
	}
	/**
	 * @param dpsr_tlno the dpsr_tlno to set
	 */
	public void setDpsr_tlno(String dpsr_tlno) {
		this.dpsr_tlno = dpsr_tlno;
	}
	/**
	 * @return the proc_dvn
	 */
	public String getProc_dvn() {
		return proc_dvn;
	}
	/**
	 * @param proc_dvn the proc_dvn to set
	 */
	public void setProc_dvn(String proc_dvn) {
		this.proc_dvn = proc_dvn;
	}
	/**
	 * @return the plan_no
	 */
	public String getPlan_no() {
		return plan_no;
	}
	/**
	 * @param plan_no the plan_no to set
	 */
	public void setPlan_no(String plan_no) {
		this.plan_no = plan_no;
	}
	
	public String getZ_resp_msg() {
		return z_resp_msg;
	}
	public void setZ_resp_msg(String z_resp_msg) {
		this.z_resp_msg = z_resp_msg;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	
}
