package com.idongbu.util;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;

public class NameCheck {
	private static Logger logger = Logger.getLogger(NameCheck.class);

	private static String strTypeCode	= "0200";	// 전문종별코드(0200)
	private String strDocCode	= "";		// 실명확인서비스(260:내국인, 270:외국인)
	
	// 회원사 설정
	private static String strUserID	= "DBU002 ";			// 사용자ID (Space포함 7자리!!)(DBU002 )
	private static String strHostIP	= "210.207.91.239";	// 서울신용평가정보 IP(210.207.91.239)
	private String strPort		= "";				// 서울신용평가정보 Port(21089:내국인, 21502:외국인)

	public int timeout		= 5;

	private static NameCheckVO vo = null;

	public NameCheck(NameCheckVO vo, HttpServletRequest request) {
		this.vo = vo;
	}

	private void init() {
		vo.setRetCode(0);
		vo.setRetMsg("");
		vo.setResult_code("");
		
		vo.setCheck_type(",1,2,3,4,".indexOf("," + StringUtil.substring(vo.getJumin_no(),6,7) + ",")!=-1 ? 0 : 1);
		strDocCode	= vo.getCheck_type()==0 ? "260" : "270";
		strPort		= vo.getCheck_type()==0 ? "21089" : "21502";
	}

	/** 실명확인 */
	public NameCheckVO check(HttpServletRequest request, boolean isReal) {
		System.out.println("실명확인 시작: " + vo.getJumin_no() + ", " + "["+vo.getName().trim()+"]");
		
		logger.debug("실명인증 isReal: _" + isReal+"_");
		if(!isReal)
        {
            System.out.println("개발서버에서는 실명인증 바이패스 합니다.");
            
            vo.setRetCode(1);
            vo.setResult_code("1");
            vo.setRetMsg("실명확인");
            
            return vo;
        }
        System.out.println("운영서버에서는 실명인증 합니다.");
        
		init();

		String strReturnCode	= "000";		// 응답코드
		String strSequence		= "0000000001";	// 순번
		String strResult		= "";			// 실명확인결과값
		String strSendBuf		= "";			// 전송전문 Buf
		StringBuffer strRecvBuf	= new StringBuffer();
		
		String rtnString	= "";
		int len = 0, nMax = 40;


		com.idongbu.util.SocketClient sock = new com.idongbu.util.SocketClient();
		try {
			if(vo.getJumin_no().length() == 13) {
				len = vo.getName().trim().length();
				rtnString = fixData(vo.getName(), 40);
				
				if ( logger.isDebugEnabled() ) {
					/*logger.debug("strUserID      ===> [" + strUserID + "]");
					logger.debug("strDocCode     ===> [" + strDocCode + "]");
					logger.debug("strReturnCode  ===> [" + strReturnCode + "]");
					logger.debug("strSequence    ===> [" + strSequence + "]");
					logger.debug("vo.getJumin_no ===> [" + vo.getJumin_no() + "]");
					logger.debug("rtnString      ===> [" + rtnString + "]");*/
				}

				strSendBuf = strUserID + strTypeCode + strDocCode + strReturnCode + strSequence + vo.getJumin_no() + rtnString ;
				strRecvBuf = sock.SendWritePacket(strHostIP, strPort, timeout, strSendBuf);
				
				logger.debug("실명인증1 결과값 strRecvBuf : _" + strRecvBuf+"_");
				
				if(strRecvBuf.length() < 10) {
					strResult = "5";
				} else {
					strReturnCode = strRecvBuf.substring(14,17);
					
					logger.debug("실명인증2 응답코드 strReturnCode : " + strReturnCode);
					/*
					 * 주민번호 잘못입력한경우 조합된 주민번호로 인식하여 '주민번호오류' '4' 로 주도록 되어 있는데 
					 * 서신평에서 응답코드에 299(전문 Format type error) 를 넘겨주어 결과값에 '5'를 잘못 셋팅하도록 되어 있어서 '299' 코드를 정상적인 경우로 추가함
					 * 2014.12.31 박형규
					*/
					if(strReturnCode.equals("000")|| strReturnCode.equals("299")){
						strResult  = strRecvBuf.substring(strRecvBuf.length()-1,strRecvBuf.length());
						logger.debug("실명인증3 strResult : " + strResult);					
					} else if(vo.getCheck_type()==0 && "444".equals(strReturnCode)){
						strResult = "7";
					} else {
						strResult = "5";
					}
				}
			} else {
				strResult = "6";
			}
			//System.out.println("strRetrunCode=" + strReturnCode + ", strResult=" + strResult + ", " + getResultMsg(strResult));
			vo.setRetCode("1".equals(strResult) ? 1 : Integer.parseInt( strResult)  * -1);
		} catch(Exception e) {
			logger.error(e, e);
			vo.setRetCode(-1);
		}
		logger.debug("실명인증4 strResult : " + strResult);
		vo.setResult_code(strResult);
		vo.setRetMsg(getResultMsg(strResult));
		logNameCheck(vo, request);

		return vo;
	}

	public static void logNameCheck(NameCheckVO vo, HttpServletRequest request) {
		try {
			if(!StringUtil.isEmpty(vo.getJumin_no()) && !StringUtil.isEmpty(vo.getMember_gb())
					&& !StringUtil.isEmpty(vo.getUse_gb())) {
				if(StringUtil.isEmpty(vo.getRemoteIp())) {
					try {
						vo.setRemoteIp(BizUtil.getClientIP(request));
					} catch(Exception e) {
						logger.warn(e.getMessage(), e);
					}
				}
			}
			logger.debug("실명확인 로그 생성 성공");
		} catch(Exception e) {
			logger.error("실명확인 로그 생성 오류: " + e.getMessage() + "\n" + vo);
		}
	}
	

	/** 결과 메세지(모듈사 제공) */
	private static String getResultMsg(String strResult) {
		// 결과 코드(외국인경우 7 없음)
		HashMap resultMap = new HashMap();
		resultMap.put("1", "실명확인");
		resultMap.put("2", "이름불일치");
		resultMap.put("3", "성명없음");
		resultMap.put("4", "주민번호 오류");
		resultMap.put("5", "시스템장애 (체크사항: 소켓서버 아이피 및 포트 확인)");
		resultMap.put("6", "파라메터 에러(체크사항: 통신호출 파라미터 확인)");
		resultMap.put("7", "Siren24도용방지 서비스를 이용 (서비스 해제는 siren24에서 할수 있음)");
		resultMap.put("9", "인증제한횟수 초과로 해킹이 의심되어 당일 실명인증이 불가합니다. 내일 다시 이용해주시기 바랍니다. 감사합니다.");
		return (String) resultMap.get(strResult);
	}
	
	/** 결과 메세지(사용자용) */
	public static String getNameCheckRetMsg(String result_code) {
		String retMsg = "";
		if("2".equals(result_code) || "3".equals(result_code)) {
			retMsg = "실명조회 결과 고객님이 입력하신 성함과 주민번호가<br>일치하지 않습니다.";
			retMsg+= " 정확한 이름과 주민번호를 입력하였음에도<br>불구하고 이름과 주민번호가 일치하지 않는다면";
			retMsg+= " <font color='#990000'>아래 실명 확인<br>등록신청 버튼을 클릭하시면 다시 한번 조회</font>하여 드립니다.";
		} else if("5".equals(result_code)) {
			retMsg = "시스템장애가 발생하였습니다.<br>재입력버튼을 누르신 후 다시한번 시도해 주시기 바랍니다.<br>";
			retMsg+= "* 에러코드 : " + result_code + "<br>* 에러메세지 : 시스템 장애.(서울신용평가정보 사이트 이상)";
		} else if("7".equals(result_code) || "444".equals(result_code)) {
			retMsg = "고객님은 서울신용평가정보(주)에서 도용방지설정이 되어 있어<br>정상적인 실명확인을 수행할 수 없습니다.<br><br>";
			retMsg+= "정상적인 실명확인을 위해서는 고객님께서 서울신용정보평가정보의<br>SIREN24사이트에서 도용방지 설정을 취소하여야만";
			retMsg+= " 실명확인을 할 수 있습니다.<br><br>도용방지설정을 취소하신 후 재시도하여 주시기 바랍니다.";
		} else if("9".equals(result_code)) {
			retMsg = "인증제한횟수 초과로 해킹이 의심되어 당일 실명인증이 불가합니다.<br>내일 다시 이용해주시기 바랍니다.<br>감사합니다.";
		} else if("100".equals(result_code)) {
			retMsg = "요청에 의해 인터넷 서비스가 중단된 회원입니다.<br>";
			retMsg+= " 회원 본인이 직접 고객서비스팀을 방문하시어 인터넷 서비스를<br>요청하셔야 서비스를 재이용하실 수 있습니다.";
		}
		return retMsg;
	}

	 public static String getCalcStr(String str, int sLoc, int eLoc) {
	        byte[] bystStr;
	        String rltStr = "";
	        try
	        {
	            bystStr = str.getBytes();
	            rltStr = new String(bystStr, sLoc, eLoc - sLoc);
	        }
	        catch(Exception e)
	        {
	            return "";
	        }
	       return rltStr;
	    }
	 
	 
	 public static String fixData(String data, int len) throws UnsupportedEncodingException {
		 	if(len <0){
		 		return "";
		 	}
			byte[] tempdata = new byte[len];
			byte[] indata = data.getBytes("EUC-KR");
			for (int i = 0; i < len; i++) {
				if (indata.length > i)
					tempdata[i] = indata[i];
				else
					tempdata[i] = 0x20;
			}

			return new String(tempdata, "EUC-KR");
		}
	 
}
