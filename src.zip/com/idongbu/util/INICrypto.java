package com.idongbu.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.Ineb.Dguard.*;
import com.Ineb.Exception.DguardLoginException;
import com.Ineb.Exception.DguardNetworkException;
import com.Ineb.Exception.DGuardPropertyException;

public class INICrypto {
   
	private static DguardManager crypt = null;	
	private static String m_db   = "signature";
	private static String m_user = "signature";
	private static String m_tb   = "sign_data";
	
	private static INICrypto m_INICrypto = null;
	
	private static Logger logger = LoggerFactory.getLogger(INICrypto.class);
	
	public  static INICrypto getInstance(String RealPath, boolean isReal) throws Exception 
	{ 
		try {

			if(m_INICrypto == null) 
			{ 
			   m_INICrypto = new INICrypto();
				
			   if (isReal)
				   crypt = DguardManager.Init(RealPath +  "\\DGuardConfigReal.properties");
			   else
				   crypt = DguardManager.Init(RealPath +  "\\DGuardConfigTest.properties");
			   
			   logger.debug("INICrypto synchronized ....");
		    }
			
			//synchronized(m_INICrypto) { }
			
		}
		catch(DguardLoginException e)
		{
			logger.error(e.toString()); 
			throw e;
		}
		catch(DguardNetworkException e)
		{
			logger.error(e.toString()); 
			throw e;			
		}
		catch(DGuardPropertyException e)
		{				
			logger.error(e.toString()); 
			throw e;
		}
		catch(Exception e)
		{
			logger.error(e.toString()); 
			throw e;
		}		
		
		return m_INICrypto; 
	} 
	
	public String  Encrypt(String strField, String strData) throws Exception
	{
		String strVal = strData; 
		try
		{       
			strVal = crypt.Encrypt(m_db, m_user, m_tb, strField, strData);			
		}
		catch(Exception e)
		{
			logger.error(e.toString()); 
			throw e;
		}
		
		return strVal;
	}		
	
	public String  Decrypt(String strField, String strData) throws Exception
	{
		String strVal = strData; 
		try
		{       
			strVal = crypt.Decrypt(m_db, m_user, m_tb, strField, strData);			
		}
		catch(Exception e)
		{
			logger.error(e.toString()); 
			throw e;
		}
		
		return strVal;
	}		
}
