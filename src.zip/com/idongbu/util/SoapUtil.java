package com.idongbu.util;

import java.io.StringReader;
import java.lang.reflect.Method;
import java.util.Calendar;
import java.util.Random;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.Namespace;
import org.jdom.input.SAXBuilder;
import org.jdom.output.Format;
import org.jdom.output.XMLOutputter;

import com.idongbu.common.vo.CMMVO;


public class SoapUtil {

	private static String specialChar(String str) {
		str = str.replaceAll("&", "&amp;");
		str = str.replaceAll("\"", "");
		str = str.replaceAll(">", "&gt;");
		str = str.replaceAll("<", "&lt;");
		return str;
	}
	
	// CMMVO를 상속받은 VO의 생성자에서 PGMID, TRID를 set 해준 경우
	public static String makeXml(CMMVO vo) throws Exception {
		return makeXml(vo.getSYSID(), vo.getPGMID(), vo.getTRID(), vo);
	}

	public static String makeXml(String sysid, String pgmid, String trid, CMMVO vo) throws Exception {
		if(vo == null){
			throw new Exception("input vo is null");
		}
//		String rtnStr = "";	//만들어진 xml string
		
		//Namespace 사용이유 colon(:) 이름을 element명으로 사용불가
		Namespace dongbuNS = Namespace.getNamespace("SOAP","dongbu");	//dongbu값 의미없음. NameSpace 지정
		
		Document doc = new Document();
		
		Element rootEle = new Element("Envelope", dongbuNS);
		doc.setRootElement(rootEle);
		rootEle.addNamespaceDeclaration(dongbuNS);	//namespace 사용선언
		
		Element soap_bodyEle = new Element("Body",dongbuNS);
		rootEle.addContent(soap_bodyEle);
		soap_bodyEle.addNamespaceDeclaration(dongbuNS);
		
		Element bizcallEle = new Element("bizcall");
		soap_bodyEle.addContent(bizcallEle);
		Element headerareaEle = new Element("HeaderArea");
		bizcallEle.addContent(headerareaEle);
		
		Element sysidEle = new Element("SYSID");
		sysidEle.setText(sysid);
		headerareaEle.addContent(sysidEle);
		Element pgmidEle = new Element("PGMID");
		pgmidEle.setText(pgmid);
		headerareaEle.addContent(pgmidEle);
		Element tridEle = new Element("TRID");
		tridEle.setText(trid);
		headerareaEle.addContent(tridEle);
		
		Element bodyareaEle = new Element("BodyArea");
		bizcallEle.addContent(bodyareaEle);
		// BODY 변경부분 세팅
		
		//3차 vo : private field에 get/set method사용
		for (Method method : vo.getClass().getDeclaredMethods()) {	//메소드 갯수만큼 loop
			String methodName = method.getName();	//method name 가져옴
			if(methodName.indexOf("set") != -1) continue;					//set method continue;
			if("toString".equalsIgnoreCase(methodName)) continue;	//toString method continue;
			
			Object value = method.invoke(vo, null);	//null means no parameter ,	(getMethod실행)
			
			if(method.getReturnType().isArray()){		//메소드 리턴타입이 array이면
				
				String[] tempArr = (String[]) value;		//무조건 string[]로 해도 될까
				for(int i=0; i< tempArr.length; i++){
					Element temp = new Element(methodName.replaceFirst("get", ""));		//method에서 get을 제외하면 필드명	
					temp.addContent(tempArr[i]);
					
					bodyareaEle.addContent(temp);
				}
				
			}else{
				String strValue = StringUtil.nvl(value, "");
				Element temp = new Element(methodName.replaceFirst("get", ""));		//method에서 get을 제외하면 필드명	
				temp.addContent(strValue);
				
				bodyareaEle.addContent(temp);
				
			}
				
		}
		
		
		/*
		 2차 소스 : vo에 public field로 사용한 경우
		 Field[] fields = vo.getClass().getFields();
		String val = "";
		
		for (int i = 0; i < fields.length; i++) {
			Element temp = null;
			if (fields[i].getType().isArray()) {
				String[] vals = (String[]) fields[i].get(vo);
				for (int j = 0; j < vals.length; j++) {
					val = vals[j];
					
					temp = new Element(fields[i].getName());
					temp.addContent(val);
				}
			} else {
				
				val = (String) fields[i].get(vo);
				
				temp = new Element(fields[i].getName());
				temp.addContent(val);
			}
			
			bodyareaEle.addContent(temp);
		}*/
		
		
		return documentToString(doc);
	}
	
	public static String documentToString(Document doc){
		
//		String xml = new XMLOutputter(Format.getPrettyFormat()).outputString(doc);	//이쁘게 나오지만 trim함
//		String xml = new XMLOutputter(Format.getCompactFormat()).outputString(doc);		//한줄로 나오지만 trim함
		String xml = new XMLOutputter(Format.getRawFormat()).outputString(doc);		//한줄로 나오지만 trim안함
		
		
		return xml;
	}
	
	public static Document stringToDocument(String rtnXmlString) throws Exception {
		
		if(rtnXmlString.indexOf("<!DOCTYPE html") != -1 ){
			//SOAP xml이 아닌 에러(404,500) HTML 이 내려오는 상황 
			throw new Exception("기간계 통신이 실패하였습니다. 잠시후 다시 시도해주세요.");
		}
		
		//중요!! :(colon) 이 namespace문제로 파싱안되서 _로 변경함
		rtnXmlString = rtnXmlString.replace(":", "_");	
		rtnXmlString = rtnXmlString.replace("p", "");
		rtnXmlString = rtnXmlString.replace("", " ");
		
		Document doc = null;
		SAXBuilder sbuilder = new SAXBuilder();
		
		doc = sbuilder.build(new StringReader(rtnXmlString));
	   
		return doc;
	}

	public static String getBlank(int count){
		if(count == 0) return"";
		else{
			String tmpStr = "";
			for (int i = 0; i < count; i++) {
				tmpStr += "";
			}
			return tmpStr;
		}	
	}

	public static String CmmRandomSN() {
		
		Random oRandom = new Random();
		oRandom.setSeed(System.currentTimeMillis());
		int i = oRandom.nextInt(24) + 1;
		Calendar oCalendar = Calendar.getInstance( ); // 현재 날짜/시간 등의 각종 정보 얻기
		String sRandSN = ""+(char)(65+(oCalendar.get(Calendar.HOUR_OF_DAY)+i)%24);
		sRandSN += ""+(char)(65+(oCalendar.get(Calendar.MINUTE)+i)%24);
		sRandSN += ""+(char)(65+(oCalendar.get(Calendar.SECOND)+i)%24);
		sRandSN += ""+(char)(65+i);

		return sRandSN;
	}
}
