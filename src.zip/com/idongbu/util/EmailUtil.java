package com.idongbu.util;

import java.util.Enumeration;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class EmailUtil {
	protected static Log logger = LogFactory.getLog(EmailUtil.class);
	
	public static String replaceEmailParams(String html, HttpServletRequest req) {
		
		@SuppressWarnings("unchecked")
		Enumeration<String> params = req.getParameterNames();
		
		while( params.hasMoreElements() ) {
			//<input type=text name=variable1 value=testValue/>
			String name = params.nextElement();//variable1
			
			String key = "\\$\\{" + name + "\\}";//${variable1}
			
			html.replaceAll(key, req.getParameter(name));//${variable1} ==> testValue
		}
		
		return html;
	}
}