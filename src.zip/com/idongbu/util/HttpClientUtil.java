package com.idongbu.util;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.HttpVersion;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.RequestEntity;
import org.apache.commons.httpclient.methods.StringRequestEntity;
import org.apache.commons.httpclient.params.HttpConnectionManagerParams;
import org.apache.commons.lang.ArrayUtils;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.xpath.XPath;

import com.idongbu.smartcustomer.vo.CmmFBM0299RVO;
import com.idongbu.smartcustomer.vo.CmmFUA6010RVO;
import com.idongbu.smartcustomer.vo.CmmFUA6011RVO;

public class HttpClientUtil {
	
	private static final int DEFALUT_CON_TIMEOUT          = 15000;	//연결까지 대기할 시간(m sec)(모바일서버 -> 중계서버 )
	private static final int DEFALUT_SO_TIMEOUT          = 120000;	//연결후 대기할 시간(m sec) (중계서버처리를 기다릴 시간)
	private static final int DEFAULT_RECEIVE_BUFFER_SIZE = 8192;

	public static byte[] callPost(String url, NameValuePair[] nvp) throws Exception, IOException{
		
		System.out.println("********HttpClientUtil.callPost********************");
		HttpClient client = new HttpClient();
		
		HttpConnectionManagerParams params = client.getHttpConnectionManager().getParams();
		params.setSoTimeout(DEFALUT_SO_TIMEOUT);	//socket Timeout
		client.getHttpConnectionManager().getParams().setReceiveBufferSize(DEFAULT_RECEIVE_BUFFER_SIZE);
		client.getParams().setContentCharset("EUC-KR");
		
		PostMethod method = new PostMethod(url);
		method.setRequestHeader("Content-Type", "application/x-www-form-urlencoded; charset=EUC-KR");
		method.setRequestBody(nvp);
		
		int resultCd = client.executeMethod(method);
		System.out.println("**********resultCd=*************"+resultCd);
		if (HttpStatus.SC_OK != resultCd) throw new Exception("Failed to get remote datas. [" + resultCd + "]");
		
//		byte[] result = method.getResponseBody(Integer.MAX_VALUE);
		byte[] result = method.getResponseBody();
		
		return result;
	
	}
	
	public static byte[] callPost(String url, String xmlStr) throws Exception,IOException {
		byte bytes[] = null;
		
		InputStream is = null;
		HttpClient client = new HttpClient();
		ByteArrayOutputStream bos = null;
		
		client.getHttpConnectionManager().getParams().setParameter("http.protocol.version", HttpVersion.HTTP_1_1); 
		client.getHttpConnectionManager().getParams().setConnectionTimeout(DEFALUT_CON_TIMEOUT);
		client.getHttpConnectionManager().getParams().setSoTimeout(DEFALUT_SO_TIMEOUT);
		
		PostMethod httppost = new PostMethod(url);
		httppost.setRequestHeader("Content-Length", String.valueOf( xmlStr.getBytes("UTF-8").length ));
		
		RequestEntity entity = new StringRequestEntity(xmlStr, "text/xml;", "UTF-8");
		httppost.setRequestEntity(entity);

		
		try {
			long start = System.currentTimeMillis();
			client.executeMethod(httppost);
			System.out.println("	== logging execute걸린시간 : " + (System.currentTimeMillis()-start) + " ms");
			
			System.out.println("응답 : " + httppost.getStatusCode());
			if (httppost.getStatusCode() != 200) {

				 throw new Exception("통신장애입니다. 잠시후 시도해주세요.");
//				 throw new Exception("기간계 응답오류[" +httppost.getStatusLine().toString() + "]");
			}

			is = httppost.getResponseBodyAsStream();
			bos = new ByteArrayOutputStream();
			byte buf[] = new byte[1024];
			int len;
			
			while (true) {
				len = is.read(buf);
				if(len<=0){
					break;
				}
				
				bos.write(buf, 0, len);
			}

			bytes = bos.toByteArray();
		} catch (Exception e) {
//			throw e;
			throw new Exception("통신장애입니다. 잠시후 시도해주세요.");
		} finally {
			if (bos != null)try {bos.close();} catch (Exception e) {bos = null;}
			if (is != null)try {is.close();} catch (Exception e) {is = null;}
			if (httppost != null)try {httppost.releaseConnection();} catch (Exception e) {httppost = null;}
		}

		return bytes;
	}
	
	public static byte[] callUrlPost(String url) throws Exception, IOException {
		
		HttpClient client = new HttpClient();
		
		HttpConnectionManagerParams params = client.getHttpConnectionManager().getParams();
		params.setSoTimeout(DEFALUT_SO_TIMEOUT);	//socket Timeout
		client.getHttpConnectionManager().getParams().setReceiveBufferSize(DEFAULT_RECEIVE_BUFFER_SIZE);
		
		PostMethod method = new PostMethod(url);
		method.setRequestHeader("Content-Type", "text/xml; charset=utf-8");
		
		int resultCd = client.executeMethod(method);
		if (HttpStatus.SC_OK != resultCd){
			System.out.println("200 아닌경우");
		}
		
		byte[] result = method.getResponseBody();
		
		return result;
	}
	
	//RD 선 인증용 메소드 한상욱C
	public static int callPostRD(String url, String xmlStr) throws Exception, IOException{
		
		byte[] xmlStrByte = xmlStr.getBytes("UTF-8");
		
		HttpClient client = new HttpClient();
		
		HttpConnectionManagerParams params = client.getHttpConnectionManager().getParams();
		params.setSoTimeout(DEFALUT_SO_TIMEOUT);	//socket Timeout
		client.getHttpConnectionManager().getParams().setReceiveBufferSize(DEFAULT_RECEIVE_BUFFER_SIZE);
		
		PostMethod method = new PostMethod(url);
		method.setRequestHeader("Content-Type", "text/xml; charset=utf-8");
		method.setRequestHeader("Content-Length", String.valueOf( xmlStrByte.length ));
//		method.setRequestBody(nvp);
		method.setRequestBody(xmlStr);
		
		int resultCd = client.executeMethod(method);
		
		if(HttpStatus.SC_OK == resultCd) return 0;
		else return 1;
		
	}
	
	public static NameValuePair[] getNameValuePairs(Object vo) throws Exception {
		NameValuePair[] nvpairs = new NameValuePair[0];
		Field[] fields = vo.getClass().getFields();
		
		for(int i=0; i<fields.length; i++) {
			String key = fields[i].getName();
			
			String val = "";
			
			if(fields[i].getType().isArray()) {
				String[] vals = (String[]) fields[i].get(vo);
				for(int j=0; j<vals.length; j++) {
					val = vals[j];
					nvpairs = (NameValuePair[]) ArrayUtils.add(nvpairs, new NameValuePair(key, val));
				}
			} else {
				val = (String) fields[i].get(vo);
				if(val==null) continue;
				nvpairs = (NameValuePair[]) ArrayUtils.add(nvpairs, new NameValuePair(key, val));
			}
		}
		return nvpairs;
	}
	
	
	//원본 버전
	public static byte[] callPostOLD(String url, String xmlStr) throws Exception, IOException{

		byte[] xmlStrByte = xmlStr.getBytes("UTF-8");
		
		HttpClient client = new HttpClient();
		
		
//		모바일서버 -> 동부 중계서버 까지의 timeout설정
//		client.getParams().setParameter("http.protocol.version", HttpVersion.HTTP_1_1);
		client.getParams().setParameter("http.protocol.expect-continue", false);
		client.getParams().setParameter("http.connection.timeout", DEFALUT_CON_TIMEOUT);
		
		
		HttpConnectionManagerParams params = client.getHttpConnectionManager().getParams();
		
//		동부 중계서버 -> 처리까지 기대리는 시간 timeout
		params.setSoTimeout(DEFALUT_SO_TIMEOUT);	//socket Timeout
		client.getHttpConnectionManager().getParams().setReceiveBufferSize(DEFAULT_RECEIVE_BUFFER_SIZE);
		
		PostMethod method = new PostMethod(url);
		method.setRequestHeader("Content-Type", "text/xml; charset=utf-8");
		method.setRequestHeader("Content-Length", String.valueOf( xmlStrByte.length ));
//		method.setRequestBody(nvp);
		method.setRequestBody(xmlStr);
		
		
		int resultCd = client.executeMethod(method);
		
		byte[] result = method.getResponseBody();
		
		if (HttpStatus.SC_OK != resultCd){
			System.out.println("200 아닌경우");
			System.out.println("UTF8 : " + new String(result , "UTF-8" ));
			throw new Exception("기간계 응답 에러 코드[" + resultCd + "]");
		}
		
//		byte[] result = method.getResponseBody(Integer.MAX_VALUE);
		
		return result;
	}
	
}
