package com.idongbu.util;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.idongbu.common.DBConnBean;
import com.idongbu.smartcustomer.vo.ComnInfoVO;
import com.idongbu.util.dao.UtilDao;

public class CodeUtil {
	
	protected static Log logger = LogFactory.getLog(CodeUtil.class);
	private static Hashtable<String, Object> codeTable = new Hashtable<String, Object>();

	/** 코드(CL_CD)로 콤보리스트를 뿌려준다 */
	public static String getSelectList(String codeId, String def) {
		return getSelectList(getCodeMap(codeId), def);
	}

	public static String getSelectList2(String codeId, String def) { // LinkedHashMap 사용하여 정렬안됨 수정
		return getSelectList(getCodeMapAsLinkedHashMap(codeId), def);
	}

	/**
	 * @param codeId	CL_CD
	 * @param def		기본으로 보여줄 DSTIN_CD
	 * @param delList	제외할 DSTIN_CD list
	 * @return
	 */
	public static String getSelectList(String codeId, String def, Vector<String> delList) {
		return getSelectList(getCodeMap(codeId), def, delList);

	}

	/** 배열을 콤보로 뿌려준다 */
	public static String getSelectList(String[] arr, String def) {
		try {
			StringBuffer strb = new StringBuffer();
			for(int i=0; i<arr.length; i++) {
				String key = arr[i];
				String val = arr[i];
				strb.append("<option value=\"").append(key).append("\"");
				if(def!=null || !"".equals(def)) {
					if(key.equals(def)) strb.append(" selected=\"selected\"");	// 웹표준에 맞춤 - 김경석
				}
				strb.append(">").append(val).append("</option>\n");
			}
			return strb.toString();
		} catch (Exception e) {
			logger.debug(e);
		}
		return "";
	}

	/** 배열을 콤보로 뿌려준다 */
	public static String getSelectList(String[][] arr, String def) {

		try {
			StringBuffer strb = new StringBuffer();
			for(int i=0; i<arr.length; i++) {
				String key = arr[i][0];
				String val = arr[i][1];
				strb.append("<option value=\"").append(key).append("\"");
				if(def!=null || !"".equals(def)) {
					if(key.equals(def)) strb.append(" selected=\"selected\"");	// 웹표준에 맞춤 - 김경석
				}
				strb.append(">").append(val).append("</option>\n");
			}
			return strb.toString();
		} catch (Exception e) {
			logger.debug(e);
		}
		return "";
	}

	public static String getSelectList(HashMap<String,String> map, String def) {
		try {
			StringBuffer strb = new StringBuffer();
			Iterator<String> it = map.keySet().iterator();
			while(it.hasNext()) {
				String key = (String) it.next();
				String val = (String) map.get(key);

				strb.append("<option value=\"").append(key).append("\"");
				if(def!=null || !"".equals(def)) {
					if(key.equals(def)) strb.append(" selected=\"selected\"");	// 웹표준에 맞춤 - 김경석

				}
				strb.append(">").append(val).append("</option>\n");
			}
			return strb.toString();
		} catch (Exception e) {
			logger.debug(e);
		}
		return "";
	}
	
	public static String getSelectList(LinkedHashMap<String,String> map, String def) {
		try {
			StringBuffer strb = new StringBuffer();
			Iterator<String> it = map.keySet().iterator();
			while(it.hasNext()) {
				String key = (String) it.next();
				String val = (String) map.get(key);
				//logger.debug("key: " + key + ", val: " + val);

				strb.append("<option value=\"").append(key).append("\"");
				if(def!=null || !"".equals(def)) {
					if(key.equals(def)) strb.append(" selected=\"selected\"");	// 웹표준에 맞춤 - 김경석

				}
				strb.append(">").append(val).append("</option>\n");
			}
			return strb.toString();
		} catch (Exception e) {
			logger.debug(e);
		}
		return "";
	}

	public static String getSelectList(HashMap<String, String> map, String def, Vector<String> delList) {
		try {
			StringBuffer strb = new StringBuffer();
			Iterator<String> it = map.keySet().iterator();
			while(it.hasNext()) {
				String key = (String) it.next();
				String val = (String) map.get(key);
				if(!delList.contains(key)){
					strb.append("<option value=\"").append(key).append("\"");
					if(def!=null || !"".equals(def)) {
						if(key.equals(def)) strb.append(" selected=\"selected\"");	// 웹표준에 맞춤 - 김경석
					}
					strb.append(">").append(val).append("</option>\n");
				}
			}
			return strb.toString();
		} catch (Exception e) {
			logger.debug(e);
		}
		return "";
	}

	/** javascript용 배열을 만든다.
	 * var codeC08Arr = <%=CodeUtil.getJsArray("C08")%>;
	 * ===> var codeC08Arr = [["01","코드명01"],["02","코드명02"]];
	 **/
	public static String getJsArray(String codeId) {
		return getJsArray(getCodeMap(codeId));

	}

	/** javascript용 배열을 만든다. */
	public static String getJsArray(HashMap<String, String> map) {
		StringBuffer strb = new StringBuffer();
		try {
			Iterator<String> it = map.keySet().iterator();
			while(it.hasNext()) {
				String key = (String) it.next();
				String val = (String) map.get(key);
				strb.append("[\"").append(StringUtil.escapeHtmlJavaScript(key)).append("\"");
				strb.append(",\"").append(StringUtil.escapeHtmlJavaScript(val)).append("\"]");
				if(it.hasNext()) strb.append(",");
			}
		} catch (Exception e) {
			logger.debug(e);
		} finally {
			strb.insert(0, "[").append("]");
		}
		return strb.toString();
	}

	/** 코드(CL_CD)로 콤보리스트를 뿌려준다 */
	public static String getRadioList(String codeId, String name, String def) {
		return getRadioList(getCodeMap(codeId), name, def);

	}

	/** 배열로 콤보리스트를 뿌려준다 */
	public static String getRadioList(String[] arr, String name, String chk) {
		try {
			StringBuffer strb = new StringBuffer();
			for(int i=0; i<arr.length; i++) {
				String key = arr[i];
				String val = arr[i];
				strb.append("<input type=\"radio\" name=\""+ name + "\"");
				strb.append(" id=\""+ name + "_temp_" + i + "\"");
				strb.append(" value=\"").append(key).append("\"");
				if(chk!=null || !"".equals(chk)) {
					if(key.equals(chk)) strb.append(" checked=\"checked\"");		// 웹표준에 맞춤 - 김경석
				}
				strb.append("><label for=\"" + name + "_temp_" + i + "\">");
				strb.append(val).append("</label>&nbsp;&nbsp;\n");
			}
			return strb.toString();
		} catch (Exception e) {
			logger.debug(e);
		}
		return "";
	}

	/** 배열로 콤보리스트를 뿌려준다 */
	public static String getRadioList(String[][] arr, String name, String chk) {
		try {
			StringBuffer strb = new StringBuffer();
			for(int i=0; i<arr.length; i++) {
				String key = arr[i][0];
				String val = arr[i][1];
				strb.append("<input type=\"radio\" name=\""+ name + "\"");
				strb.append(" id=\""+ name + "_temp_" + i + "\"");
				strb.append(" value=\"").append(key).append("\"");
				if(chk!=null || !"".equals(chk)) {
					if(key.equals(chk)) strb.append(" checked=\"checked\"");		// 웹표준에 맞춤 - 김경석
				}
				strb.append("><label for=\"" + name + "_temp_" + i + "\">");
				strb.append(val).append("</label>&nbsp;&nbsp;\n");
			}
			return strb.toString();
		} catch (Exception e) {
			logger.debug(e);
		}
		return "";
	}

	public static String getRadioList(HashMap<String, String> map, String name, String chk) {
		try {
			StringBuffer strb = new StringBuffer();
			Iterator<String> it = map.keySet().iterator();
			int idx = 0;
			while(it.hasNext()) {
				String key = (String) it.next();
				String val = (String) map.get(key);
				strb.append("<input type=\"radio\" name=\""+ name + "\"");
				strb.append(" id=\""+ name + "_temp_" + idx + "\"");
				strb.append(" value=\"").append(key).append("\"");
				if(chk!=null || !"".equals(chk)) {
					if(key.equals(chk)) strb.append(" checked=\"checked\"");		// 웹표준에 맞춤 - 김경석
				}
				strb.append("><label for=\"" + name + "_temp_" + idx + "\">");
				strb.append(val).append("</label>&nbsp;&nbsp;\n");
				idx++;
			}
			return strb.toString();
		} catch (Exception e) {
			logger.debug(e);
		}
		return "";
	}

	/** 코드(CL_CD)로 체크박스를 뿌려준다 */
	public static String getCheckList(String codeId, String name, String[] checks) {
		return getCheckList(getCodeMap(codeId), name, checks);

	}

	/** 코드(CL_CD)로 체크박스를 뿌려준다 */
	public static String getCheckList(String codeId, String name, String[] checks, int cols) {
		return getCheckList(getCodeMap(codeId), name, checks, cols);

	}

	/** 배열로 체크박스를 뿌려준다 */
	public static String getCheckList(String[] arr, String name, String[] checks) {
		try {
			StringBuffer strb = new StringBuffer();
			for(int i=0; i<arr.length; i++) {
				String key = arr[i];
				String val = arr[i];
				strb.append("<input type=\"checkbox\" name=\""+ name + "\"");
				strb.append(" id=\""+ name + "_temp_" + i + "\"");
				strb.append(" value=\"").append(key).append("\"");
				if(checks!=null && ArrayUtils.indexOf(checks, key)!=-1) {
					strb.append(" checked=\"checked\"");		// 웹표준에 맞춤 - 김경석
				}
				strb.append("><label for=\"" + name + "_temp_" + i + "\">");
				strb.append(val).append("</label>&nbsp;&nbsp;\n");
			}
			return strb.toString();
		} catch (Exception e) {
			logger.debug(e);
		}
		return "";
	}

	/** 배열로 체크박스를 뿌려준다 */
	public static String getCheckList(String[][] arr, String name, String[] checks) {
		try {
			StringBuffer strb = new StringBuffer();
			for(int i=0; i<arr.length; i++) {
				String key = arr[i][0];
				String val = arr[i][1];
				strb.append("<input type=\"checkbox\" name=\""+ name + "\"");
				strb.append(" id=\""+ name + "_temp_" + i + "\"");
				strb.append(" value=\"").append(key).append("\"");
				if(checks!=null && ArrayUtils.indexOf(checks, key)!=-1) {
					strb.append(" checked=\"checked\"");		// 웹표준에 맞춤 - 김경석
				}
				strb.append("><label for=\"" + name + "_temp_" + i + "\">");
				strb.append(val).append("</label>&nbsp;&nbsp;\n");
			}
			return strb.toString();
		} catch (Exception e) {
			logger.debug(e);
		}
		return "";
	}

	public static String getCheckList(HashMap<String, String> map, String name, String[] checks) {
		try {
			StringBuffer strb = new StringBuffer();
			Iterator<String> it = map.keySet().iterator();
			int idx = 0;
			while(it.hasNext()) {
				String key = (String) it.next();
				String val = (String) map.get(key);
				strb.append("<input type=\"checkbox\" name=\""+ name + "\"");
				strb.append(" id=\""+ name + "_temp_" + idx + "\"");
				strb.append(" value=\"").append(key).append("\"");
				if(checks!=null && ArrayUtils.indexOf(checks, key)!=-1) {
					strb.append(" checked=\"checked\"");		// 웹표준에 맞춤 - 김경석
				}
				strb.append("><label for=\"" + name + "_temp_" + idx + "\">");
				strb.append(val).append("</label>&nbsp;&nbsp;\n");
				idx++;
			}
			return strb.toString();
		} catch (Exception e) {
			logger.debug(e);
		}
		return "";
	}

	public static String getCheckList(HashMap<String, String> map, String name, String[] checks, int cols) {
		try {
			StringBuffer strb = new StringBuffer();
			Iterator<String> it = map.keySet().iterator();
			int idx = 0;
			int cnt = 1;
			while(it.hasNext()) {
				String key = (String) it.next();
				String val = (String) map.get(key);
				strb.append("<span style=\"width:100px;\"><input style=\"width:30px;\" type=\"checkbox\" name=\""+ name + "\"");
				strb.append(" id=\""+ name + "_temp_" + idx + "\"");
				strb.append(" value=\"").append(key).append("\"");
				if(checks!=null && ArrayUtils.indexOf(checks, key)!=-1) {
					strb.append(" checked=\"checked\"");		// 웹표준에 맞춤 - 김경석
				}
				strb.append("><label for=\"" + name + "_temp_" + idx + "\">");
				strb.append(val).append("</label>&nbsp;&nbsp;</span>\n");

				if((cnt % cols) == 0 )	strb.append("<br>");	

				idx++;
				cnt++;
			}
			return strb.toString();
		} catch (Exception e) {
			logger.debug(e);
		}
		return "";
	}

	public static String getCodeName(String codeId, String code) {
		return getCodeName(codeId, code, "");
	}

	public static String getCodeName(String codeId, String code, String alt) {
		HashMap<String, String> map = getCodeMap(codeId);
		String ret = (String) (map.containsKey(code) ? map.get(code) : map.get(alt));
		return StringUtil.nvl(ret, code);
	}

	public static String getCodeName(String codeId, String code, String alt, String dlt) {
		HashMap<String, String> map = getCodeMap(codeId);
		String ret = (String) (map.containsKey(code) ? map.get(code) : map.get(alt));
		return StringUtil.nvl(ret, dlt);
	}

	public static String getCodeName(HashMap<String, String> map, String code) {
		return getCodeName(map, code, "");
	}

	public static String getCodeName(HashMap<String, String> map, String code, String alt) {
		String ret = (String) (map.containsKey(code) ? map.get(code) : map.get(alt));
		return StringUtil.nvl(ret, code);
	}

	/** 코드명으로 코드를 가져온다. */
	public static String getCode(String codeId, String code_name) {
		HashMap<String, String> map = getCodeMap(codeId);
		Iterator<String> it = map.keySet().iterator();
		while(it.hasNext()) {
			String key = (String) it.next();
			String val = (String) map.get(key);
			if(val.equals(code_name)) return key;
		}
		return "";
	}


	public static String getCodeName(SqlSessionTemplate sqlSession, String codeId, String code) {
		return getCodeName(sqlSession, codeId, code, "");
	}

	public static String getCodeName(SqlSessionTemplate sqlSession, String codeId, String code, String alt) {

		ComnInfoVO vo = new ComnInfoVO();
		vo.setCL_CD(codeId);

		HashMap<String,String> map = getCodeMap(sqlSession, vo);
		String ret = (String) (map.containsKey(code) ? map.get(code) : map.get(alt));
		return StringUtil.nvl(ret, code);
	}

	public static HashMap<String,String> getCodeMap(SqlSessionTemplate sqlSession, String codeId) {

		ComnInfoVO vo = new ComnInfoVO();
		vo.setCL_CD(codeId);

		HashMap<String,String> map = getCodeMap(sqlSession, vo);
		return map;
	}

	public static LinkedHashMap<String, String> getCodeMapAsLinkedHashMap(SqlSessionTemplate sqlSession, String codeId) {

		ComnInfoVO vo = new ComnInfoVO();
		vo.setCL_CD(codeId);

		LinkedHashMap<String,String> map = getCodeMapAsLinkedHashMap(sqlSession, vo);
		return map;
	}

	public static HashMap<String,String> getCodeMap(SqlSessionTemplate sqlSession , ComnInfoVO vo) {
		Map<String,String> rtnMap = new HashMap<String,String>();

		UtilDao mapper = null;
		try {

			mapper= sqlSession.getMapper(UtilDao.class);

		} catch (Exception e) {
			logger.debug(e);
		}

		List<HashMap<String,String>> list = mapper.selectComnInfo(vo);
		if(list !=null){
			for (HashMap<String, String> hashMap : list) {
				rtnMap.put(hashMap.get("DSTIN_CD"), hashMap.get("CD_NAME"));
			}
		}

		return (HashMap<String, String>) rtnMap;
	}
	
	public static LinkedHashMap<String,String> getCodeMapAsLinkedHashMap(SqlSessionTemplate sqlSession , ComnInfoVO vo) {
		Map<String,String> rtnMap = new LinkedHashMap<String,String>();

		UtilDao mapper = null;
		try {

			mapper= sqlSession.getMapper(UtilDao.class);

		} catch (Exception e) {
			logger.debug(e);
		}

		List<HashMap<String,String>> list = mapper.selectComnInfo(vo);
		if(list !=null){
			for (HashMap<String, String> hashMap : list) {
				rtnMap.put(hashMap.get("DSTIN_CD"), hashMap.get("CD_NAME"));
			}
		}

		return (LinkedHashMap<String, String>) rtnMap;
	}	

	@SuppressWarnings("unchecked")
	public static HashMap<String,String> getCodeMap(String code) {
		HashMap<String, String> rtnMap = null;
		rtnMap = (HashMap<String, String>) codeTable.get(code);

		if (rtnMap == null) {
			
			rtnMap = new HashMap<String,String>();
			UtilDao mapper = null;
			try {
				mapper= DBConnBean.getSqlSession().getMapper(UtilDao.class);

			} catch (Exception e) {
				logger.debug(e);
			}

			List<HashMap<String,String>> list = mapper.getCodeList(code);
			if(list !=null){
				for (HashMap<String, String> hashMap : list) {
					rtnMap.put(hashMap.get("COMM_CODE"), hashMap.get("COMM_NM"));
				}
			}
			codeTable.put(code,rtnMap);
			
		}
		
		return (HashMap<String, String>) rtnMap.clone();
	}
	
	@SuppressWarnings("unchecked")
	public static LinkedHashMap<String,String> getCodeMapAsLinkedHashMap(String code) {
		LinkedHashMap<String, String> rtnMap = null;
		try {
			rtnMap = (LinkedHashMap<String, String>) codeTable.get(code);
		}
		catch(ClassCastException e) {
			logger.debug(e);
			rtnMap = null;
		}

		if (rtnMap == null) {
			
			rtnMap = new LinkedHashMap<String,String>();
			UtilDao mapper = null;
			try {
				mapper= DBConnBean.getSqlSession().getMapper(UtilDao.class);

			} catch (Exception e) {
				logger.debug(e);
			}

			List<HashMap<String,String>> list = mapper.getCodeList(code);
			if(list !=null){
				for (HashMap<String, String> hashMap : list) {
					rtnMap.put(hashMap.get("COMM_CODE"), hashMap.get("COMM_NM"));
					//logger.debug(hashMap.get("COMM_CODE") + ", " + hashMap.get("COMM_NM"));
				}
			}
			
			codeTable.put(code,rtnMap);
			
		}
		
		return (LinkedHashMap<String, String>) rtnMap;
	}	

	/**전문코드에 따른 에러메세지 조회
	 * 
	 * @param sqlSession
	 * @param msgCd
	 * @return
	 */
	public static String getJmErrMsg(SqlSessionTemplate sqlSession, String msgCd) {
		return getJmErrMsg(sqlSession,msgCd, "에러 코드에 해당하는 데이터가 없습니다.");
	}

	public static String getJmErrMsg(SqlSessionTemplate sqlSession, String msgCd, String def) {
		//UtilDao utilMapper = null;
		String msgName = sqlSession.getMapper(UtilDao.class).selectJmErrMsg(msgCd);
		if(msgName==null || "".equals(msgName)) msgName = def;
		return msgName;
	}
}
