package com.idongbu.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import KISINFO.VNO.VNOInterop;
import com.idongbu.smartcustomer.vo.IpinVO;

public class Ipin {
	private final static Logger logger = LoggerFactory.getLogger(Ipin.class);
	private static String sSiteCode		= "A574";			
	private static String sSitePWD		= "52832291";		
	private static String sFlag			= "JID";			
	
	/**
	 * 주민번호 IPIN 전송 후 VNOInterop 추출
	 * @param jumin
	 * @return VNOInterop
	 */
	public static IpinVO ipinSendJumin(String jumin){// 사용자 정보 (주민등록번호 13자리 or 안심키값 13자리)
		String sJumin			= jumin;			
		VNOInterop vnoInterop = new VNOInterop();
		IpinVO returnVO = new IpinVO();
		// DI (64 byte로 구성) 추출
		int iReturnDI = vnoInterop.fnRequestDupInfo(sSiteCode, sSitePWD, sJumin, sFlag);
		logger.debug("RESULT_CODE [DI] = " + iReturnDI);
		if (iReturnDI == 1) {
			System.out.println("DUPINFO=[" + vnoInterop.getDupInfo() + "]");
			returnVO.setIPIN_DI(vnoInterop.getDupInfo()); 
	    }
	    // CI (88 byte로 구성) 추출
	    int iReturnCI = vnoInterop.fnRequestConnInfo(sSiteCode, sSitePWD, sJumin, sFlag);
	    logger.debug("RESULT_CODE [CI] = " + iReturnCI);
	    if (iReturnCI == 1) {
	    	logger.debug("ConnINFO=[" + vnoInterop.getConnInfo() + "]");
	    	returnVO.setIPIN_CI(vnoInterop.getConnInfo()); 
	    }				
	    
		return returnVO;
	}
	
	
	
	
	
}
