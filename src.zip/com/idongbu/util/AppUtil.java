package com.idongbu.util;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

public class AppUtil {

	
	/**
	 * @param request 
	 * @info Native App의 웹뷰로 접속한지 여부
	 * @return boolean
	 * @throws Exception 
	 * @throws IOException 
	 */
	public static boolean isAppExecute(HttpServletRequest request) throws IOException, Exception {
		boolean isNativeApp = false;
		String userAgent = (String)request.getHeader("User-Agent");

		// User-Agent에 Morpheus 값이 있으면 앱 실행중임
		if ( StringUtil.nvl(userAgent).indexOf("Morpheus") > -1 ) {
			isNativeApp = true;
		}
		
		return isNativeApp;
	}
	
	/**
	 * @param request 
	 * @info  단말기 OS 종류
	 * @return String (I:iOS / A:Android)
	 * @throws Exception 
	 * @throws IOException 
	 */
	public static String getOS(HttpServletRequest request) throws IOException, Exception {
		String osType = "";
		String userAgent = (String)request.getHeader("User-Agent");

		// User-Agent에 morpheus 값이 있으면 앱 실행중임
		if ( StringUtil.nvl(userAgent).indexOf("iPhone") > -1 || 
			 StringUtil.nvl(userAgent).indexOf("iPad") > -1   ||
			 StringUtil.nvl(userAgent).indexOf("iPod") > -1     ) {
			osType = "I";
		} else if ( StringUtil.nvl(userAgent).indexOf("Android") > -1 ) {
			osType = "A";
		}
		
		return osType;
	}

	/**
	 * @param request 
	 * @info  태블릿 여부
	 * @return boolean
	 * @throws Exception 
	 * @throws IOException 
	 */
	public static boolean getIsTablet(HttpServletRequest request) throws IOException, Exception {
		String userAgent = (String)request.getHeader("User-Agent");

		// User-Agent에 iPad 있으면 아이패드
		if ( StringUtil.nvl(userAgent).indexOf("iPad") > -1 ) {
			return true;
		}
		
		// User-Agent에 Android 존재하고 Mobile 값이 없으면 태블릿
		if ( StringUtil.nvl(userAgent).indexOf("Android") > -1 &&
			 StringUtil.nvl(userAgent).indexOf("Mobile") < 0 	) {
			return true;
		}
		
		return false;
	}

	/**
	 * @param request 
	 * @info  아이패드 여부
	 * @return boolean
	 * @throws Exception 
	 * @throws IOException 
	 */
	public static boolean getIsIPad(HttpServletRequest request) throws IOException, Exception {
		String userAgent = (String)request.getHeader("User-Agent");

		// User-Agent에 iPad 있으면 아이패드
		if ( StringUtil.nvl(userAgent).indexOf("iPad") > -1 ) {
			return true;
		}
		
		return false;
	}
	
	/**
	 * @param request 
	 * @info  안드로이드 태블릿 여부
	 * @return boolean
	 * @throws Exception 
	 * @throws IOException 
	 */
	public static boolean getIsAndroidTab(HttpServletRequest request) throws IOException, Exception {
		String userAgent = (String)request.getHeader("User-Agent");

		// User-Agent에 Android 존재하고 Mobile 값이 없으면 태블릿
		if ( StringUtil.nvl(userAgent).indexOf("Android") > -1 &&
			 StringUtil.nvl(userAgent).indexOf("Mobile") < 0 	) {
			return true;
		}
		
		return false;
	}
	
	/**
	 * @param request 
	 * @info  안드로이드 킷캣 여부
	 * @return boolean
	 * @throws Exception 
	 * @throws IOException 
	 */
	public static boolean getIsKitKat(HttpServletRequest request) throws IOException, Exception {
		String userAgent = (String)request.getHeader("User-Agent");

//		// User-Agent에 Android 이고 4.4 값이 있으면 킷캣
//		if ( StringUtil.nvl(userAgent).indexOf("Android") > -1 &&
//			 StringUtil.nvl(userAgent).indexOf("4.4") > -1 	) {
//			return true;
//		}
		
		//Android는 모든 사진촬영을 앱에서 처리하기 위해 
		//모든 Android를 킷캣으로 처리함
		//2014.05.25 F1F14A23
		if ( StringUtil.nvl(userAgent).indexOf("Android") > -1 ) {
			return true;
		}
	
		return false;
	}
	
}
