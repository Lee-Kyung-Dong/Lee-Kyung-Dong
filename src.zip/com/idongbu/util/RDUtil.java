package com.idongbu.util;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URL;
import java.net.URLEncoder;

import com.idongbu.smartcustomer.vo.CuCounVO;

public class RDUtil {
	public static boolean sendRD(
			String jobGbn		//01:자동차, 02:장기 
			, String docuGbn	//01:증권, 00:이외
			, String type		// FAX = 2, Mail = 3
			, String formId		//출력폼 ID
			, String formName	//출력폼 이름
			, String data		//RD전송데이터
			, String receiverJumin
			, String receiverNm
			, String receiverAddr
			, String copyYn		//위변조 방지마크여부
			, String senderId
			, String poliNo		// 증권번호
			, String ccUrl
			, String rdUrl
			, boolean isReal
		) {
		/*if(! isReal) { // 개발모드인경우 메일은 이민섭 대리쪽으로..
			if("3".equals(type)) receiverAddr = "f1f14c24@dbins.net";
		}*/
//		senderId = "F1N00148".equals(senderId) ? senderId.substring(1) : senderId;
		
		 System.out.println("RDUtil ::::::::::: jobGbn : " + jobGbn);
		 System.out.println("RDUtil ::::::::::: docuGbn : " + docuGbn);
		 System.out.println("RDUtil ::::::::::: type : " + type);
		 System.out.println("RDUtil ::::::::::: formId : " + formId);
		 System.out.println("RDUtil ::::::::::: formName : " + formName);
		 System.out.println("RDUtil ::::::::::: data : " + data);
		 System.out.println("RDUtil ::::::::::: receiverJumin : " + receiverJumin);
		 System.out.println("RDUtil ::::::::::: receiverNm : " + receiverNm);
		 System.out.println("RDUtil ::::::::::: receiverAddr : " + receiverAddr);
		 System.out.println("RDUtil ::::::::::: copyYn : " + copyYn);
		 System.out.println("RDUtil ::::::::::: senderId : " + senderId);
		 System.out.println("RDUtil ::::::::::: poliNo : " + poliNo);
		
		
		CuCounVO cJoinVo = new CuCounVO();
		HttpURLConnection conn = null;
		InputStream is ;

		String TYPE_GB = type;//"2";	// FAX = 2, Mail = 3
		String Form_ID = formId;//"UC31";	//  장기 출력폼
		//String Form_ID = "UG74";//"UC31";	//  장기 출력폼
		String prt_data = data;//"2986561-031015";
		//Form_ID = args[0];
		//TYPE_GB = args[1];
		

		// 고객센터 로그 연동
		java.util.Date currentdate = new java.util.Date();
		java.text.SimpleDateFormat format = new java.text.SimpleDateFormat("yyyyMMddHHmmss");
		
		cJoinVo.cust_jumin = receiverJumin;
		cJoinVo.sangdamil_date = format.format(currentdate);
		cJoinVo.upmu_desc1 = "증명서";
		cJoinVo.upmu_desc2 = jobGbn.equals("01") ? "자동차보험" : (jobGbn.equals("03") ? "일반보험" : "장기보험");
		cJoinVo.upmu_desc3 = formName;
		cJoinVo.poliNo = poliNo;
		cJoinVo.sendNote = type.equals("2") ? "FAX" : "이메일";
		
		//주민등록번호 앞 6자리 비밀번호 셋팅
		String tmpStr = receiverJumin.substring(0, 6);
		System.out.println("Encrypt_Key tmpStr : " + tmpStr);
//		// System.out.println("RDUtil ::::::::::: cJoinVo : " + cJoinVo);
		
//		// System.out.println("data ::::::::::::::: " + data);
		try {
		    URL url = new URL(rdUrl);
		    //URL url = new URL("http://10.10.88.81:9110/RDServer/tps.jsp");	//- TEST
		    //URL url = new URL(Env.getSiteConfig("RD_SERVER"));	// - semi
		    //URL url = new URL("http://210.124.234.49:9110/RDServer/tps.jsp");	// - Prod
			InetAddress ip = InetAddress.getLocalHost();

		     System.out.println("RD URL ::::::::::::::::::::::: " + url);
		    
		    conn = (HttpURLConnection)url.openConnection();
		    conn.setUseCaches(false);
		    conn.setDoOutput(true);
		    conn.setDoInput(true);
		    conn.setRequestMethod("POST");
		    conn.connect();

		    StringBuffer taskparambuffer = new StringBuffer();
		    taskparambuffer.append("Type_Gb=" + TYPE_GB + "&");	//email/fax 구분
		    taskparambuffer.append("Key_No=&");
		    taskparambuffer.append("Encrypt_Yn=Y&");
		    taskparambuffer.append("Encrypt_Key="+ tmpStr +"&");
		    taskparambuffer.append("Upmu_Gb="+ jobGbn +"&");
		    taskparambuffer.append("Docu_Gb="+ docuGbn +"&");
		    taskparambuffer.append("Mail_Change_YN=N&"); 							//default value "N"
		    taskparambuffer.append("Form_Id=" + Form_ID + "&");
		    taskparambuffer.append("Form_Nm="+ formName +"&");			//폼이름 : 테스트
		    taskparambuffer.append("User_Id="+ senderId +"&");	//F1110475 장기 , F1090371 자동차
		    taskparambuffer.append("System_Gb=HCM&");
		    if(TYPE_GB.equals("2")) taskparambuffer.append("Mail_System_Gb=RDON&"); 
		    else taskparambuffer.append("Mail_System_Gb=XRDON&");
		    taskparambuffer.append("Ad_Dept=&");
		    taskparambuffer.append("Green_Yn=N&");
		    taskparambuffer.append("I_Policy_Yn=N&");
		    taskparambuffer.append("Agreement_Nm=&");
		    taskparambuffer.append("Title="+URLEncoder.encode("DB손해보험 " + formName, "utf-8")+"&");
		    taskparambuffer.append("Message="+URLEncoder.encode("", "utf-8")+"&");
		    taskparambuffer.append("Sender_Nm="+URLEncoder.encode("DB손해보험", "utf-8")+"&");		//2011.04.04 encode 추가		    
		    if(TYPE_GB.equals("2")) taskparambuffer.append("Sender_Addr=05051810037&"); //대표 fax, email 받기
		    else taskparambuffer.append("Sender_Addr=idbins@dbins.net&"); //대표 fax, email 받기
		    taskparambuffer.append("Receiver_Nm="+URLEncoder.encode(receiverNm, "utf-8")+"&");		//2011.04.04 encode 추가
		    taskparambuffer.append("Receiver_Addr="+ receiverAddr +"&");	//입력된파라미터
		    taskparambuffer.append("Sender_Dc1=&");
		    taskparambuffer.append("Sender_Dc2=&");
		    taskparambuffer.append("Sender_Dc3=&");
//		    taskparambuffer.append("Client_IP="+ Env.getSiteConfig("SERVER_IP") +"&");
		    taskparambuffer.append("Client_IP="+ ip.getHostAddress() +"&");
		    taskparambuffer.append("Barcd=&");
		    taskparambuffer.append("Intranet_Yn=Y&");
		    
		    taskparambuffer.append("Copy_YN="+ copyYn +"&");	//위변조 방지 마크 여부 폼아이디마다 분기해야함....
		    taskparambuffer.append("Sign_Key=&");
		    taskparambuffer.append("Dummy_01=&");
		    taskparambuffer.append("Dummy_02=&");
		    taskparambuffer.append("Dummy_03=&");
		    taskparambuffer.append("Dummy_04=&");
		    taskparambuffer.append("Dummy_05=");

		    String taskparam = taskparambuffer.toString();
		    String mrdparam = "/riprnmargin"; 	
		   String mrdparamAdd = "|/riprnmargin";	
		    //위변조체크가 Y 경우 /runifiedhangul 추가
		    if(copyYn.equals("Y")){
		    	mrdparam = "/riprnmargin /runifiedhangul";
		    	mrdparamAdd = "|/riprnmargin /runifiedhangul";
		    }
		    
		    StringBuffer requestparambuffer = new StringBuffer();
		    requestparambuffer.append("taskparam="+URLEncoder.encode(taskparam, "utf-8")+"&");		
		    requestparambuffer.append("mrdparam="+URLEncoder.encode(mrdparam, "utf-8"));  			
		    		    
		    String [] fomids = formId.split("\\|");
		    if(fomids.length > 1)
		    {
		    	
		        for(int i = 1; i < fomids.length; i++)
		        {
		            requestparambuffer.append(URLEncoder.encode(mrdparamAdd, "utf-8"));	
		        }
		    }
		    requestparambuffer.append("&");
		  

		    requestparambuffer.append("rdata="+URLEncoder.encode(prt_data.trim(), "utf-8")+"&");	
		  

		    String requestparam = requestparambuffer.toString();
		    
		    

		    OutputStream os = conn.getOutputStream();
		    os.write(requestparam.getBytes("utf-8"));	
		    os.flush();
		    os.close();

		    ByteArrayOutputStream baos = new ByteArrayOutputStream();
		     System.out.println("baos :: " + new String(baos.toByteArray()));
		    
		    is = conn.getInputStream();
	      	int tmp = 0 ;
	      	int i = 0;
	      	while ((tmp = is.read()) != -1)
	      	{
	      		i ++;
	    	  baos.write(tmp);
	      	}
	      	
	      	String prt_rtncode = "";
	      	String prt_rtnmsg = "";
	      	
	      	System.out.println("=================에러로그 저장전============ : ");
			//에러로그저장
	      	if(!(new String(baos.toByteArray())).equals("100")){
//	      		insertErrorLog(receiverJumin, receiverNm, "", "[" + formName + "]" + baos);
	      		System.out.println("RD에러 : " + (new String(baos.toByteArray())));
	      		
	      		// 고객센터 로그 연동
	      		mobileHisSend(cJoinVo, "실패", ccUrl);
//	      		BizUtil.sendLog(cJoinVo, "실패");
				
	      		return false;
	      	}
	      	
	      	
	      	
	      	// System.out.println("baos :: " + new String(baos.toByteArray()));
	      	int rtn_len = new String(baos.toByteArray()).length();

	      	if ( rtn_len == 3){
	      		prt_rtncode = new String(baos.toByteArray()).substring(0, 3);
	      	}else{
	      		prt_rtncode = new String(baos.toByteArray()).substring(0, 3);
	      		prt_rtnmsg = new String(baos.toByteArray()).substring(5);
	      	}
	      	System.out.println("=================RD서버 열고 닫고 전입니다.============ : ");
			is.close();
			conn.disconnect();
			System.out.println("=================RD서버 열고 닫고 성공============ : ");
			// 고객센터 로그 연동
			mobileHisSend(cJoinVo, "성공", ccUrl);
//			BizUtil.sendLog(cJoinVo, "성공");
			
		}catch(Exception e){
			
			// 고객센터 로그 연동
			mobileHisSend(cJoinVo, "실패", ccUrl);
//			BizUtil.sendLog(cJoinVo, "실패");
			
			//에러로그저장
//			insertErrorLog(receiverJumin, receiverNm, "", formName); 
			e.printStackTrace();
			return false;
		}
		System.out.println("=================RDUtil end============ : ");
		return true;
	}
	
	//고객센터 로그 연동
	public static void mobileHisSend(
		CuCounVO cJoinVo
		, String status
		, String ccUrl
	)
	{
		
		try {
			// 고객센터 로그 연동
			cJoinVo.status = status;
			BizUtil.sendLog(cJoinVo, "AUTHENTICATION", ccUrl); // 로그 기록
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}	
	
}
