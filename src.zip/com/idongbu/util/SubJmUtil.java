package com.idongbu.util;

import java.util.ArrayList;
import java.util.List;

import com.idongbu.smartcustomer.vo.SubFGZ5915SVO;
import com.idongbu.smartcustomer.vo.SubFGZ5916STBLVO;
import com.idongbu.smartcustomer.vo.SubFGZ5916SVO;
import com.idongbu.smartcustomer.vo.SubFGZ5917STBLVO;
import com.idongbu.smartcustomer.vo.SubFGZ5917SVO;
import com.idongbu.smartcustomer.vo.SubFGZ5920STBLVO;
import com.idongbu.smartcustomer.vo.SubFGZ5920SVO;

public class SubJmUtil {


	/* 한개의 String 데이터를 FGZ5915S 서브전문 형식으로 parsing */
	public static SubFGZ5915SVO getFGZ5915SVO(String str) 
	{
		return getFGZ5915SVO(str, 0);
	}
	
	public static SubFGZ5915SVO getFGZ5915SVO(String str, int gubun) 
	{
		System.out.println("getFGZ5915SVO Start!");

		//항목별 길이(byte) 정의
		int[] arr = {
				30 ,      //LK_BJ_NM
				40 ,      //LK_BOHUM_GIGAN_NM
				8  ,      //LK_BOHUM_SYMD
				8  ,      //LK_BOHUM_EYMD
				40 ,      //LK_GYEY_NM
				120,      //LK_GYEY_ADDR
				160,      //LK_GYEY_GITA
				15 ,      //LK_NAPIP_PRM
				58 ,      //LK_GAIP1_NM -- 길이가변적임
				10 ,      //LK_BUNNAP_NM
				6  ,      //LK_L_NAPIP_YM
				10 ,      //LK_ILBAN
				2  ,      //LK_FIL
				10 ,      //LK_YAKGWAN
				12 ,      //LK_JOJIKWON_NM
				12 ,      //LK_JOJIKWON_TEL
				10 ,      //LK_SANGTE_NM
				40 ,      //LK_PIBO_NM
				4  ,      //LK_L_NAPIP_CNT
				1  ,      //LK_HEJI_YN
				13        //LK_PIBO_CD
		};
		
		SubFGZ5915SVO vo = new SubFGZ5915SVO();
		int sIdx = 0;		//잘라낼 문자 시작 index
		int eIdx = 0;		//잘라낼 문자 끝 index
		int asc = 0;		//문자아스키코드
		int byteCnt  = 0;	//바이트 카운팅
		int arrCnt = 0;
		boolean hanConti = false;	//연속된 한글 진행중인지 여부
		String temp = "";
		String temp2 = "";
		
		if ( StringUtil.isEmpty(str) ) return vo;

		int strLen = str.length();

		System.out.println("#### 서브전문 FGZ5915S 파싱 처리 ####");
		System.out.println("str : " + str);
		System.out.println("strLen : " + strLen);
		
		for ( int i=0; i < strLen; i++ )
		{
			// 전문이 전달받은 레이아웃의 길이를 초과하는 경우
			if (arrCnt >= arr.length) {
				break;
			}
			
			asc = (int) str.charAt(i);

			//주택화재플랜
			if(arrCnt == 8 && gubun == 1) {
				temp += str.charAt(i);
				if("주택화재플랜".equals(temp)) {
					arr[arrCnt] = 54;
					temp2 = temp;
				}
				if("순수연금".equals(temp)) arr[arrCnt] = 54;
				if("순수연금형".equals(temp)) arr[arrCnt] = 58;
				
				if("주택화재플랜".equals(temp2)) {
					if(asc < 127) arr[arrCnt] = 58;
				}
			}
			
			
			//한글이면 2바이트 증가
			if (asc > 127) {
				if ( !hanConti ) { 	//한글 처음 나오면 2바이트 추가
					byteCnt = byteCnt + 2;
					hanConti = true;

					// LK_GAIP1_NM값이 한글일때 54바이트로 오는 문제 때문에 수정
					// 해당값 길이가 가변적이라...꼭 54로 오지도 않고 해서 수정
					if(arrCnt == 8 && gubun == 0) {
						arr[arrCnt] = 54;
					}
				}
				byteCnt = byteCnt + 2;
			} else {
				byteCnt++;
				hanConti = false;
			}

			//바이트수가 배열값만큼 진행되면
			if ( byteCnt >= arr[arrCnt] ) {
				eIdx = i + 1;
				
				//VO에 값 넣음
				if ( arrCnt == 0 ) vo.setLK_BJ_NM( StringUtil.strSpaceTrim( str.substring(sIdx, eIdx) ) );
				if ( arrCnt == 1 ) vo.setLK_BOHUM_GIGAN_NM( StringUtil.strSpaceTrim( str.substring(sIdx, eIdx) ) );
				if ( arrCnt == 2 ) vo.setLK_BOHUM_SYMD( StringUtil.strSpaceTrim( str.substring(sIdx, eIdx) ) );
				if ( arrCnt == 3 ) vo.setLK_BOHUM_EYMD( StringUtil.strSpaceTrim( str.substring(sIdx, eIdx) ) );
				if ( arrCnt == 4 ) vo.setLK_GYEY_NM( StringUtil.strSpaceTrim( str.substring(sIdx, eIdx) ) );
				if ( arrCnt == 5 ) vo.setLK_GYEY_ADDR( StringUtil.strSpaceTrim( str.substring(sIdx, eIdx) ) );
				if ( arrCnt == 6 ) vo.setLK_GYEY_GITA( StringUtil.strSpaceTrim( str.substring(sIdx, eIdx) ) );
				if ( arrCnt == 7 ) vo.setLK_NAPIP_PRM( StringUtil.strSpaceTrim( str.substring(sIdx, eIdx) ) );
				if ( arrCnt == 8 ) vo.setLK_GAIP1_NM( StringUtil.strSpaceTrim( str.substring(sIdx, eIdx) ) );
				if ( arrCnt == 9 ) vo.setLK_BUNNAP_NM( StringUtil.strSpaceTrim( str.substring(sIdx, eIdx) ) );
				if ( arrCnt == 10 ) vo.setLK_L_NAPIP_YM( StringUtil.strSpaceTrim( str.substring(sIdx, eIdx) ) );
				if ( arrCnt == 11 ) vo.setLK_ILBAN( StringUtil.strSpaceTrim( str.substring(sIdx, eIdx) ) );
				if ( arrCnt == 12 ) vo.setLK_FIL( StringUtil.strSpaceTrim( str.substring(sIdx, eIdx) ) );
				if ( arrCnt == 13 ) vo.setLK_YAKGWAN( StringUtil.strSpaceTrim( str.substring(sIdx, eIdx) ) );
				if ( arrCnt == 14 ) vo.setLK_JOJIKWON_NM( StringUtil.strSpaceTrim( str.substring(sIdx, eIdx) ) );
				if ( arrCnt == 15 ) vo.setLK_JOJIKWON_TEL( StringUtil.strSpaceTrim( str.substring(sIdx, eIdx) ) );
				if ( arrCnt == 16 ) vo.setLK_SANGTE_NM( StringUtil.strSpaceTrim( str.substring(sIdx, eIdx) ) );
				if ( arrCnt == 17 ) vo.setLK_PIBO_NM( StringUtil.strSpaceTrim( str.substring(sIdx, eIdx) ) );
				if ( arrCnt == 18 ) vo.setLK_L_NAPIP_CNT( StringUtil.strSpaceTrim( str.substring(sIdx, eIdx) ) );
				if ( arrCnt == 19 ) vo.setLK_HEJI_YN( StringUtil.strSpaceTrim( str.substring(sIdx, eIdx) ) );
				if ( arrCnt == 20 ) vo.setLK_PIBO_CD( StringUtil.strSpaceTrim( str.substring(sIdx, eIdx) ) );

				arrCnt++;
				sIdx = eIdx;
				byteCnt = 0;
				hanConti = false;
			}

		}
/*
		System.out.println("getFGZ5915SVO Start2!");
		
		//항목별 길이(byte) 정의
		int[] arr2 = {
				13 ,      //LK_PIBO_CD
				1  ,      //LK_HEJI_YN
				4  ,      //LK_L_NAPIP_CNT
				40 ,      //LK_PIBO_NM
				10 ,      //LK_SANGTE_NM
				12 ,      //LK_JOJIKWON_TEL
				12 ,      //LK_JOJIKWON_NM
				10 ,      //LK_YAKGWAN
				2  ,      //LK_FIL
				10 ,      //LK_ILBAN
				6  ,      //LK_L_NAPIP_YM
				10 ,      //LK_BUNNAP_NM
				58 ,      //LK_GAIP1_NM -- 길이가변적임
				15 ,      //LK_NAPIP_PRM
				160,      //LK_GYEY_GITA
				120,      //LK_GYEY_ADDR
				40 ,      //LK_GYEY_NM
				8  ,      //LK_BOHUM_EYMD
				8  ,      //LK_BOHUM_SYMD
				40 ,      //LK_BOHUM_GIGAN_NM
				30 ,      //LK_BJ_NM
		};

		String str2 = ( new StringBuffer(str) ).reverse().toString();
		
		sIdx = 0;		//잘라낼 문자 시작 index
		eIdx = 0;		//잘라낼 문자 끝 index
		asc = 0;		//문자아스키코드
		byteCnt  = 0;	//바이트 카운팅
		arrCnt = 0;
		hanConti = false;	//연속된 한글 진행중인지 여부
		
		if( StringUtil.isEmpty(str2) ) return vo;

		strLen = str2.length();

		System.out.println("#### 서브전문 FGZ5915S 파싱 처리2 ####");
		System.out.println("str2 : " + str2);
		System.out.println("strLen : " + strLen);
		
		for( int i=0; i < strLen; i++ ) {
			// 전문이 전달받은 레이아웃의 길이를 초과하는 경우
			if(arrCnt >= arr2.length) {
				break;
			}
			
			asc = (int) str2.charAt(i);

			//한글이면 2바이트 증가
			if(asc > 127) {
				if( !hanConti ) { 	//한글 처음 나오면 2바이트 추가
					byteCnt = byteCnt + 2;
					hanConti = true;

					if(arrCnt == 12) {
						arr2[arrCnt] = 54;
					}
				}
				byteCnt = byteCnt + 2;
			} else {
				byteCnt++;
				hanConti = false;
			}

			//바이트수가 배열값만큼 진행되면
			if( byteCnt >= arr2[arrCnt] ) {
				eIdx = i + 1;
				
				//VO에 값 넣음
				//(new StringBuffer(str2.substring(sIdx, eIdx))).reverse().toString()
				
				if ( arrCnt == 0 ) vo.setLK_PIBO_CD( StringUtil.strSpaceTrim( (new StringBuffer(str2.substring(sIdx, eIdx))).reverse().toString() ) );
				if ( arrCnt == 1 ) vo.setLK_HEJI_YN( StringUtil.strSpaceTrim( (new StringBuffer(str2.substring(sIdx, eIdx))).reverse().toString() ) );
				if ( arrCnt == 2 ) vo.setLK_L_NAPIP_CNT( StringUtil.strSpaceTrim( (new StringBuffer(str2.substring(sIdx, eIdx))).reverse().toString() ) );
				if ( arrCnt == 3 ) vo.setLK_PIBO_NM( StringUtil.strSpaceTrim( (new StringBuffer(str2.substring(sIdx, eIdx))).reverse().toString() ) );
				if ( arrCnt == 4 ) vo.setLK_SANGTE_NM( StringUtil.strSpaceTrim( (new StringBuffer(str2.substring(sIdx, eIdx))).reverse().toString() ) );
				if ( arrCnt == 5 ) vo.setLK_JOJIKWON_TEL( StringUtil.strSpaceTrim( (new StringBuffer(str2.substring(sIdx, eIdx))).reverse().toString() ) );
				if ( arrCnt == 6 ) vo.setLK_JOJIKWON_NM( StringUtil.strSpaceTrim( (new StringBuffer(str2.substring(sIdx, eIdx))).reverse().toString() ) );
				if ( arrCnt == 7 ) vo.setLK_YAKGWAN( StringUtil.strSpaceTrim( (new StringBuffer(str2.substring(sIdx, eIdx))).reverse().toString() ) );
				if ( arrCnt == 8 ) vo.setLK_FIL( StringUtil.strSpaceTrim( (new StringBuffer(str2.substring(sIdx, eIdx))).reverse().toString() ) );
				if ( arrCnt == 9 ) vo.setLK_ILBAN( StringUtil.strSpaceTrim( (new StringBuffer(str2.substring(sIdx, eIdx))).reverse().toString() ) );
				if ( arrCnt == 10 ) vo.setLK_L_NAPIP_YM( StringUtil.strSpaceTrim( (new StringBuffer(str2.substring(sIdx, eIdx))).reverse().toString() ) );
				if ( arrCnt == 11 ) vo.setLK_BUNNAP_NM( StringUtil.strSpaceTrim( (new StringBuffer(str2.substring(sIdx, eIdx))).reverse().toString() ) );
				if ( arrCnt == 12 ) vo.setLK_GAIP1_NM( StringUtil.strSpaceTrim( (new StringBuffer(str2.substring(sIdx, eIdx))).reverse().toString() ) );

				arrCnt++;
				sIdx = eIdx;
				byteCnt = 0;
				hanConti = false;
			}

		}
*/

		return vo;
	}

	/* 한개의 String 데이터를 FGZ5916S 서브전문 형식으로 parsing */ 
	public static SubFGZ5916SVO getFGZ5916SVO(String str) 
	{
		System.out.println("getFGZ5916SVO Start!");

		//항목별 길이(byte) 정의
		int[] arr = {
				30  ,      //LK_BJ_NM
				3190,      //LK_GZ5916_TBL : 55*(3+40+15)
				192 ,      //LK_FIL
				13  ,      //LK_PIBO_CD
				2861       //LK_FIL2
		};

		SubFGZ5916SVO vo = new SubFGZ5916SVO();
		int sIdx = 0;		//잘라낼 문자 시작 index
		int eIdx = 0;		//잘라낼 문자 끝 index
		int asc = 0;		//문자아스키코드
		int byteCnt  = 0;	//바이트 카운팅
		int arrCnt = 0;
		boolean hanConti = false;	//연속된 한글 진행중인지 여부
		
		if ( StringUtil.isEmpty(str) ) return vo;

		int strLen = str.length();

		System.out.println("#### 서브전문 FGZ5916S 파싱 처리 ####");
		System.out.println("str : " + str);
		System.out.println("strLen : " + strLen);
		
		for ( int i=0; i < strLen; i++ )
		{
			if (arrCnt >= arr.length) {
				break;
			}			
			
			asc = (int) str.charAt(i);

			//한글이면 2바이트 증가
			if (asc > 127) {
				if ( !hanConti ) { 	//한글 처음 나오면 2바이트 추가
					byteCnt = byteCnt + 2;
					hanConti = true;
				}
				byteCnt = byteCnt + 2;
			} else {
				byteCnt++;
				hanConti = false;
			}

			//바이트수가 배열값만큼 진행되면
			if ( byteCnt >= arr[arrCnt] ) {
				eIdx = i + 1;
				
				//VO에 값 넣음
				if ( arrCnt == 0 ) vo.setLK_BJ_NM( StringUtil.strSpaceTrim( str.substring(sIdx, eIdx) ) );
				if ( arrCnt == 1 ) {
					//배열 데이터 List로 구함
					String strTbl = str.substring(sIdx, eIdx);
					vo.setLK_GZ5916_TBL( getFGZ5916STBLVO(strTbl) );
				}
				if ( arrCnt == 2 ) vo.setLK_FIL( StringUtil.strSpaceTrim( str.substring(sIdx, eIdx) ) );
				if ( arrCnt == 3 ) vo.setLK_PIBO_CD( StringUtil.strSpaceTrim( str.substring(sIdx, eIdx) ) );
				if ( arrCnt == 4 ) vo.setLK_FIL2( StringUtil.strSpaceTrim( str.substring(sIdx, eIdx) ) );

				arrCnt++;
				sIdx = eIdx;
				byteCnt = 0;
				hanConti = false;
			}

		}

		return vo;
	}
	
	/* FGZ5916S 내의 배열데이터를 FGZ5916STBL 리스트로 만듦 */ 
	public static List<SubFGZ5916STBLVO> getFGZ5916STBLVO(String str) 
	{
		System.out.println("getFGZ5916STBLVO Start!");
		System.out.println("######str=##################"+str);

		//항목별 길이(byte) 정의
		int[] arr = {
				3  ,      //LK_DAMBO_CD
				40 ,      //LK_DAMBO_NM
				15        //LK_GAIP_GMEK
		};

		SubFGZ5916STBLVO vo = new SubFGZ5916STBLVO();
		List<SubFGZ5916STBLVO> listvo = new ArrayList<SubFGZ5916STBLVO>();
		int sIdx = 0;		//잘라낼 문자 시작 index
		int eIdx = 0;		//잘라낼 문자 끝 index
		int asc = 0;		//문자아스키코드
		int byteCnt  = 0;	//바이트 카운팅
		int lineByteCnt = 0;	//배열 한줄 바이트 카운팅
		int arrCnt = 0;
		boolean hanConti = false;	//연속된 한글 진행중인지 여부

		int lineByteTotal = 0;	//배열 한줄 총바이트수
		for ( int i=0; i < arr.length; i++ ) {
			lineByteTotal += arr[i];
		}
	
		if ( StringUtil.isEmpty(str) ) return listvo;

		int strLen = str.length();

		System.out.println("#### 서브전문 FGZ5916STBL 파싱 처리 ####");
		System.out.println("str : " + str);
		System.out.println("strLen : " + strLen);
		
		for ( int i=0; i < strLen; i++ )
		{
			if (arrCnt >= arr.length) {
				break;
			}			
			
			asc = (int) str.charAt(i);

			//한글이면 2바이트 증가
			if (asc > 127) {
				if ( !hanConti ) { 	//한글 처음 나오면 2바이트 추가
					byteCnt = byteCnt + 2;
					lineByteCnt = lineByteCnt + 2;
					hanConti = true;
				}
				byteCnt = byteCnt + 2;
				lineByteCnt = lineByteCnt + 2;
			} else {
				byteCnt++;
				lineByteCnt++;
				hanConti = false;
			}

			//바이트수가 배열값만큼 진행되면
			if ( byteCnt >= arr[arrCnt] ) {
				eIdx = i + 1;
				
				//VO에 값 넣음
				if ( arrCnt == 0 ) {
					vo = new SubFGZ5916STBLVO();
					vo.setLK_DAMBO_CD( StringUtil.strSpaceTrim( str.substring(sIdx, eIdx) ) );
				}
				if ( arrCnt == 1 ) vo.setLK_DAMBO_NM( StringUtil.strSpaceTrim( str.substring(sIdx, eIdx) ) );
				if ( arrCnt == 2 ) vo.setLK_GAIP_GMEK( StringUtil.strSpaceTrim( str.substring(sIdx, eIdx) ) );

				arrCnt++;
				sIdx = eIdx;
				byteCnt = 0;
			}
			
			//배열 한라인만큼 진행되면 listvo에 vo 입력
			if ( lineByteCnt >= lineByteTotal ) {
				listvo.add(vo);
				arrCnt = 0;
				lineByteCnt = 0;
				hanConti = false;
			}

		}

		return listvo;
	}

	

	/* 한개의 String 데이터를 FGZ5917S 서브전문 형식으로 parsing */ 
	public static SubFGZ5917SVO getFGZ5917SVO(String str) 
	{
		System.out.println("getFGZ5917SVO Start!");

		//항목별 길이(byte) 정의
		int[] arr = {
				30  ,      //LK_BJ_NM
				14, 2, 20, 20, 40, 104,	//LK_GZ5917_TBL[0]
				14, 2, 20, 20, 40, 104,	//LK_GZ5917_TBL[1]
				14, 2, 20, 20, 40, 104,	//LK_GZ5917_TBL[2]
				14, 2, 20, 20, 40, 104,	//LK_GZ5917_TBL[3]
				14, 2, 20, 20, 40, 104,	//LK_GZ5917_TBL[4]
				14, 2, 20, 20, 40, 104,	//LK_GZ5917_TBL[5]
				14, 2, 20, 20, 40, 104,	//LK_GZ5917_TBL[6]
				14, 2, 20, 20, 40, 104,	//LK_GZ5917_TBL[7]
				14, 2, 20, 20, 40, 104,	//LK_GZ5917_TBL[8]
				14, 2, 20, 20, 40, 104,	//LK_GZ5917_TBL[9]
				14, 2, 20, 20, 40, 104,	//LK_GZ5917_TBL[10]
				14, 2, 20, 20, 40, 104,	//LK_GZ5917_TBL[11]
				14, 2, 20, 20, 40, 104,	//LK_GZ5917_TBL[12]
				14, 2, 20, 20, 40, 104,	//LK_GZ5917_TBL[13]
				14, 2, 20, 20, 40, 104,	//LK_GZ5917_TBL[14]
				440        //LK_FIL
		};

		SubFGZ5917SVO vo = new SubFGZ5917SVO();

		SubFGZ5917STBLVO voTbl = new SubFGZ5917STBLVO();
		List<SubFGZ5917STBLVO> listvoTbl = new ArrayList<SubFGZ5917STBLVO>();
		
		int sIdx = 0;		//잘라낼 문자 시작 index
		int eIdx = 0;		//잘라낼 문자 끝 index
		int asc = 0;		//문자아스키코드
		int byteCnt  = 0;	//바이트 카운팅
		int arrCnt = 0;
		int arrTblCnt = 0;
		boolean hanConti = false;	//연속된 한글 진행중인지 여부
		
		if ( StringUtil.isEmpty(str) ) return vo;

		int strLen = str.length();

		System.out.println("#### 서브전문 FGZ5917S 파싱 처리 ####");
		System.out.println("str : " + str);
		System.out.println("strLen : " + strLen);
		
		for ( int i=0; i < strLen; i++ )
		{
			if (arrCnt >= arr.length) {
				break;
			}			
			
			asc = (int) str.charAt(i);

			//한글이면 2바이트 증가
			if (asc > 127) {
				if ( !hanConti ) { 	//한글 처음 나오면 2바이트 추가
					byteCnt = byteCnt + 2;
					hanConti = true;
				}
				byteCnt = byteCnt + 2;
			} else {
				byteCnt++;
				hanConti = false;
			}

			//바이트수가 배열값만큼 진행되면
			if ( byteCnt >= arr[arrCnt] || i == (strLen-1)) {
				eIdx = i + 1;
				
				//VO에 값 넣음
				if ( arrCnt == 0 ) vo.setLK_BJ_NM( StringUtil.strSpaceTrim( str.substring(sIdx, eIdx) ) );
				
				if ( arrCnt >= 1 && arrCnt <= 90 ) {
					//LIST VO에 값 넣음
					if ( arrTblCnt == 0 ) {
						voTbl = new SubFGZ5917STBLVO();
						voTbl.setLK_BUNNAP_NM( StringUtil.strSpaceTrim( str.substring(sIdx, eIdx) ) );
					}
					if ( arrTblCnt == 1 ) voTbl.setLK_ICHE_DD( StringUtil.strSpaceTrim( str.substring(sIdx, eIdx) ) );
					if ( arrTblCnt == 2 ) voTbl.setLK_BANK_NM( StringUtil.strSpaceTrim( str.substring(sIdx, eIdx) ) );
					if ( arrTblCnt == 3 ) voTbl.setLK_GYEJWA_NO( StringUtil.strSpaceTrim( str.substring(sIdx, eIdx) ) );
					if ( arrTblCnt == 4 ) voTbl.setLK_YEGMJU_NM( StringUtil.strSpaceTrim( str.substring(sIdx, eIdx) ) );
					if ( arrTblCnt == 5 ) voTbl.setLK_SUGUM_FIL( StringUtil.strSpaceTrim( str.substring(sIdx, eIdx) ) );
					
					arrTblCnt++;
					
					if ( arrTblCnt == 6 ) { 
						listvoTbl.add(voTbl);
						arrTblCnt = 0;
					}
				}

				if ( arrCnt == 91 ) vo.setLK_FIL( StringUtil.strSpaceTrim( str.substring(sIdx, eIdx) ) );

				arrCnt++;
				sIdx = eIdx;
				byteCnt = 0;
				hanConti = false;
			}

		}
		
		//전문이 중간에 잘린경우 마지막 voTbl를 list에 넣음
		if ( arrTblCnt < 6 ) {
			listvoTbl.add(voTbl);
		}
		
		//listVO를 vo에 넣음
		vo.setLK_GZ5917_TBL(listvoTbl);

		return vo;
	}
	

	

	/* 한개의 String 데이터를 FGZ5920S 서브전문 형식으로 parsing */ 
	public static SubFGZ5920SVO getFGZ5920SVO(String str) 
	{
		System.out.println("getFGZ5920SVO Start!");

		//항목별 길이(byte) 정의
		int[] arr = {
				456 ,      //LK_GZ5920_TBL : 12*(3+10+6+8+11)
				11         //LK_SUM_BUNNAP
		};

		SubFGZ5920SVO vo = new SubFGZ5920SVO();
		int sIdx = 0;		//잘라낼 문자 시작 index
		int eIdx = 0;		//잘라낼 문자 끝 index
		int asc = 0;		//문자아스키코드
		int byteCnt  = 0;	//바이트 카운팅
		int arrCnt = 0;
		boolean hanConti = false;	//연속된 한글 진행중인지 여부
		
		if ( StringUtil.isEmpty(str) ) return vo;

		int strLen = str.length();

		System.out.println("#### 서브전문 FGZ5920S 파싱 처리 ####");
		System.out.println("str : " + str);
		System.out.println("strLen : " + strLen);
		
		for ( int i=0; i < strLen; i++ )
		{
			if (arrCnt >= arr.length) {
				break;
			}			
			
			asc = (int) str.charAt(i);

			//한글이면 2바이트 증가
			if (asc > 127) {
				if ( !hanConti ) { 	//한글 처음 나오면 2바이트 추가
					byteCnt = byteCnt + 2;
					hanConti = true;
				}
				byteCnt = byteCnt + 2;
			} else {
				byteCnt++;
				hanConti = false;
			}

			//바이트수가 배열값만큼 진행되면
			if ( byteCnt >= arr[arrCnt] ) {
				eIdx = i + 1;
				
				//VO에 값 넣음
				if ( arrCnt == 0 ) {
					//배열 데이터 List로 구함
					String strTbl = str.substring(sIdx, eIdx);
					vo.setLK_GZ5920_TBL( getFGZ5920STBLVO(strTbl) );
				}
				if ( arrCnt == 1 ) vo.setLK_SUM_BUNNAP( StringUtil.strSpaceTrim( str.substring(sIdx, eIdx) ) );

				arrCnt++;
				sIdx = eIdx;
				byteCnt = 0;
				hanConti = false;
			}

		}

		return vo;
	}
	
	/* FGZ5920S 내의 배열데이터를 FGZ5920STBL 리스트로 만듦 */ 
	public static List<SubFGZ5920STBLVO> getFGZ5920STBLVO(String str) 
	{
		System.out.println("getFGZ5920STBLVO Start!");

		//항목별 길이(byte) 정의
		int[] arr = {
				 3 ,      //LK_BUNNAP_CNT
				10 ,      //LK_BANG_CD
				 6 ,      //LK_NAPIP_YM
				 8 ,      //LK_YUNG_YMD
				11        //LK_YUNG_PRM
		};

		SubFGZ5920STBLVO vo = new SubFGZ5920STBLVO();
		List<SubFGZ5920STBLVO> listvo = new ArrayList<SubFGZ5920STBLVO>();
		int sIdx = 0;		//잘라낼 문자 시작 index
		int eIdx = 0;		//잘라낼 문자 끝 index
		int asc = 0;		//문자아스키코드
		int byteCnt  = 0;	//바이트 카운팅
		int lineByteCnt = 0;	//배열 한줄 바이트 카운팅
		int arrCnt = 0;
		boolean hanConti = false;	//연속된 한글 진행중인지 여부

		int lineByteTotal = 0;	//배열 한줄 총바이트수
		for ( int i=0; i < arr.length; i++ ) {
			lineByteTotal += arr[i];
		}
	
		if ( StringUtil.isEmpty(str) ) return listvo;

		int strLen = str.length();

		System.out.println("#### 서브전문 FGZ5920STBL 파싱 처리 ####");
		System.out.println("str : " + str);
		System.out.println("strLen : " + strLen);
		
		for ( int i=0; i < strLen; i++ )
		{
			if (arrCnt >= arr.length) {
				break;
			}			
			
			asc = (int) str.charAt(i);

			//한글이면 2바이트 증가
			if (asc > 127) {
				if ( !hanConti ) { 	//한글 처음 나오면 2바이트 추가
					byteCnt = byteCnt + 2;
					lineByteCnt = lineByteCnt + 2;
					hanConti = true;
				}
				byteCnt = byteCnt + 2;
				lineByteCnt = lineByteCnt + 2;
			} else {
				byteCnt++;
				lineByteCnt++;
				hanConti = false;
			}

			//System.out.println("i[" + i + "] byteCnt[" + byteCnt + "]");

			//바이트수가 배열값만큼 진행되면
			if ( byteCnt >= arr[arrCnt] ) {
				eIdx = i + 1;
				
				//VO에 값 넣음
				if ( arrCnt == 0 ) {
					vo = new SubFGZ5920STBLVO();
					vo.setLK_BUNNAP_CNT( StringUtil.strSpaceTrim( str.substring(sIdx, eIdx) ) );
				}
				if ( arrCnt == 1 ) vo.setLK_BANG_CD( StringUtil.strSpaceTrim( str.substring(sIdx, eIdx) ) );
				if ( arrCnt == 2 ) vo.setLK_NAPIP_YM( StringUtil.strSpaceTrim( str.substring(sIdx, eIdx) ) );
				if ( arrCnt == 3 ) vo.setLK_YUNG_YMD( StringUtil.strSpaceTrim( str.substring(sIdx, eIdx) ) );
				if ( arrCnt == 4 ) vo.setLK_YUNG_PRM( StringUtil.strSpaceTrim( str.substring(sIdx, eIdx) ) );

				arrCnt++;
				sIdx = eIdx;
				byteCnt = 0;
				hanConti = false;
			}
			
			//배열 한라인만큼 진행되면 listvo에 vo 입력
			if ( lineByteCnt >= lineByteTotal ) {
				listvo.add(vo);
				arrCnt = 0;
				lineByteCnt = 0;
			}
		}

		return listvo;
	}
	
	
}
