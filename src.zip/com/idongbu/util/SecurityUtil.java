package com.idongbu.util;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;


public class SecurityUtil {

	private static SecurityUtil instance = null;
	
	public static SecurityUtil getInstance() {
		if(instance == null) {
			instance = new SecurityUtil();
		}
		return instance;	
	}
	

	/**
	 * 수신된 메시지를 클라이언트와  같은 해시 함수를 수행하여  공유 키를 구한다.
	 * @param msg
	 * @return hashValue 
	 */

	private String getSha256Key(String msg) {
		String key = ""; 
		try{
			MessageDigest sh = MessageDigest.getInstance("SHA-256"); 
			sh.update(msg.getBytes()); 
			byte byteData[] = sh.digest();
			StringBuffer sb = new StringBuffer(); 
			for(int i = 0 ; i < byteData.length ; i++){
				sb.append(Integer.toString((byteData[i]&0xff) + 0x100, 16).substring(1));
			}
			key = sb.toString();

		}catch(NoSuchAlgorithmException e){
			e.printStackTrace(); 
			key = null; 
		}
		
		System.out.println("==========================================================================================");
		System.out.println("SecurityUtil KEY[" + key + "]");
		
		return key;
	}
	

	/**
	 * 수신된 메시지와 공유 키를 비교하여 true, false를 리턴한다.
	 * 
	 * @param msg
	 * @param key
	 * @return true, false
	 */

	public boolean isKeyValidate(String msg, String key) {
		boolean flag = false;

		if (key.equals(getSha256Key(msg))){
			System.out.println("getSha256Key(msg):" + getSha256Key(msg));
			flag = true;
		}
		return flag;
	}
	
	public String createMessage(String[] values)
	{
		StringBuffer sb = new StringBuffer();
		for(int i = 0; i < values.length; i++)
		{
			if(null != values[i])
			{
				sb.append(values[i]);
				
				if(i + 1 != values.length)
					sb.append(":");
			}
		}
		
		System.out.println("==========================================================================================");
		System.out.println("SecurityUtil createMessage[" + sb.toString() + "]");
		
		return sb.toString();
	}

}
