package com.idongbu.util;

import java.util.Enumeration;
import java.util.Hashtable;

public class DBLogUtil {

	public static String makeQuery(Hashtable logTable, String sessJumin, String sessCsnm)
	{
		String qry = null;
		String columnQry = null;
		String valuesQry = null;
		
		String tablename = null;
		if ( logTable.get("TABLE") != null ) {
			tablename = (String)logTable.get("TABLE");
		} else if ( logTable.get("table") != null ) {
			tablename = (String)logTable.get("table");
		} else {
			System.out.println("로그 테이블명 없음!");
			return qry;
		}

		
		columnQry = " ( SEQ, REG_DT ";
		valuesQry = " VALUES ( SEQ_" + tablename.trim() + ".NEXTVAL, SYSDATE ";

		if ( logTable.get("JUMIN_NO") == null && 
			 logTable.get("jumin_no") == null &&
			 sessJumin != null ) {

			columnQry += ", JUMIN_NO";
			valuesQry += ", XX1.ENC_VARCHAR2_INS('" + sessJumin + "',10,'PART6')";
		}
		if ( logTable.get("CS_NM") == null &&
			 logTable.get("cs_nm") == null &&
			 sessCsnm != null ) {
			
			columnQry += ", CS_NM";
			valuesQry += ", '" + sessCsnm + "'";
		}
		
		Enumeration e = logTable.keys();
	    String key = "";

	    while(e.hasMoreElements())
	    {
	        key = (String)e.nextElement();
	    	if ( "TABLE".equals(key.toUpperCase()) ) {
	    		continue;
	    	}

	    	//주민번호 암호화 
	    	if ( "JUMIN_NO".equals(key.toUpperCase()) )
	    	{
	    		columnQry += ", " + key;
				valuesQry += ", XX1.ENC_VARCHAR2_INS('" + logTable.get(key) + "',10,'PART6')";
	    	}
	    	//계좌번호 암호화
	    	else if ( key.toUpperCase().indexOf("ACC_NO") > -1 || key.toUpperCase().indexOf("acc_no") > -1 ) 
	    	{
	    		columnQry += ", " + key;
				valuesQry += ", XX1.ENC_VARCHAR2_INS('" + logTable.get(key) + "',10,'ARIA256')";
	    	}
	    	else if ( key.toUpperCase().indexOf("BNK_ACNO") > -1 || key.toUpperCase().indexOf("bnk_acno") > -1 ) 
	    	{
	    		columnQry += ", " + key;
				valuesQry += ", XX1.ENC_VARCHAR2_INS('" + logTable.get(key) + "',10,'ARIA256')";
	    	}
	    	else {
	    		
	    		if ( logTable.get(key) != null && "SYSDATE".equalsIgnoreCase( logTable.get(key).toString() ) ) {
	    			columnQry += ", " + key;
			    	valuesQry += ", SYSDATE";
	    		} else {
			    	columnQry += ", " + key;
			    	valuesQry += ", '" + logTable.get(key) + "'";
	    		}
	    	}
	    }

	    columnQry += ") ";
	    valuesQry += ") ";

	    qry = "INSERT INTO " + tablename + columnQry + valuesQry; 
	    System.out.println("## QUERY:" + qry);
		
		return qry;
	}
	
}
