package com.idongbu.util;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import org.mybatis.spring.SqlSessionTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.idongbu.smartcustomer.vo.SmsVO;
import com.idongbu.util.dao.UtilDao;

public class Sms {
	
	private static Logger logger = LoggerFactory.getLogger(Sms.class);

	public static String getSendDate(){
		Date d = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd",Locale.KOREA);
		return sdf.format(d);
	}

	private static boolean checkValidData(SmsVO vo) {
		if(StringUtil.isEmpty(vo.getSn()))			vo.setSn("1");
		if(StringUtil.isEmpty(vo.getSend_num()))		vo.setSend_num("15880100");
		if(StringUtil.isEmpty(vo.getId()))			vo.setId("SYSTEM");
		if(StringUtil.isEmpty(vo.getSvcname()))		vo.setSvcname("1-HOY");
		if(StringUtil.isEmpty(vo.getSend_date()))	vo.setSend_date(getSendDate());
		if(StringUtil.isEmpty(vo.getSend_name()))	vo.setSend_name("DB손해보험");

		if(StringUtil.isEmpty(vo.getDest_num())) {
			vo.setRetCode(-1);
			vo.setRetMsg("전송할 번호가 없습니다.");
			logger.debug(vo.getRetCode() + ", " + vo.getRetMsg());
		}
		return !(vo.getRetCode()<0);
	}

	/**
	 * 문자발송
	 * @param sMS_PORT2 
	 * @param sMS_IP2 
	 * @param vo
	 * @param isTest 
	 * @return
	 */
	public static SmsVO send(SqlSessionTemplate sqlSession, String SMS_IP, int SMS_PORT, SmsVO vo ,boolean isTest) {
		Sms sock = null;
		
//		 if( !StringUtil.nvl( Env.getSiteConfig("SMS_SEND")).equals("Y") ) return new SmsVO();

		if(isTest) {
			logger.debug("TEST계에서는 개발자한테 문자발송하도록!!!");
//			String dest_num_test = "01042915495";	//이다혜 S
			String dest_num_test = "01025217535";	//최주형 D
			vo.setDest_num(dest_num_test);
		}

		if(!checkValidData(vo)) return vo;

		try {
			logger.debug("SMS 서버: " + SMS_IP + ", " + SMS_PORT);
			sock = new Sms(SMS_IP, SMS_PORT);

			if (!sock.connect()) {
				vo.setRetCode(-1);
				vo.setRetMsg("SMS서버에 연결할 수 없습니다.");
				return vo;
			}
			
			int cntsend = sock.sendString(new String[]{
				vo.getSn(), vo.getDest_num(), vo.getSend_num()
				,vo.getId(), vo.getSvcname(), vo.getSend_date(), vo.getSend_name()
				, vo.getSend_msg()
			}, new int[]{4, 12, 12, 20, 20, 12, 8, 70});
			
			if(cntsend<1) {
				vo.setRetCode(-2);
				vo.setRetMsg("SMS서버로 메세지를 전송할 수 없습니다.");
				return vo;
			}
			String recvstr = sock.recvString(8);
			logger.debug("recvstr : " + recvstr);
			vo.setRes(recvstr.substring(4));
			if(!"0000".equals(vo.getRes())) {
				vo.setRetCode(-3);
				vo.setRetMsg("메세지 전송이 실패하였습니다.(" + vo.getRes() + ")");
				return vo;
			}
			vo.setRetCode(1);
			vo.setRetMsg("메세지 전송이 완료되었습니다.");
		} catch (Throwable e) {
			e.printStackTrace();
			vo.setRetCode(-1);
			vo.setRetMsg("SMS서버에 연결할 수 없습니다.");
			logger.error(e.getMessage(), e);
		} finally {
			if (sock != null){
				sock.colse();
			}
			logger.debug(vo.getRetCode() + ", " + vo.getRetMsg());
			
			UtilDao mapper= sqlSession.getMapper(UtilDao.class);	//모바일 DB mapper
			mapper.insertSmsLog(vo);
//			(new CmmUtilWB()).insertSmsLog(vo);	2차: sms로그 입력
		}
		
		return vo;
	}

	String serverIp			= null;
	int serverPort			= 0;
	int timeOut				= 5 * 1000;	// 5초
	SocketAddress socketAddress;
	Socket socket			= null;
	DataInputStream dis		= null;
	DataOutputStream dos	= null;
	public Sms(String ip, int port) {
		serverIp = ip;
		serverPort = port;
	}
	
	public boolean connect() throws Exception {
		try{
			socketAddress = new InetSocketAddress(serverIp, serverPort);
			socket	= new Socket();
			socket.connect(socketAddress, timeOut);
			socket.setSoTimeout(timeOut);
			dis		= new DataInputStream(socket.getInputStream());
			dos		= new DataOutputStream(socket.getOutputStream());
		}catch(Exception e){
			e.printStackTrace();
			throw e;
		}
		return true;
	}

	public void colse() {
		try {
			if(socket!=null) socket.close();
			if(dis!=null) dis.close();
			if(dos!=null) dos.close();
		} catch (IOException e) {
			 logger.error(e.toString());			
		}
	}

	public int sendString(String[] sendStr, int[] sendSize) throws IOException {
		int cntSend = 0;
		if(sendStr==null || sendStr.length==0)
			return cntSend;

		String dataSend = "";
		for(int i=0; i<sendStr.length; i++) {
			dataSend += fixData(sendStr[i], sendSize[i]);
		}
		
		logger.debug("dataSend : " + dataSend);
		if(socket.isConnected()) {
			dos.write(dataSend.getBytes("EUC-KR"));
			dos.flush();
			cntSend = dataSend.getBytes("EUC-KR").length;
		}
		return cntSend;
	}

	public String recvString(int recvSize) throws IOException {
		if(recvSize < 0){
			return "";
		}
		
		byte[] buffer = new byte[recvSize];
		String result = "";

		result = new String(buffer);
		
		dis.read(buffer);
 
		result = new String(buffer);


		return result;
	}

	public static String fixData(String data, int len) throws UnsupportedEncodingException {
		if(data == null || len < 0){
			return "";
		}
		
		byte[] tempdata = new byte[len];
		byte[] indata = data.getBytes("EUC-KR");
		for (int i = 0; i < len; i++) {
			if (indata.length > i)
				tempdata[i] = indata[i];
			else
				tempdata[i] = 0x20;
		}

		return new String(tempdata, "EUC-KR");
	}

}
