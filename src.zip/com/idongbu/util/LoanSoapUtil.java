package com.idongbu.util;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.lang.reflect.Field;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.HashSet;

import javax.xml.soap.MessageFactory;
import javax.xml.soap.Name;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPBodyElement;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPFactory;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;

import com.idongbu.common.vo.CMMVO;
import com.idongbu.common.XmlUtil;



public class LoanSoapUtil {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	private String getSOAPUrl(boolean isReal) {
		if(isReal) {
			return "http://10.10.100.73:8801/zz.svr.link.eai.ZZEAIRcvServlet";
		}
		else {
			return "http://10.10.88.131:8801/zz.svr.link.eai.ZZEAIRcvServlet";
		}
	}
	
	@SuppressWarnings("rawtypes")
	private static HashSet exHidden = null;	// input값 생성시 제외할 필드명
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private static HashSet getExHidden() {
		HashSet set = new HashSet();
		Field[] fields = new CMMVO().getClass().getFields();
		for(int i=0; i<fields.length; i++) {
			set.add(fields[i].getName());
		}
		return set;
	}
	
	public CMMVO sendToLoan(CMMVO vo, String prgId, boolean isReal) throws Exception {
		logger.debug("##### Loan start.. soap url = " + getSOAPUrl(isReal));

		//입력 VO를 soap표준 xml을 생성한다.
        String makedSoapXml = tranSoapTOStr(makeSoapXML(vo, prgId));
        
        //전문요청 하고 리턴된 xml데이터를 vo에 할당한다.
		xmlToVO(readXML(callLoanWas(makedSoapXml, isReal)), vo, prgId);
		
		logger.debug("##### Loan end.. soap url = " + getSOAPUrl(isReal));
		
		return vo;
	}
	
	//입력받은 VO를 SOAP 표준 XML로 변환한다.
	private SOAPMessage makeSoapXML(CMMVO vo, String prgId) throws Exception {
	    SOAPFactory soapFactory =  SOAPFactory.newInstance();

	    MessageFactory factory = MessageFactory.newInstance();
	    SOAPMessage message = factory.createMessage();
	    
	    //namespace 추가
	    SOAPPart sp = message.getSOAPPart();
	    SOAPEnvelope se = sp.getEnvelope();
	    
	    //se.addNamespaceDeclaration("SOAP-ENC", "http://schemas.xmlsoap.org/soap/encoding/");
	    se.addNamespaceDeclaration("xsd", "http://www.w3.org/2001/XMLSchema");
	    se.addNamespaceDeclaration("xsi", "http://www.w3.org/2001/XMLSchema-instance");
	    
	    SOAPHeader header = message.getSOAPHeader();//Header 정보
	    SOAPBody body = message.getSOAPBody();//Body 정보
	    header.detachNode();

	    //Body 정보 추가
	    Name bodyName = soapFactory.createName(prgId, "webM", "http://localhost/soap");
	    SOAPBodyElement bodyElement = body.addBodyElement(bodyName);
	    
	    //전문정보를 세팅한다.
	    Field[] fields = vo.getClass().getFields();
		if(exHidden==null) exHidden = getExHidden();
		for(int i=0; i<fields.length; i++) {
			if(exHidden.contains(fields[i].getName())) continue;
			if(fields[i].getType().isArray()) {
				String[] vals = (String[]) fields[i].get(vo);
				for(int j=0; j<vals.length; j++) {
					setData(fields[i].getName(), vals[j], bodyElement, soapFactory);
				}
			} else {
				setData(fields[i].getName(), (String) fields[i].get(vo), bodyElement, soapFactory);
			}
		}
	    
	    return message;
	}
	
	private void setData(String tagNm, String tagVal, SOAPBodyElement bodyElement, SOAPFactory soapFactory) throws Exception {
		Name name = soapFactory.createName(tagNm);
	    SOAPElement symbol = bodyElement.addChildElement(name);
	    symbol.addTextNode(StringUtil.nvl(tagVal, ""));
	}
	
	//SOAPMessage(xml)객체를  문자열로 변경한다.
	private String tranSoapTOStr(SOAPMessage message) throws Exception {
		StringBuffer sbXml = new StringBuffer();
		
	    ByteArrayOutputStream baos = new ByteArrayOutputStream();
	    message.writeTo(baos);
	    
	    sbXml.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
	    sbXml.append(baos.toString("UTF-8"));
	    
	    logger.debug("************* request Data start***************");
		logger.debug(sbXml.toString());
		logger.debug("************* request Data end***************");

		return sbXml.toString();
	}
	
	//신융자서버에 전문 req/res 한 정보 
	private InputStream callLoanWas(String makedSoapXml, boolean isReal) throws Exception {
		//soap 버전에 따라 틀려짐 - 여기서는 SOAP-ENV 로 변경 해야 함.(테스트계에서는 soapenv로 생성됨)
		makedSoapXml = makedSoapXml.replaceAll("soapenv", "SOAP-ENV");
		
		byte[] b = makedSoapXml.getBytes();
        
        URL url = new URL(getSOAPUrl(isReal));
        logger.debug("SOAPUrl: " + getSOAPUrl(isReal));
		URLConnection connection = url.openConnection();
		
		HttpURLConnection httpConn = (HttpURLConnection) connection;
		
		httpConn.setRequestProperty("Content-Length", String.valueOf( b.length ));
		httpConn.setRequestProperty("Content-Type", "text/xml; charset=utf-8");
		httpConn.setRequestMethod("POST");
		httpConn.setDoOutput(true);
		httpConn.setDoInput(true);

		OutputStream out = httpConn.getOutputStream();
		out.write( b );
		out.flush();
		out.close();
		
		int retCode = httpConn.getResponseCode();
		
		logger.debug(" retCode = " + retCode);
		
		InputStream input= null;
		if (retCode == 500) {
			input = httpConn.getErrorStream();
		} else {
			input = httpConn.getInputStream();
		}
		
		return input;
	}
	
	//신융자서버에 전문 res 한 정보 
	private String readXML(InputStream input) throws Exception {
		InputStreamReader isr = new InputStreamReader(input, "utf-8");
		BufferedReader in = new BufferedReader(isr);
		
		StringBuffer sb = new StringBuffer();
		String inputLine;
		while ((inputLine = in.readLine()) != null) {
			sb.append(inputLine);
			sb.append("\n");
		}
		in.close();
		
		logger.debug("************* response Data start***************");
		logger.debug(sb.toString());
		logger.debug("************* response Data end***************");

		return sb.toString();
	}
	
	//리턴된 xml데이터를 vo에 할당한다.
	private CMMVO xmlToVO(String xmlData, CMMVO vo, String prgId) throws Exception {
		return XmlUtil.getXmlToVo(XmlUtil.getNodeList(XmlUtil.getDocument(xmlData), "webM:"+prgId), vo);
	}
	
}


