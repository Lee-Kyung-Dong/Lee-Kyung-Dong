package com.idongbu.util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class FileUtil {
	private static Logger logger = LoggerFactory.getLogger(FileUtil.class);
	//private static final String EOL = System.getProperty("line.separator");
	
	public static String readTextFile(String filename) {
		BufferedReader in = null;
		StringBuffer strb = new StringBuffer();
		
		try {
			in = new BufferedReader(new FileReader(filename));
			String str;

//			while ((str = in.readLine()) != null)
			while (true)
			{
				str = in.readLine();
				if(str == null ) break;
				strb.append(str).append("\r\n");
			}
		} catch (Exception e) {
			 logger.error(e.toString());			
		} finally {
			try {
		        if(in!=null) in.close();
			} catch (IOException e) {
				logger.error(e.toString());
			}
		}
		return strb.toString();
	}
	
	public static final String normalizePath(String path) {
		String normalized = path;
		
		if (normalized.indexOf('\\') >= 0)
			normalized = normalized.replace('\\', '/');

		if (!normalized.startsWith("/"))
			normalized = "/" + normalized;
		do {
			int index = normalized.indexOf("//");
			if (index < 0) break;
			
			normalized = normalized.substring(0, index) + normalized.substring(index + 1);				
		} while (true);
		
		do {
			int index = normalized.indexOf("%20");
			if (index < 0) break;
			
			normalized = normalized.substring(0, index) + " " + normalized.substring(index + 3);					
		} while (true);
		
		do {
			int index = normalized.indexOf("/./");
			if (index < 0)
				break;
			normalized = normalized.substring(0, index)
					+ normalized.substring(index + 2);
		} while (true);
		
		do {
			int index = normalized.indexOf("/../");
			if (index >= 0) {
				if (index == 0) return null;
				
				int index2 = normalized.lastIndexOf('/', index - 1);
				normalized = normalized.substring(0, index2) + normalized.substring(index + 3);							
			} else {
				return normalized;
			}
		} while (true);
	}
	
	
	// 2008.09.04 by hsahn CSV 파일 생성
	// *** 제약사항 *** 
	// 현재는 교차 지점별 기본과정 수강자 및 계약서 작성자 명단 전용임. 향후 일반적인 용도로 사용할 수 있도록 수정 필요
	// *** 제약사항 ***
	public static int writeCSVFile(String filePath, String fileName, String header, ResultSet rs)
	{	
		File csvFile 		= null;				  
		FileWriter fw 		= null;
		BufferedWriter bw 	= null;
		
		int result 			= -1;		   
		String strLine 		= "";
		   
		try {
			if(filePath != null && fileName != null){
				csvFile = new File(filePath, fileName);
				fw = new FileWriter(csvFile, false);	// APPEND 불가
				bw = new BufferedWriter(fw);
				   
				// Header 저장
				if(header!=null && header.length()>0) {
					bw.write(header, 0, header.length());
					bw.newLine();
				}
				
				// Data 저장
				if(rs!=null) {
					strLine = "";
					int idx	= 1;
					while(rs.next()) {
						strLine = idx + "," + 														// 순번
							rs.getString("CREATE_DATE") + "," + 									// 방문시간						
							StringUtil.getFmtJuminNo(rs.getString("INHAB_NO"), true) + "," +		// 주민번호 
							rs.getString("FD_MB_NAME") + "," + 										// 이름
							rs.getString("BIGO") + "\n";											// 비고

						bw.write(strLine, 0, strLine.length());					
						
						idx++;
					}
				}			
				result = 0;

			}else{
				result = -1;
				logger.debug("method : writeCSVFile에 파라미터 filePath이나 fileName이 없습니다.");
			}
			
		} catch (IOException ioe) {
			result = -1;
//			logger.debug("파일(" + filePath + "\\ " + fileName + ") 쓰기 중 오류가 발생했습니다.");
		} catch (SQLException se) {
			result = -1;
//			logger.debug("파일(" + filePath + "\\ " + fileName + ") 쓰기 중 오류가 발생했습니다.");
		} finally {
			try { 
				if(bw!=null) bw.close(); 
				if(fw!=null) fw.close(); 
				if(rs!=null) rs.close(); 
			} catch(Exception e) {
				logger.error(e.toString());
			}	    	
		}
 
		return result;
	}
	// {2008.09.04}
	
	   public static boolean  fileMove(String strSrc, String strDest) 
	   {
		   boolean bMove = false;
		   try 
		   {	   
			   File srcFile = null;
			   File destFile = null;
			   if(strSrc != null && strDest != null){
				   srcFile  = new File( strSrc); // 원본파일
				   destFile = new File( strDest); // 복사위치
			   }else{
				   logger.debug("method : fileMove에 파라미터 strSrc, strDest가 없습니다!");
				   return false;
			   }
			   
			   if(!srcFile.exists())
				  return true;
			   
			   if (destFile.exists())
			   {
				   boolean bFlag = destFile.delete();
				   logger.debug(bFlag ? "목적 파일 삭제":"목적파일삭제 실패");
			   }
			   
			   bMove = srcFile.renameTo(destFile);
			   
		   } catch (Exception e) {
			   logger.error(e.toString());	
			   bMove = false;
		   }
		   
		   return bMove;
	   }	
	
}
