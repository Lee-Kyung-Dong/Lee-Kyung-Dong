package com.idongbu.util.dao;

import com.idongbu.smartcustomer.vo.EmsMailVO;
import com.idongbu.smartcustomer.vo.ListEmsVo;

/**
 * @info myBatis 연동위한 interface 
 */
public interface EmsDao {

	//Email 전송 Sequence
	String getSeqAuto100();
	
	void insertEmsTable1(EmsMailVO vo);
	
	EmsMailVO selectEmsTable1(EmsMailVO vo);
	
	void updateEmsTable1(EmsMailVO vo);

	//void insertEmsTable2(List<ListEmsVo> list_DATA);
	void insertEmsTable2(ListEmsVo vo);
}
