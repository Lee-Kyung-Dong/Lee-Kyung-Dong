package com.idongbu.util.dao;

import java.util.HashMap;

public interface StatDao {

	int insertPageview(HashMap hm);
	int updatePageview(HashMap hm);
	int insertStat(HashMap hm);
	int updateStat(HashMap hm);
	int updateStat2(HashMap hm);

}
