package com.idongbu.util.dao;


import java.util.HashMap;
import java.util.List;

import com.idongbu.smartcustomer.vo.ComnInfoVO;
import com.idongbu.smartcustomer.vo.EmsMailVO;
import com.idongbu.smartcustomer.vo.SignatureSignVO;
import com.idongbu.smartcustomer.vo.SmsVO;


/**
 * @info myBatis 연동위한 interface 
 */
public interface UtilDao {

	//홈페이지 COMN_INFO조회
	List<HashMap<String,String>> selectComnInfo(ComnInfoVO vo);
	
	//전문에러메세지내용조회
	String selectJmErrMsg(String msg_id);
	
	//Email 전송 Sequence
	String getSeqAuto100();
	
	void insertEmsTable1(EmsMailVO vo);
	
	EmsMailVO selectEmsTable1(EmsMailVO vo);
	
	void insertEmsTable2(EmsMailVO vo);
	
	void updateEmsTable1(EmsMailVO vo);

	//SMS발송 로그
	void insertSmsLog(SmsVO vo);

	// 전자서명 insert로그
	void insertSignature(SignatureSignVO vo);
	
	List<HashMap<String, String>> getCodeList(String code);
}
