package com.idongbu.util.dao;

import java.util.HashMap;

public interface SvcCtrlDao {
	int selectHolly(HashMap hm);
}
