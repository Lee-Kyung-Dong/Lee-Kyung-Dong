package com.idongbu.util;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.idongbu.common.cmmConst;
import com.idongbu.util.dao.StatDao;

@Service
public class StatUtil {
	// 모바일 DB사용하는 sqlsession
	@Autowired(required=true)
	@Qualifier("sqlSession")
	protected SqlSessionTemplate sqlSession;


	/* URI로 페이지뷰 증가 */
	public void inputPageviewURI(String uri) {
		
		if ( uri != null && !"".equals(uri) ) {
		
			for ( int i=0; i<cmmConst.PAGEVIEW_DATA.length; i+=2 ) {
				if ( cmmConst.PAGEVIEW_DATA[i].equals( uri ) ) {
	
					String num = cmmConst.PAGEVIEW_DATA[i+1];
	
					Date currentTime = new Date();
					SimpleDateFormat dayFormat = new SimpleDateFormat ( "yyyyMMdd", Locale.KOREA );
					String bas_dt = dayFormat.format ( currentTime );
	
					StatDao mapper= sqlSession.getMapper(StatDao.class);
	
					HashMap hm = new HashMap();
					hm.put("num", num);
					hm.put("bas_dt", bas_dt);
					int updatePgview = mapper.updatePageview(hm);
					
					if ( updatePgview < 1 ) {
						int insertPgview = mapper.insertPageview(hm);
						updatePgview = mapper.updatePageview(hm);
					}
				}
			}
		}
	}

	/* 번호로 페이지뷰 증가 */
	public void inputPageview(String num) {
		
		if ( num != null && !"".equals(num) ) {
		
			Date currentTime = new Date();
			SimpleDateFormat dayFormat = new SimpleDateFormat ( "yyyyMMdd", Locale.KOREA );
			String bas_dt = dayFormat.format ( currentTime );
			
			HashMap hm = new HashMap();
			hm.put("num", num);
			hm.put("bas_dt", bas_dt);
			
			StatDao mapper= sqlSession.getMapper(StatDao.class);
			
			int result = mapper.updatePageview(hm);
			if ( result < 1 ) {
				int insertStat = mapper.insertPageview(hm);
				result = mapper.updatePageview(hm);
			}
		}
	}
	
	/* 번호로 실적뷰 증가 */
	public void inputStat(String num) {
		
		if ( num != null && !"".equals(num) ) {
		
			Date currentTime = new Date();
			SimpleDateFormat dayFormat = new SimpleDateFormat ( "yyyyMMdd", Locale.KOREA );
			String bas_dt = dayFormat.format ( currentTime );
			
			HashMap hm = new HashMap();
			hm.put("num", num);
			hm.put("bas_dt", bas_dt);
			
			StatDao mapper= sqlSession.getMapper(StatDao.class);
			
			int result = mapper.updateStat(hm);
			if ( result < 1 ) {
				int insertStat = mapper.insertStat(hm);
				result = mapper.updateStat(hm);
			}
		}

	}

	/* 번호로 실적뷰 증가(다중카운팅) */
	public void inputStat(String num, int count) {
		
		if ( num != null && !"".equals(num) ) {
		
			Date currentTime = new Date();
			SimpleDateFormat dayFormat = new SimpleDateFormat ( "yyyyMMdd", Locale.KOREA );
			String bas_dt = dayFormat.format ( currentTime );
			
			HashMap hm = new HashMap();
			hm.put("num", num);
			hm.put("bas_dt", bas_dt);
			hm.put("count", count);
			
			StatDao mapper= sqlSession.getMapper(StatDao.class);
			
			int result = mapper.updateStat2(hm);
			if ( result < 1 ) {
				int insertStat = mapper.insertStat(hm);
				result = mapper.updateStat2(hm);
			}
		}

	}
	
}
