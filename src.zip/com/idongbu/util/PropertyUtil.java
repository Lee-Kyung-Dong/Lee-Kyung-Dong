/**
 * 실시간 Properties 파일 확인
 */
package com.idongbu.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import javax.servlet.ServletContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service
public class PropertyUtil {
	
	private final ServletContext servletContext;
	
	@Autowired
	public PropertyUtil(ServletContext servletContext){
		this.servletContext = servletContext;
	}
	
	public Properties getProperty(String propName){
		Properties prop = new Properties();
		try {
//			System.out.println(servletContext.getRealPath("/"));
			prop.load(new FileInputStream(servletContext.getRealPath("/WEB-INF/") + propName));
		} catch (IOException e) {
			e.printStackTrace();
		}
		return prop;				
	}

}
