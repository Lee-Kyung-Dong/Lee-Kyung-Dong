package com.idongbu.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;

public class FileUrlDownload {
	public String getHtmlStr(String strUrl) {
		StringBuffer sb = new StringBuffer();

		String resStr = "";
		
		if ( strUrl == null || "".equals(strUrl) ) {
			return resStr;
		}
		
		try {
			URL url = new URL(strUrl);
			
			URLConnection con = url.openConnection();
			BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream(),"euc-kr"));
			String tmp = "";
			while(true){
				tmp = br.readLine();
				if(tmp == null) break;
				sb.append(tmp);
			}					
		} catch (IOException ioe) {
			ioe.printStackTrace();
			return resStr;
		}
		
		if ( sb != null ) {
			resStr = sb.toString();
		}
		
		return resStr;
	}
}

