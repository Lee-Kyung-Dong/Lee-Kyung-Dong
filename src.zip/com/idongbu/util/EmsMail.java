package com.idongbu.util;

import java.lang.reflect.Field;
import java.util.Random;

import org.apache.commons.lang.ArrayUtils;
import org.mybatis.spring.SqlSessionTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;

import com.idongbu.common.ESBBizHeader;
import com.idongbu.common.ESBChannelHeader;
import com.idongbu.common.ESBManager;
import com.idongbu.common.XmlUtil;
import com.idongbu.smartcustomer.vo.EmsMailVO;
import com.idongbu.smartcustomer.vo.ListEmsVo;
import com.idongbu.smartzone.vo.XEMS0002VO;
import com.idongbu.util.dao.EmsDao;

public class EmsMail {
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	private final EmsMailVO vo = new EmsMailVO();
	
 	public EmsMail(String mail_form_type, String mail_form_id, String from_name, String from_mail, String subject) {
		this("29", "07", "01", mail_form_type, mail_form_id, from_name, from_mail, subject);
	} 
 
	public EmsMail(String mail_type, String mail_type_seq, String channel_code
			, String mail_form_type, String mail_form_id, String from_name, String from_mail, String subject) {
		vo.setMail_form_type(mail_form_type);
		vo.setMail_type(mail_type);
		vo.setMail_type_seq(mail_type_seq);
		vo.setChannel_code(channel_code);
		vo.setMail_form_id(mail_form_id);
		vo.setFrom_name(from_name);
		vo.setFrom_mail(from_mail);
		vo.setSubject(subject);
	}

	public void addTo(String member_id, String to_name, String to_mail, String mapping  , boolean isReal) {
		//TEST서버일경우
		if(!isReal){
			logger.debug("TEST계에서는 SM한테 이메일발송하도록!!!");
			/*member_id = "8405051032211";
			to_name   = "이민섭";
			to_mail   = "f1a29541@dbins.net";*/
			//to_mail   = "f1f14a34@dbins.net";
			to_mail   = "f1a29532@dbins.net";
		}

		if(StringUtil.isEmpty(to_name)) to_name = to_mail;
		if(StringUtil.isEmpty(to_name) || StringUtil.isEmpty(to_mail)) {
			throw new IllegalArgumentException("보내는 사람명 또는 이메일이 없습니다.(" + to_name + ", " + to_mail + ")");
		}
  		
		if(StringUtil.isEmpty(member_id)) {
			member_id = "0000000000000";
		}
		
		mapping = StringUtil.splitJuminNo(member_id)[1] + "|" + member_id + "|" + to_name + "|" + to_mail + "|" + mapping;
		if(StringUtil.getByteLength(mapping)>4000) {
			mapping = StringUtil.getLeftByte(mapping, 4000);
		}
		vo.setMember_id((String[]) ArrayUtils.add(vo.getMember_id(
				), member_id));
		vo.setTo_name((String[]) ArrayUtils.add(vo.getTo_name(), to_name));
		vo.setTo_mail((String[]) ArrayUtils.add(vo.getTo_mail(), to_mail));
		vo.setMapping((String[]) ArrayUtils.add(vo.getMapping(), mapping));
	}

	public boolean send(SqlSessionTemplate sqlsession , DataSourceTransactionManager transactionManager) {
		System.out.println("#########Email-Send######################");
		boolean isTest = true;
		try {
			
			if(vo.getMember_id()==null || vo.getMember_id().length==0)
				throw new IllegalArgumentException("member_id가 null이거나 length가 0입니다.");

			if(StringUtil.isEmpty(vo.getMail_form_type())) vo.setMail_form_type("1");
		
			System.out.println("#########vo.getMail_form_id()=####################"+vo.getMail_form_id());
			
			vo.setContent(vo.getMail_form_id());

			int result = sendEmsMail(vo , sqlsession , transactionManager , isTest);
			if(result<0) return false;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	
	public int sendEmsMail(EmsMailVO vo , SqlSessionTemplate sqlsession,DataSourceTransactionManager transactionManager , boolean isTest) throws Exception {
		int result	= 0;
		EmsDao mapper = null;
		//트랜잭션 
		DefaultTransactionDefinition def = new DefaultTransactionDefinition();
		def.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRED);
		TransactionStatus status = transactionManager.getTransaction(def);
		
		try {
			mapper = sqlsession.getMapper(EmsDao.class);
			//sequence 객체를 받아온다.
			vo.setSeqno(mapper.getSeqAuto100());
			//발송등록
			mapper.insertEmsTable1(vo);
			//등록한 발송정보 얻기
			EmsMailVO retvo = mapper.selectEmsTable1(vo);
			vo.setWorkday(retvo.getWorkday());
			vo.setList_table(retvo.getList_table());

			for(int i=0; i<vo.getMember_id().length; i++) {
				ListEmsVo subVo1 = new ListEmsVo();
				subVo1.setList_table(vo.getList_table());
				subVo1.setWorkday(vo.getWorkday());
				subVo1.setSeqno(vo.getSeqno());
				subVo1.setMember_id(vo.getMember_id()[i]);
				subVo1.setTo_name(vo.getTo_name()[i]);
				subVo1.setTo_mail(vo.getTo_mail()[i]);
				subVo1.setMapping(vo.getMapping()[i]);
				subVo1.setMember_id_seq(i);

				vo.setTarget_cnt(vo.getMember_id().length);
				mapper.insertEmsTable2(subVo1);
			}
			
			//발송리스트 입력하기
			mapper.updateEmsTable1(vo);
		} catch (Exception e) {
			result = -1;
			e.printStackTrace();
			try{transactionManager.rollback(status);}catch(Exception trE){throw new Exception("이메일발송하는데 오류가 발생하였습니다");}
			throw e;
		} 
		
		transactionManager.commit(status);
		return result;
	}

	public boolean send(String esbUrl, String userId, boolean isReal) {
		System.out.println("#########Email-Send######################");
		try {
			
			if(vo.getMember_id()==null || vo.getMember_id().length==0)
				throw new IllegalArgumentException("member_id가 null이거나 length가 0입니다.");

			if(StringUtil.isEmpty(vo.getMail_form_type())) vo.setMail_form_type("1");
		
			System.out.println("#########vo.getMail_form_id()=####################"+vo.getMail_form_id());
			
			vo.setContent(vo.getMail_form_id());

			int result = sendEmsMail(vo, esbUrl, userId, isReal);
			if(result<0) return false;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	@SuppressWarnings({ "rawtypes" })
	public int sendEmsMail(EmsMailVO vo, String esbUrl, String userId, boolean isReal) throws Exception {
		int result	= 0;

		try {
			for(int i = 0, szi = vo.getMember_id().length; i < szi; i++) {
				XEMS0002VO jmvo = new XEMS0002VO();
				jmvo.mail_code = vo.getMail_type() + "_" + vo.getMail_type_seq();
				jmvo.ems_if_id = jmvo.mail_code + "_" + String.valueOf(System.currentTimeMillis()) + StringUtil.lpad(String.valueOf(new Random().nextInt(99999999) + 1), 8, "0");
				jmvo.to_id = vo.getMember_id()[i].substring(0, 7);
				jmvo.to_email = vo.getTo_mail()[i];
				jmvo.to_name = vo.getTo_name()[i];
				jmvo.from_email = "idbins@dbins.net";
				jmvo.from_name = "DB손해보험";
				jmvo.subject = vo.getSubject();
				jmvo.target_flag = "N";
				String[] arr = vo.getMapping()[i].split("[|]");
				Class cls = jmvo.getClass();
				Field[] fld = cls.getFields();
				
				for(int j = 0, szj = arr.length; j < szj; j++) {
					for(int k = 0, szk = fld.length; k < szk; k++) {
						if(("map" + (j + 1)).equals(fld[k].getName())) {
							fld[k].set(jmvo, arr[j]);
							break;
						}
					}
				}
				
				jmvo.map_content = "04_4".equals(jmvo.mail_code) ? jmvo.map5 : "내용";
				
				if("04_4".equals(jmvo.mail_code)) {
					jmvo.map5 = "";
				}

				jmvo = getXEMS0002VO(jmvo, esbUrl, userId);
			}
		} catch (Exception e) {
			logger.debug(StringUtil.getStackTraceString(e));
			throw e;
		} 
		
		return result;
	}	

	@SuppressWarnings("static-access")
	private XEMS0002VO getXEMS0002VO(XEMS0002VO jmvo, String esbUrl, String userId) throws Exception {
		String formId = "XEMS0002";                                                                                                                                                                                           
		String telegram = "XEMS"; // esb                                                                                                                                                                                      
		                                                                                                                                                                                                                      
		ESBManager em = new ESBManager();                                                                                                                                                                                     
		ESBChannelHeader channelHead = new ESBChannelHeader();                                                                                                                                                                
		ESBBizHeader bizHead = new ESBBizHeader();     
		
		bizHead = em.makeDefaultBizHeader(userId);                                                                                                                                                                            
		channelHead = em.makeDefaultChannelHeader(formId, userId);  
		String rtnXmlString = (String)XmlUtil.callESBToString(channelHead, bizHead, jmvo, esbUrl, telegram);                                                                                                                   
		                                                                                                                                                                                                                      
		logger.debug("##############################");                                                                                                                                                                       
		logger.debug(rtnXmlString);                                                                                                                                                                                           
		logger.debug("##############################");                                                                                                                                                                       
		                                                                                                                                                                                                                      
		jmvo = (XEMS0002VO) ESBManager.xmlToVOnew(rtnXmlString, (XEMS0002VO)jmvo);                                                                                                                      
		                                                                                                                                                                                                                      
		return jmvo;
	}

}
