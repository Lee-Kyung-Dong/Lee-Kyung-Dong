package com.idongbu.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.httpclient.NameValuePair;

import com.icert.comm.secu.IcertSecuManager;
import com.idongbu.smartcustomer.vo.CellPhoneCertVo;
import com.idongbu.smartcustomer.vo.CuCounVO;
import com.idongbu.smartcustomer.vo.CustomerCenterVO;
import com.idongbu.smartcustomer.vo.LoInsuAppApplyVO;


public class BizUtil {
	
	// 자동차보험 상담신청
    public static final String MOBILE_LOG_CAR  = "CAR";
    // 컨버전스 상담신청
    public static final String MOBILE_LOG_CONVERSIONS  = "CONVERSIONS";
    // 아이사랑 상담신청
    public static final String MOBILE_LOG_CHILDLOVE  = "CHILDLOVE";
    // 스마트운전자보험 상담신청
    public static final String MOBILE_LOG_SMARTCAR  = "SMARTCAR";
    // 내인생행복진단
    public static final String MOBILE_LOG_MYLIFE  = "MYLIFE";
    // 증명서 발급
    public static final String MOBILE_LOG_AUTHENTICATION  = "AUTHENTICATION";
    //대출
    public static final String LOAN  = "LOAN";
    //보상접수
    public static final String COMPENSATE  = "COMPENSATE";
    // 긴급출동
    public static final String EMERGENCY  = "EMERGENCY";
    
	//약관대출 - 나이계산
	public static int calculatorAge(LoInsuAppApplyVO vo){
		int year      = Integer.parseInt(DateUtil.getYear());
		int month     = Integer.parseInt(DateUtil.getMonth());
		int day       = Integer.parseInt(DateUtil.getDay());
		int age	      = 0;
		String age_mm = "";
		String age_dd = "";
		String b_year = "";

		if ("3".equals(vo.getSsnUserJumin().subSequence(6,7)) || "4".equals(vo.getSsnUserJumin().subSequence(6,7))){
			b_year = "20"+vo.getSsnUserJumin().substring(0,2);
		}else {
			b_year = "19"+vo.getSsnUserJumin().substring(0,2);
		}
		age=year-Integer.parseInt(b_year)+1;
		age_mm=vo.getSsnUserJumin().substring(2,4);
		age_dd=vo.getSsnUserJumin().substring(4,6);

		if ("0".equals(age_mm.substring(0,1))){
			age_mm = age_mm.substring(1);
		}	
		if ("0".equals(age_dd.substring(0,1))){
			age_dd = age_dd.substring(1);
		}
		if(month == Integer.parseInt(age_mm)){
			if (day <= Integer.parseInt(age_dd)){
				age = age - 2;
			}else {
				age = age - 1;
			}
		}else if (month < Integer.parseInt(age_mm)){
			age = age - 2;
		}else if (month > Integer.parseInt(age_mm)){
			age = age - 1;
		}


		return age;
	}
	
	
	private static final double EARTH_RADIUS =6378100.0 ; //지구 반지름(단위 m) 6378.1 km
	private static final double Rad = Math.PI / 180;						
	/**
	 * @info 긴급출동 - 두 지점(고객&출동자 거리계산)
	 * @param x1:자신의위치x
	 * @param y1:자신의위치y
	 * @param x2:해당목표위치x
	 * @param y2:해당목표위치y
	 * @return
	 */
	public static double getDist(double x1, double y1, double x2, double y2){
		double x1Rad = Rad * x1;
		double x2Rad = Rad * x2;
		double radDist = Rad * (y1 - y2);
		
		double distance = Math.sin(x1Rad) * Math.sin(x2Rad);
		distance = distance + Math.cos(x1Rad) * Math.cos(x2Rad) * Math.cos(radDist);
		double ret = EARTH_RADIUS * Math.acos(distance);
		
//		return Math.round(Math.round(ret) / 1000);
		return (double)Math.round(ret);
	}
	
	//휴대폰 본인인증 결과코드 map
	public static HashMap<String, String> initCodeMap(){
		HashMap<String, String> codeMap = new HashMap<String, String>();
			
		// 인증요청 / 결과 수신 페이지 - 코드집
		codeMap.put("KISQ0000", "인증성공");
		codeMap.put("KISQ9001", "내부처리 중 오류 (1)");
		codeMap.put("KISQ9002", "Parameter 수신 에러");
		codeMap.put("KISQ9003", "tr_cert값이 NULL인 경우");
		codeMap.put("KISQ9004", "tr_cert 1차 복호화 실패");
		codeMap.put("KISQ9005", "tr_cert 위/변조 검증 실패");
		codeMap.put("KISQ9006", "tr_cert 2차 복호화 실패");
		codeMap.put("KISQ9007", "tr_cert Split 실패");
		codeMap.put("KISQ9008", "tr_cert 요청처리 실패");
		codeMap.put("KISQ9101", "회원사ID값이 NULL인 경우");
		codeMap.put("KISQ9102", "URL코드 값이 6자리가 아닌 경우");
		codeMap.put("KISQ9103", "인증번호 값이 NULL인 경우");
		codeMap.put("KISQ9104", "요청일시 값이 14자리가 아닌 경우");
		codeMap.put("KISQ9105", "휴대폰번호값이 NULL인 경우");
		codeMap.put("KISQ9106", "이동통신사가 NULL인 경우");
		codeMap.put("KISQ9107", "생년월일이 NULL인 경우");
		codeMap.put("KISQ9108", "성별이 NULL인 경우");
		codeMap.put("KISQ9109", "내/외국인 정보가 NULL인 경우");
		codeMap.put("KISQ9110", "성명 값이 NULL인 경우");
		codeMap.put("KISQ9111", "휴대폰번호 값이 10 or 11자리 숫자가 아닌 경우");
		codeMap.put("KISQ9112", "휴대폰 “010”,“011”,“016”,“017”,“018”,“019” 아닌 경우");
		codeMap.put("KISQ9113", "이동통신사가 “SKT” or “KTF” or “LGT” 가 아닌 경우");
		codeMap.put("KISQ9114", "생년월일 값이 8자리 숫자가 아닌 경우");
		codeMap.put("KISQ9115", "성별 값이 “0”, “1” 이 아닌 경우");
		codeMap.put("KISQ9116", "내/외국인 정보가 “0”, “1” 이 아닌 경우");
		codeMap.put("KISQ9117", "성명 값이 20byte 넘는 경우");
		codeMap.put("KISQ9201", "회원사ID 비정상");
		codeMap.put("KISQ9202", "URL 코드 비정상");
		codeMap.put("KISQ9203", "요청일시와 당사 시스템시간차가 30분 이상인 경우");
		codeMap.put("KISQ9204", "본인인증 사용권한 없음");
		codeMap.put("KISQ9205", "SMS인증 사용권한 없음");
		codeMap.put("KISQ9206", "내부처리 중 오류 (2)");
		codeMap.put("KISQ9207", "일 5회 인증 실패");
		codeMap.put("KISQ9208", "내부처리 중 오류 (3)");
		codeMap.put("KISQ9209", "내부처리 중 오류 (4)");
		codeMap.put("KISQ9210", "내부처리 중 오류 (5)");
		codeMap.put("KISQ9211", "내부처리 중 오류 (6)");
		codeMap.put("KISQ9212", "내부처리 중 오류 (7)");
		codeMap.put("KISQ9213", "내부처리 중 오류 (8)");
		for(int i = 9301; i <= 9410; i++) {
			codeMap.put("KISQ" + i, "휴대폰인증 처리 중 오류");
		}
		codeMap.put("KISH0001", "분실 또는 일시정지 휴대폰");
		codeMap.put("KISH0002", "사업자(법인) 명의의 휴대폰");
		codeMap.put("KISH0003", "휴대폰 번호 또는 통신사 불일치");
		codeMap.put("KISH0004", "생년월일 또는 성별정보 불일치");
		codeMap.put("KISH0005", "성명정보 불일치");
		codeMap.put("KISH0006", "입력정보 불일치");
		codeMap.put("KISH0008", "제한 요금제 가입자");
		codeMap.put("KISH0009", "선불 휴대폰번호");
		for(int i = 10; i <= 9999; i++) {
			String n = String.valueOf(i);
			if(n.length() == 2) n = "00" + n;
			else if(n.length() == 3) n = "0" + n;
			codeMap.put("KISH" + n, "통신사의 일시적인 시스템 오류");
		}
		
		// 인증번호 확인 요청 / 최종결과 수신 페이지 - 코드집
		codeMap.put("KIST0000", "인증번호 일치 (성공)");
		codeMap.put("KIST9999", "인증번호 불일치 (실패)");
		codeMap.put("KIST9998", "인증번호 5회 오류횟수 초과");
		codeMap.put("KIST9001", "내부처리 중 오류 (1)");
		codeMap.put("KIST9002", "Parameter 수신 에러");
		codeMap.put("KIST9003", "tr_cert값이 NULL인 경우");
		codeMap.put("KIST9004", "tr_cert 1차 복호화 실패");
		codeMap.put("KIST9005", "tr_cert 위/변조 검증 실패");
		codeMap.put("KIST9006", "tr_cert 2차 복호화 실패");
		codeMap.put("KIST9007", "tr_cert Split 실패");
		codeMap.put("KIST9008", "tr_cert 요청처리 실패");
		codeMap.put("KIST9101", "인증번호값이 NULL인 경우");
		codeMap.put("KIST9102", "본인인증번호 값이 6자리가 아닌 경우");
		codeMap.put("KIST9103", "식별정보 값이 88자리가 아닌 경우");
		codeMap.put("KIST9104", "확인용 파라미터1값이 NULL인 경우");
		codeMap.put("KIST9105", "확인용 파라미터2값이 NULL인 경우");
		codeMap.put("KIST9106", "확인용 파라미터3값이 NULL인 경우");
		codeMap.put("KIST9201", "확인용 파라미터1값 비정상");
		codeMap.put("KIST9202", "확인용 파라미터2값 비정상");
		codeMap.put("KIST9203", "확인용 파라미터3값 비정상");
		
		// 인증번호 재전송 요청 / 최종결과 수신 페이지 - 코드집
		codeMap.put("KISR0000", "인증번호재전송 성공");
		codeMap.put("KISR9999", "인증번호재전송 실패");
		codeMap.put("KISR9998", "SMS 3회 재전송 실패");
		codeMap.put("KISR9001", "내부처리 중 오류 (1)");
		codeMap.put("KISR9002", "Parameter 수신 에러");
		codeMap.put("KISR9003", "tr_cert값이 NULL인 경우");
		codeMap.put("KISR9004", "tr_cert 1차 복호화 실패");
		codeMap.put("KISR9005", "tr_cert 위/변조 검증 실패");
		codeMap.put("KISR9006", "tr_cert 2차 복호화 실패");
		codeMap.put("KISR9007", "tr_cert Split 실패");
		codeMap.put("KISR9008", "tr_cert 요청처리 실패");
		codeMap.put("KISR9101", "인증번호값이 NULL인 경우");
		codeMap.put("KISR9102", "식별정보 값이 88자리가 아닌 경우");
		codeMap.put("KISR9103", "확인용 파라미터1값이 NULL인 경우");
		codeMap.put("KISR9104", "확인용 파라미터2값이 NULL인 경우");
		codeMap.put("KISR9105", "확인용 파라미터3값이 NULL인 경우");
		codeMap.put("KISR9201", "확인용 파라미터1값 비정상");
		codeMap.put("KISR9202", "확인용 파라미터2값 비정상");
		codeMap.put("KISR9203", "확인용 파라미터3값 비정상");
		codeMap.put("KISR9401", "내부처리 중 오류(2)");
		codeMap.put("KISR9402", "내부처리 중 오류(3)");
		for(int i = 9501; i <= 9510; i++) {
			codeMap.put("KISR" + i, "SMS 재발송 처리 오류");
		}
		
		return codeMap;
	}
	private static String getDay() {
        //날짜 생성
        Calendar today = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss", Locale.KOREA);
		return sdf.format(today.getTime());
	}
	private static String cpId = "DBIM2002"; // 회원사ID
	private static String urlCode = "005001"; // URL코드
	
	private static String getReqNum(String day) {
        Random ran = new Random();
        ran.setSeed(System.currentTimeMillis());	//보안성 체크 수정
        //랜덤 문자 길이
        int numLength = 6;
        String randomStr = "";

        for (int i = 0; i < numLength; i++) {
            //0 ~ 9 랜덤 숫자 생성
            randomStr += ran.nextInt(10);
        }
		//reqNum은 최대 40byte 까지 사용 가능
        String reqNum = day + randomStr;
        
        return reqNum;
	}
	/**
	 * @info 휴대폰 본인인증 인증번호 발송
	 * @return
	 * @throws Exception 
	 * @throws IOException 
	 */
	public static CellPhoneCertVo certRequest(String jumin, String name, String company, String phone) throws IOException, Exception{
		
		HashMap<String, String> codeMap = initCodeMap();
		CellPhoneCertVo cert = null;
		String date = getDay();
		String certNum = getReqNum(date);
		String gender = Integer.parseInt(jumin.substring(6, 7)) % 2 == 1 ? "0" : "1";
		String nation = Integer.parseInt(jumin.substring(6, 7)) < 5 ? "0" : "1";
		String birthDay = ("1256".indexOf(jumin.substring(6, 7)) > -1 ? "19" : "20") + jumin.substring(0, 6);
		
		String extendVar = "0000000000000000";                  //확장변수
		//-------------------------------------------------------------------------------------------------------

		/** 요청번호(certNum) 주의사항 ****************************************************************************
		* 1. 본인인증 결과값 복호화를 위한 키로 활용되므로 중요함.
		* 2. 본인인증 요청시 중복되지 않게 생성해야함. (예-시퀀스번호)
		***********************************************************************************************************/

		//01. 한국모바일인증(주) 암호화 모듈 선언
	    IcertSecuManager seed  = new IcertSecuManager();

		//02. 1차 암호화 (tr_cert 데이터변수 조합 후 암호화)
		String enc_tr_cert = "";
		String tr_cert     = cpId +"/"+ urlCode +"/"+ certNum +"/"+ date +"/"+ phone +"/"+ company +"/"+ birthDay +"/"+ gender +"/"+ nation +"/"+ name +"/"+ extendVar;
		enc_tr_cert = seed.getEnc(tr_cert, "");

		//03. 1차 암호화 데이터에 대한 위변조 검증값 생성 (HMAC)
		String hmacMsg = "";
        hmacMsg = seed.getMsg(enc_tr_cert);

		//04. 2차 암호화 (1차 암호화 데이터, HMAC 데이터, extendVar 조합 후 암호화)
		tr_cert = seed.getEnc(enc_tr_cert +"/"+ hmacMsg +"/"+ extendVar, "");

		//05. 본인인증요청 URL로 암호화 데이터 넘기기
        String send_url = "https://www.kmcert.com/kmcis/webc_CI/kmcisReqProc.jsp?tr_cert="+tr_cert;
        
		//06. URL로 암호화 값 보내고 암호화된 결과 받기
        URL url = null;
        BufferedReader in = null;
        URLConnection con = null;

        String rec_cert = "";
        String urlstr   = send_url;
        try {
            url = new URL(urlstr);
            con = url.openConnection();
            con.connect();
            in = new BufferedReader(new InputStreamReader(con.getInputStream()));

            String tmp_msg = "";
            while (true) {
            	tmp_msg = in.readLine();
            	if(tmp_msg == null) break;
                if (!"".equals(tmp_msg)) {
                    rec_cert = tmp_msg;
                }
            }
        } catch (MalformedURLException malformedurlexception) {
            rec_cert = "URL Error("+malformedurlexception+")";
        } catch (IOException ioexception) {
            rec_cert = "IO Error("+ioexception+")";
		} finally {
            try {if (in != null) {in.close();}} catch (Exception e) {in=null;}
        }
        
        
        try {
			//결과값 변수--------------------------------------------------------------------------------------------
            String encPara      = ""; //암호화된 통합 파라미터
            String encMsg1      = ""; //암호화된 통합 파라미터의 Hash값
			String encMsg2      = ""; //암호화된 통합 파라미터의 Hash값 비교를 위한 Hash값
			String msgChk       = "";

			String r_certNum    = ""; //요청번호
			String r_date       = ""; //요청일시
			String r_phoneNo	= ""; //휴대폰번호
			String r_phoneCorp	= ""; //이통사
			String r_birthDay	= ""; //생년월일
			String r_gender		= ""; //성별
			String r_nation     = ""; //내국인
			String r_name       = ""; //성명
			String r_result     = ""; //인증결과값
			String r_resultCode = ""; //인증결과코드
			String r_check_1    = ""; //인증번호 확인결과 전송 및 SMS재전송 요청을 위한 파라미터 1(수정불가)
			String r_check_2    = ""; //인증번호 확인결과 전송 및 SMS재전송 요청을 위한 파라미터 2(수정불가)
			String r_check_3    = ""; //인증번호 확인결과 전송 및 SMS재전송 요청을 위한 파라미터 3(수정불가)
			String resultText    = "";
			//-------------------------------------------------------------------------------------------------------

			//07. rec_cert 정상/비정상 체크
			if(rec_cert.length() != 8) {
				// 정상 결과값 처리 부분 -------------------------------------------------------------------------

				//08. 1차 복호화 (요청번호를 이용해 복호화)
				rec_cert = seed.getDec(rec_cert, certNum);

				int inf1 = rec_cert.indexOf("/",0);
				int inf2 = rec_cert.indexOf("/",inf1+1);

				encPara = rec_cert.substring(0, inf1);
				encMsg1 = rec_cert.substring(inf1+1, inf2);

				//09. 1차 복호화 데이터에 대한 위변조 검증값 검증
				encMsg2 = seed.getMsg(encPara);

				if(encMsg2.equals(encMsg1)){
					//10. 2차 복호화 (요청번호를 이용해 복호화)
					rec_cert  = seed.getDec(encPara, certNum);
	
					int info1  = rec_cert.indexOf("/",0);
					int info2  = rec_cert.indexOf("/",info1+1);
					int info3  = rec_cert.indexOf("/",info2+1);
					int info4  = rec_cert.indexOf("/",info3+1);
					int info5  = rec_cert.indexOf("/",info4+1);
					int info6  = rec_cert.indexOf("/",info5+1);
					int info7  = rec_cert.indexOf("/",info6+1);
					int info8  = rec_cert.indexOf("/",info7+1);
					int info9  = rec_cert.indexOf("/",info8+1);
					int info10 = rec_cert.indexOf("/",info9+1);
					int info11 = rec_cert.indexOf("/",info10+1);
					int info12 = rec_cert.indexOf("/",info11+1);
					int info13 = rec_cert.indexOf("/",info12+1);

					r_certNum		= rec_cert.substring(0,info1);
					r_date			= rec_cert.substring(info1+1,info2);
					r_phoneNo		= rec_cert.substring(info2+1,info3);
					r_phoneCorp		= rec_cert.substring(info3+1,info4);
					r_birthDay		= rec_cert.substring(info4+1,info5);
					r_gender		= rec_cert.substring(info5+1,info6);
					r_nation		= rec_cert.substring(info6+1,info7);
					r_name			= rec_cert.substring(info7+1,info8);
					r_result		= rec_cert.substring(info8+1,info9);
					r_resultCode	= rec_cert.substring(info9+1,info10);
					r_check_1		= rec_cert.substring(info10+1,info11);
					r_check_2		= rec_cert.substring(info11+1,info12);
					r_check_3		= rec_cert.substring(info12+1,info13);
					
					resultText = codeMap.get(r_resultCode);
					if(resultText == null) resultText = "";
	
					cert = new CellPhoneCertVo();
					cert.setCertNum(r_certNum);
					cert.setDate(r_date);
					cert.setPhoneNo(r_phoneNo);
					cert.setPhoneCorp(r_phoneCorp);
					cert.setBirthDay(r_birthDay);
					cert.setGender(r_gender);
					cert.setNation(r_nation);
//					cert.setCI(r_CI);
//					cert.setDI(r_DI);
					cert.setResult(r_result);
					cert.setResultCode(r_resultCode);
					cert.setResultText(resultText);
					cert.setCheck_1(r_check_1);
					cert.setCheck_2(r_check_2);
					cert.setCheck_3(r_check_3);
					
					System.out.println("REQ certvo : " + cert.toString());
				}
			}
        }
		catch(Exception e) {
			e.printStackTrace();
			throw e;
		}
        
      /*  
        StringBuffer sb = new StringBuffer();
		sb.append("var data = {error:\"0\"");
		sb.append(", certNum:\""); sb.append(cert.getCertNum()); sb.append("\"");
		sb.append(", date:\""); sb.append(cert.getDate()); sb.append("\"");
		sb.append(", phoneNo:\""); sb.append(cert.getPhoneNo()); sb.append("\"");
		sb.append(", phoneCorp:\""); sb.append(cert.getPhoneCorp()); sb.append("\"");
		sb.append(", birthDay:\""); sb.append(cert.getBirthDay()); sb.append("\"");
		sb.append(", gender:\""); sb.append(cert.getGender()); sb.append("\"");
		sb.append(", nation:\""); sb.append(cert.getNation()); sb.append("\"");
		sb.append(", result:\""); sb.append(cert.getResult()); sb.append("\"");
		sb.append(", resultCode:\""); sb.append(cert.getResultCode()); sb.append("\"");
		sb.append(", check_1:\""); sb.append(cert.getCheck_1()); sb.append("\"");
		sb.append(", check_2:\""); sb.append(cert.getCheck_2()); sb.append("\"");
		sb.append(", check_3:\""); sb.append(cert.getCheck_3()); sb.append("\"");
		sb.append("}");
        
		System.out.println(sb.toString());*/
		
		return cert;
		
	}
	
	
	
	/**
	 * @info 휴대폰 본인인증 인증번호 인증
	 * @return
	 * @throws Exception 
	 * @throws IOException 
	 */
	public static CellPhoneCertVo certResponse(String certNum
			, String check_1
			, String check_2
			, String check_3
			, String certMessage
			, String jumin
			, String name
			, String company
			, String phoneNumber
				) throws IOException, Exception{
		
		CellPhoneCertVo cert = new CellPhoneCertVo();	//리턴될 vo
		
		HashMap<String, String> codeMap = initCodeMap();
		
		String tr_cert   = "";
		String extendVar = "0000000000000000";                  //확장변수
		/** 요청번호(certNum) 주의사항 ****************************************************************************
		* 1. 본인인증 결과값 복호화를 위한 키로 활용되므로 중요함.
		* 2. 본인인증 요청시 중복되지 않게 생성해야함. (예-시퀀스번호)
		***********************************************************************************************************/

		//01. 한국모바일인증(주) 암호화 모듈 선언
	    IcertSecuManager seed  = new IcertSecuManager();
	    
		//02. 1차 암호화 (tr_cert 데이터변수 조합 후 암호화)
		String enc_tr_cert = "";
//		tr_cert     = certNum +"/"+ certMessage +"//"+ check_1 +"/"+ check_2 +"/"+ check_3 +"/"+ extendVar;	//2차 소스
		tr_cert     = certNum +"/"+ certMessage +"/"+ check_1 +"/"+ check_2 +"/"+ check_3 +"/"+ extendVar;	//3차 수정
		enc_tr_cert = seed.getEnc(tr_cert, "");

		//03. 1차 암호화 데이터에 대한 위변조 검증값 생성 (HMAC)
		String hmacMsg = "";
        hmacMsg = seed.getMsg(enc_tr_cert);
		
		//04. 2차 암호화 (1차 암호화 데이터, HMAC 데이터, extendVar 조합 후 암호화)
		tr_cert  = seed.getEnc(enc_tr_cert +"/"+ hmacMsg +"/"+ extendVar, "");
		
		//05. 본인인증요청 URL로 암호화 데이터 넘기기
//        String send_url = "https://www.kmcert.com/kmcis/webc/kmcisRetProc.jsp?tr_cert="+tr_cert;	//2차 소스
        String send_url = "https://www.kmcert.com/kmcis/webc_CI/kmcisRetProc.jsp?tr_cert="+tr_cert;	//3차 수정-KMC(담당자:최샘터) 문의확인

		//06. URL로 암호화 값 보내고 암호화된 결과 받기
        URL url = null;
        BufferedReader in = null;
        URLConnection con = null;

        String rec_cert = "";
        String urlstr   = send_url;
        try {
            url = new URL(urlstr);
            con = url.openConnection();
            con.connect();
            in = new BufferedReader(new InputStreamReader(con.getInputStream()));

            String tmp_msg = "";
            while (true) {
            	tmp_msg = in.readLine();
            	if(tmp_msg == null) break;
                if (!"".equals(tmp_msg)) {
                    rec_cert = tmp_msg;
                }
            }
        } catch (MalformedURLException malformedurlexception) {
            rec_cert = "URL Error("+malformedurlexception+")";
            malformedurlexception.printStackTrace();
        } catch (IOException ioexception) {
            rec_cert = "IO Error("+ioexception+")";
            ioexception.printStackTrace();
		} finally {
            try {
                if (in != null) {
                    in.close();
                }
            } catch (Exception ex3) {
            	ex3.printStackTrace();
            }
        }

        try {
			//결과값 변수--------------------------------------------------------------------------------------------
        	String encPara      = ""; //암호화된 통합 파라미터
            String encMsg1      = ""; //암호화된 통합 파라미터의 Hash값
			String encMsg2      = ""; //암호화된 통합 파라미터의 Hash값 비교를 위한 Hash값
			String msgChk       = "";
			String r_certNum    = ""; //요청번호
			String r_CI			= ""; //연계정보(CI)
			String r_DI			= ""; //중복가입확인정보(DI)
			String r_result     = ""; //인증결과값
			String r_resultCode = ""; //인증결과코드
			String r_check_1    = ""; //인증번호 확인결과 전송 및 SMS재전송 요청을 위한 파라미터 1(수정불가)
			String r_check_2    = ""; //인증번호 확인결과 전송 및 SMS재전송 요청을 위한 파라미터 2(수정불가)
			String r_check_3    = ""; //인증번호 확인결과 전송 및 SMS재전송 요청을 위한 파라미터 3(수정불가)
			//-------------------------------------------------------------------------------------------------------
			String resultText	= "";
			
			//07. rec_cert 정상/비정상 체크
			if(rec_cert.length() != 8){

				//08. 1차 복호화 (요청번호를 이용해 복호화)
				rec_cert = seed.getDec(rec_cert, certNum);

				int inf1 = rec_cert.indexOf("/",0);
				int inf2 = rec_cert.indexOf("/",inf1+1);

				encPara = rec_cert.substring(0, inf1);
				encMsg1 = rec_cert.substring(inf1+1, inf2);

				//09. 1차 복호화 데이터에 대한 위변조 검증값 검증
				encMsg2 = seed.getMsg(encPara);

				if(encMsg2.equals(encMsg1)){
					rec_cert  = seed.getDec(encPara, certNum);
					
					int info1  = rec_cert.indexOf("/",0);
					int info2  = rec_cert.indexOf("/",info1+1);
					int info3  = rec_cert.indexOf("/",info2+1);
					int info4  = rec_cert.indexOf("/",info3+1);
					int info5  = rec_cert.indexOf("/",info4+1);
					int info6  = rec_cert.indexOf("/",info5+1);
					int info7  = rec_cert.indexOf("/",info6+1);
					int info8  = rec_cert.indexOf("/",info7+1);

					r_certNum	= rec_cert.substring(0,info1);
					r_CI		= rec_cert.substring(info1+1,info2);
					r_DI		= rec_cert.substring(info2+1,info3);
					r_result	= rec_cert.substring(info3+1,info4);
					r_resultCode= rec_cert.substring(info4+1,info5);
					r_check_1	= rec_cert.substring(info5+1,info6);
					r_check_2	= rec_cert.substring(info6+1,info7);
					r_check_3	= rec_cert.substring(info7+1,info8);

					//11. CI, DI 복호화 (요청번호를 이용해 복호화)
					r_CI  = seed.getDec(r_CI, certNum);
					r_DI  = seed.getDec(r_DI, certNum);
					
					resultText = codeMap.get(r_resultCode);
					
					cert.setCertNum(r_certNum);
					cert.setCI(r_CI);
					cert.setDI(r_DI);
					cert.setResult(r_result);
					cert.setResultCode(r_resultCode);
					cert.setResultText(resultText);
					cert.setCheck_1(r_check_1);
					cert.setCheck_2(r_check_2);
					cert.setCheck_3(r_check_3);
					
				}else{
					throw new Exception("비정상적인 접근입니다.");
				}
				
			}

        } catch (Exception ex) {
        	ex.printStackTrace();
        }

        return cert;
	}
		
	
	public static void sendLog(Object argVo, String strGubn) {
		sendLog(argVo, strGubn, "");
	}
	/**
	 *  콜센터에 접촉 이력쌓기
	 * @param argVo
	 * @param strGubn
	 */
	public static void sendLog(Object argVo, String strGubn, String ccUrl) {
		//고객센터에 로그 저장
		{
			CustomerCenterVO jmvo = new CustomerCenterVO();
	        
			jmvo.SANGDAMIL_DATE = StringUtil.getDateTime();  //상담일자
			jmvo.NOTE           = "모바일 상품가입";
			try {
				/*
				 * 해외여행자보험 가입
				 */
				if ( strGubn.equals("STEP01")) 
				{
					Map<String,Object> map = new HashMap<String, Object>();
					map = (HashMap<String,Object>)argVo;
					jmvo.GOGAEK_NO      = (String)map.get("inhab_no"); // 주민번호
					jmvo.BALSHINJA_NO   = "";             // 발신자번호
					jmvo.STATUS         = "접수";          // 접수, 완료
					jmvo.UPMU_DESC1     = "해외여행보험";   // 메뉴 레벨1 
					jmvo.UPMU_DESC2     = "산출정보입력";   // 메뉴 레벨2
					jmvo.POLI_NO        = "";             // 증권번호
					//jmvo.JUBSU_NO       = ((MallYiOutterTravelVO)argVo).serial_no; // 접수번호
					jmvo.SULGYE_NO      =  (String)map.get("engn_no");                                     // 설계번호
					
				} else if ( strGubn.equals("STEP02")) {
					Map<String,Object> map = new HashMap<String, Object>();
					map = (HashMap<String,Object>)argVo;
					jmvo.GOGAEK_NO      = (String)map.get("inhab_no"); // 주민번호
					jmvo.BALSHINJA_NO   = (String)map.get("tel");           // 발신자번호
					jmvo.STATUS         = "접수";         // 접수, 완료
					jmvo.UPMU_DESC1     = "해외여행보험";   // 메뉴 레벨1 
					jmvo.UPMU_DESC2     = "청약서작성";    // 메뉴 레벨2
					jmvo.POLI_NO        = ""; // 증권번호
					//jmvo.JUBSU_NO       = ((CertPayVO)argVo).serial_no;          // 접수번호
					jmvo.SULGYE_NO      = (String)map.get("engn_no");            // 설계번호                 	
		 			
				} else if ( strGubn.equals("STEP03")) {
					Map<String,Object> map = new HashMap<String, Object>();
					map = (HashMap<String,Object>)argVo;
					jmvo.GOGAEK_NO      = (String)map.get("inhab_no"); // 주민번호
					jmvo.BALSHINJA_NO   = (String)map.get("tel");     // 발신자번호
					jmvo.STATUS         = "완료";          // 접수, 완료
					jmvo.UPMU_DESC1     = "해외여행보험";   // 메뉴 레벨1 
					jmvo.UPMU_DESC2     = "보험료결제";    // 메뉴 레벨2
					jmvo.POLI_NO        = (String)map.get("stock_seq"); // 증권번호
					//jmvo.JUBSU_NO       = ((AccountingVO)argVo).job.seq_no;    // 접수번호
					jmvo.SULGYE_NO      = (String)map.get("engn_no");   // 설계번호
				} 
				
				/*
				 * 해외여행자보험 상담신청
				 */
				/*
				if ( strGubn.equals("SANGDAM")) {  // 상담신청
					CuCounVO cJoinVo = (CuCounVO)argVo;
					jmvo.STATUS         = "완료";                // 접수, 완료
					jmvo.UPMU_DESC1     = "해외여행보험";         // 메뉴 레벨1 
					jmvo.UPMU_DESC2     = "보험가입상담신청";      // 메뉴 레벨2
					jmvo.UPMU_DESC3     = cJoinVo.cm_pa_gubun;  // 메뉴 레벨3
					jmvo.GOGAEK_NO      = cJoinVo.cust_jumin;   // 주민번호
					jmvo.BALSHINJA_NO   = cJoinVo.phone_1 + cJoinVo.phone_2 + cJoinVo.phone_3;     // 발신자번호
					   			
				}
				*/
				
				
				/*
				 * 자동차, 컨버전스, 아이사랑, 스마트운전자, 내인생플러스
				 */
				
				if ( 
						strGubn.equals(MOBILE_LOG_CAR) 				// 자동차
						|| strGubn.equals(MOBILE_LOG_CONVERSIONS) 	// 컨버전스
						|| strGubn.equals(MOBILE_LOG_CHILDLOVE) 	// 아이사랑
						|| strGubn.equals(MOBILE_LOG_SMARTCAR)		// 스마트운전자
						|| strGubn.equals(MOBILE_LOG_MYLIFE)		// 내인생행복진단
				) { 
					CuCounVO cJoinVo = (CuCounVO)argVo;
					jmvo.GOGAEK_NO      = cJoinVo.cust_jumin;   	// 주민번호
					jmvo.SANGDAMIL_DATE = cJoinVo.sangdamil_date;   // 상담일자
					jmvo.BALSHINJA_NO   = cJoinVo.phone_1 + cJoinVo.phone_2 + cJoinVo.phone_3;     // 발신자번호
					jmvo.STATUS         = cJoinVo.status;            // 접수완료
					jmvo.UPMU_DESC1     = cJoinVo.upmu_desc1;        // 메뉴 레벨1 
					jmvo.UPMU_DESC2     = cJoinVo.upmu_desc2;   	 // 메뉴 레벨2
					jmvo.UPMU_DESC3     = cJoinVo.upmu_desc3;  		 // 메뉴 레벨3				
					jmvo.NOTE			= "";
				}
				
				/*
				 * 증명서 발급
				 */			
				else if ( strGubn.equals(MOBILE_LOG_AUTHENTICATION)) {  
					CuCounVO cJoinVo = (CuCounVO)argVo;
					jmvo.GOGAEK_NO      = cJoinVo.cust_jumin;   	// 주민번호
					jmvo.SANGDAMIL_DATE = cJoinVo.sangdamil_date;   // 상담일자
					jmvo.BALSHINJA_NO   = "";     					// 발신자번호
					jmvo.STATUS         = cJoinVo.status;           // 성공 or 실패
					jmvo.UPMU_DESC1     = cJoinVo.upmu_desc1;       // 증명서
					jmvo.UPMU_DESC2     = cJoinVo.upmu_desc2;   	// 자동차 or 장기
					jmvo.UPMU_DESC3     = cJoinVo.upmu_desc3;  		// 증명서명
					jmvo.POLI_NO		= cJoinVo.poliNo;			// 증권번호
					jmvo.NOTE			= cJoinVo.sendNote;			// 이메일 or FAX
				}
				/*
				 * 긴급출동
				 */			
				else if ( strGubn.equals(EMERGENCY)) {  
					CuCounVO cJoinVo = (CuCounVO)argVo;
					jmvo.SANGDAMIL_DATE = cJoinVo.sangdamil_date;   // 신청일시
					jmvo.UPMU_DESC1     = cJoinVo.upmu_desc1;       // 긴급출동
					jmvo.UPMU_DESC2     = cJoinVo.upmu_desc2;   	// 긴출 접수
					jmvo.UPMU_DESC3     = cJoinVo.upmu_desc3;  		// 서비스 접수
					jmvo.STATUS         = cJoinVo.status;           // 성공(배정) or 성공(미배정) or 실패
//					jmvo.cust_name      = cJoinVo.cust_name;   		// 고객명 (요청자)
					jmvo.GOGAEK_NO      = cJoinVo.cust_jumin;   	// 주민번호
					jmvo.BALSHINJA_NO   = cJoinVo.cust_phone;		// 발신자번호
					jmvo.POLI_NO		= cJoinVo.poliNo;			// 증권번호
				}
				/**
				 * 자동이체 계좌변경 결과 로그
				 */
				else if(strGubn.equals("CY_MA_INFO_TRAN_BULK_SAVE"))
				{
					HashMap<String, String> param = (HashMap<String, String>)argVo;
					jmvo.setGOGAEK_NO((String)param.get("GOGAEK_NO"));
					jmvo.setSTATUS((String)param.get("STATUS"));
					jmvo.setUPMU_DESC1((String)param.get("UPMU_DESC1"));
					jmvo.setUPMU_DESC2((String)param.get("UPMU_DESC2"));
					jmvo.setUPMU_DESC3((String)param.get("UPMU_DESC3"));
					jmvo.setNOTE((String)param.get("NOTE"));
//					jmvo.setSANGDAMIL_DATE	= (String)param.get("SANGDAMIL_DATE");   
					jmvo.setBALSHINJA_NO((String)param.get("BALSHINJA_NO"));  
					jmvo.setPOLI_NO((String)param.get("POLI_NO"));
					jmvo.setJUBSU_NO((String)param.get("JUBSU_NO"));
					jmvo.setSULGYE_NO((String)param.get("SULGYE_NO"));
				}
				/**
				 * 대출
				 */
				/*else if ( strGubn.equals(LOAN)) {  
					HashMap param = (HashMap)argVo;
					jmvo.GOGAEK_NO      = (String)param.get("JUMIN");   	// 주민번호
					jmvo.STATUS         = (String)param.get("SUCCESS");    // 성공 or 실패
					jmvo.UPMU_DESC1     = "계약대출";    // 증명서
					jmvo.UPMU_DESC2     = (String)param.get("DESC2");   	// 자동차 or 장기
					jmvo.POLI_NO		= (String)param.get("POLI_NO");	// 증권번호
					jmvo.JUBSU_NO		= (String)param.get("JUBSU_NO");	// 증권번호
					jmvo.NOTE			= (String)param.get("ERROR_MSG");	// 이메일 or FAX
				}*/
				
				/**
				 * 보상접수
				 */
				else if ( strGubn.equals(COMPENSATE)) {  
					HashMap<String, String> param = (HashMap<String, String>)argVo;
					jmvo.GOGAEK_NO      = param.get("JUMIN");   	// 주민번호
					jmvo.SANGDAMIL_DATE = param.get("REG_DT");   	// 접수일
					jmvo.STATUS         = param.get("STATUS");    	// 접수완료 성공 or 접수완료 실패
					jmvo.UPMU_DESC1     = param.get("DESC1");    	// 보상접수
					jmvo.UPMU_DESC2     = param.get("DESC2");   	// 상해 or 자녀
					jmvo.JUBSU_NO		= param.get("JUBSU_NO");	// 접수번호
					jmvo.NOTE			= "";
				}				
//				CmmJmVO result = cmmWb.selectDicMobileHis(jmvo);
				
				//CUSTOMER_CENTER 
				NameValuePair[] nvp = HttpClientUtil.getNameValuePairs(jmvo);
				byte[] resultByte = HttpClientUtil.callPost(ccUrl, nvp);
//				byte[] resultByte = HttpClientUtil.callPost(CUSTOMER_CENTER, nvp);
				
				System.out.println("===============CUSTOMER_CENTER==============="+ccUrl);
				System.out.println(new String(resultByte,"UTF-8"));
				
			} catch( Exception e) {
//				 logger.error(e.toString());
			}
		}
	}
	
	public static String getClientIP(HttpServletRequest request){
		String userip = request.getHeader("X-Forwarded-For");
		
		if(userip == null || "".equals(userip)){
			userip = request.getRemoteAddr();
		}
		if(userip == null || "".equals(userip)){
			return "";
		}
		
		String[] userips = userip.split(",");
		return userips[0];
	}
	
	/** 메뉴이용시간 */
	private static Map<String,String> useTime = null;
	public static void setUserTime(){
		useTime = new HashMap<String,String>();
		//시작시간|끝시간|요일(0:야간, 5:월~금, 7:일주일 6:토)
		useTime.put("CyMaCarNumber", 		"0900|2100|7|차량번호변경");		//차량번호변경	
		useTime.put("CyMaCarScope",  		"0900|2100|7|연령특약변경");		//연령특약변경
		useTime.put("CyMaCarRecall", 		"0900|1700|5|자동차청약철회");	//자동차청약철회
		useTime.put("CyMaTermRecall", 		"0900|1700|5|장기청약철회");		//장기청약철회
		useTime.put("CyMaTermDelete", 		"0900|1700|5|장기계약해지");		//장기계약해지 09 ~17
		useTime.put("CyMaInfoTran", 		"0900|2100|6|자동이체|0900|1200");//자동이체
		useTime.put("CyPayIn", 				"0900|1930|6|자동차분납보험료 납입|0900|1200");//자동차분납보험료 납입
		useTime.put("CyPayRe", 				"0900|1930|6|자동차갱신보험료 납입|0900|1200");//자동차갱신보험료 납입
		useTime.put("CyPayTerm", 			"0900|1930|6|장기보험료 납입|0900|1200");//장기보험료 납입
		useTime.put("CyReEx", 				"0830|2300|7|만기환급금");		//만기환급금
		useTime.put("CyReMid", 				"0830|2300|7|중도환급금");		//중도환급금
		useTime.put("CyReDor", 				"0900|1700|5|휴면보험금");		//휴면보험금
		useTime.put("CyCerPri", 			"0900|1800|0|연말정산Fax신청");	//연말정산Fax신청
		useTime.put("LoInsuAppApply",	 	"0830|2300|7|보험대출신청");		//보험대출신청
		useTime.put("LoCreditApply", 		"0930|1600|5|신용대출신청");		//신용대출신청
		useTime.put("LoInsuRepApply", 		"0900|2100|5|대출원리금상환");	//대출원리금상환
		useTime.put("LoInsuAppointList", 	"2300|0830|0|대출예약");			//대출예약
		useTime.put("LoInsuAppointCancel", 	"2300|0830|0|대출예약취소");		//대출예약취소
		//베스트자녀사랑 채팅  타이머 적용 : 20080125 최문성
		useTime.put("MallHealBest1Chat", 	"0900|1800|5|베스트자녀채팅상담");		//베스트자녀채팅상담
		useTime.put("LoInsuAppAccount", 	"0900|2100|6|이자납입계좌변경|0900|1200");		//이자납입계좌변경
		useTime.put("CyMaCarDelete", 		"0900|1700|5|자동차양도말소해지");		//자동차말소해지
		
		
		useTime.put("LoInsuRepApply",	 	"0900|2100|5|대출상환신청");		//상환
	}
	
	public static boolean isUserUseTime(String key){

		if(useTime == null){
			setUserTime();
		}
		String time = (String)useTime.get(key);
		if(time == null || "".equals(time)) return false;
		String []arrTime = StringUtil.split(time, "|");
		String nowTime = DateUtil.getHour()+DateUtil.getMin();
		String holiday = checkHoliday();	//N: 일요일, Y: 토요일, "": 평일	/ 2차 소스에서는 DB에 뭔가 조회하던데... 이케해도 안되나?
//		String str = "nowTime:"+nowTime+",holiday:"+holiday;
//		for(int i = 0; i < arrTime.length; i++){
//			str += (", arrTime["+i+"]:"+arrTime[i]);
//		}
		
//		if("CyMaInfoTran".equals(key)){
//			logger.debug("-------key:"+key);
//			logger.debug(str);
//			logger.debug("-------------------------------------");
//		}
		//토,일요일에 평일메뉴일때
		if( !"".equals(holiday) && "5".equals(arrTime[2])) return false;
		
		//야간메뉴(대출예약)
		if("0".equals(arrTime[2])){
			//휴일이면 
			if(!"".equals(holiday)) return true;
			//휴일이 아니고 특정시간 이후,이전이면
			if((Integer.parseInt(nowTime) > Integer.parseInt(arrTime[0]) || Integer.parseInt(nowTime) < Integer.parseInt(arrTime[1]))){
				return true;
			}
		}
		//토요일메뉴
		if("6".equals(arrTime[2])){
			//일요일
			if("N".equals(holiday)) return false;
			//토요일
			if("Y".equals(holiday)){
				//토요일 이용시간 이내이면
				if((Integer.parseInt(nowTime) > Integer.parseInt(arrTime[4]) && Integer.parseInt(nowTime) < Integer.parseInt(arrTime[5]))) return true;
			}else{	//평일
				//평일 이용시간 이내이면
				if((Integer.parseInt(nowTime) > Integer.parseInt(arrTime[0]) && Integer.parseInt(nowTime) < Integer.parseInt(arrTime[1]))) return true;
			}
			return false;
		}
		//야간메뉴가 아니고 평일 이용시간 이내이면
		if(!"0".equals(arrTime[2]) && Integer.parseInt(nowTime) > Integer.parseInt(arrTime[0]) && Integer.parseInt(nowTime) < Integer.parseInt(arrTime[1])){
			return true; 
		}
		
		return false;
	}

	//N: 일요일, Y: 토요일, "": 평일
	private static String checkHoliday() {
		 Calendar oCalendar = Calendar.getInstance( );  // 현재 날짜/시간 등의 각종 정보 얻기
		 int yoil = oCalendar.get(Calendar.DAY_OF_WEEK);
		 
		switch (yoil) {
			case 1:
				return "N";
			case 7:
				return "Y";
			default:
				return "";
		}
		 
	}

	/**
	 * @param uniqueCallUrl
	 * @param request 
	 * @info uniqueCall조회
	 * @return
	 * @throws Exception 
	 * @throws IOException 
	 */
	public static String selectUniqueCall(String uniqueCallUrl, HttpServletRequest request) throws IOException, Exception {
		//1. 현재 세션에 해당값이 있는지 조회
		Object ssnTermId = request.getSession().getAttribute("ssnTermId");
		
		if("".equals(StringUtil.nvl(ssnTermId))){	//없다면 조회함
			byte[] bytes = HttpClientUtil.callPost(uniqueCallUrl, "");
			
			String temp = new String(bytes,"UTF-8").trim();
			request.getSession().setAttribute("ssnTermId", temp);
			return temp;
			
		}else{
			return ssnTermId.toString();
		}
		
	}
	
	/** 기간계서 쓰는 카드 발급사 코드 */
	// 01: BC, 02: 국민, 03: VISA, 04:삼성, 05: 엘지, 06:아멕스, 07: 다이너스, 08: 신한카드
	public static String getBALGPSA_CD(String CRCOM_CD) {
		String cd = getBALGPSA_CD2(CRCOM_CD);
		if("".equals(cd.trim())) return CRCOM_CD;
		return cd;
	}

	public static String getBALGPSA_CD2(String CRCOM_CD) {
		String card_type_tmp = "," + StringUtil.substring(CRCOM_CD,0,3) + ",";
		if(",300,310,260,261,".indexOf(card_type_tmp)!=-1) return "01";
		if(",100,110,111,112,120,121,123,130,131,133,140,141,160,161,170,171,"
				.indexOf(card_type_tmp)!=-1) return "02";
		if(",200,210,211,212,220,221,230,231,240,241,250,251,270,271,150,151,910,920,"
				.indexOf(card_type_tmp)!=-1) return "03";
		if(",500,510,".indexOf(card_type_tmp)!=-1) return "04";
		if(",400,410,".indexOf(card_type_tmp)!=-1) return "05";
		if(",700,710,".indexOf(card_type_tmp)!=-1) return "06";
		if(",600,610,620,".indexOf(card_type_tmp)!=-1) return "07";
		return "  ";
	}

	/** 기간계서 쓰는 카드 코드 */
	public static String getCARDSA_GB(String CRCOM_CD) {
		if("620".equals(CRCOM_CD)) return "610";
		return CRCOM_CD;
	}  
	
	/** 주민등록번호 유효성 체크 **/
	public static boolean isJumin(String jumin) {
		boolean isKorean = true;
		int check = 0;
		if (jumin == null || jumin.length() != 13)
			return false;
		if (Character.getNumericValue(jumin.charAt(6)) > 4
				&& Character.getNumericValue(jumin.charAt(6)) < 9) {
			isKorean = false;
		}
		for (int i = 0; i < 12; i++) {
			if (isKorean)
				check += ((i % 8 + 2) * Character.getNumericValue(jumin
						.charAt(i)));
			else
				check += ((9 - i % 8) * Character.getNumericValue(jumin
						.charAt(i)));
		}
		if (isKorean) {
			check = 11 - (check % 11);
			check %= 10;
		} else {
			int remainder = check % 11;
			if (remainder == 0)
				check = 1;
			else if (remainder == 10)
				check = 0;
			else
				check = remainder;

			int check2 = check + 2;
			if (check2 > 9)
				check = check2 - 10;
			else
				check = check2;
		}

		if (check == Character.getNumericValue(jumin.charAt(12))){
			return true;
		}else{
			return false;
		}
	}
}
