package com.idongbu.util;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class CipherUtil {
 
	private @Value("${aes.key}") String AES_KEY;
	
    public String encrypt(String str) throws Exception {
    	
    	if ( str == null ) str = "";
    	
    	String encryptStr = null;

        CipherUtil cu = new CipherUtil();
        Calendar cal = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("yyMMddHHmmss",Locale.KOREA);
        String dtStr = sdf.format(cal.getTime());
        
        String text = dtStr + str;
        System.out.println("AES_KEY:" + AES_KEY);
        try {
        	encryptStr = cu.encryptAES(text, AES_KEY);
        } catch (Exception e) {
        	e.printStackTrace();
        	throw e;
        }
        
    	return encryptStr;
    }
    
    public String decrypt(String str) throws Exception {
    	
    	if ( str == null ) return "";
    	
    	String decryptStr = null;
    	CipherUtil cu = new CipherUtil();

    	String text = null;
        try {
        	text = cu.decryptAES(str, AES_KEY);
        } catch (Exception e) {
         	e.printStackTrace();
         	throw e;
        }
        
        decryptStr = text.substring(12, text.length());
        
    	return decryptStr;
    }    
    
    
    // key는 16바이트로 구성 되어야 한다.
    private String encryptAES(String s, String key) throws Exception {
        String encrypted = null;
        try {
            SecretKeySpec skeySpec = new SecretKeySpec(key.getBytes(), "AES");
             
            Cipher cipher = Cipher.getInstance("AES");
            cipher.init(Cipher.ENCRYPT_MODE, skeySpec);
             
            encrypted = byteArrayToHex(cipher.doFinal(s.getBytes()));
            return encrypted;
        } catch (Exception e) {
            throw e;
        }
    }
     
    // key는 16 바이트로 구성 되어야 한다.
    private String decryptAES(String s, String key) throws Exception {
        String decrypted = null;
        try {
            SecretKeySpec skeySpec = new SecretKeySpec(key.getBytes(), "AES");
             
            Cipher cipher = Cipher.getInstance("AES");
            cipher.init(Cipher.DECRYPT_MODE, skeySpec);
            decrypted = new String(cipher.doFinal(hexToByteArray(s)));
            return decrypted;
        } catch (Exception e) {
            throw e;
        }
    }
     
    private byte[] hexToByteArray(String s) {
        byte[] retValue = null;
        if (s != null && s.length() > 0) {
            retValue = new byte[s.length() / 2];
            for (int i = 0; i < retValue.length; i++) {
                retValue[i] = (byte) Integer.parseInt(s.substring(2 * i, 2 * i + 2), 16);
            }
        }
        return retValue;
    }
     
    private String byteArrayToHex(byte buf[]) {
        StringBuffer strbuf = new StringBuffer(buf.length * 2);
        for (int i = 0; i < buf.length; i++) {
            if (((int) buf[i] & 0xff) < 0x10) {
                strbuf.append("0");
            }
            strbuf.append(Long.toString((int) buf[i] & 0xff, 16));
        }
         
        return strbuf.toString();
    }
}
