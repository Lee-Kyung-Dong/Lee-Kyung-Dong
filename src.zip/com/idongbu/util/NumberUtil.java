package com.idongbu.util;

import java.text.DecimalFormat;

public class NumberUtil {

	public static String cNumber(String str) throws Exception {
		if (str != null && !str.equals(""))
			str = str.trim();
		else
			str = "0";
		long num = 0L;
		num = Long.parseLong(str);
		DecimalFormat df = new DecimalFormat("###,###,###,###,###,###,###");
		str = df.format(num);
		return str;
	}

}
