package com.idongbu.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Vector;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.ChannelSftp.LsEntry;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;

public class FTPUtil {
    private final Logger logger = LoggerFactory.getLogger(this.getClass());
    private Session session = null;
    private Channel channel = null;
    private ChannelSftp channelSftp = null;
    
    private String url = null;
    private String user = null;
    private String password = null;
    private int port = 0;
    
    public FTPUtil(String url, String user, String password, int port) throws Exception {
    	setInfo(url, user, password, port);
    	logger.debug("url: " + url);
    	logger.debug("user: " + user);
    	logger.debug("password: " + password);
    	logger.debug("port: " + port);
    	init();
    }
    
    private void setInfo(String u1, String u2, String p1, int p2) {
    	url = u1;
    	user = u2;
    	password = p1;
    	port = p2;
    }

    // SFTP 서버연결
    public void init() throws Exception {
        //JSch 객체 생성
        JSch jsch = new JSch();

        try {
        	//세션객체 생성 ( user , host, port )     
            session = jsch.getSession(user, url, port);

            //password 설정
            session.setPassword(password);

            //세션관련 설정정보 설정
            java.util.Properties config = new java.util.Properties();

            //호스트 정보 검사하지 않는다
            config.put("StrictHostKeyChecking", "no");
            session.setConfig(config);

            //접속
            session.connect(10000);

            //sftp 채널 접속
            channel = session.openChannel("sftp");
            channel.connect();
            logger.debug("----- connected -----");
        } catch (JSchException e) {
            logger.debug("----- connetion error -----");
            throw e;
        }

        channelSftp = (ChannelSftp) channel;
    }

    // 단일 파일 업로드
    public void upload(String dir, File file) throws Exception{
        FileInputStream in = null;
        try { //파일을 가져와서 inputStream에 넣고 저장경로를 찾아 put
            in = new FileInputStream(file);
            channelSftp.cd(dir);
            channelSftp.put(in,file.getName());
        }catch(SftpException se){
            logger.debug(StringUtil.getStackTraceString(se));
        }catch(FileNotFoundException fe){
            logger.debug(StringUtil.getStackTraceString(fe));
        }finally{
            try{
                in.close();
            } catch(IOException ioe){
                throw ioe;
            }
        }
    }
    
    // 단일 파일 업로드 (OCR)
    public String uploadToOCR(String dir, File file, String suffix) throws Exception{
        FileInputStream in = null;
        String filename1 = "";
        String filename2 = "";
        try { //파일을 가져와서 inputStream에 넣고 저장경로를 찾아 put
            in = new FileInputStream(file);
            filename1 = file.getName() + suffix;
            filename2 = filename1 + "--E";
            channelSftp.cd(dir);
            channelSftp.put(in, filename1);
            channelSftp.rename(filename1, filename2);
        }catch(SftpException se){
            logger.debug(StringUtil.getStackTraceString(se));
        }catch(FileNotFoundException fe){
            logger.debug(StringUtil.getStackTraceString(fe));
        }finally{
            try{
                in.close();
            } catch(IOException ioe){
                throw ioe;
            }
        }
        return filename2;
    }    
    
    // 단일 파일 업로드
    public void upload(String dir, String file) throws Exception {
        upload(dir, new File(file));
    }

    // 단일 파일 업로드 (OCR)
    public String uploadToOCR(String dir, String file, String suffix) throws Exception {
    	return uploadToOCR(dir, new File(file), suffix);
    }

    // 단일 파일 다운로드
    public InputStream download(String dir, String fileNm) throws Exception {
        InputStream in = null;
        String path = "...";
        try { //경로탐색후 inputStream에 데이터를 넣음
            channelSftp.cd(path+dir);
            in = channelSftp.get(fileNm);
        }catch(SftpException se){
            throw se;
       }

       return in;
    }
    
    // 단일 파일 다운로드 (OCR)
    public void downloadFromOCR(String dir, String src, String dst) throws Exception {
        try { //경로탐색후 inputStream에 데이터를 넣음
            channelSftp.cd(dir);
            channelSftp.get(src, dst);
        }catch(SftpException se){
            throw se;
       }
    }

    public String[] ls(String dir) throws Exception {
    	logger.debug("ls " + dir);
    	String[] ls = new String[0];
    	
    	try {
			@SuppressWarnings("rawtypes")
			Vector v = channelSftp.ls(dir);
			ls = new String[v.size()];
			for(int i = 0; i < v.size(); i++) {
				ls[i] = ((LsEntry) v.get(i)).getFilename();
			}
		}
    	catch (SftpException e) {
            throw e;
		}
    	
    	return ls;
    }
    
    public void rename(String filename1, String filename2) throws Exception {
		logger.debug("rename " + filename1 + " " + filename2);
    	try {
			channelSftp.rename(filename1, filename2);
		}
    	catch (SftpException e) {
            throw e;
		}
    }
    
    // 파일서버와 세션 종료
    public void disconnect(){
        channelSftp.quit();
        session.disconnect();
        logger.debug("----- disconnected -----");
    }

}