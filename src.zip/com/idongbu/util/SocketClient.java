package com.idongbu.util;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.InterruptedIOException;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.Socket;
import java.net.UnknownHostException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import aes.SecuX;

public class SocketClient {
	
	private final Logger logger = LoggerFactory.getLogger(SocketClient.class);
	
	Socket xSocket;
	DataOutputStream out;
	DataInputStream in;
	BufferedReader stdIn;
	byte[] btWriteBuf;

	public SocketClient() {
		this.xSocket = null;

		this.out = null;
		this.in = null;

		this.stdIn = null;
	}

	public boolean Connect(String paramString, int paramInt1, int paramInt2) {
		try {
			this.xSocket = new Socket(paramString, paramInt1);

			OutputStream localOutputStream = this.xSocket.getOutputStream();
			InputStream localInputStream = this.xSocket.getInputStream();

			this.out = new DataOutputStream(localOutputStream);
			this.in = new DataInputStream(localInputStream);
		} catch (UnknownHostException localUnknownHostException) {
			return false;
		} catch (IOException localIOException) {
			return false;
		}

		this.stdIn = new BufferedReader(new InputStreamReader(System.in));

		return true;
	}

	public boolean Disconnect() {
		try {
			this.out.close();
			this.in.close();
			this.stdIn.close();
			this.xSocket.close();
		} catch (Exception localException) {
			return false;
		}

		return true;
	}

	public StringBuffer SendWritePacket(String paramString1,
			String paramString2, int paramInt, String paramString3) {
		StringBuffer localStringBuffer = new StringBuffer("");
		int i = 4111;
		int j = paramInt * 1000;

		SecuX localSecuX = new SecuX();
		byte[] arrayOfByte2;
		try {
			int k = localSecuX.EncSize(paramString3.length());

			if(k < 0){	//웹 보안성 심의 수정
				return localStringBuffer;
			}
			
			byte[] arrayOfByte1 = new byte[k];
			arrayOfByte2 = new byte[k];

			this.btWriteBuf = new byte[i];

//			paramString3 = chgUtf82EucKr(paramString3);
//			System.out.println("euc로 바뀐 param3 : " + paramString3);
			
			arrayOfByte2 = paramString3.getBytes("EUC-KR");
			

			SecuX.Encryption(arrayOfByte2, arrayOfByte1, k);

			if (!(Connect(paramString1, Integer.parseInt(paramString2), j))) {
				paramString3 = paramString3.concat(new String("5".getBytes(), "EUC-KR"));

				localStringBuffer.append(paramString3);

				return localStringBuffer;
			}

			this.out.write(arrayOfByte1);
			try {
				this.in.readFully(this.btWriteBuf);
			} catch (InterruptedIOException localInterruptedIOException) {
				System.out.println(" in.readFully(btWriteBuf) : "
						+ localInterruptedIOException);
				Disconnect();
				paramString3 = paramString3.concat(new String("5".getBytes(), "EUC-KR"));
				localStringBuffer.append(paramString3);
				return localStringBuffer;
			}

		} catch (EOFException localEOFException) {
			arrayOfByte2 = new byte[i];

			SecuX.Decryption(this.btWriteBuf, arrayOfByte2, i);

			int l = 0;
			byte[] arrayOfByte3 = new byte[1000];

			for (int i1 = 0; i1 < arrayOfByte2.length; ++i1) {
				arrayOfByte3[l] = 0;

				if ((arrayOfByte2[i1] == 0) || (arrayOfByte2[i1] == 10)) {
					localStringBuffer.append(new String(arrayOfByte3).trim());
					break;
				}

				if ((arrayOfByte2[i1] >= 1) && (arrayOfByte2[i1] <= 126)) {
					arrayOfByte3[l] = arrayOfByte2[i1];
					++l;
				} else {
					arrayOfByte3[l] = arrayOfByte2[i1];
					arrayOfByte3[(l + 1)] = arrayOfByte2[(i1 + 1)];

					l += 2;
					i1 += 1;
				}

				if (l < 998)
					continue;
				localStringBuffer.append(new String(arrayOfByte3));

				l = 0;
				arrayOfByte3 = new byte[1000];
			}

			Disconnect();
		} catch (IOException localIOException) {
			logger.error(localIOException.getMessage());
		}

		return localStringBuffer;
	}
	
	public String chgUtf82EucKr(String str) {
		if ( str == null )  return "";
		
		String r = null;
		
		try {
			r = new String(str.getBytes("UTF-8"), "EUC-KR");
		} catch(UnsupportedEncodingException e) { 
			logger.error(e.getMessage());
		}
		
		return r;
	}
}