package com.idongbu.util;

import com.idongbu.common.vo.CMMVO;

public class NameCheckVO extends CMMVO {
	public String jumin_no		= "";	// 주민번호
	public String name			= "";	// 성명 
	public int check_type		= 0;	// 0:국내, 1: 외국인

	public String result_code	= "";	// 결과코드

	public String member_gb	= "";	// 1:idongbu  2:direct  3:homeplus  4:blueclub  5:interpark
	public String use_gb		= "";	// 001:회원가입, 002:보험료산출, 003:이벤트참여, 004:산출예약
	public String idx			= "";
	public int retCode          = 0; // 리턴코드
	public String retMsg        = ""; // 리턴메시지
	public String remoteIp      = ""; // 원격IP
	
	public String getJumin_no() {
		return jumin_no;
	}
	public void setJumin_no(String jumin_no) {
		this.jumin_no = jumin_no;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getCheck_type() {
		return check_type;
	}
	public void setCheck_type(int check_type) {
		this.check_type = check_type;
	}
	public String getResult_code() {
		return result_code;
	}
	public void setResult_code(String result_code) {
		this.result_code = result_code;
	}
	public String getMember_gb() {
		return member_gb;
	}
	public void setMember_gb(String member_gb) {
		this.member_gb = member_gb;
	}
	public String getUse_gb() {
		return use_gb;
	}
	public void setUse_gb(String use_gb) {
		this.use_gb = use_gb;
	}
	public String getIdx() {
		return idx;
	}
	public void setIdx(String idx) {
		this.idx = idx;
	}
	public int getRetCode() {
		return retCode;
	}
	public void setRetCode(int retCode) {
		this.retCode = retCode;
	}
	public String getRetMsg() {
		return retMsg;
	}
	public void setRetMsg(String retMsg) {
		this.retMsg = retMsg;
	}
	public String getRemoteIp() {
		return remoteIp;
	}
	public void setRemoteIp(String remoteIp) {
		this.remoteIp = remoteIp;
	}
	
	
}
