package com.idongbu.util;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.StringUtils;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.xpath.XPath;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** ****************************************************************************
 * 문자열과 관련된 함수 모음 클래스.
 **************************************************************************** */
public class StringUtil extends StringUtils{

	private static final int JUMIN_MASKING_LEN 		= 6;	//주민번호 마스킹 문자수
	private static final int EMAIL_MASKING_LEN 		= 3;	//이메일id 마스킹 문자수
	private static final int CARD_MASKING_START 	= 7;	//카드번호 마스킹 시작자리수
	private static final int CARD_MASKING_LEN 		= 5;	//카드번호 마스킹 문자수
	private static final int ACCOUNT_MASKING_LEN 	= 4;	//계좌번호 마스킹 문자수
	
	private static Logger logger = LoggerFactory.getLogger(StringUtil.class.getName());
	
	public  static boolean isTextExist(String strTxt, String strComp)
	{
		String[] arrTxt = strTxt.split(":");
		if ( "".equals(strTxt))
			return false;
		
		for(int nLoop=0; nLoop < arrTxt.length; nLoop++)
		{
			if ( strComp.equals(arrTxt[nLoop]))
				return true;
		}
	    
		return false;
	}
	
	
	/**
	 * 문자열이 비어 있는지 체크한다.  
	 */
	public static boolean isEmpty(String str) {
		return str==null || "".equals(str);
	}

	// StringEscapeUtils 관련 함수 Start ***************************************//
	public static String escapeHtml(String str) {
		//return StringEscapeUtils.escapeHtml(str);
		str = replace(str, "'", "&#39;");
		str = replace(str, "\"", "&#34;");
		str = replace(str, ",", "&#44;");
		str = replace(str, "<", "&lt;");
		str = replace(str, ">", "&gt;");
		return str;
	}
	/** 특수문자(,)를 ',""로 변환
	 *   ==> '		//(char)7
	 *   ==> "		//(char)8
	 **/
	public static String escapeHtml2(String str) {
		String ch1 = String.valueOf((char)7);
		String ch2 = String.valueOf((char)8);
		str = StringUtil.replace(str,ch1,"'");			//따옴표(')
		str = StringUtil.replace(str,ch2,""+'"'+"");	//쌍따옴표(")
		return str;
	}
	
	public static String escapeHtmlBr(String str) {
		String ret = str.replaceAll("<", "&lt;").replaceAll("\r\n", "<br>")
					.replaceAll("\n", "<br>").replaceAll("\"", "&quot;")
					.replaceAll(" ", "&nbsp;");
		return ret;
	}

	public static String escapeJava(String str) {
		return StringEscapeUtils.escapeJava(str);
	}

	public static String escapeJavaScript(String str) {
		//return StringEscapeUtils.escapeJavaScript(str);
		str = replace(str, "\"", "\\\"");
		str = replace(str, "'", "\\\'");
		str = replace(str, "\r\n", "\\n");
		str = replace(str, "\n", "\\n");
		return str;
	}

	public static String escapeHtmlJavaScript(String str) {
		str = escapeHtml(str);
		str = replace(str, "&#34", "\\&#34");
		str = replace(str, "&#39", "\\&#39");
		return str;
	}

	public static String escapeSql(String str) {
		return StringEscapeUtils.escapeSql(str);
	}

	public static String escapeXml(String str) {
		return StringEscapeUtils.escapeXml(str);
	}

	public static String unescapeHtml(String str) {
		return StringEscapeUtils.unescapeHtml(str);
	}

	public static String unescapeJava(String str) {
		return StringEscapeUtils.unescapeJava(str);
	}

	public static String unescapeJavaScript(String str) {
		return StringEscapeUtils.unescapeJavaScript(str);
	}

	public static String unescapeXml(String str) {
		return StringEscapeUtils.unescapeXml(str);
	}
	
	// StringEscapeUtils Wrapper 관련 함수 End ***************************************//

	/** 주민번호 표시(1234561234567 -> 123456-1234567) */
	public static String getFmtJuminNo(String jumin_no) {
	    return getFmtJuminNo(jumin_no, false);
	}

	/** 주민번호 뒷자리 ** 표시 (1234561234567 -> 123456-*******) */
	public static String getFmtJuminNo(String jumin_no, boolean crypt) {
	    String retStr = "";
	    jumin_no = jumin_no == null ? jumin_no = "" : jumin_no.trim();

	    if (jumin_no.length()>6) {
	        retStr = jumin_no.substring(0,6) + "-";
	        retStr += crypt ? "*******" : jumin_no.substring(6) ;
	    }
	    return retStr;
	}

	/** 주민번호 뒷자리 ** 표시 (1234561234567 -> 123456-*******) */
	public static String getCryptJuminNo(String jumin_no) {
		return getFmtJuminNo(jumin_no, true);
	}

	/** 주민번호 뒷자리 ** 표시 (1234561234567 -> 123456-1******) */
	public static String getCryptJuminNo2(String jumin_no) {
	    String retStr = "";
	    jumin_no = jumin_no == null ? jumin_no = "" : jumin_no.trim().replaceAll("-","");

	    if (jumin_no.length()>7) {
	        retStr = jumin_no.substring(0,6) + "-";
	        retStr += jumin_no.substring(6,7) + "******";
	    }
	    return retStr;
	}


	/** 주민번호 배열로 자르기
	 * splitJuminNo("1234561234567")[0] -> 123456
	 * splitJuminNo("1234561234567")[1] -> 1234567
	 */
	public static String[] splitJuminNo(String jumin_no) {
	    return splitJuminNo(jumin_no, false);
	}
	
	/** 주민번호 암호화 해서 배열로 자르기
	 * splitJuminNo("1234561234567")[0] -> 123456
	 * splitJuminNo("1234561234567")[1] -> *******
	 */
	public static String[] splitJuminNo(String jumin_no, boolean crypt) {
	    String[] retArr = new String[]{"",""};

	    jumin_no = jumin_no == null ? "" : jumin_no.trim().replaceAll("-","");
	    if (jumin_no.length()>=6) {
	        retArr[0] = jumin_no.substring(0,6);
	        retArr[1] = crypt ? "*******" : jumin_no.substring(6) ;
	    } else {
	    	retArr[0] = jumin_no;
	    	retArr[1] = crypt ? "*******" : "";
	    }
	    return retArr;
	}

	/** 사업자번호 자르기 */
	public static String[] splitSaupNo(String saup_no) {
	    String[] retArr = new String[]{"","",""};

	    saup_no = saup_no == null ? "" : saup_no.trim().replaceAll("-","");
        retArr[0] = StringUtil.mid(saup_no, 0, 3);
        retArr[1] = StringUtil.mid(saup_no, 3, 2);
        retArr[2] = StringUtil.mid(saup_no, 5, 10);
	    return retArr;
	}

	public static String getFmtSaupNo(String saup_no) {
		String[] retArr = splitSaupNo(saup_no);
	    return StringUtil.isEmpty(retArr[0]) ? "" : retArr[0]+"-"+retArr[1]+"-"+retArr[2];
	}

	/** 전화번호
	 * getFmtTelNo("02","1234","5678") -> "02-1234-5678"
	 */
	public static String getFmtTelNo(String telno1, String telno2, String telno3) {
		return getFmtTelNo(telno1, telno2, telno3, true);
	}

	/** 전화번호
	 * getFmtTelNo("02","1234","5678") -> "02-1234-5678"
	 * getFmtTelNo("","1234","5678", false) -> "" no1, no2, no3가 하나라도 없으면 "" 리턴
	 */
	public static String getFmtTelNo(String telno1, String telno2, String telno3, boolean ignoreEmpty) {
		telno1 = telno1==null ? "" : telno1.trim();
		telno2 = telno2==null ? "" : telno2.trim();
		telno3 = telno3==null ? "" : telno3.trim();

		if(!ignoreEmpty) {
			if(StringUtil.isEmpty(telno1) || StringUtil.isEmpty(telno2)
				|| StringUtil.isEmpty(telno3)) {
				return "";
			}
		}
		return telno1 + "-" + telno2 + "-" + telno3;
	}

	/** 전화번호에 - 추가
	 * getFmtTelNo("02 1234 5678") -> "02-1234-5678"
	 * getFmtTelNo("02-1234-5678") -> "02-1234-5678"
	 * getFmtTelNo("0212345678") -> "02-1234-5678"
	 */
	public static String getFmtTelNo(String telno) {
		String[] arr = splitTelNo(telno);
		if("".equals(arr[0])) return "";
		if("".equals(arr[2])) return arr[0] + "-" + arr[1];
		return arr[0] + "-" + arr[1] + "-" + arr[2];
	}

	/** 전화번호를 12자리로(전문용)
	 * getFmtTelNo("02 1234 5678") -> "02  12345678"
	 * getFmtTelNo("02-1234-5678") -> "02  12345678"
	 * getFmtTelNo("0212345678") -> "02  12345678"
	 */
	public static String getFmtTelNo12(String telno) {
		String[] arr = splitTelNo(telno);
		return StringUtil.rpad(arr[0],4," ") + StringUtil.rpad(arr[1],4," ") + StringUtil.rpad(arr[2],4," ");
	}

	/** 전화번호 자르기
	 * splitTelNo("02 1234 5678")[0]
	 * splitTelNo("02-1234-5678")[1]
	 * splitTelNo("0212345678")[2]
	 */
	public static String[] splitTelNo(String telno) {
		String[] ret = new String[]{"","",""};
		telno = nvl(telno, "").replaceAll("[- ]", "");
		if("".equals(telno)) return ret;
		int len = telno.length();
		if(len<8) return ret;
		if(len==7) {
			ret[0] = substring(telno,0,3);
			ret[1] = substring(telno,3, 7);
		} else if(telno.lastIndexOf("15880100") >= 0) {
			//int idx = telno.lastIndexOf("15880100");
			//ret[0] = substring(telno, idx, idx+4);
			//ret[1] = substring(telno, idx+4, idx+8);
			ret[0] = "1588";
			ret[1] = "0100";
		} else if(len==8) {
			ret[0] = substring(telno,0,4);
			ret[1] = substring(telno,4, 8);
		} else if(telno.startsWith("02")) {
			if(len==9) {
				ret[0] = substring(telno,0,2);
				ret[1] = substring(telno,2,5);
				ret[2] = substring(telno,5,9);
			} else {
				ret[0] = substring(telno,0,2);
				ret[1] = substring(telno,2,6);
				ret[2] = substring(telno,6,10);
			}
		} else if(len==10){
			ret[0] = substring(telno,0,3);
			ret[1] = substring(telno,3, 6);
			ret[2] = substring(telno,6,10);
		} else if(len==11){
			ret[0] = substring(telno,0,3);
			ret[1] = substring(telno,3, 7);
			ret[2] = substring(telno,7,11);
		} else {
			ret[0] = substring(telno,0,4);
			ret[1] = substring(telno,4, 8);
			ret[2] = substring(telno,8,12);
		}
		return ret;
	}

	/** email 자르기
	 * splitEmail("no@spam.com")[0] => "no"
	 * splitEmail("no@spam.com")[1] => "spam.com"
	 */
	public static String[] splitEmail(String email) {
		String[] retStr = new String[]{"",""};
		email = email== null ? "" : email.trim();

		int idx = email.indexOf("@");
		if(idx==-1) {
			retStr[0] = email;
		} else {
			retStr[0] = email.substring(0, idx);
			retStr[1] = email.substring(idx+1);
		}
		return retStr;
	}
	
	/**
	 * email 개인정보 표시규치 적용
	 * 입력값 test@email.com  -> 반환값 te**@email.com
	 */
	public static String getFmtEmail(String email){
		String [] retStr = new String[]{"",""};
		
		retStr = splitEmail(email);
		if(!"".equals(retStr[0]) && !"".equals(retStr[1])) {
			email = getFmtCrypt(retStr[0], 2)+"@"+retStr[1]; 
		}
		return email;
		
	}

	/** 증권번호 별표시
	 * 뒷 6자리를 *표로 바꾼다.
	 * K12346-123-456	=> K12346-***-***
	 * K12346123456	=> K12346******
	 */
	public static String getCryptPolyNo(String str) {
		return getFmtCrypt(str, 6);
	}

	/** 계좌번호 별표시
	 * 뒷 6자리를 *표로 바꾼다.
	 * K12346-123-456	=> K12346-***-***
	 * K12346123456	=> K12346******
	 */
	public static String getCryptAccNo(String str) {
		return getFmtCrypt(str, 6);
	}
	
	/*계좌번호,증권번호등의 "-"문자를 삭제 
	 * A123-33-2222 ---> A123332222*/
	public static String getReplaceAccNo1(String str){
		return str.replaceAll("-", "");
	}
	
	/*금액등의 ","문자를 삭제 
	 * 100,000 ---> 100000*/
	public static String getReplaceComma(String str){
		return str.replaceAll(",", "");
	}
	
	/** str 뒤에서 len 자리만큼 * 처리 */
	public static String getFmtCrypt(String str, int len) {
		if(StringUtil.isEmpty(str)) return str;
		char[] data = str.toCharArray();
		int idx = data.length-1;
		while(len>0 && idx>=0) {
			if('-'!=data[idx]) {
				data[idx] = '*';
				len--;
			}
			idx--;
		}
		return new String(data);
	}
	
	public static String getFmtCrypt(String str) {
		if(StringUtil.isEmpty(str)) return str;
		char[] data = str.toCharArray();
		
		if(data.length < 3) {
			for(int i = 0; i < data.length; i++) {
				if(i != 0) {
					data[i] = '*';
				}
			}
		}
		else {
			for(int i = 0; i < data.length; i++) {
				if(i != 0 && i + 1 != data.length) {
					data[i] = '*';
				}
			}
		}
		
		return new String(data);
	}	
	
	/** 우편번호 자르기 */
	/* //우편번호 6자리에서 5자리로 변경 되면서 빼기 표시 뺌 2015.07.16 박형규
	public static String[] splitZipNo(String zip_no) {
		String[] retStr = new String[]{"",""};
		zip_no = zip_no== null ? "" : zip_no.trim().replaceAll("-", "");

	    if (zip_no.length()>=3) {
	        retStr[0] = zip_no.substring(0,3);
	        retStr[1] = zip_no.substring(3);
	    } else {
	    	retStr[0] = zip_no;
	    }
		return retStr;
	}
	*/
	/**
	 * 문자열 왼쪽에 원하는 수만큼의 문자를 붙여서 리턴한다.
	 * @param str 기본 문자열
	 * @param i   리턴받는 문자열의 길이
	 * @param padStr 왼쪽에 포함되는 문자
	 * @return reStr 리턴 받을 문자열
	 */
	public static String lpad(String str, int i, String padStr) {
		String rtnStr = "";
		
		if (str == null || i == 0) {
			return str;
		} else {
			rtnStr = str;
		}

		for (int j = str.length(); j < i; j++) {
			rtnStr = padStr + rtnStr;
		}
		
		if (rtnStr.length() == i) {
			return rtnStr;
		} else {
			return str;
		}
	}

	/** 문자열 오른쪽에 원하는 수만큼의 공백를 붙여서 리턴한다. */
	public static String rpad(String str, int cnt) {
		return rpad(str, cnt, " ");
	}

	/** 문자열 오른쪽에 원하는 수만큼의 문자를 붙여서 리턴한다. */
	public static String rpad(String str, int cnt, String padStr) {
		if(str==null) str = "";
		while (str.length() < cnt) {
			str =  str + padStr;
		}
		return str;
	}

	/** rpad와 유사, 입력값을 byte로 계산 */
	public static String rpadb(String str, int len) {
		return rpadb(str, len, ' ');
	}

	/** rpad와 유사, 입력값을 byte로 계산 */
	public static String rpadb(String str, int len, char ch) {
		return rpadb(str, len, (byte) ch);
	}

	/** rpad와 유사, 입력값을 byte로 계산 */
	public static String rpadb(String str, int len, byte by) {
		if(len < 0) {
			logger.error("입력된 lenth 길이가 0보다 작음");
			return "";
		}
		byte[] retBytes = new byte[len];
		byte[] indata = str.getBytes();
		for (int i = 0; i < len; i++) {
			if (indata.length > i)
				retBytes[i] = indata[i];
			else
				retBytes[i] = by;
		}
		return new String(retBytes);
	}

	/** byte[]를 문자열로 표현 */
	public static String asString(byte[] bytes) {
		if (bytes == null)
			return null;

		StringBuffer strb = new StringBuffer(bytes.length);
		for (int i = 0; i < bytes.length; i++) {
			strb.append(asString(bytes[i]));
		}
		return strb.toString();
	}

	/** byte를 문자열로 표현 */
	public static String asString(byte b) {
		String str = Integer.toHexString((int) b);
		return (str.length() == 8) ? str.substring(6) : str;
	}

	/** 문자열을 전각문자(전자)로 변경, conv2IBM */
	public static String convCharToFull(String str) {
		char[] chars = str.toCharArray();
		for(int i=0; i<chars.length; i++) {
			if(chars[i]<32 || chars[i]>126) continue;
			chars[i] = (chars[i]==32) ? '　' : (char) ((int) chars[i] + 65248);
		}		
		return new String(chars);
	}
	/** 문자열 반각문자(반자)로 변경, conv2WebCode */
	public static String convCharToHalf(String str) {
		char[] chars = str.toCharArray();
		for(int i=0; i<chars.length; i++) {
			if(chars[i]<32+65248 || chars[i]>126+65248) continue;
			chars[i] = (chars[i]==32+65248) ? ' ' : (char) ((int) chars[i] - 65248);
		}		
		return new String(chars);
	}


	/** byte수 길이만큼 왼쪽부터 문자열을 잘라옴 */
	public static String getLeftByte(String str, int len) {
		return getLeftByteString(str, len);
	}

	/** byte수 길이만큼 왼쪽부터 문자열을 잘라옴 */
	public static String getLeftByteString(String str, int len) {
		String ret = "";
		char[] chars = str.toCharArray();
		int idx = 0;
		for(idx=0; idx<chars.length && len>0; idx++) {
			String s = String.valueOf(chars[idx]);
			len -= s.getBytes().length;
			//if (chars[idx]>=0xAC00 && chars[idx]<=0xD7A3) {
		}
		ret = new String(ArrayUtils.subarray(chars, 0, len<0 ? idx-1 : idx));
		if(len<0) ret += rpad("", Math.abs(len));
		return ret;
	}

	/** byte수 길이만큼 왼쪽부터 문자열을 자르고 공백으로 rpadb */
	public static String getLeftByteRpadb(String str, int len) {
		return rpadb(getLeftByteString(str.trim(),len),len);
	}

	/** byte 수 길이 구함 */
	public static int getByteLength(String str) {
		return str.getBytes().length;
	}

	public static boolean isNumber(String input) {
		if(input == null || trim(input).equals("")) return false;
		input = replace(input, ",", "");
		input = replace(input, ".", "");
		if(trim(input).equals("")) return false;
		for(int i = 0; i < input.length(); i++){
			if(input.charAt(i) < '0' || input.charAt(i) > '9')
				return false;
		}
		return true;
	}

	public static boolean isDate(String input) {
		if(input == null || trim(input).equals("") || trim(input).length() != 8) return false;
		//숫자 체크
		if(!isNumber(input)) return false;
		//1900 ~ 2199
		if(!input.substring(0,2).equals("19") && !input.substring(0,2).equals("20")) return false;
		//월 체크
		if(!equalsArray(input.substring(4,6), new String[]{"01","02","03","04","05","06","07","08","09","10","11","12"} )) return false;
		//일 체크
		if(Integer.parseInt(input.substring(6,8)) < 1 || Integer.parseInt(input.substring(6,8)) > 31) return false;
		
		if(!DateUtil.isValidDate(input)) return false;
		
		return true;		
	}
	
	public static boolean isHPhone(String number){
		if(number == null) return false;
		
		if(number.length() >= 3 && equalsArray(number.substring(0,3), new String[]{"010","011","016","017","018","019","013","070","050"})) return true;
//		if(number.length() > 4 && equalsArray(number.substring(0,4), new String[]{"0130","0505"})) return true;
		
		return false;
	}

    public static String getFmtAmt(double val1) {
    	return getFmtAmt(val1, 0);
    }
    
    public static String getFmtAmt(String val1) {
    	return getFmtAmt(val1, 0);
    }

    public static String getFmtAmt(double val1, int sosu) {
        String out = "";
        String numFormat = "###,###,###,###,###,##0";
        if(sosu>0) numFormat +=".";
        for (int i = 0; i < sosu; i++)
            numFormat += "0";
        DecimalFormat formatter = new DecimalFormat(numFormat);
        out = formatter.format(val1);
        return out;
    }

	public static String getFmtAmt(String amt, int sosu) {
	    if (amt.trim().equals("")) {
	        amt = "0";
	    }
	    return getFmtAmt(Double.parseDouble(amt), sosu);
	}

	
	// 2008.11.26 by hsahn Char 단위로 전각문자 <-> 반각문자 변환
    /**
     * 반각문자로 변경한다
     * @param src 변경할값
     * @return String 변경된값
     */
    public static String toHalfChar(String src)
    {
        StringBuffer strBuf = new StringBuffer();
        char c = 0;
        int nSrcLength = src.length();
        for (int i = 0; i < nSrcLength; i++)
        {
            c = src.charAt(i);
            //영문이거나 특수 문자 일경우.
            if (c >= '！' && c <= '～')
            {
                c -= 0xfee0;
            }
            else if (c == '　')
            {
                c = 0x20;
            }
            // 문자열 버퍼에 변환된 문자를 쌓는다
            strBuf.append(c);
        }
        return strBuf.toString();
    } 	
    /**
     * 전각문자로 변경한다.
     * @param src 변경할값
     * @return String 변경된값
     */
    public static String toFullChar(String src)
    {
        // 입력된 스트링이 null 이면 null 을 리턴
        if (src == null)
            return null;
        // 변환된 문자들을 쌓아놓을 StringBuffer 를 마련한다
        StringBuffer strBuf = new StringBuffer();
        char c = 0;
        int nSrcLength = src.length();
        for (int i = 0; i < nSrcLength; i++)
        {
            c = src.charAt(i);
            //영문이거나 특수 문자 일경우.
            if (c >= 0x21 && c <= 0x7e)
            {
                c += 0xfee0;
            }
            //공백일경우
            else if (c == 0x20)
            {
                c = 0x3000;
            }
            // 문자열 버퍼에 변환된 문자를 쌓는다
            strBuf.append(c);
        }
        return strBuf.toString();
    }
	// {2008.11.26}
	
 
	/*2013 차세대 소숫점 이하 유무에 따라 표시 형식 변경 정우진 13.01.14 */
	public static String denum(long lnum){
		double num = 0.0;
		String str = "";
		String str2 = ""; 
			
		if(lnum >= 10000){
			num = lnum/10000.0;
			str2 = checkDnum(num) + "억원";		//checkDnum 메소드 항상 필요
		} else if(lnum >= 1000){
			num = lnum/1000.0;
			str2 = checkDnum(num) + "천만원";
		} else {
			str2 = checkDnum(num) + "만원";
		}

		return str2;
	}
	
	//2013 차세대 소수점 첫째자리 필요여부 검사 정우진 13.01.14
	public static String checkDnum(double dnum){ 
		String str = "";
		str = Double.toString(dnum); 
		char ch;
		
		ch = str.charAt(str.length()-1); //소수점 첫째자리 검사 
			
		if(ch=='0') {		//소수점 이하가 필요없을 경우
			int i = (int)dnum;
			str = Integer.toString(i);
		}
	
		return str;
	}
	
	//숫자를 컴마 있는 돈으로
	public static String int2Money(String _money) {
		long money = Long.parseLong(_money);
		NumberFormat nf = NumberFormat.getInstance();		  
		try {
	  	return nf.format(money);
	  } catch (Exception e) {
	  	System.err.print(e);
	  } 
	
	  return null;
	}
	
	//숫자를 컴마 있는 돈으로
	public static String dbl2Money(String _money) {
		double money = Double.parseDouble(_money);
		NumberFormat nf = NumberFormat.getInstance();		  
		try {
	  	return nf.format(money);
	  } catch (Exception e) {
	  	System.err.print(e);
	  } 
	
	  return null;
	}

	public static String getDateTime()
	{
		Date date = new Date(); 
		SimpleDateFormat sdf = new SimpleDateFormat(); 
		sdf.applyLocalizedPattern("yyyyMMddHHmmss");
		String strDate = sdf.format( date );
		
		//SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		return strDate;
	}
	
	
	public static String getDateTimeSSS()
	{
		Date date = new Date(); 
		SimpleDateFormat sdf = new SimpleDateFormat(); 
		sdf.applyLocalizedPattern("yyyy-MM-dd HH:mm:ss.SSS");
 
		String strDate = sdf.format( date );
		
		//SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		return strDate;
	}
	
	
	/////////////////////// 2차에서 JGrape에서 상속받는 함수들
	public static String nvl(String obj)
    {
        return obj != null ? obj : "";
    }	
	public static String nvl(Object obj)
    {
        return obj != null ? nvl(String.valueOf(obj)) : "";
    }
	public static String nvl(String str, String def)
    {
        return str == null || "".equals(str) ? def : str;
    }
    public static String nvl(Object obj, String def)
    {
        return obj != null ? nvl(String.valueOf(obj), def) : "";
    }
    
    public static boolean equalsArray(String value, String args[])
    {
        if(args == null || args.length == 0)
            return false;
        if(value == null)
        {
            for(int i = 0; i < args.length; i++)
                if(args[i] == null)
                    return true;

        } else
        {
            for(int i = 0; i < args.length; i++)
                if(value.equals(args[i]))
                    return true;

        }
        return false;
    }

	public static String substring(String str, int beginIndex) {
		String rtnValue = null;
		try {
			rtnValue = checkNull(str).substring(beginIndex);
		} catch (Exception e) {
			rtnValue = checkNull(str);
		}
		return rtnValue;
	}
	
	public static String substring(String str, int beginIndex, int endIndex) {
		String rtnValue = null;
		try {
			rtnValue = checkNull(str).substring(beginIndex, endIndex);
		} catch (Exception e) {
			rtnValue = checkNull(str);
		}
		return rtnValue;
	}
	
	public static String checkNull(String str) {
		return checkNull(str, "");
	}

	public static String checkNull(String str, String defaultStr) {
		if (str == null)
			str = defaultStr;
		else
			str = replace(str.trim(), "'", "\"");
		return str;
	}

	public static String replace(String source, String subject, String object) {
		StringBuffer rtnStr = new StringBuffer();
		String preStr = "";
		String nextStr = source;
		if (source == null)
			return "";
		for (; source.indexOf(subject) >= 0; rtnStr.append(preStr).append(
				object)) {
			preStr = source.substring(0, source.indexOf(subject));
			nextStr = source
					.substring(source.indexOf(subject) + subject.length(),
							source.length());
			source = nextStr;
		}

		rtnStr.append(nextStr);
		return rtnStr.toString();
	}
	
	/**
	 * as-is
	 * 증권번호 6자리 *처리하는 메소드입니다
	 * @param str
	 * @param len
	 * @return
	 */
	public static String getFmtStar(String str, int len) {
		str = checkNull(str);
		if (str.length() > len) {
			str = str.trim();
			String star = "";
			for (int i = 0; i < len; ++i)
				star = star + "*";

			str = str.substring(0, str.length() - len) + star;
		}
		return str;
	}

	
	/**
	 * 이름 2째자리 마스킹 처리
	 * @param str
	 * @return
	 */
	public static String strMaskName(String str) {
		str = strMiddleMasking(str, 1, 1);
		return str;
	}

	/**
	 * 주민번호 뒤6자리 마스킹 처리
	 * @param str
	 * @return
	 */
	public static String strMaskJumin(String str) {
		str = strBackMasking(str, JUMIN_MASKING_LEN);
		return str;
	}

	/**
	 * 전화번호 국번 마스킹 처리
	 * @param str
	 * @return
	 */
	public static String strMaskPhone(String str) {

		String resStr = "";
		str = checkNull(str);
		
		/* 대쉬 있는 전화번호 */
		if ( str.indexOf("-") > -1 ) {
			String[] array;
			array = str.split("-");
			
			//1234-5678 형태
			if ( array.length == 2 ) {
				resStr = "****-" + array[1];
			}
			//010-1234-5678 형태
			else {
				resStr = array[0] + "-****-" + array[2];
			}
			
		} else {
		/* 대쉬 없는 전화번호 */
		
			int strlen = str.length();
			
			if ( strlen < 7 ) {
				resStr = str;
			}
			//123 4567, 1234 5678 형태
			else if ( strlen == 7 || strlen == 8 ) {
				resStr = "****" + str.substring(str.length() - 4, str.length());
			}
			//02 123 4567 형태
			else if ( strlen == 9 ) {
				resStr = str.substring(0, 2) + "****" + str.substring(str.length() - 4, str.length());
			}
			else if ( strlen == 10 ) {
				//02 1234 4567 형태
				if ( "02".equals( str.substring(0, 2) ) ) {
					resStr = "02****" + str.substring(str.length() - 4, str.length());
				}
				//010 123 4567 형태
				else {
					resStr = str.substring(0, 3) + "****" + str.substring(str.length() - 4, str.length());
				}
			}
			else {
				//010 1234 5678 형태
				resStr = str.substring(0, 3) + "****" + str.substring(str.length() - 4, str.length());
			}
		}

		return resStr;
	}	

	
	/**
	 * 이메일id 뒷3자리 마스킹 처리
	 * @param str
	 * @return
	 */
	public static String strMaskEmail(String str) {
		String[] array;
		String resStr = "";
		array = str.split("@");
		
		if ( array.length >= 2 ) {
			if ( array[0] != null ) {
				if (array[0].length() > EMAIL_MASKING_LEN) {
					resStr = strBackMasking(array[0], EMAIL_MASKING_LEN) ;
				} else {
					resStr = "***";
				}
			}
			
			resStr += "@";
			if ( array[1] != null ) {
				resStr += array[1];
			}
		} else {
			resStr = str;
		}
		return resStr;
	}
	
	
	/**
	 * 카드번호 마스킹 처리
	 * @param str
	 * @return
	 */
	public static String strMaskCard(String str) {
		str = strMiddleMasking(str, CARD_MASKING_START, CARD_MASKING_LEN);
		return str;
	}

	/**
	 * 계좌번호 마스킹 처리
	 * @param str
	 * @return
	 */
	public static String strMaskAccount(String str) {
		str = strBackMasking(str, ACCOUNT_MASKING_LEN);
		return str;
	}
	
	
	
	/**
	 * 문자열 뒤부터 마스킹처리
	 * @param str
	 * @param len 마스킹할 문자수
	 * @return
	 */
	public static String strBackMasking(String str, int len) {
		str = checkNull(str);
		String aster = "";
		if (str.length() >= len) {	//id가 마스킹 길이보다 길면
			str = str.trim();
			for (int i = 0; i < len; i++)
				aster += "*";

			str = str.substring(0, str.length() - len) + aster;
		} else {	//id가 마스킹 길이보다 짧으면
			for ( int i = 0; i < str.length(); i++ ) {
				aster += "*";				
			}
			str = aster;
		}
		return str;
	}
	
	/**
	 * 문자열 중간 마스킹처리
	 * @param str
	 * @param sLen 마스킹할 시작순서
	 * @param eLen 마스킹할 문자수
	 * @return
	 */
	public static String strMiddleMasking(String str, int sPos, int len) {
		int ePos = sPos + len;
		str = checkNull(str);

		if (str.length() >= ePos ) {
			str = str.trim();
			String aster = "";
			for (int i = 0; i < len; i++)
				aster += "*";

			str = str.substring(0, sPos) + aster + str.substring(ePos, str.length());
		}
		return str;
	}
	
	/**
	 * as-is
	 * @param so_chigpja_cd
	 * @param so_pa_hp
	 * @param so_jibu_tel
	 * @return
	 */
	public static String getFmtTel(String so_chigpja_cd, String so_pa_hp,
			String so_jibu_tel) {
		String phone = "";
		if (so_chigpja_cd.substring(0, 1).equals("1")) {
			phone = so_jibu_tel.replaceAll(" ", "");
		} else if (!(so_pa_hp.equals("")))
			phone = so_pa_hp.replaceAll(" ", "");
		else {
			phone = so_jibu_tel.replaceAll(" ", "");
		}

		if (phone.length() < 8)
			return phone;

		if (phone.length() == 8) {
			phone = phone.substring(0, 4) + "-" + phone.substring(4);
		} else if (phone.substring(0, 2).equals("02")) {
			if (phone.length() == 9) {
				phone = phone.substring(0, 2) + "-" + phone.substring(2, 5)
						+ "-" + phone.substring(5);
			} else {
				phone = phone.substring(0, 2) + "-" + phone.substring(2, 6)
						+ "-" + phone.substring(6);
			}
		} else if (phone.length() == 10) {
			phone = phone.substring(0, 3) + "-" + phone.substring(3, 6) + "-"
					+ phone.substring(6);
		} else if (phone.length() == 11) {
			phone = phone.substring(0, 3) + "-" + phone.substring(3, 7) + "-"
					+ phone.substring(7);
		} else {
			phone = phone.substring(0, 4) + "-" + phone.substring(4, 8) + "-"
					+ phone.substring(8);
		}

		return phone;
	}
	
	/**
	 * as-is
	 * @param s
	 * @return
	 */
	public static String trim(String s) {
		if (s == null)
			s = "";
		int st = 0;
		char val[] = s.toCharArray();
		int count = val.length;
		int len;
		for (len = count; st < len && (val[st] <= ' ' || val[st] == '\u3000'); st++)
			;
		for (; st < len && (val[len - 1] <= ' ' || val[len - 1] == '\u3000'); len--)
			;
		return st <= 0 && len >= count ? s : s.substring(st, len);
	}
	
	/**
	 * as-is
	 * @param no
	 * @return
	 * @throws Exception
	 */
	public static int parseInt(String no) throws Exception {
		int i = 0;
		if ((no != null) && (!(no.trim().equals("")))) {
			no = no.trim();

			if (no.indexOf(".") > -1) {
				no = no.substring(0, no.indexOf("."));
			}
			try {
				i = Integer.parseInt(no);
			} catch (NumberFormatException e) {
				i = 0;
			}
		}
		return i;
	}
	
	/**
	 * as-is
	 * @param post
	 * @return
	 */
	public static String getFmtPost(String post) {
		post = post.trim();
		if (post.length() > 5) {
			String post1 = post.substring(0, 3);
			String post2 = post.substring(3);
			post = post1 + "-" + post2;
		}
		return post;
	}
	
	/**
	 * xpath 내용추출
	 * @param xpath
	 * @param doc
	 * @return
	 * @throws Exception
	 */
	public static String getText(String xpath , Document doc) throws Exception {
		return getElement(xpath , doc).getText().trim();
	}
	
	/**
	 * xpath 내용추출
	 * @param xpath
	 * @param doc
	 * @return
	 * @throws Exception
	 */
	public static Element getElement(String xpath , Document doc) throws Exception {
		Element element = null;
		
		try {
			element = (Element)XPath.newInstance(xpath).selectSingleNode(doc);
			if (element == null) {
				throw new Exception("주어진 XPath 요소가 존재하지 않습니다.\nXPath : [" + xpath + "] ");
			}
			
		} catch (org.jdom.JDOMException e) {
			e.printStackTrace();
			throw new Exception("주어진 XPath 요소가 존재하지 않습니다.\nXPath : [" + xpath + "] ");
		}
	
		return element;
  }
	/**
	 * 한글 인코딩변환함수입니다.(전문 한글명 인코딩변환)
	 * @param str
	 * @return
	 */
	public static String enToKr(String str) {
		if ( str == null )  return "";
		
		String r = null;
		
		try {
			r = new String(str.getBytes("utf-8"), "utf-8");
		} catch(Exception e){
			e.printStackTrace();
		}
		
		return r;
	}
	
	/**
	 * 문자열을 넘겨받아 null일 경우 빈 문자열을 반환하는 메소드.
	 * 
	 * @param String src : null 체크할 문자열
	 * @return String    : 변환한 문자열
	 */
    public static String changeNullToEmpty(String src) {
    	
    	if(src == null) {
    		return "";
    	} else {
    		return src;
    	}
    	
    }
    
    /**************************************************************************
     * ? 이하 쿼리스트링 제거
     * @param String
     * @return String
     *************************************************************************/
    public static String removeQryString(String referer) {
		int last_idx = referer.indexOf("?");
		if(last_idx > -1) {
			referer = referer.substring(0, last_idx);
		}
		return referer;
    }
    
    /**************************************************************************
     * UTF-8 인코딩 -> 디코딩시 공백이 + 로 변경되는 문제 처리
     * @param String
     * @return String
     *************************************************************************/
    public static String toUTF8(String str) {
    	
    	try {
    		str = java.net.URLEncoder.encode(str, "UTF-8").replaceAll("\\+", "%20");
		} catch (UnsupportedEncodingException e) {
			logger.error(e.getMessage());
		}
    	return str;
    }

    
    /**************************************************************************
     * 2바이트 공백문자 들어간 문자열 trim 처리
     * @param String
     * @return String
     *************************************************************************/
	public static String strSpaceTrim(String str) 
	{
		if ( str == null ) { 
			str = "";
		}
		str = str.replace("　", " ");
		str = str.trim();
		
		return str;
	}
    
	
	public static String escape(String s)               
	{                                                   
		if (s == null) {                                  
			return "";                                      
		}                                                 
	                                                    
		int len = s.length();                             
		StringBuffer buf = new StringBuffer(len * 2);     
	                                                    
		for (int i = 0; i < len; i++) {                   
			char c = s.charAt(i);                           
	                                                    
			if (c == '\'') {                                
				buf.append("''");                             
			} 
			else {                                        
				buf.append(c);                                
			}                                               
		}                                                 	                                                    
		return buf.toString();                            
	}
	
	
    /**************************************************************************
     * 특수문자 있는지 체크
     * @param String
     * @return boolean
     *************************************************************************/
	public static boolean strChkImpossibleChar(String str) 
	{
		if ( str == null ) { 
			str = "";
		}
		if ( str.indexOf("%") > -1 ) return false;
		if ( str.indexOf(";") > -1 ) return false;
//		if ( str.indexOf(":") > -1 ) return false;
		if ( str.indexOf("<") > -1 ) return false;
		if ( str.indexOf(">") > -1 ) return false;
//		if ( str.indexOf("*") > -1 ) return false;
		if ( str.indexOf("#") > -1 ) return false;
		if ( str.indexOf("$") > -1 ) return false;
		if ( str.indexOf("^") > -1 ) return false;
		if ( str.indexOf("'") > -1 ) return false;
		if ( str.indexOf("\"") > -1 ) return false;
//		if ( str.indexOf(",") > -1 ) return false;
//		if ( str.indexOf("|") > -1 ) return false;
		if ( str.indexOf("\n") > -1 ) return false;
		if ( str.indexOf("\r") > -1 ) return false;
		if ( str.indexOf("\r\n") > -1 ) return false;
		if ( str.indexOf("\\") > -1 ) return false;
//		if ( str.indexOf("[") > -1 ) return false;
//		if ( str.indexOf("]") > -1 ) return false;
		if ( str.indexOf(" or ") > -1 ) return false;
		if ( str.indexOf(" OR ") > -1 ) return false;
		if ( str.indexOf(" and ") > -1 ) return false;
		if ( str.indexOf(" AND ") > -1 ) return false;
		
		return true;
	}
	
    /**************************************************************************
     * 특수문자 제거
     * @param String
     * @return String
     *************************************************************************/
	public static String strDeleteImpossibleChar(String str) 
	{
		String res = "";

		if ( str == null ) { 
			res = "";
		}else{
			res = str.replaceAll("%", "")
					.replaceAll(";", "")
					.replaceAll(":", "")
					.replaceAll("<", "")
					.replaceAll(">", "")
					.replaceAll("?", "")
					.replaceAll("*", "")
					.replaceAll("&", "")
					.replaceAll("#", "")
					.replaceAll("$", "")
					.replaceAll("^", "")
					.replaceAll("'", "")
					.replaceAll("\"", "")
					.replaceAll(",", "")
					.replaceAll("|", "")
					.replaceAll("\n", "")
					.replaceAll("\r", "")
					.replaceAll("\r\n", "")
					.replaceAll("\\", "")
					.replaceAll("[", "")
					.replaceAll("]", "")
					.replaceAll(" or ", "")
					.replaceAll(" OR ", "")
					.replaceAll(" and ", "")
					.replaceAll(" AND ", "");
		}
		
		return res;
	}
	
    /**************************************************************************
     * 2byte 숫자 -> 1byte 숫자
     * @param String
     * @return String
     *************************************************************************/
	public static String conv2ByteNum(String strNo) {
		char toChar[] = new char[] {'０', '１', '２', '３', '４', '５', '６', '７', '８', '９'};
		String rtnStr = "";

		for(int i=0; i<strNo.length(); i++) {
			for(int j=0; j<toChar.length; j++) {
				if(strNo.charAt(i) == toChar[j]) rtnStr+=j;
			}
		}
		return rtnStr;
	}
	
	  /**************************************************************************
     * 주소 동이하 * 처리 (예시:서울시 강남구 대치동 891-10 동부금융센터 1층)-구주소
     * @param String 
     * @return String 
     *************************************************************************/
	public static String addrToMask(String adr_str) {
		if(adr_str == null || "".equals(adr_str)) {
			return "";
		}
		
		String[] tmp = adr_str.split("  ");
		String juso = "";
		for(int i = 0, i_limit = tmp.length; i < i_limit; i++) {
			String[] tmp_juso = null;
			if(tmp[i].indexOf("　") > -1) {
				tmp_juso = tmp[i].split("　");
			}
			else {
				tmp_juso = tmp[i].split(" ");
			}
			
			for(int j = 0, j_limit = tmp_juso.length; j < j_limit; j++) {
				if(i == 0 && j < j_limit - 1) {
					juso += tmp_juso[j] + " ";
				}
				else if(i == 0 && j == j_limit - 1) {
					for(int k = 0, k_limit = tmp_juso[j].length(); k < k_limit; k++) {
						if(k == k_limit - 1) {
							juso += tmp_juso[j].substring(k);
						}
						else {
							juso += "*";
						}
					}
				}
				else {
					for(int k = 0, k_limit = tmp_juso[j].length(); k < k_limit; k++) {
						if("-".equals(tmp_juso[j].substring(k, k+1)) || 
						   ",".equals(tmp_juso[j].substring(k, k+1)) ||
						   "~".equals(tmp_juso[j].substring(k, k+1)) ||
						   " ".equals(tmp_juso[j].substring(k, k+1))) {
							juso += tmp_juso[j].substring(k, k+1);
						}
						else {
							juso += "*";
						}
					}					
				}
				juso += " ";
			}
		}
		return juso;
/*
		//logger.debug("--- 출력할 주소 * 표시 전 : "+adr_str);		
		String adr_str_to = "";
		if(adr_str.indexOf("로 ") > -1
			|| adr_str.indexOf("동 ") > -1
			|| adr_str.indexOf("읍 ") > -1
			|| adr_str.indexOf("면 ") > -1){
			String adr_tmp = "";
			String adr_star = "";
			String adr_dong = "";
			int stDongNum = 0;
			int stGuNum = 0;
			stGuNum = adr_str.indexOf("구 ");
			if(adr_str.indexOf("구 ") > -1){
				stGuNum = adr_str.indexOf("구 ");
			}else if(adr_str.indexOf("군 ") > -1){
				stGuNum = adr_str.indexOf("군 ");
			}
			
			// 읍,면,동,로 처리
			if(adr_str.indexOf("로 ") > -1){
				stDongNum = adr_str.indexOf("로 ");
				adr_dong = "로 ";
			}else if(adr_str.indexOf("동 ") > -1){
				stDongNum = adr_str.indexOf("동 ");
				adr_dong = "동 ";
			}else if(adr_str.indexOf("읍 ") > -1){
				stDongNum = adr_str.indexOf("읍 ");
				adr_dong = "읍 ";
			}else if(adr_str.indexOf("면 ") > -1){
				stDongNum = adr_str.indexOf("면 ");
				adr_dong = "면 ";
			}
			adr_tmp = adr_str.substring((stGuNum+2), stDongNum);
			for(int i=0, size=adr_tmp.length();i<size;i++){
				adr_star = adr_star + "*";  
			}
			adr_tmp = adr_str.substring(0, stGuNum+2) + adr_star + adr_dong;
			//logger.debug("--- 출력할 주소 동 * 표시 후 : "+adr_tmp);
			adr_str_to = adr_tmp;
			adr_tmp = "";
			adr_tmp = adr_str.substring((stDongNum+2));
			//logger.debug("--- 출력할 주소 기타 * 표시 전 : "+adr_tmp);
			adr_star = "";
			String _adr_tmp = "";
			for(int i=0, size=adr_tmp.length();i<size;i++){
				_adr_tmp = adr_tmp.substring(i, i+1);
				if(_adr_tmp.equals(" ")){
					adr_star = adr_star + " ";
				}else if(_adr_tmp.equals("-")){
					adr_star = adr_star + "-";
				}else if(_adr_tmp.equals("?")){
					adr_star = adr_star + "";
				}else{
					adr_star = adr_star + "*";
				}
			}
			adr_tmp = "";
			adr_tmp = adr_star;
			//logger.debug("--- 출력할 주소 기타 * 표시 후 : "+adr_tmp);
			adr_str_to = adr_str_to + adr_tmp;
			//logger.debug("--- 출력할 주소 전체 * 표시 후 : "+adr_str_to);
		}else{
			adr_str_to = adr_str;
		}
		
		return adr_str_to;
*/		
	}

	 /**************************************************************************
     * 이름 성씨 두음법칙 제거 로직(20140903 by Klaus)[아이동부에서 가져옴]
     * @param String 
     * @return String 
     *************************************************************************/
	public static String applyInitialLaw(String str) { 

		String name = "";
		String tempStr = str.substring(0,1);
		String lastStr = "";
		char test = tempStr.charAt(0);

		if(test >= 0xAC00)
		{
			char uniVal = (char) (test - 0xAC00);

			char cho = (char) (((uniVal - (uniVal % 28))/28)/21);
			char jun = (char) (((uniVal - (uniVal % 28))/28)%21);
			char jon = (char) (uniVal % 28);
			
			//  ㄴ , ㄹ -> ㅇ  , ㄹ -> ㄴ 
			if (cho == 2 && ( jun == 6 ||  jun == 12 || jun == 17 || jun == 20 ) ) {   // 녀, 뇨, 뉴, 니 -->> 여, 요, 유, 이
				cho = 11;
			} 

			if (cho == 5 && ( jun == 2 ||  jun == 6 || jun == 7 || jun == 17 || jun == 12 || jun == 20) ) {   // ‘랴, 려, 례, 료, 류, 리’-->> ‘야, 여, 예, 요, 유, 이
				cho = 11;
			}

			if (cho == 5 && ( jun == 0 ||  jun == 1 || jun == 8 || jun == 11 || jun == 13 || jun == 18) ) {   //  ‘라, 래, 로, 뢰, 루, 르’ -->> ‘나, 내, 노, 뇌, 누, 느’
				cho = 2;
			}

			char temp = (char)(0xAC00 + 28 * 21 *(cho) + 28 * (jun) + (jon) );
			lastStr = lastStr.concat(String.valueOf(temp));			
			name = lastStr + str.substring(1);

		} else {
			name = str;
		}

		return name;
	}
	
	public static String getStackTraceString(Exception e) { // Exception.printStackTrace를 String에 넣기
		StringWriter sw = new StringWriter();
		e.printStackTrace(new PrintWriter(sw));
		return sw.toString();
	}
	
	public static String getWebUrl(HttpServletRequest req) {
		return req.getHeader("Host").startsWith("10.") ? "http://10.88.23.23:8080" : "http://m.idbins.com";
	}
	
	public static String getCryptVhNo(String vhNo) { // 차량번호 마스킹
		if(vhNo.length() >= 4) {
			return vhNo.substring(0, vhNo.length() - 4) + "**" + vhNo.substring(vhNo.length() - 2);
		}
		else {
			return vhNo;
		}
	}
}

