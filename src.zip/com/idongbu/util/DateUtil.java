package com.idongbu.util;

import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.Vector;

public class DateUtil {
	/** 날짜 중간에 삽입된 기호들을 제거한다. */
	public static String trim(String str) {
		return str.trim().replaceAll("[-/\\. :]", "");
	}

	/**
	 * 날짜 포맷
	 * getFmtDateTime("20070901")	=> 2007-09-01
	 * getFmtDateTime("20070901121212")	=> 2007-09-01 12:12:12
	 */
    public static String getFmtDateTime(String str) {
    	return getFmtDateTime(str, str==null ? 0 : str.length());
    }

    /**
	 * 날짜 포맷
	 * sep :  년월일 별로 구분하기 위한 특수문자 입력
	 * getFmtDateTime("20070901", "-")	=> 2007-09-01
	 * getFmtDateTime("20070901", ".")	=> 2007.09.01
	 */
    public static String getFmtDateTime(String str, String sep) {
    	return getFmtDateTime(str, sep, str.length());
    }

	/**
	 * 날짜 포맷
	 * outType : 출력형태
	 * getFmtDateTime("20070901121212", 8)	=> 2007-09-01
	 */
    public static String getFmtDateTime(String str, int outType) {
    	return getFmtDateTime(str, "-", str==null ? 0 : outType);
    }

	/**
	 * 날짜 포맷
	 * sep :  년월일 별로 구분하기 위한 특수문자 입력
	 * outType : 출력형태
	 * getFmtDateTime("20070901121212", 8)	=> 2007-09-01
	 */
    public static String getFmtDateTime(String str, String sep, int outType) {
    	String ret = "";

    	if(StringUtil.isEmpty(sep)) sep = "";
    	if(str==null || "".equals(str.trim())) return ret;
    	if(outType==0) outType = str.length();
    	if(str.length()==4) str += "0101";
    	if(str.length()==6) str += "01";
   		Date date = ymdToDate(StringUtil.rpad(str, 14, "0"), "yyyyMMddHHmmss");

    	switch(outType) {
			case   4:	ret = dateToYmd(date,	"yyyy"); 								break;
			case   6:	ret = dateToYmd(date,	"yyyy"+sep+"MM");  						break;
			case   8:	ret = dateToYmd(date,	"yyyy"+sep+"MM"+sep+"dd");  			break;
			case  10:	ret = dateToYmd(date,	"yyyy"+sep+"MM"+sep+"dd HH");  			break;
			case  12:	ret = dateToYmd(date,	"yyyy"+sep+"MM"+sep+"dd HH:mm");  		break;
			case  14:	ret = dateToYmd(date,	"yyyy"+sep+"MM"+sep+"dd HH:mm:ss");		break;
			case  16:   ret = dateToYmd(date, 	"yyyy"+sep+"MM"+sep+"dd a HH:mm:ss");	break;
			case 104:	ret = dateToYmd(date,	"yyyy년"); 								break;
			case 106:	ret = dateToYmd(date,	"yyyy년 M월");  						break;
			case 108:	ret = dateToYmd(date,	"yyyy년 M월 d일");  					break;
			case 110:	ret = dateToYmd(date,	"yyyy년 M월 d일 H시");  				break;
			case 111:	ret = dateToYmd(date,	"yyyy년 M월 d일 a h시");  				break;
			case 112:	ret = dateToYmd(date,	"yyyy년 M월 d일 H시 m분");  			break;
			case 113:	ret = dateToYmd(date,	"yyyy년 M월 d일 a h시 m분");  			break;
			case 114:	ret = dateToYmd(date,	"yyyy년 M월 d일 H시 m분 s초");  			break;
			case 115:	ret = dateToYmd(date,	"yyyy년 M월 d일 a h시 m분 s초");  		break;
			case 214:	ret = dateToYmd(date,	"yyyy년 M월 d일  HH:mm:ss");  			break;
			default:	throw new IllegalArgumentException("표시할 수 없는 출력 포맷입니다.");
    	}
    	return ret;
    }

    /**
     * 날짜 포맷
     * getSplitDate("2007-09-01")	=> 20070901
     * 
     */
    public static String getSplitDate(String yyyymmdd) {
		String ymd = yyyymmdd.trim();
		if (ymd.length() == 7)
			return ymd.substring(0, 4)
				+ ymd.substring(5, 7);
		else if (ymd.length() == 10)
			return ymd.substring(0, 4)
				+ ymd.substring(5, 7)
				+ ymd.substring(8, 10);
		else
			return ymd;
	}
    
    /**
     * 날짜 길이에 상관없이 날짜를 더하거나 빼는 함수..
     * JGrape의 addDate함수 이용..
     * @param date 날짜
     * @param flag 0:연이동, 1:월이동, 2:일이동
     * @param offset 이동(월)수
     * @return 바뀐 날짜..
     */
    public static String addSetDate(String date, int flag, int offset) {
    	String splDate = "";
    	String addDate = "";
    	String rtnDate = "";
    	
    	if (flag == 0) {
    		if (date.length() >= 4) {
    			splDate = date.substring(0,4);
    		} else {
    			return "";
    		}
    	}
    	if (flag == 1) {
    		if (date.length() >= 6) {
    			splDate = date.substring(0,6);
    		} else {
    			return "";
    		}
    	}
    	if (flag == 2) {
    		if (date.length() >= 8) {
    			splDate = date.substring(0,8);
    		} else {
    			return "";
    		}
    	}
    	
    	addDate = addDate(splDate, flag, offset);
    	
    	if (flag == 0) rtnDate = addDate + date.substring(4,date.length());
    	if (flag == 1) rtnDate = addDate + date.substring(6,date.length());
    	if (flag == 2) rtnDate = addDate + date.substring(8,date.length());
    	
    	return rtnDate;
    }

    /**  시간이 from, to 에 포함되는지 여부
	 *  예)입력형태 2007 09 01 22 01 03 , 2007 09 01 2 등..
     */
    public static boolean isBetweenCurrDate(String from, String to) {
    	Date currDate = new Date();
    	return currDate.compareTo(parseDate(from))>=0 && currDate.compareTo(parseDate(to))<=0;
	}

    /** 두 시간의 차이를 구한다. */
	public static long getBetweenDateTime(String from, String to) {
		return getBetweenDateTime(parseDate(from), parseDate(to));
	}

    /** 두 시간의 차이를 구한다. */ // 단위는 millisecond 즉, 리턴값 1000 => 1초
	public static long getBetweenDateTime(Date from, Date to) {
		return to.getTime() - from.getTime();
	}

	/** 두 시간의 차이를 구한다. (날짜) */
	public static int getBetweenDays(String from, String to) {
//		return Integer.parseInt(to.substring(0, 8)) - Integer.parseInt(from.substring(0, 8));
		long gap = getBetweenDateTime(from, to);
//		long time = 1000; 	//1초
//		time *= 60;			//1분
//		time *= 60;			//1시간
//		time *= 24;			//1일
		long time = 86400000;
		return (int)(gap / time);
	}

	/** 입력문자열을 Date객체로 리턴한다.
	 *  날짜입력형태 20070901220103, 200709012 등..
	 */
	public static Date parseDate(String str) {
		return ymdToDate(StringUtil.rpad(str, 14, "0"), "yyyyMMddHHmmss");
	}

	/** 윤년여부 */
	public static boolean isLeapYear(String str) {
		return new GregorianCalendar().isLeapYear(Integer.parseInt(str.substring(0,4)));
	}

	/** 정상적인 날짜여부 */
	public static boolean isValidDate(String str) {
		str = StringUtil.rpad(str, 14, "0");
		return str.equals(dateToYmd(parseDate(str), "yyyyMMddHHmmss"));
	}

	/**
	 * 
	 * @param sDate 날짜 to
	 * @param eDate 날짜 From
	 * @param iFlag 1:일일 기준, 2:월 기준, "": 년기준  
	 * @param iDel  년+"iDel"+월+"iDel"+일
	 * @return
	 */
	 public static Vector getDates(String sDate, String eDate, String iFlag, String iDel) {
		Vector vDates = new Vector();

		int sYYYY = Integer.parseInt(sDate.substring(0, 4));
		int sMM = Integer.parseInt(sDate.substring(4, 6));
		int sDD = Integer.parseInt(sDate.substring(6, 8));

		int eYYYY = Integer.parseInt(eDate.substring(0, 4));
		int eMM = Integer.parseInt(eDate.substring(4, 6));
		int eDD = Integer.parseInt(eDate.substring(6, 8));

		Calendar startNow = Calendar.getInstance();
		startNow.set(sYYYY, sMM - 1, sDD);

		Calendar endNow = Calendar.getInstance();
		endNow.set(eYYYY, eMM - 1, eDD);


		long lST = startNow.getTime().getTime();
		long lET = endNow.getTime().getTime();
		long oneDay = (1000L * 60 * 60 * 24);


		if (iFlag.equals("1")) {
			for (long i = lST; i <= lET; i += oneDay, startNow.add(Calendar.DATE, 1)) {
			vDates.addElement(startNow.get(Calendar.YEAR) + iDel +
				(startNow.get(Calendar.MONTH) + 1 < 10 ? "0" + (startNow.get(Calendar.MONTH) + 1) : "" + (startNow.get(Calendar.MONTH) + 1)) + iDel +
				(startNow.get(Calendar.DAY_OF_MONTH) < 10 ? "0" + startNow.get(Calendar.DAY_OF_MONTH) : "" + startNow.get(Calendar.DAY_OF_MONTH)));
			}

		} else if (iFlag.equals("2")) {
			for (int i = sYYYY; i <= eYYYY; i++) {
			for (int j = (i == sYYYY ? sMM : 1); j <= (i < eYYYY ? 12 : eMM); j++) {
				vDates.addElement(i + iDel + (j < 10 ? "0" + j : "" + j) + iDel + "01");
			}
			}
		} else {
			for (int i = sYYYY; i <= eYYYY; i++) {
			vDates.addElement(i + iDel + "01" + iDel + "01");
			}

		}
		return vDates;
	}

	/** 음력일자를 가져온다. */
	public static String getLunar(String str) {
		return new LunarCalendar().toLunar(str);
	}

	/** 양력일자를 가져온다. */
	public static String getSolar(String str) {
		return new LunarCalendar().fromLunar(str);
	}

	/** 나이(ChkAge6), 입력:yyyyMMdd,  */
	public static int getAge(String str) {
		String curr_yy = getYear();
		int age = Integer.parseInt(curr_yy) - Integer.parseInt(str.substring(0,4));
		Date d = ymdToDate(curr_yy + str.substring(4,8), "yyyyMMdd");
		if(d.before(ymdToDate(getDate(),"yyyyMMdd"))) age++;
		return age;
	}

	/** 만나이(ManAge), 입력:주민번호 */
	public static int getAgeMan(String jumin) {
		int age = -1;
		try {
			jumin = jumin.trim().replaceAll("-", "");
			int curr_yy = Integer.parseInt(getYear());
			int curr_mm = Integer.parseInt(getMonth());
			int curr_dd = Integer.parseInt(getDay());
			int yy = Integer.parseInt((("3478".indexOf(jumin.charAt(6))!=-1) ? "20" : "19") + jumin.substring(0, 2));
			int mm = Integer.parseInt(jumin.substring(2,4));
			int dd = Integer.parseInt(jumin.substring(4,6));
			age = curr_yy - yy + 1;
			if(curr_mm == mm) {
				age += curr_dd < dd ? -2 : -1;
			} else {
				age += curr_mm < mm ? -2 : -1;
			}
		} catch(Exception e) {
			e.printStackTrace();
			age = -1;
		}
		
		return age;
	}
	
	/** 보험나이(BoHumAge), 입력:주민번호 */
	public static int getAgeBoHum(String jumin) {
		int age = -1;
		try {
			jumin = jumin.trim().replaceAll("-", "");
			int curr_yy = Integer.parseInt(getYear());
			int curr_mm = Integer.parseInt(getMonth());
			int curr_dd = Integer.parseInt(getDay());
			int yy = Integer.parseInt((("34".indexOf(jumin.charAt(6))!=-1) ? "20" : "19") + jumin.substring(0, 2));
			int mm = Integer.parseInt(jumin.substring(2,4));
			int dd = Integer.parseInt(jumin.substring(4,6));
			String birth = Integer.toString(curr_yy)+(Integer.toString(curr_mm).length()==1 ? "0"+Integer.toString(curr_mm) : Integer.toString(curr_mm) )+(Integer.toString(curr_dd).length()==1 ? "0"+Integer.toString(curr_dd) : Integer.toString(curr_dd) );
			String birth2 = Integer.toString(yy)+(Integer.toString(mm).length()==1 ? "0"+Integer.toString(mm) : Integer.toString(mm) )+(Integer.toString(dd).length()==1 ? "0"+Integer.toString(dd) : Integer.toString(dd) );
			int temp1 = 0;//연차이
			int temp2 = 0;//월차이
			int temp3 = 0;//일차이
			int cnt1 = 0;
			int cnt2 = 0;
			if(Integer.parseInt(birth.substring(6,8)) - Integer.parseInt(birth2.substring(6,8)) >= 0){
				temp1 += (Integer.parseInt(birth.substring(6,8)) - Integer.parseInt(birth2.substring(6,8)));
			}else{
				temp1 += (Integer.parseInt(birth.substring(6,8)) - Integer.parseInt(birth2.substring(6,8)) + 30);
				temp2 -= 1;
				cnt1 -= 1;
			}
			if(Integer.parseInt(birth.substring(4,6)) - Integer.parseInt(birth2.substring(4,6)) + cnt1 >= 0){
				temp2 += (Integer.parseInt(birth.substring(4,6)) - Integer.parseInt(birth2.substring(4,6)));
			}else{
				temp2 += (Integer.parseInt(birth.substring(4,6)) - Integer.parseInt(birth2.substring(4,6)) + 12);
				temp3 -= 1;
				cnt2 -= 1;
			}
			if(Integer.parseInt(birth.substring(2,4)) - Integer.parseInt(birth2.substring(2,4)) + cnt2 >= 0){
				temp3 += (Integer.parseInt(birth.substring(2,4)) - Integer.parseInt(birth2.substring(2,4)));
			}else{
				temp3 += (Integer.parseInt(birth.substring(2,4)) - Integer.parseInt(birth2.substring(2,4))+100);
			}
			if(temp2 >=6) temp3 += 1;
			age = temp3;
//			System.out.println("age : "+age);
		} catch(Exception e) {
			e.printStackTrace();
			age = -1;
		}
		return age;
	}	

	
    /**
     * 시+분이 from, to 에 포함되는지 여부
     * @param from
     * @param to
     * @return
     */
    public static boolean isBetweenCurrTime(String from, String to) {
    	
    	String currTime = getDate("hh") + getDate("mi");
    	return currTime.compareTo(from)>=0 && currTime.compareTo(to)<=0;
    	
    }	
	
	
    
    ////////////////////// JGrape 에서 상속
    public static Date ymdToDate(String strIn, String formatIn)
    {
        Date date = null;
        SimpleDateFormat formatter = null;
        
        if(strIn == null || formatIn==null){	//웹 보안성 심의 수정
        	return date;
        }
        try
        {
            formatter = new SimpleDateFormat(formatIn, Locale.KOREA);
            date = formatter.parse(strIn);
        }
        catch(Exception e)
        {
            return date;
        }
        return date;
    }
    
    public static String dateToYmd(Date date, String formatOut)
    {
    	if(formatOut == null){
    		return "";
    	}
        String strOut = null;
        SimpleDateFormat formatter = null;
        try
        {
            formatter = new SimpleDateFormat(formatOut, Locale.KOREA);
            strOut = formatter.format(date);
        }
        catch(Exception e)
        {
            return strOut;
        }
        return strOut;
    }
    
    public static String addDate(int offset)
    {
      int yyyy = 0; int mm = 0; int dd = 0;
      int ryyyy = 0; int rmm = 0; int rdd = 0;
      try
      {
        StringBuffer buf = new StringBuffer();
        Calendar endx_date = new GregorianCalendar();

        endx_date.add(5, offset);

        ryyyy = endx_date.get(1);
        rmm = endx_date.get(2) + 1;
        rdd = endx_date.get(5);

        buf.append(ryyyy);

        if (rmm <= 9) {
          buf.append('0');
        }

        buf.append(rmm);

        if (rdd <= 9) {
          buf.append('0');
        }

        buf.append(rdd);

        return buf.toString();
      }
      catch (Exception e) {
        e.printStackTrace(System.err);
      }return null;
    }

    public static String addDate(String date, int flag, int offset)
    {
      int yyyy = 0; int mm = 0; int dd = 1;
      int ryyyy = 0; int rmm = 0; int rdd = 0;
      try {
        StringBuffer buf = new StringBuffer();
        if ((flag == 0) && (date.length() != 4))
          return "";
        if ((flag == 1) && (date.length() != 6))
          return "";
        if ((flag == 2) && (date.length() != 8)) {
          return "";
        }
        yyyy = Integer.parseInt(date.substring(0, 4));
        mm = Integer.parseInt(date.substring(4, 6)) - 1;

        if (flag != 1) dd = Integer.parseInt(date.substring(6, 8));

        Calendar endx_date = new GregorianCalendar(yyyy, mm, dd);

        if (flag == 0)
          endx_date.add(1, offset);
        else if (flag == 1)
          endx_date.add(2, offset);
        else if (flag == 2) {
          endx_date.add(5, offset);
        }

        ryyyy = endx_date.get(1);
        rmm = endx_date.get(2) + 1;
        rdd = endx_date.get(5);

        buf.append(ryyyy);

        if (rmm <= 9) {
          buf.append('0');
        }

        buf.append(rmm);

        if (flag == 2) {
          if (rdd <= 9) buf.append('0');
          buf.append(rdd);
        }

        return buf.toString();
      } catch (Exception e) {
        e.printStackTrace(System.err);
      }return null;
    }
    
    public static String getYear() {
	   return getDate("yyyy");
	}
    public static String getMonth()
    {
      return getDate("mm");
    }

    public static String getDay()
    {
      return getDate("dd");
    }

    public static String getHour()
    {
      return getDate("hh");
    }

    public static String getMin()
    {
      return getDate("mi");
    }

    public static String getSec() {
      return getDate("ss");
    }
    
    public static String getDate() {
        Calendar cal = Calendar.getInstance();
        int yy = cal.get(1);
        int mm = cal.get(2) + 1;
        int dd = cal.get(5);

        StringBuffer sDate = new StringBuffer();
        sDate.append(yy);
        if (mm < 10) sDate.append("0").append(mm); else
          sDate.append(mm);
        if (dd < 10) sDate.append("0").append(dd); else {
          sDate.append(dd);
        }
        return sDate.toString();
      }

      public static String getDate(String check)
      {
        Date date = new Date();
        GregorianCalendar calendar = new GregorianCalendar();
        calendar.setTime(date);
        SimpleDateFormat simpleDate = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat datetime = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss");
        SimpleDateFormat yyyy = new SimpleDateFormat("yyyy");
        SimpleDateFormat yy = new SimpleDateFormat("yy");
        SimpleDateFormat mm = new SimpleDateFormat("MM");
        SimpleDateFormat dd = new SimpleDateFormat("dd");
        SimpleDateFormat HH = new SimpleDateFormat("HH");
        SimpleDateFormat mi = new SimpleDateFormat("mm");
        SimpleDateFormat ss = new SimpleDateFormat("ss");
        SimpleDateFormat ms = new SimpleDateFormat("SSS");

        String strdate = simpleDate.format(date);
        String strdatetime = datetime.format(date);
        String lYear = yyyy.format(date);
        String sYear = yy.format(date);
        String month = mm.format(date);
        String day = dd.format(date);
        String hour = HH.format(date);
        String minute = mi.format(date);
        String second = ss.format(date);
        String milisecond = ms.format(date);

        if (check.equals("yyyy"))
          return lYear;
        if (check.equals("yy"))
          return sYear;
        if (check.equals("mm"))
          return month;
        if (check.equals("dd"))
          return day;
        if (check.equals("hh"))
          return hour;
        if (check.equals("mi"))
          return minute;
        if (check.equals("ss"))
          return second;
        if (check.equals("ms"))
          return milisecond;
        if (check.equals("date"))
          return strdate;
        if (check.equals("yyyymmdd"))
          return lYear + month + day;
        if (check.equals("yyyymm"))
          return lYear + month;
        if (check.equals("yymmdd"))
          return sYear + month + day;
        if (check.equals("yymm"))
          return sYear + month;
        if (check.equals("hhmiss"))
          return hour + minute + second;
        if (check.equals("datetime"))
          return strdatetime;
        if (check.equals("hhmissms"))
          return hour + ":" + minute + ":" + second + ":" + milisecond;
        if (check.equals("total")) {
          return lYear + month + day + hour + minute + second + milisecond;
        }
        return "";
      }
	
      /**
       * as-is
       * @param date
       * @param flag
       * @param offset
       * @return
       */
      public static String addDateYMD(String date, int flag, int offset) {
  		String result = "";
  		try {
  			Calendar cal = stringToCalendar(date);
  			cal.add(2, -1);

  			switch (flag) {
  			case 0:
  				cal.add(1, offset);
  				break;
  			case 1:
  				cal.add(2, offset);
  				break;
  			case 2:
  				cal.add(5, offset);
  			}

  			DateFormat df = new SimpleDateFormat("yyyyMMdd");
  			result = df.format(cal.getTime());
  		} catch (Exception e) {
  			e.printStackTrace(System.err);
  		}
  		return result;
  	}
    
    /**
     * 
     * @param date
     * @return
     */
	public static Calendar stringToCalendar(String date) {
		Calendar cal = null;
		try {
			if (date.length() >= 8) {
				cal = Calendar.getInstance();
				cal.set(StringUtil.parseInt(StringUtil.substring(date, 0, 4)),
						StringUtil.parseInt(StringUtil.substring(date, 4, 6)),
						StringUtil.parseInt(StringUtil.substring(date, 6, 8)));
			}
		} catch (Exception e) {
			e.printStackTrace(System.err);
		}
		return cal;
	} 
	
	public static String getTime()
    {
        Calendar cal = Calendar.getInstance();
        int hh = cal.get(11);
        int mm = cal.get(12);
        int ss = cal.get(13);
        String hhh = null;
        String mmm = null;
        String sss = null;
        if(hh < 10)
            hhh = "0" + hh;
        else
            hhh = Integer.toString(hh);
        if(mm < 10)
            mmm = "0" + mm;
        else
            mmm = Integer.toString(mm);
        if(ss < 10)
            sss = "0" + ss;
        else
            sss = Integer.toString(ss);
        String addTime = hhh + mmm + sss;
        return addTime;
    }
	
	public static String getFmtDateKo(String date) {
		String returnVal = "";
		if (date == null) {
			date = "";
		}
		date = date.trim();
		if (date.length() == 6) {
			returnVal = date.substring(0, 4);
			returnVal = returnVal + "년";
			returnVal = returnVal + date.substring(4, 6);
			returnVal = returnVal + "월";
		} else if (date.length() >= 8) {
			returnVal = date.substring(0, 4);
			returnVal = returnVal + "년";
			returnVal = returnVal + date.substring(4, 6);
			returnVal = returnVal + "월";
			returnVal = returnVal + date.substring(6, 8);
			returnVal = returnVal + "일";
		} else {
			returnVal = date;
		}
		return returnVal;
  }

	public static int getBeforeAge(String juminNo) { // 주민번호로 만나이 계산
		int currentDate = Integer.parseInt(DateUtil.getDate());
		int birthday = 0;
		int age = 0;
		if(juminNo.charAt(6) == '3' || juminNo.charAt(6) == '4' || juminNo.charAt(6) == '7' || juminNo.charAt(6) == '8') {
			birthday = Integer.parseInt("20" + juminNo.substring(0, 6));
		}
		else {
			birthday = Integer.parseInt("19" + juminNo.substring(0, 6));
		}
		age = (currentDate - birthday) / 10000;
		return age;
	}
	
	 public static String addMonths(String s, int month)
	        throws Exception
	    {
	        return addMonths(s, month, "yyyyMMdd");
	    }

	    public static String addMonths(String s, int addMonth, String format)
	        throws Exception
	    {
	    	if(format == null){
	    		return "";
	    	}
	    	
	        SimpleDateFormat formatter = new SimpleDateFormat(format, Locale.KOREA);
	        Date date = check(s, format);
	        SimpleDateFormat yearFormat = new SimpleDateFormat("yyyy", Locale.KOREA);
	        SimpleDateFormat monthFormat = new SimpleDateFormat("MM", Locale.KOREA);
	        SimpleDateFormat dayFormat = new SimpleDateFormat("dd", Locale.KOREA);
	        int year = Integer.parseInt(yearFormat.format(date));
	        int month = Integer.parseInt(monthFormat.format(date));
	        int day = Integer.parseInt(dayFormat.format(date));
	        month += addMonth;
	        if(addMonth > 0)
	            while(month > 12) 
	            {
	                month -= 12;
	                year++;
	            }
	        else
	            while(month <= 0) 
	            {
	                month += 12;
	                year--;
	            }
	        DecimalFormat fourDf = new DecimalFormat("0000");
	        DecimalFormat twoDf = new DecimalFormat("00");
	        String tempDate = String.valueOf(fourDf.format(year)) + String.valueOf(twoDf.format(month)) + String.valueOf(twoDf.format(day));
	        Date targetDate = null;
	        try
	        {
	            targetDate = check(tempDate, "yyyyMMdd");
	        }
	        catch(ParseException pe)
	        {
	            day = lastDay(year, month);
	            tempDate = String.valueOf(fourDf.format(year)) + String.valueOf(twoDf.format(month)) + String.valueOf(twoDf.format(day));
	            targetDate = check(tempDate, "yyyyMMdd");
	        }
	        return formatter.format(targetDate);
	    }
		    
    public static Date check(String s, String format)
            throws ParseException
        {
            if(s == null)
                throw new ParseException("date string to check is null", 0);
            if(format == null)
                throw new ParseException("format string to check date is null", 0);
            SimpleDateFormat formatter = new SimpleDateFormat(format, Locale.KOREA);
            Date date = null;
            try
            {
                date = formatter.parse(s);
            }
            catch(ParseException e)
            {
                throw new ParseException(" wrong date:\"" + s + "\" with format \"" + format + "\"", 0);
            }
            if(!formatter.format(date).equals(s))
                throw new ParseException("Out of bound date:\"" + s + "\" with format \"" + format + "\"", 0);
            else
                return date;
        }
    
    private static int lastDay(int year, int month)
    {
        int day = 0;
        switch(month)
        {
        case 1: // '\001'
        case 3: // '\003'
        case 5: // '\005'
        case 7: // '\007'
        case 8: // '\b'
        case 10: // '\n'
        case 12: // '\f'
            day = 31;
            break;

        case 2: // '\002'
            if(year % 4 == 0)
            {
                if(year % 100 == 0 && year % 400 != 0)
                    day = 28;
                else
                    day = 29;
            } else
            {
                day = 28;
            }
            break;

        case 4: // '\004'
        case 6: // '\006'
        case 9: // '\t'
        case 11: // '\013'
        default:
            day = 30;
            break;
        }
        return day;
    }
	
} // END ACTION 









