package com.idongbu.util;

public class GlobalConstant {
	
	/** 자녀보험 보종 코드 리스트*/
	public static String[] BJ_CODE_LIST = new String[]{"30134", "30149", "30169", "30178", "30190", "30211", "30215", "30240",
		"30241", "30243", "30253", "30260", "30268", "30271", "30273", "30274", "30275", "30276", "30279", "30282", "30286", "30288", "30291",
		"30292", "30294", "30296", "30312", "30315", "30326",  "30337", "30339", "30345",  "30361", "30363", "30851", "30852", "30855", "30860",
		"30289","30247","30867", "30381", "30367", "30297", "30261", "30877", "30299", "30387", "30875", "30882", "30954", "30951","30967","30966",       
		"30964", "30894","30968", "30977", "30984","30985", "30996", "30503","30995","30525","30526","30865","30527"};

	//자동차계약조회 보종코드
	public static String[] CAR_BJ_CODE = new String[]{"20001", "20009", "20008", "20014", "20016", "20023", "20019", "20025","20027"};
	
	/** 보종 코드 */
	public static String BJ_CODE = setBJ_CODE();
	
	/** 보종코드 세팅 함수**/
	public static String setBJ_CODE(){
		String result = "";
		
		if(BJ_CODE_LIST.length>0){//보종코드가 있을 경우
			
			for(int i=0;i<BJ_CODE_LIST.length;i++){
				if(i!=0){//두번째 보종코드부터 구분자를 붙인다.
					result += ",";
				}
				result += "'"+BJ_CODE_LIST[i]+"'";
			}			
		}		
		return result;
	}

	/** 보종코드 검색 함수 **/
	public static boolean search_BJ_CODE(String code){
		boolean result = false;
		for(int i=0;i<BJ_CODE_LIST.length;i++){
			if(code.equals(BJ_CODE_LIST[i])){
				result = true;
			}
		}		
		return result;
	}
}
